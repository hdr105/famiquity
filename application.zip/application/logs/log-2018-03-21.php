<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-21 15:17:39 --> Config Class Initialized
INFO - 2018-03-21 15:17:39 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:17:39 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:17:39 --> Utf8 Class Initialized
INFO - 2018-03-21 15:17:39 --> URI Class Initialized
INFO - 2018-03-21 15:17:39 --> Router Class Initialized
INFO - 2018-03-21 15:17:39 --> Output Class Initialized
INFO - 2018-03-21 15:17:39 --> Security Class Initialized
DEBUG - 2018-03-21 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:17:39 --> CSRF cookie sent
INFO - 2018-03-21 15:17:39 --> Input Class Initialized
INFO - 2018-03-21 15:17:39 --> Language Class Initialized
INFO - 2018-03-21 15:17:39 --> Loader Class Initialized
INFO - 2018-03-21 15:17:39 --> Helper loaded: url_helper
INFO - 2018-03-21 15:17:39 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:17:39 --> User Agent Class Initialized
INFO - 2018-03-21 15:17:39 --> Controller Class Initialized
INFO - 2018-03-21 15:17:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:17:39 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-21 15:17:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:17:39 --> Final output sent to browser
DEBUG - 2018-03-21 15:17:39 --> Total execution time: 0.6484
INFO - 2018-03-21 15:17:40 --> Config Class Initialized
INFO - 2018-03-21 15:17:40 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:17:40 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:17:40 --> Utf8 Class Initialized
INFO - 2018-03-21 15:17:40 --> URI Class Initialized
INFO - 2018-03-21 15:17:40 --> Router Class Initialized
INFO - 2018-03-21 15:17:40 --> Output Class Initialized
INFO - 2018-03-21 15:17:40 --> Security Class Initialized
DEBUG - 2018-03-21 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:17:40 --> CSRF cookie sent
INFO - 2018-03-21 15:17:40 --> Input Class Initialized
INFO - 2018-03-21 15:17:40 --> Language Class Initialized
ERROR - 2018-03-21 15:17:40 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:17:43 --> Config Class Initialized
INFO - 2018-03-21 15:17:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:17:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:17:43 --> Utf8 Class Initialized
INFO - 2018-03-21 15:17:43 --> URI Class Initialized
INFO - 2018-03-21 15:17:43 --> Router Class Initialized
INFO - 2018-03-21 15:17:43 --> Output Class Initialized
INFO - 2018-03-21 15:17:43 --> Security Class Initialized
DEBUG - 2018-03-21 15:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:17:43 --> CSRF cookie sent
INFO - 2018-03-21 15:17:43 --> Input Class Initialized
INFO - 2018-03-21 15:17:43 --> Language Class Initialized
INFO - 2018-03-21 15:17:43 --> Loader Class Initialized
INFO - 2018-03-21 15:17:43 --> Helper loaded: url_helper
INFO - 2018-03-21 15:17:43 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:17:43 --> User Agent Class Initialized
INFO - 2018-03-21 15:17:43 --> Controller Class Initialized
INFO - 2018-03-21 15:17:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:17:43 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:17:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:17:43 --> Final output sent to browser
DEBUG - 2018-03-21 15:17:43 --> Total execution time: 0.1840
INFO - 2018-03-21 15:17:44 --> Config Class Initialized
INFO - 2018-03-21 15:17:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:17:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:17:44 --> Utf8 Class Initialized
INFO - 2018-03-21 15:17:44 --> URI Class Initialized
INFO - 2018-03-21 15:17:44 --> Router Class Initialized
INFO - 2018-03-21 15:17:44 --> Output Class Initialized
INFO - 2018-03-21 15:17:44 --> Security Class Initialized
DEBUG - 2018-03-21 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:17:44 --> CSRF cookie sent
INFO - 2018-03-21 15:17:44 --> Input Class Initialized
INFO - 2018-03-21 15:17:44 --> Language Class Initialized
ERROR - 2018-03-21 15:17:44 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:20:21 --> Config Class Initialized
INFO - 2018-03-21 15:20:21 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:20:21 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:20:21 --> Utf8 Class Initialized
INFO - 2018-03-21 15:20:21 --> URI Class Initialized
INFO - 2018-03-21 15:20:21 --> Router Class Initialized
INFO - 2018-03-21 15:20:21 --> Output Class Initialized
INFO - 2018-03-21 15:20:21 --> Security Class Initialized
DEBUG - 2018-03-21 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:20:21 --> CSRF cookie sent
INFO - 2018-03-21 15:20:21 --> Input Class Initialized
INFO - 2018-03-21 15:20:21 --> Language Class Initialized
ERROR - 2018-03-21 15:20:21 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:21:07 --> Config Class Initialized
INFO - 2018-03-21 15:21:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:21:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:21:07 --> Utf8 Class Initialized
INFO - 2018-03-21 15:21:07 --> URI Class Initialized
INFO - 2018-03-21 15:21:07 --> Router Class Initialized
INFO - 2018-03-21 15:21:07 --> Output Class Initialized
INFO - 2018-03-21 15:21:07 --> Security Class Initialized
DEBUG - 2018-03-21 15:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:21:07 --> CSRF cookie sent
INFO - 2018-03-21 15:21:07 --> Input Class Initialized
INFO - 2018-03-21 15:21:07 --> Language Class Initialized
INFO - 2018-03-21 15:21:07 --> Loader Class Initialized
INFO - 2018-03-21 15:21:07 --> Helper loaded: url_helper
INFO - 2018-03-21 15:21:07 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:21:07 --> User Agent Class Initialized
INFO - 2018-03-21 15:21:07 --> Controller Class Initialized
INFO - 2018-03-21 15:21:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:21:07 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:21:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:21:07 --> Final output sent to browser
DEBUG - 2018-03-21 15:21:07 --> Total execution time: 0.1870
INFO - 2018-03-21 15:21:07 --> Config Class Initialized
INFO - 2018-03-21 15:21:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:21:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:21:07 --> Utf8 Class Initialized
INFO - 2018-03-21 15:21:07 --> URI Class Initialized
INFO - 2018-03-21 15:21:07 --> Router Class Initialized
INFO - 2018-03-21 15:21:07 --> Output Class Initialized
INFO - 2018-03-21 15:21:07 --> Security Class Initialized
DEBUG - 2018-03-21 15:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:21:07 --> CSRF cookie sent
INFO - 2018-03-21 15:21:07 --> Input Class Initialized
INFO - 2018-03-21 15:21:07 --> Language Class Initialized
ERROR - 2018-03-21 15:21:07 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:21:07 --> Config Class Initialized
INFO - 2018-03-21 15:21:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:21:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:21:07 --> Utf8 Class Initialized
INFO - 2018-03-21 15:21:07 --> URI Class Initialized
INFO - 2018-03-21 15:21:07 --> Router Class Initialized
INFO - 2018-03-21 15:21:08 --> Output Class Initialized
INFO - 2018-03-21 15:21:08 --> Security Class Initialized
DEBUG - 2018-03-21 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:21:08 --> CSRF cookie sent
INFO - 2018-03-21 15:21:08 --> Input Class Initialized
INFO - 2018-03-21 15:21:08 --> Language Class Initialized
ERROR - 2018-03-21 15:21:08 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:22:10 --> Config Class Initialized
INFO - 2018-03-21 15:22:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:10 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:10 --> URI Class Initialized
INFO - 2018-03-21 15:22:10 --> Router Class Initialized
INFO - 2018-03-21 15:22:10 --> Output Class Initialized
INFO - 2018-03-21 15:22:10 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:10 --> CSRF cookie sent
INFO - 2018-03-21 15:22:10 --> Input Class Initialized
INFO - 2018-03-21 15:22:10 --> Language Class Initialized
INFO - 2018-03-21 15:22:10 --> Loader Class Initialized
INFO - 2018-03-21 15:22:10 --> Helper loaded: url_helper
INFO - 2018-03-21 15:22:10 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:22:10 --> User Agent Class Initialized
INFO - 2018-03-21 15:22:10 --> Controller Class Initialized
INFO - 2018-03-21 15:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:22:10 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:22:10 --> Final output sent to browser
DEBUG - 2018-03-21 15:22:10 --> Total execution time: 0.1823
INFO - 2018-03-21 15:22:10 --> Config Class Initialized
INFO - 2018-03-21 15:22:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:10 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:10 --> URI Class Initialized
INFO - 2018-03-21 15:22:10 --> Router Class Initialized
INFO - 2018-03-21 15:22:10 --> Output Class Initialized
INFO - 2018-03-21 15:22:10 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:10 --> CSRF cookie sent
INFO - 2018-03-21 15:22:10 --> Input Class Initialized
INFO - 2018-03-21 15:22:10 --> Language Class Initialized
ERROR - 2018-03-21 15:22:10 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:22:11 --> Config Class Initialized
INFO - 2018-03-21 15:22:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:11 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:11 --> URI Class Initialized
INFO - 2018-03-21 15:22:11 --> Router Class Initialized
INFO - 2018-03-21 15:22:11 --> Output Class Initialized
INFO - 2018-03-21 15:22:11 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:11 --> CSRF cookie sent
INFO - 2018-03-21 15:22:11 --> Input Class Initialized
INFO - 2018-03-21 15:22:11 --> Language Class Initialized
ERROR - 2018-03-21 15:22:11 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:22:33 --> Config Class Initialized
INFO - 2018-03-21 15:22:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:33 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:33 --> URI Class Initialized
INFO - 2018-03-21 15:22:33 --> Router Class Initialized
INFO - 2018-03-21 15:22:33 --> Output Class Initialized
INFO - 2018-03-21 15:22:33 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:33 --> CSRF cookie sent
INFO - 2018-03-21 15:22:33 --> Input Class Initialized
INFO - 2018-03-21 15:22:33 --> Language Class Initialized
INFO - 2018-03-21 15:22:33 --> Loader Class Initialized
INFO - 2018-03-21 15:22:33 --> Helper loaded: url_helper
INFO - 2018-03-21 15:22:33 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:22:33 --> User Agent Class Initialized
INFO - 2018-03-21 15:22:33 --> Controller Class Initialized
INFO - 2018-03-21 15:22:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:22:33 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:22:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:22:33 --> Final output sent to browser
DEBUG - 2018-03-21 15:22:33 --> Total execution time: 0.1866
INFO - 2018-03-21 15:22:33 --> Config Class Initialized
INFO - 2018-03-21 15:22:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:33 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:33 --> URI Class Initialized
INFO - 2018-03-21 15:22:33 --> Router Class Initialized
INFO - 2018-03-21 15:22:33 --> Output Class Initialized
INFO - 2018-03-21 15:22:33 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:33 --> CSRF cookie sent
INFO - 2018-03-21 15:22:33 --> Input Class Initialized
INFO - 2018-03-21 15:22:33 --> Language Class Initialized
ERROR - 2018-03-21 15:22:33 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:22:33 --> Config Class Initialized
INFO - 2018-03-21 15:22:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:33 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:33 --> URI Class Initialized
INFO - 2018-03-21 15:22:33 --> Router Class Initialized
INFO - 2018-03-21 15:22:33 --> Output Class Initialized
INFO - 2018-03-21 15:22:33 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:33 --> CSRF cookie sent
INFO - 2018-03-21 15:22:33 --> Input Class Initialized
INFO - 2018-03-21 15:22:33 --> Language Class Initialized
ERROR - 2018-03-21 15:22:33 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:22:47 --> Config Class Initialized
INFO - 2018-03-21 15:22:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:47 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:47 --> URI Class Initialized
INFO - 2018-03-21 15:22:47 --> Router Class Initialized
INFO - 2018-03-21 15:22:47 --> Output Class Initialized
INFO - 2018-03-21 15:22:47 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:47 --> CSRF cookie sent
INFO - 2018-03-21 15:22:47 --> Input Class Initialized
INFO - 2018-03-21 15:22:47 --> Language Class Initialized
INFO - 2018-03-21 15:22:47 --> Loader Class Initialized
INFO - 2018-03-21 15:22:47 --> Helper loaded: url_helper
INFO - 2018-03-21 15:22:47 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:22:47 --> User Agent Class Initialized
INFO - 2018-03-21 15:22:47 --> Controller Class Initialized
INFO - 2018-03-21 15:22:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:22:47 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:22:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:22:47 --> Final output sent to browser
DEBUG - 2018-03-21 15:22:47 --> Total execution time: 0.1966
INFO - 2018-03-21 15:22:47 --> Config Class Initialized
INFO - 2018-03-21 15:22:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:47 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:47 --> URI Class Initialized
INFO - 2018-03-21 15:22:47 --> Router Class Initialized
INFO - 2018-03-21 15:22:47 --> Output Class Initialized
INFO - 2018-03-21 15:22:47 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:47 --> CSRF cookie sent
INFO - 2018-03-21 15:22:47 --> Input Class Initialized
INFO - 2018-03-21 15:22:47 --> Language Class Initialized
ERROR - 2018-03-21 15:22:47 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:22:48 --> Config Class Initialized
INFO - 2018-03-21 15:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:22:48 --> Utf8 Class Initialized
INFO - 2018-03-21 15:22:48 --> URI Class Initialized
INFO - 2018-03-21 15:22:48 --> Router Class Initialized
INFO - 2018-03-21 15:22:48 --> Output Class Initialized
INFO - 2018-03-21 15:22:48 --> Security Class Initialized
DEBUG - 2018-03-21 15:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:22:48 --> CSRF cookie sent
INFO - 2018-03-21 15:22:48 --> Input Class Initialized
INFO - 2018-03-21 15:22:48 --> Language Class Initialized
ERROR - 2018-03-21 15:22:48 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:23:29 --> Config Class Initialized
INFO - 2018-03-21 15:23:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:29 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:29 --> URI Class Initialized
INFO - 2018-03-21 15:23:29 --> Router Class Initialized
INFO - 2018-03-21 15:23:29 --> Output Class Initialized
INFO - 2018-03-21 15:23:29 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:29 --> CSRF cookie sent
INFO - 2018-03-21 15:23:30 --> Input Class Initialized
INFO - 2018-03-21 15:23:30 --> Language Class Initialized
INFO - 2018-03-21 15:23:30 --> Loader Class Initialized
INFO - 2018-03-21 15:23:30 --> Helper loaded: url_helper
INFO - 2018-03-21 15:23:30 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:23:30 --> User Agent Class Initialized
INFO - 2018-03-21 15:23:30 --> Controller Class Initialized
INFO - 2018-03-21 15:23:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:23:30 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:23:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:23:30 --> Final output sent to browser
DEBUG - 2018-03-21 15:23:30 --> Total execution time: 0.2033
INFO - 2018-03-21 15:23:30 --> Config Class Initialized
INFO - 2018-03-21 15:23:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:30 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:30 --> URI Class Initialized
INFO - 2018-03-21 15:23:30 --> Router Class Initialized
INFO - 2018-03-21 15:23:30 --> Output Class Initialized
INFO - 2018-03-21 15:23:30 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:30 --> CSRF cookie sent
INFO - 2018-03-21 15:23:30 --> Input Class Initialized
INFO - 2018-03-21 15:23:30 --> Language Class Initialized
ERROR - 2018-03-21 15:23:30 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:23:30 --> Config Class Initialized
INFO - 2018-03-21 15:23:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:30 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:30 --> URI Class Initialized
INFO - 2018-03-21 15:23:30 --> Router Class Initialized
INFO - 2018-03-21 15:23:30 --> Output Class Initialized
INFO - 2018-03-21 15:23:30 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:30 --> CSRF cookie sent
INFO - 2018-03-21 15:23:30 --> Input Class Initialized
INFO - 2018-03-21 15:23:30 --> Language Class Initialized
ERROR - 2018-03-21 15:23:30 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:23:44 --> Config Class Initialized
INFO - 2018-03-21 15:23:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:44 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:44 --> URI Class Initialized
INFO - 2018-03-21 15:23:44 --> Router Class Initialized
INFO - 2018-03-21 15:23:44 --> Output Class Initialized
INFO - 2018-03-21 15:23:44 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:44 --> CSRF cookie sent
INFO - 2018-03-21 15:23:44 --> Input Class Initialized
INFO - 2018-03-21 15:23:44 --> Language Class Initialized
INFO - 2018-03-21 15:23:44 --> Loader Class Initialized
INFO - 2018-03-21 15:23:44 --> Helper loaded: url_helper
INFO - 2018-03-21 15:23:44 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:23:44 --> User Agent Class Initialized
INFO - 2018-03-21 15:23:44 --> Controller Class Initialized
INFO - 2018-03-21 15:23:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:23:44 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:23:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:23:44 --> Final output sent to browser
DEBUG - 2018-03-21 15:23:44 --> Total execution time: 0.2098
INFO - 2018-03-21 15:23:44 --> Config Class Initialized
INFO - 2018-03-21 15:23:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:44 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:44 --> URI Class Initialized
INFO - 2018-03-21 15:23:44 --> Router Class Initialized
INFO - 2018-03-21 15:23:44 --> Output Class Initialized
INFO - 2018-03-21 15:23:44 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:44 --> CSRF cookie sent
INFO - 2018-03-21 15:23:44 --> Input Class Initialized
INFO - 2018-03-21 15:23:44 --> Language Class Initialized
ERROR - 2018-03-21 15:23:44 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:23:44 --> Config Class Initialized
INFO - 2018-03-21 15:23:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:23:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:23:44 --> Utf8 Class Initialized
INFO - 2018-03-21 15:23:44 --> URI Class Initialized
INFO - 2018-03-21 15:23:44 --> Router Class Initialized
INFO - 2018-03-21 15:23:44 --> Output Class Initialized
INFO - 2018-03-21 15:23:44 --> Security Class Initialized
DEBUG - 2018-03-21 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:23:44 --> CSRF cookie sent
INFO - 2018-03-21 15:23:44 --> Input Class Initialized
INFO - 2018-03-21 15:23:44 --> Language Class Initialized
ERROR - 2018-03-21 15:23:44 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:24:32 --> Config Class Initialized
INFO - 2018-03-21 15:24:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:24:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:24:32 --> Utf8 Class Initialized
INFO - 2018-03-21 15:24:32 --> URI Class Initialized
INFO - 2018-03-21 15:24:32 --> Router Class Initialized
INFO - 2018-03-21 15:24:32 --> Output Class Initialized
INFO - 2018-03-21 15:24:32 --> Security Class Initialized
DEBUG - 2018-03-21 15:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:24:32 --> CSRF cookie sent
INFO - 2018-03-21 15:24:32 --> Input Class Initialized
INFO - 2018-03-21 15:24:32 --> Language Class Initialized
INFO - 2018-03-21 15:24:32 --> Loader Class Initialized
INFO - 2018-03-21 15:24:32 --> Helper loaded: url_helper
INFO - 2018-03-21 15:24:32 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:24:32 --> User Agent Class Initialized
INFO - 2018-03-21 15:24:32 --> Controller Class Initialized
INFO - 2018-03-21 15:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:24:32 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:24:32 --> Final output sent to browser
DEBUG - 2018-03-21 15:24:32 --> Total execution time: 0.1892
INFO - 2018-03-21 15:24:32 --> Config Class Initialized
INFO - 2018-03-21 15:24:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:24:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:24:32 --> Utf8 Class Initialized
INFO - 2018-03-21 15:24:32 --> URI Class Initialized
INFO - 2018-03-21 15:24:32 --> Router Class Initialized
INFO - 2018-03-21 15:24:32 --> Output Class Initialized
INFO - 2018-03-21 15:24:32 --> Security Class Initialized
DEBUG - 2018-03-21 15:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:24:32 --> CSRF cookie sent
INFO - 2018-03-21 15:24:32 --> Input Class Initialized
INFO - 2018-03-21 15:24:32 --> Language Class Initialized
ERROR - 2018-03-21 15:24:32 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:24:32 --> Config Class Initialized
INFO - 2018-03-21 15:24:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:24:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:24:33 --> Utf8 Class Initialized
INFO - 2018-03-21 15:24:33 --> URI Class Initialized
INFO - 2018-03-21 15:24:33 --> Router Class Initialized
INFO - 2018-03-21 15:24:33 --> Output Class Initialized
INFO - 2018-03-21 15:24:33 --> Security Class Initialized
DEBUG - 2018-03-21 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:24:33 --> CSRF cookie sent
INFO - 2018-03-21 15:24:33 --> Input Class Initialized
INFO - 2018-03-21 15:24:33 --> Language Class Initialized
ERROR - 2018-03-21 15:24:33 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:25:48 --> Config Class Initialized
INFO - 2018-03-21 15:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:25:48 --> Utf8 Class Initialized
INFO - 2018-03-21 15:25:48 --> URI Class Initialized
INFO - 2018-03-21 15:25:48 --> Router Class Initialized
INFO - 2018-03-21 15:25:48 --> Output Class Initialized
INFO - 2018-03-21 15:25:48 --> Security Class Initialized
DEBUG - 2018-03-21 15:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:25:48 --> CSRF cookie sent
INFO - 2018-03-21 15:25:48 --> Input Class Initialized
INFO - 2018-03-21 15:25:48 --> Language Class Initialized
INFO - 2018-03-21 15:25:48 --> Loader Class Initialized
INFO - 2018-03-21 15:25:48 --> Helper loaded: url_helper
INFO - 2018-03-21 15:25:48 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:25:48 --> User Agent Class Initialized
INFO - 2018-03-21 15:25:48 --> Controller Class Initialized
INFO - 2018-03-21 15:25:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:25:48 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:25:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:25:48 --> Final output sent to browser
DEBUG - 2018-03-21 15:25:48 --> Total execution time: 0.1989
INFO - 2018-03-21 15:25:48 --> Config Class Initialized
INFO - 2018-03-21 15:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:25:48 --> Utf8 Class Initialized
INFO - 2018-03-21 15:25:48 --> URI Class Initialized
INFO - 2018-03-21 15:25:48 --> Router Class Initialized
INFO - 2018-03-21 15:25:48 --> Output Class Initialized
INFO - 2018-03-21 15:25:48 --> Security Class Initialized
DEBUG - 2018-03-21 15:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:25:48 --> CSRF cookie sent
INFO - 2018-03-21 15:25:48 --> Input Class Initialized
INFO - 2018-03-21 15:25:48 --> Language Class Initialized
ERROR - 2018-03-21 15:25:48 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:25:48 --> Config Class Initialized
INFO - 2018-03-21 15:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:25:48 --> Utf8 Class Initialized
INFO - 2018-03-21 15:25:48 --> URI Class Initialized
INFO - 2018-03-21 15:25:48 --> Router Class Initialized
INFO - 2018-03-21 15:25:48 --> Output Class Initialized
INFO - 2018-03-21 15:25:48 --> Security Class Initialized
DEBUG - 2018-03-21 15:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:25:48 --> CSRF cookie sent
INFO - 2018-03-21 15:25:48 --> Input Class Initialized
INFO - 2018-03-21 15:25:48 --> Language Class Initialized
ERROR - 2018-03-21 15:25:48 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:26:03 --> Config Class Initialized
INFO - 2018-03-21 15:26:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:03 --> URI Class Initialized
INFO - 2018-03-21 15:26:03 --> Router Class Initialized
INFO - 2018-03-21 15:26:03 --> Output Class Initialized
INFO - 2018-03-21 15:26:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:03 --> CSRF cookie sent
INFO - 2018-03-21 15:26:03 --> Input Class Initialized
INFO - 2018-03-21 15:26:03 --> Language Class Initialized
INFO - 2018-03-21 15:26:03 --> Loader Class Initialized
INFO - 2018-03-21 15:26:03 --> Helper loaded: url_helper
INFO - 2018-03-21 15:26:03 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:26:03 --> User Agent Class Initialized
INFO - 2018-03-21 15:26:03 --> Controller Class Initialized
INFO - 2018-03-21 15:26:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:26:03 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:26:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:26:03 --> Final output sent to browser
DEBUG - 2018-03-21 15:26:03 --> Total execution time: 0.2019
INFO - 2018-03-21 15:26:03 --> Config Class Initialized
INFO - 2018-03-21 15:26:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:03 --> URI Class Initialized
INFO - 2018-03-21 15:26:03 --> Router Class Initialized
INFO - 2018-03-21 15:26:03 --> Output Class Initialized
INFO - 2018-03-21 15:26:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:03 --> CSRF cookie sent
INFO - 2018-03-21 15:26:03 --> Input Class Initialized
INFO - 2018-03-21 15:26:03 --> Language Class Initialized
ERROR - 2018-03-21 15:26:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:26:03 --> Config Class Initialized
INFO - 2018-03-21 15:26:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:03 --> URI Class Initialized
INFO - 2018-03-21 15:26:03 --> Router Class Initialized
INFO - 2018-03-21 15:26:03 --> Output Class Initialized
INFO - 2018-03-21 15:26:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:03 --> CSRF cookie sent
INFO - 2018-03-21 15:26:03 --> Input Class Initialized
INFO - 2018-03-21 15:26:03 --> Language Class Initialized
ERROR - 2018-03-21 15:26:03 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:26:26 --> Config Class Initialized
INFO - 2018-03-21 15:26:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:26 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:26 --> URI Class Initialized
INFO - 2018-03-21 15:26:26 --> Router Class Initialized
INFO - 2018-03-21 15:26:26 --> Output Class Initialized
INFO - 2018-03-21 15:26:26 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:26 --> CSRF cookie sent
INFO - 2018-03-21 15:26:26 --> Input Class Initialized
INFO - 2018-03-21 15:26:26 --> Language Class Initialized
INFO - 2018-03-21 15:26:26 --> Loader Class Initialized
INFO - 2018-03-21 15:26:26 --> Helper loaded: url_helper
INFO - 2018-03-21 15:26:26 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:26:26 --> User Agent Class Initialized
INFO - 2018-03-21 15:26:27 --> Controller Class Initialized
INFO - 2018-03-21 15:26:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:26:27 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:26:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:26:27 --> Final output sent to browser
DEBUG - 2018-03-21 15:26:27 --> Total execution time: 0.2019
INFO - 2018-03-21 15:26:27 --> Config Class Initialized
INFO - 2018-03-21 15:26:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:27 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:27 --> URI Class Initialized
INFO - 2018-03-21 15:26:27 --> Router Class Initialized
INFO - 2018-03-21 15:26:27 --> Output Class Initialized
INFO - 2018-03-21 15:26:27 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:27 --> CSRF cookie sent
INFO - 2018-03-21 15:26:27 --> Input Class Initialized
INFO - 2018-03-21 15:26:27 --> Language Class Initialized
ERROR - 2018-03-21 15:26:27 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:26:27 --> Config Class Initialized
INFO - 2018-03-21 15:26:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:26:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:26:27 --> Utf8 Class Initialized
INFO - 2018-03-21 15:26:27 --> URI Class Initialized
INFO - 2018-03-21 15:26:27 --> Router Class Initialized
INFO - 2018-03-21 15:26:27 --> Output Class Initialized
INFO - 2018-03-21 15:26:27 --> Security Class Initialized
DEBUG - 2018-03-21 15:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:26:27 --> CSRF cookie sent
INFO - 2018-03-21 15:26:27 --> Input Class Initialized
INFO - 2018-03-21 15:26:27 --> Language Class Initialized
ERROR - 2018-03-21 15:26:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:27:28 --> Config Class Initialized
INFO - 2018-03-21 15:27:28 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:28 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:29 --> URI Class Initialized
INFO - 2018-03-21 15:27:29 --> Router Class Initialized
INFO - 2018-03-21 15:27:29 --> Output Class Initialized
INFO - 2018-03-21 15:27:29 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:29 --> CSRF cookie sent
INFO - 2018-03-21 15:27:29 --> Input Class Initialized
INFO - 2018-03-21 15:27:29 --> Language Class Initialized
INFO - 2018-03-21 15:27:29 --> Loader Class Initialized
INFO - 2018-03-21 15:27:29 --> Helper loaded: url_helper
INFO - 2018-03-21 15:27:29 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:27:29 --> User Agent Class Initialized
INFO - 2018-03-21 15:27:29 --> Controller Class Initialized
INFO - 2018-03-21 15:27:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:27:29 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:27:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:27:29 --> Final output sent to browser
DEBUG - 2018-03-21 15:27:29 --> Total execution time: 0.2014
INFO - 2018-03-21 15:27:29 --> Config Class Initialized
INFO - 2018-03-21 15:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:29 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:29 --> URI Class Initialized
INFO - 2018-03-21 15:27:29 --> Router Class Initialized
INFO - 2018-03-21 15:27:29 --> Output Class Initialized
INFO - 2018-03-21 15:27:29 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:29 --> CSRF cookie sent
INFO - 2018-03-21 15:27:29 --> Input Class Initialized
INFO - 2018-03-21 15:27:29 --> Language Class Initialized
ERROR - 2018-03-21 15:27:29 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:27:29 --> Config Class Initialized
INFO - 2018-03-21 15:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:29 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:29 --> URI Class Initialized
INFO - 2018-03-21 15:27:29 --> Router Class Initialized
INFO - 2018-03-21 15:27:29 --> Output Class Initialized
INFO - 2018-03-21 15:27:29 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:29 --> CSRF cookie sent
INFO - 2018-03-21 15:27:29 --> Input Class Initialized
INFO - 2018-03-21 15:27:29 --> Language Class Initialized
ERROR - 2018-03-21 15:27:29 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:27:54 --> Config Class Initialized
INFO - 2018-03-21 15:27:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:54 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:54 --> URI Class Initialized
INFO - 2018-03-21 15:27:54 --> Router Class Initialized
INFO - 2018-03-21 15:27:54 --> Output Class Initialized
INFO - 2018-03-21 15:27:54 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:54 --> CSRF cookie sent
INFO - 2018-03-21 15:27:54 --> Input Class Initialized
INFO - 2018-03-21 15:27:54 --> Language Class Initialized
INFO - 2018-03-21 15:27:54 --> Loader Class Initialized
INFO - 2018-03-21 15:27:54 --> Helper loaded: url_helper
INFO - 2018-03-21 15:27:54 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:27:54 --> User Agent Class Initialized
INFO - 2018-03-21 15:27:54 --> Controller Class Initialized
INFO - 2018-03-21 15:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:27:54 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:27:54 --> Final output sent to browser
DEBUG - 2018-03-21 15:27:54 --> Total execution time: 0.2127
INFO - 2018-03-21 15:27:54 --> Config Class Initialized
INFO - 2018-03-21 15:27:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:55 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:55 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:55 --> URI Class Initialized
INFO - 2018-03-21 15:27:55 --> Router Class Initialized
INFO - 2018-03-21 15:27:55 --> Output Class Initialized
INFO - 2018-03-21 15:27:55 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:55 --> CSRF cookie sent
INFO - 2018-03-21 15:27:55 --> Input Class Initialized
INFO - 2018-03-21 15:27:55 --> Language Class Initialized
ERROR - 2018-03-21 15:27:55 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:27:55 --> Config Class Initialized
INFO - 2018-03-21 15:27:55 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:27:55 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:27:55 --> Utf8 Class Initialized
INFO - 2018-03-21 15:27:55 --> URI Class Initialized
INFO - 2018-03-21 15:27:55 --> Router Class Initialized
INFO - 2018-03-21 15:27:55 --> Output Class Initialized
INFO - 2018-03-21 15:27:55 --> Security Class Initialized
DEBUG - 2018-03-21 15:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:27:55 --> CSRF cookie sent
INFO - 2018-03-21 15:27:55 --> Input Class Initialized
INFO - 2018-03-21 15:27:55 --> Language Class Initialized
ERROR - 2018-03-21 15:27:55 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 15:29:03 --> Config Class Initialized
INFO - 2018-03-21 15:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:29:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:29:03 --> URI Class Initialized
INFO - 2018-03-21 15:29:03 --> Router Class Initialized
INFO - 2018-03-21 15:29:03 --> Output Class Initialized
INFO - 2018-03-21 15:29:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:29:03 --> CSRF cookie sent
INFO - 2018-03-21 15:29:03 --> Input Class Initialized
INFO - 2018-03-21 15:29:03 --> Language Class Initialized
INFO - 2018-03-21 15:29:03 --> Loader Class Initialized
INFO - 2018-03-21 15:29:03 --> Helper loaded: url_helper
INFO - 2018-03-21 15:29:03 --> Helper loaded: form_helper
DEBUG - 2018-03-21 15:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 15:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 15:29:03 --> User Agent Class Initialized
INFO - 2018-03-21 15:29:03 --> Controller Class Initialized
INFO - 2018-03-21 15:29:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 15:29:03 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 15:29:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 15:29:03 --> Final output sent to browser
DEBUG - 2018-03-21 15:29:03 --> Total execution time: 0.2027
INFO - 2018-03-21 15:29:03 --> Config Class Initialized
INFO - 2018-03-21 15:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:29:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:29:03 --> URI Class Initialized
INFO - 2018-03-21 15:29:03 --> Router Class Initialized
INFO - 2018-03-21 15:29:03 --> Output Class Initialized
INFO - 2018-03-21 15:29:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:29:03 --> CSRF cookie sent
INFO - 2018-03-21 15:29:03 --> Input Class Initialized
INFO - 2018-03-21 15:29:03 --> Language Class Initialized
ERROR - 2018-03-21 15:29:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 15:29:03 --> Config Class Initialized
INFO - 2018-03-21 15:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 15:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 15:29:03 --> Utf8 Class Initialized
INFO - 2018-03-21 15:29:03 --> URI Class Initialized
INFO - 2018-03-21 15:29:03 --> Router Class Initialized
INFO - 2018-03-21 15:29:03 --> Output Class Initialized
INFO - 2018-03-21 15:29:03 --> Security Class Initialized
DEBUG - 2018-03-21 15:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 15:29:03 --> CSRF cookie sent
INFO - 2018-03-21 15:29:03 --> Input Class Initialized
INFO - 2018-03-21 15:29:03 --> Language Class Initialized
ERROR - 2018-03-21 15:29:03 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 21:57:10 --> Config Class Initialized
INFO - 2018-03-21 21:57:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 21:57:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 21:57:10 --> Utf8 Class Initialized
INFO - 2018-03-21 21:57:10 --> URI Class Initialized
INFO - 2018-03-21 21:57:10 --> Router Class Initialized
INFO - 2018-03-21 21:57:10 --> Output Class Initialized
INFO - 2018-03-21 21:57:10 --> Security Class Initialized
DEBUG - 2018-03-21 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 21:57:10 --> CSRF cookie sent
INFO - 2018-03-21 21:57:10 --> Input Class Initialized
INFO - 2018-03-21 21:57:10 --> Language Class Initialized
INFO - 2018-03-21 21:57:10 --> Loader Class Initialized
INFO - 2018-03-21 21:57:10 --> Helper loaded: url_helper
INFO - 2018-03-21 21:57:10 --> Helper loaded: form_helper
DEBUG - 2018-03-21 21:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 21:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 21:57:11 --> User Agent Class Initialized
INFO - 2018-03-21 21:57:11 --> Controller Class Initialized
INFO - 2018-03-21 21:57:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 21:57:11 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-21 21:57:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 21:57:11 --> Final output sent to browser
DEBUG - 2018-03-21 21:57:11 --> Total execution time: 1.0233
INFO - 2018-03-21 21:57:12 --> Config Class Initialized
INFO - 2018-03-21 21:57:12 --> Hooks Class Initialized
DEBUG - 2018-03-21 21:57:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 21:57:12 --> Utf8 Class Initialized
INFO - 2018-03-21 21:57:12 --> URI Class Initialized
INFO - 2018-03-21 21:57:12 --> Router Class Initialized
INFO - 2018-03-21 21:57:12 --> Output Class Initialized
INFO - 2018-03-21 21:57:12 --> Security Class Initialized
DEBUG - 2018-03-21 21:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 21:57:12 --> CSRF cookie sent
INFO - 2018-03-21 21:57:12 --> Input Class Initialized
INFO - 2018-03-21 21:57:12 --> Language Class Initialized
ERROR - 2018-03-21 21:57:12 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:12:54 --> Config Class Initialized
INFO - 2018-03-21 22:12:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:12:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:12:54 --> Utf8 Class Initialized
INFO - 2018-03-21 22:12:54 --> URI Class Initialized
INFO - 2018-03-21 22:12:54 --> Router Class Initialized
INFO - 2018-03-21 22:12:54 --> Output Class Initialized
INFO - 2018-03-21 22:12:54 --> Security Class Initialized
DEBUG - 2018-03-21 22:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:12:54 --> CSRF cookie sent
INFO - 2018-03-21 22:12:54 --> Input Class Initialized
INFO - 2018-03-21 22:12:54 --> Language Class Initialized
INFO - 2018-03-21 22:12:54 --> Loader Class Initialized
INFO - 2018-03-21 22:12:54 --> Helper loaded: url_helper
INFO - 2018-03-21 22:12:54 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:12:54 --> User Agent Class Initialized
INFO - 2018-03-21 22:12:54 --> Controller Class Initialized
INFO - 2018-03-21 22:12:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:12:54 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-21 22:12:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:12:54 --> Final output sent to browser
DEBUG - 2018-03-21 22:12:54 --> Total execution time: 0.1955
INFO - 2018-03-21 22:12:54 --> Config Class Initialized
INFO - 2018-03-21 22:12:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:12:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:12:54 --> Utf8 Class Initialized
INFO - 2018-03-21 22:12:54 --> URI Class Initialized
INFO - 2018-03-21 22:12:54 --> Router Class Initialized
INFO - 2018-03-21 22:12:54 --> Output Class Initialized
INFO - 2018-03-21 22:12:54 --> Security Class Initialized
DEBUG - 2018-03-21 22:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:12:54 --> CSRF cookie sent
INFO - 2018-03-21 22:12:54 --> Input Class Initialized
INFO - 2018-03-21 22:12:54 --> Language Class Initialized
ERROR - 2018-03-21 22:12:54 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:12:56 --> Config Class Initialized
INFO - 2018-03-21 22:12:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:12:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:12:56 --> Utf8 Class Initialized
INFO - 2018-03-21 22:12:56 --> URI Class Initialized
INFO - 2018-03-21 22:12:56 --> Router Class Initialized
INFO - 2018-03-21 22:12:56 --> Output Class Initialized
INFO - 2018-03-21 22:12:56 --> Security Class Initialized
DEBUG - 2018-03-21 22:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:12:56 --> CSRF cookie sent
INFO - 2018-03-21 22:12:56 --> Input Class Initialized
INFO - 2018-03-21 22:12:56 --> Language Class Initialized
INFO - 2018-03-21 22:12:56 --> Loader Class Initialized
INFO - 2018-03-21 22:12:56 --> Helper loaded: url_helper
INFO - 2018-03-21 22:12:56 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:12:56 --> User Agent Class Initialized
INFO - 2018-03-21 22:12:56 --> Controller Class Initialized
INFO - 2018-03-21 22:12:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:12:56 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-21 22:12:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:12:56 --> Final output sent to browser
DEBUG - 2018-03-21 22:12:56 --> Total execution time: 0.2206
INFO - 2018-03-21 22:12:57 --> Config Class Initialized
INFO - 2018-03-21 22:12:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:12:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:12:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:12:57 --> URI Class Initialized
INFO - 2018-03-21 22:12:57 --> Router Class Initialized
INFO - 2018-03-21 22:12:57 --> Output Class Initialized
INFO - 2018-03-21 22:12:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:12:57 --> CSRF cookie sent
INFO - 2018-03-21 22:12:57 --> Input Class Initialized
INFO - 2018-03-21 22:12:57 --> Language Class Initialized
ERROR - 2018-03-21 22:12:57 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:13:12 --> Config Class Initialized
INFO - 2018-03-21 22:13:12 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:12 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:12 --> URI Class Initialized
INFO - 2018-03-21 22:13:12 --> Router Class Initialized
INFO - 2018-03-21 22:13:12 --> Output Class Initialized
INFO - 2018-03-21 22:13:12 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:12 --> CSRF cookie sent
INFO - 2018-03-21 22:13:12 --> Input Class Initialized
INFO - 2018-03-21 22:13:12 --> Language Class Initialized
INFO - 2018-03-21 22:13:12 --> Loader Class Initialized
INFO - 2018-03-21 22:13:12 --> Helper loaded: url_helper
INFO - 2018-03-21 22:13:12 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:13:12 --> User Agent Class Initialized
INFO - 2018-03-21 22:13:12 --> Controller Class Initialized
INFO - 2018-03-21 22:13:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:13:12 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-21 22:13:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:13:12 --> Final output sent to browser
DEBUG - 2018-03-21 22:13:12 --> Total execution time: 0.2043
INFO - 2018-03-21 22:13:13 --> Config Class Initialized
INFO - 2018-03-21 22:13:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:13 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:13 --> URI Class Initialized
INFO - 2018-03-21 22:13:13 --> Router Class Initialized
INFO - 2018-03-21 22:13:13 --> Output Class Initialized
INFO - 2018-03-21 22:13:13 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:13 --> CSRF cookie sent
INFO - 2018-03-21 22:13:13 --> Input Class Initialized
INFO - 2018-03-21 22:13:13 --> Language Class Initialized
ERROR - 2018-03-21 22:13:13 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:13:17 --> Config Class Initialized
INFO - 2018-03-21 22:13:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:17 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:17 --> URI Class Initialized
INFO - 2018-03-21 22:13:17 --> Router Class Initialized
INFO - 2018-03-21 22:13:17 --> Output Class Initialized
INFO - 2018-03-21 22:13:17 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:17 --> CSRF cookie sent
INFO - 2018-03-21 22:13:17 --> Input Class Initialized
INFO - 2018-03-21 22:13:17 --> Language Class Initialized
ERROR - 2018-03-21 22:13:17 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:13:24 --> Config Class Initialized
INFO - 2018-03-21 22:13:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:24 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:24 --> URI Class Initialized
INFO - 2018-03-21 22:13:24 --> Router Class Initialized
INFO - 2018-03-21 22:13:24 --> Output Class Initialized
INFO - 2018-03-21 22:13:24 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:25 --> CSRF cookie sent
INFO - 2018-03-21 22:13:25 --> Input Class Initialized
INFO - 2018-03-21 22:13:25 --> Language Class Initialized
INFO - 2018-03-21 22:13:25 --> Loader Class Initialized
INFO - 2018-03-21 22:13:25 --> Helper loaded: url_helper
INFO - 2018-03-21 22:13:25 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:13:25 --> User Agent Class Initialized
INFO - 2018-03-21 22:13:25 --> Controller Class Initialized
INFO - 2018-03-21 22:13:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:13:25 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:13:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:13:25 --> Final output sent to browser
DEBUG - 2018-03-21 22:13:25 --> Total execution time: 0.1970
INFO - 2018-03-21 22:13:25 --> Config Class Initialized
INFO - 2018-03-21 22:13:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:25 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:25 --> URI Class Initialized
INFO - 2018-03-21 22:13:25 --> Router Class Initialized
INFO - 2018-03-21 22:13:25 --> Output Class Initialized
INFO - 2018-03-21 22:13:25 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:25 --> CSRF cookie sent
INFO - 2018-03-21 22:13:25 --> Input Class Initialized
INFO - 2018-03-21 22:13:25 --> Language Class Initialized
ERROR - 2018-03-21 22:13:25 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:13:25 --> Config Class Initialized
INFO - 2018-03-21 22:13:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:25 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:25 --> URI Class Initialized
INFO - 2018-03-21 22:13:25 --> Router Class Initialized
INFO - 2018-03-21 22:13:25 --> Output Class Initialized
INFO - 2018-03-21 22:13:25 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:25 --> CSRF cookie sent
INFO - 2018-03-21 22:13:25 --> Input Class Initialized
INFO - 2018-03-21 22:13:25 --> Language Class Initialized
ERROR - 2018-03-21 22:13:25 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:14:38 --> Config Class Initialized
INFO - 2018-03-21 22:14:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:14:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:14:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:14:38 --> URI Class Initialized
INFO - 2018-03-21 22:14:38 --> Router Class Initialized
INFO - 2018-03-21 22:14:38 --> Output Class Initialized
INFO - 2018-03-21 22:14:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:14:38 --> CSRF cookie sent
INFO - 2018-03-21 22:14:38 --> Input Class Initialized
INFO - 2018-03-21 22:14:38 --> Language Class Initialized
INFO - 2018-03-21 22:14:38 --> Loader Class Initialized
INFO - 2018-03-21 22:14:38 --> Helper loaded: url_helper
INFO - 2018-03-21 22:14:38 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:14:38 --> User Agent Class Initialized
INFO - 2018-03-21 22:14:38 --> Controller Class Initialized
INFO - 2018-03-21 22:14:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:14:38 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:14:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:14:38 --> Final output sent to browser
DEBUG - 2018-03-21 22:14:38 --> Total execution time: 0.1909
INFO - 2018-03-21 22:14:38 --> Config Class Initialized
INFO - 2018-03-21 22:14:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:14:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:14:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:14:38 --> URI Class Initialized
INFO - 2018-03-21 22:14:38 --> Router Class Initialized
INFO - 2018-03-21 22:14:38 --> Output Class Initialized
INFO - 2018-03-21 22:14:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:14:38 --> CSRF cookie sent
INFO - 2018-03-21 22:14:38 --> Input Class Initialized
INFO - 2018-03-21 22:14:38 --> Language Class Initialized
ERROR - 2018-03-21 22:14:38 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:14:38 --> Config Class Initialized
INFO - 2018-03-21 22:14:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:14:39 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:14:39 --> Utf8 Class Initialized
INFO - 2018-03-21 22:14:39 --> URI Class Initialized
INFO - 2018-03-21 22:14:39 --> Router Class Initialized
INFO - 2018-03-21 22:14:39 --> Output Class Initialized
INFO - 2018-03-21 22:14:39 --> Security Class Initialized
DEBUG - 2018-03-21 22:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:14:39 --> CSRF cookie sent
INFO - 2018-03-21 22:14:39 --> Input Class Initialized
INFO - 2018-03-21 22:14:39 --> Language Class Initialized
ERROR - 2018-03-21 22:14:39 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:15:05 --> Config Class Initialized
INFO - 2018-03-21 22:15:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:05 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:05 --> URI Class Initialized
INFO - 2018-03-21 22:15:05 --> Router Class Initialized
INFO - 2018-03-21 22:15:05 --> Output Class Initialized
INFO - 2018-03-21 22:15:05 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:05 --> CSRF cookie sent
INFO - 2018-03-21 22:15:05 --> Input Class Initialized
INFO - 2018-03-21 22:15:05 --> Language Class Initialized
INFO - 2018-03-21 22:15:05 --> Loader Class Initialized
INFO - 2018-03-21 22:15:05 --> Helper loaded: url_helper
INFO - 2018-03-21 22:15:05 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:15:05 --> User Agent Class Initialized
INFO - 2018-03-21 22:15:05 --> Controller Class Initialized
INFO - 2018-03-21 22:15:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:15:05 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:15:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:15:05 --> Final output sent to browser
DEBUG - 2018-03-21 22:15:05 --> Total execution time: 0.2060
INFO - 2018-03-21 22:15:05 --> Config Class Initialized
INFO - 2018-03-21 22:15:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:05 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:05 --> URI Class Initialized
INFO - 2018-03-21 22:15:05 --> Router Class Initialized
INFO - 2018-03-21 22:15:05 --> Output Class Initialized
INFO - 2018-03-21 22:15:05 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:06 --> CSRF cookie sent
INFO - 2018-03-21 22:15:06 --> Input Class Initialized
INFO - 2018-03-21 22:15:06 --> Language Class Initialized
ERROR - 2018-03-21 22:15:06 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:15:06 --> Config Class Initialized
INFO - 2018-03-21 22:15:06 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:06 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:06 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:06 --> URI Class Initialized
INFO - 2018-03-21 22:15:06 --> Router Class Initialized
INFO - 2018-03-21 22:15:06 --> Output Class Initialized
INFO - 2018-03-21 22:15:06 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:06 --> CSRF cookie sent
INFO - 2018-03-21 22:15:06 --> Input Class Initialized
INFO - 2018-03-21 22:15:06 --> Language Class Initialized
ERROR - 2018-03-21 22:15:06 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:15:30 --> Config Class Initialized
INFO - 2018-03-21 22:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:30 --> URI Class Initialized
INFO - 2018-03-21 22:15:30 --> Router Class Initialized
INFO - 2018-03-21 22:15:30 --> Output Class Initialized
INFO - 2018-03-21 22:15:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:30 --> CSRF cookie sent
INFO - 2018-03-21 22:15:30 --> Input Class Initialized
INFO - 2018-03-21 22:15:30 --> Language Class Initialized
INFO - 2018-03-21 22:15:30 --> Loader Class Initialized
INFO - 2018-03-21 22:15:30 --> Helper loaded: url_helper
INFO - 2018-03-21 22:15:30 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:15:30 --> User Agent Class Initialized
INFO - 2018-03-21 22:15:30 --> Controller Class Initialized
INFO - 2018-03-21 22:15:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:15:30 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:15:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:15:30 --> Final output sent to browser
DEBUG - 2018-03-21 22:15:30 --> Total execution time: 0.2442
INFO - 2018-03-21 22:15:30 --> Config Class Initialized
INFO - 2018-03-21 22:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:30 --> URI Class Initialized
INFO - 2018-03-21 22:15:30 --> Router Class Initialized
INFO - 2018-03-21 22:15:30 --> Output Class Initialized
INFO - 2018-03-21 22:15:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:30 --> CSRF cookie sent
INFO - 2018-03-21 22:15:30 --> Input Class Initialized
INFO - 2018-03-21 22:15:30 --> Language Class Initialized
ERROR - 2018-03-21 22:15:30 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:15:30 --> Config Class Initialized
INFO - 2018-03-21 22:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:15:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:15:30 --> URI Class Initialized
INFO - 2018-03-21 22:15:30 --> Router Class Initialized
INFO - 2018-03-21 22:15:30 --> Output Class Initialized
INFO - 2018-03-21 22:15:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:15:30 --> CSRF cookie sent
INFO - 2018-03-21 22:15:30 --> Input Class Initialized
INFO - 2018-03-21 22:15:30 --> Language Class Initialized
ERROR - 2018-03-21 22:15:30 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:16:26 --> Config Class Initialized
INFO - 2018-03-21 22:16:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:16:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:16:26 --> Utf8 Class Initialized
INFO - 2018-03-21 22:16:26 --> URI Class Initialized
INFO - 2018-03-21 22:16:26 --> Router Class Initialized
INFO - 2018-03-21 22:16:26 --> Output Class Initialized
INFO - 2018-03-21 22:16:26 --> Security Class Initialized
DEBUG - 2018-03-21 22:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:16:26 --> CSRF cookie sent
INFO - 2018-03-21 22:16:26 --> Input Class Initialized
INFO - 2018-03-21 22:16:26 --> Language Class Initialized
INFO - 2018-03-21 22:16:26 --> Loader Class Initialized
INFO - 2018-03-21 22:16:26 --> Helper loaded: url_helper
INFO - 2018-03-21 22:16:26 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:16:26 --> User Agent Class Initialized
INFO - 2018-03-21 22:16:26 --> Controller Class Initialized
INFO - 2018-03-21 22:16:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:16:26 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:16:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:16:26 --> Final output sent to browser
DEBUG - 2018-03-21 22:16:26 --> Total execution time: 0.2008
INFO - 2018-03-21 22:16:27 --> Config Class Initialized
INFO - 2018-03-21 22:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:16:27 --> Utf8 Class Initialized
INFO - 2018-03-21 22:16:27 --> URI Class Initialized
INFO - 2018-03-21 22:16:27 --> Router Class Initialized
INFO - 2018-03-21 22:16:27 --> Output Class Initialized
INFO - 2018-03-21 22:16:27 --> Security Class Initialized
DEBUG - 2018-03-21 22:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:16:27 --> CSRF cookie sent
INFO - 2018-03-21 22:16:27 --> Input Class Initialized
INFO - 2018-03-21 22:16:27 --> Language Class Initialized
ERROR - 2018-03-21 22:16:27 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:16:27 --> Config Class Initialized
INFO - 2018-03-21 22:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:16:27 --> Utf8 Class Initialized
INFO - 2018-03-21 22:16:27 --> URI Class Initialized
INFO - 2018-03-21 22:16:27 --> Router Class Initialized
INFO - 2018-03-21 22:16:27 --> Output Class Initialized
INFO - 2018-03-21 22:16:27 --> Security Class Initialized
DEBUG - 2018-03-21 22:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:16:27 --> CSRF cookie sent
INFO - 2018-03-21 22:16:27 --> Input Class Initialized
INFO - 2018-03-21 22:16:27 --> Language Class Initialized
ERROR - 2018-03-21 22:16:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:18:09 --> Config Class Initialized
INFO - 2018-03-21 22:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:09 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:09 --> URI Class Initialized
INFO - 2018-03-21 22:18:09 --> Router Class Initialized
INFO - 2018-03-21 22:18:09 --> Output Class Initialized
INFO - 2018-03-21 22:18:09 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:09 --> CSRF cookie sent
INFO - 2018-03-21 22:18:09 --> Input Class Initialized
INFO - 2018-03-21 22:18:09 --> Language Class Initialized
INFO - 2018-03-21 22:18:09 --> Loader Class Initialized
INFO - 2018-03-21 22:18:09 --> Helper loaded: url_helper
INFO - 2018-03-21 22:18:09 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:18:09 --> User Agent Class Initialized
INFO - 2018-03-21 22:18:09 --> Controller Class Initialized
INFO - 2018-03-21 22:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:18:09 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:18:09 --> Final output sent to browser
DEBUG - 2018-03-21 22:18:09 --> Total execution time: 0.2001
INFO - 2018-03-21 22:18:09 --> Config Class Initialized
INFO - 2018-03-21 22:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:09 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:09 --> URI Class Initialized
INFO - 2018-03-21 22:18:09 --> Router Class Initialized
INFO - 2018-03-21 22:18:09 --> Output Class Initialized
INFO - 2018-03-21 22:18:09 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:09 --> CSRF cookie sent
INFO - 2018-03-21 22:18:09 --> Input Class Initialized
INFO - 2018-03-21 22:18:09 --> Language Class Initialized
ERROR - 2018-03-21 22:18:09 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:18:09 --> Config Class Initialized
INFO - 2018-03-21 22:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:09 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:09 --> URI Class Initialized
INFO - 2018-03-21 22:18:09 --> Router Class Initialized
INFO - 2018-03-21 22:18:09 --> Output Class Initialized
INFO - 2018-03-21 22:18:09 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:09 --> CSRF cookie sent
INFO - 2018-03-21 22:18:09 --> Input Class Initialized
INFO - 2018-03-21 22:18:09 --> Language Class Initialized
ERROR - 2018-03-21 22:18:09 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:18:57 --> Config Class Initialized
INFO - 2018-03-21 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:57 --> URI Class Initialized
INFO - 2018-03-21 22:18:57 --> Router Class Initialized
INFO - 2018-03-21 22:18:57 --> Output Class Initialized
INFO - 2018-03-21 22:18:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:57 --> CSRF cookie sent
INFO - 2018-03-21 22:18:57 --> Input Class Initialized
INFO - 2018-03-21 22:18:57 --> Language Class Initialized
INFO - 2018-03-21 22:18:57 --> Loader Class Initialized
INFO - 2018-03-21 22:18:57 --> Helper loaded: url_helper
INFO - 2018-03-21 22:18:57 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:18:57 --> User Agent Class Initialized
INFO - 2018-03-21 22:18:57 --> Controller Class Initialized
INFO - 2018-03-21 22:18:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:18:57 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:18:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:18:57 --> Final output sent to browser
DEBUG - 2018-03-21 22:18:57 --> Total execution time: 0.2015
INFO - 2018-03-21 22:18:57 --> Config Class Initialized
INFO - 2018-03-21 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:57 --> URI Class Initialized
INFO - 2018-03-21 22:18:57 --> Router Class Initialized
INFO - 2018-03-21 22:18:57 --> Output Class Initialized
INFO - 2018-03-21 22:18:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:57 --> CSRF cookie sent
INFO - 2018-03-21 22:18:57 --> Input Class Initialized
INFO - 2018-03-21 22:18:57 --> Language Class Initialized
ERROR - 2018-03-21 22:18:58 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:18:58 --> Config Class Initialized
INFO - 2018-03-21 22:18:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:58 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:58 --> URI Class Initialized
INFO - 2018-03-21 22:18:58 --> Router Class Initialized
INFO - 2018-03-21 22:18:58 --> Output Class Initialized
INFO - 2018-03-21 22:18:58 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:58 --> CSRF cookie sent
INFO - 2018-03-21 22:18:58 --> Input Class Initialized
INFO - 2018-03-21 22:18:58 --> Language Class Initialized
ERROR - 2018-03-21 22:18:58 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:18:59 --> Config Class Initialized
INFO - 2018-03-21 22:18:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:18:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:18:59 --> Utf8 Class Initialized
INFO - 2018-03-21 22:18:59 --> URI Class Initialized
INFO - 2018-03-21 22:18:59 --> Router Class Initialized
INFO - 2018-03-21 22:18:59 --> Output Class Initialized
INFO - 2018-03-21 22:18:59 --> Security Class Initialized
DEBUG - 2018-03-21 22:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:18:59 --> CSRF cookie sent
INFO - 2018-03-21 22:18:59 --> Input Class Initialized
INFO - 2018-03-21 22:18:59 --> Language Class Initialized
INFO - 2018-03-21 22:18:59 --> Loader Class Initialized
INFO - 2018-03-21 22:18:59 --> Helper loaded: url_helper
INFO - 2018-03-21 22:19:00 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:19:00 --> User Agent Class Initialized
INFO - 2018-03-21 22:19:00 --> Controller Class Initialized
INFO - 2018-03-21 22:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:19:00 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:19:00 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:00 --> Total execution time: 0.2253
INFO - 2018-03-21 22:19:00 --> Config Class Initialized
INFO - 2018-03-21 22:19:00 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:00 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:00 --> URI Class Initialized
INFO - 2018-03-21 22:19:00 --> Router Class Initialized
INFO - 2018-03-21 22:19:00 --> Output Class Initialized
INFO - 2018-03-21 22:19:00 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:00 --> CSRF cookie sent
INFO - 2018-03-21 22:19:00 --> Input Class Initialized
INFO - 2018-03-21 22:19:00 --> Language Class Initialized
INFO - 2018-03-21 22:19:00 --> Config Class Initialized
INFO - 2018-03-21 22:19:00 --> Hooks Class Initialized
ERROR - 2018-03-21 22:19:00 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 22:19:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:00 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:00 --> URI Class Initialized
INFO - 2018-03-21 22:19:00 --> Router Class Initialized
INFO - 2018-03-21 22:19:00 --> Output Class Initialized
INFO - 2018-03-21 22:19:00 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:00 --> CSRF cookie sent
INFO - 2018-03-21 22:19:00 --> Input Class Initialized
INFO - 2018-03-21 22:19:00 --> Language Class Initialized
ERROR - 2018-03-21 22:19:00 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:19:10 --> Config Class Initialized
INFO - 2018-03-21 22:19:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:10 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:10 --> URI Class Initialized
INFO - 2018-03-21 22:19:10 --> Router Class Initialized
INFO - 2018-03-21 22:19:10 --> Output Class Initialized
INFO - 2018-03-21 22:19:10 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:10 --> CSRF cookie sent
INFO - 2018-03-21 22:19:10 --> Input Class Initialized
INFO - 2018-03-21 22:19:10 --> Language Class Initialized
INFO - 2018-03-21 22:19:10 --> Loader Class Initialized
INFO - 2018-03-21 22:19:10 --> Helper loaded: url_helper
INFO - 2018-03-21 22:19:10 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:19:10 --> User Agent Class Initialized
INFO - 2018-03-21 22:19:10 --> Controller Class Initialized
INFO - 2018-03-21 22:19:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:19:10 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:19:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:19:10 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:10 --> Total execution time: 0.2206
INFO - 2018-03-21 22:19:10 --> Config Class Initialized
INFO - 2018-03-21 22:19:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:10 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:10 --> URI Class Initialized
INFO - 2018-03-21 22:19:10 --> Router Class Initialized
INFO - 2018-03-21 22:19:10 --> Output Class Initialized
INFO - 2018-03-21 22:19:10 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:10 --> CSRF cookie sent
INFO - 2018-03-21 22:19:10 --> Input Class Initialized
INFO - 2018-03-21 22:19:10 --> Language Class Initialized
ERROR - 2018-03-21 22:19:10 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:19:11 --> Config Class Initialized
INFO - 2018-03-21 22:19:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:11 --> URI Class Initialized
INFO - 2018-03-21 22:19:11 --> Router Class Initialized
INFO - 2018-03-21 22:19:11 --> Output Class Initialized
INFO - 2018-03-21 22:19:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:11 --> CSRF cookie sent
INFO - 2018-03-21 22:19:11 --> Input Class Initialized
INFO - 2018-03-21 22:19:11 --> Language Class Initialized
ERROR - 2018-03-21 22:19:11 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:19:56 --> Config Class Initialized
INFO - 2018-03-21 22:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:56 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:56 --> URI Class Initialized
INFO - 2018-03-21 22:19:56 --> Router Class Initialized
INFO - 2018-03-21 22:19:56 --> Output Class Initialized
INFO - 2018-03-21 22:19:56 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:56 --> CSRF cookie sent
INFO - 2018-03-21 22:19:56 --> Input Class Initialized
INFO - 2018-03-21 22:19:56 --> Language Class Initialized
INFO - 2018-03-21 22:19:56 --> Loader Class Initialized
INFO - 2018-03-21 22:19:56 --> Helper loaded: url_helper
INFO - 2018-03-21 22:19:56 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:19:56 --> User Agent Class Initialized
INFO - 2018-03-21 22:19:56 --> Controller Class Initialized
INFO - 2018-03-21 22:19:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:19:56 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:19:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:19:56 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:56 --> Total execution time: 0.2109
INFO - 2018-03-21 22:19:56 --> Config Class Initialized
INFO - 2018-03-21 22:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:56 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:56 --> URI Class Initialized
INFO - 2018-03-21 22:19:56 --> Router Class Initialized
INFO - 2018-03-21 22:19:56 --> Output Class Initialized
INFO - 2018-03-21 22:19:56 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:56 --> CSRF cookie sent
INFO - 2018-03-21 22:19:56 --> Input Class Initialized
INFO - 2018-03-21 22:19:56 --> Language Class Initialized
ERROR - 2018-03-21 22:19:56 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:19:56 --> Config Class Initialized
INFO - 2018-03-21 22:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:56 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:56 --> URI Class Initialized
INFO - 2018-03-21 22:19:56 --> Router Class Initialized
INFO - 2018-03-21 22:19:56 --> Output Class Initialized
INFO - 2018-03-21 22:19:56 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:56 --> CSRF cookie sent
INFO - 2018-03-21 22:19:56 --> Input Class Initialized
INFO - 2018-03-21 22:19:56 --> Language Class Initialized
ERROR - 2018-03-21 22:19:56 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:21:58 --> Config Class Initialized
INFO - 2018-03-21 22:21:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:21:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:21:58 --> Utf8 Class Initialized
INFO - 2018-03-21 22:21:58 --> URI Class Initialized
INFO - 2018-03-21 22:21:58 --> Router Class Initialized
INFO - 2018-03-21 22:21:58 --> Output Class Initialized
INFO - 2018-03-21 22:21:58 --> Security Class Initialized
DEBUG - 2018-03-21 22:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:21:58 --> CSRF cookie sent
INFO - 2018-03-21 22:21:58 --> Input Class Initialized
INFO - 2018-03-21 22:21:58 --> Language Class Initialized
INFO - 2018-03-21 22:21:58 --> Loader Class Initialized
INFO - 2018-03-21 22:21:58 --> Helper loaded: url_helper
INFO - 2018-03-21 22:21:58 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:21:58 --> User Agent Class Initialized
INFO - 2018-03-21 22:21:58 --> Controller Class Initialized
INFO - 2018-03-21 22:21:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:21:58 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:21:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:21:58 --> Final output sent to browser
DEBUG - 2018-03-21 22:21:58 --> Total execution time: 0.2143
INFO - 2018-03-21 22:21:58 --> Config Class Initialized
INFO - 2018-03-21 22:21:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:21:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:21:59 --> Utf8 Class Initialized
INFO - 2018-03-21 22:21:59 --> URI Class Initialized
INFO - 2018-03-21 22:21:59 --> Router Class Initialized
INFO - 2018-03-21 22:21:59 --> Output Class Initialized
INFO - 2018-03-21 22:21:59 --> Security Class Initialized
DEBUG - 2018-03-21 22:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:21:59 --> CSRF cookie sent
INFO - 2018-03-21 22:21:59 --> Input Class Initialized
INFO - 2018-03-21 22:21:59 --> Language Class Initialized
ERROR - 2018-03-21 22:21:59 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:21:59 --> Config Class Initialized
INFO - 2018-03-21 22:21:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:21:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:21:59 --> Utf8 Class Initialized
INFO - 2018-03-21 22:21:59 --> URI Class Initialized
INFO - 2018-03-21 22:21:59 --> Router Class Initialized
INFO - 2018-03-21 22:21:59 --> Output Class Initialized
INFO - 2018-03-21 22:21:59 --> Security Class Initialized
DEBUG - 2018-03-21 22:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:21:59 --> CSRF cookie sent
INFO - 2018-03-21 22:21:59 --> Input Class Initialized
INFO - 2018-03-21 22:21:59 --> Language Class Initialized
ERROR - 2018-03-21 22:21:59 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:23:41 --> Config Class Initialized
INFO - 2018-03-21 22:23:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:23:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:23:41 --> Utf8 Class Initialized
INFO - 2018-03-21 22:23:41 --> URI Class Initialized
INFO - 2018-03-21 22:23:41 --> Router Class Initialized
INFO - 2018-03-21 22:23:41 --> Output Class Initialized
INFO - 2018-03-21 22:23:41 --> Security Class Initialized
DEBUG - 2018-03-21 22:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:23:41 --> CSRF cookie sent
INFO - 2018-03-21 22:23:41 --> Input Class Initialized
INFO - 2018-03-21 22:23:41 --> Language Class Initialized
INFO - 2018-03-21 22:23:41 --> Loader Class Initialized
INFO - 2018-03-21 22:23:41 --> Helper loaded: url_helper
INFO - 2018-03-21 22:23:41 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:23:41 --> User Agent Class Initialized
INFO - 2018-03-21 22:23:41 --> Controller Class Initialized
INFO - 2018-03-21 22:23:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:23:41 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:23:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:23:41 --> Final output sent to browser
DEBUG - 2018-03-21 22:23:41 --> Total execution time: 0.2216
INFO - 2018-03-21 22:23:42 --> Config Class Initialized
INFO - 2018-03-21 22:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:23:42 --> Utf8 Class Initialized
INFO - 2018-03-21 22:23:42 --> URI Class Initialized
INFO - 2018-03-21 22:23:42 --> Router Class Initialized
INFO - 2018-03-21 22:23:42 --> Output Class Initialized
INFO - 2018-03-21 22:23:42 --> Security Class Initialized
DEBUG - 2018-03-21 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:23:42 --> CSRF cookie sent
INFO - 2018-03-21 22:23:42 --> Input Class Initialized
INFO - 2018-03-21 22:23:42 --> Language Class Initialized
ERROR - 2018-03-21 22:23:42 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:23:42 --> Config Class Initialized
INFO - 2018-03-21 22:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:23:42 --> Utf8 Class Initialized
INFO - 2018-03-21 22:23:42 --> URI Class Initialized
INFO - 2018-03-21 22:23:42 --> Router Class Initialized
INFO - 2018-03-21 22:23:42 --> Output Class Initialized
INFO - 2018-03-21 22:23:42 --> Security Class Initialized
DEBUG - 2018-03-21 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:23:42 --> CSRF cookie sent
INFO - 2018-03-21 22:23:42 --> Input Class Initialized
INFO - 2018-03-21 22:23:42 --> Language Class Initialized
ERROR - 2018-03-21 22:23:42 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:26:13 --> Config Class Initialized
INFO - 2018-03-21 22:26:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:13 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:13 --> URI Class Initialized
INFO - 2018-03-21 22:26:13 --> Router Class Initialized
INFO - 2018-03-21 22:26:13 --> Output Class Initialized
INFO - 2018-03-21 22:26:13 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:13 --> CSRF cookie sent
INFO - 2018-03-21 22:26:13 --> Input Class Initialized
INFO - 2018-03-21 22:26:13 --> Language Class Initialized
INFO - 2018-03-21 22:26:13 --> Loader Class Initialized
INFO - 2018-03-21 22:26:13 --> Helper loaded: url_helper
INFO - 2018-03-21 22:26:13 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:26:13 --> User Agent Class Initialized
INFO - 2018-03-21 22:26:13 --> Controller Class Initialized
INFO - 2018-03-21 22:26:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:26:13 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:26:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:26:13 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:13 --> Total execution time: 0.2061
INFO - 2018-03-21 22:26:13 --> Config Class Initialized
INFO - 2018-03-21 22:26:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:13 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:13 --> URI Class Initialized
INFO - 2018-03-21 22:26:13 --> Router Class Initialized
INFO - 2018-03-21 22:26:13 --> Output Class Initialized
INFO - 2018-03-21 22:26:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:14 --> CSRF cookie sent
INFO - 2018-03-21 22:26:14 --> Input Class Initialized
INFO - 2018-03-21 22:26:14 --> Language Class Initialized
ERROR - 2018-03-21 22:26:14 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:26:14 --> Config Class Initialized
INFO - 2018-03-21 22:26:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:14 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:14 --> URI Class Initialized
INFO - 2018-03-21 22:26:14 --> Router Class Initialized
INFO - 2018-03-21 22:26:14 --> Output Class Initialized
INFO - 2018-03-21 22:26:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:14 --> CSRF cookie sent
INFO - 2018-03-21 22:26:14 --> Input Class Initialized
INFO - 2018-03-21 22:26:14 --> Language Class Initialized
ERROR - 2018-03-21 22:26:14 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:26:51 --> Config Class Initialized
INFO - 2018-03-21 22:26:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:51 --> URI Class Initialized
INFO - 2018-03-21 22:26:51 --> Router Class Initialized
INFO - 2018-03-21 22:26:51 --> Output Class Initialized
INFO - 2018-03-21 22:26:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:51 --> CSRF cookie sent
INFO - 2018-03-21 22:26:51 --> Input Class Initialized
INFO - 2018-03-21 22:26:51 --> Language Class Initialized
INFO - 2018-03-21 22:26:51 --> Loader Class Initialized
INFO - 2018-03-21 22:26:51 --> Helper loaded: url_helper
INFO - 2018-03-21 22:26:51 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:26:51 --> User Agent Class Initialized
INFO - 2018-03-21 22:26:51 --> Controller Class Initialized
INFO - 2018-03-21 22:26:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:26:51 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:26:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:26:51 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:51 --> Total execution time: 0.2066
INFO - 2018-03-21 22:26:51 --> Config Class Initialized
INFO - 2018-03-21 22:26:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:51 --> URI Class Initialized
INFO - 2018-03-21 22:26:51 --> Router Class Initialized
INFO - 2018-03-21 22:26:51 --> Output Class Initialized
INFO - 2018-03-21 22:26:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:51 --> CSRF cookie sent
INFO - 2018-03-21 22:26:51 --> Input Class Initialized
INFO - 2018-03-21 22:26:51 --> Language Class Initialized
ERROR - 2018-03-21 22:26:51 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:26:51 --> Config Class Initialized
INFO - 2018-03-21 22:26:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:26:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:26:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:26:51 --> URI Class Initialized
INFO - 2018-03-21 22:26:51 --> Router Class Initialized
INFO - 2018-03-21 22:26:51 --> Output Class Initialized
INFO - 2018-03-21 22:26:52 --> Security Class Initialized
DEBUG - 2018-03-21 22:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:26:52 --> CSRF cookie sent
INFO - 2018-03-21 22:26:52 --> Input Class Initialized
INFO - 2018-03-21 22:26:52 --> Language Class Initialized
ERROR - 2018-03-21 22:26:52 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:29:11 --> Config Class Initialized
INFO - 2018-03-21 22:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:29:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:29:11 --> URI Class Initialized
INFO - 2018-03-21 22:29:11 --> Router Class Initialized
INFO - 2018-03-21 22:29:11 --> Output Class Initialized
INFO - 2018-03-21 22:29:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:29:11 --> CSRF cookie sent
INFO - 2018-03-21 22:29:11 --> Input Class Initialized
INFO - 2018-03-21 22:29:11 --> Language Class Initialized
INFO - 2018-03-21 22:29:11 --> Loader Class Initialized
INFO - 2018-03-21 22:29:11 --> Helper loaded: url_helper
INFO - 2018-03-21 22:29:11 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:29:11 --> User Agent Class Initialized
INFO - 2018-03-21 22:29:11 --> Controller Class Initialized
INFO - 2018-03-21 22:29:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:29:11 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:29:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:29:11 --> Final output sent to browser
DEBUG - 2018-03-21 22:29:11 --> Total execution time: 0.2111
INFO - 2018-03-21 22:29:11 --> Config Class Initialized
INFO - 2018-03-21 22:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:29:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:29:11 --> URI Class Initialized
INFO - 2018-03-21 22:29:11 --> Router Class Initialized
INFO - 2018-03-21 22:29:11 --> Output Class Initialized
INFO - 2018-03-21 22:29:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:29:11 --> CSRF cookie sent
INFO - 2018-03-21 22:29:11 --> Input Class Initialized
INFO - 2018-03-21 22:29:11 --> Language Class Initialized
ERROR - 2018-03-21 22:29:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:29:11 --> Config Class Initialized
INFO - 2018-03-21 22:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:29:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:29:11 --> URI Class Initialized
INFO - 2018-03-21 22:29:11 --> Router Class Initialized
INFO - 2018-03-21 22:29:11 --> Output Class Initialized
INFO - 2018-03-21 22:29:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:29:12 --> CSRF cookie sent
INFO - 2018-03-21 22:29:12 --> Input Class Initialized
INFO - 2018-03-21 22:29:12 --> Language Class Initialized
ERROR - 2018-03-21 22:29:12 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:31:56 --> Config Class Initialized
INFO - 2018-03-21 22:31:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:31:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:31:56 --> Utf8 Class Initialized
INFO - 2018-03-21 22:31:57 --> URI Class Initialized
INFO - 2018-03-21 22:31:57 --> Router Class Initialized
INFO - 2018-03-21 22:31:57 --> Output Class Initialized
INFO - 2018-03-21 22:31:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:31:57 --> CSRF cookie sent
INFO - 2018-03-21 22:31:57 --> Input Class Initialized
INFO - 2018-03-21 22:31:57 --> Language Class Initialized
INFO - 2018-03-21 22:31:57 --> Loader Class Initialized
INFO - 2018-03-21 22:31:57 --> Helper loaded: url_helper
INFO - 2018-03-21 22:31:57 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:31:57 --> User Agent Class Initialized
INFO - 2018-03-21 22:31:57 --> Controller Class Initialized
INFO - 2018-03-21 22:31:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:31:57 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:31:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:31:57 --> Final output sent to browser
DEBUG - 2018-03-21 22:31:57 --> Total execution time: 0.2155
INFO - 2018-03-21 22:31:57 --> Config Class Initialized
INFO - 2018-03-21 22:31:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:31:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:31:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:31:57 --> URI Class Initialized
INFO - 2018-03-21 22:31:57 --> Router Class Initialized
INFO - 2018-03-21 22:31:57 --> Output Class Initialized
INFO - 2018-03-21 22:31:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:31:57 --> CSRF cookie sent
INFO - 2018-03-21 22:31:57 --> Input Class Initialized
INFO - 2018-03-21 22:31:57 --> Language Class Initialized
ERROR - 2018-03-21 22:31:57 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:31:57 --> Config Class Initialized
INFO - 2018-03-21 22:31:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:31:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:31:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:31:57 --> URI Class Initialized
INFO - 2018-03-21 22:31:57 --> Router Class Initialized
INFO - 2018-03-21 22:31:57 --> Output Class Initialized
INFO - 2018-03-21 22:31:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:31:57 --> CSRF cookie sent
INFO - 2018-03-21 22:31:57 --> Input Class Initialized
INFO - 2018-03-21 22:31:57 --> Language Class Initialized
ERROR - 2018-03-21 22:31:57 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:32:19 --> Config Class Initialized
INFO - 2018-03-21 22:32:19 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:32:19 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:32:19 --> Utf8 Class Initialized
INFO - 2018-03-21 22:32:19 --> URI Class Initialized
INFO - 2018-03-21 22:32:19 --> Router Class Initialized
INFO - 2018-03-21 22:32:19 --> Output Class Initialized
INFO - 2018-03-21 22:32:19 --> Security Class Initialized
DEBUG - 2018-03-21 22:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:32:19 --> CSRF cookie sent
INFO - 2018-03-21 22:32:19 --> Input Class Initialized
INFO - 2018-03-21 22:32:19 --> Language Class Initialized
INFO - 2018-03-21 22:32:19 --> Loader Class Initialized
INFO - 2018-03-21 22:32:19 --> Helper loaded: url_helper
INFO - 2018-03-21 22:32:19 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:32:19 --> User Agent Class Initialized
INFO - 2018-03-21 22:32:19 --> Controller Class Initialized
INFO - 2018-03-21 22:32:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:32:19 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:32:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:32:19 --> Final output sent to browser
DEBUG - 2018-03-21 22:32:19 --> Total execution time: 0.2132
INFO - 2018-03-21 22:32:20 --> Config Class Initialized
INFO - 2018-03-21 22:32:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:32:20 --> Utf8 Class Initialized
INFO - 2018-03-21 22:32:20 --> URI Class Initialized
INFO - 2018-03-21 22:32:20 --> Router Class Initialized
INFO - 2018-03-21 22:32:20 --> Output Class Initialized
INFO - 2018-03-21 22:32:20 --> Security Class Initialized
DEBUG - 2018-03-21 22:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:32:20 --> CSRF cookie sent
INFO - 2018-03-21 22:32:20 --> Input Class Initialized
INFO - 2018-03-21 22:32:20 --> Language Class Initialized
ERROR - 2018-03-21 22:32:20 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:32:20 --> Config Class Initialized
INFO - 2018-03-21 22:32:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:32:20 --> Utf8 Class Initialized
INFO - 2018-03-21 22:32:20 --> URI Class Initialized
INFO - 2018-03-21 22:32:20 --> Router Class Initialized
INFO - 2018-03-21 22:32:20 --> Output Class Initialized
INFO - 2018-03-21 22:32:20 --> Security Class Initialized
DEBUG - 2018-03-21 22:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:32:20 --> CSRF cookie sent
INFO - 2018-03-21 22:32:20 --> Input Class Initialized
INFO - 2018-03-21 22:32:20 --> Language Class Initialized
ERROR - 2018-03-21 22:32:20 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:35:50 --> Config Class Initialized
INFO - 2018-03-21 22:35:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:35:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:35:50 --> Utf8 Class Initialized
INFO - 2018-03-21 22:35:50 --> URI Class Initialized
INFO - 2018-03-21 22:35:50 --> Router Class Initialized
INFO - 2018-03-21 22:35:50 --> Output Class Initialized
INFO - 2018-03-21 22:35:50 --> Security Class Initialized
DEBUG - 2018-03-21 22:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:35:50 --> CSRF cookie sent
INFO - 2018-03-21 22:35:50 --> Input Class Initialized
INFO - 2018-03-21 22:35:50 --> Language Class Initialized
INFO - 2018-03-21 22:35:50 --> Loader Class Initialized
INFO - 2018-03-21 22:35:50 --> Helper loaded: url_helper
INFO - 2018-03-21 22:35:50 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:35:50 --> User Agent Class Initialized
INFO - 2018-03-21 22:35:50 --> Controller Class Initialized
INFO - 2018-03-21 22:35:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:35:50 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:35:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:35:50 --> Final output sent to browser
DEBUG - 2018-03-21 22:35:50 --> Total execution time: 0.2202
INFO - 2018-03-21 22:35:51 --> Config Class Initialized
INFO - 2018-03-21 22:35:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:35:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:35:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:35:51 --> URI Class Initialized
INFO - 2018-03-21 22:35:51 --> Router Class Initialized
INFO - 2018-03-21 22:35:51 --> Output Class Initialized
INFO - 2018-03-21 22:35:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:35:51 --> CSRF cookie sent
INFO - 2018-03-21 22:35:51 --> Input Class Initialized
INFO - 2018-03-21 22:35:51 --> Language Class Initialized
ERROR - 2018-03-21 22:35:51 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:35:51 --> Config Class Initialized
INFO - 2018-03-21 22:35:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:35:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:35:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:35:51 --> URI Class Initialized
INFO - 2018-03-21 22:35:51 --> Router Class Initialized
INFO - 2018-03-21 22:35:51 --> Output Class Initialized
INFO - 2018-03-21 22:35:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:35:51 --> CSRF cookie sent
INFO - 2018-03-21 22:35:51 --> Input Class Initialized
INFO - 2018-03-21 22:35:51 --> Language Class Initialized
ERROR - 2018-03-21 22:35:51 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:36:51 --> Config Class Initialized
INFO - 2018-03-21 22:36:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:36:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:36:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:36:51 --> URI Class Initialized
INFO - 2018-03-21 22:36:51 --> Router Class Initialized
INFO - 2018-03-21 22:36:51 --> Output Class Initialized
INFO - 2018-03-21 22:36:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:36:51 --> CSRF cookie sent
INFO - 2018-03-21 22:36:51 --> Input Class Initialized
INFO - 2018-03-21 22:36:51 --> Language Class Initialized
INFO - 2018-03-21 22:36:51 --> Loader Class Initialized
INFO - 2018-03-21 22:36:51 --> Helper loaded: url_helper
INFO - 2018-03-21 22:36:51 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:36:51 --> User Agent Class Initialized
INFO - 2018-03-21 22:36:51 --> Controller Class Initialized
INFO - 2018-03-21 22:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:36:51 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:36:51 --> Final output sent to browser
DEBUG - 2018-03-21 22:36:51 --> Total execution time: 0.2125
INFO - 2018-03-21 22:36:51 --> Config Class Initialized
INFO - 2018-03-21 22:36:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:36:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:36:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:36:51 --> URI Class Initialized
INFO - 2018-03-21 22:36:51 --> Router Class Initialized
INFO - 2018-03-21 22:36:51 --> Output Class Initialized
INFO - 2018-03-21 22:36:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:36:51 --> CSRF cookie sent
INFO - 2018-03-21 22:36:51 --> Input Class Initialized
INFO - 2018-03-21 22:36:51 --> Language Class Initialized
INFO - 2018-03-21 22:36:51 --> Config Class Initialized
INFO - 2018-03-21 22:36:51 --> Hooks Class Initialized
ERROR - 2018-03-21 22:36:51 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 22:36:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:36:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:36:51 --> URI Class Initialized
INFO - 2018-03-21 22:36:51 --> Router Class Initialized
INFO - 2018-03-21 22:36:51 --> Output Class Initialized
INFO - 2018-03-21 22:36:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:36:51 --> CSRF cookie sent
INFO - 2018-03-21 22:36:51 --> Input Class Initialized
INFO - 2018-03-21 22:36:51 --> Language Class Initialized
ERROR - 2018-03-21 22:36:52 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:37:11 --> Config Class Initialized
INFO - 2018-03-21 22:37:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:11 --> URI Class Initialized
INFO - 2018-03-21 22:37:11 --> Router Class Initialized
INFO - 2018-03-21 22:37:11 --> Output Class Initialized
INFO - 2018-03-21 22:37:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:11 --> CSRF cookie sent
INFO - 2018-03-21 22:37:11 --> Input Class Initialized
INFO - 2018-03-21 22:37:11 --> Language Class Initialized
INFO - 2018-03-21 22:37:11 --> Loader Class Initialized
INFO - 2018-03-21 22:37:11 --> Helper loaded: url_helper
INFO - 2018-03-21 22:37:11 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:37:11 --> User Agent Class Initialized
INFO - 2018-03-21 22:37:11 --> Controller Class Initialized
INFO - 2018-03-21 22:37:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:37:11 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:37:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:37:11 --> Final output sent to browser
DEBUG - 2018-03-21 22:37:11 --> Total execution time: 0.2327
INFO - 2018-03-21 22:37:11 --> Config Class Initialized
INFO - 2018-03-21 22:37:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:11 --> URI Class Initialized
INFO - 2018-03-21 22:37:11 --> Router Class Initialized
INFO - 2018-03-21 22:37:11 --> Output Class Initialized
INFO - 2018-03-21 22:37:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:11 --> CSRF cookie sent
INFO - 2018-03-21 22:37:11 --> Input Class Initialized
INFO - 2018-03-21 22:37:11 --> Language Class Initialized
ERROR - 2018-03-21 22:37:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:37:11 --> Config Class Initialized
INFO - 2018-03-21 22:37:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:11 --> URI Class Initialized
INFO - 2018-03-21 22:37:11 --> Router Class Initialized
INFO - 2018-03-21 22:37:11 --> Output Class Initialized
INFO - 2018-03-21 22:37:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:11 --> CSRF cookie sent
INFO - 2018-03-21 22:37:11 --> Input Class Initialized
INFO - 2018-03-21 22:37:11 --> Language Class Initialized
ERROR - 2018-03-21 22:37:11 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:37:22 --> Config Class Initialized
INFO - 2018-03-21 22:37:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:22 --> URI Class Initialized
INFO - 2018-03-21 22:37:22 --> Router Class Initialized
INFO - 2018-03-21 22:37:22 --> Output Class Initialized
INFO - 2018-03-21 22:37:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:22 --> CSRF cookie sent
INFO - 2018-03-21 22:37:22 --> Input Class Initialized
INFO - 2018-03-21 22:37:22 --> Language Class Initialized
INFO - 2018-03-21 22:37:22 --> Loader Class Initialized
INFO - 2018-03-21 22:37:22 --> Helper loaded: url_helper
INFO - 2018-03-21 22:37:22 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:37:22 --> User Agent Class Initialized
INFO - 2018-03-21 22:37:22 --> Controller Class Initialized
INFO - 2018-03-21 22:37:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:37:23 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:37:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:37:23 --> Final output sent to browser
DEBUG - 2018-03-21 22:37:23 --> Total execution time: 0.2368
INFO - 2018-03-21 22:37:23 --> Config Class Initialized
INFO - 2018-03-21 22:37:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:23 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:23 --> URI Class Initialized
INFO - 2018-03-21 22:37:23 --> Router Class Initialized
INFO - 2018-03-21 22:37:23 --> Output Class Initialized
INFO - 2018-03-21 22:37:23 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:23 --> CSRF cookie sent
INFO - 2018-03-21 22:37:23 --> Input Class Initialized
INFO - 2018-03-21 22:37:23 --> Language Class Initialized
ERROR - 2018-03-21 22:37:23 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:37:24 --> Config Class Initialized
INFO - 2018-03-21 22:37:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:37:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:37:24 --> Utf8 Class Initialized
INFO - 2018-03-21 22:37:24 --> URI Class Initialized
INFO - 2018-03-21 22:37:24 --> Router Class Initialized
INFO - 2018-03-21 22:37:24 --> Output Class Initialized
INFO - 2018-03-21 22:37:24 --> Security Class Initialized
DEBUG - 2018-03-21 22:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:37:24 --> CSRF cookie sent
INFO - 2018-03-21 22:37:24 --> Input Class Initialized
INFO - 2018-03-21 22:37:24 --> Language Class Initialized
ERROR - 2018-03-21 22:37:24 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:42:47 --> Config Class Initialized
INFO - 2018-03-21 22:42:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:42:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:42:47 --> Utf8 Class Initialized
INFO - 2018-03-21 22:42:47 --> URI Class Initialized
INFO - 2018-03-21 22:42:47 --> Router Class Initialized
INFO - 2018-03-21 22:42:47 --> Output Class Initialized
INFO - 2018-03-21 22:42:47 --> Security Class Initialized
DEBUG - 2018-03-21 22:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:42:47 --> CSRF cookie sent
INFO - 2018-03-21 22:42:47 --> Input Class Initialized
INFO - 2018-03-21 22:42:47 --> Language Class Initialized
INFO - 2018-03-21 22:42:47 --> Loader Class Initialized
INFO - 2018-03-21 22:42:47 --> Helper loaded: url_helper
INFO - 2018-03-21 22:42:47 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:42:47 --> User Agent Class Initialized
INFO - 2018-03-21 22:42:47 --> Controller Class Initialized
INFO - 2018-03-21 22:42:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:42:47 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:42:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:42:47 --> Final output sent to browser
DEBUG - 2018-03-21 22:42:47 --> Total execution time: 0.2170
INFO - 2018-03-21 22:42:47 --> Config Class Initialized
INFO - 2018-03-21 22:42:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:42:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:42:47 --> Utf8 Class Initialized
INFO - 2018-03-21 22:42:47 --> URI Class Initialized
INFO - 2018-03-21 22:42:47 --> Router Class Initialized
INFO - 2018-03-21 22:42:47 --> Output Class Initialized
INFO - 2018-03-21 22:42:47 --> Security Class Initialized
DEBUG - 2018-03-21 22:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:42:47 --> Config Class Initialized
INFO - 2018-03-21 22:42:47 --> Hooks Class Initialized
INFO - 2018-03-21 22:42:47 --> CSRF cookie sent
INFO - 2018-03-21 22:42:47 --> Input Class Initialized
DEBUG - 2018-03-21 22:42:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:42:47 --> Utf8 Class Initialized
INFO - 2018-03-21 22:42:47 --> Language Class Initialized
INFO - 2018-03-21 22:42:47 --> URI Class Initialized
ERROR - 2018-03-21 22:42:47 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:42:47 --> Router Class Initialized
INFO - 2018-03-21 22:42:47 --> Output Class Initialized
INFO - 2018-03-21 22:42:47 --> Security Class Initialized
DEBUG - 2018-03-21 22:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:42:47 --> CSRF cookie sent
INFO - 2018-03-21 22:42:47 --> Input Class Initialized
INFO - 2018-03-21 22:42:47 --> Language Class Initialized
ERROR - 2018-03-21 22:42:48 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:43:52 --> Config Class Initialized
INFO - 2018-03-21 22:43:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:43:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:43:52 --> Utf8 Class Initialized
INFO - 2018-03-21 22:43:52 --> URI Class Initialized
INFO - 2018-03-21 22:43:52 --> Router Class Initialized
INFO - 2018-03-21 22:43:52 --> Output Class Initialized
INFO - 2018-03-21 22:43:52 --> Security Class Initialized
DEBUG - 2018-03-21 22:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:43:52 --> CSRF cookie sent
INFO - 2018-03-21 22:43:52 --> Input Class Initialized
INFO - 2018-03-21 22:43:52 --> Language Class Initialized
INFO - 2018-03-21 22:43:52 --> Loader Class Initialized
INFO - 2018-03-21 22:43:52 --> Helper loaded: url_helper
INFO - 2018-03-21 22:43:52 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:43:52 --> User Agent Class Initialized
INFO - 2018-03-21 22:43:52 --> Controller Class Initialized
INFO - 2018-03-21 22:43:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:43:52 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:43:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:43:52 --> Final output sent to browser
DEBUG - 2018-03-21 22:43:52 --> Total execution time: 0.2185
INFO - 2018-03-21 22:43:52 --> Config Class Initialized
INFO - 2018-03-21 22:43:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:43:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:43:52 --> Utf8 Class Initialized
INFO - 2018-03-21 22:43:52 --> URI Class Initialized
INFO - 2018-03-21 22:43:52 --> Router Class Initialized
INFO - 2018-03-21 22:43:52 --> Output Class Initialized
INFO - 2018-03-21 22:43:52 --> Security Class Initialized
DEBUG - 2018-03-21 22:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:43:52 --> CSRF cookie sent
INFO - 2018-03-21 22:43:52 --> Input Class Initialized
INFO - 2018-03-21 22:43:52 --> Language Class Initialized
ERROR - 2018-03-21 22:43:52 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:43:52 --> Config Class Initialized
INFO - 2018-03-21 22:43:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:43:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:43:52 --> Utf8 Class Initialized
INFO - 2018-03-21 22:43:52 --> URI Class Initialized
INFO - 2018-03-21 22:43:52 --> Router Class Initialized
INFO - 2018-03-21 22:43:52 --> Output Class Initialized
INFO - 2018-03-21 22:43:52 --> Security Class Initialized
DEBUG - 2018-03-21 22:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:43:52 --> CSRF cookie sent
INFO - 2018-03-21 22:43:52 --> Input Class Initialized
INFO - 2018-03-21 22:43:52 --> Language Class Initialized
ERROR - 2018-03-21 22:43:52 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:44:10 --> Config Class Initialized
INFO - 2018-03-21 22:44:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:10 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:10 --> URI Class Initialized
INFO - 2018-03-21 22:44:10 --> Router Class Initialized
INFO - 2018-03-21 22:44:10 --> Output Class Initialized
INFO - 2018-03-21 22:44:10 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:10 --> CSRF cookie sent
INFO - 2018-03-21 22:44:10 --> Input Class Initialized
INFO - 2018-03-21 22:44:10 --> Language Class Initialized
INFO - 2018-03-21 22:44:11 --> Loader Class Initialized
INFO - 2018-03-21 22:44:11 --> Helper loaded: url_helper
INFO - 2018-03-21 22:44:11 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:44:11 --> User Agent Class Initialized
INFO - 2018-03-21 22:44:11 --> Controller Class Initialized
INFO - 2018-03-21 22:44:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:44:11 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:44:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:44:11 --> Final output sent to browser
DEBUG - 2018-03-21 22:44:11 --> Total execution time: 0.2641
INFO - 2018-03-21 22:44:11 --> Config Class Initialized
INFO - 2018-03-21 22:44:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:11 --> URI Class Initialized
INFO - 2018-03-21 22:44:11 --> Router Class Initialized
INFO - 2018-03-21 22:44:11 --> Output Class Initialized
INFO - 2018-03-21 22:44:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:11 --> CSRF cookie sent
INFO - 2018-03-21 22:44:11 --> Input Class Initialized
INFO - 2018-03-21 22:44:11 --> Language Class Initialized
ERROR - 2018-03-21 22:44:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:44:11 --> Config Class Initialized
INFO - 2018-03-21 22:44:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:11 --> URI Class Initialized
INFO - 2018-03-21 22:44:11 --> Router Class Initialized
INFO - 2018-03-21 22:44:11 --> Output Class Initialized
INFO - 2018-03-21 22:44:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:11 --> CSRF cookie sent
INFO - 2018-03-21 22:44:11 --> Input Class Initialized
INFO - 2018-03-21 22:44:11 --> Language Class Initialized
ERROR - 2018-03-21 22:44:11 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:44:29 --> Config Class Initialized
INFO - 2018-03-21 22:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:30 --> URI Class Initialized
INFO - 2018-03-21 22:44:30 --> Router Class Initialized
INFO - 2018-03-21 22:44:30 --> Output Class Initialized
INFO - 2018-03-21 22:44:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:30 --> CSRF cookie sent
INFO - 2018-03-21 22:44:30 --> Input Class Initialized
INFO - 2018-03-21 22:44:30 --> Language Class Initialized
INFO - 2018-03-21 22:44:30 --> Loader Class Initialized
INFO - 2018-03-21 22:44:30 --> Helper loaded: url_helper
INFO - 2018-03-21 22:44:30 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:44:30 --> User Agent Class Initialized
INFO - 2018-03-21 22:44:30 --> Controller Class Initialized
INFO - 2018-03-21 22:44:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:44:30 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:44:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:44:30 --> Final output sent to browser
DEBUG - 2018-03-21 22:44:30 --> Total execution time: 0.2341
INFO - 2018-03-21 22:44:30 --> Config Class Initialized
INFO - 2018-03-21 22:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:30 --> URI Class Initialized
INFO - 2018-03-21 22:44:30 --> Router Class Initialized
INFO - 2018-03-21 22:44:30 --> Output Class Initialized
INFO - 2018-03-21 22:44:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:30 --> CSRF cookie sent
INFO - 2018-03-21 22:44:30 --> Input Class Initialized
INFO - 2018-03-21 22:44:30 --> Language Class Initialized
ERROR - 2018-03-21 22:44:30 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:44:30 --> Config Class Initialized
INFO - 2018-03-21 22:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:30 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:30 --> URI Class Initialized
INFO - 2018-03-21 22:44:30 --> Router Class Initialized
INFO - 2018-03-21 22:44:30 --> Output Class Initialized
INFO - 2018-03-21 22:44:30 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:30 --> CSRF cookie sent
INFO - 2018-03-21 22:44:30 --> Input Class Initialized
INFO - 2018-03-21 22:44:30 --> Language Class Initialized
ERROR - 2018-03-21 22:44:30 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:44:44 --> Config Class Initialized
INFO - 2018-03-21 22:44:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:45 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:45 --> URI Class Initialized
INFO - 2018-03-21 22:44:45 --> Router Class Initialized
INFO - 2018-03-21 22:44:45 --> Output Class Initialized
INFO - 2018-03-21 22:44:45 --> Security Class Initialized
DEBUG - 2018-03-21 22:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:45 --> CSRF cookie sent
INFO - 2018-03-21 22:44:45 --> Input Class Initialized
INFO - 2018-03-21 22:44:45 --> Language Class Initialized
INFO - 2018-03-21 22:44:45 --> Loader Class Initialized
INFO - 2018-03-21 22:44:45 --> Helper loaded: url_helper
INFO - 2018-03-21 22:44:45 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:44:45 --> User Agent Class Initialized
INFO - 2018-03-21 22:44:45 --> Controller Class Initialized
INFO - 2018-03-21 22:44:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:44:45 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:44:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:44:45 --> Final output sent to browser
DEBUG - 2018-03-21 22:44:45 --> Total execution time: 0.2347
INFO - 2018-03-21 22:44:45 --> Config Class Initialized
INFO - 2018-03-21 22:44:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:44:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:45 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:45 --> URI Class Initialized
INFO - 2018-03-21 22:44:45 --> Config Class Initialized
INFO - 2018-03-21 22:44:45 --> Hooks Class Initialized
INFO - 2018-03-21 22:44:45 --> Router Class Initialized
INFO - 2018-03-21 22:44:45 --> Output Class Initialized
DEBUG - 2018-03-21 22:44:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:44:45 --> Utf8 Class Initialized
INFO - 2018-03-21 22:44:45 --> Security Class Initialized
INFO - 2018-03-21 22:44:45 --> URI Class Initialized
DEBUG - 2018-03-21 22:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:45 --> CSRF cookie sent
INFO - 2018-03-21 22:44:45 --> Router Class Initialized
INFO - 2018-03-21 22:44:45 --> Input Class Initialized
INFO - 2018-03-21 22:44:45 --> Output Class Initialized
INFO - 2018-03-21 22:44:45 --> Language Class Initialized
INFO - 2018-03-21 22:44:45 --> Security Class Initialized
ERROR - 2018-03-21 22:44:45 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 22:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:44:45 --> CSRF cookie sent
INFO - 2018-03-21 22:44:45 --> Input Class Initialized
INFO - 2018-03-21 22:44:45 --> Language Class Initialized
ERROR - 2018-03-21 22:44:45 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:45:01 --> Config Class Initialized
INFO - 2018-03-21 22:45:01 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:01 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:01 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:01 --> URI Class Initialized
INFO - 2018-03-21 22:45:01 --> Router Class Initialized
INFO - 2018-03-21 22:45:01 --> Output Class Initialized
INFO - 2018-03-21 22:45:01 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:01 --> CSRF cookie sent
INFO - 2018-03-21 22:45:01 --> Input Class Initialized
INFO - 2018-03-21 22:45:01 --> Language Class Initialized
INFO - 2018-03-21 22:45:01 --> Loader Class Initialized
INFO - 2018-03-21 22:45:01 --> Helper loaded: url_helper
INFO - 2018-03-21 22:45:01 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:45:01 --> User Agent Class Initialized
INFO - 2018-03-21 22:45:01 --> Controller Class Initialized
INFO - 2018-03-21 22:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:45:01 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:45:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:45:02 --> Final output sent to browser
DEBUG - 2018-03-21 22:45:02 --> Total execution time: 0.2644
INFO - 2018-03-21 22:45:02 --> Config Class Initialized
INFO - 2018-03-21 22:45:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:02 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:02 --> URI Class Initialized
INFO - 2018-03-21 22:45:02 --> Router Class Initialized
INFO - 2018-03-21 22:45:02 --> Output Class Initialized
INFO - 2018-03-21 22:45:02 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:02 --> CSRF cookie sent
INFO - 2018-03-21 22:45:02 --> Input Class Initialized
INFO - 2018-03-21 22:45:02 --> Language Class Initialized
ERROR - 2018-03-21 22:45:02 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:45:02 --> Config Class Initialized
INFO - 2018-03-21 22:45:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:02 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:02 --> URI Class Initialized
INFO - 2018-03-21 22:45:02 --> Router Class Initialized
INFO - 2018-03-21 22:45:02 --> Output Class Initialized
INFO - 2018-03-21 22:45:02 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:02 --> CSRF cookie sent
INFO - 2018-03-21 22:45:02 --> Input Class Initialized
INFO - 2018-03-21 22:45:02 --> Language Class Initialized
ERROR - 2018-03-21 22:45:02 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:45:14 --> Config Class Initialized
INFO - 2018-03-21 22:45:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:14 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:14 --> URI Class Initialized
INFO - 2018-03-21 22:45:14 --> Router Class Initialized
INFO - 2018-03-21 22:45:14 --> Output Class Initialized
INFO - 2018-03-21 22:45:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:14 --> CSRF cookie sent
INFO - 2018-03-21 22:45:14 --> Input Class Initialized
INFO - 2018-03-21 22:45:14 --> Language Class Initialized
INFO - 2018-03-21 22:45:14 --> Loader Class Initialized
INFO - 2018-03-21 22:45:14 --> Helper loaded: url_helper
INFO - 2018-03-21 22:45:14 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:45:14 --> User Agent Class Initialized
INFO - 2018-03-21 22:45:14 --> Controller Class Initialized
INFO - 2018-03-21 22:45:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:45:14 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:45:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:45:14 --> Final output sent to browser
DEBUG - 2018-03-21 22:45:14 --> Total execution time: 0.2382
INFO - 2018-03-21 22:45:14 --> Config Class Initialized
INFO - 2018-03-21 22:45:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:14 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:14 --> URI Class Initialized
INFO - 2018-03-21 22:45:14 --> Router Class Initialized
INFO - 2018-03-21 22:45:14 --> Output Class Initialized
INFO - 2018-03-21 22:45:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:14 --> CSRF cookie sent
INFO - 2018-03-21 22:45:14 --> Input Class Initialized
INFO - 2018-03-21 22:45:14 --> Language Class Initialized
ERROR - 2018-03-21 22:45:15 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:45:15 --> Config Class Initialized
INFO - 2018-03-21 22:45:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:15 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:15 --> URI Class Initialized
INFO - 2018-03-21 22:45:15 --> Router Class Initialized
INFO - 2018-03-21 22:45:15 --> Output Class Initialized
INFO - 2018-03-21 22:45:15 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:15 --> CSRF cookie sent
INFO - 2018-03-21 22:45:15 --> Input Class Initialized
INFO - 2018-03-21 22:45:15 --> Language Class Initialized
ERROR - 2018-03-21 22:45:15 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:45:25 --> Config Class Initialized
INFO - 2018-03-21 22:45:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:25 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:25 --> URI Class Initialized
INFO - 2018-03-21 22:45:25 --> Router Class Initialized
INFO - 2018-03-21 22:45:25 --> Output Class Initialized
INFO - 2018-03-21 22:45:25 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:25 --> CSRF cookie sent
INFO - 2018-03-21 22:45:25 --> Input Class Initialized
INFO - 2018-03-21 22:45:25 --> Language Class Initialized
INFO - 2018-03-21 22:45:25 --> Loader Class Initialized
INFO - 2018-03-21 22:45:25 --> Helper loaded: url_helper
INFO - 2018-03-21 22:45:25 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:45:25 --> User Agent Class Initialized
INFO - 2018-03-21 22:45:25 --> Controller Class Initialized
INFO - 2018-03-21 22:45:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:45:25 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:45:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:45:25 --> Final output sent to browser
DEBUG - 2018-03-21 22:45:25 --> Total execution time: 0.2415
INFO - 2018-03-21 22:45:25 --> Config Class Initialized
INFO - 2018-03-21 22:45:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:25 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:25 --> URI Class Initialized
INFO - 2018-03-21 22:45:25 --> Router Class Initialized
INFO - 2018-03-21 22:45:25 --> Output Class Initialized
INFO - 2018-03-21 22:45:25 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:25 --> CSRF cookie sent
INFO - 2018-03-21 22:45:25 --> Input Class Initialized
INFO - 2018-03-21 22:45:25 --> Language Class Initialized
ERROR - 2018-03-21 22:45:25 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:45:26 --> Config Class Initialized
INFO - 2018-03-21 22:45:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:26 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:26 --> URI Class Initialized
INFO - 2018-03-21 22:45:26 --> Router Class Initialized
INFO - 2018-03-21 22:45:26 --> Output Class Initialized
INFO - 2018-03-21 22:45:26 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:26 --> CSRF cookie sent
INFO - 2018-03-21 22:45:26 --> Input Class Initialized
INFO - 2018-03-21 22:45:26 --> Language Class Initialized
ERROR - 2018-03-21 22:45:26 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:45:36 --> Config Class Initialized
INFO - 2018-03-21 22:45:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:36 --> URI Class Initialized
INFO - 2018-03-21 22:45:36 --> Router Class Initialized
INFO - 2018-03-21 22:45:36 --> Output Class Initialized
INFO - 2018-03-21 22:45:36 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:36 --> CSRF cookie sent
INFO - 2018-03-21 22:45:36 --> Input Class Initialized
INFO - 2018-03-21 22:45:36 --> Language Class Initialized
INFO - 2018-03-21 22:45:36 --> Loader Class Initialized
INFO - 2018-03-21 22:45:36 --> Helper loaded: url_helper
INFO - 2018-03-21 22:45:36 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:45:36 --> User Agent Class Initialized
INFO - 2018-03-21 22:45:36 --> Controller Class Initialized
INFO - 2018-03-21 22:45:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:45:36 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:45:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:45:36 --> Final output sent to browser
DEBUG - 2018-03-21 22:45:36 --> Total execution time: 0.2392
INFO - 2018-03-21 22:45:36 --> Config Class Initialized
INFO - 2018-03-21 22:45:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:36 --> URI Class Initialized
INFO - 2018-03-21 22:45:37 --> Router Class Initialized
INFO - 2018-03-21 22:45:37 --> Output Class Initialized
INFO - 2018-03-21 22:45:37 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:37 --> CSRF cookie sent
INFO - 2018-03-21 22:45:37 --> Input Class Initialized
INFO - 2018-03-21 22:45:37 --> Language Class Initialized
ERROR - 2018-03-21 22:45:37 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:45:37 --> Config Class Initialized
INFO - 2018-03-21 22:45:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:37 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:37 --> URI Class Initialized
INFO - 2018-03-21 22:45:37 --> Router Class Initialized
INFO - 2018-03-21 22:45:37 --> Output Class Initialized
INFO - 2018-03-21 22:45:37 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:37 --> CSRF cookie sent
INFO - 2018-03-21 22:45:37 --> Input Class Initialized
INFO - 2018-03-21 22:45:37 --> Language Class Initialized
ERROR - 2018-03-21 22:45:37 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:46:38 --> Config Class Initialized
INFO - 2018-03-21 22:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:46:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:46:38 --> URI Class Initialized
INFO - 2018-03-21 22:46:38 --> Router Class Initialized
INFO - 2018-03-21 22:46:38 --> Output Class Initialized
INFO - 2018-03-21 22:46:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:46:38 --> CSRF cookie sent
INFO - 2018-03-21 22:46:38 --> Input Class Initialized
INFO - 2018-03-21 22:46:38 --> Language Class Initialized
INFO - 2018-03-21 22:46:38 --> Loader Class Initialized
INFO - 2018-03-21 22:46:38 --> Helper loaded: url_helper
INFO - 2018-03-21 22:46:38 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:46:38 --> User Agent Class Initialized
INFO - 2018-03-21 22:46:38 --> Controller Class Initialized
INFO - 2018-03-21 22:46:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:46:38 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:46:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:46:38 --> Final output sent to browser
DEBUG - 2018-03-21 22:46:38 --> Total execution time: 0.2762
INFO - 2018-03-21 22:46:38 --> Config Class Initialized
INFO - 2018-03-21 22:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:46:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:46:38 --> URI Class Initialized
INFO - 2018-03-21 22:46:38 --> Router Class Initialized
INFO - 2018-03-21 22:46:38 --> Output Class Initialized
INFO - 2018-03-21 22:46:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:46:38 --> CSRF cookie sent
INFO - 2018-03-21 22:46:39 --> Input Class Initialized
INFO - 2018-03-21 22:46:39 --> Language Class Initialized
ERROR - 2018-03-21 22:46:39 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:46:39 --> Config Class Initialized
INFO - 2018-03-21 22:46:39 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:46:39 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:46:39 --> Utf8 Class Initialized
INFO - 2018-03-21 22:46:39 --> URI Class Initialized
INFO - 2018-03-21 22:46:39 --> Router Class Initialized
INFO - 2018-03-21 22:46:39 --> Output Class Initialized
INFO - 2018-03-21 22:46:39 --> Security Class Initialized
DEBUG - 2018-03-21 22:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:46:39 --> CSRF cookie sent
INFO - 2018-03-21 22:46:39 --> Input Class Initialized
INFO - 2018-03-21 22:46:39 --> Language Class Initialized
ERROR - 2018-03-21 22:46:39 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:47:36 --> Config Class Initialized
INFO - 2018-03-21 22:47:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:47:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:47:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:47:36 --> URI Class Initialized
INFO - 2018-03-21 22:47:36 --> Router Class Initialized
INFO - 2018-03-21 22:47:36 --> Output Class Initialized
INFO - 2018-03-21 22:47:36 --> Security Class Initialized
DEBUG - 2018-03-21 22:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:47:36 --> CSRF cookie sent
INFO - 2018-03-21 22:47:36 --> Input Class Initialized
INFO - 2018-03-21 22:47:36 --> Language Class Initialized
INFO - 2018-03-21 22:47:36 --> Loader Class Initialized
INFO - 2018-03-21 22:47:36 --> Helper loaded: url_helper
INFO - 2018-03-21 22:47:36 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:47:36 --> User Agent Class Initialized
INFO - 2018-03-21 22:47:36 --> Controller Class Initialized
INFO - 2018-03-21 22:47:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:47:36 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:47:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:47:36 --> Final output sent to browser
DEBUG - 2018-03-21 22:47:36 --> Total execution time: 0.2466
INFO - 2018-03-21 22:47:37 --> Config Class Initialized
INFO - 2018-03-21 22:47:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:47:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:47:37 --> Utf8 Class Initialized
INFO - 2018-03-21 22:47:37 --> URI Class Initialized
INFO - 2018-03-21 22:47:37 --> Router Class Initialized
INFO - 2018-03-21 22:47:37 --> Output Class Initialized
INFO - 2018-03-21 22:47:37 --> Security Class Initialized
DEBUG - 2018-03-21 22:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:47:37 --> CSRF cookie sent
INFO - 2018-03-21 22:47:37 --> Input Class Initialized
INFO - 2018-03-21 22:47:37 --> Language Class Initialized
ERROR - 2018-03-21 22:47:37 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:47:37 --> Config Class Initialized
INFO - 2018-03-21 22:47:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:47:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:47:37 --> Utf8 Class Initialized
INFO - 2018-03-21 22:47:37 --> URI Class Initialized
INFO - 2018-03-21 22:47:37 --> Router Class Initialized
INFO - 2018-03-21 22:47:37 --> Output Class Initialized
INFO - 2018-03-21 22:47:37 --> Security Class Initialized
DEBUG - 2018-03-21 22:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:47:37 --> CSRF cookie sent
INFO - 2018-03-21 22:47:37 --> Input Class Initialized
INFO - 2018-03-21 22:47:37 --> Language Class Initialized
ERROR - 2018-03-21 22:47:37 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:48:22 --> Config Class Initialized
INFO - 2018-03-21 22:48:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:22 --> URI Class Initialized
INFO - 2018-03-21 22:48:22 --> Router Class Initialized
INFO - 2018-03-21 22:48:22 --> Output Class Initialized
INFO - 2018-03-21 22:48:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:22 --> CSRF cookie sent
INFO - 2018-03-21 22:48:22 --> Input Class Initialized
INFO - 2018-03-21 22:48:22 --> Language Class Initialized
INFO - 2018-03-21 22:48:23 --> Loader Class Initialized
INFO - 2018-03-21 22:48:23 --> Helper loaded: url_helper
INFO - 2018-03-21 22:48:23 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:48:23 --> User Agent Class Initialized
INFO - 2018-03-21 22:48:23 --> Controller Class Initialized
INFO - 2018-03-21 22:48:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:48:23 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:48:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:48:23 --> Final output sent to browser
DEBUG - 2018-03-21 22:48:23 --> Total execution time: 0.2424
INFO - 2018-03-21 22:48:23 --> Config Class Initialized
INFO - 2018-03-21 22:48:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:23 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:23 --> URI Class Initialized
INFO - 2018-03-21 22:48:23 --> Router Class Initialized
INFO - 2018-03-21 22:48:23 --> Output Class Initialized
INFO - 2018-03-21 22:48:23 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:23 --> CSRF cookie sent
INFO - 2018-03-21 22:48:23 --> Input Class Initialized
INFO - 2018-03-21 22:48:23 --> Language Class Initialized
ERROR - 2018-03-21 22:48:23 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:48:24 --> Config Class Initialized
INFO - 2018-03-21 22:48:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:24 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:24 --> URI Class Initialized
INFO - 2018-03-21 22:48:24 --> Router Class Initialized
INFO - 2018-03-21 22:48:24 --> Output Class Initialized
INFO - 2018-03-21 22:48:24 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:24 --> CSRF cookie sent
INFO - 2018-03-21 22:48:24 --> Input Class Initialized
INFO - 2018-03-21 22:48:24 --> Language Class Initialized
ERROR - 2018-03-21 22:48:24 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:48:42 --> Config Class Initialized
INFO - 2018-03-21 22:48:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:42 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:42 --> URI Class Initialized
INFO - 2018-03-21 22:48:42 --> Router Class Initialized
INFO - 2018-03-21 22:48:42 --> Output Class Initialized
INFO - 2018-03-21 22:48:42 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:42 --> CSRF cookie sent
INFO - 2018-03-21 22:48:42 --> Input Class Initialized
INFO - 2018-03-21 22:48:42 --> Language Class Initialized
INFO - 2018-03-21 22:48:42 --> Loader Class Initialized
INFO - 2018-03-21 22:48:42 --> Helper loaded: url_helper
INFO - 2018-03-21 22:48:42 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:48:43 --> User Agent Class Initialized
INFO - 2018-03-21 22:48:43 --> Controller Class Initialized
INFO - 2018-03-21 22:48:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:48:43 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:48:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:48:43 --> Final output sent to browser
DEBUG - 2018-03-21 22:48:43 --> Total execution time: 0.2628
INFO - 2018-03-21 22:48:43 --> Config Class Initialized
INFO - 2018-03-21 22:48:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:43 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:43 --> URI Class Initialized
INFO - 2018-03-21 22:48:43 --> Router Class Initialized
INFO - 2018-03-21 22:48:43 --> Output Class Initialized
INFO - 2018-03-21 22:48:43 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:43 --> CSRF cookie sent
INFO - 2018-03-21 22:48:43 --> Input Class Initialized
INFO - 2018-03-21 22:48:43 --> Language Class Initialized
ERROR - 2018-03-21 22:48:43 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:48:44 --> Config Class Initialized
INFO - 2018-03-21 22:48:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:44 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:44 --> URI Class Initialized
INFO - 2018-03-21 22:48:44 --> Router Class Initialized
INFO - 2018-03-21 22:48:44 --> Output Class Initialized
INFO - 2018-03-21 22:48:44 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:44 --> CSRF cookie sent
INFO - 2018-03-21 22:48:44 --> Input Class Initialized
INFO - 2018-03-21 22:48:44 --> Language Class Initialized
ERROR - 2018-03-21 22:48:44 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:53:11 --> Config Class Initialized
INFO - 2018-03-21 22:53:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:11 --> URI Class Initialized
INFO - 2018-03-21 22:53:11 --> Router Class Initialized
INFO - 2018-03-21 22:53:11 --> Output Class Initialized
INFO - 2018-03-21 22:53:11 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:11 --> CSRF cookie sent
INFO - 2018-03-21 22:53:11 --> Input Class Initialized
INFO - 2018-03-21 22:53:11 --> Language Class Initialized
INFO - 2018-03-21 22:53:11 --> Loader Class Initialized
INFO - 2018-03-21 22:53:11 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:11 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:11 --> User Agent Class Initialized
INFO - 2018-03-21 22:53:11 --> Controller Class Initialized
INFO - 2018-03-21 22:53:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:53:11 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:53:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:53:11 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:11 --> Total execution time: 0.2503
INFO - 2018-03-21 22:53:11 --> Config Class Initialized
INFO - 2018-03-21 22:53:11 --> Config Class Initialized
INFO - 2018-03-21 22:53:11 --> Hooks Class Initialized
INFO - 2018-03-21 22:53:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 22:53:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:11 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:11 --> URI Class Initialized
INFO - 2018-03-21 22:53:12 --> Router Class Initialized
INFO - 2018-03-21 22:53:12 --> Output Class Initialized
INFO - 2018-03-21 22:53:12 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:12 --> Security Class Initialized
INFO - 2018-03-21 22:53:12 --> URI Class Initialized
DEBUG - 2018-03-21 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:12 --> CSRF cookie sent
INFO - 2018-03-21 22:53:12 --> Router Class Initialized
INFO - 2018-03-21 22:53:12 --> Input Class Initialized
INFO - 2018-03-21 22:53:12 --> Output Class Initialized
INFO - 2018-03-21 22:53:12 --> Language Class Initialized
INFO - 2018-03-21 22:53:12 --> Security Class Initialized
ERROR - 2018-03-21 22:53:12 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:12 --> CSRF cookie sent
INFO - 2018-03-21 22:53:12 --> Input Class Initialized
INFO - 2018-03-21 22:53:12 --> Language Class Initialized
ERROR - 2018-03-21 22:53:12 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:53:22 --> Config Class Initialized
INFO - 2018-03-21 22:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:22 --> URI Class Initialized
INFO - 2018-03-21 22:53:22 --> Router Class Initialized
INFO - 2018-03-21 22:53:22 --> Output Class Initialized
INFO - 2018-03-21 22:53:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:22 --> CSRF cookie sent
INFO - 2018-03-21 22:53:22 --> Input Class Initialized
INFO - 2018-03-21 22:53:22 --> Language Class Initialized
INFO - 2018-03-21 22:53:22 --> Loader Class Initialized
INFO - 2018-03-21 22:53:22 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:22 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:22 --> User Agent Class Initialized
INFO - 2018-03-21 22:53:22 --> Controller Class Initialized
INFO - 2018-03-21 22:53:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:53:22 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:53:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:53:22 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:22 --> Total execution time: 0.2480
INFO - 2018-03-21 22:53:22 --> Config Class Initialized
INFO - 2018-03-21 22:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:22 --> URI Class Initialized
INFO - 2018-03-21 22:53:22 --> Router Class Initialized
INFO - 2018-03-21 22:53:22 --> Output Class Initialized
INFO - 2018-03-21 22:53:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:22 --> CSRF cookie sent
INFO - 2018-03-21 22:53:22 --> Input Class Initialized
INFO - 2018-03-21 22:53:22 --> Language Class Initialized
ERROR - 2018-03-21 22:53:22 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:53:22 --> Config Class Initialized
INFO - 2018-03-21 22:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:22 --> URI Class Initialized
INFO - 2018-03-21 22:53:22 --> Router Class Initialized
INFO - 2018-03-21 22:53:22 --> Output Class Initialized
INFO - 2018-03-21 22:53:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:22 --> CSRF cookie sent
INFO - 2018-03-21 22:53:22 --> Input Class Initialized
INFO - 2018-03-21 22:53:22 --> Language Class Initialized
ERROR - 2018-03-21 22:53:22 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 22:58:40 --> Config Class Initialized
INFO - 2018-03-21 22:58:40 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:58:40 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:58:40 --> Utf8 Class Initialized
INFO - 2018-03-21 22:58:41 --> URI Class Initialized
INFO - 2018-03-21 22:58:41 --> Router Class Initialized
INFO - 2018-03-21 22:58:41 --> Output Class Initialized
INFO - 2018-03-21 22:58:41 --> Security Class Initialized
DEBUG - 2018-03-21 22:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:58:41 --> CSRF cookie sent
INFO - 2018-03-21 22:58:41 --> Input Class Initialized
INFO - 2018-03-21 22:58:41 --> Language Class Initialized
INFO - 2018-03-21 22:58:41 --> Loader Class Initialized
INFO - 2018-03-21 22:58:41 --> Helper loaded: url_helper
INFO - 2018-03-21 22:58:41 --> Helper loaded: form_helper
DEBUG - 2018-03-21 22:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:58:41 --> User Agent Class Initialized
INFO - 2018-03-21 22:58:41 --> Controller Class Initialized
INFO - 2018-03-21 22:58:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 22:58:41 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 22:58:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 22:58:41 --> Final output sent to browser
DEBUG - 2018-03-21 22:58:41 --> Total execution time: 0.2341
INFO - 2018-03-21 22:58:41 --> Config Class Initialized
INFO - 2018-03-21 22:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:58:41 --> Utf8 Class Initialized
INFO - 2018-03-21 22:58:41 --> URI Class Initialized
INFO - 2018-03-21 22:58:41 --> Router Class Initialized
INFO - 2018-03-21 22:58:41 --> Output Class Initialized
INFO - 2018-03-21 22:58:41 --> Security Class Initialized
DEBUG - 2018-03-21 22:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:58:41 --> CSRF cookie sent
INFO - 2018-03-21 22:58:41 --> Input Class Initialized
INFO - 2018-03-21 22:58:41 --> Language Class Initialized
ERROR - 2018-03-21 22:58:41 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 22:58:41 --> Config Class Initialized
INFO - 2018-03-21 22:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:58:41 --> Utf8 Class Initialized
INFO - 2018-03-21 22:58:41 --> URI Class Initialized
INFO - 2018-03-21 22:58:41 --> Router Class Initialized
INFO - 2018-03-21 22:58:41 --> Output Class Initialized
INFO - 2018-03-21 22:58:41 --> Security Class Initialized
DEBUG - 2018-03-21 22:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:58:41 --> CSRF cookie sent
INFO - 2018-03-21 22:58:41 --> Input Class Initialized
INFO - 2018-03-21 22:58:41 --> Language Class Initialized
ERROR - 2018-03-21 22:58:41 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:00:17 --> Config Class Initialized
INFO - 2018-03-21 23:00:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:17 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:17 --> URI Class Initialized
INFO - 2018-03-21 23:00:17 --> Router Class Initialized
INFO - 2018-03-21 23:00:17 --> Output Class Initialized
INFO - 2018-03-21 23:00:17 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:17 --> CSRF cookie sent
INFO - 2018-03-21 23:00:17 --> Input Class Initialized
INFO - 2018-03-21 23:00:17 --> Language Class Initialized
INFO - 2018-03-21 23:00:17 --> Loader Class Initialized
INFO - 2018-03-21 23:00:17 --> Helper loaded: url_helper
INFO - 2018-03-21 23:00:17 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:00:17 --> User Agent Class Initialized
INFO - 2018-03-21 23:00:17 --> Controller Class Initialized
INFO - 2018-03-21 23:00:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:00:17 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:00:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:00:17 --> Final output sent to browser
DEBUG - 2018-03-21 23:00:17 --> Total execution time: 0.2352
INFO - 2018-03-21 23:00:17 --> Config Class Initialized
INFO - 2018-03-21 23:00:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:17 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:17 --> URI Class Initialized
INFO - 2018-03-21 23:00:17 --> Router Class Initialized
INFO - 2018-03-21 23:00:17 --> Output Class Initialized
INFO - 2018-03-21 23:00:17 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:17 --> CSRF cookie sent
INFO - 2018-03-21 23:00:17 --> Input Class Initialized
INFO - 2018-03-21 23:00:17 --> Language Class Initialized
ERROR - 2018-03-21 23:00:17 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:00:17 --> Config Class Initialized
INFO - 2018-03-21 23:00:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:18 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:18 --> URI Class Initialized
INFO - 2018-03-21 23:00:18 --> Router Class Initialized
INFO - 2018-03-21 23:00:18 --> Output Class Initialized
INFO - 2018-03-21 23:00:18 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:18 --> CSRF cookie sent
INFO - 2018-03-21 23:00:18 --> Input Class Initialized
INFO - 2018-03-21 23:00:18 --> Language Class Initialized
ERROR - 2018-03-21 23:00:18 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:00:46 --> Config Class Initialized
INFO - 2018-03-21 23:00:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:46 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:46 --> URI Class Initialized
INFO - 2018-03-21 23:00:46 --> Router Class Initialized
INFO - 2018-03-21 23:00:46 --> Output Class Initialized
INFO - 2018-03-21 23:00:46 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:46 --> CSRF cookie sent
INFO - 2018-03-21 23:00:46 --> Input Class Initialized
INFO - 2018-03-21 23:00:46 --> Language Class Initialized
INFO - 2018-03-21 23:00:46 --> Loader Class Initialized
INFO - 2018-03-21 23:00:46 --> Helper loaded: url_helper
INFO - 2018-03-21 23:00:46 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:00:46 --> User Agent Class Initialized
INFO - 2018-03-21 23:00:46 --> Controller Class Initialized
INFO - 2018-03-21 23:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:00:46 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:00:46 --> Final output sent to browser
DEBUG - 2018-03-21 23:00:47 --> Total execution time: 0.2371
INFO - 2018-03-21 23:00:47 --> Config Class Initialized
INFO - 2018-03-21 23:00:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:47 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:47 --> URI Class Initialized
INFO - 2018-03-21 23:00:47 --> Router Class Initialized
INFO - 2018-03-21 23:00:47 --> Output Class Initialized
INFO - 2018-03-21 23:00:47 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:47 --> CSRF cookie sent
INFO - 2018-03-21 23:00:47 --> Input Class Initialized
INFO - 2018-03-21 23:00:47 --> Language Class Initialized
ERROR - 2018-03-21 23:00:47 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:00:47 --> Config Class Initialized
INFO - 2018-03-21 23:00:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:00:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:00:47 --> Utf8 Class Initialized
INFO - 2018-03-21 23:00:47 --> URI Class Initialized
INFO - 2018-03-21 23:00:47 --> Router Class Initialized
INFO - 2018-03-21 23:00:47 --> Output Class Initialized
INFO - 2018-03-21 23:00:47 --> Security Class Initialized
DEBUG - 2018-03-21 23:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:00:47 --> CSRF cookie sent
INFO - 2018-03-21 23:00:47 --> Input Class Initialized
INFO - 2018-03-21 23:00:47 --> Language Class Initialized
ERROR - 2018-03-21 23:00:47 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:01:26 --> Config Class Initialized
INFO - 2018-03-21 23:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:26 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:26 --> URI Class Initialized
INFO - 2018-03-21 23:01:26 --> Router Class Initialized
INFO - 2018-03-21 23:01:26 --> Output Class Initialized
INFO - 2018-03-21 23:01:26 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:26 --> CSRF cookie sent
INFO - 2018-03-21 23:01:26 --> Input Class Initialized
INFO - 2018-03-21 23:01:26 --> Language Class Initialized
INFO - 2018-03-21 23:01:26 --> Loader Class Initialized
INFO - 2018-03-21 23:01:26 --> Helper loaded: url_helper
INFO - 2018-03-21 23:01:26 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:01:26 --> User Agent Class Initialized
INFO - 2018-03-21 23:01:26 --> Controller Class Initialized
INFO - 2018-03-21 23:01:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:01:26 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:01:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:01:26 --> Final output sent to browser
DEBUG - 2018-03-21 23:01:26 --> Total execution time: 0.2448
INFO - 2018-03-21 23:01:26 --> Config Class Initialized
INFO - 2018-03-21 23:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:26 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:26 --> URI Class Initialized
INFO - 2018-03-21 23:01:26 --> Router Class Initialized
INFO - 2018-03-21 23:01:26 --> Output Class Initialized
INFO - 2018-03-21 23:01:26 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:26 --> CSRF cookie sent
INFO - 2018-03-21 23:01:26 --> Input Class Initialized
INFO - 2018-03-21 23:01:26 --> Language Class Initialized
ERROR - 2018-03-21 23:01:26 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:01:26 --> Config Class Initialized
INFO - 2018-03-21 23:01:26 --> Config Class Initialized
INFO - 2018-03-21 23:01:26 --> Hooks Class Initialized
INFO - 2018-03-21 23:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 23:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:26 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:26 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:26 --> URI Class Initialized
INFO - 2018-03-21 23:01:26 --> URI Class Initialized
INFO - 2018-03-21 23:01:26 --> Router Class Initialized
INFO - 2018-03-21 23:01:26 --> Router Class Initialized
INFO - 2018-03-21 23:01:26 --> Output Class Initialized
INFO - 2018-03-21 23:01:26 --> Output Class Initialized
INFO - 2018-03-21 23:01:26 --> Security Class Initialized
INFO - 2018-03-21 23:01:26 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 23:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:26 --> CSRF cookie sent
INFO - 2018-03-21 23:01:26 --> CSRF cookie sent
INFO - 2018-03-21 23:01:26 --> Input Class Initialized
INFO - 2018-03-21 23:01:26 --> Input Class Initialized
INFO - 2018-03-21 23:01:26 --> Language Class Initialized
ERROR - 2018-03-21 23:01:26 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:01:26 --> Language Class Initialized
ERROR - 2018-03-21 23:01:26 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:01:27 --> Config Class Initialized
INFO - 2018-03-21 23:01:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:27 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:27 --> URI Class Initialized
INFO - 2018-03-21 23:01:27 --> Router Class Initialized
INFO - 2018-03-21 23:01:27 --> Output Class Initialized
INFO - 2018-03-21 23:01:27 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:27 --> CSRF cookie sent
INFO - 2018-03-21 23:01:27 --> Input Class Initialized
INFO - 2018-03-21 23:01:27 --> Language Class Initialized
ERROR - 2018-03-21 23:01:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:01:27 --> Config Class Initialized
INFO - 2018-03-21 23:01:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:27 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:27 --> URI Class Initialized
INFO - 2018-03-21 23:01:27 --> Router Class Initialized
INFO - 2018-03-21 23:01:27 --> Output Class Initialized
INFO - 2018-03-21 23:01:27 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:27 --> CSRF cookie sent
INFO - 2018-03-21 23:01:27 --> Input Class Initialized
INFO - 2018-03-21 23:01:27 --> Language Class Initialized
ERROR - 2018-03-21 23:01:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:01:58 --> Config Class Initialized
INFO - 2018-03-21 23:01:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:58 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:58 --> URI Class Initialized
INFO - 2018-03-21 23:01:58 --> Router Class Initialized
INFO - 2018-03-21 23:01:58 --> Output Class Initialized
INFO - 2018-03-21 23:01:58 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:58 --> CSRF cookie sent
INFO - 2018-03-21 23:01:58 --> Input Class Initialized
INFO - 2018-03-21 23:01:58 --> Language Class Initialized
INFO - 2018-03-21 23:01:58 --> Loader Class Initialized
INFO - 2018-03-21 23:01:58 --> Helper loaded: url_helper
INFO - 2018-03-21 23:01:58 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:01:58 --> User Agent Class Initialized
INFO - 2018-03-21 23:01:58 --> Controller Class Initialized
INFO - 2018-03-21 23:01:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:01:58 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:01:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:01:58 --> Final output sent to browser
DEBUG - 2018-03-21 23:01:59 --> Total execution time: 0.2363
INFO - 2018-03-21 23:01:59 --> Config Class Initialized
INFO - 2018-03-21 23:01:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:59 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:59 --> URI Class Initialized
INFO - 2018-03-21 23:01:59 --> Router Class Initialized
INFO - 2018-03-21 23:01:59 --> Output Class Initialized
INFO - 2018-03-21 23:01:59 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:59 --> CSRF cookie sent
INFO - 2018-03-21 23:01:59 --> Input Class Initialized
INFO - 2018-03-21 23:01:59 --> Language Class Initialized
ERROR - 2018-03-21 23:01:59 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:01:59 --> Config Class Initialized
INFO - 2018-03-21 23:01:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:01:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:01:59 --> Utf8 Class Initialized
INFO - 2018-03-21 23:01:59 --> URI Class Initialized
INFO - 2018-03-21 23:01:59 --> Router Class Initialized
INFO - 2018-03-21 23:01:59 --> Output Class Initialized
INFO - 2018-03-21 23:01:59 --> Security Class Initialized
DEBUG - 2018-03-21 23:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:01:59 --> CSRF cookie sent
INFO - 2018-03-21 23:01:59 --> Input Class Initialized
INFO - 2018-03-21 23:01:59 --> Language Class Initialized
ERROR - 2018-03-21 23:01:59 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:03:37 --> Config Class Initialized
INFO - 2018-03-21 23:03:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:03:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:03:37 --> Utf8 Class Initialized
INFO - 2018-03-21 23:03:37 --> URI Class Initialized
INFO - 2018-03-21 23:03:37 --> Router Class Initialized
INFO - 2018-03-21 23:03:37 --> Output Class Initialized
INFO - 2018-03-21 23:03:37 --> Security Class Initialized
DEBUG - 2018-03-21 23:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:03:37 --> CSRF cookie sent
INFO - 2018-03-21 23:03:37 --> Input Class Initialized
INFO - 2018-03-21 23:03:37 --> Language Class Initialized
INFO - 2018-03-21 23:03:37 --> Loader Class Initialized
INFO - 2018-03-21 23:03:37 --> Helper loaded: url_helper
INFO - 2018-03-21 23:03:37 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:03:37 --> User Agent Class Initialized
INFO - 2018-03-21 23:03:37 --> Controller Class Initialized
INFO - 2018-03-21 23:03:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:03:37 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:03:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:03:37 --> Final output sent to browser
DEBUG - 2018-03-21 23:03:37 --> Total execution time: 0.2390
INFO - 2018-03-21 23:03:37 --> Config Class Initialized
INFO - 2018-03-21 23:03:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:03:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:03:37 --> Utf8 Class Initialized
INFO - 2018-03-21 23:03:37 --> URI Class Initialized
INFO - 2018-03-21 23:03:37 --> Router Class Initialized
INFO - 2018-03-21 23:03:37 --> Output Class Initialized
INFO - 2018-03-21 23:03:37 --> Security Class Initialized
DEBUG - 2018-03-21 23:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:03:38 --> CSRF cookie sent
INFO - 2018-03-21 23:03:38 --> Input Class Initialized
INFO - 2018-03-21 23:03:38 --> Language Class Initialized
ERROR - 2018-03-21 23:03:38 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:03:38 --> Config Class Initialized
INFO - 2018-03-21 23:03:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:03:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:03:38 --> Utf8 Class Initialized
INFO - 2018-03-21 23:03:38 --> URI Class Initialized
INFO - 2018-03-21 23:03:38 --> Router Class Initialized
INFO - 2018-03-21 23:03:38 --> Output Class Initialized
INFO - 2018-03-21 23:03:38 --> Security Class Initialized
DEBUG - 2018-03-21 23:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:03:38 --> CSRF cookie sent
INFO - 2018-03-21 23:03:38 --> Input Class Initialized
INFO - 2018-03-21 23:03:38 --> Language Class Initialized
ERROR - 2018-03-21 23:03:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:04:16 --> Config Class Initialized
INFO - 2018-03-21 23:04:16 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:16 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:16 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:16 --> URI Class Initialized
INFO - 2018-03-21 23:04:16 --> Router Class Initialized
INFO - 2018-03-21 23:04:16 --> Output Class Initialized
INFO - 2018-03-21 23:04:16 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:16 --> CSRF cookie sent
INFO - 2018-03-21 23:04:16 --> Input Class Initialized
INFO - 2018-03-21 23:04:16 --> Language Class Initialized
INFO - 2018-03-21 23:04:16 --> Loader Class Initialized
INFO - 2018-03-21 23:04:16 --> Helper loaded: url_helper
INFO - 2018-03-21 23:04:16 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:04:16 --> User Agent Class Initialized
INFO - 2018-03-21 23:04:16 --> Controller Class Initialized
INFO - 2018-03-21 23:04:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:04:16 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:04:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:04:16 --> Final output sent to browser
DEBUG - 2018-03-21 23:04:16 --> Total execution time: 0.2405
INFO - 2018-03-21 23:04:16 --> Config Class Initialized
INFO - 2018-03-21 23:04:16 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:16 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:16 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:16 --> URI Class Initialized
INFO - 2018-03-21 23:04:16 --> Router Class Initialized
INFO - 2018-03-21 23:04:16 --> Output Class Initialized
INFO - 2018-03-21 23:04:16 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:16 --> CSRF cookie sent
INFO - 2018-03-21 23:04:16 --> Input Class Initialized
INFO - 2018-03-21 23:04:17 --> Language Class Initialized
ERROR - 2018-03-21 23:04:17 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:04:17 --> Config Class Initialized
INFO - 2018-03-21 23:04:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:17 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:17 --> URI Class Initialized
INFO - 2018-03-21 23:04:17 --> Router Class Initialized
INFO - 2018-03-21 23:04:17 --> Output Class Initialized
INFO - 2018-03-21 23:04:17 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:17 --> CSRF cookie sent
INFO - 2018-03-21 23:04:17 --> Input Class Initialized
INFO - 2018-03-21 23:04:17 --> Language Class Initialized
ERROR - 2018-03-21 23:04:17 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:04:50 --> Config Class Initialized
INFO - 2018-03-21 23:04:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:50 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:50 --> URI Class Initialized
INFO - 2018-03-21 23:04:50 --> Router Class Initialized
INFO - 2018-03-21 23:04:50 --> Output Class Initialized
INFO - 2018-03-21 23:04:50 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:50 --> CSRF cookie sent
INFO - 2018-03-21 23:04:50 --> Input Class Initialized
INFO - 2018-03-21 23:04:51 --> Language Class Initialized
INFO - 2018-03-21 23:04:51 --> Loader Class Initialized
INFO - 2018-03-21 23:04:51 --> Helper loaded: url_helper
INFO - 2018-03-21 23:04:51 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:04:51 --> User Agent Class Initialized
INFO - 2018-03-21 23:04:51 --> Controller Class Initialized
INFO - 2018-03-21 23:04:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:04:51 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:04:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:04:51 --> Final output sent to browser
DEBUG - 2018-03-21 23:04:51 --> Total execution time: 0.2473
INFO - 2018-03-21 23:04:51 --> Config Class Initialized
INFO - 2018-03-21 23:04:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:51 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:51 --> URI Class Initialized
INFO - 2018-03-21 23:04:51 --> Router Class Initialized
INFO - 2018-03-21 23:04:51 --> Output Class Initialized
INFO - 2018-03-21 23:04:51 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:51 --> CSRF cookie sent
INFO - 2018-03-21 23:04:51 --> Input Class Initialized
INFO - 2018-03-21 23:04:51 --> Language Class Initialized
ERROR - 2018-03-21 23:04:51 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:04:51 --> Config Class Initialized
INFO - 2018-03-21 23:04:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:04:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:04:51 --> Utf8 Class Initialized
INFO - 2018-03-21 23:04:51 --> URI Class Initialized
INFO - 2018-03-21 23:04:51 --> Router Class Initialized
INFO - 2018-03-21 23:04:51 --> Output Class Initialized
INFO - 2018-03-21 23:04:51 --> Security Class Initialized
DEBUG - 2018-03-21 23:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:04:51 --> CSRF cookie sent
INFO - 2018-03-21 23:04:51 --> Input Class Initialized
INFO - 2018-03-21 23:04:51 --> Language Class Initialized
ERROR - 2018-03-21 23:04:51 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:05:16 --> Config Class Initialized
INFO - 2018-03-21 23:05:16 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:05:16 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:05:16 --> Utf8 Class Initialized
INFO - 2018-03-21 23:05:16 --> URI Class Initialized
INFO - 2018-03-21 23:05:16 --> Router Class Initialized
INFO - 2018-03-21 23:05:16 --> Output Class Initialized
INFO - 2018-03-21 23:05:16 --> Security Class Initialized
DEBUG - 2018-03-21 23:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:05:16 --> CSRF cookie sent
INFO - 2018-03-21 23:05:16 --> Input Class Initialized
INFO - 2018-03-21 23:05:16 --> Language Class Initialized
INFO - 2018-03-21 23:05:16 --> Loader Class Initialized
INFO - 2018-03-21 23:05:16 --> Helper loaded: url_helper
INFO - 2018-03-21 23:05:16 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:05:16 --> User Agent Class Initialized
INFO - 2018-03-21 23:05:16 --> Controller Class Initialized
INFO - 2018-03-21 23:05:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:05:16 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:05:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:05:16 --> Final output sent to browser
DEBUG - 2018-03-21 23:05:16 --> Total execution time: 0.3205
INFO - 2018-03-21 23:05:17 --> Config Class Initialized
INFO - 2018-03-21 23:05:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:05:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:05:17 --> Utf8 Class Initialized
INFO - 2018-03-21 23:05:17 --> URI Class Initialized
INFO - 2018-03-21 23:05:17 --> Router Class Initialized
INFO - 2018-03-21 23:05:17 --> Output Class Initialized
INFO - 2018-03-21 23:05:17 --> Security Class Initialized
DEBUG - 2018-03-21 23:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:05:17 --> CSRF cookie sent
INFO - 2018-03-21 23:05:17 --> Input Class Initialized
INFO - 2018-03-21 23:05:17 --> Language Class Initialized
ERROR - 2018-03-21 23:05:17 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:05:17 --> Config Class Initialized
INFO - 2018-03-21 23:05:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:05:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:05:17 --> Utf8 Class Initialized
INFO - 2018-03-21 23:05:17 --> URI Class Initialized
INFO - 2018-03-21 23:05:17 --> Router Class Initialized
INFO - 2018-03-21 23:05:17 --> Output Class Initialized
INFO - 2018-03-21 23:05:17 --> Security Class Initialized
DEBUG - 2018-03-21 23:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:05:17 --> CSRF cookie sent
INFO - 2018-03-21 23:05:17 --> Input Class Initialized
INFO - 2018-03-21 23:05:17 --> Language Class Initialized
ERROR - 2018-03-21 23:05:17 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:06:47 --> Config Class Initialized
INFO - 2018-03-21 23:06:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:06:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:06:48 --> Utf8 Class Initialized
INFO - 2018-03-21 23:06:48 --> URI Class Initialized
INFO - 2018-03-21 23:06:48 --> Router Class Initialized
INFO - 2018-03-21 23:06:48 --> Output Class Initialized
INFO - 2018-03-21 23:06:48 --> Security Class Initialized
DEBUG - 2018-03-21 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:06:48 --> CSRF cookie sent
INFO - 2018-03-21 23:06:48 --> Input Class Initialized
INFO - 2018-03-21 23:06:48 --> Language Class Initialized
INFO - 2018-03-21 23:06:48 --> Loader Class Initialized
INFO - 2018-03-21 23:06:48 --> Helper loaded: url_helper
INFO - 2018-03-21 23:06:48 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:06:48 --> User Agent Class Initialized
INFO - 2018-03-21 23:06:48 --> Controller Class Initialized
INFO - 2018-03-21 23:06:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:06:48 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:06:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:06:48 --> Final output sent to browser
DEBUG - 2018-03-21 23:06:48 --> Total execution time: 0.2446
INFO - 2018-03-21 23:06:48 --> Config Class Initialized
INFO - 2018-03-21 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:06:48 --> Utf8 Class Initialized
INFO - 2018-03-21 23:06:48 --> URI Class Initialized
INFO - 2018-03-21 23:06:48 --> Router Class Initialized
INFO - 2018-03-21 23:06:48 --> Output Class Initialized
INFO - 2018-03-21 23:06:48 --> Security Class Initialized
DEBUG - 2018-03-21 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:06:48 --> CSRF cookie sent
INFO - 2018-03-21 23:06:48 --> Input Class Initialized
INFO - 2018-03-21 23:06:48 --> Language Class Initialized
ERROR - 2018-03-21 23:06:48 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:06:48 --> Config Class Initialized
INFO - 2018-03-21 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:06:48 --> Utf8 Class Initialized
INFO - 2018-03-21 23:06:48 --> URI Class Initialized
INFO - 2018-03-21 23:06:48 --> Router Class Initialized
INFO - 2018-03-21 23:06:48 --> Output Class Initialized
INFO - 2018-03-21 23:06:48 --> Security Class Initialized
DEBUG - 2018-03-21 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:06:48 --> CSRF cookie sent
INFO - 2018-03-21 23:06:48 --> Input Class Initialized
INFO - 2018-03-21 23:06:48 --> Language Class Initialized
ERROR - 2018-03-21 23:06:48 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:08:37 --> Config Class Initialized
INFO - 2018-03-21 23:08:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:08:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:08:37 --> Utf8 Class Initialized
INFO - 2018-03-21 23:08:37 --> URI Class Initialized
INFO - 2018-03-21 23:08:37 --> Router Class Initialized
INFO - 2018-03-21 23:08:37 --> Output Class Initialized
INFO - 2018-03-21 23:08:37 --> Security Class Initialized
DEBUG - 2018-03-21 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:08:37 --> CSRF cookie sent
INFO - 2018-03-21 23:08:37 --> Input Class Initialized
INFO - 2018-03-21 23:08:37 --> Language Class Initialized
INFO - 2018-03-21 23:08:37 --> Loader Class Initialized
INFO - 2018-03-21 23:08:37 --> Helper loaded: url_helper
INFO - 2018-03-21 23:08:37 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:08:37 --> User Agent Class Initialized
INFO - 2018-03-21 23:08:37 --> Controller Class Initialized
INFO - 2018-03-21 23:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:08:37 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:08:37 --> Final output sent to browser
DEBUG - 2018-03-21 23:08:37 --> Total execution time: 0.2491
INFO - 2018-03-21 23:08:37 --> Config Class Initialized
INFO - 2018-03-21 23:08:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:08:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:08:37 --> Utf8 Class Initialized
INFO - 2018-03-21 23:08:37 --> URI Class Initialized
INFO - 2018-03-21 23:08:37 --> Router Class Initialized
INFO - 2018-03-21 23:08:37 --> Output Class Initialized
INFO - 2018-03-21 23:08:37 --> Security Class Initialized
DEBUG - 2018-03-21 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:08:37 --> CSRF cookie sent
INFO - 2018-03-21 23:08:37 --> Input Class Initialized
INFO - 2018-03-21 23:08:37 --> Language Class Initialized
ERROR - 2018-03-21 23:08:37 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:08:37 --> Config Class Initialized
INFO - 2018-03-21 23:08:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:08:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:08:37 --> Utf8 Class Initialized
INFO - 2018-03-21 23:08:37 --> URI Class Initialized
INFO - 2018-03-21 23:08:37 --> Router Class Initialized
INFO - 2018-03-21 23:08:38 --> Output Class Initialized
INFO - 2018-03-21 23:08:38 --> Security Class Initialized
DEBUG - 2018-03-21 23:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:08:38 --> CSRF cookie sent
INFO - 2018-03-21 23:08:38 --> Input Class Initialized
INFO - 2018-03-21 23:08:38 --> Language Class Initialized
ERROR - 2018-03-21 23:08:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:10:35 --> Config Class Initialized
INFO - 2018-03-21 23:10:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:10:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:10:35 --> Utf8 Class Initialized
INFO - 2018-03-21 23:10:35 --> URI Class Initialized
INFO - 2018-03-21 23:10:35 --> Router Class Initialized
INFO - 2018-03-21 23:10:35 --> Output Class Initialized
INFO - 2018-03-21 23:10:35 --> Security Class Initialized
DEBUG - 2018-03-21 23:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:10:35 --> CSRF cookie sent
INFO - 2018-03-21 23:10:35 --> Input Class Initialized
INFO - 2018-03-21 23:10:35 --> Language Class Initialized
INFO - 2018-03-21 23:10:35 --> Loader Class Initialized
INFO - 2018-03-21 23:10:35 --> Helper loaded: url_helper
INFO - 2018-03-21 23:10:35 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:10:35 --> User Agent Class Initialized
INFO - 2018-03-21 23:10:35 --> Controller Class Initialized
INFO - 2018-03-21 23:10:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:10:35 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:10:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:10:36 --> Final output sent to browser
DEBUG - 2018-03-21 23:10:36 --> Total execution time: 0.2538
INFO - 2018-03-21 23:10:36 --> Config Class Initialized
INFO - 2018-03-21 23:10:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:10:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:10:36 --> Utf8 Class Initialized
INFO - 2018-03-21 23:10:36 --> URI Class Initialized
INFO - 2018-03-21 23:10:36 --> Router Class Initialized
INFO - 2018-03-21 23:10:36 --> Output Class Initialized
INFO - 2018-03-21 23:10:36 --> Security Class Initialized
DEBUG - 2018-03-21 23:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:10:36 --> CSRF cookie sent
INFO - 2018-03-21 23:10:36 --> Input Class Initialized
INFO - 2018-03-21 23:10:36 --> Language Class Initialized
INFO - 2018-03-21 23:10:36 --> Config Class Initialized
INFO - 2018-03-21 23:10:36 --> Hooks Class Initialized
ERROR - 2018-03-21 23:10:36 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 23:10:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:10:36 --> Utf8 Class Initialized
INFO - 2018-03-21 23:10:36 --> URI Class Initialized
INFO - 2018-03-21 23:10:36 --> Router Class Initialized
INFO - 2018-03-21 23:10:36 --> Output Class Initialized
INFO - 2018-03-21 23:10:36 --> Security Class Initialized
DEBUG - 2018-03-21 23:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:10:36 --> CSRF cookie sent
INFO - 2018-03-21 23:10:36 --> Input Class Initialized
INFO - 2018-03-21 23:10:36 --> Language Class Initialized
ERROR - 2018-03-21 23:10:36 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:11:03 --> Config Class Initialized
INFO - 2018-03-21 23:11:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:03 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:03 --> URI Class Initialized
INFO - 2018-03-21 23:11:03 --> Router Class Initialized
INFO - 2018-03-21 23:11:03 --> Output Class Initialized
INFO - 2018-03-21 23:11:03 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:03 --> CSRF cookie sent
INFO - 2018-03-21 23:11:03 --> Input Class Initialized
INFO - 2018-03-21 23:11:03 --> Language Class Initialized
INFO - 2018-03-21 23:11:03 --> Loader Class Initialized
INFO - 2018-03-21 23:11:03 --> Helper loaded: url_helper
INFO - 2018-03-21 23:11:03 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:11:03 --> User Agent Class Initialized
INFO - 2018-03-21 23:11:03 --> Controller Class Initialized
INFO - 2018-03-21 23:11:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:11:03 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:11:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:11:03 --> Final output sent to browser
DEBUG - 2018-03-21 23:11:03 --> Total execution time: 0.2559
INFO - 2018-03-21 23:11:04 --> Config Class Initialized
INFO - 2018-03-21 23:11:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:04 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:04 --> URI Class Initialized
INFO - 2018-03-21 23:11:04 --> Router Class Initialized
INFO - 2018-03-21 23:11:04 --> Output Class Initialized
INFO - 2018-03-21 23:11:04 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:04 --> CSRF cookie sent
INFO - 2018-03-21 23:11:04 --> Input Class Initialized
INFO - 2018-03-21 23:11:04 --> Language Class Initialized
ERROR - 2018-03-21 23:11:04 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:11:04 --> Config Class Initialized
INFO - 2018-03-21 23:11:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:04 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:04 --> URI Class Initialized
INFO - 2018-03-21 23:11:04 --> Router Class Initialized
INFO - 2018-03-21 23:11:04 --> Output Class Initialized
INFO - 2018-03-21 23:11:04 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:04 --> CSRF cookie sent
INFO - 2018-03-21 23:11:04 --> Input Class Initialized
INFO - 2018-03-21 23:11:04 --> Language Class Initialized
ERROR - 2018-03-21 23:11:04 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:11:26 --> Config Class Initialized
INFO - 2018-03-21 23:11:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:26 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:26 --> URI Class Initialized
INFO - 2018-03-21 23:11:26 --> Router Class Initialized
INFO - 2018-03-21 23:11:26 --> Output Class Initialized
INFO - 2018-03-21 23:11:26 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:26 --> CSRF cookie sent
INFO - 2018-03-21 23:11:26 --> Input Class Initialized
INFO - 2018-03-21 23:11:26 --> Language Class Initialized
INFO - 2018-03-21 23:11:26 --> Loader Class Initialized
INFO - 2018-03-21 23:11:26 --> Helper loaded: url_helper
INFO - 2018-03-21 23:11:26 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:11:26 --> User Agent Class Initialized
INFO - 2018-03-21 23:11:26 --> Controller Class Initialized
INFO - 2018-03-21 23:11:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:11:26 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:11:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:11:26 --> Final output sent to browser
DEBUG - 2018-03-21 23:11:26 --> Total execution time: 0.2528
INFO - 2018-03-21 23:11:27 --> Config Class Initialized
INFO - 2018-03-21 23:11:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:27 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:27 --> URI Class Initialized
INFO - 2018-03-21 23:11:27 --> Router Class Initialized
INFO - 2018-03-21 23:11:27 --> Output Class Initialized
INFO - 2018-03-21 23:11:27 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:27 --> CSRF cookie sent
INFO - 2018-03-21 23:11:27 --> Input Class Initialized
INFO - 2018-03-21 23:11:27 --> Language Class Initialized
ERROR - 2018-03-21 23:11:27 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:11:27 --> Config Class Initialized
INFO - 2018-03-21 23:11:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:11:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:11:27 --> Utf8 Class Initialized
INFO - 2018-03-21 23:11:27 --> URI Class Initialized
INFO - 2018-03-21 23:11:27 --> Router Class Initialized
INFO - 2018-03-21 23:11:27 --> Output Class Initialized
INFO - 2018-03-21 23:11:27 --> Security Class Initialized
DEBUG - 2018-03-21 23:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:11:27 --> CSRF cookie sent
INFO - 2018-03-21 23:11:27 --> Input Class Initialized
INFO - 2018-03-21 23:11:27 --> Language Class Initialized
ERROR - 2018-03-21 23:11:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:12:03 --> Config Class Initialized
INFO - 2018-03-21 23:12:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:03 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:03 --> URI Class Initialized
INFO - 2018-03-21 23:12:03 --> Router Class Initialized
INFO - 2018-03-21 23:12:03 --> Output Class Initialized
INFO - 2018-03-21 23:12:03 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:03 --> CSRF cookie sent
INFO - 2018-03-21 23:12:03 --> Input Class Initialized
INFO - 2018-03-21 23:12:03 --> Language Class Initialized
INFO - 2018-03-21 23:12:03 --> Loader Class Initialized
INFO - 2018-03-21 23:12:03 --> Helper loaded: url_helper
INFO - 2018-03-21 23:12:03 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:12:03 --> User Agent Class Initialized
INFO - 2018-03-21 23:12:03 --> Controller Class Initialized
INFO - 2018-03-21 23:12:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:12:03 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:12:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:12:03 --> Final output sent to browser
DEBUG - 2018-03-21 23:12:03 --> Total execution time: 0.2518
INFO - 2018-03-21 23:12:03 --> Config Class Initialized
INFO - 2018-03-21 23:12:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:03 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:03 --> URI Class Initialized
INFO - 2018-03-21 23:12:03 --> Router Class Initialized
INFO - 2018-03-21 23:12:03 --> Output Class Initialized
INFO - 2018-03-21 23:12:03 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:03 --> CSRF cookie sent
INFO - 2018-03-21 23:12:03 --> Input Class Initialized
INFO - 2018-03-21 23:12:03 --> Language Class Initialized
ERROR - 2018-03-21 23:12:03 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:12:04 --> Config Class Initialized
INFO - 2018-03-21 23:12:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:04 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:04 --> URI Class Initialized
INFO - 2018-03-21 23:12:04 --> Router Class Initialized
INFO - 2018-03-21 23:12:04 --> Output Class Initialized
INFO - 2018-03-21 23:12:04 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:04 --> CSRF cookie sent
INFO - 2018-03-21 23:12:04 --> Input Class Initialized
INFO - 2018-03-21 23:12:04 --> Language Class Initialized
ERROR - 2018-03-21 23:12:04 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:12:50 --> Config Class Initialized
INFO - 2018-03-21 23:12:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:50 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:50 --> URI Class Initialized
INFO - 2018-03-21 23:12:50 --> Router Class Initialized
INFO - 2018-03-21 23:12:50 --> Output Class Initialized
INFO - 2018-03-21 23:12:50 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:50 --> CSRF cookie sent
INFO - 2018-03-21 23:12:50 --> Input Class Initialized
INFO - 2018-03-21 23:12:50 --> Language Class Initialized
INFO - 2018-03-21 23:12:50 --> Loader Class Initialized
INFO - 2018-03-21 23:12:50 --> Helper loaded: url_helper
INFO - 2018-03-21 23:12:50 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:12:50 --> User Agent Class Initialized
INFO - 2018-03-21 23:12:51 --> Controller Class Initialized
INFO - 2018-03-21 23:12:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:12:51 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:12:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:12:51 --> Final output sent to browser
DEBUG - 2018-03-21 23:12:51 --> Total execution time: 0.2672
INFO - 2018-03-21 23:12:51 --> Config Class Initialized
INFO - 2018-03-21 23:12:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:51 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:51 --> URI Class Initialized
INFO - 2018-03-21 23:12:51 --> Router Class Initialized
INFO - 2018-03-21 23:12:51 --> Output Class Initialized
INFO - 2018-03-21 23:12:51 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:51 --> CSRF cookie sent
INFO - 2018-03-21 23:12:51 --> Input Class Initialized
INFO - 2018-03-21 23:12:51 --> Language Class Initialized
ERROR - 2018-03-21 23:12:51 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:12:51 --> Config Class Initialized
INFO - 2018-03-21 23:12:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:12:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:12:51 --> Utf8 Class Initialized
INFO - 2018-03-21 23:12:51 --> URI Class Initialized
INFO - 2018-03-21 23:12:51 --> Router Class Initialized
INFO - 2018-03-21 23:12:51 --> Output Class Initialized
INFO - 2018-03-21 23:12:51 --> Security Class Initialized
DEBUG - 2018-03-21 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:12:51 --> CSRF cookie sent
INFO - 2018-03-21 23:12:51 --> Input Class Initialized
INFO - 2018-03-21 23:12:51 --> Language Class Initialized
ERROR - 2018-03-21 23:12:51 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:13:08 --> Config Class Initialized
INFO - 2018-03-21 23:13:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:08 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:08 --> URI Class Initialized
INFO - 2018-03-21 23:13:08 --> Router Class Initialized
INFO - 2018-03-21 23:13:08 --> Output Class Initialized
INFO - 2018-03-21 23:13:08 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:08 --> CSRF cookie sent
INFO - 2018-03-21 23:13:08 --> Input Class Initialized
INFO - 2018-03-21 23:13:08 --> Language Class Initialized
INFO - 2018-03-21 23:13:08 --> Loader Class Initialized
INFO - 2018-03-21 23:13:08 --> Helper loaded: url_helper
INFO - 2018-03-21 23:13:08 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:13:09 --> User Agent Class Initialized
INFO - 2018-03-21 23:13:09 --> Controller Class Initialized
INFO - 2018-03-21 23:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:13:09 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:13:09 --> Final output sent to browser
DEBUG - 2018-03-21 23:13:09 --> Total execution time: 0.2676
INFO - 2018-03-21 23:13:09 --> Config Class Initialized
INFO - 2018-03-21 23:13:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:09 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:09 --> URI Class Initialized
INFO - 2018-03-21 23:13:09 --> Router Class Initialized
INFO - 2018-03-21 23:13:09 --> Output Class Initialized
INFO - 2018-03-21 23:13:09 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:09 --> CSRF cookie sent
INFO - 2018-03-21 23:13:09 --> Input Class Initialized
INFO - 2018-03-21 23:13:09 --> Config Class Initialized
INFO - 2018-03-21 23:13:09 --> Hooks Class Initialized
INFO - 2018-03-21 23:13:09 --> Language Class Initialized
ERROR - 2018-03-21 23:13:09 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-21 23:13:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:09 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:09 --> URI Class Initialized
INFO - 2018-03-21 23:13:09 --> Router Class Initialized
INFO - 2018-03-21 23:13:09 --> Output Class Initialized
INFO - 2018-03-21 23:13:09 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:09 --> CSRF cookie sent
INFO - 2018-03-21 23:13:09 --> Input Class Initialized
INFO - 2018-03-21 23:13:09 --> Language Class Initialized
ERROR - 2018-03-21 23:13:09 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:13:27 --> Config Class Initialized
INFO - 2018-03-21 23:13:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:27 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:27 --> URI Class Initialized
INFO - 2018-03-21 23:13:27 --> Router Class Initialized
INFO - 2018-03-21 23:13:27 --> Output Class Initialized
INFO - 2018-03-21 23:13:27 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:27 --> CSRF cookie sent
INFO - 2018-03-21 23:13:27 --> Input Class Initialized
INFO - 2018-03-21 23:13:27 --> Language Class Initialized
INFO - 2018-03-21 23:13:27 --> Loader Class Initialized
INFO - 2018-03-21 23:13:27 --> Helper loaded: url_helper
INFO - 2018-03-21 23:13:27 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:13:27 --> User Agent Class Initialized
INFO - 2018-03-21 23:13:27 --> Controller Class Initialized
INFO - 2018-03-21 23:13:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:13:28 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:13:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:13:28 --> Final output sent to browser
DEBUG - 2018-03-21 23:13:28 --> Total execution time: 0.2583
INFO - 2018-03-21 23:13:28 --> Config Class Initialized
INFO - 2018-03-21 23:13:28 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:28 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:28 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:28 --> URI Class Initialized
INFO - 2018-03-21 23:13:28 --> Router Class Initialized
INFO - 2018-03-21 23:13:28 --> Output Class Initialized
INFO - 2018-03-21 23:13:28 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:28 --> CSRF cookie sent
INFO - 2018-03-21 23:13:28 --> Input Class Initialized
INFO - 2018-03-21 23:13:28 --> Language Class Initialized
ERROR - 2018-03-21 23:13:28 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:13:28 --> Config Class Initialized
INFO - 2018-03-21 23:13:28 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:28 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:28 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:28 --> URI Class Initialized
INFO - 2018-03-21 23:13:28 --> Router Class Initialized
INFO - 2018-03-21 23:13:28 --> Output Class Initialized
INFO - 2018-03-21 23:13:28 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:28 --> CSRF cookie sent
INFO - 2018-03-21 23:13:28 --> Input Class Initialized
INFO - 2018-03-21 23:13:28 --> Language Class Initialized
ERROR - 2018-03-21 23:13:28 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:13:44 --> Config Class Initialized
INFO - 2018-03-21 23:13:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:44 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:44 --> URI Class Initialized
INFO - 2018-03-21 23:13:44 --> Router Class Initialized
INFO - 2018-03-21 23:13:44 --> Output Class Initialized
INFO - 2018-03-21 23:13:44 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:44 --> CSRF cookie sent
INFO - 2018-03-21 23:13:44 --> Input Class Initialized
INFO - 2018-03-21 23:13:44 --> Language Class Initialized
INFO - 2018-03-21 23:13:44 --> Loader Class Initialized
INFO - 2018-03-21 23:13:44 --> Helper loaded: url_helper
INFO - 2018-03-21 23:13:44 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:13:44 --> User Agent Class Initialized
INFO - 2018-03-21 23:13:44 --> Controller Class Initialized
INFO - 2018-03-21 23:13:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:13:44 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:13:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:13:44 --> Final output sent to browser
DEBUG - 2018-03-21 23:13:44 --> Total execution time: 0.2549
INFO - 2018-03-21 23:13:45 --> Config Class Initialized
INFO - 2018-03-21 23:13:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:45 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:45 --> URI Class Initialized
INFO - 2018-03-21 23:13:45 --> Router Class Initialized
INFO - 2018-03-21 23:13:45 --> Output Class Initialized
INFO - 2018-03-21 23:13:45 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:45 --> CSRF cookie sent
INFO - 2018-03-21 23:13:45 --> Input Class Initialized
INFO - 2018-03-21 23:13:45 --> Language Class Initialized
ERROR - 2018-03-21 23:13:45 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:13:45 --> Config Class Initialized
INFO - 2018-03-21 23:13:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:45 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:45 --> URI Class Initialized
INFO - 2018-03-21 23:13:45 --> Router Class Initialized
INFO - 2018-03-21 23:13:45 --> Output Class Initialized
INFO - 2018-03-21 23:13:45 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:45 --> CSRF cookie sent
INFO - 2018-03-21 23:13:45 --> Input Class Initialized
INFO - 2018-03-21 23:13:45 --> Language Class Initialized
ERROR - 2018-03-21 23:13:45 --> 404 Page Not Found: Assets/css
INFO - 2018-03-21 23:13:51 --> Config Class Initialized
INFO - 2018-03-21 23:13:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:51 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:51 --> URI Class Initialized
INFO - 2018-03-21 23:13:51 --> Router Class Initialized
INFO - 2018-03-21 23:13:51 --> Output Class Initialized
INFO - 2018-03-21 23:13:51 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:51 --> CSRF cookie sent
INFO - 2018-03-21 23:13:51 --> Input Class Initialized
INFO - 2018-03-21 23:13:51 --> Language Class Initialized
INFO - 2018-03-21 23:13:51 --> Loader Class Initialized
INFO - 2018-03-21 23:13:52 --> Helper loaded: url_helper
INFO - 2018-03-21 23:13:52 --> Helper loaded: form_helper
DEBUG - 2018-03-21 23:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 23:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 23:13:52 --> User Agent Class Initialized
INFO - 2018-03-21 23:13:52 --> Controller Class Initialized
INFO - 2018-03-21 23:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-21 23:13:52 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-21 23:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-21 23:13:52 --> Final output sent to browser
DEBUG - 2018-03-21 23:13:52 --> Total execution time: 0.2548
INFO - 2018-03-21 23:13:52 --> Config Class Initialized
INFO - 2018-03-21 23:13:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:52 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:52 --> URI Class Initialized
INFO - 2018-03-21 23:13:52 --> Router Class Initialized
INFO - 2018-03-21 23:13:52 --> Output Class Initialized
INFO - 2018-03-21 23:13:52 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:52 --> CSRF cookie sent
INFO - 2018-03-21 23:13:52 --> Input Class Initialized
INFO - 2018-03-21 23:13:52 --> Language Class Initialized
ERROR - 2018-03-21 23:13:52 --> 404 Page Not Found: Assets/images
INFO - 2018-03-21 23:13:52 --> Config Class Initialized
INFO - 2018-03-21 23:13:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 23:13:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 23:13:52 --> Utf8 Class Initialized
INFO - 2018-03-21 23:13:52 --> URI Class Initialized
INFO - 2018-03-21 23:13:52 --> Router Class Initialized
INFO - 2018-03-21 23:13:52 --> Output Class Initialized
INFO - 2018-03-21 23:13:52 --> Security Class Initialized
DEBUG - 2018-03-21 23:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 23:13:52 --> CSRF cookie sent
INFO - 2018-03-21 23:13:52 --> Input Class Initialized
INFO - 2018-03-21 23:13:52 --> Language Class Initialized
ERROR - 2018-03-21 23:13:52 --> 404 Page Not Found: Assets/css

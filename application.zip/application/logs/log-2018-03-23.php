<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-23 17:58:43 --> Config Class Initialized
INFO - 2018-03-23 17:58:43 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:58:43 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:58:43 --> Utf8 Class Initialized
INFO - 2018-03-23 17:58:43 --> URI Class Initialized
INFO - 2018-03-23 17:58:43 --> Router Class Initialized
INFO - 2018-03-23 17:58:43 --> Output Class Initialized
INFO - 2018-03-23 17:58:43 --> Security Class Initialized
DEBUG - 2018-03-23 17:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:58:43 --> CSRF cookie sent
INFO - 2018-03-23 17:58:43 --> Input Class Initialized
INFO - 2018-03-23 17:58:43 --> Language Class Initialized
INFO - 2018-03-23 17:58:43 --> Loader Class Initialized
INFO - 2018-03-23 17:58:43 --> Helper loaded: url_helper
INFO - 2018-03-23 17:58:43 --> Helper loaded: form_helper
DEBUG - 2018-03-23 17:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 17:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 17:58:43 --> User Agent Class Initialized
INFO - 2018-03-23 17:58:43 --> Controller Class Initialized
INFO - 2018-03-23 17:58:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-23 17:58:43 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-23 17:58:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-23 17:58:43 --> Final output sent to browser
DEBUG - 2018-03-23 17:58:43 --> Total execution time: 0.6697
INFO - 2018-03-23 17:58:43 --> Config Class Initialized
INFO - 2018-03-23 17:58:43 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:58:43 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:58:43 --> Utf8 Class Initialized
INFO - 2018-03-23 17:58:43 --> URI Class Initialized
INFO - 2018-03-23 17:58:43 --> Router Class Initialized
INFO - 2018-03-23 17:58:43 --> Output Class Initialized
INFO - 2018-03-23 17:58:43 --> Security Class Initialized
DEBUG - 2018-03-23 17:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:58:44 --> CSRF cookie sent
INFO - 2018-03-23 17:58:44 --> Input Class Initialized
INFO - 2018-03-23 17:58:44 --> Language Class Initialized
ERROR - 2018-03-23 17:58:44 --> 404 Page Not Found: Assets/images
INFO - 2018-03-23 17:58:49 --> Config Class Initialized
INFO - 2018-03-23 17:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:58:49 --> Utf8 Class Initialized
INFO - 2018-03-23 17:58:49 --> URI Class Initialized
INFO - 2018-03-23 17:58:49 --> Router Class Initialized
INFO - 2018-03-23 17:58:49 --> Output Class Initialized
INFO - 2018-03-23 17:58:49 --> Security Class Initialized
DEBUG - 2018-03-23 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:58:49 --> CSRF cookie sent
INFO - 2018-03-23 17:58:49 --> Input Class Initialized
INFO - 2018-03-23 17:58:49 --> Language Class Initialized
INFO - 2018-03-23 17:58:49 --> Loader Class Initialized
INFO - 2018-03-23 17:58:49 --> Helper loaded: url_helper
INFO - 2018-03-23 17:58:49 --> Helper loaded: form_helper
DEBUG - 2018-03-23 17:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 17:58:49 --> User Agent Class Initialized
INFO - 2018-03-23 17:58:49 --> Controller Class Initialized
INFO - 2018-03-23 17:58:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-23 17:58:49 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-23 17:58:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-23 17:58:49 --> Final output sent to browser
DEBUG - 2018-03-23 17:58:49 --> Total execution time: 0.1906
INFO - 2018-03-23 17:58:49 --> Config Class Initialized
INFO - 2018-03-23 17:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:58:49 --> Utf8 Class Initialized
INFO - 2018-03-23 17:58:49 --> URI Class Initialized
INFO - 2018-03-23 17:58:49 --> Router Class Initialized
INFO - 2018-03-23 17:58:49 --> Output Class Initialized
INFO - 2018-03-23 17:58:49 --> Security Class Initialized
DEBUG - 2018-03-23 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:58:49 --> CSRF cookie sent
INFO - 2018-03-23 17:58:49 --> Input Class Initialized
INFO - 2018-03-23 17:58:49 --> Language Class Initialized
ERROR - 2018-03-23 17:58:49 --> 404 Page Not Found: Assets/images
INFO - 2018-03-23 17:58:56 --> Config Class Initialized
INFO - 2018-03-23 17:58:56 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:58:56 --> Utf8 Class Initialized
INFO - 2018-03-23 17:58:56 --> URI Class Initialized
INFO - 2018-03-23 17:58:56 --> Router Class Initialized
INFO - 2018-03-23 17:58:56 --> Output Class Initialized
INFO - 2018-03-23 17:58:56 --> Security Class Initialized
DEBUG - 2018-03-23 17:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:58:56 --> CSRF cookie sent
INFO - 2018-03-23 17:58:56 --> Input Class Initialized
INFO - 2018-03-23 17:58:56 --> Language Class Initialized
ERROR - 2018-03-23 17:58:56 --> 404 Page Not Found: Assets/css
INFO - 2018-03-23 17:59:38 --> Config Class Initialized
INFO - 2018-03-23 17:59:38 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:59:38 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:59:38 --> Utf8 Class Initialized
INFO - 2018-03-23 17:59:38 --> URI Class Initialized
INFO - 2018-03-23 17:59:38 --> Router Class Initialized
INFO - 2018-03-23 17:59:38 --> Output Class Initialized
INFO - 2018-03-23 17:59:38 --> Security Class Initialized
DEBUG - 2018-03-23 17:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:59:38 --> CSRF cookie sent
INFO - 2018-03-23 17:59:38 --> Input Class Initialized
INFO - 2018-03-23 17:59:38 --> Language Class Initialized
INFO - 2018-03-23 17:59:38 --> Loader Class Initialized
INFO - 2018-03-23 17:59:38 --> Helper loaded: url_helper
INFO - 2018-03-23 17:59:38 --> Helper loaded: form_helper
DEBUG - 2018-03-23 17:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 17:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 17:59:38 --> User Agent Class Initialized
INFO - 2018-03-23 17:59:38 --> Controller Class Initialized
INFO - 2018-03-23 17:59:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-23 17:59:38 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-23 17:59:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-23 17:59:38 --> Final output sent to browser
DEBUG - 2018-03-23 17:59:38 --> Total execution time: 0.1870
INFO - 2018-03-23 17:59:39 --> Config Class Initialized
INFO - 2018-03-23 17:59:39 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:59:39 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:59:39 --> Utf8 Class Initialized
INFO - 2018-03-23 17:59:39 --> URI Class Initialized
INFO - 2018-03-23 17:59:39 --> Router Class Initialized
INFO - 2018-03-23 17:59:39 --> Output Class Initialized
INFO - 2018-03-23 17:59:39 --> Security Class Initialized
DEBUG - 2018-03-23 17:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:59:39 --> CSRF cookie sent
INFO - 2018-03-23 17:59:39 --> Input Class Initialized
INFO - 2018-03-23 17:59:39 --> Language Class Initialized
ERROR - 2018-03-23 17:59:39 --> 404 Page Not Found: Assets/images
INFO - 2018-03-23 17:59:39 --> Config Class Initialized
INFO - 2018-03-23 17:59:39 --> Hooks Class Initialized
DEBUG - 2018-03-23 17:59:39 --> UTF-8 Support Enabled
INFO - 2018-03-23 17:59:39 --> Utf8 Class Initialized
INFO - 2018-03-23 17:59:39 --> URI Class Initialized
INFO - 2018-03-23 17:59:39 --> Router Class Initialized
INFO - 2018-03-23 17:59:39 --> Output Class Initialized
INFO - 2018-03-23 17:59:39 --> Security Class Initialized
DEBUG - 2018-03-23 17:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 17:59:39 --> CSRF cookie sent
INFO - 2018-03-23 17:59:39 --> Input Class Initialized
INFO - 2018-03-23 17:59:39 --> Language Class Initialized
ERROR - 2018-03-23 17:59:39 --> 404 Page Not Found: Assets/css
INFO - 2018-03-23 18:00:12 --> Config Class Initialized
INFO - 2018-03-23 18:00:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 18:00:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 18:00:12 --> Utf8 Class Initialized
INFO - 2018-03-23 18:00:12 --> URI Class Initialized
INFO - 2018-03-23 18:00:12 --> Router Class Initialized
INFO - 2018-03-23 18:00:12 --> Output Class Initialized
INFO - 2018-03-23 18:00:12 --> Security Class Initialized
DEBUG - 2018-03-23 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 18:00:12 --> CSRF cookie sent
INFO - 2018-03-23 18:00:12 --> Input Class Initialized
INFO - 2018-03-23 18:00:12 --> Language Class Initialized
INFO - 2018-03-23 18:00:12 --> Loader Class Initialized
INFO - 2018-03-23 18:00:12 --> Helper loaded: url_helper
INFO - 2018-03-23 18:00:12 --> Helper loaded: form_helper
DEBUG - 2018-03-23 18:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 18:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 18:00:12 --> User Agent Class Initialized
INFO - 2018-03-23 18:00:12 --> Controller Class Initialized
INFO - 2018-03-23 18:00:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-23 18:00:12 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-23 18:00:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-23 18:00:12 --> Final output sent to browser
DEBUG - 2018-03-23 18:00:12 --> Total execution time: 0.1958
INFO - 2018-03-23 18:00:12 --> Config Class Initialized
INFO - 2018-03-23 18:00:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 18:00:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 18:00:12 --> Utf8 Class Initialized
INFO - 2018-03-23 18:00:12 --> URI Class Initialized
INFO - 2018-03-23 18:00:12 --> Router Class Initialized
INFO - 2018-03-23 18:00:12 --> Output Class Initialized
INFO - 2018-03-23 18:00:12 --> Security Class Initialized
DEBUG - 2018-03-23 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 18:00:12 --> CSRF cookie sent
INFO - 2018-03-23 18:00:12 --> Input Class Initialized
INFO - 2018-03-23 18:00:12 --> Language Class Initialized
ERROR - 2018-03-23 18:00:12 --> 404 Page Not Found: Assets/images
INFO - 2018-03-23 18:00:12 --> Config Class Initialized
INFO - 2018-03-23 18:00:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 18:00:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 18:00:12 --> Utf8 Class Initialized
INFO - 2018-03-23 18:00:12 --> URI Class Initialized
INFO - 2018-03-23 18:00:12 --> Router Class Initialized
INFO - 2018-03-23 18:00:12 --> Output Class Initialized
INFO - 2018-03-23 18:00:12 --> Security Class Initialized
DEBUG - 2018-03-23 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 18:00:12 --> CSRF cookie sent
INFO - 2018-03-23 18:00:12 --> Input Class Initialized
INFO - 2018-03-23 18:00:12 --> Language Class Initialized
ERROR - 2018-03-23 18:00:12 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-29 16:10:09 --> Config Class Initialized
INFO - 2018-03-29 16:10:09 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:10:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:10:10 --> Utf8 Class Initialized
INFO - 2018-03-29 16:10:10 --> URI Class Initialized
INFO - 2018-03-29 16:10:10 --> Router Class Initialized
INFO - 2018-03-29 16:10:10 --> Output Class Initialized
INFO - 2018-03-29 16:10:10 --> Security Class Initialized
DEBUG - 2018-03-29 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:10:10 --> CSRF cookie sent
INFO - 2018-03-29 16:10:10 --> Input Class Initialized
INFO - 2018-03-29 16:10:10 --> Language Class Initialized
INFO - 2018-03-29 16:10:10 --> Loader Class Initialized
INFO - 2018-03-29 16:10:10 --> Helper loaded: url_helper
INFO - 2018-03-29 16:10:10 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:10:10 --> User Agent Class Initialized
INFO - 2018-03-29 16:10:10 --> Controller Class Initialized
INFO - 2018-03-29 16:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:10:10 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:10:10 --> Final output sent to browser
DEBUG - 2018-03-29 16:10:10 --> Total execution time: 0.6474
INFO - 2018-03-29 16:10:10 --> Config Class Initialized
INFO - 2018-03-29 16:10:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:10:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:10:10 --> Utf8 Class Initialized
INFO - 2018-03-29 16:10:10 --> URI Class Initialized
INFO - 2018-03-29 16:10:10 --> Router Class Initialized
INFO - 2018-03-29 16:10:10 --> Output Class Initialized
INFO - 2018-03-29 16:10:10 --> Security Class Initialized
DEBUG - 2018-03-29 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:10:10 --> CSRF cookie sent
INFO - 2018-03-29 16:10:10 --> Input Class Initialized
INFO - 2018-03-29 16:10:10 --> Language Class Initialized
ERROR - 2018-03-29 16:10:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:13:46 --> Config Class Initialized
INFO - 2018-03-29 16:13:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:13:46 --> Utf8 Class Initialized
INFO - 2018-03-29 16:13:46 --> URI Class Initialized
INFO - 2018-03-29 16:13:46 --> Router Class Initialized
INFO - 2018-03-29 16:13:46 --> Output Class Initialized
INFO - 2018-03-29 16:13:46 --> Security Class Initialized
DEBUG - 2018-03-29 16:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:13:46 --> CSRF cookie sent
INFO - 2018-03-29 16:13:46 --> Input Class Initialized
INFO - 2018-03-29 16:13:46 --> Language Class Initialized
INFO - 2018-03-29 16:13:46 --> Loader Class Initialized
INFO - 2018-03-29 16:13:46 --> Helper loaded: url_helper
INFO - 2018-03-29 16:13:47 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:13:47 --> User Agent Class Initialized
INFO - 2018-03-29 16:13:47 --> Controller Class Initialized
INFO - 2018-03-29 16:13:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:13:47 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:13:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:13:47 --> Final output sent to browser
DEBUG - 2018-03-29 16:13:47 --> Total execution time: 0.1969
INFO - 2018-03-29 16:13:47 --> Config Class Initialized
INFO - 2018-03-29 16:13:47 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:13:47 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:13:47 --> Utf8 Class Initialized
INFO - 2018-03-29 16:13:47 --> URI Class Initialized
INFO - 2018-03-29 16:13:47 --> Router Class Initialized
INFO - 2018-03-29 16:13:47 --> Output Class Initialized
INFO - 2018-03-29 16:13:47 --> Security Class Initialized
DEBUG - 2018-03-29 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:13:47 --> CSRF cookie sent
INFO - 2018-03-29 16:13:47 --> Input Class Initialized
INFO - 2018-03-29 16:13:47 --> Language Class Initialized
ERROR - 2018-03-29 16:13:47 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:13:50 --> Config Class Initialized
INFO - 2018-03-29 16:13:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:13:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:13:50 --> Utf8 Class Initialized
INFO - 2018-03-29 16:13:50 --> URI Class Initialized
INFO - 2018-03-29 16:13:50 --> Router Class Initialized
INFO - 2018-03-29 16:13:50 --> Output Class Initialized
INFO - 2018-03-29 16:13:50 --> Security Class Initialized
DEBUG - 2018-03-29 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:13:50 --> CSRF cookie sent
INFO - 2018-03-29 16:13:50 --> Input Class Initialized
INFO - 2018-03-29 16:13:50 --> Language Class Initialized
INFO - 2018-03-29 16:13:50 --> Loader Class Initialized
INFO - 2018-03-29 16:13:50 --> Helper loaded: url_helper
INFO - 2018-03-29 16:13:50 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:13:50 --> User Agent Class Initialized
INFO - 2018-03-29 16:13:50 --> Controller Class Initialized
INFO - 2018-03-29 16:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:13:50 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:13:50 --> Final output sent to browser
DEBUG - 2018-03-29 16:13:50 --> Total execution time: 0.2035
INFO - 2018-03-29 16:13:50 --> Config Class Initialized
INFO - 2018-03-29 16:13:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:13:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:13:50 --> Utf8 Class Initialized
INFO - 2018-03-29 16:13:50 --> URI Class Initialized
INFO - 2018-03-29 16:13:50 --> Router Class Initialized
INFO - 2018-03-29 16:13:50 --> Output Class Initialized
INFO - 2018-03-29 16:13:50 --> Security Class Initialized
DEBUG - 2018-03-29 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:13:50 --> CSRF cookie sent
INFO - 2018-03-29 16:13:50 --> Input Class Initialized
INFO - 2018-03-29 16:13:50 --> Language Class Initialized
ERROR - 2018-03-29 16:13:50 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:14:34 --> Config Class Initialized
INFO - 2018-03-29 16:14:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:14:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:14:34 --> Utf8 Class Initialized
INFO - 2018-03-29 16:14:35 --> URI Class Initialized
INFO - 2018-03-29 16:14:35 --> Router Class Initialized
INFO - 2018-03-29 16:14:35 --> Output Class Initialized
INFO - 2018-03-29 16:14:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:14:35 --> CSRF cookie sent
INFO - 2018-03-29 16:14:35 --> Input Class Initialized
INFO - 2018-03-29 16:14:35 --> Language Class Initialized
ERROR - 2018-03-29 16:14:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:15:02 --> Config Class Initialized
INFO - 2018-03-29 16:15:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:15:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:15:02 --> Utf8 Class Initialized
INFO - 2018-03-29 16:15:02 --> URI Class Initialized
INFO - 2018-03-29 16:15:02 --> Router Class Initialized
INFO - 2018-03-29 16:15:02 --> Output Class Initialized
INFO - 2018-03-29 16:15:02 --> Security Class Initialized
DEBUG - 2018-03-29 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:15:02 --> CSRF cookie sent
INFO - 2018-03-29 16:15:02 --> Input Class Initialized
INFO - 2018-03-29 16:15:02 --> Language Class Initialized
INFO - 2018-03-29 16:15:02 --> Loader Class Initialized
INFO - 2018-03-29 16:15:02 --> Helper loaded: url_helper
INFO - 2018-03-29 16:15:02 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:15:02 --> User Agent Class Initialized
INFO - 2018-03-29 16:15:02 --> Controller Class Initialized
INFO - 2018-03-29 16:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:15:02 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:15:02 --> Final output sent to browser
DEBUG - 2018-03-29 16:15:02 --> Total execution time: 0.2342
INFO - 2018-03-29 16:15:02 --> Config Class Initialized
INFO - 2018-03-29 16:15:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:15:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:15:02 --> Utf8 Class Initialized
INFO - 2018-03-29 16:15:02 --> URI Class Initialized
INFO - 2018-03-29 16:15:02 --> Router Class Initialized
INFO - 2018-03-29 16:15:02 --> Output Class Initialized
INFO - 2018-03-29 16:15:02 --> Security Class Initialized
DEBUG - 2018-03-29 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:15:02 --> CSRF cookie sent
INFO - 2018-03-29 16:15:02 --> Input Class Initialized
INFO - 2018-03-29 16:15:02 --> Language Class Initialized
ERROR - 2018-03-29 16:15:02 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:15:02 --> Config Class Initialized
INFO - 2018-03-29 16:15:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:15:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:15:02 --> Utf8 Class Initialized
INFO - 2018-03-29 16:15:02 --> URI Class Initialized
INFO - 2018-03-29 16:15:02 --> Router Class Initialized
INFO - 2018-03-29 16:15:02 --> Output Class Initialized
INFO - 2018-03-29 16:15:02 --> Security Class Initialized
DEBUG - 2018-03-29 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:15:02 --> CSRF cookie sent
INFO - 2018-03-29 16:15:02 --> Input Class Initialized
INFO - 2018-03-29 16:15:02 --> Language Class Initialized
ERROR - 2018-03-29 16:15:02 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:17:02 --> Config Class Initialized
INFO - 2018-03-29 16:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:02 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:02 --> URI Class Initialized
INFO - 2018-03-29 16:17:02 --> Router Class Initialized
INFO - 2018-03-29 16:17:02 --> Output Class Initialized
INFO - 2018-03-29 16:17:02 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:02 --> CSRF cookie sent
INFO - 2018-03-29 16:17:02 --> Input Class Initialized
INFO - 2018-03-29 16:17:02 --> Language Class Initialized
INFO - 2018-03-29 16:17:02 --> Loader Class Initialized
INFO - 2018-03-29 16:17:02 --> Helper loaded: url_helper
INFO - 2018-03-29 16:17:02 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:17:02 --> User Agent Class Initialized
INFO - 2018-03-29 16:17:02 --> Controller Class Initialized
INFO - 2018-03-29 16:17:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:17:02 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:17:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:17:02 --> Final output sent to browser
DEBUG - 2018-03-29 16:17:02 --> Total execution time: 0.2105
INFO - 2018-03-29 16:17:02 --> Config Class Initialized
INFO - 2018-03-29 16:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:02 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:02 --> URI Class Initialized
INFO - 2018-03-29 16:17:02 --> Router Class Initialized
INFO - 2018-03-29 16:17:02 --> Output Class Initialized
INFO - 2018-03-29 16:17:02 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:02 --> CSRF cookie sent
INFO - 2018-03-29 16:17:02 --> Input Class Initialized
INFO - 2018-03-29 16:17:02 --> Language Class Initialized
ERROR - 2018-03-29 16:17:02 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:17:03 --> Config Class Initialized
INFO - 2018-03-29 16:17:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:03 --> URI Class Initialized
INFO - 2018-03-29 16:17:03 --> Router Class Initialized
INFO - 2018-03-29 16:17:03 --> Output Class Initialized
INFO - 2018-03-29 16:17:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:03 --> CSRF cookie sent
INFO - 2018-03-29 16:17:03 --> Input Class Initialized
INFO - 2018-03-29 16:17:03 --> Language Class Initialized
ERROR - 2018-03-29 16:17:03 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:17:10 --> Config Class Initialized
INFO - 2018-03-29 16:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:10 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:10 --> URI Class Initialized
INFO - 2018-03-29 16:17:10 --> Router Class Initialized
INFO - 2018-03-29 16:17:10 --> Output Class Initialized
INFO - 2018-03-29 16:17:10 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:10 --> CSRF cookie sent
INFO - 2018-03-29 16:17:10 --> Input Class Initialized
INFO - 2018-03-29 16:17:10 --> Language Class Initialized
INFO - 2018-03-29 16:17:10 --> Loader Class Initialized
INFO - 2018-03-29 16:17:10 --> Helper loaded: url_helper
INFO - 2018-03-29 16:17:10 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:17:10 --> User Agent Class Initialized
INFO - 2018-03-29 16:17:10 --> Controller Class Initialized
INFO - 2018-03-29 16:17:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:17:10 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:17:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:17:10 --> Final output sent to browser
DEBUG - 2018-03-29 16:17:10 --> Total execution time: 0.2083
INFO - 2018-03-29 16:17:10 --> Config Class Initialized
INFO - 2018-03-29 16:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:10 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:10 --> URI Class Initialized
INFO - 2018-03-29 16:17:11 --> Router Class Initialized
INFO - 2018-03-29 16:17:11 --> Output Class Initialized
INFO - 2018-03-29 16:17:11 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:11 --> CSRF cookie sent
INFO - 2018-03-29 16:17:11 --> Input Class Initialized
INFO - 2018-03-29 16:17:11 --> Language Class Initialized
ERROR - 2018-03-29 16:17:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:17:11 --> Config Class Initialized
INFO - 2018-03-29 16:17:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:11 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:11 --> URI Class Initialized
INFO - 2018-03-29 16:17:11 --> Router Class Initialized
INFO - 2018-03-29 16:17:11 --> Output Class Initialized
INFO - 2018-03-29 16:17:11 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:11 --> CSRF cookie sent
INFO - 2018-03-29 16:17:11 --> Input Class Initialized
INFO - 2018-03-29 16:17:11 --> Language Class Initialized
ERROR - 2018-03-29 16:17:11 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:17:51 --> Config Class Initialized
INFO - 2018-03-29 16:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:51 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:51 --> URI Class Initialized
INFO - 2018-03-29 16:17:51 --> Router Class Initialized
INFO - 2018-03-29 16:17:51 --> Output Class Initialized
INFO - 2018-03-29 16:17:51 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:51 --> CSRF cookie sent
INFO - 2018-03-29 16:17:51 --> Input Class Initialized
INFO - 2018-03-29 16:17:51 --> Language Class Initialized
INFO - 2018-03-29 16:17:51 --> Loader Class Initialized
INFO - 2018-03-29 16:17:51 --> Helper loaded: url_helper
INFO - 2018-03-29 16:17:51 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:17:51 --> User Agent Class Initialized
INFO - 2018-03-29 16:17:51 --> Controller Class Initialized
INFO - 2018-03-29 16:17:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:17:51 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:17:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:17:51 --> Final output sent to browser
DEBUG - 2018-03-29 16:17:51 --> Total execution time: 0.2150
INFO - 2018-03-29 16:17:51 --> Config Class Initialized
INFO - 2018-03-29 16:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:51 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:51 --> URI Class Initialized
INFO - 2018-03-29 16:17:51 --> Router Class Initialized
INFO - 2018-03-29 16:17:51 --> Output Class Initialized
INFO - 2018-03-29 16:17:51 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:51 --> CSRF cookie sent
INFO - 2018-03-29 16:17:51 --> Input Class Initialized
INFO - 2018-03-29 16:17:51 --> Language Class Initialized
ERROR - 2018-03-29 16:17:51 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:17:51 --> Config Class Initialized
INFO - 2018-03-29 16:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:51 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:51 --> URI Class Initialized
INFO - 2018-03-29 16:17:51 --> Router Class Initialized
INFO - 2018-03-29 16:17:51 --> Output Class Initialized
INFO - 2018-03-29 16:17:51 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:51 --> CSRF cookie sent
INFO - 2018-03-29 16:17:51 --> Input Class Initialized
INFO - 2018-03-29 16:17:51 --> Language Class Initialized
ERROR - 2018-03-29 16:17:51 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:17:53 --> Config Class Initialized
INFO - 2018-03-29 16:17:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:53 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:53 --> URI Class Initialized
INFO - 2018-03-29 16:17:53 --> Router Class Initialized
INFO - 2018-03-29 16:17:53 --> Output Class Initialized
INFO - 2018-03-29 16:17:53 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:53 --> CSRF cookie sent
INFO - 2018-03-29 16:17:53 --> Input Class Initialized
INFO - 2018-03-29 16:17:53 --> Language Class Initialized
INFO - 2018-03-29 16:17:53 --> Loader Class Initialized
INFO - 2018-03-29 16:17:53 --> Helper loaded: url_helper
INFO - 2018-03-29 16:17:53 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:17:53 --> User Agent Class Initialized
INFO - 2018-03-29 16:17:53 --> Controller Class Initialized
INFO - 2018-03-29 16:17:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:17:53 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:17:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:17:53 --> Final output sent to browser
DEBUG - 2018-03-29 16:17:53 --> Total execution time: 0.2706
INFO - 2018-03-29 16:17:53 --> Config Class Initialized
INFO - 2018-03-29 16:17:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:53 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:53 --> URI Class Initialized
INFO - 2018-03-29 16:17:53 --> Router Class Initialized
INFO - 2018-03-29 16:17:53 --> Output Class Initialized
INFO - 2018-03-29 16:17:53 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:53 --> CSRF cookie sent
INFO - 2018-03-29 16:17:53 --> Input Class Initialized
INFO - 2018-03-29 16:17:53 --> Language Class Initialized
ERROR - 2018-03-29 16:17:53 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:17:53 --> Config Class Initialized
INFO - 2018-03-29 16:17:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:17:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:17:53 --> Utf8 Class Initialized
INFO - 2018-03-29 16:17:53 --> URI Class Initialized
INFO - 2018-03-29 16:17:54 --> Router Class Initialized
INFO - 2018-03-29 16:17:54 --> Output Class Initialized
INFO - 2018-03-29 16:17:54 --> Security Class Initialized
DEBUG - 2018-03-29 16:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:17:54 --> CSRF cookie sent
INFO - 2018-03-29 16:17:54 --> Input Class Initialized
INFO - 2018-03-29 16:17:54 --> Language Class Initialized
ERROR - 2018-03-29 16:17:54 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:19:23 --> Config Class Initialized
INFO - 2018-03-29 16:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:23 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:23 --> URI Class Initialized
INFO - 2018-03-29 16:19:23 --> Router Class Initialized
INFO - 2018-03-29 16:19:23 --> Output Class Initialized
INFO - 2018-03-29 16:19:23 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:23 --> CSRF cookie sent
INFO - 2018-03-29 16:19:23 --> Input Class Initialized
INFO - 2018-03-29 16:19:23 --> Language Class Initialized
INFO - 2018-03-29 16:19:23 --> Loader Class Initialized
INFO - 2018-03-29 16:19:23 --> Helper loaded: url_helper
INFO - 2018-03-29 16:19:23 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:19:23 --> User Agent Class Initialized
INFO - 2018-03-29 16:19:23 --> Controller Class Initialized
INFO - 2018-03-29 16:19:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:19:23 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:19:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:19:23 --> Final output sent to browser
DEBUG - 2018-03-29 16:19:23 --> Total execution time: 0.1991
INFO - 2018-03-29 16:19:23 --> Config Class Initialized
INFO - 2018-03-29 16:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:23 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:23 --> URI Class Initialized
INFO - 2018-03-29 16:19:23 --> Router Class Initialized
INFO - 2018-03-29 16:19:23 --> Output Class Initialized
INFO - 2018-03-29 16:19:23 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:23 --> CSRF cookie sent
INFO - 2018-03-29 16:19:23 --> Input Class Initialized
INFO - 2018-03-29 16:19:23 --> Language Class Initialized
ERROR - 2018-03-29 16:19:23 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:19:24 --> Config Class Initialized
INFO - 2018-03-29 16:19:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:24 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:24 --> URI Class Initialized
INFO - 2018-03-29 16:19:24 --> Router Class Initialized
INFO - 2018-03-29 16:19:24 --> Output Class Initialized
INFO - 2018-03-29 16:19:24 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:24 --> CSRF cookie sent
INFO - 2018-03-29 16:19:24 --> Input Class Initialized
INFO - 2018-03-29 16:19:24 --> Language Class Initialized
ERROR - 2018-03-29 16:19:24 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:19:44 --> Config Class Initialized
INFO - 2018-03-29 16:19:44 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:44 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:44 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:44 --> URI Class Initialized
INFO - 2018-03-29 16:19:44 --> Router Class Initialized
INFO - 2018-03-29 16:19:44 --> Output Class Initialized
INFO - 2018-03-29 16:19:44 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:44 --> CSRF cookie sent
INFO - 2018-03-29 16:19:44 --> Input Class Initialized
INFO - 2018-03-29 16:19:44 --> Language Class Initialized
INFO - 2018-03-29 16:19:45 --> Loader Class Initialized
INFO - 2018-03-29 16:19:45 --> Helper loaded: url_helper
INFO - 2018-03-29 16:19:45 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:19:45 --> User Agent Class Initialized
INFO - 2018-03-29 16:19:45 --> Controller Class Initialized
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:19:45 --> Final output sent to browser
DEBUG - 2018-03-29 16:19:45 --> Total execution time: 0.2073
INFO - 2018-03-29 16:19:45 --> Config Class Initialized
INFO - 2018-03-29 16:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:45 --> Config Class Initialized
INFO - 2018-03-29 16:19:45 --> Hooks Class Initialized
INFO - 2018-03-29 16:19:45 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:45 --> URI Class Initialized
DEBUG - 2018-03-29 16:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:45 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:45 --> Router Class Initialized
INFO - 2018-03-29 16:19:45 --> URI Class Initialized
INFO - 2018-03-29 16:19:45 --> Output Class Initialized
INFO - 2018-03-29 16:19:45 --> Security Class Initialized
INFO - 2018-03-29 16:19:45 --> Router Class Initialized
INFO - 2018-03-29 16:19:45 --> Output Class Initialized
DEBUG - 2018-03-29 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:45 --> CSRF cookie sent
INFO - 2018-03-29 16:19:45 --> Security Class Initialized
INFO - 2018-03-29 16:19:45 --> Input Class Initialized
DEBUG - 2018-03-29 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:45 --> CSRF cookie sent
INFO - 2018-03-29 16:19:45 --> Language Class Initialized
INFO - 2018-03-29 16:19:45 --> Input Class Initialized
ERROR - 2018-03-29 16:19:45 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:19:45 --> Language Class Initialized
INFO - 2018-03-29 16:19:45 --> Loader Class Initialized
INFO - 2018-03-29 16:19:45 --> Helper loaded: url_helper
INFO - 2018-03-29 16:19:45 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:19:45 --> User Agent Class Initialized
INFO - 2018-03-29 16:19:45 --> Controller Class Initialized
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:19:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:19:45 --> Config Class Initialized
INFO - 2018-03-29 16:19:45 --> Hooks Class Initialized
INFO - 2018-03-29 16:19:45 --> Final output sent to browser
DEBUG - 2018-03-29 16:19:45 --> Total execution time: 0.3165
DEBUG - 2018-03-29 16:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:45 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:45 --> URI Class Initialized
INFO - 2018-03-29 16:19:45 --> Router Class Initialized
INFO - 2018-03-29 16:19:45 --> Output Class Initialized
INFO - 2018-03-29 16:19:45 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:45 --> CSRF cookie sent
INFO - 2018-03-29 16:19:45 --> Input Class Initialized
INFO - 2018-03-29 16:19:45 --> Language Class Initialized
ERROR - 2018-03-29 16:19:45 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:19:45 --> Config Class Initialized
INFO - 2018-03-29 16:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:45 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:45 --> URI Class Initialized
INFO - 2018-03-29 16:19:45 --> Router Class Initialized
INFO - 2018-03-29 16:19:45 --> Output Class Initialized
INFO - 2018-03-29 16:19:45 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:45 --> CSRF cookie sent
INFO - 2018-03-29 16:19:45 --> Input Class Initialized
INFO - 2018-03-29 16:19:45 --> Language Class Initialized
ERROR - 2018-03-29 16:19:45 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:19:46 --> Config Class Initialized
INFO - 2018-03-29 16:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:19:46 --> Utf8 Class Initialized
INFO - 2018-03-29 16:19:46 --> URI Class Initialized
INFO - 2018-03-29 16:19:46 --> Router Class Initialized
INFO - 2018-03-29 16:19:46 --> Output Class Initialized
INFO - 2018-03-29 16:19:46 --> Security Class Initialized
DEBUG - 2018-03-29 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:19:46 --> CSRF cookie sent
INFO - 2018-03-29 16:19:46 --> Input Class Initialized
INFO - 2018-03-29 16:19:46 --> Language Class Initialized
ERROR - 2018-03-29 16:19:46 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:20:04 --> Config Class Initialized
INFO - 2018-03-29 16:20:04 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:04 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:04 --> URI Class Initialized
INFO - 2018-03-29 16:20:04 --> Router Class Initialized
INFO - 2018-03-29 16:20:04 --> Output Class Initialized
INFO - 2018-03-29 16:20:04 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:04 --> CSRF cookie sent
INFO - 2018-03-29 16:20:04 --> Input Class Initialized
INFO - 2018-03-29 16:20:04 --> Language Class Initialized
INFO - 2018-03-29 16:20:04 --> Loader Class Initialized
INFO - 2018-03-29 16:20:04 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:04 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:05 --> User Agent Class Initialized
INFO - 2018-03-29 16:20:05 --> Controller Class Initialized
INFO - 2018-03-29 16:20:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:20:05 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:20:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:20:05 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:05 --> Total execution time: 0.2044
INFO - 2018-03-29 16:20:05 --> Config Class Initialized
INFO - 2018-03-29 16:20:05 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:05 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:05 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:05 --> URI Class Initialized
INFO - 2018-03-29 16:20:05 --> Router Class Initialized
INFO - 2018-03-29 16:20:05 --> Output Class Initialized
INFO - 2018-03-29 16:20:05 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:05 --> CSRF cookie sent
INFO - 2018-03-29 16:20:05 --> Input Class Initialized
INFO - 2018-03-29 16:20:05 --> Language Class Initialized
ERROR - 2018-03-29 16:20:05 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:20:05 --> Config Class Initialized
INFO - 2018-03-29 16:20:05 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:05 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:05 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:05 --> URI Class Initialized
INFO - 2018-03-29 16:20:05 --> Router Class Initialized
INFO - 2018-03-29 16:20:05 --> Output Class Initialized
INFO - 2018-03-29 16:20:05 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:05 --> CSRF cookie sent
INFO - 2018-03-29 16:20:05 --> Input Class Initialized
INFO - 2018-03-29 16:20:05 --> Language Class Initialized
ERROR - 2018-03-29 16:20:05 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:20:18 --> Config Class Initialized
INFO - 2018-03-29 16:20:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:18 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:18 --> URI Class Initialized
INFO - 2018-03-29 16:20:18 --> Router Class Initialized
INFO - 2018-03-29 16:20:18 --> Output Class Initialized
INFO - 2018-03-29 16:20:18 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:18 --> CSRF cookie sent
INFO - 2018-03-29 16:20:18 --> Input Class Initialized
INFO - 2018-03-29 16:20:18 --> Language Class Initialized
INFO - 2018-03-29 16:20:18 --> Loader Class Initialized
INFO - 2018-03-29 16:20:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:18 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:18 --> User Agent Class Initialized
INFO - 2018-03-29 16:20:18 --> Controller Class Initialized
INFO - 2018-03-29 16:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:20:18 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:20:18 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:18 --> Total execution time: 0.2066
INFO - 2018-03-29 16:20:18 --> Config Class Initialized
INFO - 2018-03-29 16:20:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:18 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:18 --> URI Class Initialized
INFO - 2018-03-29 16:20:18 --> Router Class Initialized
INFO - 2018-03-29 16:20:18 --> Output Class Initialized
INFO - 2018-03-29 16:20:18 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:18 --> CSRF cookie sent
INFO - 2018-03-29 16:20:18 --> Input Class Initialized
INFO - 2018-03-29 16:20:18 --> Language Class Initialized
ERROR - 2018-03-29 16:20:18 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:20:19 --> Config Class Initialized
INFO - 2018-03-29 16:20:19 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:19 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:19 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:19 --> URI Class Initialized
INFO - 2018-03-29 16:20:19 --> Router Class Initialized
INFO - 2018-03-29 16:20:19 --> Output Class Initialized
INFO - 2018-03-29 16:20:19 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:19 --> CSRF cookie sent
INFO - 2018-03-29 16:20:19 --> Input Class Initialized
INFO - 2018-03-29 16:20:19 --> Language Class Initialized
ERROR - 2018-03-29 16:20:19 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:20:36 --> Config Class Initialized
INFO - 2018-03-29 16:20:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:36 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:36 --> URI Class Initialized
INFO - 2018-03-29 16:20:36 --> Router Class Initialized
INFO - 2018-03-29 16:20:36 --> Output Class Initialized
INFO - 2018-03-29 16:20:36 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:36 --> CSRF cookie sent
INFO - 2018-03-29 16:20:36 --> Input Class Initialized
INFO - 2018-03-29 16:20:36 --> Language Class Initialized
INFO - 2018-03-29 16:20:36 --> Loader Class Initialized
INFO - 2018-03-29 16:20:36 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:36 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:36 --> User Agent Class Initialized
INFO - 2018-03-29 16:20:36 --> Controller Class Initialized
INFO - 2018-03-29 16:20:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:20:36 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:20:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:20:36 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:36 --> Total execution time: 0.2073
INFO - 2018-03-29 16:20:36 --> Config Class Initialized
INFO - 2018-03-29 16:20:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:36 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:36 --> URI Class Initialized
INFO - 2018-03-29 16:20:36 --> Router Class Initialized
INFO - 2018-03-29 16:20:36 --> Output Class Initialized
INFO - 2018-03-29 16:20:36 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:36 --> CSRF cookie sent
INFO - 2018-03-29 16:20:36 --> Input Class Initialized
INFO - 2018-03-29 16:20:36 --> Language Class Initialized
ERROR - 2018-03-29 16:20:36 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:20:37 --> Config Class Initialized
INFO - 2018-03-29 16:20:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:20:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:20:37 --> Utf8 Class Initialized
INFO - 2018-03-29 16:20:37 --> URI Class Initialized
INFO - 2018-03-29 16:20:37 --> Router Class Initialized
INFO - 2018-03-29 16:20:37 --> Output Class Initialized
INFO - 2018-03-29 16:20:37 --> Security Class Initialized
DEBUG - 2018-03-29 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:20:37 --> CSRF cookie sent
INFO - 2018-03-29 16:20:37 --> Input Class Initialized
INFO - 2018-03-29 16:20:37 --> Language Class Initialized
ERROR - 2018-03-29 16:20:37 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:21:23 --> Config Class Initialized
INFO - 2018-03-29 16:21:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:21:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:21:23 --> Utf8 Class Initialized
INFO - 2018-03-29 16:21:23 --> URI Class Initialized
INFO - 2018-03-29 16:21:23 --> Router Class Initialized
INFO - 2018-03-29 16:21:23 --> Output Class Initialized
INFO - 2018-03-29 16:21:23 --> Security Class Initialized
DEBUG - 2018-03-29 16:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:21:23 --> CSRF cookie sent
INFO - 2018-03-29 16:21:24 --> Input Class Initialized
INFO - 2018-03-29 16:21:24 --> Language Class Initialized
INFO - 2018-03-29 16:21:24 --> Loader Class Initialized
INFO - 2018-03-29 16:21:24 --> Helper loaded: url_helper
INFO - 2018-03-29 16:21:24 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:21:24 --> User Agent Class Initialized
INFO - 2018-03-29 16:21:24 --> Controller Class Initialized
INFO - 2018-03-29 16:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:21:24 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:21:24 --> Final output sent to browser
DEBUG - 2018-03-29 16:21:24 --> Total execution time: 0.2084
INFO - 2018-03-29 16:21:24 --> Config Class Initialized
INFO - 2018-03-29 16:21:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:21:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:21:24 --> Utf8 Class Initialized
INFO - 2018-03-29 16:21:24 --> URI Class Initialized
INFO - 2018-03-29 16:21:24 --> Router Class Initialized
INFO - 2018-03-29 16:21:24 --> Output Class Initialized
INFO - 2018-03-29 16:21:24 --> Security Class Initialized
DEBUG - 2018-03-29 16:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:21:24 --> CSRF cookie sent
INFO - 2018-03-29 16:21:24 --> Input Class Initialized
INFO - 2018-03-29 16:21:24 --> Language Class Initialized
ERROR - 2018-03-29 16:21:24 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:21:24 --> Config Class Initialized
INFO - 2018-03-29 16:21:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:21:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:21:24 --> Utf8 Class Initialized
INFO - 2018-03-29 16:21:24 --> URI Class Initialized
INFO - 2018-03-29 16:21:24 --> Router Class Initialized
INFO - 2018-03-29 16:21:24 --> Output Class Initialized
INFO - 2018-03-29 16:21:24 --> Security Class Initialized
DEBUG - 2018-03-29 16:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:21:24 --> CSRF cookie sent
INFO - 2018-03-29 16:21:24 --> Input Class Initialized
INFO - 2018-03-29 16:21:24 --> Language Class Initialized
ERROR - 2018-03-29 16:21:24 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:22:34 --> Config Class Initialized
INFO - 2018-03-29 16:22:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:34 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:34 --> URI Class Initialized
INFO - 2018-03-29 16:22:34 --> Router Class Initialized
INFO - 2018-03-29 16:22:34 --> Output Class Initialized
INFO - 2018-03-29 16:22:34 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:34 --> CSRF cookie sent
INFO - 2018-03-29 16:22:34 --> Input Class Initialized
INFO - 2018-03-29 16:22:34 --> Language Class Initialized
INFO - 2018-03-29 16:22:34 --> Loader Class Initialized
INFO - 2018-03-29 16:22:34 --> Helper loaded: url_helper
INFO - 2018-03-29 16:22:34 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:22:34 --> User Agent Class Initialized
INFO - 2018-03-29 16:22:34 --> Controller Class Initialized
INFO - 2018-03-29 16:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:22:35 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:22:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:22:35 --> Final output sent to browser
DEBUG - 2018-03-29 16:22:35 --> Total execution time: 0.2086
INFO - 2018-03-29 16:22:35 --> Config Class Initialized
INFO - 2018-03-29 16:22:35 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:35 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:35 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:35 --> URI Class Initialized
INFO - 2018-03-29 16:22:35 --> Router Class Initialized
INFO - 2018-03-29 16:22:35 --> Output Class Initialized
INFO - 2018-03-29 16:22:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:35 --> CSRF cookie sent
INFO - 2018-03-29 16:22:35 --> Input Class Initialized
INFO - 2018-03-29 16:22:35 --> Language Class Initialized
ERROR - 2018-03-29 16:22:35 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:22:35 --> Config Class Initialized
INFO - 2018-03-29 16:22:35 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:35 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:35 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:35 --> URI Class Initialized
INFO - 2018-03-29 16:22:35 --> Router Class Initialized
INFO - 2018-03-29 16:22:35 --> Output Class Initialized
INFO - 2018-03-29 16:22:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:35 --> CSRF cookie sent
INFO - 2018-03-29 16:22:35 --> Input Class Initialized
INFO - 2018-03-29 16:22:35 --> Language Class Initialized
ERROR - 2018-03-29 16:22:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:22:37 --> Config Class Initialized
INFO - 2018-03-29 16:22:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:37 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:37 --> URI Class Initialized
INFO - 2018-03-29 16:22:37 --> Router Class Initialized
INFO - 2018-03-29 16:22:37 --> Output Class Initialized
INFO - 2018-03-29 16:22:37 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:37 --> CSRF cookie sent
INFO - 2018-03-29 16:22:37 --> Input Class Initialized
INFO - 2018-03-29 16:22:37 --> Language Class Initialized
INFO - 2018-03-29 16:22:37 --> Loader Class Initialized
INFO - 2018-03-29 16:22:37 --> Helper loaded: url_helper
INFO - 2018-03-29 16:22:37 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:22:37 --> User Agent Class Initialized
INFO - 2018-03-29 16:22:37 --> Controller Class Initialized
INFO - 2018-03-29 16:22:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:22:37 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:22:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:22:37 --> Final output sent to browser
DEBUG - 2018-03-29 16:22:37 --> Total execution time: 0.2332
INFO - 2018-03-29 16:22:37 --> Config Class Initialized
INFO - 2018-03-29 16:22:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:37 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:37 --> URI Class Initialized
INFO - 2018-03-29 16:22:37 --> Router Class Initialized
INFO - 2018-03-29 16:22:37 --> Output Class Initialized
INFO - 2018-03-29 16:22:37 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:37 --> CSRF cookie sent
INFO - 2018-03-29 16:22:37 --> Input Class Initialized
INFO - 2018-03-29 16:22:37 --> Language Class Initialized
INFO - 2018-03-29 16:22:37 --> Loader Class Initialized
INFO - 2018-03-29 16:22:37 --> Helper loaded: url_helper
INFO - 2018-03-29 16:22:37 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:22:37 --> User Agent Class Initialized
INFO - 2018-03-29 16:22:37 --> Controller Class Initialized
INFO - 2018-03-29 16:22:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:22:37 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:22:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:22:38 --> Final output sent to browser
DEBUG - 2018-03-29 16:22:38 --> Total execution time: 0.2082
INFO - 2018-03-29 16:22:38 --> Config Class Initialized
INFO - 2018-03-29 16:22:38 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:38 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:38 --> URI Class Initialized
INFO - 2018-03-29 16:22:38 --> Router Class Initialized
INFO - 2018-03-29 16:22:38 --> Output Class Initialized
INFO - 2018-03-29 16:22:38 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:38 --> CSRF cookie sent
INFO - 2018-03-29 16:22:38 --> Input Class Initialized
INFO - 2018-03-29 16:22:38 --> Language Class Initialized
ERROR - 2018-03-29 16:22:38 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:22:38 --> Config Class Initialized
INFO - 2018-03-29 16:22:38 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:22:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:22:38 --> Utf8 Class Initialized
INFO - 2018-03-29 16:22:38 --> URI Class Initialized
INFO - 2018-03-29 16:22:38 --> Router Class Initialized
INFO - 2018-03-29 16:22:38 --> Output Class Initialized
INFO - 2018-03-29 16:22:38 --> Security Class Initialized
DEBUG - 2018-03-29 16:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:22:38 --> CSRF cookie sent
INFO - 2018-03-29 16:22:38 --> Input Class Initialized
INFO - 2018-03-29 16:22:38 --> Language Class Initialized
ERROR - 2018-03-29 16:22:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:23:18 --> Config Class Initialized
INFO - 2018-03-29 16:23:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:18 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:18 --> URI Class Initialized
INFO - 2018-03-29 16:23:18 --> Router Class Initialized
INFO - 2018-03-29 16:23:18 --> Output Class Initialized
INFO - 2018-03-29 16:23:18 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:18 --> CSRF cookie sent
INFO - 2018-03-29 16:23:18 --> Input Class Initialized
INFO - 2018-03-29 16:23:18 --> Language Class Initialized
INFO - 2018-03-29 16:23:18 --> Loader Class Initialized
INFO - 2018-03-29 16:23:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:18 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:19 --> User Agent Class Initialized
INFO - 2018-03-29 16:23:19 --> Controller Class Initialized
INFO - 2018-03-29 16:23:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:23:19 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:23:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:23:19 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:19 --> Total execution time: 0.2084
INFO - 2018-03-29 16:23:19 --> Config Class Initialized
INFO - 2018-03-29 16:23:19 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:19 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:19 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:19 --> URI Class Initialized
INFO - 2018-03-29 16:23:19 --> Router Class Initialized
INFO - 2018-03-29 16:23:19 --> Output Class Initialized
INFO - 2018-03-29 16:23:19 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:19 --> CSRF cookie sent
INFO - 2018-03-29 16:23:19 --> Input Class Initialized
INFO - 2018-03-29 16:23:19 --> Language Class Initialized
ERROR - 2018-03-29 16:23:19 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:23:19 --> Config Class Initialized
INFO - 2018-03-29 16:23:19 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:19 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:19 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:19 --> URI Class Initialized
INFO - 2018-03-29 16:23:19 --> Router Class Initialized
INFO - 2018-03-29 16:23:19 --> Output Class Initialized
INFO - 2018-03-29 16:23:19 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:19 --> CSRF cookie sent
INFO - 2018-03-29 16:23:19 --> Input Class Initialized
INFO - 2018-03-29 16:23:19 --> Language Class Initialized
ERROR - 2018-03-29 16:23:19 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:23:34 --> Config Class Initialized
INFO - 2018-03-29 16:23:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:34 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:34 --> URI Class Initialized
INFO - 2018-03-29 16:23:34 --> Router Class Initialized
INFO - 2018-03-29 16:23:34 --> Output Class Initialized
INFO - 2018-03-29 16:23:34 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:34 --> CSRF cookie sent
INFO - 2018-03-29 16:23:34 --> Input Class Initialized
INFO - 2018-03-29 16:23:34 --> Language Class Initialized
INFO - 2018-03-29 16:23:34 --> Loader Class Initialized
INFO - 2018-03-29 16:23:34 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:34 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:34 --> User Agent Class Initialized
INFO - 2018-03-29 16:23:34 --> Controller Class Initialized
INFO - 2018-03-29 16:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:23:34 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:23:34 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:34 --> Total execution time: 0.2293
INFO - 2018-03-29 16:23:34 --> Config Class Initialized
INFO - 2018-03-29 16:23:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:34 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:34 --> URI Class Initialized
INFO - 2018-03-29 16:23:34 --> Router Class Initialized
INFO - 2018-03-29 16:23:34 --> Output Class Initialized
INFO - 2018-03-29 16:23:34 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:34 --> CSRF cookie sent
INFO - 2018-03-29 16:23:34 --> Input Class Initialized
INFO - 2018-03-29 16:23:34 --> Language Class Initialized
ERROR - 2018-03-29 16:23:34 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:23:35 --> Config Class Initialized
INFO - 2018-03-29 16:23:35 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:35 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:35 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:35 --> URI Class Initialized
INFO - 2018-03-29 16:23:35 --> Router Class Initialized
INFO - 2018-03-29 16:23:35 --> Output Class Initialized
INFO - 2018-03-29 16:23:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:35 --> CSRF cookie sent
INFO - 2018-03-29 16:23:35 --> Input Class Initialized
INFO - 2018-03-29 16:23:35 --> Language Class Initialized
ERROR - 2018-03-29 16:23:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:23:50 --> Config Class Initialized
INFO - 2018-03-29 16:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:50 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:50 --> URI Class Initialized
INFO - 2018-03-29 16:23:50 --> Router Class Initialized
INFO - 2018-03-29 16:23:50 --> Output Class Initialized
INFO - 2018-03-29 16:23:50 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:50 --> CSRF cookie sent
INFO - 2018-03-29 16:23:50 --> Input Class Initialized
INFO - 2018-03-29 16:23:50 --> Language Class Initialized
INFO - 2018-03-29 16:23:50 --> Loader Class Initialized
INFO - 2018-03-29 16:23:50 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:50 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:50 --> User Agent Class Initialized
INFO - 2018-03-29 16:23:50 --> Controller Class Initialized
INFO - 2018-03-29 16:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:23:50 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:23:50 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:50 --> Total execution time: 0.2287
INFO - 2018-03-29 16:23:50 --> Config Class Initialized
INFO - 2018-03-29 16:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:50 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:50 --> URI Class Initialized
INFO - 2018-03-29 16:23:50 --> Router Class Initialized
INFO - 2018-03-29 16:23:50 --> Output Class Initialized
INFO - 2018-03-29 16:23:50 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:50 --> CSRF cookie sent
INFO - 2018-03-29 16:23:50 --> Input Class Initialized
INFO - 2018-03-29 16:23:50 --> Language Class Initialized
ERROR - 2018-03-29 16:23:50 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:23:50 --> Config Class Initialized
INFO - 2018-03-29 16:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:23:50 --> Utf8 Class Initialized
INFO - 2018-03-29 16:23:50 --> URI Class Initialized
INFO - 2018-03-29 16:23:50 --> Router Class Initialized
INFO - 2018-03-29 16:23:50 --> Output Class Initialized
INFO - 2018-03-29 16:23:50 --> Security Class Initialized
DEBUG - 2018-03-29 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:50 --> CSRF cookie sent
INFO - 2018-03-29 16:23:50 --> Input Class Initialized
INFO - 2018-03-29 16:23:50 --> Language Class Initialized
ERROR - 2018-03-29 16:23:50 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:25:03 --> Config Class Initialized
INFO - 2018-03-29 16:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:03 --> URI Class Initialized
INFO - 2018-03-29 16:25:03 --> Router Class Initialized
INFO - 2018-03-29 16:25:03 --> Output Class Initialized
INFO - 2018-03-29 16:25:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:03 --> CSRF cookie sent
INFO - 2018-03-29 16:25:03 --> Input Class Initialized
INFO - 2018-03-29 16:25:03 --> Language Class Initialized
INFO - 2018-03-29 16:25:03 --> Loader Class Initialized
INFO - 2018-03-29 16:25:03 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:03 --> User Agent Class Initialized
INFO - 2018-03-29 16:25:03 --> Controller Class Initialized
INFO - 2018-03-29 16:25:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:25:03 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:25:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:25:03 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:03 --> Total execution time: 0.2099
INFO - 2018-03-29 16:25:03 --> Config Class Initialized
INFO - 2018-03-29 16:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:03 --> URI Class Initialized
INFO - 2018-03-29 16:25:03 --> Router Class Initialized
INFO - 2018-03-29 16:25:03 --> Output Class Initialized
INFO - 2018-03-29 16:25:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:03 --> CSRF cookie sent
INFO - 2018-03-29 16:25:03 --> Input Class Initialized
INFO - 2018-03-29 16:25:03 --> Language Class Initialized
ERROR - 2018-03-29 16:25:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:25:03 --> Config Class Initialized
INFO - 2018-03-29 16:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:03 --> URI Class Initialized
INFO - 2018-03-29 16:25:03 --> Router Class Initialized
INFO - 2018-03-29 16:25:03 --> Output Class Initialized
INFO - 2018-03-29 16:25:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:04 --> CSRF cookie sent
INFO - 2018-03-29 16:25:04 --> Input Class Initialized
INFO - 2018-03-29 16:25:04 --> Language Class Initialized
ERROR - 2018-03-29 16:25:04 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:25:58 --> Config Class Initialized
INFO - 2018-03-29 16:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:58 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:58 --> URI Class Initialized
INFO - 2018-03-29 16:25:58 --> Router Class Initialized
INFO - 2018-03-29 16:25:58 --> Output Class Initialized
INFO - 2018-03-29 16:25:58 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:58 --> CSRF cookie sent
INFO - 2018-03-29 16:25:58 --> Input Class Initialized
INFO - 2018-03-29 16:25:58 --> Language Class Initialized
INFO - 2018-03-29 16:25:58 --> Loader Class Initialized
INFO - 2018-03-29 16:25:58 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:58 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:58 --> User Agent Class Initialized
INFO - 2018-03-29 16:25:58 --> Controller Class Initialized
INFO - 2018-03-29 16:25:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:25:58 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:25:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:25:58 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:58 --> Total execution time: 0.2181
INFO - 2018-03-29 16:25:58 --> Config Class Initialized
INFO - 2018-03-29 16:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:58 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:58 --> URI Class Initialized
INFO - 2018-03-29 16:25:58 --> Router Class Initialized
INFO - 2018-03-29 16:25:58 --> Output Class Initialized
INFO - 2018-03-29 16:25:59 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:59 --> CSRF cookie sent
INFO - 2018-03-29 16:25:59 --> Input Class Initialized
INFO - 2018-03-29 16:25:59 --> Language Class Initialized
ERROR - 2018-03-29 16:25:59 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:25:59 --> Config Class Initialized
INFO - 2018-03-29 16:25:59 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:25:59 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:25:59 --> Utf8 Class Initialized
INFO - 2018-03-29 16:25:59 --> URI Class Initialized
INFO - 2018-03-29 16:25:59 --> Router Class Initialized
INFO - 2018-03-29 16:25:59 --> Output Class Initialized
INFO - 2018-03-29 16:25:59 --> Security Class Initialized
DEBUG - 2018-03-29 16:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:25:59 --> CSRF cookie sent
INFO - 2018-03-29 16:25:59 --> Input Class Initialized
INFO - 2018-03-29 16:25:59 --> Language Class Initialized
ERROR - 2018-03-29 16:25:59 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:26:55 --> Config Class Initialized
INFO - 2018-03-29 16:26:55 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:26:55 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:26:55 --> Utf8 Class Initialized
INFO - 2018-03-29 16:26:55 --> URI Class Initialized
INFO - 2018-03-29 16:26:55 --> Router Class Initialized
INFO - 2018-03-29 16:26:55 --> Output Class Initialized
INFO - 2018-03-29 16:26:55 --> Security Class Initialized
DEBUG - 2018-03-29 16:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:26:55 --> CSRF cookie sent
INFO - 2018-03-29 16:26:55 --> Input Class Initialized
INFO - 2018-03-29 16:26:55 --> Language Class Initialized
INFO - 2018-03-29 16:26:55 --> Loader Class Initialized
INFO - 2018-03-29 16:26:55 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:55 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:55 --> User Agent Class Initialized
INFO - 2018-03-29 16:26:55 --> Controller Class Initialized
INFO - 2018-03-29 16:26:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:26:56 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:26:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:26:56 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:56 --> Total execution time: 0.2125
INFO - 2018-03-29 16:26:56 --> Config Class Initialized
INFO - 2018-03-29 16:26:56 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:26:56 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:26:56 --> Utf8 Class Initialized
INFO - 2018-03-29 16:26:56 --> URI Class Initialized
INFO - 2018-03-29 16:26:56 --> Router Class Initialized
INFO - 2018-03-29 16:26:56 --> Output Class Initialized
INFO - 2018-03-29 16:26:56 --> Security Class Initialized
DEBUG - 2018-03-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:26:56 --> CSRF cookie sent
INFO - 2018-03-29 16:26:56 --> Input Class Initialized
INFO - 2018-03-29 16:26:56 --> Language Class Initialized
ERROR - 2018-03-29 16:26:56 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:26:56 --> Config Class Initialized
INFO - 2018-03-29 16:26:56 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:26:56 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:26:56 --> Utf8 Class Initialized
INFO - 2018-03-29 16:26:56 --> URI Class Initialized
INFO - 2018-03-29 16:26:56 --> Router Class Initialized
INFO - 2018-03-29 16:26:56 --> Output Class Initialized
INFO - 2018-03-29 16:26:56 --> Security Class Initialized
DEBUG - 2018-03-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:26:56 --> CSRF cookie sent
INFO - 2018-03-29 16:26:56 --> Input Class Initialized
INFO - 2018-03-29 16:26:56 --> Language Class Initialized
ERROR - 2018-03-29 16:26:56 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:28:35 --> Config Class Initialized
INFO - 2018-03-29 16:28:35 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:28:35 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:28:35 --> Utf8 Class Initialized
INFO - 2018-03-29 16:28:35 --> URI Class Initialized
INFO - 2018-03-29 16:28:35 --> Router Class Initialized
INFO - 2018-03-29 16:28:35 --> Output Class Initialized
INFO - 2018-03-29 16:28:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:28:35 --> CSRF cookie sent
INFO - 2018-03-29 16:28:35 --> Input Class Initialized
INFO - 2018-03-29 16:28:35 --> Language Class Initialized
INFO - 2018-03-29 16:28:35 --> Loader Class Initialized
INFO - 2018-03-29 16:28:35 --> Helper loaded: url_helper
INFO - 2018-03-29 16:28:35 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:28:35 --> User Agent Class Initialized
INFO - 2018-03-29 16:28:35 --> Controller Class Initialized
INFO - 2018-03-29 16:28:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:28:35 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:28:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:28:35 --> Final output sent to browser
DEBUG - 2018-03-29 16:28:35 --> Total execution time: 0.2138
INFO - 2018-03-29 16:28:35 --> Config Class Initialized
INFO - 2018-03-29 16:28:35 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:28:35 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:28:35 --> Utf8 Class Initialized
INFO - 2018-03-29 16:28:35 --> URI Class Initialized
INFO - 2018-03-29 16:28:35 --> Router Class Initialized
INFO - 2018-03-29 16:28:35 --> Output Class Initialized
INFO - 2018-03-29 16:28:35 --> Security Class Initialized
DEBUG - 2018-03-29 16:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:28:35 --> CSRF cookie sent
INFO - 2018-03-29 16:28:35 --> Input Class Initialized
INFO - 2018-03-29 16:28:35 --> Language Class Initialized
ERROR - 2018-03-29 16:28:35 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:28:36 --> Config Class Initialized
INFO - 2018-03-29 16:28:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:28:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:28:36 --> Utf8 Class Initialized
INFO - 2018-03-29 16:28:36 --> URI Class Initialized
INFO - 2018-03-29 16:28:36 --> Router Class Initialized
INFO - 2018-03-29 16:28:36 --> Output Class Initialized
INFO - 2018-03-29 16:28:36 --> Security Class Initialized
DEBUG - 2018-03-29 16:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:28:36 --> CSRF cookie sent
INFO - 2018-03-29 16:28:36 --> Input Class Initialized
INFO - 2018-03-29 16:28:36 --> Language Class Initialized
ERROR - 2018-03-29 16:28:36 --> 404 Page Not Found: Assets/css
INFO - 2018-03-29 16:31:02 --> Config Class Initialized
INFO - 2018-03-29 16:31:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:31:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:31:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:31:03 --> URI Class Initialized
INFO - 2018-03-29 16:31:03 --> Router Class Initialized
INFO - 2018-03-29 16:31:03 --> Output Class Initialized
INFO - 2018-03-29 16:31:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:31:03 --> CSRF cookie sent
INFO - 2018-03-29 16:31:03 --> Input Class Initialized
INFO - 2018-03-29 16:31:03 --> Language Class Initialized
INFO - 2018-03-29 16:31:03 --> Loader Class Initialized
INFO - 2018-03-29 16:31:03 --> Helper loaded: url_helper
INFO - 2018-03-29 16:31:03 --> Helper loaded: form_helper
DEBUG - 2018-03-29 16:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:31:03 --> User Agent Class Initialized
INFO - 2018-03-29 16:31:03 --> Controller Class Initialized
INFO - 2018-03-29 16:31:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-29 16:31:03 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-03-29 16:31:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-29 16:31:03 --> Final output sent to browser
DEBUG - 2018-03-29 16:31:03 --> Total execution time: 0.3915
INFO - 2018-03-29 16:31:03 --> Config Class Initialized
INFO - 2018-03-29 16:31:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:31:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:31:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:31:03 --> URI Class Initialized
INFO - 2018-03-29 16:31:03 --> Router Class Initialized
INFO - 2018-03-29 16:31:03 --> Output Class Initialized
INFO - 2018-03-29 16:31:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:31:03 --> CSRF cookie sent
INFO - 2018-03-29 16:31:03 --> Input Class Initialized
INFO - 2018-03-29 16:31:03 --> Language Class Initialized
ERROR - 2018-03-29 16:31:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-29 16:31:03 --> Config Class Initialized
INFO - 2018-03-29 16:31:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:31:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:31:03 --> Utf8 Class Initialized
INFO - 2018-03-29 16:31:03 --> URI Class Initialized
INFO - 2018-03-29 16:31:03 --> Router Class Initialized
INFO - 2018-03-29 16:31:03 --> Output Class Initialized
INFO - 2018-03-29 16:31:03 --> Security Class Initialized
DEBUG - 2018-03-29 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:31:03 --> CSRF cookie sent
INFO - 2018-03-29 16:31:03 --> Input Class Initialized
INFO - 2018-03-29 16:31:03 --> Language Class Initialized
ERROR - 2018-03-29 16:31:03 --> 404 Page Not Found: Assets/css

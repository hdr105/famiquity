<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-05 00:01:48 --> Config Class Initialized
INFO - 2018-04-05 00:01:48 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:01:48 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:01:48 --> Utf8 Class Initialized
INFO - 2018-04-05 00:01:48 --> URI Class Initialized
INFO - 2018-04-05 00:01:48 --> Router Class Initialized
INFO - 2018-04-05 00:01:48 --> Output Class Initialized
INFO - 2018-04-05 00:01:48 --> Security Class Initialized
DEBUG - 2018-04-05 00:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:01:48 --> CSRF cookie sent
INFO - 2018-04-05 00:01:48 --> Input Class Initialized
INFO - 2018-04-05 00:01:48 --> Language Class Initialized
INFO - 2018-04-05 00:01:48 --> Loader Class Initialized
INFO - 2018-04-05 00:01:48 --> Helper loaded: url_helper
INFO - 2018-04-05 00:01:48 --> Helper loaded: form_helper
DEBUG - 2018-04-05 00:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 00:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 00:01:48 --> User Agent Class Initialized
INFO - 2018-04-05 00:01:48 --> Controller Class Initialized
INFO - 2018-04-05 00:01:48 --> Pixel_Model class loaded
INFO - 2018-04-05 00:01:48 --> Database Driver Class Initialized
INFO - 2018-04-05 00:01:51 --> Model "QuestionsModel" initialized
ERROR - 2018-04-05 00:01:51 --> Severity: Notice --> Undefined variable: footerJs E:\www\yacopoo\application\controllers\QuestionnaireController.php 28
INFO - 2018-04-05 00:01:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-05 00:01:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-05 00:01:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-05 00:01:51 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-05 00:01:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-05 00:01:51 --> Final output sent to browser
DEBUG - 2018-04-05 00:01:51 --> Total execution time: 3.5390
INFO - 2018-04-05 00:01:52 --> Config Class Initialized
INFO - 2018-04-05 00:01:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:01:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:01:52 --> Utf8 Class Initialized
INFO - 2018-04-05 00:01:52 --> URI Class Initialized
INFO - 2018-04-05 00:01:52 --> Router Class Initialized
INFO - 2018-04-05 00:01:52 --> Output Class Initialized
INFO - 2018-04-05 00:01:52 --> Security Class Initialized
DEBUG - 2018-04-05 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:01:52 --> CSRF cookie sent
INFO - 2018-04-05 00:01:52 --> Input Class Initialized
INFO - 2018-04-05 00:01:52 --> Language Class Initialized
ERROR - 2018-04-05 00:01:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-05 00:01:52 --> Config Class Initialized
INFO - 2018-04-05 00:01:52 --> Config Class Initialized
INFO - 2018-04-05 00:01:52 --> Hooks Class Initialized
INFO - 2018-04-05 00:01:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:01:52 --> UTF-8 Support Enabled
DEBUG - 2018-04-05 00:01:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:01:52 --> Utf8 Class Initialized
INFO - 2018-04-05 00:01:52 --> Utf8 Class Initialized
INFO - 2018-04-05 00:01:52 --> URI Class Initialized
INFO - 2018-04-05 00:01:52 --> URI Class Initialized
INFO - 2018-04-05 00:01:52 --> Router Class Initialized
INFO - 2018-04-05 00:01:52 --> Router Class Initialized
INFO - 2018-04-05 00:01:52 --> Output Class Initialized
INFO - 2018-04-05 00:01:52 --> Output Class Initialized
INFO - 2018-04-05 00:01:52 --> Security Class Initialized
INFO - 2018-04-05 00:01:52 --> Security Class Initialized
DEBUG - 2018-04-05 00:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-05 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:01:52 --> CSRF cookie sent
INFO - 2018-04-05 00:01:52 --> CSRF cookie sent
INFO - 2018-04-05 00:01:53 --> Input Class Initialized
INFO - 2018-04-05 00:01:53 --> Input Class Initialized
INFO - 2018-04-05 00:01:53 --> Language Class Initialized
INFO - 2018-04-05 00:01:53 --> Language Class Initialized
ERROR - 2018-04-05 00:01:53 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-05 00:01:53 --> 404 Page Not Found: Assets/js
INFO - 2018-04-05 00:02:36 --> Config Class Initialized
INFO - 2018-04-05 00:02:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:02:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:02:36 --> Utf8 Class Initialized
INFO - 2018-04-05 00:02:36 --> URI Class Initialized
INFO - 2018-04-05 00:02:36 --> Router Class Initialized
INFO - 2018-04-05 00:02:36 --> Output Class Initialized
INFO - 2018-04-05 00:02:36 --> Security Class Initialized
DEBUG - 2018-04-05 00:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:02:37 --> CSRF cookie sent
INFO - 2018-04-05 00:02:37 --> Input Class Initialized
INFO - 2018-04-05 00:02:37 --> Language Class Initialized
INFO - 2018-04-05 00:02:37 --> Loader Class Initialized
INFO - 2018-04-05 00:02:37 --> Helper loaded: url_helper
INFO - 2018-04-05 00:02:37 --> Helper loaded: form_helper
DEBUG - 2018-04-05 00:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 00:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 00:02:37 --> User Agent Class Initialized
INFO - 2018-04-05 00:02:37 --> Controller Class Initialized
INFO - 2018-04-05 00:02:37 --> Pixel_Model class loaded
INFO - 2018-04-05 00:02:37 --> Database Driver Class Initialized
INFO - 2018-04-05 00:02:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-05 00:02:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-05 00:02:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-05 00:02:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-05 00:02:37 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-05 00:02:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-05 00:02:37 --> Final output sent to browser
DEBUG - 2018-04-05 00:02:37 --> Total execution time: 0.5389
INFO - 2018-04-05 00:02:37 --> Config Class Initialized
INFO - 2018-04-05 00:02:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:02:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:02:37 --> Utf8 Class Initialized
INFO - 2018-04-05 00:02:37 --> URI Class Initialized
INFO - 2018-04-05 00:02:37 --> Router Class Initialized
INFO - 2018-04-05 00:02:37 --> Output Class Initialized
INFO - 2018-04-05 00:02:37 --> Security Class Initialized
DEBUG - 2018-04-05 00:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:02:37 --> CSRF cookie sent
INFO - 2018-04-05 00:02:37 --> Input Class Initialized
INFO - 2018-04-05 00:02:38 --> Language Class Initialized
ERROR - 2018-04-05 00:02:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-05 00:02:38 --> Config Class Initialized
INFO - 2018-04-05 00:02:38 --> Config Class Initialized
INFO - 2018-04-05 00:02:38 --> Hooks Class Initialized
INFO - 2018-04-05 00:02:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:02:38 --> UTF-8 Support Enabled
DEBUG - 2018-04-05 00:02:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:02:38 --> Utf8 Class Initialized
INFO - 2018-04-05 00:02:38 --> Utf8 Class Initialized
INFO - 2018-04-05 00:02:38 --> URI Class Initialized
INFO - 2018-04-05 00:02:38 --> URI Class Initialized
INFO - 2018-04-05 00:02:38 --> Router Class Initialized
INFO - 2018-04-05 00:02:38 --> Output Class Initialized
INFO - 2018-04-05 00:02:38 --> Router Class Initialized
INFO - 2018-04-05 00:02:38 --> Security Class Initialized
INFO - 2018-04-05 00:02:38 --> Output Class Initialized
DEBUG - 2018-04-05 00:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:02:38 --> CSRF cookie sent
INFO - 2018-04-05 00:02:38 --> Security Class Initialized
INFO - 2018-04-05 00:02:38 --> Input Class Initialized
DEBUG - 2018-04-05 00:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:02:38 --> CSRF cookie sent
INFO - 2018-04-05 00:02:38 --> Language Class Initialized
INFO - 2018-04-05 00:02:38 --> Input Class Initialized
ERROR - 2018-04-05 00:02:38 --> 404 Page Not Found: Assets/js
INFO - 2018-04-05 00:02:38 --> Language Class Initialized
ERROR - 2018-04-05 00:02:38 --> 404 Page Not Found: Assets/js
INFO - 2018-04-05 00:04:22 --> Config Class Initialized
INFO - 2018-04-05 00:04:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:22 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:22 --> URI Class Initialized
INFO - 2018-04-05 00:04:22 --> Router Class Initialized
INFO - 2018-04-05 00:04:22 --> Output Class Initialized
INFO - 2018-04-05 00:04:22 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:22 --> CSRF cookie sent
INFO - 2018-04-05 00:04:22 --> Input Class Initialized
INFO - 2018-04-05 00:04:22 --> Language Class Initialized
INFO - 2018-04-05 00:04:22 --> Loader Class Initialized
INFO - 2018-04-05 00:04:22 --> Helper loaded: url_helper
INFO - 2018-04-05 00:04:22 --> Helper loaded: form_helper
DEBUG - 2018-04-05 00:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 00:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 00:04:22 --> User Agent Class Initialized
INFO - 2018-04-05 00:04:22 --> Controller Class Initialized
INFO - 2018-04-05 00:04:22 --> Pixel_Model class loaded
INFO - 2018-04-05 00:04:22 --> Database Driver Class Initialized
INFO - 2018-04-05 00:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-05 00:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-05 00:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-05 00:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-05 00:04:25 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-05 00:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-05 00:04:25 --> Final output sent to browser
DEBUG - 2018-04-05 00:04:25 --> Total execution time: 3.3064
INFO - 2018-04-05 00:04:26 --> Config Class Initialized
INFO - 2018-04-05 00:04:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:26 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:26 --> URI Class Initialized
INFO - 2018-04-05 00:04:26 --> Router Class Initialized
INFO - 2018-04-05 00:04:26 --> Output Class Initialized
INFO - 2018-04-05 00:04:26 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:26 --> CSRF cookie sent
INFO - 2018-04-05 00:04:26 --> Input Class Initialized
INFO - 2018-04-05 00:04:26 --> Language Class Initialized
ERROR - 2018-04-05 00:04:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-05 00:04:26 --> Config Class Initialized
INFO - 2018-04-05 00:04:26 --> Config Class Initialized
INFO - 2018-04-05 00:04:26 --> Hooks Class Initialized
INFO - 2018-04-05 00:04:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:26 --> UTF-8 Support Enabled
DEBUG - 2018-04-05 00:04:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:26 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:26 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:26 --> URI Class Initialized
INFO - 2018-04-05 00:04:26 --> URI Class Initialized
INFO - 2018-04-05 00:04:26 --> Router Class Initialized
INFO - 2018-04-05 00:04:26 --> Router Class Initialized
INFO - 2018-04-05 00:04:26 --> Output Class Initialized
INFO - 2018-04-05 00:04:26 --> Output Class Initialized
INFO - 2018-04-05 00:04:26 --> Security Class Initialized
INFO - 2018-04-05 00:04:26 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:26 --> CSRF cookie sent
DEBUG - 2018-04-05 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:26 --> CSRF cookie sent
INFO - 2018-04-05 00:04:26 --> Input Class Initialized
INFO - 2018-04-05 00:04:26 --> Input Class Initialized
INFO - 2018-04-05 00:04:26 --> Language Class Initialized
INFO - 2018-04-05 00:04:26 --> Language Class Initialized
ERROR - 2018-04-05 00:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-05 00:04:26 --> 404 Page Not Found: Assets/js
INFO - 2018-04-05 00:04:44 --> Config Class Initialized
INFO - 2018-04-05 00:04:44 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:44 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:44 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:44 --> URI Class Initialized
INFO - 2018-04-05 00:04:44 --> Router Class Initialized
INFO - 2018-04-05 00:04:44 --> Output Class Initialized
INFO - 2018-04-05 00:04:44 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:44 --> CSRF cookie sent
INFO - 2018-04-05 00:04:44 --> Input Class Initialized
INFO - 2018-04-05 00:04:44 --> Language Class Initialized
INFO - 2018-04-05 00:04:44 --> Loader Class Initialized
INFO - 2018-04-05 00:04:44 --> Helper loaded: url_helper
INFO - 2018-04-05 00:04:44 --> Helper loaded: form_helper
DEBUG - 2018-04-05 00:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 00:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 00:04:44 --> User Agent Class Initialized
INFO - 2018-04-05 00:04:44 --> Controller Class Initialized
INFO - 2018-04-05 00:04:44 --> Pixel_Model class loaded
INFO - 2018-04-05 00:04:44 --> Database Driver Class Initialized
INFO - 2018-04-05 00:04:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-05 00:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-05 00:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-05 00:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-05 00:04:44 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-05 00:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-05 00:04:44 --> Final output sent to browser
DEBUG - 2018-04-05 00:04:44 --> Total execution time: 0.3191
INFO - 2018-04-05 00:04:44 --> Config Class Initialized
INFO - 2018-04-05 00:04:44 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:44 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:44 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:44 --> URI Class Initialized
INFO - 2018-04-05 00:04:44 --> Router Class Initialized
INFO - 2018-04-05 00:04:44 --> Output Class Initialized
INFO - 2018-04-05 00:04:44 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:45 --> CSRF cookie sent
INFO - 2018-04-05 00:04:45 --> Input Class Initialized
INFO - 2018-04-05 00:04:45 --> Language Class Initialized
ERROR - 2018-04-05 00:04:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-05 00:04:45 --> Config Class Initialized
INFO - 2018-04-05 00:04:45 --> Config Class Initialized
INFO - 2018-04-05 00:04:45 --> Hooks Class Initialized
INFO - 2018-04-05 00:04:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 00:04:45 --> UTF-8 Support Enabled
DEBUG - 2018-04-05 00:04:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 00:04:45 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:45 --> Utf8 Class Initialized
INFO - 2018-04-05 00:04:45 --> URI Class Initialized
INFO - 2018-04-05 00:04:45 --> URI Class Initialized
INFO - 2018-04-05 00:04:45 --> Router Class Initialized
INFO - 2018-04-05 00:04:45 --> Output Class Initialized
INFO - 2018-04-05 00:04:45 --> Router Class Initialized
INFO - 2018-04-05 00:04:45 --> Security Class Initialized
INFO - 2018-04-05 00:04:45 --> Output Class Initialized
INFO - 2018-04-05 00:04:45 --> Security Class Initialized
DEBUG - 2018-04-05 00:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:45 --> CSRF cookie sent
DEBUG - 2018-04-05 00:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 00:04:45 --> Input Class Initialized
INFO - 2018-04-05 00:04:45 --> CSRF cookie sent
INFO - 2018-04-05 00:04:45 --> Input Class Initialized
INFO - 2018-04-05 00:04:45 --> Language Class Initialized
INFO - 2018-04-05 00:04:45 --> Language Class Initialized
ERROR - 2018-04-05 00:04:45 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-05 00:04:45 --> 404 Page Not Found: Assets/js

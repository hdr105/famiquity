<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-13 00:00:01 --> Config Class Initialized
INFO - 2018-04-13 00:00:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:00:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:00:01 --> Utf8 Class Initialized
INFO - 2018-04-13 00:00:01 --> URI Class Initialized
INFO - 2018-04-13 00:00:01 --> Router Class Initialized
INFO - 2018-04-13 00:00:01 --> Output Class Initialized
INFO - 2018-04-13 00:00:01 --> Security Class Initialized
DEBUG - 2018-04-13 00:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:00:01 --> CSRF cookie sent
INFO - 2018-04-13 00:00:01 --> CSRF token verified
INFO - 2018-04-13 00:00:01 --> Input Class Initialized
INFO - 2018-04-13 00:00:01 --> Language Class Initialized
INFO - 2018-04-13 00:00:01 --> Loader Class Initialized
INFO - 2018-04-13 00:00:01 --> Helper loaded: url_helper
INFO - 2018-04-13 00:00:01 --> Helper loaded: form_helper
INFO - 2018-04-13 00:00:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:00:01 --> User Agent Class Initialized
INFO - 2018-04-13 00:00:01 --> Controller Class Initialized
INFO - 2018-04-13 00:00:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:00:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:00:01 --> Pixel_Model class loaded
INFO - 2018-04-13 00:00:01 --> Database Driver Class Initialized
INFO - 2018-04-13 00:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:00:01 --> Form Validation Class Initialized
INFO - 2018-04-13 00:00:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 00:00:02 --> Config Class Initialized
INFO - 2018-04-13 00:00:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:00:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:00:02 --> Utf8 Class Initialized
INFO - 2018-04-13 00:00:02 --> URI Class Initialized
INFO - 2018-04-13 00:00:02 --> Router Class Initialized
INFO - 2018-04-13 00:00:02 --> Output Class Initialized
INFO - 2018-04-13 00:00:02 --> Security Class Initialized
DEBUG - 2018-04-13 00:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:00:02 --> CSRF cookie sent
INFO - 2018-04-13 00:00:02 --> Input Class Initialized
INFO - 2018-04-13 00:00:02 --> Language Class Initialized
INFO - 2018-04-13 00:00:02 --> Loader Class Initialized
INFO - 2018-04-13 00:00:02 --> Helper loaded: url_helper
INFO - 2018-04-13 00:00:02 --> Helper loaded: form_helper
INFO - 2018-04-13 00:00:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:00:02 --> User Agent Class Initialized
INFO - 2018-04-13 00:00:02 --> Controller Class Initialized
INFO - 2018-04-13 00:00:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:00:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:00:02 --> Pixel_Model class loaded
INFO - 2018-04-13 00:00:02 --> Database Driver Class Initialized
INFO - 2018-04-13 00:00:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:00:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:00:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 00:00:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 00:00:02 --> File loaded: E:\www\yacopoo\application\views\questions/financial.php
INFO - 2018-04-13 00:00:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:00:02 --> Final output sent to browser
DEBUG - 2018-04-13 00:00:02 --> Total execution time: 0.5158
INFO - 2018-04-13 00:00:05 --> Config Class Initialized
INFO - 2018-04-13 00:00:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:00:05 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:00:05 --> Utf8 Class Initialized
INFO - 2018-04-13 00:00:05 --> URI Class Initialized
INFO - 2018-04-13 00:00:05 --> Router Class Initialized
INFO - 2018-04-13 00:00:05 --> Output Class Initialized
INFO - 2018-04-13 00:00:05 --> Security Class Initialized
DEBUG - 2018-04-13 00:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:00:05 --> CSRF cookie sent
INFO - 2018-04-13 00:00:05 --> Input Class Initialized
INFO - 2018-04-13 00:00:05 --> Language Class Initialized
INFO - 2018-04-13 00:00:05 --> Loader Class Initialized
INFO - 2018-04-13 00:00:05 --> Helper loaded: url_helper
INFO - 2018-04-13 00:00:05 --> Helper loaded: form_helper
INFO - 2018-04-13 00:00:05 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:00:05 --> User Agent Class Initialized
INFO - 2018-04-13 00:00:05 --> Controller Class Initialized
INFO - 2018-04-13 00:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:00:05 --> Pixel_Model class loaded
INFO - 2018-04-13 00:00:05 --> Database Driver Class Initialized
INFO - 2018-04-13 00:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:00:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:00:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 00:00:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 00:00:05 --> File loaded: E:\www\yacopoo\application\views\questions/home_value.php
INFO - 2018-04-13 00:00:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:00:05 --> Final output sent to browser
DEBUG - 2018-04-13 00:00:05 --> Total execution time: 0.5708
INFO - 2018-04-13 00:07:47 --> Config Class Initialized
INFO - 2018-04-13 00:07:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:07:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:07:47 --> Utf8 Class Initialized
INFO - 2018-04-13 00:07:47 --> URI Class Initialized
INFO - 2018-04-13 00:07:47 --> Router Class Initialized
INFO - 2018-04-13 00:07:47 --> Output Class Initialized
INFO - 2018-04-13 00:07:47 --> Security Class Initialized
DEBUG - 2018-04-13 00:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:07:47 --> CSRF cookie sent
INFO - 2018-04-13 00:07:47 --> Input Class Initialized
INFO - 2018-04-13 00:07:47 --> Language Class Initialized
INFO - 2018-04-13 00:07:47 --> Loader Class Initialized
INFO - 2018-04-13 00:07:47 --> Helper loaded: url_helper
INFO - 2018-04-13 00:07:47 --> Helper loaded: form_helper
INFO - 2018-04-13 00:07:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:07:47 --> User Agent Class Initialized
INFO - 2018-04-13 00:07:47 --> Controller Class Initialized
INFO - 2018-04-13 00:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:07:47 --> Pixel_Model class loaded
INFO - 2018-04-13 00:07:47 --> Database Driver Class Initialized
INFO - 2018-04-13 00:07:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:07:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 00:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 00:07:51 --> File loaded: E:\www\yacopoo\application\views\questions/other_kids.php
INFO - 2018-04-13 00:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:07:51 --> Final output sent to browser
DEBUG - 2018-04-13 00:07:51 --> Total execution time: 3.5712
INFO - 2018-04-13 00:07:55 --> Config Class Initialized
INFO - 2018-04-13 00:07:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:07:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:07:55 --> Utf8 Class Initialized
INFO - 2018-04-13 00:07:55 --> URI Class Initialized
INFO - 2018-04-13 00:07:55 --> Router Class Initialized
INFO - 2018-04-13 00:07:55 --> Output Class Initialized
INFO - 2018-04-13 00:07:55 --> Security Class Initialized
DEBUG - 2018-04-13 00:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:07:55 --> CSRF cookie sent
INFO - 2018-04-13 00:07:55 --> CSRF token verified
INFO - 2018-04-13 00:07:55 --> Input Class Initialized
INFO - 2018-04-13 00:07:55 --> Language Class Initialized
INFO - 2018-04-13 00:07:55 --> Loader Class Initialized
INFO - 2018-04-13 00:07:55 --> Helper loaded: url_helper
INFO - 2018-04-13 00:07:55 --> Helper loaded: form_helper
INFO - 2018-04-13 00:07:55 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:07:55 --> User Agent Class Initialized
INFO - 2018-04-13 00:07:55 --> Controller Class Initialized
INFO - 2018-04-13 00:07:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:07:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:07:55 --> Pixel_Model class loaded
INFO - 2018-04-13 00:07:55 --> Database Driver Class Initialized
INFO - 2018-04-13 00:07:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:07:55 --> Form Validation Class Initialized
INFO - 2018-04-13 00:07:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 00:07:55 --> Config Class Initialized
INFO - 2018-04-13 00:07:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:07:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:07:55 --> Utf8 Class Initialized
INFO - 2018-04-13 00:07:55 --> URI Class Initialized
INFO - 2018-04-13 00:07:55 --> Router Class Initialized
INFO - 2018-04-13 00:07:55 --> Output Class Initialized
INFO - 2018-04-13 00:07:55 --> Security Class Initialized
DEBUG - 2018-04-13 00:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:07:55 --> CSRF cookie sent
INFO - 2018-04-13 00:07:55 --> Input Class Initialized
INFO - 2018-04-13 00:07:55 --> Language Class Initialized
INFO - 2018-04-13 00:07:55 --> Loader Class Initialized
INFO - 2018-04-13 00:07:55 --> Helper loaded: url_helper
INFO - 2018-04-13 00:07:55 --> Helper loaded: form_helper
INFO - 2018-04-13 00:07:55 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:07:55 --> User Agent Class Initialized
INFO - 2018-04-13 00:07:55 --> Controller Class Initialized
INFO - 2018-04-13 00:07:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:07:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:07:55 --> Pixel_Model class loaded
INFO - 2018-04-13 00:07:55 --> Database Driver Class Initialized
INFO - 2018-04-13 00:07:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\questions/home_value.php
INFO - 2018-04-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:07:55 --> Final output sent to browser
DEBUG - 2018-04-13 00:07:55 --> Total execution time: 0.3418
INFO - 2018-04-13 00:14:24 --> Config Class Initialized
INFO - 2018-04-13 00:14:24 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:24 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:24 --> URI Class Initialized
DEBUG - 2018-04-13 00:14:24 --> No URI present. Default controller set.
INFO - 2018-04-13 00:14:24 --> Router Class Initialized
INFO - 2018-04-13 00:14:24 --> Output Class Initialized
INFO - 2018-04-13 00:14:24 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:24 --> CSRF cookie sent
INFO - 2018-04-13 00:14:24 --> Input Class Initialized
INFO - 2018-04-13 00:14:24 --> Language Class Initialized
INFO - 2018-04-13 00:14:24 --> Loader Class Initialized
INFO - 2018-04-13 00:14:24 --> Helper loaded: url_helper
INFO - 2018-04-13 00:14:24 --> Helper loaded: form_helper
INFO - 2018-04-13 00:14:24 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:14:24 --> User Agent Class Initialized
INFO - 2018-04-13 00:14:24 --> Controller Class Initialized
INFO - 2018-04-13 00:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:14:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:14:24 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:14:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:14:24 --> Final output sent to browser
DEBUG - 2018-04-13 00:14:24 --> Total execution time: 0.3463
INFO - 2018-04-13 00:14:26 --> Config Class Initialized
INFO - 2018-04-13 00:14:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:26 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:26 --> URI Class Initialized
INFO - 2018-04-13 00:14:26 --> Router Class Initialized
INFO - 2018-04-13 00:14:26 --> Output Class Initialized
INFO - 2018-04-13 00:14:26 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:26 --> CSRF cookie sent
INFO - 2018-04-13 00:14:26 --> Input Class Initialized
INFO - 2018-04-13 00:14:26 --> Language Class Initialized
ERROR - 2018-04-13 00:14:26 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 00:14:32 --> Config Class Initialized
INFO - 2018-04-13 00:14:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:32 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:32 --> URI Class Initialized
INFO - 2018-04-13 00:14:32 --> Router Class Initialized
INFO - 2018-04-13 00:14:32 --> Output Class Initialized
INFO - 2018-04-13 00:14:32 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:32 --> CSRF cookie sent
INFO - 2018-04-13 00:14:32 --> Input Class Initialized
INFO - 2018-04-13 00:14:32 --> Language Class Initialized
ERROR - 2018-04-13 00:14:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:14:35 --> Config Class Initialized
INFO - 2018-04-13 00:14:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:35 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:35 --> URI Class Initialized
DEBUG - 2018-04-13 00:14:35 --> No URI present. Default controller set.
INFO - 2018-04-13 00:14:35 --> Router Class Initialized
INFO - 2018-04-13 00:14:35 --> Output Class Initialized
INFO - 2018-04-13 00:14:35 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:35 --> CSRF cookie sent
INFO - 2018-04-13 00:14:35 --> Input Class Initialized
INFO - 2018-04-13 00:14:35 --> Language Class Initialized
INFO - 2018-04-13 00:14:35 --> Loader Class Initialized
INFO - 2018-04-13 00:14:35 --> Helper loaded: url_helper
INFO - 2018-04-13 00:14:35 --> Helper loaded: form_helper
INFO - 2018-04-13 00:14:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:14:35 --> User Agent Class Initialized
INFO - 2018-04-13 00:14:35 --> Controller Class Initialized
INFO - 2018-04-13 00:14:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:14:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:14:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:14:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:14:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:14:35 --> Final output sent to browser
DEBUG - 2018-04-13 00:14:35 --> Total execution time: 0.3096
INFO - 2018-04-13 00:14:36 --> Config Class Initialized
INFO - 2018-04-13 00:14:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:36 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:36 --> URI Class Initialized
INFO - 2018-04-13 00:14:36 --> Router Class Initialized
INFO - 2018-04-13 00:14:36 --> Output Class Initialized
INFO - 2018-04-13 00:14:36 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:36 --> CSRF cookie sent
INFO - 2018-04-13 00:14:36 --> Input Class Initialized
INFO - 2018-04-13 00:14:36 --> Language Class Initialized
ERROR - 2018-04-13 00:14:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:14:39 --> Config Class Initialized
INFO - 2018-04-13 00:14:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:14:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:14:39 --> Utf8 Class Initialized
INFO - 2018-04-13 00:14:39 --> URI Class Initialized
INFO - 2018-04-13 00:14:39 --> Router Class Initialized
INFO - 2018-04-13 00:14:39 --> Output Class Initialized
INFO - 2018-04-13 00:14:39 --> Security Class Initialized
DEBUG - 2018-04-13 00:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:14:39 --> CSRF cookie sent
INFO - 2018-04-13 00:14:39 --> Input Class Initialized
INFO - 2018-04-13 00:14:39 --> Language Class Initialized
ERROR - 2018-04-13 00:14:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 00:15:21 --> Config Class Initialized
INFO - 2018-04-13 00:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:21 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:21 --> URI Class Initialized
DEBUG - 2018-04-13 00:15:21 --> No URI present. Default controller set.
INFO - 2018-04-13 00:15:21 --> Router Class Initialized
INFO - 2018-04-13 00:15:21 --> Output Class Initialized
INFO - 2018-04-13 00:15:21 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:21 --> CSRF cookie sent
INFO - 2018-04-13 00:15:21 --> Input Class Initialized
INFO - 2018-04-13 00:15:21 --> Language Class Initialized
INFO - 2018-04-13 00:15:21 --> Loader Class Initialized
INFO - 2018-04-13 00:15:21 --> Helper loaded: url_helper
INFO - 2018-04-13 00:15:21 --> Helper loaded: form_helper
INFO - 2018-04-13 00:15:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:15:21 --> User Agent Class Initialized
INFO - 2018-04-13 00:15:21 --> Controller Class Initialized
INFO - 2018-04-13 00:15:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:15:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:15:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:15:21 --> Final output sent to browser
DEBUG - 2018-04-13 00:15:21 --> Total execution time: 0.3632
INFO - 2018-04-13 00:15:21 --> Config Class Initialized
INFO - 2018-04-13 00:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:21 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:21 --> URI Class Initialized
INFO - 2018-04-13 00:15:21 --> Router Class Initialized
INFO - 2018-04-13 00:15:21 --> Output Class Initialized
INFO - 2018-04-13 00:15:22 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:22 --> CSRF cookie sent
INFO - 2018-04-13 00:15:22 --> Input Class Initialized
INFO - 2018-04-13 00:15:22 --> Language Class Initialized
ERROR - 2018-04-13 00:15:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:15:23 --> Config Class Initialized
INFO - 2018-04-13 00:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:23 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:23 --> URI Class Initialized
INFO - 2018-04-13 00:15:23 --> Router Class Initialized
INFO - 2018-04-13 00:15:23 --> Output Class Initialized
INFO - 2018-04-13 00:15:23 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:23 --> CSRF cookie sent
INFO - 2018-04-13 00:15:23 --> Input Class Initialized
INFO - 2018-04-13 00:15:23 --> Language Class Initialized
ERROR - 2018-04-13 00:15:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 00:15:25 --> Config Class Initialized
INFO - 2018-04-13 00:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:25 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:25 --> URI Class Initialized
DEBUG - 2018-04-13 00:15:25 --> No URI present. Default controller set.
INFO - 2018-04-13 00:15:25 --> Router Class Initialized
INFO - 2018-04-13 00:15:25 --> Output Class Initialized
INFO - 2018-04-13 00:15:25 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:25 --> CSRF cookie sent
INFO - 2018-04-13 00:15:25 --> Input Class Initialized
INFO - 2018-04-13 00:15:25 --> Language Class Initialized
INFO - 2018-04-13 00:15:25 --> Loader Class Initialized
INFO - 2018-04-13 00:15:25 --> Helper loaded: url_helper
INFO - 2018-04-13 00:15:25 --> Helper loaded: form_helper
INFO - 2018-04-13 00:15:25 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:15:25 --> User Agent Class Initialized
INFO - 2018-04-13 00:15:25 --> Controller Class Initialized
INFO - 2018-04-13 00:15:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:15:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:15:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:15:25 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:15:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:15:25 --> Final output sent to browser
DEBUG - 2018-04-13 00:15:25 --> Total execution time: 0.3428
INFO - 2018-04-13 00:15:26 --> Config Class Initialized
INFO - 2018-04-13 00:15:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:26 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:26 --> URI Class Initialized
INFO - 2018-04-13 00:15:26 --> Router Class Initialized
INFO - 2018-04-13 00:15:26 --> Output Class Initialized
INFO - 2018-04-13 00:15:26 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:26 --> CSRF cookie sent
INFO - 2018-04-13 00:15:26 --> Input Class Initialized
INFO - 2018-04-13 00:15:26 --> Language Class Initialized
ERROR - 2018-04-13 00:15:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:15:27 --> Config Class Initialized
INFO - 2018-04-13 00:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:27 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:27 --> URI Class Initialized
INFO - 2018-04-13 00:15:27 --> Router Class Initialized
INFO - 2018-04-13 00:15:27 --> Output Class Initialized
INFO - 2018-04-13 00:15:27 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:27 --> CSRF cookie sent
INFO - 2018-04-13 00:15:27 --> Input Class Initialized
INFO - 2018-04-13 00:15:27 --> Language Class Initialized
ERROR - 2018-04-13 00:15:27 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 00:15:32 --> Config Class Initialized
INFO - 2018-04-13 00:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:32 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:32 --> URI Class Initialized
DEBUG - 2018-04-13 00:15:32 --> No URI present. Default controller set.
INFO - 2018-04-13 00:15:32 --> Router Class Initialized
INFO - 2018-04-13 00:15:32 --> Output Class Initialized
INFO - 2018-04-13 00:15:32 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:32 --> CSRF cookie sent
INFO - 2018-04-13 00:15:32 --> Input Class Initialized
INFO - 2018-04-13 00:15:32 --> Language Class Initialized
INFO - 2018-04-13 00:15:32 --> Loader Class Initialized
INFO - 2018-04-13 00:15:32 --> Helper loaded: url_helper
INFO - 2018-04-13 00:15:32 --> Helper loaded: form_helper
INFO - 2018-04-13 00:15:32 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:15:32 --> User Agent Class Initialized
INFO - 2018-04-13 00:15:32 --> Controller Class Initialized
INFO - 2018-04-13 00:15:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:15:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:15:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:15:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:15:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:15:32 --> Final output sent to browser
DEBUG - 2018-04-13 00:15:32 --> Total execution time: 0.3128
INFO - 2018-04-13 00:15:33 --> Config Class Initialized
INFO - 2018-04-13 00:15:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:33 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:33 --> URI Class Initialized
INFO - 2018-04-13 00:15:33 --> Router Class Initialized
INFO - 2018-04-13 00:15:33 --> Output Class Initialized
INFO - 2018-04-13 00:15:33 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:33 --> CSRF cookie sent
INFO - 2018-04-13 00:15:33 --> Input Class Initialized
INFO - 2018-04-13 00:15:33 --> Language Class Initialized
ERROR - 2018-04-13 00:15:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:15:34 --> Config Class Initialized
INFO - 2018-04-13 00:15:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:34 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:35 --> URI Class Initialized
INFO - 2018-04-13 00:15:35 --> Router Class Initialized
INFO - 2018-04-13 00:15:35 --> Output Class Initialized
INFO - 2018-04-13 00:15:35 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:35 --> CSRF cookie sent
INFO - 2018-04-13 00:15:35 --> Input Class Initialized
INFO - 2018-04-13 00:15:35 --> Language Class Initialized
ERROR - 2018-04-13 00:15:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 00:15:42 --> Config Class Initialized
INFO - 2018-04-13 00:15:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:42 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:42 --> URI Class Initialized
DEBUG - 2018-04-13 00:15:42 --> No URI present. Default controller set.
INFO - 2018-04-13 00:15:42 --> Router Class Initialized
INFO - 2018-04-13 00:15:42 --> Output Class Initialized
INFO - 2018-04-13 00:15:42 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:42 --> CSRF cookie sent
INFO - 2018-04-13 00:15:42 --> Input Class Initialized
INFO - 2018-04-13 00:15:42 --> Language Class Initialized
INFO - 2018-04-13 00:15:42 --> Loader Class Initialized
INFO - 2018-04-13 00:15:42 --> Helper loaded: url_helper
INFO - 2018-04-13 00:15:42 --> Helper loaded: form_helper
INFO - 2018-04-13 00:15:42 --> Helper loaded: language_helper
DEBUG - 2018-04-13 00:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 00:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 00:15:43 --> User Agent Class Initialized
INFO - 2018-04-13 00:15:43 --> Controller Class Initialized
INFO - 2018-04-13 00:15:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 00:15:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 00:15:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 00:15:43 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 00:15:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 00:15:43 --> Final output sent to browser
DEBUG - 2018-04-13 00:15:43 --> Total execution time: 0.3647
INFO - 2018-04-13 00:15:43 --> Config Class Initialized
INFO - 2018-04-13 00:15:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:43 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:43 --> URI Class Initialized
INFO - 2018-04-13 00:15:43 --> Router Class Initialized
INFO - 2018-04-13 00:15:43 --> Output Class Initialized
INFO - 2018-04-13 00:15:43 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:43 --> CSRF cookie sent
INFO - 2018-04-13 00:15:43 --> Input Class Initialized
INFO - 2018-04-13 00:15:43 --> Language Class Initialized
ERROR - 2018-04-13 00:15:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 00:15:45 --> Config Class Initialized
INFO - 2018-04-13 00:15:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 00:15:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 00:15:45 --> Utf8 Class Initialized
INFO - 2018-04-13 00:15:45 --> URI Class Initialized
INFO - 2018-04-13 00:15:45 --> Router Class Initialized
INFO - 2018-04-13 00:15:45 --> Output Class Initialized
INFO - 2018-04-13 00:15:45 --> Security Class Initialized
DEBUG - 2018-04-13 00:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 00:15:45 --> CSRF cookie sent
INFO - 2018-04-13 00:15:45 --> Input Class Initialized
INFO - 2018-04-13 00:15:45 --> Language Class Initialized
ERROR - 2018-04-13 00:15:45 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 15:56:03 --> Config Class Initialized
INFO - 2018-04-13 15:56:03 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:04 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:04 --> URI Class Initialized
INFO - 2018-04-13 15:56:04 --> Router Class Initialized
INFO - 2018-04-13 15:56:04 --> Output Class Initialized
INFO - 2018-04-13 15:56:04 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:04 --> CSRF cookie sent
INFO - 2018-04-13 15:56:04 --> Input Class Initialized
INFO - 2018-04-13 15:56:04 --> Language Class Initialized
INFO - 2018-04-13 15:56:04 --> Loader Class Initialized
INFO - 2018-04-13 15:56:04 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:04 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:04 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:04 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:04 --> Controller Class Initialized
INFO - 2018-04-13 15:56:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:56:04 --> Pixel_Model class loaded
INFO - 2018-04-13 15:56:05 --> Database Driver Class Initialized
INFO - 2018-04-13 15:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 15:56:08 --> Config Class Initialized
INFO - 2018-04-13 15:56:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:08 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:08 --> URI Class Initialized
DEBUG - 2018-04-13 15:56:08 --> No URI present. Default controller set.
INFO - 2018-04-13 15:56:08 --> Router Class Initialized
INFO - 2018-04-13 15:56:08 --> Output Class Initialized
INFO - 2018-04-13 15:56:08 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:08 --> CSRF cookie sent
INFO - 2018-04-13 15:56:08 --> Input Class Initialized
INFO - 2018-04-13 15:56:08 --> Language Class Initialized
INFO - 2018-04-13 15:56:08 --> Loader Class Initialized
INFO - 2018-04-13 15:56:08 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:08 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:08 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:08 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:08 --> Controller Class Initialized
INFO - 2018-04-13 15:56:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:56:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:56:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 15:56:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:56:09 --> Final output sent to browser
DEBUG - 2018-04-13 15:56:09 --> Total execution time: 0.6059
INFO - 2018-04-13 15:56:10 --> Config Class Initialized
INFO - 2018-04-13 15:56:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:10 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:10 --> URI Class Initialized
INFO - 2018-04-13 15:56:10 --> Router Class Initialized
INFO - 2018-04-13 15:56:10 --> Output Class Initialized
INFO - 2018-04-13 15:56:10 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:10 --> CSRF cookie sent
INFO - 2018-04-13 15:56:10 --> Input Class Initialized
INFO - 2018-04-13 15:56:10 --> Language Class Initialized
ERROR - 2018-04-13 15:56:10 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 15:56:16 --> Config Class Initialized
INFO - 2018-04-13 15:56:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:16 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:16 --> URI Class Initialized
INFO - 2018-04-13 15:56:16 --> Router Class Initialized
INFO - 2018-04-13 15:56:16 --> Output Class Initialized
INFO - 2018-04-13 15:56:16 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:16 --> CSRF cookie sent
INFO - 2018-04-13 15:56:16 --> Input Class Initialized
INFO - 2018-04-13 15:56:16 --> Language Class Initialized
INFO - 2018-04-13 15:56:16 --> Loader Class Initialized
INFO - 2018-04-13 15:56:16 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:16 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:16 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:16 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:16 --> Controller Class Initialized
INFO - 2018-04-13 15:56:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-13 15:56:17 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 15:56:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:56:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 15:56:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 15:56:17 --> Could not find the language line "req_email"
INFO - 2018-04-13 15:56:17 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-13 15:56:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:56:17 --> Final output sent to browser
DEBUG - 2018-04-13 15:56:17 --> Total execution time: 0.4684
INFO - 2018-04-13 15:56:32 --> Config Class Initialized
INFO - 2018-04-13 15:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:33 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:33 --> URI Class Initialized
INFO - 2018-04-13 15:56:33 --> Router Class Initialized
INFO - 2018-04-13 15:56:33 --> Output Class Initialized
INFO - 2018-04-13 15:56:33 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:33 --> CSRF cookie sent
INFO - 2018-04-13 15:56:33 --> CSRF token verified
INFO - 2018-04-13 15:56:33 --> Input Class Initialized
INFO - 2018-04-13 15:56:33 --> Language Class Initialized
INFO - 2018-04-13 15:56:33 --> Loader Class Initialized
INFO - 2018-04-13 15:56:33 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:33 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:33 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:33 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:33 --> Controller Class Initialized
INFO - 2018-04-13 15:56:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-13 15:56:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 15:56:33 --> Form Validation Class Initialized
INFO - 2018-04-13 15:56:33 --> Pixel_Model class loaded
INFO - 2018-04-13 15:56:33 --> Database Driver Class Initialized
INFO - 2018-04-13 15:56:33 --> Model "AuthenticationModel" initialized
INFO - 2018-04-13 15:56:34 --> Config Class Initialized
INFO - 2018-04-13 15:56:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:34 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:34 --> URI Class Initialized
DEBUG - 2018-04-13 15:56:34 --> No URI present. Default controller set.
INFO - 2018-04-13 15:56:34 --> Router Class Initialized
INFO - 2018-04-13 15:56:34 --> Output Class Initialized
INFO - 2018-04-13 15:56:34 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:34 --> CSRF cookie sent
INFO - 2018-04-13 15:56:34 --> Input Class Initialized
INFO - 2018-04-13 15:56:34 --> Language Class Initialized
INFO - 2018-04-13 15:56:34 --> Loader Class Initialized
INFO - 2018-04-13 15:56:34 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:34 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:34 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:34 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:34 --> Controller Class Initialized
INFO - 2018-04-13 15:56:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:56:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 15:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:56:34 --> Final output sent to browser
DEBUG - 2018-04-13 15:56:34 --> Total execution time: 0.3764
INFO - 2018-04-13 15:56:36 --> Config Class Initialized
INFO - 2018-04-13 15:56:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:36 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:36 --> URI Class Initialized
INFO - 2018-04-13 15:56:36 --> Router Class Initialized
INFO - 2018-04-13 15:56:36 --> Output Class Initialized
INFO - 2018-04-13 15:56:36 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:36 --> CSRF cookie sent
INFO - 2018-04-13 15:56:36 --> Input Class Initialized
INFO - 2018-04-13 15:56:36 --> Language Class Initialized
ERROR - 2018-04-13 15:56:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 15:56:40 --> Config Class Initialized
INFO - 2018-04-13 15:56:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:40 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:40 --> URI Class Initialized
INFO - 2018-04-13 15:56:40 --> Router Class Initialized
INFO - 2018-04-13 15:56:40 --> Output Class Initialized
INFO - 2018-04-13 15:56:40 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:40 --> CSRF cookie sent
INFO - 2018-04-13 15:56:40 --> Input Class Initialized
INFO - 2018-04-13 15:56:40 --> Language Class Initialized
INFO - 2018-04-13 15:56:40 --> Loader Class Initialized
INFO - 2018-04-13 15:56:40 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:40 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:40 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:40 --> Controller Class Initialized
INFO - 2018-04-13 15:56:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:56:40 --> Pixel_Model class loaded
INFO - 2018-04-13 15:56:40 --> Database Driver Class Initialized
INFO - 2018-04-13 15:56:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 15:56:40 --> Config Class Initialized
INFO - 2018-04-13 15:56:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:56:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:56:40 --> Utf8 Class Initialized
INFO - 2018-04-13 15:56:40 --> URI Class Initialized
INFO - 2018-04-13 15:56:40 --> Router Class Initialized
INFO - 2018-04-13 15:56:40 --> Output Class Initialized
INFO - 2018-04-13 15:56:40 --> Security Class Initialized
DEBUG - 2018-04-13 15:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:56:40 --> CSRF cookie sent
INFO - 2018-04-13 15:56:40 --> Input Class Initialized
INFO - 2018-04-13 15:56:40 --> Language Class Initialized
INFO - 2018-04-13 15:56:40 --> Loader Class Initialized
INFO - 2018-04-13 15:56:40 --> Helper loaded: url_helper
INFO - 2018-04-13 15:56:40 --> Helper loaded: form_helper
INFO - 2018-04-13 15:56:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:56:40 --> User Agent Class Initialized
INFO - 2018-04-13 15:56:40 --> Controller Class Initialized
INFO - 2018-04-13 15:56:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:56:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:56:40 --> Pixel_Model class loaded
INFO - 2018-04-13 15:56:40 --> Database Driver Class Initialized
INFO - 2018-04-13 15:56:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 15:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 15:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 15:56:41 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-13 15:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:56:41 --> Final output sent to browser
DEBUG - 2018-04-13 15:56:41 --> Total execution time: 0.5317
INFO - 2018-04-13 15:57:39 --> Config Class Initialized
INFO - 2018-04-13 15:57:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:57:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:57:39 --> Utf8 Class Initialized
INFO - 2018-04-13 15:57:39 --> URI Class Initialized
INFO - 2018-04-13 15:57:39 --> Router Class Initialized
INFO - 2018-04-13 15:57:39 --> Output Class Initialized
INFO - 2018-04-13 15:57:39 --> Security Class Initialized
DEBUG - 2018-04-13 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:57:39 --> CSRF cookie sent
INFO - 2018-04-13 15:57:39 --> Input Class Initialized
INFO - 2018-04-13 15:57:39 --> Language Class Initialized
INFO - 2018-04-13 15:57:39 --> Loader Class Initialized
INFO - 2018-04-13 15:57:39 --> Helper loaded: url_helper
INFO - 2018-04-13 15:57:39 --> Helper loaded: form_helper
INFO - 2018-04-13 15:57:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:57:39 --> User Agent Class Initialized
INFO - 2018-04-13 15:57:39 --> Controller Class Initialized
INFO - 2018-04-13 15:57:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:57:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:57:39 --> Pixel_Model class loaded
INFO - 2018-04-13 15:57:39 --> Database Driver Class Initialized
INFO - 2018-04-13 15:57:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 15:57:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:57:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 15:57:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 15:57:42 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-13 15:57:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:57:42 --> Final output sent to browser
DEBUG - 2018-04-13 15:57:42 --> Total execution time: 3.4614
INFO - 2018-04-13 15:57:54 --> Config Class Initialized
INFO - 2018-04-13 15:57:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 15:57:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 15:57:54 --> Utf8 Class Initialized
INFO - 2018-04-13 15:57:54 --> URI Class Initialized
INFO - 2018-04-13 15:57:54 --> Router Class Initialized
INFO - 2018-04-13 15:57:54 --> Output Class Initialized
INFO - 2018-04-13 15:57:54 --> Security Class Initialized
DEBUG - 2018-04-13 15:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 15:57:54 --> CSRF cookie sent
INFO - 2018-04-13 15:57:54 --> Input Class Initialized
INFO - 2018-04-13 15:57:54 --> Language Class Initialized
INFO - 2018-04-13 15:57:54 --> Loader Class Initialized
INFO - 2018-04-13 15:57:54 --> Helper loaded: url_helper
INFO - 2018-04-13 15:57:54 --> Helper loaded: form_helper
INFO - 2018-04-13 15:57:54 --> Helper loaded: language_helper
DEBUG - 2018-04-13 15:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 15:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 15:57:54 --> User Agent Class Initialized
INFO - 2018-04-13 15:57:54 --> Controller Class Initialized
INFO - 2018-04-13 15:57:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 15:57:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 15:57:54 --> Pixel_Model class loaded
INFO - 2018-04-13 15:57:54 --> Database Driver Class Initialized
INFO - 2018-04-13 15:57:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 15:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 15:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 15:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 15:57:54 --> File loaded: E:\www\yacopoo\application\views\questions/home_value.php
INFO - 2018-04-13 15:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 15:57:54 --> Final output sent to browser
DEBUG - 2018-04-13 15:57:54 --> Total execution time: 0.5359
INFO - 2018-04-13 16:29:19 --> Config Class Initialized
INFO - 2018-04-13 16:29:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:29:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:29:19 --> Utf8 Class Initialized
INFO - 2018-04-13 16:29:19 --> URI Class Initialized
INFO - 2018-04-13 16:29:19 --> Router Class Initialized
INFO - 2018-04-13 16:29:19 --> Output Class Initialized
INFO - 2018-04-13 16:29:19 --> Security Class Initialized
DEBUG - 2018-04-13 16:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:29:19 --> CSRF cookie sent
INFO - 2018-04-13 16:29:19 --> Input Class Initialized
INFO - 2018-04-13 16:29:19 --> Language Class Initialized
INFO - 2018-04-13 16:29:19 --> Loader Class Initialized
INFO - 2018-04-13 16:29:19 --> Helper loaded: url_helper
INFO - 2018-04-13 16:29:19 --> Helper loaded: form_helper
INFO - 2018-04-13 16:29:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:29:19 --> User Agent Class Initialized
INFO - 2018-04-13 16:29:19 --> Controller Class Initialized
INFO - 2018-04-13 16:29:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:29:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:29:19 --> Pixel_Model class loaded
INFO - 2018-04-13 16:29:19 --> Database Driver Class Initialized
INFO - 2018-04-13 16:29:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:29:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:29:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:29:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:29:22 --> File loaded: E:\www\yacopoo\application\views\questions/other_kids.php
INFO - 2018-04-13 16:29:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:29:22 --> Final output sent to browser
DEBUG - 2018-04-13 16:29:22 --> Total execution time: 3.5417
INFO - 2018-04-13 16:49:03 --> Config Class Initialized
INFO - 2018-04-13 16:49:03 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:49:03 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:49:03 --> Utf8 Class Initialized
INFO - 2018-04-13 16:49:03 --> URI Class Initialized
INFO - 2018-04-13 16:49:03 --> Router Class Initialized
INFO - 2018-04-13 16:49:03 --> Output Class Initialized
INFO - 2018-04-13 16:49:03 --> Security Class Initialized
DEBUG - 2018-04-13 16:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:49:03 --> CSRF cookie sent
INFO - 2018-04-13 16:49:03 --> CSRF token verified
INFO - 2018-04-13 16:49:03 --> Input Class Initialized
INFO - 2018-04-13 16:49:03 --> Language Class Initialized
INFO - 2018-04-13 16:49:03 --> Loader Class Initialized
INFO - 2018-04-13 16:49:03 --> Helper loaded: url_helper
INFO - 2018-04-13 16:49:03 --> Helper loaded: form_helper
INFO - 2018-04-13 16:49:03 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:49:03 --> User Agent Class Initialized
INFO - 2018-04-13 16:49:03 --> Controller Class Initialized
INFO - 2018-04-13 16:49:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:49:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:49:03 --> Pixel_Model class loaded
INFO - 2018-04-13 16:49:03 --> Database Driver Class Initialized
INFO - 2018-04-13 16:49:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:49:06 --> Form Validation Class Initialized
INFO - 2018-04-13 16:49:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 16:49:06 --> Config Class Initialized
INFO - 2018-04-13 16:49:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:49:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:49:06 --> Utf8 Class Initialized
INFO - 2018-04-13 16:49:06 --> URI Class Initialized
INFO - 2018-04-13 16:49:06 --> Router Class Initialized
INFO - 2018-04-13 16:49:06 --> Output Class Initialized
INFO - 2018-04-13 16:49:06 --> Security Class Initialized
DEBUG - 2018-04-13 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:49:06 --> CSRF cookie sent
INFO - 2018-04-13 16:49:06 --> Input Class Initialized
INFO - 2018-04-13 16:49:06 --> Language Class Initialized
INFO - 2018-04-13 16:49:06 --> Loader Class Initialized
INFO - 2018-04-13 16:49:06 --> Helper loaded: url_helper
INFO - 2018-04-13 16:49:06 --> Helper loaded: form_helper
INFO - 2018-04-13 16:49:06 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:49:06 --> User Agent Class Initialized
INFO - 2018-04-13 16:49:06 --> Controller Class Initialized
INFO - 2018-04-13 16:49:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:49:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:49:06 --> Pixel_Model class loaded
INFO - 2018-04-13 16:49:06 --> Database Driver Class Initialized
INFO - 2018-04-13 16:49:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:49:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:49:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:49:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:49:06 --> File loaded: E:\www\yacopoo\application\views\questions/home_value.php
INFO - 2018-04-13 16:49:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:49:06 --> Final output sent to browser
DEBUG - 2018-04-13 16:49:06 --> Total execution time: 0.3512
INFO - 2018-04-13 16:49:11 --> Config Class Initialized
INFO - 2018-04-13 16:49:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:49:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:49:11 --> Utf8 Class Initialized
INFO - 2018-04-13 16:49:11 --> URI Class Initialized
INFO - 2018-04-13 16:49:11 --> Router Class Initialized
INFO - 2018-04-13 16:49:11 --> Output Class Initialized
INFO - 2018-04-13 16:49:11 --> Security Class Initialized
DEBUG - 2018-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:49:11 --> CSRF cookie sent
INFO - 2018-04-13 16:49:11 --> CSRF token verified
INFO - 2018-04-13 16:49:11 --> Input Class Initialized
INFO - 2018-04-13 16:49:11 --> Language Class Initialized
INFO - 2018-04-13 16:49:11 --> Loader Class Initialized
INFO - 2018-04-13 16:49:11 --> Helper loaded: url_helper
INFO - 2018-04-13 16:49:11 --> Helper loaded: form_helper
INFO - 2018-04-13 16:49:11 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:49:11 --> User Agent Class Initialized
INFO - 2018-04-13 16:49:11 --> Controller Class Initialized
INFO - 2018-04-13 16:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:49:11 --> Pixel_Model class loaded
INFO - 2018-04-13 16:49:11 --> Database Driver Class Initialized
INFO - 2018-04-13 16:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:49:11 --> Form Validation Class Initialized
INFO - 2018-04-13 16:49:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 16:49:11 --> Config Class Initialized
INFO - 2018-04-13 16:49:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:49:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:49:11 --> Utf8 Class Initialized
INFO - 2018-04-13 16:49:11 --> URI Class Initialized
INFO - 2018-04-13 16:49:11 --> Router Class Initialized
INFO - 2018-04-13 16:49:11 --> Output Class Initialized
INFO - 2018-04-13 16:49:11 --> Security Class Initialized
DEBUG - 2018-04-13 16:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:49:12 --> CSRF cookie sent
INFO - 2018-04-13 16:49:12 --> Input Class Initialized
INFO - 2018-04-13 16:49:12 --> Language Class Initialized
INFO - 2018-04-13 16:49:12 --> Loader Class Initialized
INFO - 2018-04-13 16:49:12 --> Helper loaded: url_helper
INFO - 2018-04-13 16:49:12 --> Helper loaded: form_helper
INFO - 2018-04-13 16:49:12 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:49:12 --> User Agent Class Initialized
INFO - 2018-04-13 16:49:12 --> Controller Class Initialized
INFO - 2018-04-13 16:49:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:49:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:49:12 --> Pixel_Model class loaded
INFO - 2018-04-13 16:49:12 --> Database Driver Class Initialized
INFO - 2018-04-13 16:49:12 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:49:12 --> File loaded: E:\www\yacopoo\application\views\questions/financial.php
INFO - 2018-04-13 16:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:49:12 --> Final output sent to browser
DEBUG - 2018-04-13 16:49:12 --> Total execution time: 0.3744
INFO - 2018-04-13 16:49:14 --> Config Class Initialized
INFO - 2018-04-13 16:49:14 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:49:14 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:49:14 --> Utf8 Class Initialized
INFO - 2018-04-13 16:49:14 --> URI Class Initialized
INFO - 2018-04-13 16:49:14 --> Router Class Initialized
INFO - 2018-04-13 16:49:14 --> Output Class Initialized
INFO - 2018-04-13 16:49:14 --> Security Class Initialized
DEBUG - 2018-04-13 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:49:14 --> CSRF cookie sent
INFO - 2018-04-13 16:49:14 --> CSRF token verified
INFO - 2018-04-13 16:49:14 --> Input Class Initialized
INFO - 2018-04-13 16:49:14 --> Language Class Initialized
INFO - 2018-04-13 16:49:14 --> Loader Class Initialized
INFO - 2018-04-13 16:49:14 --> Helper loaded: url_helper
INFO - 2018-04-13 16:49:15 --> Helper loaded: form_helper
INFO - 2018-04-13 16:49:15 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:49:15 --> User Agent Class Initialized
INFO - 2018-04-13 16:49:15 --> Controller Class Initialized
INFO - 2018-04-13 16:49:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:49:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:49:15 --> Pixel_Model class loaded
INFO - 2018-04-13 16:49:15 --> Database Driver Class Initialized
INFO - 2018-04-13 16:49:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:49:15 --> Form Validation Class Initialized
INFO - 2018-04-13 16:49:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-13 16:49:15 --> Severity: Error --> Call to undefined method PayerReciepientController::homeTitleInfoPage() E:\www\yacopoo\application\controllers\PayerReciepientController.php 213
INFO - 2018-04-13 16:51:55 --> Config Class Initialized
INFO - 2018-04-13 16:51:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:51:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:51:55 --> Utf8 Class Initialized
INFO - 2018-04-13 16:51:55 --> URI Class Initialized
INFO - 2018-04-13 16:51:55 --> Router Class Initialized
INFO - 2018-04-13 16:51:55 --> Output Class Initialized
INFO - 2018-04-13 16:51:55 --> Security Class Initialized
DEBUG - 2018-04-13 16:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:51:55 --> CSRF cookie sent
INFO - 2018-04-13 16:51:55 --> CSRF token verified
INFO - 2018-04-13 16:51:55 --> Input Class Initialized
INFO - 2018-04-13 16:51:55 --> Language Class Initialized
INFO - 2018-04-13 16:51:55 --> Loader Class Initialized
INFO - 2018-04-13 16:51:55 --> Helper loaded: url_helper
INFO - 2018-04-13 16:51:55 --> Helper loaded: form_helper
INFO - 2018-04-13 16:51:55 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:51:55 --> User Agent Class Initialized
INFO - 2018-04-13 16:51:55 --> Controller Class Initialized
INFO - 2018-04-13 16:51:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:51:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:51:56 --> Pixel_Model class loaded
INFO - 2018-04-13 16:51:56 --> Database Driver Class Initialized
INFO - 2018-04-13 16:51:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:51:59 --> Form Validation Class Initialized
INFO - 2018-04-13 16:51:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 16:51:59 --> Config Class Initialized
INFO - 2018-04-13 16:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:51:59 --> Utf8 Class Initialized
INFO - 2018-04-13 16:51:59 --> URI Class Initialized
INFO - 2018-04-13 16:51:59 --> Router Class Initialized
INFO - 2018-04-13 16:51:59 --> Output Class Initialized
INFO - 2018-04-13 16:51:59 --> Security Class Initialized
DEBUG - 2018-04-13 16:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:51:59 --> CSRF cookie sent
INFO - 2018-04-13 16:51:59 --> Input Class Initialized
INFO - 2018-04-13 16:51:59 --> Language Class Initialized
INFO - 2018-04-13 16:51:59 --> Loader Class Initialized
INFO - 2018-04-13 16:51:59 --> Helper loaded: url_helper
INFO - 2018-04-13 16:51:59 --> Helper loaded: form_helper
INFO - 2018-04-13 16:51:59 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:51:59 --> User Agent Class Initialized
INFO - 2018-04-13 16:51:59 --> Controller Class Initialized
INFO - 2018-04-13 16:51:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:51:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:51:59 --> Pixel_Model class loaded
INFO - 2018-04-13 16:51:59 --> Database Driver Class Initialized
INFO - 2018-04-13 16:51:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:51:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:51:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:51:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:51:59 --> File loaded: E:\www\yacopoo\application\views\questions/other_kids.php
INFO - 2018-04-13 16:51:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:51:59 --> Final output sent to browser
DEBUG - 2018-04-13 16:51:59 --> Total execution time: 0.3563
INFO - 2018-04-13 16:52:01 --> Config Class Initialized
INFO - 2018-04-13 16:52:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:52:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:52:01 --> Utf8 Class Initialized
INFO - 2018-04-13 16:52:01 --> URI Class Initialized
INFO - 2018-04-13 16:52:01 --> Router Class Initialized
INFO - 2018-04-13 16:52:01 --> Output Class Initialized
INFO - 2018-04-13 16:52:01 --> Security Class Initialized
DEBUG - 2018-04-13 16:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:52:01 --> CSRF cookie sent
INFO - 2018-04-13 16:52:01 --> CSRF token verified
INFO - 2018-04-13 16:52:01 --> Input Class Initialized
INFO - 2018-04-13 16:52:01 --> Language Class Initialized
INFO - 2018-04-13 16:52:01 --> Loader Class Initialized
INFO - 2018-04-13 16:52:01 --> Helper loaded: url_helper
INFO - 2018-04-13 16:52:01 --> Helper loaded: form_helper
INFO - 2018-04-13 16:52:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:52:02 --> User Agent Class Initialized
INFO - 2018-04-13 16:52:02 --> Controller Class Initialized
INFO - 2018-04-13 16:52:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:52:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:52:02 --> Pixel_Model class loaded
INFO - 2018-04-13 16:52:02 --> Database Driver Class Initialized
INFO - 2018-04-13 16:52:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:52:02 --> Form Validation Class Initialized
INFO - 2018-04-13 16:52:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 16:52:02 --> Config Class Initialized
INFO - 2018-04-13 16:52:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:52:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:52:02 --> Utf8 Class Initialized
INFO - 2018-04-13 16:52:02 --> URI Class Initialized
INFO - 2018-04-13 16:52:02 --> Router Class Initialized
INFO - 2018-04-13 16:52:02 --> Output Class Initialized
INFO - 2018-04-13 16:52:02 --> Security Class Initialized
DEBUG - 2018-04-13 16:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:52:02 --> CSRF cookie sent
INFO - 2018-04-13 16:52:02 --> Input Class Initialized
INFO - 2018-04-13 16:52:02 --> Language Class Initialized
INFO - 2018-04-13 16:52:02 --> Loader Class Initialized
INFO - 2018-04-13 16:52:02 --> Helper loaded: url_helper
INFO - 2018-04-13 16:52:02 --> Helper loaded: form_helper
INFO - 2018-04-13 16:52:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:52:02 --> User Agent Class Initialized
INFO - 2018-04-13 16:52:02 --> Controller Class Initialized
INFO - 2018-04-13 16:52:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:52:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:52:02 --> Pixel_Model class loaded
INFO - 2018-04-13 16:52:02 --> Database Driver Class Initialized
INFO - 2018-04-13 16:52:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:52:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:52:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:52:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:52:02 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 16:52:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:52:02 --> Final output sent to browser
DEBUG - 2018-04-13 16:52:02 --> Total execution time: 0.4376
INFO - 2018-04-13 16:56:21 --> Config Class Initialized
INFO - 2018-04-13 16:56:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:56:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:56:22 --> Utf8 Class Initialized
INFO - 2018-04-13 16:56:22 --> URI Class Initialized
INFO - 2018-04-13 16:56:22 --> Router Class Initialized
INFO - 2018-04-13 16:56:22 --> Output Class Initialized
INFO - 2018-04-13 16:56:22 --> Security Class Initialized
DEBUG - 2018-04-13 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:56:22 --> CSRF cookie sent
INFO - 2018-04-13 16:56:22 --> Input Class Initialized
INFO - 2018-04-13 16:56:22 --> Language Class Initialized
INFO - 2018-04-13 16:56:22 --> Loader Class Initialized
INFO - 2018-04-13 16:56:22 --> Helper loaded: url_helper
INFO - 2018-04-13 16:56:22 --> Helper loaded: form_helper
INFO - 2018-04-13 16:56:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:56:22 --> User Agent Class Initialized
INFO - 2018-04-13 16:56:22 --> Controller Class Initialized
INFO - 2018-04-13 16:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:56:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:56:22 --> Pixel_Model class loaded
INFO - 2018-04-13 16:56:22 --> Database Driver Class Initialized
INFO - 2018-04-13 16:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:25 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
INFO - 2018-04-13 16:56:25 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 16:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:56:25 --> Final output sent to browser
DEBUG - 2018-04-13 16:56:25 --> Total execution time: 3.7007
INFO - 2018-04-13 16:56:38 --> Config Class Initialized
INFO - 2018-04-13 16:56:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:56:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:56:38 --> Utf8 Class Initialized
INFO - 2018-04-13 16:56:38 --> URI Class Initialized
INFO - 2018-04-13 16:56:38 --> Router Class Initialized
INFO - 2018-04-13 16:56:38 --> Output Class Initialized
INFO - 2018-04-13 16:56:38 --> Security Class Initialized
DEBUG - 2018-04-13 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:56:38 --> CSRF cookie sent
INFO - 2018-04-13 16:56:38 --> Input Class Initialized
INFO - 2018-04-13 16:56:38 --> Language Class Initialized
INFO - 2018-04-13 16:56:38 --> Loader Class Initialized
INFO - 2018-04-13 16:56:38 --> Helper loaded: url_helper
INFO - 2018-04-13 16:56:38 --> Helper loaded: form_helper
INFO - 2018-04-13 16:56:38 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:56:39 --> User Agent Class Initialized
INFO - 2018-04-13 16:56:39 --> Controller Class Initialized
INFO - 2018-04-13 16:56:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:56:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:56:39 --> Pixel_Model class loaded
INFO - 2018-04-13 16:56:39 --> Database Driver Class Initialized
INFO - 2018-04-13 16:56:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
ERROR - 2018-04-13 16:56:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given E:\www\yacopoo\application\libraries\Smart.php 415
INFO - 2018-04-13 16:56:39 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 16:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:56:39 --> Final output sent to browser
DEBUG - 2018-04-13 16:56:39 --> Total execution time: 0.5599
INFO - 2018-04-13 16:57:00 --> Config Class Initialized
INFO - 2018-04-13 16:57:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:00 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:00 --> URI Class Initialized
INFO - 2018-04-13 16:57:00 --> Router Class Initialized
INFO - 2018-04-13 16:57:00 --> Output Class Initialized
INFO - 2018-04-13 16:57:00 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:00 --> CSRF cookie sent
INFO - 2018-04-13 16:57:00 --> Input Class Initialized
INFO - 2018-04-13 16:57:00 --> Language Class Initialized
INFO - 2018-04-13 16:57:01 --> Loader Class Initialized
INFO - 2018-04-13 16:57:01 --> Helper loaded: url_helper
INFO - 2018-04-13 16:57:01 --> Helper loaded: form_helper
INFO - 2018-04-13 16:57:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:57:01 --> User Agent Class Initialized
INFO - 2018-04-13 16:57:01 --> Controller Class Initialized
INFO - 2018-04-13 16:57:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:57:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:57:01 --> Pixel_Model class loaded
INFO - 2018-04-13 16:57:01 --> Database Driver Class Initialized
INFO - 2018-04-13 16:57:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 16:57:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:57:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:57:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 16:57:04 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 16:57:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:57:04 --> Final output sent to browser
DEBUG - 2018-04-13 16:57:04 --> Total execution time: 3.4567
INFO - 2018-04-13 16:57:17 --> Config Class Initialized
INFO - 2018-04-13 16:57:17 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:17 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:17 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:17 --> URI Class Initialized
INFO - 2018-04-13 16:57:18 --> Router Class Initialized
INFO - 2018-04-13 16:57:18 --> Output Class Initialized
INFO - 2018-04-13 16:57:18 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:18 --> CSRF cookie sent
INFO - 2018-04-13 16:57:18 --> Input Class Initialized
INFO - 2018-04-13 16:57:18 --> Language Class Initialized
INFO - 2018-04-13 16:57:18 --> Loader Class Initialized
INFO - 2018-04-13 16:57:18 --> Helper loaded: url_helper
INFO - 2018-04-13 16:57:18 --> Helper loaded: form_helper
INFO - 2018-04-13 16:57:18 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:57:18 --> User Agent Class Initialized
INFO - 2018-04-13 16:57:18 --> Controller Class Initialized
INFO - 2018-04-13 16:57:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:57:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:57:18 --> Pixel_Model class loaded
INFO - 2018-04-13 16:57:18 --> Database Driver Class Initialized
INFO - 2018-04-13 16:57:18 --> Model "QuestionsModel" initialized
ERROR - 2018-04-13 16:57:18 --> Severity: Notice --> Undefined index: HTTP_REFERER E:\www\yacopoo\application\core\Pixel_Controller.php 87
INFO - 2018-04-13 16:57:18 --> Config Class Initialized
INFO - 2018-04-13 16:57:18 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:18 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:18 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:18 --> URI Class Initialized
DEBUG - 2018-04-13 16:57:18 --> No URI present. Default controller set.
INFO - 2018-04-13 16:57:18 --> Router Class Initialized
INFO - 2018-04-13 16:57:18 --> Output Class Initialized
INFO - 2018-04-13 16:57:18 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:18 --> CSRF cookie sent
INFO - 2018-04-13 16:57:18 --> Input Class Initialized
INFO - 2018-04-13 16:57:18 --> Language Class Initialized
INFO - 2018-04-13 16:57:18 --> Loader Class Initialized
INFO - 2018-04-13 16:57:18 --> Helper loaded: url_helper
INFO - 2018-04-13 16:57:18 --> Helper loaded: form_helper
INFO - 2018-04-13 16:57:18 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:57:18 --> User Agent Class Initialized
INFO - 2018-04-13 16:57:18 --> Controller Class Initialized
INFO - 2018-04-13 16:57:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:57:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:57:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:57:18 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 16:57:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:57:18 --> Final output sent to browser
DEBUG - 2018-04-13 16:57:18 --> Total execution time: 0.3974
INFO - 2018-04-13 16:57:20 --> Config Class Initialized
INFO - 2018-04-13 16:57:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:20 --> Config Class Initialized
INFO - 2018-04-13 16:57:20 --> Hooks Class Initialized
INFO - 2018-04-13 16:57:20 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:20 --> URI Class Initialized
DEBUG - 2018-04-13 16:57:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:20 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:20 --> Router Class Initialized
INFO - 2018-04-13 16:57:20 --> URI Class Initialized
INFO - 2018-04-13 16:57:20 --> Output Class Initialized
INFO - 2018-04-13 16:57:20 --> Router Class Initialized
INFO - 2018-04-13 16:57:20 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:20 --> Output Class Initialized
INFO - 2018-04-13 16:57:20 --> CSRF cookie sent
INFO - 2018-04-13 16:57:20 --> Security Class Initialized
INFO - 2018-04-13 16:57:20 --> Input Class Initialized
DEBUG - 2018-04-13 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:20 --> CSRF cookie sent
INFO - 2018-04-13 16:57:20 --> Language Class Initialized
INFO - 2018-04-13 16:57:20 --> Input Class Initialized
ERROR - 2018-04-13 16:57:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 16:57:20 --> Language Class Initialized
INFO - 2018-04-13 16:57:20 --> Loader Class Initialized
INFO - 2018-04-13 16:57:20 --> Helper loaded: url_helper
INFO - 2018-04-13 16:57:20 --> Helper loaded: form_helper
INFO - 2018-04-13 16:57:20 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:57:20 --> User Agent Class Initialized
INFO - 2018-04-13 16:57:20 --> Controller Class Initialized
INFO - 2018-04-13 16:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:57:20 --> Pixel_Model class loaded
INFO - 2018-04-13 16:57:20 --> Database Driver Class Initialized
INFO - 2018-04-13 16:57:20 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-13 16:57:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 16:57:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:57:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:57:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 16:57:21 --> Could not find the language line "req_email"
INFO - 2018-04-13 16:57:21 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-13 16:57:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:57:21 --> Final output sent to browser
DEBUG - 2018-04-13 16:57:21 --> Total execution time: 0.5276
INFO - 2018-04-13 16:57:26 --> Config Class Initialized
INFO - 2018-04-13 16:57:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:26 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:26 --> URI Class Initialized
INFO - 2018-04-13 16:57:26 --> Router Class Initialized
INFO - 2018-04-13 16:57:26 --> Output Class Initialized
INFO - 2018-04-13 16:57:26 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:26 --> CSRF cookie sent
INFO - 2018-04-13 16:57:26 --> Input Class Initialized
INFO - 2018-04-13 16:57:26 --> Language Class Initialized
ERROR - 2018-04-13 16:57:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 16:57:44 --> Config Class Initialized
INFO - 2018-04-13 16:57:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:44 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:44 --> URI Class Initialized
INFO - 2018-04-13 16:57:44 --> Router Class Initialized
INFO - 2018-04-13 16:57:44 --> Output Class Initialized
INFO - 2018-04-13 16:57:44 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:44 --> CSRF cookie sent
INFO - 2018-04-13 16:57:44 --> Input Class Initialized
INFO - 2018-04-13 16:57:44 --> Language Class Initialized
INFO - 2018-04-13 16:57:44 --> Loader Class Initialized
INFO - 2018-04-13 16:57:44 --> Helper loaded: url_helper
INFO - 2018-04-13 16:57:44 --> Helper loaded: form_helper
INFO - 2018-04-13 16:57:44 --> Helper loaded: language_helper
DEBUG - 2018-04-13 16:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:57:44 --> User Agent Class Initialized
INFO - 2018-04-13 16:57:44 --> Controller Class Initialized
INFO - 2018-04-13 16:57:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 16:57:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 16:57:44 --> Pixel_Model class loaded
INFO - 2018-04-13 16:57:44 --> Database Driver Class Initialized
INFO - 2018-04-13 16:57:44 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-13 16:57:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 16:57:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 16:57:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 16:57:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 16:57:44 --> Could not find the language line "req_email"
INFO - 2018-04-13 16:57:44 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-13 16:57:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 16:57:44 --> Final output sent to browser
DEBUG - 2018-04-13 16:57:44 --> Total execution time: 0.4410
INFO - 2018-04-13 16:57:45 --> Config Class Initialized
INFO - 2018-04-13 16:57:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 16:57:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 16:57:45 --> Utf8 Class Initialized
INFO - 2018-04-13 16:57:45 --> URI Class Initialized
INFO - 2018-04-13 16:57:45 --> Router Class Initialized
INFO - 2018-04-13 16:57:45 --> Output Class Initialized
INFO - 2018-04-13 16:57:45 --> Security Class Initialized
DEBUG - 2018-04-13 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 16:57:45 --> CSRF cookie sent
INFO - 2018-04-13 16:57:45 --> Input Class Initialized
INFO - 2018-04-13 16:57:45 --> Language Class Initialized
ERROR - 2018-04-13 16:57:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:00:22 --> Config Class Initialized
INFO - 2018-04-13 17:00:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:00:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:00:22 --> Utf8 Class Initialized
INFO - 2018-04-13 17:00:22 --> URI Class Initialized
INFO - 2018-04-13 17:00:22 --> Router Class Initialized
INFO - 2018-04-13 17:00:22 --> Output Class Initialized
INFO - 2018-04-13 17:00:22 --> Security Class Initialized
DEBUG - 2018-04-13 17:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:00:22 --> CSRF cookie sent
INFO - 2018-04-13 17:00:22 --> Input Class Initialized
INFO - 2018-04-13 17:00:22 --> Language Class Initialized
INFO - 2018-04-13 17:00:22 --> Loader Class Initialized
INFO - 2018-04-13 17:00:22 --> Helper loaded: url_helper
INFO - 2018-04-13 17:00:22 --> Helper loaded: form_helper
INFO - 2018-04-13 17:00:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:00:22 --> User Agent Class Initialized
INFO - 2018-04-13 17:00:22 --> Controller Class Initialized
INFO - 2018-04-13 17:00:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:00:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:00:22 --> Pixel_Model class loaded
INFO - 2018-04-13 17:00:22 --> Database Driver Class Initialized
INFO - 2018-04-13 17:00:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:00:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:00:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:00:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:00:25 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:00:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:00:26 --> Final output sent to browser
DEBUG - 2018-04-13 17:00:26 --> Total execution time: 3.4867
INFO - 2018-04-13 17:01:41 --> Config Class Initialized
INFO - 2018-04-13 17:01:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:01:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:01:41 --> Utf8 Class Initialized
INFO - 2018-04-13 17:01:41 --> URI Class Initialized
INFO - 2018-04-13 17:01:41 --> Router Class Initialized
INFO - 2018-04-13 17:01:41 --> Output Class Initialized
INFO - 2018-04-13 17:01:41 --> Security Class Initialized
DEBUG - 2018-04-13 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:01:41 --> CSRF cookie sent
INFO - 2018-04-13 17:01:41 --> Input Class Initialized
INFO - 2018-04-13 17:01:41 --> Language Class Initialized
INFO - 2018-04-13 17:01:41 --> Loader Class Initialized
INFO - 2018-04-13 17:01:41 --> Helper loaded: url_helper
INFO - 2018-04-13 17:01:41 --> Helper loaded: form_helper
INFO - 2018-04-13 17:01:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:01:41 --> User Agent Class Initialized
INFO - 2018-04-13 17:01:41 --> Controller Class Initialized
INFO - 2018-04-13 17:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:01:41 --> Pixel_Model class loaded
INFO - 2018-04-13 17:01:41 --> Database Driver Class Initialized
INFO - 2018-04-13 17:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:01:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:01:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:01:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:01:44 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:01:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:01:44 --> Final output sent to browser
DEBUG - 2018-04-13 17:01:44 --> Total execution time: 3.4742
INFO - 2018-04-13 17:02:26 --> Config Class Initialized
INFO - 2018-04-13 17:02:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:02:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:02:27 --> Utf8 Class Initialized
INFO - 2018-04-13 17:02:27 --> URI Class Initialized
INFO - 2018-04-13 17:02:27 --> Router Class Initialized
INFO - 2018-04-13 17:02:27 --> Output Class Initialized
INFO - 2018-04-13 17:02:27 --> Security Class Initialized
DEBUG - 2018-04-13 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:02:27 --> CSRF cookie sent
INFO - 2018-04-13 17:02:27 --> Input Class Initialized
INFO - 2018-04-13 17:02:27 --> Language Class Initialized
INFO - 2018-04-13 17:02:27 --> Loader Class Initialized
INFO - 2018-04-13 17:02:27 --> Helper loaded: url_helper
INFO - 2018-04-13 17:02:27 --> Helper loaded: form_helper
INFO - 2018-04-13 17:02:27 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:02:27 --> User Agent Class Initialized
INFO - 2018-04-13 17:02:27 --> Controller Class Initialized
INFO - 2018-04-13 17:02:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:02:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:02:27 --> Pixel_Model class loaded
INFO - 2018-04-13 17:02:27 --> Database Driver Class Initialized
INFO - 2018-04-13 17:02:27 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:02:27 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:02:27 --> Final output sent to browser
DEBUG - 2018-04-13 17:02:27 --> Total execution time: 0.4223
INFO - 2018-04-13 17:04:39 --> Config Class Initialized
INFO - 2018-04-13 17:04:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:04:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:04:39 --> Utf8 Class Initialized
INFO - 2018-04-13 17:04:39 --> URI Class Initialized
INFO - 2018-04-13 17:04:39 --> Router Class Initialized
INFO - 2018-04-13 17:04:39 --> Output Class Initialized
INFO - 2018-04-13 17:04:39 --> Security Class Initialized
DEBUG - 2018-04-13 17:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:04:39 --> CSRF cookie sent
INFO - 2018-04-13 17:04:39 --> CSRF token verified
INFO - 2018-04-13 17:04:39 --> Input Class Initialized
INFO - 2018-04-13 17:04:39 --> Language Class Initialized
INFO - 2018-04-13 17:04:39 --> Loader Class Initialized
INFO - 2018-04-13 17:04:39 --> Helper loaded: url_helper
INFO - 2018-04-13 17:04:39 --> Helper loaded: form_helper
INFO - 2018-04-13 17:04:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:04:39 --> User Agent Class Initialized
INFO - 2018-04-13 17:04:39 --> Controller Class Initialized
INFO - 2018-04-13 17:04:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:04:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:04:39 --> Pixel_Model class loaded
INFO - 2018-04-13 17:04:39 --> Database Driver Class Initialized
INFO - 2018-04-13 17:04:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:04:42 --> Form Validation Class Initialized
INFO - 2018-04-13 17:04:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 17:04:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-13 17:06:05 --> Config Class Initialized
INFO - 2018-04-13 17:06:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:06:05 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:06:05 --> Utf8 Class Initialized
INFO - 2018-04-13 17:06:05 --> URI Class Initialized
INFO - 2018-04-13 17:06:05 --> Router Class Initialized
INFO - 2018-04-13 17:06:05 --> Output Class Initialized
INFO - 2018-04-13 17:06:05 --> Security Class Initialized
DEBUG - 2018-04-13 17:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:06:05 --> CSRF cookie sent
INFO - 2018-04-13 17:06:05 --> Input Class Initialized
INFO - 2018-04-13 17:06:05 --> Language Class Initialized
INFO - 2018-04-13 17:06:05 --> Loader Class Initialized
INFO - 2018-04-13 17:06:05 --> Helper loaded: url_helper
INFO - 2018-04-13 17:06:05 --> Helper loaded: form_helper
INFO - 2018-04-13 17:06:05 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:06:05 --> User Agent Class Initialized
INFO - 2018-04-13 17:06:05 --> Controller Class Initialized
INFO - 2018-04-13 17:06:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:06:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:06:05 --> Pixel_Model class loaded
INFO - 2018-04-13 17:06:05 --> Database Driver Class Initialized
INFO - 2018-04-13 17:06:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:06:08 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:06:08 --> Final output sent to browser
DEBUG - 2018-04-13 17:06:08 --> Total execution time: 3.4387
INFO - 2018-04-13 17:06:19 --> Config Class Initialized
INFO - 2018-04-13 17:06:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:06:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:06:19 --> Utf8 Class Initialized
INFO - 2018-04-13 17:06:19 --> URI Class Initialized
INFO - 2018-04-13 17:06:19 --> Router Class Initialized
INFO - 2018-04-13 17:06:19 --> Output Class Initialized
INFO - 2018-04-13 17:06:19 --> Security Class Initialized
DEBUG - 2018-04-13 17:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:06:19 --> CSRF cookie sent
INFO - 2018-04-13 17:06:19 --> CSRF token verified
INFO - 2018-04-13 17:06:19 --> Input Class Initialized
INFO - 2018-04-13 17:06:19 --> Language Class Initialized
INFO - 2018-04-13 17:06:19 --> Loader Class Initialized
INFO - 2018-04-13 17:06:19 --> Helper loaded: url_helper
INFO - 2018-04-13 17:06:19 --> Helper loaded: form_helper
INFO - 2018-04-13 17:06:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:06:19 --> User Agent Class Initialized
INFO - 2018-04-13 17:06:19 --> Controller Class Initialized
INFO - 2018-04-13 17:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:06:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:06:19 --> Pixel_Model class loaded
INFO - 2018-04-13 17:06:19 --> Database Driver Class Initialized
INFO - 2018-04-13 17:06:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:06:19 --> Form Validation Class Initialized
INFO - 2018-04-13 17:06:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:07:34 --> Config Class Initialized
INFO - 2018-04-13 17:07:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:34 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:34 --> URI Class Initialized
INFO - 2018-04-13 17:07:34 --> Router Class Initialized
INFO - 2018-04-13 17:07:34 --> Output Class Initialized
INFO - 2018-04-13 17:07:34 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:34 --> CSRF cookie sent
INFO - 2018-04-13 17:07:34 --> CSRF token verified
INFO - 2018-04-13 17:07:34 --> Input Class Initialized
INFO - 2018-04-13 17:07:34 --> Language Class Initialized
INFO - 2018-04-13 17:07:34 --> Loader Class Initialized
INFO - 2018-04-13 17:07:34 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:34 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:34 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:34 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:34 --> Controller Class Initialized
INFO - 2018-04-13 17:07:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:34 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:34 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:37 --> Form Validation Class Initialized
INFO - 2018-04-13 17:07:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:07:37 --> Config Class Initialized
INFO - 2018-04-13 17:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:37 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:37 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:37 --> URI Class Initialized
INFO - 2018-04-13 17:07:37 --> Router Class Initialized
INFO - 2018-04-13 17:07:37 --> Output Class Initialized
INFO - 2018-04-13 17:07:37 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:37 --> CSRF cookie sent
INFO - 2018-04-13 17:07:37 --> Input Class Initialized
INFO - 2018-04-13 17:07:37 --> Language Class Initialized
INFO - 2018-04-13 17:07:37 --> Loader Class Initialized
INFO - 2018-04-13 17:07:37 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:37 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:37 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:37 --> Controller Class Initialized
INFO - 2018-04-13 17:07:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:37 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:37 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:07:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:07:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:07:38 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:07:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:07:38 --> Final output sent to browser
DEBUG - 2018-04-13 17:07:38 --> Total execution time: 0.3726
INFO - 2018-04-13 17:07:40 --> Config Class Initialized
INFO - 2018-04-13 17:07:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:40 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:40 --> URI Class Initialized
INFO - 2018-04-13 17:07:40 --> Router Class Initialized
INFO - 2018-04-13 17:07:40 --> Output Class Initialized
INFO - 2018-04-13 17:07:40 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:40 --> CSRF cookie sent
INFO - 2018-04-13 17:07:40 --> Input Class Initialized
INFO - 2018-04-13 17:07:40 --> Language Class Initialized
INFO - 2018-04-13 17:07:40 --> Loader Class Initialized
INFO - 2018-04-13 17:07:40 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:40 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:40 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:40 --> Controller Class Initialized
INFO - 2018-04-13 17:07:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:40 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:40 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:07:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:07:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:07:41 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:07:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:07:41 --> Final output sent to browser
DEBUG - 2018-04-13 17:07:41 --> Total execution time: 0.3863
INFO - 2018-04-13 17:07:48 --> Config Class Initialized
INFO - 2018-04-13 17:07:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:48 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:48 --> URI Class Initialized
INFO - 2018-04-13 17:07:48 --> Router Class Initialized
INFO - 2018-04-13 17:07:48 --> Output Class Initialized
INFO - 2018-04-13 17:07:48 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:48 --> CSRF cookie sent
INFO - 2018-04-13 17:07:48 --> CSRF token verified
INFO - 2018-04-13 17:07:48 --> Input Class Initialized
INFO - 2018-04-13 17:07:48 --> Language Class Initialized
INFO - 2018-04-13 17:07:48 --> Loader Class Initialized
INFO - 2018-04-13 17:07:48 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:48 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:49 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:49 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:49 --> Controller Class Initialized
INFO - 2018-04-13 17:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:49 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:49 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:49 --> Form Validation Class Initialized
INFO - 2018-04-13 17:07:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-13 17:07:49 --> Severity: Warning --> implode(): Invalid arguments passed E:\www\yacopoo\application\controllers\PayerReciepientController.php 301
INFO - 2018-04-13 17:07:49 --> Config Class Initialized
INFO - 2018-04-13 17:07:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:49 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:49 --> URI Class Initialized
INFO - 2018-04-13 17:07:49 --> Router Class Initialized
INFO - 2018-04-13 17:07:49 --> Output Class Initialized
INFO - 2018-04-13 17:07:49 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:49 --> CSRF cookie sent
INFO - 2018-04-13 17:07:49 --> Input Class Initialized
INFO - 2018-04-13 17:07:49 --> Language Class Initialized
INFO - 2018-04-13 17:07:49 --> Loader Class Initialized
INFO - 2018-04-13 17:07:49 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:49 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:49 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:49 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:49 --> Controller Class Initialized
INFO - 2018-04-13 17:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:49 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:49 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:07:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:07:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:07:49 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:07:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:07:49 --> Final output sent to browser
DEBUG - 2018-04-13 17:07:49 --> Total execution time: 0.3976
INFO - 2018-04-13 17:07:52 --> Config Class Initialized
INFO - 2018-04-13 17:07:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:52 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:52 --> URI Class Initialized
INFO - 2018-04-13 17:07:52 --> Router Class Initialized
INFO - 2018-04-13 17:07:52 --> Output Class Initialized
INFO - 2018-04-13 17:07:52 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:53 --> CSRF cookie sent
INFO - 2018-04-13 17:07:53 --> CSRF token verified
INFO - 2018-04-13 17:07:53 --> Input Class Initialized
INFO - 2018-04-13 17:07:53 --> Language Class Initialized
INFO - 2018-04-13 17:07:53 --> Loader Class Initialized
INFO - 2018-04-13 17:07:53 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:53 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:53 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:53 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:53 --> Controller Class Initialized
INFO - 2018-04-13 17:07:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:53 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:53 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:53 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:53 --> Form Validation Class Initialized
INFO - 2018-04-13 17:07:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:07:53 --> Config Class Initialized
INFO - 2018-04-13 17:07:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:07:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:07:53 --> Utf8 Class Initialized
INFO - 2018-04-13 17:07:53 --> URI Class Initialized
INFO - 2018-04-13 17:07:53 --> Router Class Initialized
INFO - 2018-04-13 17:07:53 --> Output Class Initialized
INFO - 2018-04-13 17:07:53 --> Security Class Initialized
DEBUG - 2018-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:07:53 --> CSRF cookie sent
INFO - 2018-04-13 17:07:53 --> Input Class Initialized
INFO - 2018-04-13 17:07:53 --> Language Class Initialized
INFO - 2018-04-13 17:07:53 --> Loader Class Initialized
INFO - 2018-04-13 17:07:53 --> Helper loaded: url_helper
INFO - 2018-04-13 17:07:53 --> Helper loaded: form_helper
INFO - 2018-04-13 17:07:53 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:07:53 --> User Agent Class Initialized
INFO - 2018-04-13 17:07:53 --> Controller Class Initialized
INFO - 2018-04-13 17:07:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:07:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:07:53 --> Pixel_Model class loaded
INFO - 2018-04-13 17:07:53 --> Database Driver Class Initialized
INFO - 2018-04-13 17:07:53 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:07:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:07:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:07:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:07:53 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:07:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:07:53 --> Final output sent to browser
DEBUG - 2018-04-13 17:07:53 --> Total execution time: 0.4026
INFO - 2018-04-13 17:08:01 --> Config Class Initialized
INFO - 2018-04-13 17:08:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:08:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:08:01 --> Utf8 Class Initialized
INFO - 2018-04-13 17:08:01 --> URI Class Initialized
INFO - 2018-04-13 17:08:01 --> Router Class Initialized
INFO - 2018-04-13 17:08:01 --> Output Class Initialized
INFO - 2018-04-13 17:08:01 --> Security Class Initialized
DEBUG - 2018-04-13 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:08:01 --> CSRF cookie sent
INFO - 2018-04-13 17:08:01 --> CSRF token verified
INFO - 2018-04-13 17:08:01 --> Input Class Initialized
INFO - 2018-04-13 17:08:01 --> Language Class Initialized
INFO - 2018-04-13 17:08:01 --> Loader Class Initialized
INFO - 2018-04-13 17:08:01 --> Helper loaded: url_helper
INFO - 2018-04-13 17:08:01 --> Helper loaded: form_helper
INFO - 2018-04-13 17:08:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:08:01 --> User Agent Class Initialized
INFO - 2018-04-13 17:08:01 --> Controller Class Initialized
INFO - 2018-04-13 17:08:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:08:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:08:01 --> Pixel_Model class loaded
INFO - 2018-04-13 17:08:01 --> Database Driver Class Initialized
INFO - 2018-04-13 17:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:08:01 --> Form Validation Class Initialized
INFO - 2018-04-13 17:08:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:08:02 --> Config Class Initialized
INFO - 2018-04-13 17:08:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:08:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:08:02 --> Utf8 Class Initialized
INFO - 2018-04-13 17:08:02 --> URI Class Initialized
INFO - 2018-04-13 17:08:02 --> Router Class Initialized
INFO - 2018-04-13 17:08:02 --> Output Class Initialized
INFO - 2018-04-13 17:08:02 --> Security Class Initialized
DEBUG - 2018-04-13 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:08:02 --> CSRF cookie sent
INFO - 2018-04-13 17:08:02 --> Input Class Initialized
INFO - 2018-04-13 17:08:02 --> Language Class Initialized
INFO - 2018-04-13 17:08:02 --> Loader Class Initialized
INFO - 2018-04-13 17:08:02 --> Helper loaded: url_helper
INFO - 2018-04-13 17:08:02 --> Helper loaded: form_helper
INFO - 2018-04-13 17:08:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:08:02 --> User Agent Class Initialized
INFO - 2018-04-13 17:08:02 --> Controller Class Initialized
INFO - 2018-04-13 17:08:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:08:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:08:02 --> Pixel_Model class loaded
INFO - 2018-04-13 17:08:02 --> Database Driver Class Initialized
INFO - 2018-04-13 17:08:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:08:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:08:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:08:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:08:02 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:08:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:08:02 --> Final output sent to browser
DEBUG - 2018-04-13 17:08:02 --> Total execution time: 0.3901
INFO - 2018-04-13 17:34:19 --> Config Class Initialized
INFO - 2018-04-13 17:34:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:19 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:19 --> URI Class Initialized
INFO - 2018-04-13 17:34:19 --> Router Class Initialized
INFO - 2018-04-13 17:34:19 --> Output Class Initialized
INFO - 2018-04-13 17:34:19 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:19 --> CSRF cookie sent
INFO - 2018-04-13 17:34:19 --> CSRF token verified
INFO - 2018-04-13 17:34:19 --> Input Class Initialized
INFO - 2018-04-13 17:34:19 --> Language Class Initialized
INFO - 2018-04-13 17:34:19 --> Loader Class Initialized
INFO - 2018-04-13 17:34:19 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:19 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:19 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:19 --> Controller Class Initialized
INFO - 2018-04-13 17:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:19 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:19 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:22 --> Form Validation Class Initialized
INFO - 2018-04-13 17:34:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:34:22 --> Config Class Initialized
INFO - 2018-04-13 17:34:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:23 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:23 --> URI Class Initialized
INFO - 2018-04-13 17:34:23 --> Router Class Initialized
INFO - 2018-04-13 17:34:23 --> Output Class Initialized
INFO - 2018-04-13 17:34:23 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:23 --> CSRF cookie sent
INFO - 2018-04-13 17:34:23 --> Input Class Initialized
INFO - 2018-04-13 17:34:23 --> Language Class Initialized
INFO - 2018-04-13 17:34:23 --> Loader Class Initialized
INFO - 2018-04-13 17:34:23 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:23 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:23 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:23 --> Controller Class Initialized
INFO - 2018-04-13 17:34:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:23 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:23 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:34:23 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:34:23 --> Final output sent to browser
DEBUG - 2018-04-13 17:34:23 --> Total execution time: 0.3969
INFO - 2018-04-13 17:34:47 --> Config Class Initialized
INFO - 2018-04-13 17:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:47 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:47 --> URI Class Initialized
INFO - 2018-04-13 17:34:47 --> Router Class Initialized
INFO - 2018-04-13 17:34:47 --> Output Class Initialized
INFO - 2018-04-13 17:34:47 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:47 --> CSRF cookie sent
INFO - 2018-04-13 17:34:47 --> CSRF token verified
INFO - 2018-04-13 17:34:47 --> Input Class Initialized
INFO - 2018-04-13 17:34:47 --> Language Class Initialized
INFO - 2018-04-13 17:34:47 --> Loader Class Initialized
INFO - 2018-04-13 17:34:47 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:47 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:47 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:47 --> Controller Class Initialized
INFO - 2018-04-13 17:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:47 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:47 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:47 --> Form Validation Class Initialized
INFO - 2018-04-13 17:34:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:34:47 --> Config Class Initialized
INFO - 2018-04-13 17:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:47 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:47 --> URI Class Initialized
INFO - 2018-04-13 17:34:47 --> Router Class Initialized
INFO - 2018-04-13 17:34:47 --> Output Class Initialized
INFO - 2018-04-13 17:34:47 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:47 --> CSRF cookie sent
INFO - 2018-04-13 17:34:47 --> Input Class Initialized
INFO - 2018-04-13 17:34:47 --> Language Class Initialized
INFO - 2018-04-13 17:34:47 --> Loader Class Initialized
INFO - 2018-04-13 17:34:47 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:47 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:47 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:47 --> Controller Class Initialized
INFO - 2018-04-13 17:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:47 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:47 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:34:47 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:34:47 --> Final output sent to browser
DEBUG - 2018-04-13 17:34:47 --> Total execution time: 0.4021
INFO - 2018-04-13 17:34:51 --> Config Class Initialized
INFO - 2018-04-13 17:34:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:51 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:51 --> URI Class Initialized
INFO - 2018-04-13 17:34:51 --> Router Class Initialized
INFO - 2018-04-13 17:34:51 --> Output Class Initialized
INFO - 2018-04-13 17:34:51 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:51 --> CSRF cookie sent
INFO - 2018-04-13 17:34:51 --> CSRF token verified
INFO - 2018-04-13 17:34:51 --> Input Class Initialized
INFO - 2018-04-13 17:34:51 --> Language Class Initialized
INFO - 2018-04-13 17:34:51 --> Loader Class Initialized
INFO - 2018-04-13 17:34:51 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:51 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:51 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:51 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:51 --> Controller Class Initialized
INFO - 2018-04-13 17:34:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:51 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:51 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:51 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:51 --> Form Validation Class Initialized
INFO - 2018-04-13 17:34:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:34:51 --> Config Class Initialized
INFO - 2018-04-13 17:34:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:34:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:34:51 --> Utf8 Class Initialized
INFO - 2018-04-13 17:34:51 --> URI Class Initialized
INFO - 2018-04-13 17:34:51 --> Router Class Initialized
INFO - 2018-04-13 17:34:52 --> Output Class Initialized
INFO - 2018-04-13 17:34:52 --> Security Class Initialized
DEBUG - 2018-04-13 17:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:34:52 --> CSRF cookie sent
INFO - 2018-04-13 17:34:52 --> Input Class Initialized
INFO - 2018-04-13 17:34:52 --> Language Class Initialized
INFO - 2018-04-13 17:34:52 --> Loader Class Initialized
INFO - 2018-04-13 17:34:52 --> Helper loaded: url_helper
INFO - 2018-04-13 17:34:52 --> Helper loaded: form_helper
INFO - 2018-04-13 17:34:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:34:52 --> User Agent Class Initialized
INFO - 2018-04-13 17:34:52 --> Controller Class Initialized
INFO - 2018-04-13 17:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:34:52 --> Pixel_Model class loaded
INFO - 2018-04-13 17:34:52 --> Database Driver Class Initialized
INFO - 2018-04-13 17:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:34:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:34:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:34:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:34:52 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:34:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:34:52 --> Final output sent to browser
DEBUG - 2018-04-13 17:34:52 --> Total execution time: 0.4095
INFO - 2018-04-13 17:35:22 --> Config Class Initialized
INFO - 2018-04-13 17:35:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:35:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:35:22 --> Utf8 Class Initialized
INFO - 2018-04-13 17:35:22 --> URI Class Initialized
INFO - 2018-04-13 17:35:22 --> Router Class Initialized
INFO - 2018-04-13 17:35:22 --> Output Class Initialized
INFO - 2018-04-13 17:35:22 --> Security Class Initialized
DEBUG - 2018-04-13 17:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:35:22 --> CSRF cookie sent
INFO - 2018-04-13 17:35:22 --> Input Class Initialized
INFO - 2018-04-13 17:35:22 --> Language Class Initialized
INFO - 2018-04-13 17:35:22 --> Loader Class Initialized
INFO - 2018-04-13 17:35:22 --> Helper loaded: url_helper
INFO - 2018-04-13 17:35:22 --> Helper loaded: form_helper
INFO - 2018-04-13 17:35:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:35:22 --> User Agent Class Initialized
INFO - 2018-04-13 17:35:22 --> Controller Class Initialized
INFO - 2018-04-13 17:35:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:35:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:35:22 --> Pixel_Model class loaded
INFO - 2018-04-13 17:35:22 --> Database Driver Class Initialized
INFO - 2018-04-13 17:35:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:35:25 --> File loaded: E:\www\yacopoo\application\views\questions/kids_activities.php
INFO - 2018-04-13 17:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:35:25 --> Final output sent to browser
DEBUG - 2018-04-13 17:35:25 --> Total execution time: 3.5012
INFO - 2018-04-13 17:35:27 --> Config Class Initialized
INFO - 2018-04-13 17:35:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:35:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:35:28 --> Utf8 Class Initialized
INFO - 2018-04-13 17:35:28 --> URI Class Initialized
INFO - 2018-04-13 17:35:28 --> Router Class Initialized
INFO - 2018-04-13 17:35:28 --> Output Class Initialized
INFO - 2018-04-13 17:35:28 --> Security Class Initialized
DEBUG - 2018-04-13 17:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:35:28 --> CSRF cookie sent
INFO - 2018-04-13 17:35:28 --> CSRF token verified
INFO - 2018-04-13 17:35:28 --> Input Class Initialized
INFO - 2018-04-13 17:35:28 --> Language Class Initialized
INFO - 2018-04-13 17:35:28 --> Loader Class Initialized
INFO - 2018-04-13 17:35:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:35:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:35:28 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:35:28 --> User Agent Class Initialized
INFO - 2018-04-13 17:35:28 --> Controller Class Initialized
INFO - 2018-04-13 17:35:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:35:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:35:28 --> Pixel_Model class loaded
INFO - 2018-04-13 17:35:28 --> Database Driver Class Initialized
INFO - 2018-04-13 17:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:35:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:35:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:35:28 --> Config Class Initialized
INFO - 2018-04-13 17:35:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:35:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:35:28 --> Utf8 Class Initialized
INFO - 2018-04-13 17:35:28 --> URI Class Initialized
INFO - 2018-04-13 17:35:28 --> Router Class Initialized
INFO - 2018-04-13 17:35:28 --> Output Class Initialized
INFO - 2018-04-13 17:35:28 --> Security Class Initialized
DEBUG - 2018-04-13 17:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:35:28 --> CSRF cookie sent
INFO - 2018-04-13 17:35:28 --> Input Class Initialized
INFO - 2018-04-13 17:35:28 --> Language Class Initialized
INFO - 2018-04-13 17:35:28 --> Loader Class Initialized
INFO - 2018-04-13 17:35:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:35:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:35:28 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:35:28 --> User Agent Class Initialized
INFO - 2018-04-13 17:35:28 --> Controller Class Initialized
INFO - 2018-04-13 17:35:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:35:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:35:28 --> Pixel_Model class loaded
INFO - 2018-04-13 17:35:28 --> Database Driver Class Initialized
INFO - 2018-04-13 17:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:35:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:35:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:35:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 22
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 32
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 38
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 44
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 22
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 32
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 38
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 44
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 22
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 32
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 38
ERROR - 2018-04-13 17:35:28 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 44
INFO - 2018-04-13 17:35:28 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:35:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:35:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:35:28 --> Total execution time: 0.5406
INFO - 2018-04-13 17:37:43 --> Config Class Initialized
INFO - 2018-04-13 17:37:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:37:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:37:43 --> Utf8 Class Initialized
INFO - 2018-04-13 17:37:43 --> URI Class Initialized
INFO - 2018-04-13 17:37:43 --> Router Class Initialized
INFO - 2018-04-13 17:37:43 --> Output Class Initialized
INFO - 2018-04-13 17:37:43 --> Security Class Initialized
DEBUG - 2018-04-13 17:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:37:43 --> CSRF cookie sent
INFO - 2018-04-13 17:37:43 --> Input Class Initialized
INFO - 2018-04-13 17:37:43 --> Language Class Initialized
INFO - 2018-04-13 17:37:43 --> Loader Class Initialized
INFO - 2018-04-13 17:37:43 --> Helper loaded: url_helper
INFO - 2018-04-13 17:37:43 --> Helper loaded: form_helper
INFO - 2018-04-13 17:37:43 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:37:43 --> User Agent Class Initialized
INFO - 2018-04-13 17:37:43 --> Controller Class Initialized
INFO - 2018-04-13 17:37:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:37:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:37:44 --> Pixel_Model class loaded
INFO - 2018-04-13 17:37:44 --> Database Driver Class Initialized
INFO - 2018-04-13 17:37:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:37:47 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:37:47 --> Final output sent to browser
DEBUG - 2018-04-13 17:37:47 --> Total execution time: 3.5107
INFO - 2018-04-13 17:38:02 --> Config Class Initialized
INFO - 2018-04-13 17:38:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:38:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:38:02 --> Utf8 Class Initialized
INFO - 2018-04-13 17:38:02 --> URI Class Initialized
INFO - 2018-04-13 17:38:02 --> Router Class Initialized
INFO - 2018-04-13 17:38:02 --> Output Class Initialized
INFO - 2018-04-13 17:38:02 --> Security Class Initialized
DEBUG - 2018-04-13 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:38:02 --> CSRF cookie sent
INFO - 2018-04-13 17:38:02 --> Input Class Initialized
INFO - 2018-04-13 17:38:02 --> Language Class Initialized
INFO - 2018-04-13 17:38:02 --> Loader Class Initialized
INFO - 2018-04-13 17:38:02 --> Helper loaded: url_helper
INFO - 2018-04-13 17:38:02 --> Helper loaded: form_helper
INFO - 2018-04-13 17:38:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:38:02 --> User Agent Class Initialized
INFO - 2018-04-13 17:38:02 --> Controller Class Initialized
INFO - 2018-04-13 17:38:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:38:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:38:02 --> Pixel_Model class loaded
INFO - 2018-04-13 17:38:02 --> Database Driver Class Initialized
INFO - 2018-04-13 17:38:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:38:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:38:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:38:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:38:02 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:38:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:38:02 --> Final output sent to browser
DEBUG - 2018-04-13 17:38:02 --> Total execution time: 0.4324
INFO - 2018-04-13 17:38:23 --> Config Class Initialized
INFO - 2018-04-13 17:38:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:38:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:38:23 --> Utf8 Class Initialized
INFO - 2018-04-13 17:38:23 --> URI Class Initialized
INFO - 2018-04-13 17:38:23 --> Router Class Initialized
INFO - 2018-04-13 17:38:23 --> Output Class Initialized
INFO - 2018-04-13 17:38:23 --> Security Class Initialized
DEBUG - 2018-04-13 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:38:23 --> CSRF cookie sent
INFO - 2018-04-13 17:38:23 --> Input Class Initialized
INFO - 2018-04-13 17:38:23 --> Language Class Initialized
INFO - 2018-04-13 17:38:23 --> Loader Class Initialized
INFO - 2018-04-13 17:38:23 --> Helper loaded: url_helper
INFO - 2018-04-13 17:38:23 --> Helper loaded: form_helper
INFO - 2018-04-13 17:38:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:38:23 --> User Agent Class Initialized
INFO - 2018-04-13 17:38:23 --> Controller Class Initialized
INFO - 2018-04-13 17:38:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:38:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:38:23 --> Pixel_Model class loaded
INFO - 2018-04-13 17:38:23 --> Database Driver Class Initialized
INFO - 2018-04-13 17:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:38:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:38:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:38:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:38:23 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:38:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:38:23 --> Final output sent to browser
DEBUG - 2018-04-13 17:38:23 --> Total execution time: 0.4161
INFO - 2018-04-13 17:38:51 --> Config Class Initialized
INFO - 2018-04-13 17:38:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:38:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:38:51 --> Utf8 Class Initialized
INFO - 2018-04-13 17:38:51 --> URI Class Initialized
INFO - 2018-04-13 17:38:51 --> Router Class Initialized
INFO - 2018-04-13 17:38:51 --> Output Class Initialized
INFO - 2018-04-13 17:38:51 --> Security Class Initialized
DEBUG - 2018-04-13 17:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:38:51 --> CSRF cookie sent
INFO - 2018-04-13 17:38:51 --> Input Class Initialized
INFO - 2018-04-13 17:38:51 --> Language Class Initialized
INFO - 2018-04-13 17:38:51 --> Loader Class Initialized
INFO - 2018-04-13 17:38:51 --> Helper loaded: url_helper
INFO - 2018-04-13 17:38:51 --> Helper loaded: form_helper
INFO - 2018-04-13 17:38:51 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:38:51 --> User Agent Class Initialized
INFO - 2018-04-13 17:38:51 --> Controller Class Initialized
INFO - 2018-04-13 17:38:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:38:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:38:51 --> Pixel_Model class loaded
INFO - 2018-04-13 17:38:51 --> Database Driver Class Initialized
INFO - 2018-04-13 17:38:51 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:38:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:38:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:38:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:38:51 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:38:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:38:51 --> Final output sent to browser
DEBUG - 2018-04-13 17:38:51 --> Total execution time: 0.4195
INFO - 2018-04-13 17:39:11 --> Config Class Initialized
INFO - 2018-04-13 17:39:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:39:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:39:11 --> Utf8 Class Initialized
INFO - 2018-04-13 17:39:11 --> URI Class Initialized
INFO - 2018-04-13 17:39:11 --> Router Class Initialized
INFO - 2018-04-13 17:39:11 --> Output Class Initialized
INFO - 2018-04-13 17:39:11 --> Security Class Initialized
DEBUG - 2018-04-13 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:39:11 --> CSRF cookie sent
INFO - 2018-04-13 17:39:11 --> Input Class Initialized
INFO - 2018-04-13 17:39:11 --> Language Class Initialized
INFO - 2018-04-13 17:39:11 --> Loader Class Initialized
INFO - 2018-04-13 17:39:11 --> Helper loaded: url_helper
INFO - 2018-04-13 17:39:12 --> Helper loaded: form_helper
INFO - 2018-04-13 17:39:12 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:39:12 --> User Agent Class Initialized
INFO - 2018-04-13 17:39:12 --> Controller Class Initialized
INFO - 2018-04-13 17:39:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:39:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:39:12 --> Pixel_Model class loaded
INFO - 2018-04-13 17:39:12 --> Database Driver Class Initialized
INFO - 2018-04-13 17:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:39:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:39:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:39:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:39:15 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:39:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:39:15 --> Final output sent to browser
DEBUG - 2018-04-13 17:39:15 --> Total execution time: 3.5521
INFO - 2018-04-13 17:39:32 --> Config Class Initialized
INFO - 2018-04-13 17:39:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:39:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:39:32 --> Utf8 Class Initialized
INFO - 2018-04-13 17:39:32 --> URI Class Initialized
INFO - 2018-04-13 17:39:32 --> Router Class Initialized
INFO - 2018-04-13 17:39:32 --> Output Class Initialized
INFO - 2018-04-13 17:39:32 --> Security Class Initialized
DEBUG - 2018-04-13 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:39:32 --> CSRF cookie sent
INFO - 2018-04-13 17:39:32 --> Input Class Initialized
INFO - 2018-04-13 17:39:32 --> Language Class Initialized
INFO - 2018-04-13 17:39:32 --> Loader Class Initialized
INFO - 2018-04-13 17:39:32 --> Helper loaded: url_helper
INFO - 2018-04-13 17:39:32 --> Helper loaded: form_helper
INFO - 2018-04-13 17:39:32 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:39:32 --> User Agent Class Initialized
INFO - 2018-04-13 17:39:32 --> Controller Class Initialized
INFO - 2018-04-13 17:39:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:39:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:39:32 --> Pixel_Model class loaded
INFO - 2018-04-13 17:39:32 --> Database Driver Class Initialized
INFO - 2018-04-13 17:39:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:39:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:39:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:39:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:39:32 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:39:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:39:32 --> Final output sent to browser
DEBUG - 2018-04-13 17:39:32 --> Total execution time: 0.4601
INFO - 2018-04-13 17:40:26 --> Config Class Initialized
INFO - 2018-04-13 17:40:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:40:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:40:26 --> Utf8 Class Initialized
INFO - 2018-04-13 17:40:26 --> URI Class Initialized
INFO - 2018-04-13 17:40:26 --> Router Class Initialized
INFO - 2018-04-13 17:40:26 --> Output Class Initialized
INFO - 2018-04-13 17:40:26 --> Security Class Initialized
DEBUG - 2018-04-13 17:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:40:26 --> CSRF cookie sent
INFO - 2018-04-13 17:40:26 --> Input Class Initialized
INFO - 2018-04-13 17:40:26 --> Language Class Initialized
INFO - 2018-04-13 17:40:26 --> Loader Class Initialized
INFO - 2018-04-13 17:40:26 --> Helper loaded: url_helper
INFO - 2018-04-13 17:40:26 --> Helper loaded: form_helper
INFO - 2018-04-13 17:40:26 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:40:26 --> User Agent Class Initialized
INFO - 2018-04-13 17:40:26 --> Controller Class Initialized
INFO - 2018-04-13 17:40:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:40:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:40:26 --> Pixel_Model class loaded
INFO - 2018-04-13 17:40:26 --> Database Driver Class Initialized
INFO - 2018-04-13 17:40:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:40:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:40:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:40:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:40:27 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:40:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:40:27 --> Final output sent to browser
DEBUG - 2018-04-13 17:40:27 --> Total execution time: 0.4930
INFO - 2018-04-13 17:40:31 --> Config Class Initialized
INFO - 2018-04-13 17:40:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:40:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:40:31 --> Utf8 Class Initialized
INFO - 2018-04-13 17:40:31 --> URI Class Initialized
INFO - 2018-04-13 17:40:31 --> Router Class Initialized
INFO - 2018-04-13 17:40:31 --> Output Class Initialized
INFO - 2018-04-13 17:40:31 --> Security Class Initialized
DEBUG - 2018-04-13 17:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:40:31 --> CSRF cookie sent
INFO - 2018-04-13 17:40:31 --> Input Class Initialized
INFO - 2018-04-13 17:40:31 --> Language Class Initialized
INFO - 2018-04-13 17:40:31 --> Loader Class Initialized
INFO - 2018-04-13 17:40:31 --> Helper loaded: url_helper
INFO - 2018-04-13 17:40:31 --> Helper loaded: form_helper
INFO - 2018-04-13 17:40:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:40:31 --> User Agent Class Initialized
INFO - 2018-04-13 17:40:31 --> Controller Class Initialized
INFO - 2018-04-13 17:40:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:40:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:40:31 --> Pixel_Model class loaded
INFO - 2018-04-13 17:40:31 --> Database Driver Class Initialized
INFO - 2018-04-13 17:40:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:40:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:40:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:40:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:40:31 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:40:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:40:31 --> Final output sent to browser
DEBUG - 2018-04-13 17:40:31 --> Total execution time: 0.4388
INFO - 2018-04-13 17:40:36 --> Config Class Initialized
INFO - 2018-04-13 17:40:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:40:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:40:36 --> Utf8 Class Initialized
INFO - 2018-04-13 17:40:36 --> URI Class Initialized
INFO - 2018-04-13 17:40:36 --> Router Class Initialized
INFO - 2018-04-13 17:40:36 --> Output Class Initialized
INFO - 2018-04-13 17:40:36 --> Security Class Initialized
DEBUG - 2018-04-13 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:40:36 --> CSRF cookie sent
INFO - 2018-04-13 17:40:36 --> Input Class Initialized
INFO - 2018-04-13 17:40:36 --> Language Class Initialized
ERROR - 2018-04-13 17:40:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:42:54 --> Config Class Initialized
INFO - 2018-04-13 17:42:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:42:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:42:54 --> Utf8 Class Initialized
INFO - 2018-04-13 17:42:54 --> URI Class Initialized
INFO - 2018-04-13 17:42:54 --> Router Class Initialized
INFO - 2018-04-13 17:42:54 --> Output Class Initialized
INFO - 2018-04-13 17:42:54 --> Security Class Initialized
DEBUG - 2018-04-13 17:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:42:54 --> CSRF cookie sent
INFO - 2018-04-13 17:42:54 --> Input Class Initialized
INFO - 2018-04-13 17:42:54 --> Language Class Initialized
INFO - 2018-04-13 17:42:54 --> Loader Class Initialized
INFO - 2018-04-13 17:42:54 --> Helper loaded: url_helper
INFO - 2018-04-13 17:42:54 --> Helper loaded: form_helper
INFO - 2018-04-13 17:42:54 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:42:54 --> User Agent Class Initialized
INFO - 2018-04-13 17:42:54 --> Controller Class Initialized
INFO - 2018-04-13 17:42:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:42:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:42:54 --> Pixel_Model class loaded
INFO - 2018-04-13 17:42:54 --> Database Driver Class Initialized
INFO - 2018-04-13 17:42:57 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:42:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:42:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:42:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:42:57 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:42:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:42:57 --> Final output sent to browser
DEBUG - 2018-04-13 17:42:57 --> Total execution time: 3.4527
INFO - 2018-04-13 17:42:58 --> Config Class Initialized
INFO - 2018-04-13 17:42:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:42:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:42:58 --> Utf8 Class Initialized
INFO - 2018-04-13 17:42:58 --> URI Class Initialized
INFO - 2018-04-13 17:42:58 --> Router Class Initialized
INFO - 2018-04-13 17:42:58 --> Output Class Initialized
INFO - 2018-04-13 17:42:58 --> Security Class Initialized
DEBUG - 2018-04-13 17:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:42:58 --> CSRF cookie sent
INFO - 2018-04-13 17:42:58 --> Input Class Initialized
INFO - 2018-04-13 17:42:58 --> Language Class Initialized
ERROR - 2018-04-13 17:42:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:54:05 --> Config Class Initialized
INFO - 2018-04-13 17:54:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:54:05 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:54:05 --> Utf8 Class Initialized
INFO - 2018-04-13 17:54:05 --> URI Class Initialized
INFO - 2018-04-13 17:54:05 --> Router Class Initialized
INFO - 2018-04-13 17:54:05 --> Output Class Initialized
INFO - 2018-04-13 17:54:05 --> Security Class Initialized
DEBUG - 2018-04-13 17:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:54:05 --> CSRF cookie sent
INFO - 2018-04-13 17:54:05 --> Input Class Initialized
INFO - 2018-04-13 17:54:05 --> Language Class Initialized
INFO - 2018-04-13 17:54:05 --> Loader Class Initialized
INFO - 2018-04-13 17:54:05 --> Helper loaded: url_helper
INFO - 2018-04-13 17:54:05 --> Helper loaded: form_helper
INFO - 2018-04-13 17:54:05 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:54:05 --> User Agent Class Initialized
INFO - 2018-04-13 17:54:05 --> Controller Class Initialized
INFO - 2018-04-13 17:54:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:54:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:54:05 --> Pixel_Model class loaded
INFO - 2018-04-13 17:54:05 --> Database Driver Class Initialized
INFO - 2018-04-13 17:54:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:54:08 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:54:08 --> Final output sent to browser
DEBUG - 2018-04-13 17:54:08 --> Total execution time: 3.4741
INFO - 2018-04-13 17:54:09 --> Config Class Initialized
INFO - 2018-04-13 17:54:09 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:54:09 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:54:09 --> Utf8 Class Initialized
INFO - 2018-04-13 17:54:09 --> URI Class Initialized
INFO - 2018-04-13 17:54:09 --> Router Class Initialized
INFO - 2018-04-13 17:54:09 --> Output Class Initialized
INFO - 2018-04-13 17:54:09 --> Security Class Initialized
DEBUG - 2018-04-13 17:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:54:09 --> CSRF cookie sent
INFO - 2018-04-13 17:54:09 --> Input Class Initialized
INFO - 2018-04-13 17:54:09 --> Language Class Initialized
ERROR - 2018-04-13 17:54:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:55:01 --> Config Class Initialized
INFO - 2018-04-13 17:55:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:55:01 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:01 --> URI Class Initialized
INFO - 2018-04-13 17:55:01 --> Router Class Initialized
INFO - 2018-04-13 17:55:01 --> Output Class Initialized
INFO - 2018-04-13 17:55:01 --> Security Class Initialized
DEBUG - 2018-04-13 17:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:55:01 --> CSRF cookie sent
INFO - 2018-04-13 17:55:01 --> CSRF token verified
INFO - 2018-04-13 17:55:01 --> Input Class Initialized
INFO - 2018-04-13 17:55:01 --> Language Class Initialized
INFO - 2018-04-13 17:55:01 --> Loader Class Initialized
INFO - 2018-04-13 17:55:01 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:01 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:01 --> User Agent Class Initialized
INFO - 2018-04-13 17:55:01 --> Controller Class Initialized
INFO - 2018-04-13 17:55:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:55:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:55:01 --> Pixel_Model class loaded
INFO - 2018-04-13 17:55:01 --> Database Driver Class Initialized
INFO - 2018-04-13 17:55:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:55:04 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-13 17:55:05 --> Severity: Error --> Call to undefined method PayerReciepientController::createKids() E:\www\yacopoo\application\controllers\PayerReciepientController.php 311
INFO - 2018-04-13 17:55:26 --> Config Class Initialized
INFO - 2018-04-13 17:55:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:55:26 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:26 --> URI Class Initialized
INFO - 2018-04-13 17:55:26 --> Router Class Initialized
INFO - 2018-04-13 17:55:26 --> Output Class Initialized
INFO - 2018-04-13 17:55:26 --> Security Class Initialized
DEBUG - 2018-04-13 17:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:55:26 --> CSRF cookie sent
INFO - 2018-04-13 17:55:26 --> CSRF token verified
INFO - 2018-04-13 17:55:26 --> Input Class Initialized
INFO - 2018-04-13 17:55:26 --> Language Class Initialized
INFO - 2018-04-13 17:55:26 --> Loader Class Initialized
INFO - 2018-04-13 17:55:26 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:26 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:26 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:26 --> User Agent Class Initialized
INFO - 2018-04-13 17:55:26 --> Controller Class Initialized
INFO - 2018-04-13 17:55:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:55:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:55:26 --> Pixel_Model class loaded
INFO - 2018-04-13 17:55:26 --> Database Driver Class Initialized
INFO - 2018-04-13 17:55:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:55:26 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:55:27 --> Config Class Initialized
INFO - 2018-04-13 17:55:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:55:27 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:27 --> URI Class Initialized
INFO - 2018-04-13 17:55:27 --> Router Class Initialized
INFO - 2018-04-13 17:55:27 --> Output Class Initialized
INFO - 2018-04-13 17:55:27 --> Security Class Initialized
DEBUG - 2018-04-13 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:55:27 --> CSRF cookie sent
INFO - 2018-04-13 17:55:27 --> Input Class Initialized
INFO - 2018-04-13 17:55:27 --> Language Class Initialized
INFO - 2018-04-13 17:55:27 --> Loader Class Initialized
INFO - 2018-04-13 17:55:27 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:27 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:27 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:27 --> User Agent Class Initialized
INFO - 2018-04-13 17:55:27 --> Controller Class Initialized
INFO - 2018-04-13 17:55:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:55:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:55:27 --> Pixel_Model class loaded
INFO - 2018-04-13 17:55:27 --> Database Driver Class Initialized
INFO - 2018-04-13 17:55:27 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:55:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:55:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:55:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:55:27 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:55:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:55:27 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:27 --> Total execution time: 0.4296
INFO - 2018-04-13 17:55:27 --> Config Class Initialized
INFO - 2018-04-13 17:55:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:55:27 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:27 --> URI Class Initialized
INFO - 2018-04-13 17:55:28 --> Router Class Initialized
INFO - 2018-04-13 17:55:28 --> Output Class Initialized
INFO - 2018-04-13 17:55:28 --> Security Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:55:28 --> CSRF cookie sent
INFO - 2018-04-13 17:55:28 --> Input Class Initialized
INFO - 2018-04-13 17:55:28 --> Language Class Initialized
ERROR - 2018-04-13 17:55:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:56:33 --> Config Class Initialized
INFO - 2018-04-13 17:56:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:56:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:56:33 --> Utf8 Class Initialized
INFO - 2018-04-13 17:56:33 --> URI Class Initialized
INFO - 2018-04-13 17:56:33 --> Router Class Initialized
INFO - 2018-04-13 17:56:33 --> Output Class Initialized
INFO - 2018-04-13 17:56:33 --> Security Class Initialized
DEBUG - 2018-04-13 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:56:33 --> CSRF cookie sent
INFO - 2018-04-13 17:56:33 --> CSRF token verified
INFO - 2018-04-13 17:56:33 --> Input Class Initialized
INFO - 2018-04-13 17:56:33 --> Language Class Initialized
INFO - 2018-04-13 17:56:33 --> Loader Class Initialized
INFO - 2018-04-13 17:56:33 --> Helper loaded: url_helper
INFO - 2018-04-13 17:56:33 --> Helper loaded: form_helper
INFO - 2018-04-13 17:56:33 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:56:33 --> User Agent Class Initialized
INFO - 2018-04-13 17:56:33 --> Controller Class Initialized
INFO - 2018-04-13 17:56:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:56:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:56:33 --> Pixel_Model class loaded
INFO - 2018-04-13 17:56:33 --> Database Driver Class Initialized
INFO - 2018-04-13 17:56:33 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:56:33 --> Form Validation Class Initialized
INFO - 2018-04-13 17:56:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:56:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 17:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-13 17:56:34 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:56:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:56:34 --> Final output sent to browser
DEBUG - 2018-04-13 17:56:34 --> Total execution time: 1.1829
INFO - 2018-04-13 17:56:35 --> Config Class Initialized
INFO - 2018-04-13 17:56:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:56:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:56:35 --> Utf8 Class Initialized
INFO - 2018-04-13 17:56:35 --> URI Class Initialized
INFO - 2018-04-13 17:56:35 --> Router Class Initialized
INFO - 2018-04-13 17:56:35 --> Output Class Initialized
INFO - 2018-04-13 17:56:35 --> Security Class Initialized
DEBUG - 2018-04-13 17:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:56:35 --> CSRF cookie sent
INFO - 2018-04-13 17:56:35 --> Input Class Initialized
INFO - 2018-04-13 17:56:35 --> Language Class Initialized
ERROR - 2018-04-13 17:56:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:57:31 --> Config Class Initialized
INFO - 2018-04-13 17:57:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:57:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:57:31 --> Utf8 Class Initialized
INFO - 2018-04-13 17:57:31 --> URI Class Initialized
INFO - 2018-04-13 17:57:31 --> Router Class Initialized
INFO - 2018-04-13 17:57:31 --> Output Class Initialized
INFO - 2018-04-13 17:57:31 --> Security Class Initialized
DEBUG - 2018-04-13 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:57:31 --> CSRF cookie sent
INFO - 2018-04-13 17:57:31 --> CSRF token verified
INFO - 2018-04-13 17:57:31 --> Input Class Initialized
INFO - 2018-04-13 17:57:31 --> Language Class Initialized
INFO - 2018-04-13 17:57:31 --> Loader Class Initialized
INFO - 2018-04-13 17:57:31 --> Helper loaded: url_helper
INFO - 2018-04-13 17:57:31 --> Helper loaded: form_helper
INFO - 2018-04-13 17:57:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:57:31 --> User Agent Class Initialized
INFO - 2018-04-13 17:57:31 --> Controller Class Initialized
INFO - 2018-04-13 17:57:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:57:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:57:31 --> Pixel_Model class loaded
INFO - 2018-04-13 17:57:31 --> Database Driver Class Initialized
INFO - 2018-04-13 17:57:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:57:34 --> Form Validation Class Initialized
INFO - 2018-04-13 17:57:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 17:57:35 --> Config Class Initialized
INFO - 2018-04-13 17:57:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:57:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:57:35 --> Utf8 Class Initialized
INFO - 2018-04-13 17:57:35 --> URI Class Initialized
INFO - 2018-04-13 17:57:35 --> Router Class Initialized
INFO - 2018-04-13 17:57:35 --> Output Class Initialized
INFO - 2018-04-13 17:57:35 --> Security Class Initialized
DEBUG - 2018-04-13 17:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:57:35 --> CSRF cookie sent
INFO - 2018-04-13 17:57:35 --> Input Class Initialized
INFO - 2018-04-13 17:57:35 --> Language Class Initialized
INFO - 2018-04-13 17:57:35 --> Loader Class Initialized
INFO - 2018-04-13 17:57:35 --> Helper loaded: url_helper
INFO - 2018-04-13 17:57:35 --> Helper loaded: form_helper
INFO - 2018-04-13 17:57:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:57:35 --> User Agent Class Initialized
INFO - 2018-04-13 17:57:35 --> Controller Class Initialized
INFO - 2018-04-13 17:57:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:57:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:57:35 --> Pixel_Model class loaded
INFO - 2018-04-13 17:57:35 --> Database Driver Class Initialized
INFO - 2018-04-13 17:57:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 33
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 39
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 45
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 1 E:\www\yacopoo\application\views\questions\kids_info.php 23
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 23
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 1 E:\www\yacopoo\application\views\questions\kids_info.php 33
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 33
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 1 E:\www\yacopoo\application\views\questions\kids_info.php 39
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 39
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 1 E:\www\yacopoo\application\views\questions\kids_info.php 45
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 45
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 2 E:\www\yacopoo\application\views\questions\kids_info.php 23
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 23
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 2 E:\www\yacopoo\application\views\questions\kids_info.php 33
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 33
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 2 E:\www\yacopoo\application\views\questions\kids_info.php 39
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 39
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Undefined offset: 2 E:\www\yacopoo\application\views\questions\kids_info.php 45
ERROR - 2018-04-13 17:57:35 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\kids_info.php 45
INFO - 2018-04-13 17:57:35 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 17:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 17:57:35 --> Final output sent to browser
DEBUG - 2018-04-13 17:57:35 --> Total execution time: 0.7187
INFO - 2018-04-13 17:57:36 --> Config Class Initialized
INFO - 2018-04-13 17:57:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:57:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:57:36 --> Utf8 Class Initialized
INFO - 2018-04-13 17:57:36 --> URI Class Initialized
INFO - 2018-04-13 17:57:36 --> Router Class Initialized
INFO - 2018-04-13 17:57:36 --> Output Class Initialized
INFO - 2018-04-13 17:57:36 --> Security Class Initialized
DEBUG - 2018-04-13 17:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:57:36 --> CSRF cookie sent
INFO - 2018-04-13 17:57:36 --> Input Class Initialized
INFO - 2018-04-13 17:57:36 --> Language Class Initialized
ERROR - 2018-04-13 17:57:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 17:59:28 --> Config Class Initialized
INFO - 2018-04-13 17:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 17:59:28 --> Utf8 Class Initialized
INFO - 2018-04-13 17:59:28 --> URI Class Initialized
INFO - 2018-04-13 17:59:28 --> Router Class Initialized
INFO - 2018-04-13 17:59:28 --> Output Class Initialized
INFO - 2018-04-13 17:59:28 --> Security Class Initialized
DEBUG - 2018-04-13 17:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 17:59:28 --> CSRF cookie sent
INFO - 2018-04-13 17:59:28 --> Input Class Initialized
INFO - 2018-04-13 17:59:28 --> Language Class Initialized
INFO - 2018-04-13 17:59:28 --> Loader Class Initialized
INFO - 2018-04-13 17:59:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:59:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:59:28 --> Helper loaded: language_helper
DEBUG - 2018-04-13 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:59:28 --> User Agent Class Initialized
INFO - 2018-04-13 17:59:28 --> Controller Class Initialized
INFO - 2018-04-13 17:59:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 17:59:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 17:59:28 --> Pixel_Model class loaded
INFO - 2018-04-13 17:59:28 --> Database Driver Class Initialized
INFO - 2018-04-13 17:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 17:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 17:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 17:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 18:00:21 --> Config Class Initialized
INFO - 2018-04-13 18:00:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:00:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:00:21 --> Utf8 Class Initialized
INFO - 2018-04-13 18:00:21 --> URI Class Initialized
INFO - 2018-04-13 18:00:21 --> Router Class Initialized
INFO - 2018-04-13 18:00:21 --> Output Class Initialized
INFO - 2018-04-13 18:00:21 --> Security Class Initialized
DEBUG - 2018-04-13 18:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:00:21 --> CSRF cookie sent
INFO - 2018-04-13 18:00:21 --> Input Class Initialized
INFO - 2018-04-13 18:00:21 --> Language Class Initialized
INFO - 2018-04-13 18:00:21 --> Loader Class Initialized
INFO - 2018-04-13 18:00:21 --> Helper loaded: url_helper
INFO - 2018-04-13 18:00:21 --> Helper loaded: form_helper
INFO - 2018-04-13 18:00:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:00:21 --> User Agent Class Initialized
INFO - 2018-04-13 18:00:21 --> Controller Class Initialized
INFO - 2018-04-13 18:00:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:00:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:00:21 --> Pixel_Model class loaded
INFO - 2018-04-13 18:00:21 --> Database Driver Class Initialized
INFO - 2018-04-13 18:00:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:00:21 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
INFO - 2018-04-13 18:00:21 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:00:21 --> Final output sent to browser
DEBUG - 2018-04-13 18:00:21 --> Total execution time: 0.5826
INFO - 2018-04-13 18:00:22 --> Config Class Initialized
INFO - 2018-04-13 18:00:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:00:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:00:22 --> Utf8 Class Initialized
INFO - 2018-04-13 18:00:22 --> URI Class Initialized
INFO - 2018-04-13 18:00:22 --> Router Class Initialized
INFO - 2018-04-13 18:00:22 --> Output Class Initialized
INFO - 2018-04-13 18:00:22 --> Security Class Initialized
DEBUG - 2018-04-13 18:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:00:22 --> CSRF cookie sent
INFO - 2018-04-13 18:00:22 --> Input Class Initialized
INFO - 2018-04-13 18:00:22 --> Language Class Initialized
ERROR - 2018-04-13 18:00:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:01:02 --> Config Class Initialized
INFO - 2018-04-13 18:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:01:02 --> Utf8 Class Initialized
INFO - 2018-04-13 18:01:02 --> URI Class Initialized
INFO - 2018-04-13 18:01:02 --> Router Class Initialized
INFO - 2018-04-13 18:01:02 --> Output Class Initialized
INFO - 2018-04-13 18:01:02 --> Security Class Initialized
DEBUG - 2018-04-13 18:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:01:02 --> CSRF cookie sent
INFO - 2018-04-13 18:01:02 --> Input Class Initialized
INFO - 2018-04-13 18:01:02 --> Language Class Initialized
INFO - 2018-04-13 18:01:02 --> Loader Class Initialized
INFO - 2018-04-13 18:01:02 --> Helper loaded: url_helper
INFO - 2018-04-13 18:01:02 --> Helper loaded: form_helper
INFO - 2018-04-13 18:01:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:01:02 --> User Agent Class Initialized
INFO - 2018-04-13 18:01:03 --> Controller Class Initialized
INFO - 2018-04-13 18:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:01:03 --> Pixel_Model class loaded
INFO - 2018-04-13 18:01:03 --> Database Driver Class Initialized
INFO - 2018-04-13 18:01:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:01:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:01:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:01:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:06 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
INFO - 2018-04-13 18:01:06 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:01:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:01:06 --> Final output sent to browser
DEBUG - 2018-04-13 18:01:06 --> Total execution time: 3.6139
INFO - 2018-04-13 18:01:06 --> Config Class Initialized
INFO - 2018-04-13 18:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:01:06 --> Utf8 Class Initialized
INFO - 2018-04-13 18:01:06 --> URI Class Initialized
INFO - 2018-04-13 18:01:06 --> Router Class Initialized
INFO - 2018-04-13 18:01:06 --> Output Class Initialized
INFO - 2018-04-13 18:01:06 --> Security Class Initialized
DEBUG - 2018-04-13 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:01:06 --> CSRF cookie sent
INFO - 2018-04-13 18:01:06 --> Input Class Initialized
INFO - 2018-04-13 18:01:06 --> Language Class Initialized
ERROR - 2018-04-13 18:01:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:01:53 --> Config Class Initialized
INFO - 2018-04-13 18:01:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:01:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:01:53 --> Utf8 Class Initialized
INFO - 2018-04-13 18:01:53 --> URI Class Initialized
INFO - 2018-04-13 18:01:53 --> Router Class Initialized
INFO - 2018-04-13 18:01:53 --> Output Class Initialized
INFO - 2018-04-13 18:01:53 --> Security Class Initialized
DEBUG - 2018-04-13 18:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:01:53 --> CSRF cookie sent
INFO - 2018-04-13 18:01:53 --> Input Class Initialized
INFO - 2018-04-13 18:01:53 --> Language Class Initialized
INFO - 2018-04-13 18:01:53 --> Loader Class Initialized
INFO - 2018-04-13 18:01:53 --> Helper loaded: url_helper
INFO - 2018-04-13 18:01:53 --> Helper loaded: form_helper
INFO - 2018-04-13 18:01:53 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:01:54 --> User Agent Class Initialized
INFO - 2018-04-13 18:01:54 --> Controller Class Initialized
INFO - 2018-04-13 18:01:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:01:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:01:54 --> Pixel_Model class loaded
INFO - 2018-04-13 18:01:54 --> Database Driver Class Initialized
INFO - 2018-04-13 18:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:01:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:01:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:01:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:01:54 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
INFO - 2018-04-13 18:01:54 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:01:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:01:54 --> Final output sent to browser
DEBUG - 2018-04-13 18:01:54 --> Total execution time: 0.6376
INFO - 2018-04-13 18:01:54 --> Config Class Initialized
INFO - 2018-04-13 18:01:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:01:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:01:54 --> Utf8 Class Initialized
INFO - 2018-04-13 18:01:54 --> URI Class Initialized
INFO - 2018-04-13 18:01:54 --> Router Class Initialized
INFO - 2018-04-13 18:01:54 --> Output Class Initialized
INFO - 2018-04-13 18:01:54 --> Security Class Initialized
DEBUG - 2018-04-13 18:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:01:55 --> CSRF cookie sent
INFO - 2018-04-13 18:01:55 --> Input Class Initialized
INFO - 2018-04-13 18:01:55 --> Language Class Initialized
ERROR - 2018-04-13 18:01:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:02:26 --> Config Class Initialized
INFO - 2018-04-13 18:02:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:02:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:02:26 --> Utf8 Class Initialized
INFO - 2018-04-13 18:02:26 --> URI Class Initialized
INFO - 2018-04-13 18:02:26 --> Router Class Initialized
INFO - 2018-04-13 18:02:26 --> Output Class Initialized
INFO - 2018-04-13 18:02:26 --> Security Class Initialized
DEBUG - 2018-04-13 18:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:02:26 --> CSRF cookie sent
INFO - 2018-04-13 18:02:26 --> Input Class Initialized
INFO - 2018-04-13 18:02:26 --> Language Class Initialized
INFO - 2018-04-13 18:02:26 --> Loader Class Initialized
INFO - 2018-04-13 18:02:26 --> Helper loaded: url_helper
INFO - 2018-04-13 18:02:26 --> Helper loaded: form_helper
INFO - 2018-04-13 18:02:26 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:02:27 --> User Agent Class Initialized
INFO - 2018-04-13 18:02:27 --> Controller Class Initialized
INFO - 2018-04-13 18:02:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:02:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:02:27 --> Pixel_Model class loaded
INFO - 2018-04-13 18:02:27 --> Database Driver Class Initialized
INFO - 2018-04-13 18:02:27 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 25
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 25
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 25
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:27 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
INFO - 2018-04-13 18:02:27 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:02:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:02:27 --> Final output sent to browser
DEBUG - 2018-04-13 18:02:27 --> Total execution time: 0.6702
INFO - 2018-04-13 18:02:27 --> Config Class Initialized
INFO - 2018-04-13 18:02:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:02:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:02:27 --> Utf8 Class Initialized
INFO - 2018-04-13 18:02:27 --> URI Class Initialized
INFO - 2018-04-13 18:02:27 --> Router Class Initialized
INFO - 2018-04-13 18:02:27 --> Output Class Initialized
INFO - 2018-04-13 18:02:27 --> Security Class Initialized
DEBUG - 2018-04-13 18:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:02:27 --> CSRF cookie sent
INFO - 2018-04-13 18:02:27 --> Input Class Initialized
INFO - 2018-04-13 18:02:27 --> Language Class Initialized
ERROR - 2018-04-13 18:02:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:02:50 --> Config Class Initialized
INFO - 2018-04-13 18:02:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:02:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:02:50 --> Utf8 Class Initialized
INFO - 2018-04-13 18:02:50 --> URI Class Initialized
INFO - 2018-04-13 18:02:50 --> Router Class Initialized
INFO - 2018-04-13 18:02:50 --> Output Class Initialized
INFO - 2018-04-13 18:02:50 --> Security Class Initialized
DEBUG - 2018-04-13 18:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:02:50 --> CSRF cookie sent
INFO - 2018-04-13 18:02:50 --> Input Class Initialized
INFO - 2018-04-13 18:02:50 --> Language Class Initialized
INFO - 2018-04-13 18:02:50 --> Loader Class Initialized
INFO - 2018-04-13 18:02:50 --> Helper loaded: url_helper
INFO - 2018-04-13 18:02:50 --> Helper loaded: form_helper
INFO - 2018-04-13 18:02:50 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:02:50 --> User Agent Class Initialized
INFO - 2018-04-13 18:02:50 --> Controller Class Initialized
INFO - 2018-04-13 18:02:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:02:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:02:50 --> Pixel_Model class loaded
INFO - 2018-04-13 18:02:50 --> Database Driver Class Initialized
INFO - 2018-04-13 18:02:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:02:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:02:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:02:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 30
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 36
ERROR - 2018-04-13 18:02:50 --> Severity: Notice --> A non well formed numeric value encountered E:\www\yacopoo\application\views\questions\kids_info.php 42
INFO - 2018-04-13 18:02:50 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:02:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:02:50 --> Final output sent to browser
DEBUG - 2018-04-13 18:02:50 --> Total execution time: 0.6973
INFO - 2018-04-13 18:02:51 --> Config Class Initialized
INFO - 2018-04-13 18:02:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:02:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:02:51 --> Utf8 Class Initialized
INFO - 2018-04-13 18:02:51 --> URI Class Initialized
INFO - 2018-04-13 18:02:51 --> Router Class Initialized
INFO - 2018-04-13 18:02:51 --> Output Class Initialized
INFO - 2018-04-13 18:02:51 --> Security Class Initialized
DEBUG - 2018-04-13 18:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:02:51 --> CSRF cookie sent
INFO - 2018-04-13 18:02:51 --> Input Class Initialized
INFO - 2018-04-13 18:02:51 --> Language Class Initialized
ERROR - 2018-04-13 18:02:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:03:51 --> Config Class Initialized
INFO - 2018-04-13 18:03:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:03:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:03:51 --> Utf8 Class Initialized
INFO - 2018-04-13 18:03:51 --> URI Class Initialized
INFO - 2018-04-13 18:03:51 --> Router Class Initialized
INFO - 2018-04-13 18:03:51 --> Output Class Initialized
INFO - 2018-04-13 18:03:51 --> Security Class Initialized
DEBUG - 2018-04-13 18:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:03:51 --> CSRF cookie sent
INFO - 2018-04-13 18:03:51 --> Input Class Initialized
INFO - 2018-04-13 18:03:51 --> Language Class Initialized
INFO - 2018-04-13 18:03:52 --> Loader Class Initialized
INFO - 2018-04-13 18:03:52 --> Helper loaded: url_helper
INFO - 2018-04-13 18:03:52 --> Helper loaded: form_helper
INFO - 2018-04-13 18:03:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:03:52 --> User Agent Class Initialized
INFO - 2018-04-13 18:03:52 --> Controller Class Initialized
INFO - 2018-04-13 18:03:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:03:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:03:52 --> Pixel_Model class loaded
INFO - 2018-04-13 18:03:52 --> Database Driver Class Initialized
INFO - 2018-04-13 18:03:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 18:03:55 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:03:55 --> Final output sent to browser
DEBUG - 2018-04-13 18:03:55 --> Total execution time: 3.5279
INFO - 2018-04-13 18:03:55 --> Config Class Initialized
INFO - 2018-04-13 18:03:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:03:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:03:55 --> Utf8 Class Initialized
INFO - 2018-04-13 18:03:55 --> URI Class Initialized
INFO - 2018-04-13 18:03:55 --> Router Class Initialized
INFO - 2018-04-13 18:03:55 --> Output Class Initialized
INFO - 2018-04-13 18:03:55 --> Security Class Initialized
DEBUG - 2018-04-13 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:03:55 --> CSRF cookie sent
INFO - 2018-04-13 18:03:55 --> Input Class Initialized
INFO - 2018-04-13 18:03:55 --> Language Class Initialized
ERROR - 2018-04-13 18:03:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:04:10 --> Config Class Initialized
INFO - 2018-04-13 18:04:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:10 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:10 --> URI Class Initialized
INFO - 2018-04-13 18:04:10 --> Router Class Initialized
INFO - 2018-04-13 18:04:10 --> Output Class Initialized
INFO - 2018-04-13 18:04:10 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:10 --> CSRF cookie sent
INFO - 2018-04-13 18:04:10 --> CSRF token verified
INFO - 2018-04-13 18:04:10 --> Input Class Initialized
INFO - 2018-04-13 18:04:10 --> Language Class Initialized
INFO - 2018-04-13 18:04:10 --> Loader Class Initialized
INFO - 2018-04-13 18:04:10 --> Helper loaded: url_helper
INFO - 2018-04-13 18:04:10 --> Helper loaded: form_helper
INFO - 2018-04-13 18:04:10 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:04:10 --> User Agent Class Initialized
INFO - 2018-04-13 18:04:10 --> Controller Class Initialized
INFO - 2018-04-13 18:04:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:04:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:04:10 --> Pixel_Model class loaded
INFO - 2018-04-13 18:04:10 --> Database Driver Class Initialized
INFO - 2018-04-13 18:04:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:04:10 --> Form Validation Class Initialized
INFO - 2018-04-13 18:04:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 18:04:10 --> Config Class Initialized
INFO - 2018-04-13 18:04:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:10 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:10 --> URI Class Initialized
INFO - 2018-04-13 18:04:10 --> Router Class Initialized
INFO - 2018-04-13 18:04:10 --> Output Class Initialized
INFO - 2018-04-13 18:04:10 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:10 --> CSRF cookie sent
INFO - 2018-04-13 18:04:10 --> Input Class Initialized
INFO - 2018-04-13 18:04:10 --> Language Class Initialized
INFO - 2018-04-13 18:04:10 --> Loader Class Initialized
INFO - 2018-04-13 18:04:10 --> Helper loaded: url_helper
INFO - 2018-04-13 18:04:10 --> Helper loaded: form_helper
INFO - 2018-04-13 18:04:10 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:04:11 --> User Agent Class Initialized
INFO - 2018-04-13 18:04:11 --> Controller Class Initialized
INFO - 2018-04-13 18:04:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:04:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:04:11 --> Pixel_Model class loaded
INFO - 2018-04-13 18:04:11 --> Database Driver Class Initialized
INFO - 2018-04-13 18:04:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:04:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:04:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:04:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 18:04:11 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:04:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:04:11 --> Final output sent to browser
DEBUG - 2018-04-13 18:04:11 --> Total execution time: 0.5079
INFO - 2018-04-13 18:04:11 --> Config Class Initialized
INFO - 2018-04-13 18:04:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:11 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:11 --> URI Class Initialized
INFO - 2018-04-13 18:04:11 --> Router Class Initialized
INFO - 2018-04-13 18:04:11 --> Output Class Initialized
INFO - 2018-04-13 18:04:11 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:11 --> CSRF cookie sent
INFO - 2018-04-13 18:04:11 --> Input Class Initialized
INFO - 2018-04-13 18:04:11 --> Language Class Initialized
ERROR - 2018-04-13 18:04:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 18:04:22 --> Config Class Initialized
INFO - 2018-04-13 18:04:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:22 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:22 --> URI Class Initialized
INFO - 2018-04-13 18:04:22 --> Router Class Initialized
INFO - 2018-04-13 18:04:22 --> Output Class Initialized
INFO - 2018-04-13 18:04:22 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:22 --> CSRF cookie sent
INFO - 2018-04-13 18:04:22 --> CSRF token verified
INFO - 2018-04-13 18:04:22 --> Input Class Initialized
INFO - 2018-04-13 18:04:22 --> Language Class Initialized
INFO - 2018-04-13 18:04:22 --> Loader Class Initialized
INFO - 2018-04-13 18:04:22 --> Helper loaded: url_helper
INFO - 2018-04-13 18:04:22 --> Helper loaded: form_helper
INFO - 2018-04-13 18:04:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:04:22 --> User Agent Class Initialized
INFO - 2018-04-13 18:04:22 --> Controller Class Initialized
INFO - 2018-04-13 18:04:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:04:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:04:22 --> Pixel_Model class loaded
INFO - 2018-04-13 18:04:22 --> Database Driver Class Initialized
INFO - 2018-04-13 18:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:04:22 --> Form Validation Class Initialized
INFO - 2018-04-13 18:04:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 18:04:22 --> Config Class Initialized
INFO - 2018-04-13 18:04:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:22 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:22 --> URI Class Initialized
INFO - 2018-04-13 18:04:22 --> Router Class Initialized
INFO - 2018-04-13 18:04:22 --> Output Class Initialized
INFO - 2018-04-13 18:04:22 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:22 --> CSRF cookie sent
INFO - 2018-04-13 18:04:22 --> Input Class Initialized
INFO - 2018-04-13 18:04:23 --> Language Class Initialized
INFO - 2018-04-13 18:04:23 --> Loader Class Initialized
INFO - 2018-04-13 18:04:23 --> Helper loaded: url_helper
INFO - 2018-04-13 18:04:23 --> Helper loaded: form_helper
INFO - 2018-04-13 18:04:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 18:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:04:23 --> User Agent Class Initialized
INFO - 2018-04-13 18:04:23 --> Controller Class Initialized
INFO - 2018-04-13 18:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 18:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 18:04:23 --> Pixel_Model class loaded
INFO - 2018-04-13 18:04:23 --> Database Driver Class Initialized
INFO - 2018-04-13 18:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 18:04:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 18:04:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 18:04:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 18:04:23 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 18:04:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 18:04:23 --> Final output sent to browser
DEBUG - 2018-04-13 18:04:23 --> Total execution time: 0.6286
INFO - 2018-04-13 18:04:23 --> Config Class Initialized
INFO - 2018-04-13 18:04:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 18:04:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 18:04:24 --> Utf8 Class Initialized
INFO - 2018-04-13 18:04:24 --> URI Class Initialized
INFO - 2018-04-13 18:04:24 --> Router Class Initialized
INFO - 2018-04-13 18:04:24 --> Output Class Initialized
INFO - 2018-04-13 18:04:24 --> Security Class Initialized
DEBUG - 2018-04-13 18:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 18:04:24 --> CSRF cookie sent
INFO - 2018-04-13 18:04:24 --> Input Class Initialized
INFO - 2018-04-13 18:04:24 --> Language Class Initialized
ERROR - 2018-04-13 18:04:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:00:55 --> Config Class Initialized
INFO - 2018-04-13 19:00:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:00:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:00:55 --> Utf8 Class Initialized
INFO - 2018-04-13 19:00:55 --> URI Class Initialized
INFO - 2018-04-13 19:00:55 --> Router Class Initialized
INFO - 2018-04-13 19:00:55 --> Output Class Initialized
INFO - 2018-04-13 19:00:55 --> Security Class Initialized
DEBUG - 2018-04-13 19:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:00:55 --> CSRF cookie sent
INFO - 2018-04-13 19:00:55 --> Input Class Initialized
INFO - 2018-04-13 19:00:55 --> Language Class Initialized
ERROR - 2018-04-13 19:00:55 --> Severity: Compile Error --> Cannot redeclare PayerReciepientController::kidsDoctorInfoPage() E:\www\yacopoo\application\controllers\PayerReciepientController.php 504
INFO - 2018-04-13 19:01:18 --> Config Class Initialized
INFO - 2018-04-13 19:01:18 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:01:18 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:01:18 --> Utf8 Class Initialized
INFO - 2018-04-13 19:01:18 --> URI Class Initialized
INFO - 2018-04-13 19:01:18 --> Router Class Initialized
INFO - 2018-04-13 19:01:18 --> Output Class Initialized
INFO - 2018-04-13 19:01:18 --> Security Class Initialized
DEBUG - 2018-04-13 19:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:01:18 --> CSRF cookie sent
INFO - 2018-04-13 19:01:18 --> Input Class Initialized
INFO - 2018-04-13 19:01:18 --> Language Class Initialized
INFO - 2018-04-13 19:01:18 --> Loader Class Initialized
INFO - 2018-04-13 19:01:18 --> Helper loaded: url_helper
INFO - 2018-04-13 19:01:18 --> Helper loaded: form_helper
INFO - 2018-04-13 19:01:18 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:01:18 --> User Agent Class Initialized
INFO - 2018-04-13 19:01:18 --> Controller Class Initialized
INFO - 2018-04-13 19:01:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:01:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:01:18 --> Pixel_Model class loaded
INFO - 2018-04-13 19:01:18 --> Database Driver Class Initialized
INFO - 2018-04-13 19:01:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:01:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:01:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:01:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:01:21 --> File loaded: E:\www\yacopoo\application\views\questions/kids_communicate.php
INFO - 2018-04-13 19:01:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:01:21 --> Final output sent to browser
DEBUG - 2018-04-13 19:01:21 --> Total execution time: 3.5003
INFO - 2018-04-13 19:01:21 --> Config Class Initialized
INFO - 2018-04-13 19:01:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:01:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:01:21 --> Utf8 Class Initialized
INFO - 2018-04-13 19:01:21 --> URI Class Initialized
INFO - 2018-04-13 19:01:21 --> Router Class Initialized
INFO - 2018-04-13 19:01:21 --> Output Class Initialized
INFO - 2018-04-13 19:01:21 --> Security Class Initialized
DEBUG - 2018-04-13 19:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:01:22 --> CSRF cookie sent
INFO - 2018-04-13 19:01:22 --> Input Class Initialized
INFO - 2018-04-13 19:01:22 --> Language Class Initialized
ERROR - 2018-04-13 19:01:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:01:39 --> Config Class Initialized
INFO - 2018-04-13 19:01:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:01:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:01:39 --> Utf8 Class Initialized
INFO - 2018-04-13 19:01:39 --> URI Class Initialized
INFO - 2018-04-13 19:01:39 --> Router Class Initialized
INFO - 2018-04-13 19:01:39 --> Output Class Initialized
INFO - 2018-04-13 19:01:39 --> Security Class Initialized
DEBUG - 2018-04-13 19:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:01:39 --> CSRF cookie sent
INFO - 2018-04-13 19:01:39 --> CSRF token verified
INFO - 2018-04-13 19:01:39 --> Input Class Initialized
INFO - 2018-04-13 19:01:39 --> Language Class Initialized
INFO - 2018-04-13 19:01:39 --> Loader Class Initialized
INFO - 2018-04-13 19:01:39 --> Helper loaded: url_helper
INFO - 2018-04-13 19:01:39 --> Helper loaded: form_helper
INFO - 2018-04-13 19:01:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:01:39 --> User Agent Class Initialized
INFO - 2018-04-13 19:01:39 --> Controller Class Initialized
INFO - 2018-04-13 19:01:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:01:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:01:39 --> Pixel_Model class loaded
INFO - 2018-04-13 19:01:39 --> Database Driver Class Initialized
INFO - 2018-04-13 19:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:01:39 --> Form Validation Class Initialized
INFO - 2018-04-13 19:01:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:01:39 --> Config Class Initialized
INFO - 2018-04-13 19:01:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:01:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:01:39 --> Utf8 Class Initialized
INFO - 2018-04-13 19:01:39 --> URI Class Initialized
INFO - 2018-04-13 19:01:39 --> Router Class Initialized
INFO - 2018-04-13 19:01:39 --> Output Class Initialized
INFO - 2018-04-13 19:01:39 --> Security Class Initialized
DEBUG - 2018-04-13 19:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:01:39 --> CSRF cookie sent
INFO - 2018-04-13 19:01:39 --> Input Class Initialized
INFO - 2018-04-13 19:01:39 --> Language Class Initialized
INFO - 2018-04-13 19:01:39 --> Loader Class Initialized
INFO - 2018-04-13 19:01:39 --> Helper loaded: url_helper
INFO - 2018-04-13 19:01:39 --> Helper loaded: form_helper
INFO - 2018-04-13 19:01:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:01:39 --> User Agent Class Initialized
INFO - 2018-04-13 19:01:39 --> Controller Class Initialized
INFO - 2018-04-13 19:01:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:01:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:01:39 --> Pixel_Model class loaded
INFO - 2018-04-13 19:01:39 --> Database Driver Class Initialized
INFO - 2018-04-13 19:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:01:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:01:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:01:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:01:39 --> File loaded: E:\www\yacopoo\application\views\questions/kids_dinner.php
INFO - 2018-04-13 19:01:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:01:39 --> Final output sent to browser
DEBUG - 2018-04-13 19:01:39 --> Total execution time: 0.4336
INFO - 2018-04-13 19:01:40 --> Config Class Initialized
INFO - 2018-04-13 19:01:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:01:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:01:40 --> Utf8 Class Initialized
INFO - 2018-04-13 19:01:40 --> URI Class Initialized
INFO - 2018-04-13 19:01:40 --> Router Class Initialized
INFO - 2018-04-13 19:01:40 --> Output Class Initialized
INFO - 2018-04-13 19:01:40 --> Security Class Initialized
DEBUG - 2018-04-13 19:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:01:40 --> CSRF cookie sent
INFO - 2018-04-13 19:01:40 --> Input Class Initialized
INFO - 2018-04-13 19:01:40 --> Language Class Initialized
ERROR - 2018-04-13 19:01:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:06 --> Config Class Initialized
INFO - 2018-04-13 19:02:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:06 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:06 --> URI Class Initialized
INFO - 2018-04-13 19:02:06 --> Router Class Initialized
INFO - 2018-04-13 19:02:06 --> Output Class Initialized
INFO - 2018-04-13 19:02:06 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:06 --> CSRF cookie sent
INFO - 2018-04-13 19:02:06 --> Input Class Initialized
INFO - 2018-04-13 19:02:06 --> Language Class Initialized
INFO - 2018-04-13 19:02:06 --> Loader Class Initialized
INFO - 2018-04-13 19:02:06 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:06 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:06 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:06 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:06 --> Controller Class Initialized
INFO - 2018-04-13 19:02:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:06 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:06 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:02:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:02:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:02:06 --> File loaded: E:\www\yacopoo\application\views\questions/kids_dinner.php
INFO - 2018-04-13 19:02:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:02:06 --> Final output sent to browser
DEBUG - 2018-04-13 19:02:06 --> Total execution time: 0.4652
INFO - 2018-04-13 19:02:07 --> Config Class Initialized
INFO - 2018-04-13 19:02:07 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:07 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:07 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:07 --> URI Class Initialized
INFO - 2018-04-13 19:02:07 --> Router Class Initialized
INFO - 2018-04-13 19:02:07 --> Output Class Initialized
INFO - 2018-04-13 19:02:07 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:07 --> CSRF cookie sent
INFO - 2018-04-13 19:02:07 --> Input Class Initialized
INFO - 2018-04-13 19:02:07 --> Language Class Initialized
ERROR - 2018-04-13 19:02:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:30 --> Config Class Initialized
INFO - 2018-04-13 19:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:30 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:30 --> URI Class Initialized
INFO - 2018-04-13 19:02:30 --> Router Class Initialized
INFO - 2018-04-13 19:02:30 --> Output Class Initialized
INFO - 2018-04-13 19:02:30 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:30 --> CSRF cookie sent
INFO - 2018-04-13 19:02:30 --> Input Class Initialized
INFO - 2018-04-13 19:02:30 --> Language Class Initialized
INFO - 2018-04-13 19:02:30 --> Loader Class Initialized
INFO - 2018-04-13 19:02:30 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:30 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:30 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:30 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:30 --> Controller Class Initialized
INFO - 2018-04-13 19:02:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:30 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:30 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:30 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:02:31 --> File loaded: E:\www\yacopoo\application\views\questions/kids_dinner.php
INFO - 2018-04-13 19:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:02:31 --> Final output sent to browser
DEBUG - 2018-04-13 19:02:31 --> Total execution time: 0.4909
INFO - 2018-04-13 19:02:31 --> Config Class Initialized
INFO - 2018-04-13 19:02:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:31 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:31 --> URI Class Initialized
INFO - 2018-04-13 19:02:31 --> Router Class Initialized
INFO - 2018-04-13 19:02:31 --> Output Class Initialized
INFO - 2018-04-13 19:02:31 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:31 --> CSRF cookie sent
INFO - 2018-04-13 19:02:31 --> Input Class Initialized
INFO - 2018-04-13 19:02:31 --> Language Class Initialized
ERROR - 2018-04-13 19:02:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:33 --> Config Class Initialized
INFO - 2018-04-13 19:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:33 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:34 --> URI Class Initialized
INFO - 2018-04-13 19:02:34 --> Router Class Initialized
INFO - 2018-04-13 19:02:34 --> Output Class Initialized
INFO - 2018-04-13 19:02:34 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:34 --> CSRF cookie sent
INFO - 2018-04-13 19:02:34 --> CSRF token verified
INFO - 2018-04-13 19:02:34 --> Input Class Initialized
INFO - 2018-04-13 19:02:34 --> Language Class Initialized
INFO - 2018-04-13 19:02:34 --> Loader Class Initialized
INFO - 2018-04-13 19:02:34 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:34 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:34 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:34 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:34 --> Controller Class Initialized
INFO - 2018-04-13 19:02:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:34 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:34 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:34 --> Form Validation Class Initialized
INFO - 2018-04-13 19:02:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:02:34 --> Config Class Initialized
INFO - 2018-04-13 19:02:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:34 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:34 --> URI Class Initialized
INFO - 2018-04-13 19:02:34 --> Router Class Initialized
INFO - 2018-04-13 19:02:34 --> Output Class Initialized
INFO - 2018-04-13 19:02:34 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:34 --> CSRF cookie sent
INFO - 2018-04-13 19:02:34 --> Input Class Initialized
INFO - 2018-04-13 19:02:34 --> Language Class Initialized
INFO - 2018-04-13 19:02:34 --> Loader Class Initialized
INFO - 2018-04-13 19:02:34 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:34 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:34 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:34 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:34 --> Controller Class Initialized
INFO - 2018-04-13 19:02:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:34 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:34 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:02:34 --> File loaded: E:\www\yacopoo\application\views\questions/kids_homework.php
INFO - 2018-04-13 19:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:02:34 --> Final output sent to browser
DEBUG - 2018-04-13 19:02:34 --> Total execution time: 0.4447
INFO - 2018-04-13 19:02:35 --> Config Class Initialized
INFO - 2018-04-13 19:02:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:35 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:35 --> URI Class Initialized
INFO - 2018-04-13 19:02:35 --> Router Class Initialized
INFO - 2018-04-13 19:02:35 --> Output Class Initialized
INFO - 2018-04-13 19:02:35 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:35 --> CSRF cookie sent
INFO - 2018-04-13 19:02:35 --> Input Class Initialized
INFO - 2018-04-13 19:02:35 --> Language Class Initialized
ERROR - 2018-04-13 19:02:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:37 --> Config Class Initialized
INFO - 2018-04-13 19:02:37 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:37 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:37 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:37 --> URI Class Initialized
INFO - 2018-04-13 19:02:37 --> Router Class Initialized
INFO - 2018-04-13 19:02:37 --> Output Class Initialized
INFO - 2018-04-13 19:02:37 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:37 --> CSRF cookie sent
INFO - 2018-04-13 19:02:37 --> Input Class Initialized
INFO - 2018-04-13 19:02:37 --> Language Class Initialized
INFO - 2018-04-13 19:02:37 --> Loader Class Initialized
INFO - 2018-04-13 19:02:37 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:37 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:37 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:37 --> Controller Class Initialized
INFO - 2018-04-13 19:02:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:37 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:37 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:02:38 --> File loaded: E:\www\yacopoo\application\views\questions/kids_dinner.php
INFO - 2018-04-13 19:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:02:38 --> Final output sent to browser
DEBUG - 2018-04-13 19:02:38 --> Total execution time: 0.4689
INFO - 2018-04-13 19:02:38 --> Config Class Initialized
INFO - 2018-04-13 19:02:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:38 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:38 --> URI Class Initialized
INFO - 2018-04-13 19:02:38 --> Router Class Initialized
INFO - 2018-04-13 19:02:38 --> Output Class Initialized
INFO - 2018-04-13 19:02:38 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:38 --> CSRF cookie sent
INFO - 2018-04-13 19:02:38 --> Input Class Initialized
INFO - 2018-04-13 19:02:38 --> Language Class Initialized
ERROR - 2018-04-13 19:02:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:40 --> Config Class Initialized
INFO - 2018-04-13 19:02:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:40 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:40 --> URI Class Initialized
INFO - 2018-04-13 19:02:40 --> Router Class Initialized
INFO - 2018-04-13 19:02:40 --> Output Class Initialized
INFO - 2018-04-13 19:02:40 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:40 --> CSRF cookie sent
INFO - 2018-04-13 19:02:41 --> Input Class Initialized
INFO - 2018-04-13 19:02:41 --> Language Class Initialized
INFO - 2018-04-13 19:02:41 --> Loader Class Initialized
INFO - 2018-04-13 19:02:41 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:41 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:41 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:41 --> Controller Class Initialized
INFO - 2018-04-13 19:02:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:41 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:41 --> Database Driver Class Initialized
INFO - 2018-04-13 19:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:02:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:02:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:02:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:02:41 --> File loaded: E:\www\yacopoo\application\views\questions/kids_homework.php
INFO - 2018-04-13 19:02:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:02:41 --> Final output sent to browser
DEBUG - 2018-04-13 19:02:41 --> Total execution time: 0.5766
INFO - 2018-04-13 19:02:41 --> Config Class Initialized
INFO - 2018-04-13 19:02:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:41 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:41 --> URI Class Initialized
INFO - 2018-04-13 19:02:41 --> Router Class Initialized
INFO - 2018-04-13 19:02:41 --> Output Class Initialized
INFO - 2018-04-13 19:02:41 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:41 --> CSRF cookie sent
INFO - 2018-04-13 19:02:41 --> Input Class Initialized
INFO - 2018-04-13 19:02:41 --> Language Class Initialized
ERROR - 2018-04-13 19:02:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:02:57 --> Config Class Initialized
INFO - 2018-04-13 19:02:57 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:02:57 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:02:57 --> Utf8 Class Initialized
INFO - 2018-04-13 19:02:57 --> URI Class Initialized
INFO - 2018-04-13 19:02:57 --> Router Class Initialized
INFO - 2018-04-13 19:02:57 --> Output Class Initialized
INFO - 2018-04-13 19:02:58 --> Security Class Initialized
DEBUG - 2018-04-13 19:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:02:58 --> CSRF cookie sent
INFO - 2018-04-13 19:02:58 --> Input Class Initialized
INFO - 2018-04-13 19:02:58 --> Language Class Initialized
INFO - 2018-04-13 19:02:58 --> Loader Class Initialized
INFO - 2018-04-13 19:02:58 --> Helper loaded: url_helper
INFO - 2018-04-13 19:02:58 --> Helper loaded: form_helper
INFO - 2018-04-13 19:02:58 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:02:58 --> User Agent Class Initialized
INFO - 2018-04-13 19:02:58 --> Controller Class Initialized
INFO - 2018-04-13 19:02:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:02:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:02:58 --> Pixel_Model class loaded
INFO - 2018-04-13 19:02:58 --> Database Driver Class Initialized
INFO - 2018-04-13 19:03:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:03:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:03:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:03:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:03:01 --> File loaded: E:\www\yacopoo\application\views\questions/kids_homework.php
INFO - 2018-04-13 19:03:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:03:01 --> Final output sent to browser
DEBUG - 2018-04-13 19:03:01 --> Total execution time: 3.4562
INFO - 2018-04-13 19:03:01 --> Config Class Initialized
INFO - 2018-04-13 19:03:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:01 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:01 --> URI Class Initialized
INFO - 2018-04-13 19:03:01 --> Router Class Initialized
INFO - 2018-04-13 19:03:01 --> Output Class Initialized
INFO - 2018-04-13 19:03:01 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:01 --> CSRF cookie sent
INFO - 2018-04-13 19:03:02 --> Input Class Initialized
INFO - 2018-04-13 19:03:02 --> Language Class Initialized
ERROR - 2018-04-13 19:03:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:03:11 --> Config Class Initialized
INFO - 2018-04-13 19:03:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:11 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:11 --> URI Class Initialized
INFO - 2018-04-13 19:03:11 --> Router Class Initialized
INFO - 2018-04-13 19:03:11 --> Output Class Initialized
INFO - 2018-04-13 19:03:11 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:11 --> CSRF cookie sent
INFO - 2018-04-13 19:03:11 --> Input Class Initialized
INFO - 2018-04-13 19:03:11 --> Language Class Initialized
INFO - 2018-04-13 19:03:11 --> Loader Class Initialized
INFO - 2018-04-13 19:03:12 --> Helper loaded: url_helper
INFO - 2018-04-13 19:03:12 --> Helper loaded: form_helper
INFO - 2018-04-13 19:03:12 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:03:12 --> User Agent Class Initialized
INFO - 2018-04-13 19:03:12 --> Controller Class Initialized
INFO - 2018-04-13 19:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:03:12 --> Pixel_Model class loaded
INFO - 2018-04-13 19:03:12 --> Database Driver Class Initialized
INFO - 2018-04-13 19:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:03:12 --> File loaded: E:\www\yacopoo\application\views\questions/kids_homework.php
INFO - 2018-04-13 19:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:03:12 --> Final output sent to browser
DEBUG - 2018-04-13 19:03:12 --> Total execution time: 0.5581
INFO - 2018-04-13 19:03:12 --> Config Class Initialized
INFO - 2018-04-13 19:03:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:12 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:12 --> URI Class Initialized
INFO - 2018-04-13 19:03:12 --> Router Class Initialized
INFO - 2018-04-13 19:03:12 --> Output Class Initialized
INFO - 2018-04-13 19:03:12 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:12 --> CSRF cookie sent
INFO - 2018-04-13 19:03:12 --> Input Class Initialized
INFO - 2018-04-13 19:03:12 --> Language Class Initialized
ERROR - 2018-04-13 19:03:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:03:23 --> Config Class Initialized
INFO - 2018-04-13 19:03:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:23 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:23 --> URI Class Initialized
INFO - 2018-04-13 19:03:23 --> Router Class Initialized
INFO - 2018-04-13 19:03:23 --> Output Class Initialized
INFO - 2018-04-13 19:03:23 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:23 --> CSRF cookie sent
INFO - 2018-04-13 19:03:23 --> CSRF token verified
INFO - 2018-04-13 19:03:23 --> Input Class Initialized
INFO - 2018-04-13 19:03:23 --> Language Class Initialized
INFO - 2018-04-13 19:03:23 --> Loader Class Initialized
INFO - 2018-04-13 19:03:23 --> Helper loaded: url_helper
INFO - 2018-04-13 19:03:23 --> Helper loaded: form_helper
INFO - 2018-04-13 19:03:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:03:23 --> User Agent Class Initialized
INFO - 2018-04-13 19:03:23 --> Controller Class Initialized
INFO - 2018-04-13 19:03:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:03:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:03:23 --> Pixel_Model class loaded
INFO - 2018-04-13 19:03:23 --> Database Driver Class Initialized
INFO - 2018-04-13 19:03:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:03:23 --> Form Validation Class Initialized
INFO - 2018-04-13 19:03:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:03:23 --> Config Class Initialized
INFO - 2018-04-13 19:03:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:24 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:24 --> URI Class Initialized
INFO - 2018-04-13 19:03:24 --> Router Class Initialized
INFO - 2018-04-13 19:03:24 --> Output Class Initialized
INFO - 2018-04-13 19:03:24 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:24 --> CSRF cookie sent
INFO - 2018-04-13 19:03:24 --> Input Class Initialized
INFO - 2018-04-13 19:03:24 --> Language Class Initialized
INFO - 2018-04-13 19:03:24 --> Loader Class Initialized
INFO - 2018-04-13 19:03:24 --> Helper loaded: url_helper
INFO - 2018-04-13 19:03:24 --> Helper loaded: form_helper
INFO - 2018-04-13 19:03:24 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:03:24 --> User Agent Class Initialized
INFO - 2018-04-13 19:03:24 --> Controller Class Initialized
INFO - 2018-04-13 19:03:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:03:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:03:24 --> Pixel_Model class loaded
INFO - 2018-04-13 19:03:24 --> Database Driver Class Initialized
INFO - 2018-04-13 19:03:24 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:03:24 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:03:24 --> Final output sent to browser
DEBUG - 2018-04-13 19:03:24 --> Total execution time: 0.4537
INFO - 2018-04-13 19:03:24 --> Config Class Initialized
INFO - 2018-04-13 19:03:24 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:03:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:03:24 --> Utf8 Class Initialized
INFO - 2018-04-13 19:03:24 --> URI Class Initialized
INFO - 2018-04-13 19:03:25 --> Router Class Initialized
INFO - 2018-04-13 19:03:25 --> Output Class Initialized
INFO - 2018-04-13 19:03:25 --> Security Class Initialized
DEBUG - 2018-04-13 19:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:03:25 --> CSRF cookie sent
INFO - 2018-04-13 19:03:25 --> Input Class Initialized
INFO - 2018-04-13 19:03:25 --> Language Class Initialized
ERROR - 2018-04-13 19:03:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:04:25 --> Config Class Initialized
INFO - 2018-04-13 19:04:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:25 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:25 --> URI Class Initialized
INFO - 2018-04-13 19:04:25 --> Router Class Initialized
INFO - 2018-04-13 19:04:25 --> Output Class Initialized
INFO - 2018-04-13 19:04:25 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:25 --> CSRF cookie sent
INFO - 2018-04-13 19:04:25 --> Input Class Initialized
INFO - 2018-04-13 19:04:25 --> Language Class Initialized
INFO - 2018-04-13 19:04:25 --> Loader Class Initialized
INFO - 2018-04-13 19:04:25 --> Helper loaded: url_helper
INFO - 2018-04-13 19:04:25 --> Helper loaded: form_helper
INFO - 2018-04-13 19:04:25 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:04:25 --> User Agent Class Initialized
INFO - 2018-04-13 19:04:25 --> Controller Class Initialized
INFO - 2018-04-13 19:04:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:04:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:04:25 --> Pixel_Model class loaded
INFO - 2018-04-13 19:04:25 --> Database Driver Class Initialized
INFO - 2018-04-13 19:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:04:25 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:04:25 --> Final output sent to browser
DEBUG - 2018-04-13 19:04:25 --> Total execution time: 0.4909
INFO - 2018-04-13 19:04:26 --> Config Class Initialized
INFO - 2018-04-13 19:04:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:26 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:26 --> URI Class Initialized
INFO - 2018-04-13 19:04:26 --> Router Class Initialized
INFO - 2018-04-13 19:04:26 --> Output Class Initialized
INFO - 2018-04-13 19:04:26 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:26 --> CSRF cookie sent
INFO - 2018-04-13 19:04:26 --> Input Class Initialized
INFO - 2018-04-13 19:04:26 --> Language Class Initialized
ERROR - 2018-04-13 19:04:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:04:31 --> Config Class Initialized
INFO - 2018-04-13 19:04:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:31 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:31 --> URI Class Initialized
INFO - 2018-04-13 19:04:31 --> Router Class Initialized
INFO - 2018-04-13 19:04:31 --> Output Class Initialized
INFO - 2018-04-13 19:04:31 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:31 --> CSRF cookie sent
INFO - 2018-04-13 19:04:31 --> Input Class Initialized
INFO - 2018-04-13 19:04:31 --> Language Class Initialized
INFO - 2018-04-13 19:04:31 --> Loader Class Initialized
INFO - 2018-04-13 19:04:31 --> Helper loaded: url_helper
INFO - 2018-04-13 19:04:31 --> Helper loaded: form_helper
INFO - 2018-04-13 19:04:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:04:31 --> User Agent Class Initialized
INFO - 2018-04-13 19:04:31 --> Controller Class Initialized
INFO - 2018-04-13 19:04:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:04:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:04:31 --> Pixel_Model class loaded
INFO - 2018-04-13 19:04:31 --> Database Driver Class Initialized
INFO - 2018-04-13 19:04:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:04:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:04:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:04:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:04:31 --> File loaded: E:\www\yacopoo\application\views\questions/kids_homework.php
INFO - 2018-04-13 19:04:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:04:31 --> Final output sent to browser
DEBUG - 2018-04-13 19:04:31 --> Total execution time: 0.4819
INFO - 2018-04-13 19:04:32 --> Config Class Initialized
INFO - 2018-04-13 19:04:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:32 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:32 --> URI Class Initialized
INFO - 2018-04-13 19:04:32 --> Router Class Initialized
INFO - 2018-04-13 19:04:32 --> Output Class Initialized
INFO - 2018-04-13 19:04:32 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:32 --> CSRF cookie sent
INFO - 2018-04-13 19:04:32 --> Input Class Initialized
INFO - 2018-04-13 19:04:32 --> Language Class Initialized
ERROR - 2018-04-13 19:04:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:04:51 --> Config Class Initialized
INFO - 2018-04-13 19:04:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:51 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:51 --> URI Class Initialized
INFO - 2018-04-13 19:04:51 --> Router Class Initialized
INFO - 2018-04-13 19:04:51 --> Output Class Initialized
INFO - 2018-04-13 19:04:51 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:51 --> CSRF cookie sent
INFO - 2018-04-13 19:04:51 --> CSRF token verified
INFO - 2018-04-13 19:04:51 --> Input Class Initialized
INFO - 2018-04-13 19:04:51 --> Language Class Initialized
INFO - 2018-04-13 19:04:51 --> Loader Class Initialized
INFO - 2018-04-13 19:04:51 --> Helper loaded: url_helper
INFO - 2018-04-13 19:04:51 --> Helper loaded: form_helper
INFO - 2018-04-13 19:04:51 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:04:51 --> User Agent Class Initialized
INFO - 2018-04-13 19:04:51 --> Controller Class Initialized
INFO - 2018-04-13 19:04:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:04:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:04:51 --> Pixel_Model class loaded
INFO - 2018-04-13 19:04:51 --> Database Driver Class Initialized
INFO - 2018-04-13 19:04:51 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:04:51 --> Form Validation Class Initialized
INFO - 2018-04-13 19:04:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:04:51 --> Config Class Initialized
INFO - 2018-04-13 19:04:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:51 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:51 --> URI Class Initialized
INFO - 2018-04-13 19:04:51 --> Router Class Initialized
INFO - 2018-04-13 19:04:51 --> Output Class Initialized
INFO - 2018-04-13 19:04:51 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:52 --> CSRF cookie sent
INFO - 2018-04-13 19:04:52 --> Input Class Initialized
INFO - 2018-04-13 19:04:52 --> Language Class Initialized
INFO - 2018-04-13 19:04:52 --> Loader Class Initialized
INFO - 2018-04-13 19:04:52 --> Helper loaded: url_helper
INFO - 2018-04-13 19:04:52 --> Helper loaded: form_helper
INFO - 2018-04-13 19:04:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:04:52 --> User Agent Class Initialized
INFO - 2018-04-13 19:04:52 --> Controller Class Initialized
INFO - 2018-04-13 19:04:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:04:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:04:52 --> Pixel_Model class loaded
INFO - 2018-04-13 19:04:52 --> Database Driver Class Initialized
INFO - 2018-04-13 19:04:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:04:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:04:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:04:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:04:52 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:04:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:04:52 --> Final output sent to browser
DEBUG - 2018-04-13 19:04:52 --> Total execution time: 0.4599
INFO - 2018-04-13 19:04:52 --> Config Class Initialized
INFO - 2018-04-13 19:04:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:04:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:04:52 --> Utf8 Class Initialized
INFO - 2018-04-13 19:04:52 --> URI Class Initialized
INFO - 2018-04-13 19:04:52 --> Router Class Initialized
INFO - 2018-04-13 19:04:52 --> Output Class Initialized
INFO - 2018-04-13 19:04:52 --> Security Class Initialized
DEBUG - 2018-04-13 19:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:04:52 --> CSRF cookie sent
INFO - 2018-04-13 19:04:52 --> Input Class Initialized
INFO - 2018-04-13 19:04:52 --> Language Class Initialized
ERROR - 2018-04-13 19:04:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:05:12 --> Config Class Initialized
INFO - 2018-04-13 19:05:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:12 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:12 --> URI Class Initialized
INFO - 2018-04-13 19:05:12 --> Router Class Initialized
INFO - 2018-04-13 19:05:12 --> Output Class Initialized
INFO - 2018-04-13 19:05:12 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:12 --> CSRF cookie sent
INFO - 2018-04-13 19:05:12 --> Input Class Initialized
INFO - 2018-04-13 19:05:12 --> Language Class Initialized
INFO - 2018-04-13 19:05:12 --> Loader Class Initialized
INFO - 2018-04-13 19:05:12 --> Helper loaded: url_helper
INFO - 2018-04-13 19:05:12 --> Helper loaded: form_helper
INFO - 2018-04-13 19:05:12 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:05:12 --> User Agent Class Initialized
INFO - 2018-04-13 19:05:12 --> Controller Class Initialized
INFO - 2018-04-13 19:05:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:05:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:05:12 --> Pixel_Model class loaded
INFO - 2018-04-13 19:05:12 --> Database Driver Class Initialized
INFO - 2018-04-13 19:05:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:05:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:05:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:05:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:05:15 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:05:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:05:15 --> Final output sent to browser
DEBUG - 2018-04-13 19:05:15 --> Total execution time: 3.5883
INFO - 2018-04-13 19:05:16 --> Config Class Initialized
INFO - 2018-04-13 19:05:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:16 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:16 --> URI Class Initialized
INFO - 2018-04-13 19:05:16 --> Router Class Initialized
INFO - 2018-04-13 19:05:16 --> Output Class Initialized
INFO - 2018-04-13 19:05:16 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:16 --> CSRF cookie sent
INFO - 2018-04-13 19:05:16 --> Input Class Initialized
INFO - 2018-04-13 19:05:16 --> Language Class Initialized
ERROR - 2018-04-13 19:05:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:05:19 --> Config Class Initialized
INFO - 2018-04-13 19:05:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:19 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:19 --> URI Class Initialized
INFO - 2018-04-13 19:05:19 --> Router Class Initialized
INFO - 2018-04-13 19:05:19 --> Output Class Initialized
INFO - 2018-04-13 19:05:19 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:19 --> CSRF cookie sent
INFO - 2018-04-13 19:05:19 --> CSRF token verified
INFO - 2018-04-13 19:05:19 --> Input Class Initialized
INFO - 2018-04-13 19:05:19 --> Language Class Initialized
INFO - 2018-04-13 19:05:19 --> Loader Class Initialized
INFO - 2018-04-13 19:05:19 --> Helper loaded: url_helper
INFO - 2018-04-13 19:05:19 --> Helper loaded: form_helper
INFO - 2018-04-13 19:05:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:05:19 --> User Agent Class Initialized
INFO - 2018-04-13 19:05:19 --> Controller Class Initialized
INFO - 2018-04-13 19:05:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:05:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:05:19 --> Pixel_Model class loaded
INFO - 2018-04-13 19:05:19 --> Database Driver Class Initialized
INFO - 2018-04-13 19:05:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:05:19 --> Form Validation Class Initialized
INFO - 2018-04-13 19:05:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\questions/other_kids.php
INFO - 2018-04-13 19:05:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:05:19 --> Final output sent to browser
DEBUG - 2018-04-13 19:05:19 --> Total execution time: 0.5647
INFO - 2018-04-13 19:05:20 --> Config Class Initialized
INFO - 2018-04-13 19:05:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:20 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:20 --> URI Class Initialized
INFO - 2018-04-13 19:05:20 --> Router Class Initialized
INFO - 2018-04-13 19:05:20 --> Output Class Initialized
INFO - 2018-04-13 19:05:20 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:20 --> CSRF cookie sent
INFO - 2018-04-13 19:05:20 --> Input Class Initialized
INFO - 2018-04-13 19:05:20 --> Language Class Initialized
ERROR - 2018-04-13 19:05:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:05:28 --> Config Class Initialized
INFO - 2018-04-13 19:05:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:28 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:28 --> URI Class Initialized
INFO - 2018-04-13 19:05:28 --> Router Class Initialized
INFO - 2018-04-13 19:05:28 --> Output Class Initialized
INFO - 2018-04-13 19:05:28 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:28 --> CSRF cookie sent
INFO - 2018-04-13 19:05:28 --> Input Class Initialized
INFO - 2018-04-13 19:05:28 --> Language Class Initialized
INFO - 2018-04-13 19:05:28 --> Loader Class Initialized
INFO - 2018-04-13 19:05:28 --> Helper loaded: url_helper
INFO - 2018-04-13 19:05:28 --> Helper loaded: form_helper
INFO - 2018-04-13 19:05:28 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:05:28 --> User Agent Class Initialized
INFO - 2018-04-13 19:05:28 --> Controller Class Initialized
INFO - 2018-04-13 19:05:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:05:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:05:28 --> Pixel_Model class loaded
INFO - 2018-04-13 19:05:29 --> Database Driver Class Initialized
INFO - 2018-04-13 19:05:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:05:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:05:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:05:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:05:29 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:05:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:05:29 --> Final output sent to browser
DEBUG - 2018-04-13 19:05:29 --> Total execution time: 0.5086
INFO - 2018-04-13 19:05:29 --> Config Class Initialized
INFO - 2018-04-13 19:05:29 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:29 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:29 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:29 --> URI Class Initialized
INFO - 2018-04-13 19:05:29 --> Router Class Initialized
INFO - 2018-04-13 19:05:29 --> Output Class Initialized
INFO - 2018-04-13 19:05:29 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:29 --> CSRF cookie sent
INFO - 2018-04-13 19:05:29 --> Input Class Initialized
INFO - 2018-04-13 19:05:29 --> Language Class Initialized
ERROR - 2018-04-13 19:05:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:05:59 --> Config Class Initialized
INFO - 2018-04-13 19:05:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:59 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:59 --> URI Class Initialized
INFO - 2018-04-13 19:05:59 --> Router Class Initialized
INFO - 2018-04-13 19:05:59 --> Output Class Initialized
INFO - 2018-04-13 19:05:59 --> Security Class Initialized
DEBUG - 2018-04-13 19:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:05:59 --> CSRF cookie sent
INFO - 2018-04-13 19:05:59 --> CSRF token verified
INFO - 2018-04-13 19:05:59 --> Input Class Initialized
INFO - 2018-04-13 19:05:59 --> Language Class Initialized
INFO - 2018-04-13 19:05:59 --> Loader Class Initialized
INFO - 2018-04-13 19:05:59 --> Helper loaded: url_helper
INFO - 2018-04-13 19:05:59 --> Helper loaded: form_helper
INFO - 2018-04-13 19:05:59 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:05:59 --> User Agent Class Initialized
INFO - 2018-04-13 19:05:59 --> Controller Class Initialized
INFO - 2018-04-13 19:05:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:05:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:05:59 --> Pixel_Model class loaded
INFO - 2018-04-13 19:05:59 --> Database Driver Class Initialized
INFO - 2018-04-13 19:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:05:59 --> Form Validation Class Initialized
INFO - 2018-04-13 19:05:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:05:59 --> Config Class Initialized
INFO - 2018-04-13 19:05:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:05:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:05:59 --> Utf8 Class Initialized
INFO - 2018-04-13 19:05:59 --> URI Class Initialized
INFO - 2018-04-13 19:05:59 --> Router Class Initialized
INFO - 2018-04-13 19:05:59 --> Output Class Initialized
INFO - 2018-04-13 19:05:59 --> Security Class Initialized
DEBUG - 2018-04-13 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:06:00 --> CSRF cookie sent
INFO - 2018-04-13 19:06:00 --> Input Class Initialized
INFO - 2018-04-13 19:06:00 --> Language Class Initialized
INFO - 2018-04-13 19:06:00 --> Loader Class Initialized
INFO - 2018-04-13 19:06:00 --> Helper loaded: url_helper
INFO - 2018-04-13 19:06:00 --> Helper loaded: form_helper
INFO - 2018-04-13 19:06:00 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:06:00 --> User Agent Class Initialized
INFO - 2018-04-13 19:06:00 --> Controller Class Initialized
INFO - 2018-04-13 19:06:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:06:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:06:00 --> Pixel_Model class loaded
INFO - 2018-04-13 19:06:00 --> Database Driver Class Initialized
INFO - 2018-04-13 19:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:06:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:06:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:06:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:06:00 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:06:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:06:00 --> Final output sent to browser
DEBUG - 2018-04-13 19:06:00 --> Total execution time: 0.5169
INFO - 2018-04-13 19:06:00 --> Config Class Initialized
INFO - 2018-04-13 19:06:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:06:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:06:00 --> Utf8 Class Initialized
INFO - 2018-04-13 19:06:00 --> URI Class Initialized
INFO - 2018-04-13 19:06:00 --> Router Class Initialized
INFO - 2018-04-13 19:06:00 --> Output Class Initialized
INFO - 2018-04-13 19:06:00 --> Security Class Initialized
DEBUG - 2018-04-13 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:06:00 --> CSRF cookie sent
INFO - 2018-04-13 19:06:00 --> Input Class Initialized
INFO - 2018-04-13 19:06:00 --> Language Class Initialized
ERROR - 2018-04-13 19:06:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 19:06:03 --> Config Class Initialized
INFO - 2018-04-13 19:06:03 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:06:03 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:06:03 --> Utf8 Class Initialized
INFO - 2018-04-13 19:06:03 --> URI Class Initialized
INFO - 2018-04-13 19:06:03 --> Router Class Initialized
INFO - 2018-04-13 19:06:03 --> Output Class Initialized
INFO - 2018-04-13 19:06:03 --> Security Class Initialized
DEBUG - 2018-04-13 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:06:03 --> CSRF cookie sent
INFO - 2018-04-13 19:06:03 --> CSRF token verified
INFO - 2018-04-13 19:06:03 --> Input Class Initialized
INFO - 2018-04-13 19:06:03 --> Language Class Initialized
INFO - 2018-04-13 19:06:03 --> Loader Class Initialized
INFO - 2018-04-13 19:06:03 --> Helper loaded: url_helper
INFO - 2018-04-13 19:06:03 --> Helper loaded: form_helper
INFO - 2018-04-13 19:06:03 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:06:03 --> User Agent Class Initialized
INFO - 2018-04-13 19:06:03 --> Controller Class Initialized
INFO - 2018-04-13 19:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:06:03 --> Pixel_Model class loaded
INFO - 2018-04-13 19:06:03 --> Database Driver Class Initialized
INFO - 2018-04-13 19:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:06:03 --> Form Validation Class Initialized
INFO - 2018-04-13 19:06:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 19:06:04 --> Config Class Initialized
INFO - 2018-04-13 19:06:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:06:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:06:04 --> Utf8 Class Initialized
INFO - 2018-04-13 19:06:04 --> URI Class Initialized
INFO - 2018-04-13 19:06:04 --> Router Class Initialized
INFO - 2018-04-13 19:06:04 --> Output Class Initialized
INFO - 2018-04-13 19:06:04 --> Security Class Initialized
DEBUG - 2018-04-13 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:06:04 --> CSRF cookie sent
INFO - 2018-04-13 19:06:04 --> Input Class Initialized
INFO - 2018-04-13 19:06:04 --> Language Class Initialized
INFO - 2018-04-13 19:06:04 --> Loader Class Initialized
INFO - 2018-04-13 19:06:04 --> Helper loaded: url_helper
INFO - 2018-04-13 19:06:04 --> Helper loaded: form_helper
INFO - 2018-04-13 19:06:04 --> Helper loaded: language_helper
DEBUG - 2018-04-13 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 19:06:04 --> User Agent Class Initialized
INFO - 2018-04-13 19:06:04 --> Controller Class Initialized
INFO - 2018-04-13 19:06:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 19:06:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 19:06:04 --> Pixel_Model class loaded
INFO - 2018-04-13 19:06:04 --> Database Driver Class Initialized
INFO - 2018-04-13 19:06:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 19:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 19:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 19:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 19:06:04 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 19:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 19:06:04 --> Final output sent to browser
DEBUG - 2018-04-13 19:06:04 --> Total execution time: 0.4662
INFO - 2018-04-13 19:06:04 --> Config Class Initialized
INFO - 2018-04-13 19:06:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 19:06:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 19:06:04 --> Utf8 Class Initialized
INFO - 2018-04-13 19:06:04 --> URI Class Initialized
INFO - 2018-04-13 19:06:04 --> Router Class Initialized
INFO - 2018-04-13 19:06:04 --> Output Class Initialized
INFO - 2018-04-13 19:06:05 --> Security Class Initialized
DEBUG - 2018-04-13 19:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 19:06:05 --> CSRF cookie sent
INFO - 2018-04-13 19:06:05 --> Input Class Initialized
INFO - 2018-04-13 19:06:05 --> Language Class Initialized
ERROR - 2018-04-13 19:06:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:42:04 --> Config Class Initialized
INFO - 2018-04-13 21:42:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:04 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:04 --> URI Class Initialized
INFO - 2018-04-13 21:42:04 --> Router Class Initialized
INFO - 2018-04-13 21:42:04 --> Output Class Initialized
INFO - 2018-04-13 21:42:04 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:04 --> CSRF cookie sent
INFO - 2018-04-13 21:42:04 --> Input Class Initialized
INFO - 2018-04-13 21:42:04 --> Language Class Initialized
INFO - 2018-04-13 21:42:04 --> Loader Class Initialized
INFO - 2018-04-13 21:42:04 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:04 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:04 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:04 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:04 --> Controller Class Initialized
INFO - 2018-04-13 21:42:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:42:04 --> Pixel_Model class loaded
INFO - 2018-04-13 21:42:04 --> Database Driver Class Initialized
INFO - 2018-04-13 21:42:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:42:08 --> Config Class Initialized
INFO - 2018-04-13 21:42:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:08 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:08 --> URI Class Initialized
DEBUG - 2018-04-13 21:42:08 --> No URI present. Default controller set.
INFO - 2018-04-13 21:42:08 --> Router Class Initialized
INFO - 2018-04-13 21:42:08 --> Output Class Initialized
INFO - 2018-04-13 21:42:08 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:08 --> CSRF cookie sent
INFO - 2018-04-13 21:42:08 --> Input Class Initialized
INFO - 2018-04-13 21:42:08 --> Language Class Initialized
INFO - 2018-04-13 21:42:08 --> Loader Class Initialized
INFO - 2018-04-13 21:42:08 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:08 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:08 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:08 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:08 --> Controller Class Initialized
INFO - 2018-04-13 21:42:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:42:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 21:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:42:08 --> Final output sent to browser
DEBUG - 2018-04-13 21:42:08 --> Total execution time: 0.3910
INFO - 2018-04-13 21:42:08 --> Config Class Initialized
INFO - 2018-04-13 21:42:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:08 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:08 --> URI Class Initialized
INFO - 2018-04-13 21:42:09 --> Router Class Initialized
INFO - 2018-04-13 21:42:09 --> Output Class Initialized
INFO - 2018-04-13 21:42:09 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:09 --> CSRF cookie sent
INFO - 2018-04-13 21:42:09 --> Input Class Initialized
INFO - 2018-04-13 21:42:09 --> Language Class Initialized
ERROR - 2018-04-13 21:42:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:42:10 --> Config Class Initialized
INFO - 2018-04-13 21:42:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:10 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:10 --> URI Class Initialized
INFO - 2018-04-13 21:42:10 --> Router Class Initialized
INFO - 2018-04-13 21:42:10 --> Output Class Initialized
INFO - 2018-04-13 21:42:10 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:10 --> CSRF cookie sent
INFO - 2018-04-13 21:42:10 --> Input Class Initialized
INFO - 2018-04-13 21:42:10 --> Language Class Initialized
ERROR - 2018-04-13 21:42:10 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 21:42:32 --> Config Class Initialized
INFO - 2018-04-13 21:42:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:32 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:32 --> URI Class Initialized
INFO - 2018-04-13 21:42:32 --> Router Class Initialized
INFO - 2018-04-13 21:42:32 --> Output Class Initialized
INFO - 2018-04-13 21:42:32 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:32 --> CSRF cookie sent
INFO - 2018-04-13 21:42:32 --> Input Class Initialized
INFO - 2018-04-13 21:42:32 --> Language Class Initialized
INFO - 2018-04-13 21:42:32 --> Loader Class Initialized
INFO - 2018-04-13 21:42:32 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:32 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:33 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:33 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:33 --> Controller Class Initialized
INFO - 2018-04-13 21:42:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-13 21:42:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 21:42:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:42:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:42:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-13 21:42:33 --> Could not find the language line "req_email"
INFO - 2018-04-13 21:42:33 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-13 21:42:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:42:33 --> Final output sent to browser
DEBUG - 2018-04-13 21:42:33 --> Total execution time: 0.4971
INFO - 2018-04-13 21:42:33 --> Config Class Initialized
INFO - 2018-04-13 21:42:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:33 --> URI Class Initialized
INFO - 2018-04-13 21:42:33 --> Router Class Initialized
INFO - 2018-04-13 21:42:33 --> Output Class Initialized
INFO - 2018-04-13 21:42:33 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:33 --> CSRF cookie sent
INFO - 2018-04-13 21:42:33 --> Input Class Initialized
INFO - 2018-04-13 21:42:33 --> Language Class Initialized
ERROR - 2018-04-13 21:42:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:42:44 --> Config Class Initialized
INFO - 2018-04-13 21:42:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:44 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:44 --> URI Class Initialized
INFO - 2018-04-13 21:42:44 --> Router Class Initialized
INFO - 2018-04-13 21:42:44 --> Output Class Initialized
INFO - 2018-04-13 21:42:44 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:44 --> CSRF cookie sent
INFO - 2018-04-13 21:42:44 --> CSRF token verified
INFO - 2018-04-13 21:42:44 --> Input Class Initialized
INFO - 2018-04-13 21:42:44 --> Language Class Initialized
INFO - 2018-04-13 21:42:44 --> Loader Class Initialized
INFO - 2018-04-13 21:42:44 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:44 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:44 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:44 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:44 --> Controller Class Initialized
INFO - 2018-04-13 21:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-13 21:42:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-13 21:42:44 --> Form Validation Class Initialized
INFO - 2018-04-13 21:42:44 --> Pixel_Model class loaded
INFO - 2018-04-13 21:42:44 --> Database Driver Class Initialized
INFO - 2018-04-13 21:42:44 --> Model "AuthenticationModel" initialized
INFO - 2018-04-13 21:42:45 --> Config Class Initialized
INFO - 2018-04-13 21:42:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:45 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:45 --> URI Class Initialized
DEBUG - 2018-04-13 21:42:45 --> No URI present. Default controller set.
INFO - 2018-04-13 21:42:45 --> Router Class Initialized
INFO - 2018-04-13 21:42:45 --> Output Class Initialized
INFO - 2018-04-13 21:42:45 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:45 --> CSRF cookie sent
INFO - 2018-04-13 21:42:45 --> Input Class Initialized
INFO - 2018-04-13 21:42:45 --> Language Class Initialized
INFO - 2018-04-13 21:42:45 --> Loader Class Initialized
INFO - 2018-04-13 21:42:45 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:45 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:45 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:45 --> Controller Class Initialized
INFO - 2018-04-13 21:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:42:45 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-13 21:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:42:45 --> Final output sent to browser
DEBUG - 2018-04-13 21:42:45 --> Total execution time: 0.4526
INFO - 2018-04-13 21:42:45 --> Config Class Initialized
INFO - 2018-04-13 21:42:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:45 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:45 --> URI Class Initialized
INFO - 2018-04-13 21:42:46 --> Router Class Initialized
INFO - 2018-04-13 21:42:46 --> Output Class Initialized
INFO - 2018-04-13 21:42:46 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:46 --> CSRF cookie sent
INFO - 2018-04-13 21:42:46 --> Input Class Initialized
INFO - 2018-04-13 21:42:46 --> Language Class Initialized
ERROR - 2018-04-13 21:42:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:42:47 --> Config Class Initialized
INFO - 2018-04-13 21:42:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:47 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:47 --> URI Class Initialized
INFO - 2018-04-13 21:42:47 --> Router Class Initialized
INFO - 2018-04-13 21:42:47 --> Output Class Initialized
INFO - 2018-04-13 21:42:47 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:48 --> CSRF cookie sent
INFO - 2018-04-13 21:42:48 --> Input Class Initialized
INFO - 2018-04-13 21:42:48 --> Language Class Initialized
ERROR - 2018-04-13 21:42:48 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-13 21:42:51 --> Config Class Initialized
INFO - 2018-04-13 21:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:52 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:52 --> URI Class Initialized
INFO - 2018-04-13 21:42:52 --> Router Class Initialized
INFO - 2018-04-13 21:42:52 --> Output Class Initialized
INFO - 2018-04-13 21:42:52 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:52 --> CSRF cookie sent
INFO - 2018-04-13 21:42:52 --> Input Class Initialized
INFO - 2018-04-13 21:42:52 --> Language Class Initialized
INFO - 2018-04-13 21:42:52 --> Loader Class Initialized
INFO - 2018-04-13 21:42:52 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:52 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:52 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:52 --> Controller Class Initialized
INFO - 2018-04-13 21:42:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:42:52 --> Pixel_Model class loaded
INFO - 2018-04-13 21:42:52 --> Database Driver Class Initialized
INFO - 2018-04-13 21:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:42:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:42:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:42:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:42:52 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-13 21:42:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:42:52 --> Final output sent to browser
DEBUG - 2018-04-13 21:42:52 --> Total execution time: 0.5901
INFO - 2018-04-13 21:42:52 --> Config Class Initialized
INFO - 2018-04-13 21:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:53 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:53 --> URI Class Initialized
INFO - 2018-04-13 21:42:53 --> Router Class Initialized
INFO - 2018-04-13 21:42:53 --> Output Class Initialized
INFO - 2018-04-13 21:42:53 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:53 --> CSRF cookie sent
INFO - 2018-04-13 21:42:53 --> Input Class Initialized
INFO - 2018-04-13 21:42:53 --> Language Class Initialized
ERROR - 2018-04-13 21:42:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:42:59 --> Config Class Initialized
INFO - 2018-04-13 21:42:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:42:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:42:59 --> Utf8 Class Initialized
INFO - 2018-04-13 21:42:59 --> URI Class Initialized
INFO - 2018-04-13 21:42:59 --> Router Class Initialized
INFO - 2018-04-13 21:42:59 --> Output Class Initialized
INFO - 2018-04-13 21:42:59 --> Security Class Initialized
DEBUG - 2018-04-13 21:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:42:59 --> CSRF cookie sent
INFO - 2018-04-13 21:42:59 --> Input Class Initialized
INFO - 2018-04-13 21:42:59 --> Language Class Initialized
INFO - 2018-04-13 21:42:59 --> Loader Class Initialized
INFO - 2018-04-13 21:42:59 --> Helper loaded: url_helper
INFO - 2018-04-13 21:42:59 --> Helper loaded: form_helper
INFO - 2018-04-13 21:42:59 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:42:59 --> User Agent Class Initialized
INFO - 2018-04-13 21:42:59 --> Controller Class Initialized
INFO - 2018-04-13 21:42:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:42:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:42:59 --> Pixel_Model class loaded
INFO - 2018-04-13 21:42:59 --> Database Driver Class Initialized
INFO - 2018-04-13 21:42:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:42:59 --> File loaded: E:\www\yacopoo\application\views\questions/kids_doctor.php
INFO - 2018-04-13 21:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:42:59 --> Final output sent to browser
DEBUG - 2018-04-13 21:42:59 --> Total execution time: 0.5470
INFO - 2018-04-13 21:42:59 --> Config Class Initialized
INFO - 2018-04-13 21:42:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:00 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:00 --> URI Class Initialized
INFO - 2018-04-13 21:43:00 --> Router Class Initialized
INFO - 2018-04-13 21:43:00 --> Output Class Initialized
INFO - 2018-04-13 21:43:00 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:00 --> CSRF cookie sent
INFO - 2018-04-13 21:43:00 --> Input Class Initialized
INFO - 2018-04-13 21:43:00 --> Language Class Initialized
ERROR - 2018-04-13 21:43:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:43:02 --> Config Class Initialized
INFO - 2018-04-13 21:43:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:02 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:02 --> URI Class Initialized
INFO - 2018-04-13 21:43:02 --> Router Class Initialized
INFO - 2018-04-13 21:43:02 --> Output Class Initialized
INFO - 2018-04-13 21:43:02 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:02 --> CSRF cookie sent
INFO - 2018-04-13 21:43:02 --> CSRF token verified
INFO - 2018-04-13 21:43:02 --> Input Class Initialized
INFO - 2018-04-13 21:43:02 --> Language Class Initialized
INFO - 2018-04-13 21:43:02 --> Loader Class Initialized
INFO - 2018-04-13 21:43:02 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:02 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:02 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:02 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:02 --> Controller Class Initialized
INFO - 2018-04-13 21:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:02 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:02 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:02 --> Form Validation Class Initialized
INFO - 2018-04-13 21:43:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:43:03 --> Config Class Initialized
INFO - 2018-04-13 21:43:03 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:03 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:03 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:03 --> URI Class Initialized
INFO - 2018-04-13 21:43:03 --> Router Class Initialized
INFO - 2018-04-13 21:43:03 --> Output Class Initialized
INFO - 2018-04-13 21:43:03 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:03 --> CSRF cookie sent
INFO - 2018-04-13 21:43:03 --> Input Class Initialized
INFO - 2018-04-13 21:43:03 --> Language Class Initialized
INFO - 2018-04-13 21:43:03 --> Loader Class Initialized
INFO - 2018-04-13 21:43:03 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:03 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:03 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:03 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:03 --> Controller Class Initialized
INFO - 2018-04-13 21:43:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:03 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:03 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:43:03 --> File loaded: E:\www\yacopoo\application\views\questions/kids_help_complaint.php
INFO - 2018-04-13 21:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:43:03 --> Final output sent to browser
DEBUG - 2018-04-13 21:43:03 --> Total execution time: 0.4862
INFO - 2018-04-13 21:43:03 --> Config Class Initialized
INFO - 2018-04-13 21:43:03 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:04 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:04 --> URI Class Initialized
INFO - 2018-04-13 21:43:04 --> Router Class Initialized
INFO - 2018-04-13 21:43:04 --> Output Class Initialized
INFO - 2018-04-13 21:43:04 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:04 --> CSRF cookie sent
INFO - 2018-04-13 21:43:04 --> Input Class Initialized
INFO - 2018-04-13 21:43:04 --> Language Class Initialized
ERROR - 2018-04-13 21:43:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:43:32 --> Config Class Initialized
INFO - 2018-04-13 21:43:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:32 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:32 --> URI Class Initialized
INFO - 2018-04-13 21:43:32 --> Router Class Initialized
INFO - 2018-04-13 21:43:32 --> Output Class Initialized
INFO - 2018-04-13 21:43:32 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:32 --> CSRF cookie sent
INFO - 2018-04-13 21:43:32 --> CSRF token verified
INFO - 2018-04-13 21:43:32 --> Input Class Initialized
INFO - 2018-04-13 21:43:32 --> Language Class Initialized
INFO - 2018-04-13 21:43:32 --> Loader Class Initialized
INFO - 2018-04-13 21:43:32 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:32 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:32 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:32 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:32 --> Controller Class Initialized
INFO - 2018-04-13 21:43:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:32 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:32 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:35 --> Form Validation Class Initialized
INFO - 2018-04-13 21:43:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:43:35 --> Config Class Initialized
INFO - 2018-04-13 21:43:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:35 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:35 --> URI Class Initialized
INFO - 2018-04-13 21:43:35 --> Router Class Initialized
INFO - 2018-04-13 21:43:35 --> Output Class Initialized
INFO - 2018-04-13 21:43:35 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:35 --> CSRF cookie sent
INFO - 2018-04-13 21:43:35 --> Input Class Initialized
INFO - 2018-04-13 21:43:35 --> Language Class Initialized
INFO - 2018-04-13 21:43:35 --> Loader Class Initialized
INFO - 2018-04-13 21:43:35 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:35 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:36 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:36 --> Controller Class Initialized
INFO - 2018-04-13 21:43:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:36 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:36 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:36 --> Form Validation Class Initialized
INFO - 2018-04-13 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:43:36 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_info.php
INFO - 2018-04-13 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:43:36 --> Final output sent to browser
DEBUG - 2018-04-13 21:43:36 --> Total execution time: 0.5181
INFO - 2018-04-13 21:43:36 --> Config Class Initialized
INFO - 2018-04-13 21:43:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:36 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:36 --> URI Class Initialized
INFO - 2018-04-13 21:43:36 --> Router Class Initialized
INFO - 2018-04-13 21:43:36 --> Output Class Initialized
INFO - 2018-04-13 21:43:36 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:36 --> CSRF cookie sent
INFO - 2018-04-13 21:43:36 --> Input Class Initialized
INFO - 2018-04-13 21:43:36 --> Language Class Initialized
ERROR - 2018-04-13 21:43:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:43:41 --> Config Class Initialized
INFO - 2018-04-13 21:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:41 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:41 --> URI Class Initialized
INFO - 2018-04-13 21:43:41 --> Router Class Initialized
INFO - 2018-04-13 21:43:41 --> Output Class Initialized
INFO - 2018-04-13 21:43:41 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:41 --> CSRF cookie sent
INFO - 2018-04-13 21:43:41 --> Input Class Initialized
INFO - 2018-04-13 21:43:41 --> Language Class Initialized
INFO - 2018-04-13 21:43:41 --> Loader Class Initialized
INFO - 2018-04-13 21:43:41 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:41 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:41 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:41 --> Controller Class Initialized
INFO - 2018-04-13 21:43:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:41 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:41 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:43:42 --> File loaded: E:\www\yacopoo\application\views\questions/kids_help_complaint.php
INFO - 2018-04-13 21:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:43:42 --> Final output sent to browser
DEBUG - 2018-04-13 21:43:42 --> Total execution time: 0.5141
INFO - 2018-04-13 21:43:42 --> Config Class Initialized
INFO - 2018-04-13 21:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:42 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:42 --> URI Class Initialized
INFO - 2018-04-13 21:43:42 --> Router Class Initialized
INFO - 2018-04-13 21:43:42 --> Output Class Initialized
INFO - 2018-04-13 21:43:42 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:42 --> CSRF cookie sent
INFO - 2018-04-13 21:43:42 --> Input Class Initialized
INFO - 2018-04-13 21:43:42 --> Language Class Initialized
ERROR - 2018-04-13 21:43:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:43:44 --> Config Class Initialized
INFO - 2018-04-13 21:43:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:44 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:44 --> URI Class Initialized
INFO - 2018-04-13 21:43:44 --> Router Class Initialized
INFO - 2018-04-13 21:43:44 --> Output Class Initialized
INFO - 2018-04-13 21:43:44 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:44 --> CSRF cookie sent
INFO - 2018-04-13 21:43:44 --> Input Class Initialized
INFO - 2018-04-13 21:43:44 --> Language Class Initialized
INFO - 2018-04-13 21:43:44 --> Loader Class Initialized
INFO - 2018-04-13 21:43:44 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:44 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:44 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:44 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:44 --> Controller Class Initialized
INFO - 2018-04-13 21:43:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:44 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:44 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:43:44 --> File loaded: E:\www\yacopoo\application\views\questions/kids_help_complaint.php
INFO - 2018-04-13 21:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:43:44 --> Final output sent to browser
DEBUG - 2018-04-13 21:43:44 --> Total execution time: 0.5156
INFO - 2018-04-13 21:43:45 --> Config Class Initialized
INFO - 2018-04-13 21:43:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:45 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:45 --> URI Class Initialized
INFO - 2018-04-13 21:43:45 --> Router Class Initialized
INFO - 2018-04-13 21:43:45 --> Output Class Initialized
INFO - 2018-04-13 21:43:45 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:45 --> CSRF cookie sent
INFO - 2018-04-13 21:43:45 --> Input Class Initialized
INFO - 2018-04-13 21:43:45 --> Language Class Initialized
ERROR - 2018-04-13 21:43:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:43:46 --> Config Class Initialized
INFO - 2018-04-13 21:43:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:46 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:46 --> URI Class Initialized
INFO - 2018-04-13 21:43:46 --> Router Class Initialized
INFO - 2018-04-13 21:43:46 --> Output Class Initialized
INFO - 2018-04-13 21:43:46 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:46 --> CSRF cookie sent
INFO - 2018-04-13 21:43:46 --> CSRF token verified
INFO - 2018-04-13 21:43:46 --> Input Class Initialized
INFO - 2018-04-13 21:43:46 --> Language Class Initialized
INFO - 2018-04-13 21:43:46 --> Loader Class Initialized
INFO - 2018-04-13 21:43:46 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:46 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:47 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:47 --> Controller Class Initialized
INFO - 2018-04-13 21:43:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:47 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:47 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:47 --> Form Validation Class Initialized
INFO - 2018-04-13 21:43:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:43:47 --> Config Class Initialized
INFO - 2018-04-13 21:43:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:47 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:47 --> URI Class Initialized
INFO - 2018-04-13 21:43:47 --> Router Class Initialized
INFO - 2018-04-13 21:43:47 --> Output Class Initialized
INFO - 2018-04-13 21:43:47 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:47 --> CSRF cookie sent
INFO - 2018-04-13 21:43:47 --> Input Class Initialized
INFO - 2018-04-13 21:43:47 --> Language Class Initialized
INFO - 2018-04-13 21:43:47 --> Loader Class Initialized
INFO - 2018-04-13 21:43:47 --> Helper loaded: url_helper
INFO - 2018-04-13 21:43:47 --> Helper loaded: form_helper
INFO - 2018-04-13 21:43:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:43:47 --> User Agent Class Initialized
INFO - 2018-04-13 21:43:47 --> Controller Class Initialized
INFO - 2018-04-13 21:43:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:43:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:43:47 --> Pixel_Model class loaded
INFO - 2018-04-13 21:43:47 --> Database Driver Class Initialized
INFO - 2018-04-13 21:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:43:47 --> Form Validation Class Initialized
INFO - 2018-04-13 21:43:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:43:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:43:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:43:47 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_info.php
INFO - 2018-04-13 21:43:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:43:47 --> Final output sent to browser
DEBUG - 2018-04-13 21:43:47 --> Total execution time: 0.5047
INFO - 2018-04-13 21:43:48 --> Config Class Initialized
INFO - 2018-04-13 21:43:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:43:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:43:48 --> Utf8 Class Initialized
INFO - 2018-04-13 21:43:48 --> URI Class Initialized
INFO - 2018-04-13 21:43:48 --> Router Class Initialized
INFO - 2018-04-13 21:43:48 --> Output Class Initialized
INFO - 2018-04-13 21:43:48 --> Security Class Initialized
DEBUG - 2018-04-13 21:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:43:48 --> CSRF cookie sent
INFO - 2018-04-13 21:43:48 --> Input Class Initialized
INFO - 2018-04-13 21:43:48 --> Language Class Initialized
ERROR - 2018-04-13 21:43:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:46:19 --> Config Class Initialized
INFO - 2018-04-13 21:46:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:19 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:19 --> URI Class Initialized
INFO - 2018-04-13 21:46:19 --> Router Class Initialized
INFO - 2018-04-13 21:46:19 --> Output Class Initialized
INFO - 2018-04-13 21:46:19 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:19 --> CSRF cookie sent
INFO - 2018-04-13 21:46:19 --> Input Class Initialized
INFO - 2018-04-13 21:46:19 --> Language Class Initialized
INFO - 2018-04-13 21:46:19 --> Loader Class Initialized
INFO - 2018-04-13 21:46:19 --> Helper loaded: url_helper
INFO - 2018-04-13 21:46:19 --> Helper loaded: form_helper
INFO - 2018-04-13 21:46:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:46:19 --> User Agent Class Initialized
INFO - 2018-04-13 21:46:19 --> Controller Class Initialized
INFO - 2018-04-13 21:46:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:46:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:46:19 --> Pixel_Model class loaded
INFO - 2018-04-13 21:46:19 --> Database Driver Class Initialized
INFO - 2018-04-13 21:46:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:46:22 --> Form Validation Class Initialized
INFO - 2018-04-13 21:46:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:46:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:46:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:46:22 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_info.php
INFO - 2018-04-13 21:46:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:46:22 --> Final output sent to browser
DEBUG - 2018-04-13 21:46:22 --> Total execution time: 3.5465
INFO - 2018-04-13 21:46:22 --> Config Class Initialized
INFO - 2018-04-13 21:46:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:23 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:23 --> URI Class Initialized
INFO - 2018-04-13 21:46:23 --> Router Class Initialized
INFO - 2018-04-13 21:46:23 --> Output Class Initialized
INFO - 2018-04-13 21:46:23 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:23 --> CSRF cookie sent
INFO - 2018-04-13 21:46:23 --> Input Class Initialized
INFO - 2018-04-13 21:46:23 --> Language Class Initialized
ERROR - 2018-04-13 21:46:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:46:44 --> Config Class Initialized
INFO - 2018-04-13 21:46:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:44 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:44 --> URI Class Initialized
INFO - 2018-04-13 21:46:44 --> Router Class Initialized
INFO - 2018-04-13 21:46:44 --> Output Class Initialized
INFO - 2018-04-13 21:46:44 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:44 --> CSRF cookie sent
INFO - 2018-04-13 21:46:45 --> CSRF token verified
INFO - 2018-04-13 21:46:45 --> Input Class Initialized
INFO - 2018-04-13 21:46:45 --> Language Class Initialized
INFO - 2018-04-13 21:46:45 --> Loader Class Initialized
INFO - 2018-04-13 21:46:45 --> Helper loaded: url_helper
INFO - 2018-04-13 21:46:45 --> Helper loaded: form_helper
INFO - 2018-04-13 21:46:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:46:45 --> User Agent Class Initialized
INFO - 2018-04-13 21:46:45 --> Controller Class Initialized
INFO - 2018-04-13 21:46:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:46:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:46:45 --> Pixel_Model class loaded
INFO - 2018-04-13 21:46:45 --> Database Driver Class Initialized
INFO - 2018-04-13 21:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:46:45 --> Form Validation Class Initialized
INFO - 2018-04-13 21:46:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:46:45 --> Config Class Initialized
INFO - 2018-04-13 21:46:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:45 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:45 --> URI Class Initialized
INFO - 2018-04-13 21:46:45 --> Router Class Initialized
INFO - 2018-04-13 21:46:45 --> Output Class Initialized
INFO - 2018-04-13 21:46:45 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:45 --> CSRF cookie sent
INFO - 2018-04-13 21:46:45 --> Input Class Initialized
INFO - 2018-04-13 21:46:45 --> Language Class Initialized
INFO - 2018-04-13 21:46:45 --> Loader Class Initialized
INFO - 2018-04-13 21:46:45 --> Helper loaded: url_helper
INFO - 2018-04-13 21:46:45 --> Helper loaded: form_helper
INFO - 2018-04-13 21:46:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:46:45 --> User Agent Class Initialized
INFO - 2018-04-13 21:46:45 --> Controller Class Initialized
INFO - 2018-04-13 21:46:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:46:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:46:45 --> Pixel_Model class loaded
INFO - 2018-04-13 21:46:45 --> Database Driver Class Initialized
INFO - 2018-04-13 21:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:46:45 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:46:45 --> Final output sent to browser
DEBUG - 2018-04-13 21:46:45 --> Total execution time: 0.5011
INFO - 2018-04-13 21:46:46 --> Config Class Initialized
INFO - 2018-04-13 21:46:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:46 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:46 --> URI Class Initialized
INFO - 2018-04-13 21:46:46 --> Router Class Initialized
INFO - 2018-04-13 21:46:46 --> Output Class Initialized
INFO - 2018-04-13 21:46:46 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:46 --> CSRF cookie sent
INFO - 2018-04-13 21:46:46 --> Input Class Initialized
INFO - 2018-04-13 21:46:46 --> Language Class Initialized
ERROR - 2018-04-13 21:46:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:46:55 --> Config Class Initialized
INFO - 2018-04-13 21:46:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:55 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:55 --> URI Class Initialized
INFO - 2018-04-13 21:46:55 --> Router Class Initialized
INFO - 2018-04-13 21:46:55 --> Output Class Initialized
INFO - 2018-04-13 21:46:55 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:55 --> CSRF cookie sent
INFO - 2018-04-13 21:46:55 --> Input Class Initialized
INFO - 2018-04-13 21:46:55 --> Language Class Initialized
INFO - 2018-04-13 21:46:55 --> Loader Class Initialized
INFO - 2018-04-13 21:46:55 --> Helper loaded: url_helper
INFO - 2018-04-13 21:46:55 --> Helper loaded: form_helper
INFO - 2018-04-13 21:46:55 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:46:55 --> User Agent Class Initialized
INFO - 2018-04-13 21:46:55 --> Controller Class Initialized
INFO - 2018-04-13 21:46:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:46:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:46:55 --> Pixel_Model class loaded
INFO - 2018-04-13 21:46:55 --> Database Driver Class Initialized
INFO - 2018-04-13 21:46:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:46:55 --> Form Validation Class Initialized
INFO - 2018-04-13 21:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:46:55 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_info.php
INFO - 2018-04-13 21:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:46:55 --> Final output sent to browser
DEBUG - 2018-04-13 21:46:55 --> Total execution time: 0.6782
INFO - 2018-04-13 21:46:56 --> Config Class Initialized
INFO - 2018-04-13 21:46:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:56 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:56 --> URI Class Initialized
INFO - 2018-04-13 21:46:56 --> Router Class Initialized
INFO - 2018-04-13 21:46:56 --> Output Class Initialized
INFO - 2018-04-13 21:46:56 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:56 --> CSRF cookie sent
INFO - 2018-04-13 21:46:56 --> Input Class Initialized
INFO - 2018-04-13 21:46:56 --> Language Class Initialized
ERROR - 2018-04-13 21:46:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:46:58 --> Config Class Initialized
INFO - 2018-04-13 21:46:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:58 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:58 --> URI Class Initialized
INFO - 2018-04-13 21:46:58 --> Router Class Initialized
INFO - 2018-04-13 21:46:58 --> Output Class Initialized
INFO - 2018-04-13 21:46:58 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:58 --> CSRF cookie sent
INFO - 2018-04-13 21:46:58 --> Input Class Initialized
INFO - 2018-04-13 21:46:58 --> Language Class Initialized
INFO - 2018-04-13 21:46:58 --> Loader Class Initialized
INFO - 2018-04-13 21:46:58 --> Helper loaded: url_helper
INFO - 2018-04-13 21:46:58 --> Helper loaded: form_helper
INFO - 2018-04-13 21:46:58 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:46:58 --> User Agent Class Initialized
INFO - 2018-04-13 21:46:58 --> Controller Class Initialized
INFO - 2018-04-13 21:46:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:46:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:46:58 --> Pixel_Model class loaded
INFO - 2018-04-13 21:46:58 --> Database Driver Class Initialized
INFO - 2018-04-13 21:46:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:46:58 --> Form Validation Class Initialized
INFO - 2018-04-13 21:46:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:46:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:46:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:46:58 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_info.php
INFO - 2018-04-13 21:46:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:46:58 --> Final output sent to browser
DEBUG - 2018-04-13 21:46:58 --> Total execution time: 0.5522
INFO - 2018-04-13 21:46:59 --> Config Class Initialized
INFO - 2018-04-13 21:46:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:46:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:46:59 --> Utf8 Class Initialized
INFO - 2018-04-13 21:46:59 --> URI Class Initialized
INFO - 2018-04-13 21:46:59 --> Router Class Initialized
INFO - 2018-04-13 21:46:59 --> Output Class Initialized
INFO - 2018-04-13 21:46:59 --> Security Class Initialized
DEBUG - 2018-04-13 21:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:46:59 --> CSRF cookie sent
INFO - 2018-04-13 21:46:59 --> Input Class Initialized
INFO - 2018-04-13 21:46:59 --> Language Class Initialized
ERROR - 2018-04-13 21:46:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:47:00 --> Config Class Initialized
INFO - 2018-04-13 21:47:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:47:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:47:00 --> Utf8 Class Initialized
INFO - 2018-04-13 21:47:00 --> URI Class Initialized
INFO - 2018-04-13 21:47:00 --> Router Class Initialized
INFO - 2018-04-13 21:47:00 --> Output Class Initialized
INFO - 2018-04-13 21:47:00 --> Security Class Initialized
DEBUG - 2018-04-13 21:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:47:00 --> CSRF cookie sent
INFO - 2018-04-13 21:47:00 --> Input Class Initialized
INFO - 2018-04-13 21:47:00 --> Language Class Initialized
INFO - 2018-04-13 21:47:01 --> Loader Class Initialized
INFO - 2018-04-13 21:47:01 --> Helper loaded: url_helper
INFO - 2018-04-13 21:47:01 --> Helper loaded: form_helper
INFO - 2018-04-13 21:47:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:47:01 --> User Agent Class Initialized
INFO - 2018-04-13 21:47:01 --> Controller Class Initialized
INFO - 2018-04-13 21:47:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:47:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:47:01 --> Pixel_Model class loaded
INFO - 2018-04-13 21:47:01 --> Database Driver Class Initialized
INFO - 2018-04-13 21:47:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:47:01 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:47:01 --> Final output sent to browser
DEBUG - 2018-04-13 21:47:01 --> Total execution time: 0.5301
INFO - 2018-04-13 21:47:01 --> Config Class Initialized
INFO - 2018-04-13 21:47:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:47:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:47:01 --> Utf8 Class Initialized
INFO - 2018-04-13 21:47:01 --> URI Class Initialized
INFO - 2018-04-13 21:47:01 --> Router Class Initialized
INFO - 2018-04-13 21:47:01 --> Output Class Initialized
INFO - 2018-04-13 21:47:01 --> Security Class Initialized
DEBUG - 2018-04-13 21:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:47:01 --> CSRF cookie sent
INFO - 2018-04-13 21:47:01 --> Input Class Initialized
INFO - 2018-04-13 21:47:01 --> Language Class Initialized
ERROR - 2018-04-13 21:47:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:49:24 --> Config Class Initialized
INFO - 2018-04-13 21:49:24 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:24 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:24 --> URI Class Initialized
INFO - 2018-04-13 21:49:24 --> Router Class Initialized
INFO - 2018-04-13 21:49:24 --> Output Class Initialized
INFO - 2018-04-13 21:49:24 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:24 --> CSRF cookie sent
INFO - 2018-04-13 21:49:24 --> Input Class Initialized
INFO - 2018-04-13 21:49:24 --> Language Class Initialized
INFO - 2018-04-13 21:49:24 --> Loader Class Initialized
INFO - 2018-04-13 21:49:24 --> Helper loaded: url_helper
INFO - 2018-04-13 21:49:24 --> Helper loaded: form_helper
INFO - 2018-04-13 21:49:24 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:49:24 --> User Agent Class Initialized
INFO - 2018-04-13 21:49:24 --> Controller Class Initialized
INFO - 2018-04-13 21:49:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:49:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:49:25 --> Pixel_Model class loaded
INFO - 2018-04-13 21:49:25 --> Database Driver Class Initialized
INFO - 2018-04-13 21:49:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:49:28 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:49:28 --> Final output sent to browser
DEBUG - 2018-04-13 21:49:28 --> Total execution time: 3.5520
INFO - 2018-04-13 21:49:28 --> Config Class Initialized
INFO - 2018-04-13 21:49:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:28 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:28 --> URI Class Initialized
INFO - 2018-04-13 21:49:28 --> Router Class Initialized
INFO - 2018-04-13 21:49:28 --> Output Class Initialized
INFO - 2018-04-13 21:49:28 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:28 --> CSRF cookie sent
INFO - 2018-04-13 21:49:28 --> Input Class Initialized
INFO - 2018-04-13 21:49:28 --> Language Class Initialized
ERROR - 2018-04-13 21:49:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:49:32 --> Config Class Initialized
INFO - 2018-04-13 21:49:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:32 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:32 --> URI Class Initialized
INFO - 2018-04-13 21:49:32 --> Router Class Initialized
INFO - 2018-04-13 21:49:32 --> Output Class Initialized
INFO - 2018-04-13 21:49:32 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:32 --> CSRF cookie sent
INFO - 2018-04-13 21:49:32 --> CSRF token verified
INFO - 2018-04-13 21:49:32 --> Input Class Initialized
INFO - 2018-04-13 21:49:32 --> Language Class Initialized
INFO - 2018-04-13 21:49:32 --> Loader Class Initialized
INFO - 2018-04-13 21:49:32 --> Helper loaded: url_helper
INFO - 2018-04-13 21:49:32 --> Helper loaded: form_helper
INFO - 2018-04-13 21:49:32 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:49:32 --> User Agent Class Initialized
INFO - 2018-04-13 21:49:32 --> Controller Class Initialized
INFO - 2018-04-13 21:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:49:32 --> Pixel_Model class loaded
INFO - 2018-04-13 21:49:32 --> Database Driver Class Initialized
INFO - 2018-04-13 21:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:49:32 --> Form Validation Class Initialized
INFO - 2018-04-13 21:49:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:49:32 --> Config Class Initialized
INFO - 2018-04-13 21:49:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:32 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:32 --> URI Class Initialized
INFO - 2018-04-13 21:49:32 --> Router Class Initialized
INFO - 2018-04-13 21:49:32 --> Output Class Initialized
INFO - 2018-04-13 21:49:32 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:32 --> CSRF cookie sent
INFO - 2018-04-13 21:49:32 --> Input Class Initialized
INFO - 2018-04-13 21:49:32 --> Language Class Initialized
ERROR - 2018-04-13 21:49:32 --> 404 Page Not Found: Your-job-info/index
INFO - 2018-04-13 21:49:37 --> Config Class Initialized
INFO - 2018-04-13 21:49:37 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:37 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:37 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:37 --> URI Class Initialized
INFO - 2018-04-13 21:49:37 --> Router Class Initialized
INFO - 2018-04-13 21:49:37 --> Output Class Initialized
INFO - 2018-04-13 21:49:37 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:37 --> CSRF cookie sent
INFO - 2018-04-13 21:49:37 --> Input Class Initialized
INFO - 2018-04-13 21:49:37 --> Language Class Initialized
INFO - 2018-04-13 21:49:37 --> Loader Class Initialized
INFO - 2018-04-13 21:49:37 --> Helper loaded: url_helper
INFO - 2018-04-13 21:49:37 --> Helper loaded: form_helper
INFO - 2018-04-13 21:49:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:49:37 --> User Agent Class Initialized
INFO - 2018-04-13 21:49:37 --> Controller Class Initialized
INFO - 2018-04-13 21:49:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:49:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:49:37 --> Pixel_Model class loaded
INFO - 2018-04-13 21:49:37 --> Database Driver Class Initialized
INFO - 2018-04-13 21:49:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:49:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:49:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:49:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:49:37 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:49:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:49:37 --> Final output sent to browser
DEBUG - 2018-04-13 21:49:37 --> Total execution time: 0.5020
INFO - 2018-04-13 21:49:38 --> Config Class Initialized
INFO - 2018-04-13 21:49:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:49:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:49:38 --> Utf8 Class Initialized
INFO - 2018-04-13 21:49:38 --> URI Class Initialized
INFO - 2018-04-13 21:49:38 --> Router Class Initialized
INFO - 2018-04-13 21:49:38 --> Output Class Initialized
INFO - 2018-04-13 21:49:38 --> Security Class Initialized
DEBUG - 2018-04-13 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:49:38 --> CSRF cookie sent
INFO - 2018-04-13 21:49:38 --> Input Class Initialized
INFO - 2018-04-13 21:49:38 --> Language Class Initialized
ERROR - 2018-04-13 21:49:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:50:09 --> Config Class Initialized
INFO - 2018-04-13 21:50:09 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:50:09 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:50:09 --> Utf8 Class Initialized
INFO - 2018-04-13 21:50:09 --> URI Class Initialized
INFO - 2018-04-13 21:50:09 --> Router Class Initialized
INFO - 2018-04-13 21:50:09 --> Output Class Initialized
INFO - 2018-04-13 21:50:09 --> Security Class Initialized
DEBUG - 2018-04-13 21:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:50:09 --> CSRF cookie sent
INFO - 2018-04-13 21:50:09 --> Input Class Initialized
INFO - 2018-04-13 21:50:09 --> Language Class Initialized
INFO - 2018-04-13 21:50:09 --> Loader Class Initialized
INFO - 2018-04-13 21:50:09 --> Helper loaded: url_helper
INFO - 2018-04-13 21:50:09 --> Helper loaded: form_helper
INFO - 2018-04-13 21:50:09 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:50:09 --> User Agent Class Initialized
INFO - 2018-04-13 21:50:09 --> Controller Class Initialized
INFO - 2018-04-13 21:50:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:50:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:50:09 --> Pixel_Model class loaded
INFO - 2018-04-13 21:50:09 --> Database Driver Class Initialized
INFO - 2018-04-13 21:50:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:50:10 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:50:10 --> Final output sent to browser
DEBUG - 2018-04-13 21:50:10 --> Total execution time: 0.5325
INFO - 2018-04-13 21:50:10 --> Config Class Initialized
INFO - 2018-04-13 21:50:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:50:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:50:10 --> Utf8 Class Initialized
INFO - 2018-04-13 21:50:10 --> URI Class Initialized
INFO - 2018-04-13 21:50:10 --> Router Class Initialized
INFO - 2018-04-13 21:50:10 --> Output Class Initialized
INFO - 2018-04-13 21:50:10 --> Security Class Initialized
DEBUG - 2018-04-13 21:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:50:10 --> CSRF cookie sent
INFO - 2018-04-13 21:50:10 --> Input Class Initialized
INFO - 2018-04-13 21:50:10 --> Language Class Initialized
ERROR - 2018-04-13 21:50:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:50:22 --> Config Class Initialized
INFO - 2018-04-13 21:50:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:50:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:50:22 --> Utf8 Class Initialized
INFO - 2018-04-13 21:50:22 --> URI Class Initialized
INFO - 2018-04-13 21:50:22 --> Router Class Initialized
INFO - 2018-04-13 21:50:22 --> Output Class Initialized
INFO - 2018-04-13 21:50:22 --> Security Class Initialized
DEBUG - 2018-04-13 21:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:50:22 --> CSRF cookie sent
INFO - 2018-04-13 21:50:22 --> CSRF token verified
INFO - 2018-04-13 21:50:22 --> Input Class Initialized
INFO - 2018-04-13 21:50:22 --> Language Class Initialized
INFO - 2018-04-13 21:50:22 --> Loader Class Initialized
INFO - 2018-04-13 21:50:22 --> Helper loaded: url_helper
INFO - 2018-04-13 21:50:22 --> Helper loaded: form_helper
INFO - 2018-04-13 21:50:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:50:22 --> User Agent Class Initialized
INFO - 2018-04-13 21:50:22 --> Controller Class Initialized
INFO - 2018-04-13 21:50:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:50:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:50:22 --> Pixel_Model class loaded
INFO - 2018-04-13 21:50:22 --> Database Driver Class Initialized
INFO - 2018-04-13 21:50:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:50:22 --> Form Validation Class Initialized
INFO - 2018-04-13 21:50:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:50:22 --> Config Class Initialized
INFO - 2018-04-13 21:50:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:50:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:50:23 --> Utf8 Class Initialized
INFO - 2018-04-13 21:50:23 --> URI Class Initialized
INFO - 2018-04-13 21:50:23 --> Router Class Initialized
INFO - 2018-04-13 21:50:23 --> Output Class Initialized
INFO - 2018-04-13 21:50:23 --> Security Class Initialized
DEBUG - 2018-04-13 21:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:50:23 --> CSRF cookie sent
INFO - 2018-04-13 21:50:23 --> Input Class Initialized
INFO - 2018-04-13 21:50:23 --> Language Class Initialized
ERROR - 2018-04-13 21:50:23 --> 404 Page Not Found: Your-job-info/index
INFO - 2018-04-13 21:51:34 --> Config Class Initialized
INFO - 2018-04-13 21:51:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:34 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:34 --> URI Class Initialized
INFO - 2018-04-13 21:51:34 --> Router Class Initialized
INFO - 2018-04-13 21:51:34 --> Output Class Initialized
INFO - 2018-04-13 21:51:34 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:34 --> CSRF cookie sent
INFO - 2018-04-13 21:51:34 --> Input Class Initialized
INFO - 2018-04-13 21:51:34 --> Language Class Initialized
INFO - 2018-04-13 21:51:34 --> Loader Class Initialized
INFO - 2018-04-13 21:51:34 --> Helper loaded: url_helper
INFO - 2018-04-13 21:51:34 --> Helper loaded: form_helper
INFO - 2018-04-13 21:51:34 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:51:34 --> User Agent Class Initialized
INFO - 2018-04-13 21:51:34 --> Controller Class Initialized
INFO - 2018-04-13 21:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:51:34 --> Pixel_Model class loaded
INFO - 2018-04-13 21:51:34 --> Database Driver Class Initialized
INFO - 2018-04-13 21:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:51:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:51:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:51:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:51:38 --> File loaded: E:\www\yacopoo\application\views\questions/spouse_job.php
INFO - 2018-04-13 21:51:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:51:38 --> Final output sent to browser
DEBUG - 2018-04-13 21:51:38 --> Total execution time: 3.8087
INFO - 2018-04-13 21:51:38 --> Config Class Initialized
INFO - 2018-04-13 21:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:38 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:38 --> URI Class Initialized
INFO - 2018-04-13 21:51:38 --> Router Class Initialized
INFO - 2018-04-13 21:51:38 --> Output Class Initialized
INFO - 2018-04-13 21:51:38 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:38 --> CSRF cookie sent
INFO - 2018-04-13 21:51:38 --> Input Class Initialized
INFO - 2018-04-13 21:51:38 --> Language Class Initialized
ERROR - 2018-04-13 21:51:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:51:40 --> Config Class Initialized
INFO - 2018-04-13 21:51:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:40 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:40 --> URI Class Initialized
INFO - 2018-04-13 21:51:40 --> Router Class Initialized
INFO - 2018-04-13 21:51:40 --> Output Class Initialized
INFO - 2018-04-13 21:51:40 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:40 --> CSRF cookie sent
INFO - 2018-04-13 21:51:40 --> CSRF token verified
INFO - 2018-04-13 21:51:40 --> Input Class Initialized
INFO - 2018-04-13 21:51:40 --> Language Class Initialized
INFO - 2018-04-13 21:51:40 --> Loader Class Initialized
INFO - 2018-04-13 21:51:40 --> Helper loaded: url_helper
INFO - 2018-04-13 21:51:40 --> Helper loaded: form_helper
INFO - 2018-04-13 21:51:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:51:40 --> User Agent Class Initialized
INFO - 2018-04-13 21:51:40 --> Controller Class Initialized
INFO - 2018-04-13 21:51:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:51:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:51:40 --> Pixel_Model class loaded
INFO - 2018-04-13 21:51:40 --> Database Driver Class Initialized
INFO - 2018-04-13 21:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:51:40 --> Form Validation Class Initialized
INFO - 2018-04-13 21:51:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:51:40 --> Config Class Initialized
INFO - 2018-04-13 21:51:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:40 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:40 --> URI Class Initialized
INFO - 2018-04-13 21:51:40 --> Router Class Initialized
INFO - 2018-04-13 21:51:41 --> Output Class Initialized
INFO - 2018-04-13 21:51:41 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:41 --> CSRF cookie sent
INFO - 2018-04-13 21:51:41 --> Input Class Initialized
INFO - 2018-04-13 21:51:41 --> Language Class Initialized
INFO - 2018-04-13 21:51:41 --> Loader Class Initialized
INFO - 2018-04-13 21:51:41 --> Helper loaded: url_helper
INFO - 2018-04-13 21:51:41 --> Helper loaded: form_helper
INFO - 2018-04-13 21:51:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:51:41 --> User Agent Class Initialized
INFO - 2018-04-13 21:51:41 --> Controller Class Initialized
INFO - 2018-04-13 21:51:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:51:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:51:41 --> Pixel_Model class loaded
INFO - 2018-04-13 21:51:41 --> Database Driver Class Initialized
INFO - 2018-04-13 21:51:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:51:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:51:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:51:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:51:41 --> File loaded: E:\www\yacopoo\application\views\questions/your_job.php
INFO - 2018-04-13 21:51:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:51:41 --> Final output sent to browser
DEBUG - 2018-04-13 21:51:41 --> Total execution time: 0.5210
INFO - 2018-04-13 21:51:41 --> Config Class Initialized
INFO - 2018-04-13 21:51:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:41 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:41 --> URI Class Initialized
INFO - 2018-04-13 21:51:42 --> Router Class Initialized
INFO - 2018-04-13 21:51:42 --> Output Class Initialized
INFO - 2018-04-13 21:51:42 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:42 --> CSRF cookie sent
INFO - 2018-04-13 21:51:42 --> Input Class Initialized
INFO - 2018-04-13 21:51:42 --> Language Class Initialized
ERROR - 2018-04-13 21:51:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:51:49 --> Config Class Initialized
INFO - 2018-04-13 21:51:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:49 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:49 --> URI Class Initialized
INFO - 2018-04-13 21:51:49 --> Router Class Initialized
INFO - 2018-04-13 21:51:49 --> Output Class Initialized
INFO - 2018-04-13 21:51:49 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:49 --> CSRF cookie sent
INFO - 2018-04-13 21:51:49 --> CSRF token verified
INFO - 2018-04-13 21:51:49 --> Input Class Initialized
INFO - 2018-04-13 21:51:49 --> Language Class Initialized
INFO - 2018-04-13 21:51:49 --> Loader Class Initialized
INFO - 2018-04-13 21:51:49 --> Helper loaded: url_helper
INFO - 2018-04-13 21:51:49 --> Helper loaded: form_helper
INFO - 2018-04-13 21:51:49 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:51:49 --> User Agent Class Initialized
INFO - 2018-04-13 21:51:49 --> Controller Class Initialized
INFO - 2018-04-13 21:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:51:49 --> Pixel_Model class loaded
INFO - 2018-04-13 21:51:49 --> Database Driver Class Initialized
INFO - 2018-04-13 21:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:51:49 --> Form Validation Class Initialized
INFO - 2018-04-13 21:51:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:51:49 --> Config Class Initialized
INFO - 2018-04-13 21:51:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:49 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:49 --> URI Class Initialized
INFO - 2018-04-13 21:51:49 --> Router Class Initialized
INFO - 2018-04-13 21:51:49 --> Output Class Initialized
INFO - 2018-04-13 21:51:49 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:49 --> CSRF cookie sent
INFO - 2018-04-13 21:51:49 --> Input Class Initialized
INFO - 2018-04-13 21:51:49 --> Language Class Initialized
INFO - 2018-04-13 21:51:49 --> Loader Class Initialized
INFO - 2018-04-13 21:51:49 --> Helper loaded: url_helper
INFO - 2018-04-13 21:51:49 --> Helper loaded: form_helper
INFO - 2018-04-13 21:51:49 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:51:49 --> User Agent Class Initialized
INFO - 2018-04-13 21:51:49 --> Controller Class Initialized
INFO - 2018-04-13 21:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:51:49 --> Pixel_Model class loaded
INFO - 2018-04-13 21:51:49 --> Database Driver Class Initialized
INFO - 2018-04-13 21:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:51:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:51:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:51:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:51:50 --> File loaded: E:\www\yacopoo\application\views\questions/business_tax_info.php
INFO - 2018-04-13 21:51:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:51:50 --> Final output sent to browser
DEBUG - 2018-04-13 21:51:50 --> Total execution time: 0.5469
INFO - 2018-04-13 21:51:50 --> Config Class Initialized
INFO - 2018-04-13 21:51:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:51:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:51:50 --> Utf8 Class Initialized
INFO - 2018-04-13 21:51:50 --> URI Class Initialized
INFO - 2018-04-13 21:51:50 --> Router Class Initialized
INFO - 2018-04-13 21:51:50 --> Output Class Initialized
INFO - 2018-04-13 21:51:50 --> Security Class Initialized
DEBUG - 2018-04-13 21:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:51:50 --> CSRF cookie sent
INFO - 2018-04-13 21:51:50 --> Input Class Initialized
INFO - 2018-04-13 21:51:50 --> Language Class Initialized
ERROR - 2018-04-13 21:51:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:52:36 --> Config Class Initialized
INFO - 2018-04-13 21:52:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:52:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:52:37 --> Utf8 Class Initialized
INFO - 2018-04-13 21:52:37 --> URI Class Initialized
INFO - 2018-04-13 21:52:37 --> Router Class Initialized
INFO - 2018-04-13 21:52:37 --> Output Class Initialized
INFO - 2018-04-13 21:52:37 --> Security Class Initialized
DEBUG - 2018-04-13 21:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:52:37 --> CSRF cookie sent
INFO - 2018-04-13 21:52:37 --> CSRF token verified
INFO - 2018-04-13 21:52:37 --> Input Class Initialized
INFO - 2018-04-13 21:52:37 --> Language Class Initialized
INFO - 2018-04-13 21:52:37 --> Loader Class Initialized
INFO - 2018-04-13 21:52:37 --> Helper loaded: url_helper
INFO - 2018-04-13 21:52:37 --> Helper loaded: form_helper
INFO - 2018-04-13 21:52:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:52:37 --> User Agent Class Initialized
INFO - 2018-04-13 21:52:37 --> Controller Class Initialized
INFO - 2018-04-13 21:52:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:52:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:52:37 --> Pixel_Model class loaded
INFO - 2018-04-13 21:52:37 --> Database Driver Class Initialized
INFO - 2018-04-13 21:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:52:37 --> Form Validation Class Initialized
INFO - 2018-04-13 21:52:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:52:37 --> Config Class Initialized
INFO - 2018-04-13 21:52:37 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:52:37 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:52:37 --> Utf8 Class Initialized
INFO - 2018-04-13 21:52:37 --> URI Class Initialized
INFO - 2018-04-13 21:52:37 --> Router Class Initialized
INFO - 2018-04-13 21:52:37 --> Output Class Initialized
INFO - 2018-04-13 21:52:37 --> Security Class Initialized
DEBUG - 2018-04-13 21:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:52:37 --> CSRF cookie sent
INFO - 2018-04-13 21:52:37 --> Input Class Initialized
INFO - 2018-04-13 21:52:37 --> Language Class Initialized
INFO - 2018-04-13 21:52:37 --> Loader Class Initialized
INFO - 2018-04-13 21:52:37 --> Helper loaded: url_helper
INFO - 2018-04-13 21:52:37 --> Helper loaded: form_helper
INFO - 2018-04-13 21:52:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:52:37 --> User Agent Class Initialized
INFO - 2018-04-13 21:52:37 --> Controller Class Initialized
INFO - 2018-04-13 21:52:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:52:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:52:37 --> Pixel_Model class loaded
INFO - 2018-04-13 21:52:37 --> Database Driver Class Initialized
INFO - 2018-04-13 21:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:52:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:52:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:52:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:52:37 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 21:52:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:52:37 --> Final output sent to browser
DEBUG - 2018-04-13 21:52:38 --> Total execution time: 0.5284
INFO - 2018-04-13 21:52:38 --> Config Class Initialized
INFO - 2018-04-13 21:52:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:52:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:52:38 --> Utf8 Class Initialized
INFO - 2018-04-13 21:52:38 --> URI Class Initialized
INFO - 2018-04-13 21:52:38 --> Router Class Initialized
INFO - 2018-04-13 21:52:38 --> Output Class Initialized
INFO - 2018-04-13 21:52:38 --> Security Class Initialized
DEBUG - 2018-04-13 21:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:52:38 --> CSRF cookie sent
INFO - 2018-04-13 21:52:38 --> Input Class Initialized
INFO - 2018-04-13 21:52:38 --> Language Class Initialized
ERROR - 2018-04-13 21:52:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:56:52 --> Config Class Initialized
INFO - 2018-04-13 21:56:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:56:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:56:52 --> Utf8 Class Initialized
INFO - 2018-04-13 21:56:52 --> URI Class Initialized
INFO - 2018-04-13 21:56:52 --> Router Class Initialized
INFO - 2018-04-13 21:56:52 --> Output Class Initialized
INFO - 2018-04-13 21:56:52 --> Security Class Initialized
DEBUG - 2018-04-13 21:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:56:52 --> CSRF cookie sent
INFO - 2018-04-13 21:56:52 --> Input Class Initialized
INFO - 2018-04-13 21:56:52 --> Language Class Initialized
INFO - 2018-04-13 21:56:52 --> Loader Class Initialized
INFO - 2018-04-13 21:56:52 --> Helper loaded: url_helper
INFO - 2018-04-13 21:56:52 --> Helper loaded: form_helper
INFO - 2018-04-13 21:56:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:56:52 --> User Agent Class Initialized
INFO - 2018-04-13 21:56:52 --> Controller Class Initialized
INFO - 2018-04-13 21:56:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:56:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:56:53 --> Pixel_Model class loaded
INFO - 2018-04-13 21:56:53 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:57:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:57:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:57:02 --> File loaded: E:\www\yacopoo\application\views\questions/business_tax_info.php
INFO - 2018-04-13 21:57:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:57:02 --> Final output sent to browser
DEBUG - 2018-04-13 21:57:02 --> Total execution time: 9.5773
INFO - 2018-04-13 21:57:02 --> Config Class Initialized
INFO - 2018-04-13 21:57:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:02 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:02 --> URI Class Initialized
INFO - 2018-04-13 21:57:02 --> Router Class Initialized
INFO - 2018-04-13 21:57:02 --> Output Class Initialized
INFO - 2018-04-13 21:57:02 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:02 --> CSRF cookie sent
INFO - 2018-04-13 21:57:02 --> Input Class Initialized
INFO - 2018-04-13 21:57:02 --> Language Class Initialized
ERROR - 2018-04-13 21:57:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:57:06 --> Config Class Initialized
INFO - 2018-04-13 21:57:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:06 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:06 --> URI Class Initialized
INFO - 2018-04-13 21:57:06 --> Router Class Initialized
INFO - 2018-04-13 21:57:06 --> Output Class Initialized
INFO - 2018-04-13 21:57:06 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:06 --> CSRF cookie sent
INFO - 2018-04-13 21:57:06 --> Input Class Initialized
INFO - 2018-04-13 21:57:06 --> Language Class Initialized
INFO - 2018-04-13 21:57:06 --> Loader Class Initialized
INFO - 2018-04-13 21:57:06 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:06 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:06 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:06 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:06 --> Controller Class Initialized
INFO - 2018-04-13 21:57:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:06 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:06 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:57:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:57:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:57:06 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 21:57:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:57:06 --> Final output sent to browser
DEBUG - 2018-04-13 21:57:06 --> Total execution time: 0.5330
INFO - 2018-04-13 21:57:07 --> Config Class Initialized
INFO - 2018-04-13 21:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:07 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:07 --> URI Class Initialized
INFO - 2018-04-13 21:57:07 --> Router Class Initialized
INFO - 2018-04-13 21:57:07 --> Output Class Initialized
INFO - 2018-04-13 21:57:07 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:07 --> CSRF cookie sent
INFO - 2018-04-13 21:57:07 --> Input Class Initialized
INFO - 2018-04-13 21:57:07 --> Language Class Initialized
ERROR - 2018-04-13 21:57:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:57:10 --> Config Class Initialized
INFO - 2018-04-13 21:57:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:10 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:10 --> URI Class Initialized
INFO - 2018-04-13 21:57:10 --> Router Class Initialized
INFO - 2018-04-13 21:57:10 --> Output Class Initialized
INFO - 2018-04-13 21:57:10 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:10 --> CSRF cookie sent
INFO - 2018-04-13 21:57:10 --> CSRF token verified
INFO - 2018-04-13 21:57:10 --> Input Class Initialized
INFO - 2018-04-13 21:57:10 --> Language Class Initialized
INFO - 2018-04-13 21:57:10 --> Loader Class Initialized
INFO - 2018-04-13 21:57:10 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:10 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:10 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:10 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:10 --> Controller Class Initialized
INFO - 2018-04-13 21:57:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:10 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:10 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:10 --> Form Validation Class Initialized
INFO - 2018-04-13 21:57:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:57:10 --> Config Class Initialized
INFO - 2018-04-13 21:57:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:10 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:10 --> URI Class Initialized
INFO - 2018-04-13 21:57:10 --> Router Class Initialized
INFO - 2018-04-13 21:57:10 --> Output Class Initialized
INFO - 2018-04-13 21:57:10 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:10 --> CSRF cookie sent
INFO - 2018-04-13 21:57:11 --> Input Class Initialized
INFO - 2018-04-13 21:57:11 --> Language Class Initialized
ERROR - 2018-04-13 21:57:11 --> 404 Page Not Found: Shift-work/index
INFO - 2018-04-13 21:57:49 --> Config Class Initialized
INFO - 2018-04-13 21:57:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:49 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:49 --> URI Class Initialized
INFO - 2018-04-13 21:57:49 --> Router Class Initialized
INFO - 2018-04-13 21:57:49 --> Output Class Initialized
INFO - 2018-04-13 21:57:49 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:49 --> CSRF cookie sent
INFO - 2018-04-13 21:57:49 --> Input Class Initialized
INFO - 2018-04-13 21:57:49 --> Language Class Initialized
INFO - 2018-04-13 21:57:49 --> Loader Class Initialized
INFO - 2018-04-13 21:57:49 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:49 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:49 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:49 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:49 --> Controller Class Initialized
INFO - 2018-04-13 21:57:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:49 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:49 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:57:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:57:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:57:49 --> File loaded: E:\www\yacopoo\application\views\questions/shift_work.php
INFO - 2018-04-13 21:57:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:57:49 --> Final output sent to browser
DEBUG - 2018-04-13 21:57:49 --> Total execution time: 0.5455
INFO - 2018-04-13 21:57:50 --> Config Class Initialized
INFO - 2018-04-13 21:57:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:50 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:50 --> URI Class Initialized
INFO - 2018-04-13 21:57:50 --> Router Class Initialized
INFO - 2018-04-13 21:57:50 --> Output Class Initialized
INFO - 2018-04-13 21:57:50 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:50 --> CSRF cookie sent
INFO - 2018-04-13 21:57:50 --> Input Class Initialized
INFO - 2018-04-13 21:57:50 --> Language Class Initialized
ERROR - 2018-04-13 21:57:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:57:53 --> Config Class Initialized
INFO - 2018-04-13 21:57:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:53 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:53 --> URI Class Initialized
INFO - 2018-04-13 21:57:53 --> Router Class Initialized
INFO - 2018-04-13 21:57:53 --> Output Class Initialized
INFO - 2018-04-13 21:57:53 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:53 --> CSRF cookie sent
INFO - 2018-04-13 21:57:53 --> CSRF token verified
INFO - 2018-04-13 21:57:53 --> Input Class Initialized
INFO - 2018-04-13 21:57:53 --> Language Class Initialized
INFO - 2018-04-13 21:57:53 --> Loader Class Initialized
INFO - 2018-04-13 21:57:53 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:54 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:54 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:54 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:54 --> Controller Class Initialized
INFO - 2018-04-13 21:57:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:54 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:54 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:54 --> Form Validation Class Initialized
INFO - 2018-04-13 21:57:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:57:54 --> Config Class Initialized
INFO - 2018-04-13 21:57:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:54 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:54 --> URI Class Initialized
INFO - 2018-04-13 21:57:54 --> Router Class Initialized
INFO - 2018-04-13 21:57:54 --> Output Class Initialized
INFO - 2018-04-13 21:57:54 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:54 --> CSRF cookie sent
INFO - 2018-04-13 21:57:54 --> Input Class Initialized
INFO - 2018-04-13 21:57:54 --> Language Class Initialized
INFO - 2018-04-13 21:57:54 --> Loader Class Initialized
INFO - 2018-04-13 21:57:54 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:54 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:54 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:54 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:54 --> Controller Class Initialized
INFO - 2018-04-13 21:57:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:54 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:54 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:57:54 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 21:57:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:57:54 --> Final output sent to browser
DEBUG - 2018-04-13 21:57:54 --> Total execution time: 0.5327
INFO - 2018-04-13 21:57:55 --> Config Class Initialized
INFO - 2018-04-13 21:57:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:55 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:55 --> URI Class Initialized
INFO - 2018-04-13 21:57:55 --> Router Class Initialized
INFO - 2018-04-13 21:57:55 --> Output Class Initialized
INFO - 2018-04-13 21:57:55 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:55 --> CSRF cookie sent
INFO - 2018-04-13 21:57:55 --> Input Class Initialized
INFO - 2018-04-13 21:57:55 --> Language Class Initialized
ERROR - 2018-04-13 21:57:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 21:57:58 --> Config Class Initialized
INFO - 2018-04-13 21:57:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:58 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:58 --> URI Class Initialized
INFO - 2018-04-13 21:57:58 --> Router Class Initialized
INFO - 2018-04-13 21:57:58 --> Output Class Initialized
INFO - 2018-04-13 21:57:58 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:58 --> CSRF cookie sent
INFO - 2018-04-13 21:57:58 --> CSRF token verified
INFO - 2018-04-13 21:57:58 --> Input Class Initialized
INFO - 2018-04-13 21:57:58 --> Language Class Initialized
INFO - 2018-04-13 21:57:58 --> Loader Class Initialized
INFO - 2018-04-13 21:57:58 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:58 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:58 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:58 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:58 --> Controller Class Initialized
INFO - 2018-04-13 21:57:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:58 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:58 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:58 --> Form Validation Class Initialized
INFO - 2018-04-13 21:57:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 21:57:59 --> Config Class Initialized
INFO - 2018-04-13 21:57:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:57:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:57:59 --> Utf8 Class Initialized
INFO - 2018-04-13 21:57:59 --> URI Class Initialized
INFO - 2018-04-13 21:57:59 --> Router Class Initialized
INFO - 2018-04-13 21:57:59 --> Output Class Initialized
INFO - 2018-04-13 21:57:59 --> Security Class Initialized
DEBUG - 2018-04-13 21:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:57:59 --> CSRF cookie sent
INFO - 2018-04-13 21:57:59 --> Input Class Initialized
INFO - 2018-04-13 21:57:59 --> Language Class Initialized
INFO - 2018-04-13 21:57:59 --> Loader Class Initialized
INFO - 2018-04-13 21:57:59 --> Helper loaded: url_helper
INFO - 2018-04-13 21:57:59 --> Helper loaded: form_helper
INFO - 2018-04-13 21:57:59 --> Helper loaded: language_helper
DEBUG - 2018-04-13 21:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 21:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 21:57:59 --> User Agent Class Initialized
INFO - 2018-04-13 21:57:59 --> Controller Class Initialized
INFO - 2018-04-13 21:57:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 21:57:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 21:57:59 --> Pixel_Model class loaded
INFO - 2018-04-13 21:57:59 --> Database Driver Class Initialized
INFO - 2018-04-13 21:57:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 21:57:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 21:57:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 21:57:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 21:57:59 --> File loaded: E:\www\yacopoo\application\views\questions/shift_work.php
INFO - 2018-04-13 21:57:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 21:57:59 --> Final output sent to browser
DEBUG - 2018-04-13 21:57:59 --> Total execution time: 0.5103
INFO - 2018-04-13 21:57:59 --> Config Class Initialized
INFO - 2018-04-13 21:57:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 21:58:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 21:58:00 --> Utf8 Class Initialized
INFO - 2018-04-13 21:58:00 --> URI Class Initialized
INFO - 2018-04-13 21:58:00 --> Router Class Initialized
INFO - 2018-04-13 21:58:00 --> Output Class Initialized
INFO - 2018-04-13 21:58:00 --> Security Class Initialized
DEBUG - 2018-04-13 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 21:58:00 --> CSRF cookie sent
INFO - 2018-04-13 21:58:00 --> Input Class Initialized
INFO - 2018-04-13 21:58:00 --> Language Class Initialized
ERROR - 2018-04-13 21:58:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:28:21 --> Config Class Initialized
INFO - 2018-04-13 22:28:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:21 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:21 --> URI Class Initialized
INFO - 2018-04-13 22:28:21 --> Router Class Initialized
INFO - 2018-04-13 22:28:21 --> Output Class Initialized
INFO - 2018-04-13 22:28:21 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:21 --> CSRF cookie sent
INFO - 2018-04-13 22:28:21 --> Input Class Initialized
INFO - 2018-04-13 22:28:21 --> Language Class Initialized
INFO - 2018-04-13 22:28:21 --> Loader Class Initialized
INFO - 2018-04-13 22:28:21 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:21 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:21 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:21 --> Controller Class Initialized
INFO - 2018-04-13 22:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:21 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:21 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:28:24 --> File loaded: E:\www\yacopoo\application\views\questions/shift_work.php
INFO - 2018-04-13 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:28:24 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:24 --> Total execution time: 3.5541
INFO - 2018-04-13 22:28:25 --> Config Class Initialized
INFO - 2018-04-13 22:28:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:25 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:25 --> URI Class Initialized
INFO - 2018-04-13 22:28:25 --> Router Class Initialized
INFO - 2018-04-13 22:28:25 --> Output Class Initialized
INFO - 2018-04-13 22:28:25 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:25 --> CSRF cookie sent
INFO - 2018-04-13 22:28:25 --> Input Class Initialized
INFO - 2018-04-13 22:28:25 --> Language Class Initialized
ERROR - 2018-04-13 22:28:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:28:30 --> Config Class Initialized
INFO - 2018-04-13 22:28:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:30 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:30 --> URI Class Initialized
INFO - 2018-04-13 22:28:30 --> Router Class Initialized
INFO - 2018-04-13 22:28:30 --> Output Class Initialized
INFO - 2018-04-13 22:28:30 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:30 --> CSRF cookie sent
INFO - 2018-04-13 22:28:30 --> CSRF token verified
INFO - 2018-04-13 22:28:30 --> Input Class Initialized
INFO - 2018-04-13 22:28:30 --> Language Class Initialized
INFO - 2018-04-13 22:28:30 --> Loader Class Initialized
INFO - 2018-04-13 22:28:30 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:30 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:30 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:30 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:30 --> Controller Class Initialized
INFO - 2018-04-13 22:28:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:30 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:30 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:31 --> Form Validation Class Initialized
INFO - 2018-04-13 22:28:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:28:31 --> Config Class Initialized
INFO - 2018-04-13 22:28:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:31 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:31 --> URI Class Initialized
INFO - 2018-04-13 22:28:31 --> Router Class Initialized
INFO - 2018-04-13 22:28:31 --> Output Class Initialized
INFO - 2018-04-13 22:28:31 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:31 --> CSRF cookie sent
INFO - 2018-04-13 22:28:31 --> Input Class Initialized
INFO - 2018-04-13 22:28:31 --> Language Class Initialized
INFO - 2018-04-13 22:28:31 --> Loader Class Initialized
INFO - 2018-04-13 22:28:31 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:31 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:31 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:31 --> Controller Class Initialized
INFO - 2018-04-13 22:28:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:31 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:31 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:28:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:28:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:28:31 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 22:28:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:28:31 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:31 --> Total execution time: 0.5341
INFO - 2018-04-13 22:28:31 --> Config Class Initialized
INFO - 2018-04-13 22:28:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:31 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:32 --> URI Class Initialized
INFO - 2018-04-13 22:28:32 --> Router Class Initialized
INFO - 2018-04-13 22:28:32 --> Output Class Initialized
INFO - 2018-04-13 22:28:32 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:32 --> CSRF cookie sent
INFO - 2018-04-13 22:28:32 --> Input Class Initialized
INFO - 2018-04-13 22:28:32 --> Language Class Initialized
ERROR - 2018-04-13 22:28:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:28:38 --> Config Class Initialized
INFO - 2018-04-13 22:28:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:38 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:38 --> URI Class Initialized
INFO - 2018-04-13 22:28:38 --> Router Class Initialized
INFO - 2018-04-13 22:28:38 --> Output Class Initialized
INFO - 2018-04-13 22:28:38 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:38 --> CSRF cookie sent
INFO - 2018-04-13 22:28:38 --> CSRF token verified
INFO - 2018-04-13 22:28:38 --> Input Class Initialized
INFO - 2018-04-13 22:28:38 --> Language Class Initialized
INFO - 2018-04-13 22:28:38 --> Loader Class Initialized
INFO - 2018-04-13 22:28:38 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:38 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:38 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:38 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:38 --> Controller Class Initialized
INFO - 2018-04-13 22:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:38 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:38 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:38 --> Form Validation Class Initialized
INFO - 2018-04-13 22:28:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:28:38 --> Config Class Initialized
INFO - 2018-04-13 22:28:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:38 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:38 --> URI Class Initialized
INFO - 2018-04-13 22:28:38 --> Router Class Initialized
INFO - 2018-04-13 22:28:38 --> Output Class Initialized
INFO - 2018-04-13 22:28:38 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:38 --> CSRF cookie sent
INFO - 2018-04-13 22:28:38 --> Input Class Initialized
INFO - 2018-04-13 22:28:38 --> Language Class Initialized
INFO - 2018-04-13 22:28:38 --> Loader Class Initialized
INFO - 2018-04-13 22:28:38 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:38 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:39 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:39 --> Controller Class Initialized
INFO - 2018-04-13 22:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:39 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:39 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:28:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:28:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:28:39 --> File loaded: E:\www\yacopoo\application\views\questions/shift_work.php
INFO - 2018-04-13 22:28:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:28:39 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:39 --> Total execution time: 0.5812
INFO - 2018-04-13 22:28:39 --> Config Class Initialized
INFO - 2018-04-13 22:28:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:39 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:39 --> URI Class Initialized
INFO - 2018-04-13 22:28:39 --> Router Class Initialized
INFO - 2018-04-13 22:28:39 --> Output Class Initialized
INFO - 2018-04-13 22:28:39 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:39 --> CSRF cookie sent
INFO - 2018-04-13 22:28:39 --> Input Class Initialized
INFO - 2018-04-13 22:28:39 --> Language Class Initialized
ERROR - 2018-04-13 22:28:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:28:41 --> Config Class Initialized
INFO - 2018-04-13 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:41 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:41 --> URI Class Initialized
INFO - 2018-04-13 22:28:41 --> Router Class Initialized
INFO - 2018-04-13 22:28:41 --> Output Class Initialized
INFO - 2018-04-13 22:28:41 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:41 --> CSRF cookie sent
INFO - 2018-04-13 22:28:41 --> CSRF token verified
INFO - 2018-04-13 22:28:41 --> Input Class Initialized
INFO - 2018-04-13 22:28:41 --> Language Class Initialized
INFO - 2018-04-13 22:28:41 --> Loader Class Initialized
INFO - 2018-04-13 22:28:41 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:41 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:41 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:41 --> Controller Class Initialized
INFO - 2018-04-13 22:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:41 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:41 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:41 --> Form Validation Class Initialized
INFO - 2018-04-13 22:28:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:28:41 --> Config Class Initialized
INFO - 2018-04-13 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:41 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:41 --> URI Class Initialized
INFO - 2018-04-13 22:28:41 --> Router Class Initialized
INFO - 2018-04-13 22:28:41 --> Output Class Initialized
INFO - 2018-04-13 22:28:41 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:42 --> CSRF cookie sent
INFO - 2018-04-13 22:28:42 --> Input Class Initialized
INFO - 2018-04-13 22:28:42 --> Language Class Initialized
INFO - 2018-04-13 22:28:42 --> Loader Class Initialized
INFO - 2018-04-13 22:28:42 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:42 --> Helper loaded: form_helper
INFO - 2018-04-13 22:28:42 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:42 --> User Agent Class Initialized
INFO - 2018-04-13 22:28:42 --> Controller Class Initialized
INFO - 2018-04-13 22:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:28:42 --> Pixel_Model class loaded
INFO - 2018-04-13 22:28:42 --> Database Driver Class Initialized
INFO - 2018-04-13 22:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:28:42 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 22:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:28:42 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:42 --> Total execution time: 0.6129
INFO - 2018-04-13 22:28:42 --> Config Class Initialized
INFO - 2018-04-13 22:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:42 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:42 --> URI Class Initialized
INFO - 2018-04-13 22:28:42 --> Router Class Initialized
INFO - 2018-04-13 22:28:43 --> Output Class Initialized
INFO - 2018-04-13 22:28:43 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:43 --> CSRF cookie sent
INFO - 2018-04-13 22:28:43 --> Input Class Initialized
INFO - 2018-04-13 22:28:43 --> Language Class Initialized
ERROR - 2018-04-13 22:28:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:22 --> Config Class Initialized
INFO - 2018-04-13 22:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:22 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:22 --> URI Class Initialized
INFO - 2018-04-13 22:29:22 --> Router Class Initialized
INFO - 2018-04-13 22:29:22 --> Output Class Initialized
INFO - 2018-04-13 22:29:22 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:22 --> CSRF cookie sent
INFO - 2018-04-13 22:29:22 --> Input Class Initialized
INFO - 2018-04-13 22:29:22 --> Language Class Initialized
INFO - 2018-04-13 22:29:22 --> Loader Class Initialized
INFO - 2018-04-13 22:29:22 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:22 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:22 --> Controller Class Initialized
INFO - 2018-04-13 22:29:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:22 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:22 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:25 --> File loaded: E:\www\yacopoo\application\views\questions/trust_info.php
INFO - 2018-04-13 22:29:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:25 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:25 --> Total execution time: 3.6324
INFO - 2018-04-13 22:29:26 --> Config Class Initialized
INFO - 2018-04-13 22:29:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:26 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:26 --> URI Class Initialized
INFO - 2018-04-13 22:29:26 --> Router Class Initialized
INFO - 2018-04-13 22:29:26 --> Output Class Initialized
INFO - 2018-04-13 22:29:26 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:26 --> CSRF cookie sent
INFO - 2018-04-13 22:29:26 --> Input Class Initialized
INFO - 2018-04-13 22:29:26 --> Language Class Initialized
ERROR - 2018-04-13 22:29:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:27 --> Config Class Initialized
INFO - 2018-04-13 22:29:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:27 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:27 --> URI Class Initialized
INFO - 2018-04-13 22:29:27 --> Router Class Initialized
INFO - 2018-04-13 22:29:27 --> Output Class Initialized
INFO - 2018-04-13 22:29:27 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:27 --> CSRF cookie sent
INFO - 2018-04-13 22:29:27 --> CSRF token verified
INFO - 2018-04-13 22:29:27 --> Input Class Initialized
INFO - 2018-04-13 22:29:27 --> Language Class Initialized
INFO - 2018-04-13 22:29:27 --> Loader Class Initialized
INFO - 2018-04-13 22:29:27 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:27 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:27 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:27 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:27 --> Controller Class Initialized
INFO - 2018-04-13 22:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:27 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:28 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:28 --> Form Validation Class Initialized
INFO - 2018-04-13 22:29:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:29:28 --> Config Class Initialized
INFO - 2018-04-13 22:29:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:28 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:28 --> URI Class Initialized
INFO - 2018-04-13 22:29:28 --> Router Class Initialized
INFO - 2018-04-13 22:29:28 --> Output Class Initialized
INFO - 2018-04-13 22:29:28 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:28 --> CSRF cookie sent
INFO - 2018-04-13 22:29:28 --> Input Class Initialized
INFO - 2018-04-13 22:29:28 --> Language Class Initialized
INFO - 2018-04-13 22:29:28 --> Loader Class Initialized
INFO - 2018-04-13 22:29:28 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:28 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:28 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:28 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:28 --> Controller Class Initialized
INFO - 2018-04-13 22:29:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:28 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:28 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:28 --> File loaded: E:\www\yacopoo\application\views\questions/shift_work.php
INFO - 2018-04-13 22:29:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:28 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:28 --> Total execution time: 0.6710
INFO - 2018-04-13 22:29:29 --> Config Class Initialized
INFO - 2018-04-13 22:29:29 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:29 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:29 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:29 --> URI Class Initialized
INFO - 2018-04-13 22:29:29 --> Router Class Initialized
INFO - 2018-04-13 22:29:29 --> Output Class Initialized
INFO - 2018-04-13 22:29:29 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:29 --> CSRF cookie sent
INFO - 2018-04-13 22:29:29 --> Input Class Initialized
INFO - 2018-04-13 22:29:29 --> Language Class Initialized
ERROR - 2018-04-13 22:29:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:30 --> Config Class Initialized
INFO - 2018-04-13 22:29:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:30 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:30 --> URI Class Initialized
INFO - 2018-04-13 22:29:30 --> Router Class Initialized
INFO - 2018-04-13 22:29:30 --> Output Class Initialized
INFO - 2018-04-13 22:29:30 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:30 --> CSRF cookie sent
INFO - 2018-04-13 22:29:30 --> CSRF token verified
INFO - 2018-04-13 22:29:30 --> Input Class Initialized
INFO - 2018-04-13 22:29:30 --> Language Class Initialized
INFO - 2018-04-13 22:29:30 --> Loader Class Initialized
INFO - 2018-04-13 22:29:30 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:30 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:30 --> Controller Class Initialized
INFO - 2018-04-13 22:29:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:30 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:30 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:30 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:30 --> Form Validation Class Initialized
INFO - 2018-04-13 22:29:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:29:30 --> Config Class Initialized
INFO - 2018-04-13 22:29:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:31 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:31 --> URI Class Initialized
INFO - 2018-04-13 22:29:31 --> Router Class Initialized
INFO - 2018-04-13 22:29:31 --> Output Class Initialized
INFO - 2018-04-13 22:29:31 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:31 --> CSRF cookie sent
INFO - 2018-04-13 22:29:31 --> Input Class Initialized
INFO - 2018-04-13 22:29:31 --> Language Class Initialized
INFO - 2018-04-13 22:29:31 --> Loader Class Initialized
INFO - 2018-04-13 22:29:31 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:31 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:31 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:31 --> Controller Class Initialized
INFO - 2018-04-13 22:29:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:31 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:31 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:31 --> File loaded: E:\www\yacopoo\application\views\questions/night_without_s.php
INFO - 2018-04-13 22:29:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:31 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:31 --> Total execution time: 0.6268
INFO - 2018-04-13 22:29:31 --> Config Class Initialized
INFO - 2018-04-13 22:29:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:32 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:32 --> URI Class Initialized
INFO - 2018-04-13 22:29:32 --> Router Class Initialized
INFO - 2018-04-13 22:29:32 --> Output Class Initialized
INFO - 2018-04-13 22:29:32 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:32 --> CSRF cookie sent
INFO - 2018-04-13 22:29:32 --> Input Class Initialized
INFO - 2018-04-13 22:29:32 --> Language Class Initialized
ERROR - 2018-04-13 22:29:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:40 --> Config Class Initialized
INFO - 2018-04-13 22:29:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:40 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:40 --> URI Class Initialized
INFO - 2018-04-13 22:29:40 --> Router Class Initialized
INFO - 2018-04-13 22:29:40 --> Output Class Initialized
INFO - 2018-04-13 22:29:40 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:40 --> CSRF cookie sent
INFO - 2018-04-13 22:29:40 --> CSRF token verified
INFO - 2018-04-13 22:29:40 --> Input Class Initialized
INFO - 2018-04-13 22:29:40 --> Language Class Initialized
INFO - 2018-04-13 22:29:40 --> Loader Class Initialized
INFO - 2018-04-13 22:29:40 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:40 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:40 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:40 --> Controller Class Initialized
INFO - 2018-04-13 22:29:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:40 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:40 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:40 --> Form Validation Class Initialized
INFO - 2018-04-13 22:29:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:29:40 --> Config Class Initialized
INFO - 2018-04-13 22:29:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:40 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:40 --> URI Class Initialized
INFO - 2018-04-13 22:29:40 --> Router Class Initialized
INFO - 2018-04-13 22:29:40 --> Output Class Initialized
INFO - 2018-04-13 22:29:41 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:41 --> CSRF cookie sent
INFO - 2018-04-13 22:29:41 --> Input Class Initialized
INFO - 2018-04-13 22:29:41 --> Language Class Initialized
INFO - 2018-04-13 22:29:41 --> Loader Class Initialized
INFO - 2018-04-13 22:29:41 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:41 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:41 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:41 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:41 --> Controller Class Initialized
INFO - 2018-04-13 22:29:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:41 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:41 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:41 --> File loaded: E:\www\yacopoo\application\views\questions/have_date.php
INFO - 2018-04-13 22:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:41 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:41 --> Total execution time: 0.5477
INFO - 2018-04-13 22:29:41 --> Config Class Initialized
INFO - 2018-04-13 22:29:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:41 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:41 --> URI Class Initialized
INFO - 2018-04-13 22:29:41 --> Router Class Initialized
INFO - 2018-04-13 22:29:41 --> Output Class Initialized
INFO - 2018-04-13 22:29:41 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:42 --> CSRF cookie sent
INFO - 2018-04-13 22:29:42 --> Input Class Initialized
INFO - 2018-04-13 22:29:42 --> Language Class Initialized
ERROR - 2018-04-13 22:29:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:43 --> Config Class Initialized
INFO - 2018-04-13 22:29:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:43 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:43 --> URI Class Initialized
INFO - 2018-04-13 22:29:43 --> Router Class Initialized
INFO - 2018-04-13 22:29:43 --> Output Class Initialized
INFO - 2018-04-13 22:29:43 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:43 --> CSRF cookie sent
INFO - 2018-04-13 22:29:43 --> Input Class Initialized
INFO - 2018-04-13 22:29:43 --> Language Class Initialized
INFO - 2018-04-13 22:29:43 --> Loader Class Initialized
INFO - 2018-04-13 22:29:43 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:43 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:44 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:44 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:44 --> Controller Class Initialized
INFO - 2018-04-13 22:29:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:44 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:44 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:44 --> File loaded: E:\www\yacopoo\application\views\questions/night_without_s.php
INFO - 2018-04-13 22:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:44 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:44 --> Total execution time: 0.6775
INFO - 2018-04-13 22:29:44 --> Config Class Initialized
INFO - 2018-04-13 22:29:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:44 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:44 --> URI Class Initialized
INFO - 2018-04-13 22:29:44 --> Router Class Initialized
INFO - 2018-04-13 22:29:44 --> Output Class Initialized
INFO - 2018-04-13 22:29:44 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:44 --> CSRF cookie sent
INFO - 2018-04-13 22:29:45 --> Input Class Initialized
INFO - 2018-04-13 22:29:45 --> Language Class Initialized
ERROR - 2018-04-13 22:29:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:46 --> Config Class Initialized
INFO - 2018-04-13 22:29:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:46 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:46 --> URI Class Initialized
INFO - 2018-04-13 22:29:46 --> Router Class Initialized
INFO - 2018-04-13 22:29:46 --> Output Class Initialized
INFO - 2018-04-13 22:29:46 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:46 --> CSRF cookie sent
INFO - 2018-04-13 22:29:46 --> Input Class Initialized
INFO - 2018-04-13 22:29:46 --> Language Class Initialized
INFO - 2018-04-13 22:29:47 --> Loader Class Initialized
INFO - 2018-04-13 22:29:47 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:47 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:47 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:47 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:47 --> Controller Class Initialized
INFO - 2018-04-13 22:29:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:47 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:47 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:47 --> File loaded: E:\www\yacopoo\application\views\questions/have_date.php
INFO - 2018-04-13 22:29:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:47 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:47 --> Total execution time: 0.6674
INFO - 2018-04-13 22:29:47 --> Config Class Initialized
INFO - 2018-04-13 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:47 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:47 --> URI Class Initialized
INFO - 2018-04-13 22:29:47 --> Router Class Initialized
INFO - 2018-04-13 22:29:47 --> Output Class Initialized
INFO - 2018-04-13 22:29:47 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:47 --> CSRF cookie sent
INFO - 2018-04-13 22:29:47 --> Input Class Initialized
INFO - 2018-04-13 22:29:48 --> Language Class Initialized
ERROR - 2018-04-13 22:29:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:29:56 --> Config Class Initialized
INFO - 2018-04-13 22:29:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:56 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:56 --> URI Class Initialized
INFO - 2018-04-13 22:29:57 --> Router Class Initialized
INFO - 2018-04-13 22:29:57 --> Output Class Initialized
INFO - 2018-04-13 22:29:57 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:57 --> CSRF cookie sent
INFO - 2018-04-13 22:29:57 --> CSRF token verified
INFO - 2018-04-13 22:29:57 --> Input Class Initialized
INFO - 2018-04-13 22:29:57 --> Language Class Initialized
INFO - 2018-04-13 22:29:57 --> Loader Class Initialized
INFO - 2018-04-13 22:29:57 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:57 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:57 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:57 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:57 --> Controller Class Initialized
INFO - 2018-04-13 22:29:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:57 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:57 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:57 --> Form Validation Class Initialized
INFO - 2018-04-13 22:29:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:29:57 --> Config Class Initialized
INFO - 2018-04-13 22:29:57 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:57 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:57 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:57 --> URI Class Initialized
INFO - 2018-04-13 22:29:57 --> Router Class Initialized
INFO - 2018-04-13 22:29:57 --> Output Class Initialized
INFO - 2018-04-13 22:29:57 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:57 --> CSRF cookie sent
INFO - 2018-04-13 22:29:57 --> Input Class Initialized
INFO - 2018-04-13 22:29:57 --> Language Class Initialized
INFO - 2018-04-13 22:29:57 --> Loader Class Initialized
INFO - 2018-04-13 22:29:57 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:57 --> Helper loaded: form_helper
INFO - 2018-04-13 22:29:57 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:57 --> User Agent Class Initialized
INFO - 2018-04-13 22:29:57 --> Controller Class Initialized
INFO - 2018-04-13 22:29:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:29:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:29:57 --> Pixel_Model class loaded
INFO - 2018-04-13 22:29:57 --> Database Driver Class Initialized
INFO - 2018-04-13 22:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:29:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:29:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:29:58 --> File loaded: E:\www\yacopoo\application\views\questions/nights_not_home.php
INFO - 2018-04-13 22:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:29:58 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:58 --> Total execution time: 0.5722
INFO - 2018-04-13 22:29:58 --> Config Class Initialized
INFO - 2018-04-13 22:29:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:58 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:58 --> URI Class Initialized
INFO - 2018-04-13 22:29:58 --> Router Class Initialized
INFO - 2018-04-13 22:29:58 --> Output Class Initialized
INFO - 2018-04-13 22:29:58 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:58 --> CSRF cookie sent
INFO - 2018-04-13 22:29:58 --> Input Class Initialized
INFO - 2018-04-13 22:29:58 --> Language Class Initialized
ERROR - 2018-04-13 22:29:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:05 --> Config Class Initialized
INFO - 2018-04-13 22:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:05 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:05 --> URI Class Initialized
INFO - 2018-04-13 22:30:05 --> Router Class Initialized
INFO - 2018-04-13 22:30:05 --> Output Class Initialized
INFO - 2018-04-13 22:30:05 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:05 --> CSRF cookie sent
INFO - 2018-04-13 22:30:05 --> CSRF token verified
INFO - 2018-04-13 22:30:05 --> Input Class Initialized
INFO - 2018-04-13 22:30:05 --> Language Class Initialized
INFO - 2018-04-13 22:30:05 --> Loader Class Initialized
INFO - 2018-04-13 22:30:05 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:05 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:05 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:05 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:05 --> Controller Class Initialized
INFO - 2018-04-13 22:30:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:05 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:05 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:05 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:05 --> Form Validation Class Initialized
INFO - 2018-04-13 22:30:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:30:05 --> Config Class Initialized
INFO - 2018-04-13 22:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:05 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:05 --> URI Class Initialized
INFO - 2018-04-13 22:30:06 --> Router Class Initialized
INFO - 2018-04-13 22:30:06 --> Output Class Initialized
INFO - 2018-04-13 22:30:06 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:06 --> CSRF cookie sent
INFO - 2018-04-13 22:30:06 --> Input Class Initialized
INFO - 2018-04-13 22:30:06 --> Language Class Initialized
INFO - 2018-04-13 22:30:06 --> Loader Class Initialized
INFO - 2018-04-13 22:30:06 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:06 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:06 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:06 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:06 --> Controller Class Initialized
INFO - 2018-04-13 22:30:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:06 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:06 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:06 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:30:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:06 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:06 --> Total execution time: 0.7734
INFO - 2018-04-13 22:30:07 --> Config Class Initialized
INFO - 2018-04-13 22:30:07 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:07 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:07 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:07 --> URI Class Initialized
INFO - 2018-04-13 22:30:07 --> Router Class Initialized
INFO - 2018-04-13 22:30:07 --> Output Class Initialized
INFO - 2018-04-13 22:30:07 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:07 --> CSRF cookie sent
INFO - 2018-04-13 22:30:07 --> Input Class Initialized
INFO - 2018-04-13 22:30:07 --> Language Class Initialized
ERROR - 2018-04-13 22:30:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:10 --> Config Class Initialized
INFO - 2018-04-13 22:30:10 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:10 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:10 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:10 --> URI Class Initialized
INFO - 2018-04-13 22:30:10 --> Router Class Initialized
INFO - 2018-04-13 22:30:10 --> Output Class Initialized
INFO - 2018-04-13 22:30:10 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:10 --> CSRF cookie sent
INFO - 2018-04-13 22:30:10 --> Input Class Initialized
INFO - 2018-04-13 22:30:10 --> Language Class Initialized
INFO - 2018-04-13 22:30:10 --> Loader Class Initialized
INFO - 2018-04-13 22:30:10 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:10 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:11 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:11 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:11 --> Controller Class Initialized
INFO - 2018-04-13 22:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:11 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:11 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:11 --> File loaded: E:\www\yacopoo\application\views\questions/nights_not_home.php
INFO - 2018-04-13 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:11 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:11 --> Total execution time: 0.6954
INFO - 2018-04-13 22:30:11 --> Config Class Initialized
INFO - 2018-04-13 22:30:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:11 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:11 --> URI Class Initialized
INFO - 2018-04-13 22:30:11 --> Router Class Initialized
INFO - 2018-04-13 22:30:11 --> Output Class Initialized
INFO - 2018-04-13 22:30:11 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:11 --> CSRF cookie sent
INFO - 2018-04-13 22:30:11 --> Input Class Initialized
INFO - 2018-04-13 22:30:11 --> Language Class Initialized
ERROR - 2018-04-13 22:30:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:13 --> Config Class Initialized
INFO - 2018-04-13 22:30:13 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:13 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:13 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:13 --> URI Class Initialized
INFO - 2018-04-13 22:30:13 --> Router Class Initialized
INFO - 2018-04-13 22:30:13 --> Output Class Initialized
INFO - 2018-04-13 22:30:13 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:13 --> CSRF cookie sent
INFO - 2018-04-13 22:30:13 --> Input Class Initialized
INFO - 2018-04-13 22:30:13 --> Language Class Initialized
INFO - 2018-04-13 22:30:13 --> Loader Class Initialized
INFO - 2018-04-13 22:30:13 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:13 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:13 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:13 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:13 --> Controller Class Initialized
INFO - 2018-04-13 22:30:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:14 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:14 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:14 --> File loaded: E:\www\yacopoo\application\views\questions/have_date.php
INFO - 2018-04-13 22:30:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:14 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:14 --> Total execution time: 0.6587
INFO - 2018-04-13 22:30:14 --> Config Class Initialized
INFO - 2018-04-13 22:30:14 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:14 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:14 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:14 --> URI Class Initialized
INFO - 2018-04-13 22:30:14 --> Router Class Initialized
INFO - 2018-04-13 22:30:14 --> Output Class Initialized
INFO - 2018-04-13 22:30:14 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:14 --> CSRF cookie sent
INFO - 2018-04-13 22:30:14 --> Input Class Initialized
INFO - 2018-04-13 22:30:14 --> Language Class Initialized
ERROR - 2018-04-13 22:30:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:16 --> Config Class Initialized
INFO - 2018-04-13 22:30:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:16 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:16 --> URI Class Initialized
INFO - 2018-04-13 22:30:16 --> Router Class Initialized
INFO - 2018-04-13 22:30:16 --> Output Class Initialized
INFO - 2018-04-13 22:30:16 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:16 --> CSRF cookie sent
INFO - 2018-04-13 22:30:16 --> Input Class Initialized
INFO - 2018-04-13 22:30:16 --> Language Class Initialized
INFO - 2018-04-13 22:30:16 --> Loader Class Initialized
INFO - 2018-04-13 22:30:16 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:16 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:16 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:16 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:16 --> Controller Class Initialized
INFO - 2018-04-13 22:30:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:16 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:16 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:16 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:17 --> File loaded: E:\www\yacopoo\application\views\questions/have_date.php
INFO - 2018-04-13 22:30:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:17 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:17 --> Total execution time: 0.6296
INFO - 2018-04-13 22:30:17 --> Config Class Initialized
INFO - 2018-04-13 22:30:17 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:17 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:17 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:17 --> URI Class Initialized
INFO - 2018-04-13 22:30:17 --> Router Class Initialized
INFO - 2018-04-13 22:30:17 --> Output Class Initialized
INFO - 2018-04-13 22:30:17 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:17 --> CSRF cookie sent
INFO - 2018-04-13 22:30:17 --> Input Class Initialized
INFO - 2018-04-13 22:30:17 --> Language Class Initialized
ERROR - 2018-04-13 22:30:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:18 --> Config Class Initialized
INFO - 2018-04-13 22:30:18 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:19 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:19 --> URI Class Initialized
INFO - 2018-04-13 22:30:19 --> Router Class Initialized
INFO - 2018-04-13 22:30:19 --> Output Class Initialized
INFO - 2018-04-13 22:30:19 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:19 --> CSRF cookie sent
INFO - 2018-04-13 22:30:19 --> Input Class Initialized
INFO - 2018-04-13 22:30:19 --> Language Class Initialized
INFO - 2018-04-13 22:30:19 --> Loader Class Initialized
INFO - 2018-04-13 22:30:19 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:19 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:19 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:19 --> Controller Class Initialized
INFO - 2018-04-13 22:30:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:19 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:19 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:19 --> File loaded: E:\www\yacopoo\application\views\questions/nights_not_home.php
INFO - 2018-04-13 22:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:19 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:19 --> Total execution time: 0.6501
INFO - 2018-04-13 22:30:19 --> Config Class Initialized
INFO - 2018-04-13 22:30:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:20 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:20 --> URI Class Initialized
INFO - 2018-04-13 22:30:20 --> Router Class Initialized
INFO - 2018-04-13 22:30:20 --> Output Class Initialized
INFO - 2018-04-13 22:30:20 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:20 --> CSRF cookie sent
INFO - 2018-04-13 22:30:20 --> Input Class Initialized
INFO - 2018-04-13 22:30:20 --> Language Class Initialized
ERROR - 2018-04-13 22:30:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:20 --> Config Class Initialized
INFO - 2018-04-13 22:30:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:21 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:21 --> URI Class Initialized
INFO - 2018-04-13 22:30:21 --> Router Class Initialized
INFO - 2018-04-13 22:30:21 --> Output Class Initialized
INFO - 2018-04-13 22:30:21 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:21 --> CSRF cookie sent
INFO - 2018-04-13 22:30:21 --> Input Class Initialized
INFO - 2018-04-13 22:30:21 --> Language Class Initialized
INFO - 2018-04-13 22:30:21 --> Loader Class Initialized
INFO - 2018-04-13 22:30:21 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:21 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:21 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:21 --> Controller Class Initialized
INFO - 2018-04-13 22:30:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:21 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:21 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:21 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:21 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:21 --> Total execution time: 0.6614
INFO - 2018-04-13 22:30:22 --> Config Class Initialized
INFO - 2018-04-13 22:30:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:22 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:22 --> URI Class Initialized
INFO - 2018-04-13 22:30:22 --> Router Class Initialized
INFO - 2018-04-13 22:30:22 --> Output Class Initialized
INFO - 2018-04-13 22:30:22 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:22 --> CSRF cookie sent
INFO - 2018-04-13 22:30:22 --> Input Class Initialized
INFO - 2018-04-13 22:30:22 --> Language Class Initialized
ERROR - 2018-04-13 22:30:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:33 --> Config Class Initialized
INFO - 2018-04-13 22:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:33 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:33 --> URI Class Initialized
INFO - 2018-04-13 22:30:33 --> Router Class Initialized
INFO - 2018-04-13 22:30:33 --> Output Class Initialized
INFO - 2018-04-13 22:30:33 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:33 --> CSRF cookie sent
INFO - 2018-04-13 22:30:33 --> CSRF token verified
INFO - 2018-04-13 22:30:33 --> Input Class Initialized
INFO - 2018-04-13 22:30:33 --> Language Class Initialized
INFO - 2018-04-13 22:30:33 --> Loader Class Initialized
INFO - 2018-04-13 22:30:33 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:33 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:33 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:33 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:33 --> Controller Class Initialized
INFO - 2018-04-13 22:30:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:33 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:33 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:33 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:33 --> Form Validation Class Initialized
INFO - 2018-04-13 22:30:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:30:33 --> Config Class Initialized
INFO - 2018-04-13 22:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:33 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:33 --> URI Class Initialized
INFO - 2018-04-13 22:30:33 --> Router Class Initialized
INFO - 2018-04-13 22:30:33 --> Output Class Initialized
INFO - 2018-04-13 22:30:33 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:33 --> CSRF cookie sent
INFO - 2018-04-13 22:30:33 --> Input Class Initialized
INFO - 2018-04-13 22:30:33 --> Language Class Initialized
INFO - 2018-04-13 22:30:33 --> Loader Class Initialized
INFO - 2018-04-13 22:30:33 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:33 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:33 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:34 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:34 --> Controller Class Initialized
INFO - 2018-04-13 22:30:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:34 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:34 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:34 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:30:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:34 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:34 --> Total execution time: 0.5661
INFO - 2018-04-13 22:30:34 --> Config Class Initialized
INFO - 2018-04-13 22:30:34 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:34 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:34 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:34 --> URI Class Initialized
INFO - 2018-04-13 22:30:34 --> Router Class Initialized
INFO - 2018-04-13 22:30:34 --> Output Class Initialized
INFO - 2018-04-13 22:30:34 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:34 --> CSRF cookie sent
INFO - 2018-04-13 22:30:34 --> Input Class Initialized
INFO - 2018-04-13 22:30:34 --> Language Class Initialized
ERROR - 2018-04-13 22:30:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:30:44 --> Config Class Initialized
INFO - 2018-04-13 22:30:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:44 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:44 --> URI Class Initialized
INFO - 2018-04-13 22:30:44 --> Router Class Initialized
INFO - 2018-04-13 22:30:44 --> Output Class Initialized
INFO - 2018-04-13 22:30:44 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:44 --> CSRF cookie sent
INFO - 2018-04-13 22:30:45 --> CSRF token verified
INFO - 2018-04-13 22:30:45 --> Input Class Initialized
INFO - 2018-04-13 22:30:45 --> Language Class Initialized
INFO - 2018-04-13 22:30:45 --> Loader Class Initialized
INFO - 2018-04-13 22:30:45 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:45 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:45 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:45 --> Controller Class Initialized
INFO - 2018-04-13 22:30:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:45 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:45 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:45 --> Form Validation Class Initialized
INFO - 2018-04-13 22:30:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:30:45 --> Config Class Initialized
INFO - 2018-04-13 22:30:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:45 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:45 --> URI Class Initialized
INFO - 2018-04-13 22:30:45 --> Router Class Initialized
INFO - 2018-04-13 22:30:45 --> Output Class Initialized
INFO - 2018-04-13 22:30:45 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:45 --> CSRF cookie sent
INFO - 2018-04-13 22:30:45 --> Input Class Initialized
INFO - 2018-04-13 22:30:45 --> Language Class Initialized
INFO - 2018-04-13 22:30:45 --> Loader Class Initialized
INFO - 2018-04-13 22:30:45 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:45 --> Helper loaded: form_helper
INFO - 2018-04-13 22:30:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:45 --> User Agent Class Initialized
INFO - 2018-04-13 22:30:45 --> Controller Class Initialized
INFO - 2018-04-13 22:30:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:30:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:30:45 --> Pixel_Model class loaded
INFO - 2018-04-13 22:30:45 --> Database Driver Class Initialized
INFO - 2018-04-13 22:30:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:30:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:30:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:30:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:30:45 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:30:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:30:45 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:46 --> Total execution time: 0.5789
INFO - 2018-04-13 22:30:46 --> Config Class Initialized
INFO - 2018-04-13 22:30:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:46 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:46 --> URI Class Initialized
INFO - 2018-04-13 22:30:46 --> Router Class Initialized
INFO - 2018-04-13 22:30:46 --> Output Class Initialized
INFO - 2018-04-13 22:30:46 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:46 --> CSRF cookie sent
INFO - 2018-04-13 22:30:46 --> Input Class Initialized
INFO - 2018-04-13 22:30:46 --> Language Class Initialized
ERROR - 2018-04-13 22:30:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:32:00 --> Config Class Initialized
INFO - 2018-04-13 22:32:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:00 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:00 --> URI Class Initialized
INFO - 2018-04-13 22:32:00 --> Router Class Initialized
INFO - 2018-04-13 22:32:00 --> Output Class Initialized
INFO - 2018-04-13 22:32:00 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:00 --> CSRF cookie sent
INFO - 2018-04-13 22:32:00 --> Input Class Initialized
INFO - 2018-04-13 22:32:00 --> Language Class Initialized
INFO - 2018-04-13 22:32:00 --> Loader Class Initialized
INFO - 2018-04-13 22:32:00 --> Helper loaded: url_helper
INFO - 2018-04-13 22:32:00 --> Helper loaded: form_helper
INFO - 2018-04-13 22:32:00 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:32:00 --> User Agent Class Initialized
INFO - 2018-04-13 22:32:00 --> Controller Class Initialized
INFO - 2018-04-13 22:32:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:32:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:32:00 --> Pixel_Model class loaded
INFO - 2018-04-13 22:32:00 --> Database Driver Class Initialized
INFO - 2018-04-13 22:32:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:32:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:32:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:32:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:32:04 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:32:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:32:04 --> Final output sent to browser
DEBUG - 2018-04-13 22:32:04 --> Total execution time: 3.6049
INFO - 2018-04-13 22:32:04 --> Config Class Initialized
INFO - 2018-04-13 22:32:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:04 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:04 --> URI Class Initialized
INFO - 2018-04-13 22:32:04 --> Router Class Initialized
INFO - 2018-04-13 22:32:04 --> Output Class Initialized
INFO - 2018-04-13 22:32:04 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:04 --> CSRF cookie sent
INFO - 2018-04-13 22:32:04 --> Input Class Initialized
INFO - 2018-04-13 22:32:04 --> Language Class Initialized
ERROR - 2018-04-13 22:32:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:32:06 --> Config Class Initialized
INFO - 2018-04-13 22:32:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:06 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:06 --> URI Class Initialized
INFO - 2018-04-13 22:32:06 --> Router Class Initialized
INFO - 2018-04-13 22:32:06 --> Output Class Initialized
INFO - 2018-04-13 22:32:06 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:06 --> CSRF cookie sent
INFO - 2018-04-13 22:32:06 --> CSRF token verified
INFO - 2018-04-13 22:32:06 --> Input Class Initialized
INFO - 2018-04-13 22:32:06 --> Language Class Initialized
INFO - 2018-04-13 22:32:06 --> Loader Class Initialized
INFO - 2018-04-13 22:32:06 --> Helper loaded: url_helper
INFO - 2018-04-13 22:32:06 --> Helper loaded: form_helper
INFO - 2018-04-13 22:32:06 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:32:06 --> User Agent Class Initialized
INFO - 2018-04-13 22:32:06 --> Controller Class Initialized
INFO - 2018-04-13 22:32:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:32:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:32:06 --> Pixel_Model class loaded
INFO - 2018-04-13 22:32:06 --> Database Driver Class Initialized
INFO - 2018-04-13 22:32:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:32:06 --> Form Validation Class Initialized
INFO - 2018-04-13 22:32:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:32:06 --> Config Class Initialized
INFO - 2018-04-13 22:32:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:06 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:06 --> URI Class Initialized
INFO - 2018-04-13 22:32:06 --> Router Class Initialized
INFO - 2018-04-13 22:32:06 --> Output Class Initialized
INFO - 2018-04-13 22:32:06 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:06 --> CSRF cookie sent
INFO - 2018-04-13 22:32:06 --> Input Class Initialized
INFO - 2018-04-13 22:32:06 --> Language Class Initialized
INFO - 2018-04-13 22:32:06 --> Loader Class Initialized
INFO - 2018-04-13 22:32:07 --> Helper loaded: url_helper
INFO - 2018-04-13 22:32:07 --> Helper loaded: form_helper
INFO - 2018-04-13 22:32:07 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:32:07 --> User Agent Class Initialized
INFO - 2018-04-13 22:32:07 --> Controller Class Initialized
INFO - 2018-04-13 22:32:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:32:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:32:07 --> Pixel_Model class loaded
INFO - 2018-04-13 22:32:07 --> Database Driver Class Initialized
INFO - 2018-04-13 22:32:07 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:32:07 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_not_home.php
INFO - 2018-04-13 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:32:07 --> Final output sent to browser
DEBUG - 2018-04-13 22:32:07 --> Total execution time: 0.5670
INFO - 2018-04-13 22:32:07 --> Config Class Initialized
INFO - 2018-04-13 22:32:07 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:07 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:07 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:07 --> URI Class Initialized
INFO - 2018-04-13 22:32:07 --> Router Class Initialized
INFO - 2018-04-13 22:32:07 --> Output Class Initialized
INFO - 2018-04-13 22:32:07 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:07 --> CSRF cookie sent
INFO - 2018-04-13 22:32:07 --> Input Class Initialized
INFO - 2018-04-13 22:32:07 --> Language Class Initialized
ERROR - 2018-04-13 22:32:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:33:23 --> Config Class Initialized
INFO - 2018-04-13 22:33:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:23 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:23 --> URI Class Initialized
INFO - 2018-04-13 22:33:23 --> Router Class Initialized
INFO - 2018-04-13 22:33:23 --> Output Class Initialized
INFO - 2018-04-13 22:33:23 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:23 --> CSRF cookie sent
INFO - 2018-04-13 22:33:23 --> Input Class Initialized
INFO - 2018-04-13 22:33:23 --> Language Class Initialized
INFO - 2018-04-13 22:33:23 --> Loader Class Initialized
INFO - 2018-04-13 22:33:23 --> Helper loaded: url_helper
INFO - 2018-04-13 22:33:23 --> Helper loaded: form_helper
INFO - 2018-04-13 22:33:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:33:23 --> User Agent Class Initialized
INFO - 2018-04-13 22:33:23 --> Controller Class Initialized
INFO - 2018-04-13 22:33:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:33:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:33:23 --> Pixel_Model class loaded
INFO - 2018-04-13 22:33:23 --> Database Driver Class Initialized
INFO - 2018-04-13 22:33:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:33:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:33:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:33:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:33:26 --> File loaded: E:\www\yacopoo\application\views\questions/s_nights_without_you.php
INFO - 2018-04-13 22:33:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:33:26 --> Final output sent to browser
DEBUG - 2018-04-13 22:33:26 --> Total execution time: 3.6210
INFO - 2018-04-13 22:33:26 --> Config Class Initialized
INFO - 2018-04-13 22:33:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:27 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:27 --> URI Class Initialized
INFO - 2018-04-13 22:33:27 --> Router Class Initialized
INFO - 2018-04-13 22:33:27 --> Output Class Initialized
INFO - 2018-04-13 22:33:27 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:27 --> CSRF cookie sent
INFO - 2018-04-13 22:33:27 --> Input Class Initialized
INFO - 2018-04-13 22:33:27 --> Language Class Initialized
ERROR - 2018-04-13 22:33:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:33:31 --> Config Class Initialized
INFO - 2018-04-13 22:33:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:31 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:31 --> URI Class Initialized
INFO - 2018-04-13 22:33:31 --> Router Class Initialized
INFO - 2018-04-13 22:33:31 --> Output Class Initialized
INFO - 2018-04-13 22:33:31 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:31 --> CSRF cookie sent
INFO - 2018-04-13 22:33:31 --> CSRF token verified
INFO - 2018-04-13 22:33:31 --> Input Class Initialized
INFO - 2018-04-13 22:33:31 --> Language Class Initialized
INFO - 2018-04-13 22:33:31 --> Loader Class Initialized
INFO - 2018-04-13 22:33:31 --> Helper loaded: url_helper
INFO - 2018-04-13 22:33:31 --> Helper loaded: form_helper
INFO - 2018-04-13 22:33:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:33:31 --> User Agent Class Initialized
INFO - 2018-04-13 22:33:31 --> Controller Class Initialized
INFO - 2018-04-13 22:33:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:33:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:33:31 --> Pixel_Model class loaded
INFO - 2018-04-13 22:33:31 --> Database Driver Class Initialized
INFO - 2018-04-13 22:33:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:33:31 --> Form Validation Class Initialized
INFO - 2018-04-13 22:33:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:33:31 --> Config Class Initialized
INFO - 2018-04-13 22:33:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:31 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:31 --> URI Class Initialized
INFO - 2018-04-13 22:33:31 --> Router Class Initialized
INFO - 2018-04-13 22:33:31 --> Output Class Initialized
INFO - 2018-04-13 22:33:31 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:31 --> CSRF cookie sent
INFO - 2018-04-13 22:33:31 --> Input Class Initialized
INFO - 2018-04-13 22:33:31 --> Language Class Initialized
INFO - 2018-04-13 22:33:31 --> Loader Class Initialized
INFO - 2018-04-13 22:33:31 --> Helper loaded: url_helper
INFO - 2018-04-13 22:33:31 --> Helper loaded: form_helper
INFO - 2018-04-13 22:33:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:33:32 --> User Agent Class Initialized
INFO - 2018-04-13 22:33:32 --> Controller Class Initialized
INFO - 2018-04-13 22:33:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:33:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:33:32 --> Pixel_Model class loaded
INFO - 2018-04-13 22:33:32 --> Database Driver Class Initialized
INFO - 2018-04-13 22:33:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:33:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:33:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:33:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:33:32 --> File loaded: E:\www\yacopoo\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-04-13 22:33:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:33:32 --> Final output sent to browser
DEBUG - 2018-04-13 22:33:32 --> Total execution time: 0.5671
INFO - 2018-04-13 22:33:32 --> Config Class Initialized
INFO - 2018-04-13 22:33:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:32 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:32 --> URI Class Initialized
INFO - 2018-04-13 22:33:32 --> Router Class Initialized
INFO - 2018-04-13 22:33:32 --> Output Class Initialized
INFO - 2018-04-13 22:33:32 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:32 --> CSRF cookie sent
INFO - 2018-04-13 22:33:32 --> Input Class Initialized
INFO - 2018-04-13 22:33:32 --> Language Class Initialized
ERROR - 2018-04-13 22:33:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:33:35 --> Config Class Initialized
INFO - 2018-04-13 22:33:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:35 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:35 --> URI Class Initialized
INFO - 2018-04-13 22:33:35 --> Router Class Initialized
INFO - 2018-04-13 22:33:35 --> Output Class Initialized
INFO - 2018-04-13 22:33:35 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:35 --> CSRF cookie sent
INFO - 2018-04-13 22:33:35 --> CSRF token verified
INFO - 2018-04-13 22:33:35 --> Input Class Initialized
INFO - 2018-04-13 22:33:35 --> Language Class Initialized
INFO - 2018-04-13 22:33:35 --> Loader Class Initialized
INFO - 2018-04-13 22:33:35 --> Helper loaded: url_helper
INFO - 2018-04-13 22:33:35 --> Helper loaded: form_helper
INFO - 2018-04-13 22:33:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:33:35 --> User Agent Class Initialized
INFO - 2018-04-13 22:33:35 --> Controller Class Initialized
INFO - 2018-04-13 22:33:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:33:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:33:35 --> Pixel_Model class loaded
INFO - 2018-04-13 22:33:35 --> Database Driver Class Initialized
INFO - 2018-04-13 22:33:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:33:36 --> Form Validation Class Initialized
INFO - 2018-04-13 22:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-04-13 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:33:36 --> Final output sent to browser
DEBUG - 2018-04-13 22:33:36 --> Total execution time: 0.7104
INFO - 2018-04-13 22:33:36 --> Config Class Initialized
INFO - 2018-04-13 22:33:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:33:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:33:36 --> Utf8 Class Initialized
INFO - 2018-04-13 22:33:36 --> URI Class Initialized
INFO - 2018-04-13 22:33:36 --> Router Class Initialized
INFO - 2018-04-13 22:33:36 --> Output Class Initialized
INFO - 2018-04-13 22:33:36 --> Security Class Initialized
DEBUG - 2018-04-13 22:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:33:36 --> CSRF cookie sent
INFO - 2018-04-13 22:33:36 --> Input Class Initialized
INFO - 2018-04-13 22:33:36 --> Language Class Initialized
ERROR - 2018-04-13 22:33:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 22:34:22 --> Config Class Initialized
INFO - 2018-04-13 22:34:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:34:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:34:22 --> Utf8 Class Initialized
INFO - 2018-04-13 22:34:22 --> URI Class Initialized
INFO - 2018-04-13 22:34:22 --> Router Class Initialized
INFO - 2018-04-13 22:34:22 --> Output Class Initialized
INFO - 2018-04-13 22:34:22 --> Security Class Initialized
DEBUG - 2018-04-13 22:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:34:22 --> CSRF cookie sent
INFO - 2018-04-13 22:34:22 --> CSRF token verified
INFO - 2018-04-13 22:34:22 --> Input Class Initialized
INFO - 2018-04-13 22:34:22 --> Language Class Initialized
INFO - 2018-04-13 22:34:22 --> Loader Class Initialized
INFO - 2018-04-13 22:34:22 --> Helper loaded: url_helper
INFO - 2018-04-13 22:34:22 --> Helper loaded: form_helper
INFO - 2018-04-13 22:34:22 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:34:22 --> User Agent Class Initialized
INFO - 2018-04-13 22:34:22 --> Controller Class Initialized
INFO - 2018-04-13 22:34:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:34:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:34:22 --> Pixel_Model class loaded
INFO - 2018-04-13 22:34:22 --> Database Driver Class Initialized
INFO - 2018-04-13 22:34:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:34:22 --> Form Validation Class Initialized
INFO - 2018-04-13 22:34:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 22:34:23 --> Config Class Initialized
INFO - 2018-04-13 22:34:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:34:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:34:23 --> Utf8 Class Initialized
INFO - 2018-04-13 22:34:23 --> URI Class Initialized
INFO - 2018-04-13 22:34:23 --> Router Class Initialized
INFO - 2018-04-13 22:34:23 --> Output Class Initialized
INFO - 2018-04-13 22:34:23 --> Security Class Initialized
DEBUG - 2018-04-13 22:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:34:23 --> CSRF cookie sent
INFO - 2018-04-13 22:34:23 --> Input Class Initialized
INFO - 2018-04-13 22:34:23 --> Language Class Initialized
INFO - 2018-04-13 22:34:23 --> Loader Class Initialized
INFO - 2018-04-13 22:34:23 --> Helper loaded: url_helper
INFO - 2018-04-13 22:34:23 --> Helper loaded: form_helper
INFO - 2018-04-13 22:34:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 22:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:34:23 --> User Agent Class Initialized
INFO - 2018-04-13 22:34:23 --> Controller Class Initialized
INFO - 2018-04-13 22:34:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 22:34:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 22:34:23 --> Pixel_Model class loaded
INFO - 2018-04-13 22:34:23 --> Database Driver Class Initialized
INFO - 2018-04-13 22:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 22:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 22:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 22:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 22:34:23 --> File loaded: E:\www\yacopoo\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-04-13 22:34:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 22:34:23 --> Final output sent to browser
DEBUG - 2018-04-13 22:34:23 --> Total execution time: 0.6058
INFO - 2018-04-13 22:34:23 --> Config Class Initialized
INFO - 2018-04-13 22:34:24 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:34:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:34:24 --> Utf8 Class Initialized
INFO - 2018-04-13 22:34:24 --> URI Class Initialized
INFO - 2018-04-13 22:34:24 --> Router Class Initialized
INFO - 2018-04-13 22:34:24 --> Output Class Initialized
INFO - 2018-04-13 22:34:24 --> Security Class Initialized
DEBUG - 2018-04-13 22:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:34:24 --> CSRF cookie sent
INFO - 2018-04-13 22:34:24 --> Input Class Initialized
INFO - 2018-04-13 22:34:24 --> Language Class Initialized
ERROR - 2018-04-13 22:34:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:23 --> Config Class Initialized
INFO - 2018-04-13 23:23:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:23 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:23 --> URI Class Initialized
INFO - 2018-04-13 23:23:23 --> Router Class Initialized
INFO - 2018-04-13 23:23:23 --> Output Class Initialized
INFO - 2018-04-13 23:23:23 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:23 --> CSRF cookie sent
INFO - 2018-04-13 23:23:23 --> Input Class Initialized
INFO - 2018-04-13 23:23:23 --> Language Class Initialized
INFO - 2018-04-13 23:23:23 --> Loader Class Initialized
INFO - 2018-04-13 23:23:23 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:23 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:23 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:23 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:23 --> Controller Class Initialized
INFO - 2018-04-13 23:23:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:23 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:23 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:26 --> File loaded: E:\www\yacopoo\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-04-13 23:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:26 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:26 --> Total execution time: 3.6780
INFO - 2018-04-13 23:23:27 --> Config Class Initialized
INFO - 2018-04-13 23:23:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:27 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:27 --> URI Class Initialized
INFO - 2018-04-13 23:23:27 --> Router Class Initialized
INFO - 2018-04-13 23:23:27 --> Output Class Initialized
INFO - 2018-04-13 23:23:27 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:27 --> CSRF cookie sent
INFO - 2018-04-13 23:23:27 --> Input Class Initialized
INFO - 2018-04-13 23:23:27 --> Language Class Initialized
ERROR - 2018-04-13 23:23:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:30 --> Config Class Initialized
INFO - 2018-04-13 23:23:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:30 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:30 --> URI Class Initialized
INFO - 2018-04-13 23:23:30 --> Router Class Initialized
INFO - 2018-04-13 23:23:30 --> Output Class Initialized
INFO - 2018-04-13 23:23:30 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:30 --> CSRF cookie sent
INFO - 2018-04-13 23:23:30 --> CSRF token verified
INFO - 2018-04-13 23:23:30 --> Input Class Initialized
INFO - 2018-04-13 23:23:30 --> Language Class Initialized
INFO - 2018-04-13 23:23:30 --> Loader Class Initialized
INFO - 2018-04-13 23:23:30 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:30 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:30 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:30 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:30 --> Controller Class Initialized
INFO - 2018-04-13 23:23:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:30 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:31 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:31 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:31 --> Config Class Initialized
INFO - 2018-04-13 23:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:31 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:31 --> URI Class Initialized
INFO - 2018-04-13 23:23:31 --> Router Class Initialized
INFO - 2018-04-13 23:23:31 --> Output Class Initialized
INFO - 2018-04-13 23:23:31 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:31 --> CSRF cookie sent
INFO - 2018-04-13 23:23:31 --> Input Class Initialized
INFO - 2018-04-13 23:23:31 --> Language Class Initialized
INFO - 2018-04-13 23:23:31 --> Loader Class Initialized
INFO - 2018-04-13 23:23:31 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:31 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:31 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:31 --> Controller Class Initialized
INFO - 2018-04-13 23:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:31 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:31 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:31 --> File loaded: E:\www\yacopoo\application\views\questions/have_drugs.php
INFO - 2018-04-13 23:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:31 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:31 --> Total execution time: 0.5712
INFO - 2018-04-13 23:23:32 --> Config Class Initialized
INFO - 2018-04-13 23:23:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:32 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:32 --> URI Class Initialized
INFO - 2018-04-13 23:23:32 --> Router Class Initialized
INFO - 2018-04-13 23:23:32 --> Output Class Initialized
INFO - 2018-04-13 23:23:32 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:32 --> CSRF cookie sent
INFO - 2018-04-13 23:23:32 --> Input Class Initialized
INFO - 2018-04-13 23:23:32 --> Language Class Initialized
ERROR - 2018-04-13 23:23:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:34 --> Config Class Initialized
INFO - 2018-04-13 23:23:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:35 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:35 --> URI Class Initialized
INFO - 2018-04-13 23:23:35 --> Router Class Initialized
INFO - 2018-04-13 23:23:35 --> Output Class Initialized
INFO - 2018-04-13 23:23:35 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:35 --> CSRF cookie sent
INFO - 2018-04-13 23:23:35 --> CSRF token verified
INFO - 2018-04-13 23:23:35 --> Input Class Initialized
INFO - 2018-04-13 23:23:35 --> Language Class Initialized
INFO - 2018-04-13 23:23:35 --> Loader Class Initialized
INFO - 2018-04-13 23:23:35 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:35 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:35 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:35 --> Controller Class Initialized
INFO - 2018-04-13 23:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:35 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:35 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:35 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:35 --> Config Class Initialized
INFO - 2018-04-13 23:23:35 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:35 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:35 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:35 --> URI Class Initialized
INFO - 2018-04-13 23:23:35 --> Router Class Initialized
INFO - 2018-04-13 23:23:35 --> Output Class Initialized
INFO - 2018-04-13 23:23:35 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:35 --> CSRF cookie sent
INFO - 2018-04-13 23:23:35 --> Input Class Initialized
INFO - 2018-04-13 23:23:35 --> Language Class Initialized
INFO - 2018-04-13 23:23:35 --> Loader Class Initialized
INFO - 2018-04-13 23:23:35 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:35 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:35 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:35 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:35 --> Controller Class Initialized
INFO - 2018-04-13 23:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:35 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:36 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:36 --> File loaded: E:\www\yacopoo\application\views\questions/has_addiction_problem.php
INFO - 2018-04-13 23:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:36 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:36 --> Total execution time: 0.6219
INFO - 2018-04-13 23:23:36 --> Config Class Initialized
INFO - 2018-04-13 23:23:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:36 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:36 --> URI Class Initialized
INFO - 2018-04-13 23:23:36 --> Router Class Initialized
INFO - 2018-04-13 23:23:36 --> Output Class Initialized
INFO - 2018-04-13 23:23:36 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:36 --> CSRF cookie sent
INFO - 2018-04-13 23:23:36 --> Input Class Initialized
INFO - 2018-04-13 23:23:37 --> Language Class Initialized
ERROR - 2018-04-13 23:23:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:39 --> Config Class Initialized
INFO - 2018-04-13 23:23:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:39 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:39 --> URI Class Initialized
INFO - 2018-04-13 23:23:39 --> Router Class Initialized
INFO - 2018-04-13 23:23:39 --> Output Class Initialized
INFO - 2018-04-13 23:23:39 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:39 --> CSRF cookie sent
INFO - 2018-04-13 23:23:39 --> CSRF token verified
INFO - 2018-04-13 23:23:39 --> Input Class Initialized
INFO - 2018-04-13 23:23:39 --> Language Class Initialized
INFO - 2018-04-13 23:23:39 --> Loader Class Initialized
INFO - 2018-04-13 23:23:39 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:39 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:39 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:40 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:40 --> Controller Class Initialized
INFO - 2018-04-13 23:23:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:40 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:40 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:40 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:40 --> Config Class Initialized
INFO - 2018-04-13 23:23:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:40 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:40 --> URI Class Initialized
INFO - 2018-04-13 23:23:40 --> Router Class Initialized
INFO - 2018-04-13 23:23:40 --> Output Class Initialized
INFO - 2018-04-13 23:23:40 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:40 --> CSRF cookie sent
INFO - 2018-04-13 23:23:40 --> Input Class Initialized
INFO - 2018-04-13 23:23:40 --> Language Class Initialized
INFO - 2018-04-13 23:23:40 --> Loader Class Initialized
INFO - 2018-04-13 23:23:40 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:40 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:40 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:40 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:40 --> Controller Class Initialized
INFO - 2018-04-13 23:23:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:40 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:40 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:40 --> File loaded: E:\www\yacopoo\application\views\questions/have_hit_s.php
INFO - 2018-04-13 23:23:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:40 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:40 --> Total execution time: 0.6540
INFO - 2018-04-13 23:23:41 --> Config Class Initialized
INFO - 2018-04-13 23:23:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:41 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:41 --> URI Class Initialized
INFO - 2018-04-13 23:23:41 --> Router Class Initialized
INFO - 2018-04-13 23:23:41 --> Output Class Initialized
INFO - 2018-04-13 23:23:41 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:41 --> CSRF cookie sent
INFO - 2018-04-13 23:23:41 --> Input Class Initialized
INFO - 2018-04-13 23:23:41 --> Language Class Initialized
ERROR - 2018-04-13 23:23:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:48 --> Config Class Initialized
INFO - 2018-04-13 23:23:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:48 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:48 --> URI Class Initialized
INFO - 2018-04-13 23:23:48 --> Router Class Initialized
INFO - 2018-04-13 23:23:48 --> Output Class Initialized
INFO - 2018-04-13 23:23:48 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:48 --> CSRF cookie sent
INFO - 2018-04-13 23:23:48 --> CSRF token verified
INFO - 2018-04-13 23:23:48 --> Input Class Initialized
INFO - 2018-04-13 23:23:48 --> Language Class Initialized
INFO - 2018-04-13 23:23:48 --> Loader Class Initialized
INFO - 2018-04-13 23:23:48 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:48 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:48 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:48 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:48 --> Controller Class Initialized
INFO - 2018-04-13 23:23:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:48 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:48 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:48 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:48 --> Config Class Initialized
INFO - 2018-04-13 23:23:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:48 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:48 --> URI Class Initialized
INFO - 2018-04-13 23:23:48 --> Router Class Initialized
INFO - 2018-04-13 23:23:48 --> Output Class Initialized
INFO - 2018-04-13 23:23:48 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:48 --> CSRF cookie sent
INFO - 2018-04-13 23:23:48 --> Input Class Initialized
INFO - 2018-04-13 23:23:48 --> Language Class Initialized
INFO - 2018-04-13 23:23:48 --> Loader Class Initialized
INFO - 2018-04-13 23:23:48 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:48 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:48 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:49 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:49 --> Controller Class Initialized
INFO - 2018-04-13 23:23:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:49 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:49 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:49 --> File loaded: E:\www\yacopoo\application\views\questions/has_hit_kids.php
INFO - 2018-04-13 23:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:49 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:49 --> Total execution time: 0.6251
INFO - 2018-04-13 23:23:49 --> Config Class Initialized
INFO - 2018-04-13 23:23:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:49 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:49 --> URI Class Initialized
INFO - 2018-04-13 23:23:49 --> Router Class Initialized
INFO - 2018-04-13 23:23:49 --> Output Class Initialized
INFO - 2018-04-13 23:23:49 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:49 --> CSRF cookie sent
INFO - 2018-04-13 23:23:49 --> Input Class Initialized
INFO - 2018-04-13 23:23:49 --> Language Class Initialized
ERROR - 2018-04-13 23:23:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:52 --> Config Class Initialized
INFO - 2018-04-13 23:23:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:52 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:52 --> URI Class Initialized
INFO - 2018-04-13 23:23:52 --> Router Class Initialized
INFO - 2018-04-13 23:23:52 --> Output Class Initialized
INFO - 2018-04-13 23:23:52 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:52 --> CSRF cookie sent
INFO - 2018-04-13 23:23:52 --> CSRF token verified
INFO - 2018-04-13 23:23:52 --> Input Class Initialized
INFO - 2018-04-13 23:23:52 --> Language Class Initialized
INFO - 2018-04-13 23:23:52 --> Loader Class Initialized
INFO - 2018-04-13 23:23:52 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:52 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:52 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:52 --> Controller Class Initialized
INFO - 2018-04-13 23:23:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:52 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:52 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:52 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:52 --> Config Class Initialized
INFO - 2018-04-13 23:23:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:52 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:52 --> URI Class Initialized
INFO - 2018-04-13 23:23:52 --> Router Class Initialized
INFO - 2018-04-13 23:23:52 --> Output Class Initialized
INFO - 2018-04-13 23:23:52 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:52 --> CSRF cookie sent
INFO - 2018-04-13 23:23:52 --> Input Class Initialized
INFO - 2018-04-13 23:23:52 --> Language Class Initialized
INFO - 2018-04-13 23:23:52 --> Loader Class Initialized
INFO - 2018-04-13 23:23:52 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:52 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:52 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:52 --> Controller Class Initialized
INFO - 2018-04-13 23:23:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:53 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:53 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:53 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:53 --> File loaded: E:\www\yacopoo\application\views\questions/has_dating_profile.php
INFO - 2018-04-13 23:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:53 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:53 --> Total execution time: 0.5802
INFO - 2018-04-13 23:23:53 --> Config Class Initialized
INFO - 2018-04-13 23:23:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:53 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:53 --> URI Class Initialized
INFO - 2018-04-13 23:23:53 --> Router Class Initialized
INFO - 2018-04-13 23:23:53 --> Output Class Initialized
INFO - 2018-04-13 23:23:53 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:53 --> CSRF cookie sent
INFO - 2018-04-13 23:23:53 --> Input Class Initialized
INFO - 2018-04-13 23:23:53 --> Language Class Initialized
ERROR - 2018-04-13 23:23:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:23:56 --> Config Class Initialized
INFO - 2018-04-13 23:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:56 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:56 --> URI Class Initialized
INFO - 2018-04-13 23:23:56 --> Router Class Initialized
INFO - 2018-04-13 23:23:56 --> Output Class Initialized
INFO - 2018-04-13 23:23:56 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:56 --> CSRF cookie sent
INFO - 2018-04-13 23:23:56 --> CSRF token verified
INFO - 2018-04-13 23:23:56 --> Input Class Initialized
INFO - 2018-04-13 23:23:56 --> Language Class Initialized
INFO - 2018-04-13 23:23:56 --> Loader Class Initialized
INFO - 2018-04-13 23:23:56 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:56 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:56 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:56 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:56 --> Controller Class Initialized
INFO - 2018-04-13 23:23:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:56 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:56 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:56 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:56 --> Form Validation Class Initialized
INFO - 2018-04-13 23:23:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:23:56 --> Config Class Initialized
INFO - 2018-04-13 23:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:56 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:56 --> URI Class Initialized
INFO - 2018-04-13 23:23:56 --> Router Class Initialized
INFO - 2018-04-13 23:23:56 --> Output Class Initialized
INFO - 2018-04-13 23:23:56 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:56 --> CSRF cookie sent
INFO - 2018-04-13 23:23:56 --> Input Class Initialized
INFO - 2018-04-13 23:23:56 --> Language Class Initialized
INFO - 2018-04-13 23:23:56 --> Loader Class Initialized
INFO - 2018-04-13 23:23:56 --> Helper loaded: url_helper
INFO - 2018-04-13 23:23:56 --> Helper loaded: form_helper
INFO - 2018-04-13 23:23:56 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:23:57 --> User Agent Class Initialized
INFO - 2018-04-13 23:23:57 --> Controller Class Initialized
INFO - 2018-04-13 23:23:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:23:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:23:57 --> Pixel_Model class loaded
INFO - 2018-04-13 23:23:57 --> Database Driver Class Initialized
INFO - 2018-04-13 23:23:57 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:23:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:23:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:23:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:23:57 --> File loaded: E:\www\yacopoo\application\views\questions/times_slept_couch.php
INFO - 2018-04-13 23:23:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:23:57 --> Final output sent to browser
DEBUG - 2018-04-13 23:23:57 --> Total execution time: 0.5701
INFO - 2018-04-13 23:23:57 --> Config Class Initialized
INFO - 2018-04-13 23:23:57 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:23:57 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:23:57 --> Utf8 Class Initialized
INFO - 2018-04-13 23:23:57 --> URI Class Initialized
INFO - 2018-04-13 23:23:57 --> Router Class Initialized
INFO - 2018-04-13 23:23:57 --> Output Class Initialized
INFO - 2018-04-13 23:23:57 --> Security Class Initialized
DEBUG - 2018-04-13 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:23:57 --> CSRF cookie sent
INFO - 2018-04-13 23:23:57 --> Input Class Initialized
INFO - 2018-04-13 23:23:57 --> Language Class Initialized
ERROR - 2018-04-13 23:23:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:00 --> Config Class Initialized
INFO - 2018-04-13 23:24:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:00 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:00 --> URI Class Initialized
INFO - 2018-04-13 23:24:00 --> Router Class Initialized
INFO - 2018-04-13 23:24:00 --> Output Class Initialized
INFO - 2018-04-13 23:24:00 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:00 --> CSRF cookie sent
INFO - 2018-04-13 23:24:00 --> CSRF token verified
INFO - 2018-04-13 23:24:00 --> Input Class Initialized
INFO - 2018-04-13 23:24:00 --> Language Class Initialized
INFO - 2018-04-13 23:24:00 --> Loader Class Initialized
INFO - 2018-04-13 23:24:00 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:00 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:00 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:00 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:00 --> Controller Class Initialized
INFO - 2018-04-13 23:24:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:00 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:01 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:01 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:01 --> Config Class Initialized
INFO - 2018-04-13 23:24:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:01 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:01 --> URI Class Initialized
INFO - 2018-04-13 23:24:01 --> Router Class Initialized
INFO - 2018-04-13 23:24:01 --> Output Class Initialized
INFO - 2018-04-13 23:24:01 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:01 --> CSRF cookie sent
INFO - 2018-04-13 23:24:01 --> Input Class Initialized
INFO - 2018-04-13 23:24:01 --> Language Class Initialized
INFO - 2018-04-13 23:24:01 --> Loader Class Initialized
INFO - 2018-04-13 23:24:01 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:01 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:01 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:01 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:01 --> Controller Class Initialized
INFO - 2018-04-13 23:24:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:01 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:01 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:01 --> File loaded: E:\www\yacopoo\application\views\questions/has_relationship_outside.php
INFO - 2018-04-13 23:24:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:01 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:01 --> Total execution time: 0.5785
INFO - 2018-04-13 23:24:02 --> Config Class Initialized
INFO - 2018-04-13 23:24:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:02 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:02 --> URI Class Initialized
INFO - 2018-04-13 23:24:02 --> Router Class Initialized
INFO - 2018-04-13 23:24:02 --> Output Class Initialized
INFO - 2018-04-13 23:24:02 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:02 --> CSRF cookie sent
INFO - 2018-04-13 23:24:02 --> Input Class Initialized
INFO - 2018-04-13 23:24:02 --> Language Class Initialized
ERROR - 2018-04-13 23:24:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:16 --> Config Class Initialized
INFO - 2018-04-13 23:24:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:16 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:16 --> URI Class Initialized
INFO - 2018-04-13 23:24:16 --> Router Class Initialized
INFO - 2018-04-13 23:24:16 --> Output Class Initialized
INFO - 2018-04-13 23:24:16 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:16 --> CSRF cookie sent
INFO - 2018-04-13 23:24:16 --> CSRF token verified
INFO - 2018-04-13 23:24:16 --> Input Class Initialized
INFO - 2018-04-13 23:24:16 --> Language Class Initialized
INFO - 2018-04-13 23:24:16 --> Loader Class Initialized
INFO - 2018-04-13 23:24:16 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:16 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:16 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:16 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:16 --> Controller Class Initialized
INFO - 2018-04-13 23:24:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:16 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:16 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:16 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:16 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:16 --> Config Class Initialized
INFO - 2018-04-13 23:24:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:16 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:16 --> URI Class Initialized
INFO - 2018-04-13 23:24:16 --> Router Class Initialized
INFO - 2018-04-13 23:24:16 --> Output Class Initialized
INFO - 2018-04-13 23:24:16 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:17 --> CSRF cookie sent
INFO - 2018-04-13 23:24:17 --> Input Class Initialized
INFO - 2018-04-13 23:24:17 --> Language Class Initialized
INFO - 2018-04-13 23:24:17 --> Loader Class Initialized
INFO - 2018-04-13 23:24:17 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:17 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:17 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:17 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:17 --> Controller Class Initialized
INFO - 2018-04-13 23:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:17 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:17 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:17 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:17 --> File loaded: E:\www\yacopoo\application\views\questions/liens_on_house.php
INFO - 2018-04-13 23:24:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:17 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:17 --> Total execution time: 0.5849
INFO - 2018-04-13 23:24:17 --> Config Class Initialized
INFO - 2018-04-13 23:24:17 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:17 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:17 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:17 --> URI Class Initialized
INFO - 2018-04-13 23:24:17 --> Router Class Initialized
INFO - 2018-04-13 23:24:18 --> Output Class Initialized
INFO - 2018-04-13 23:24:18 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:18 --> CSRF cookie sent
INFO - 2018-04-13 23:24:18 --> Input Class Initialized
INFO - 2018-04-13 23:24:18 --> Language Class Initialized
ERROR - 2018-04-13 23:24:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:20 --> Config Class Initialized
INFO - 2018-04-13 23:24:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:20 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:20 --> URI Class Initialized
INFO - 2018-04-13 23:24:20 --> Router Class Initialized
INFO - 2018-04-13 23:24:20 --> Output Class Initialized
INFO - 2018-04-13 23:24:21 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:21 --> CSRF cookie sent
INFO - 2018-04-13 23:24:21 --> CSRF token verified
INFO - 2018-04-13 23:24:21 --> Input Class Initialized
INFO - 2018-04-13 23:24:21 --> Language Class Initialized
INFO - 2018-04-13 23:24:21 --> Loader Class Initialized
INFO - 2018-04-13 23:24:21 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:21 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:21 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:21 --> Controller Class Initialized
INFO - 2018-04-13 23:24:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:21 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:21 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:21 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:21 --> Config Class Initialized
INFO - 2018-04-13 23:24:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:21 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:21 --> URI Class Initialized
INFO - 2018-04-13 23:24:21 --> Router Class Initialized
INFO - 2018-04-13 23:24:21 --> Output Class Initialized
INFO - 2018-04-13 23:24:21 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:21 --> CSRF cookie sent
INFO - 2018-04-13 23:24:21 --> Input Class Initialized
INFO - 2018-04-13 23:24:21 --> Language Class Initialized
INFO - 2018-04-13 23:24:21 --> Loader Class Initialized
INFO - 2018-04-13 23:24:21 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:21 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:21 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:21 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:21 --> Controller Class Initialized
INFO - 2018-04-13 23:24:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:21 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:21 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:22 --> File loaded: E:\www\yacopoo\application\views\questions/have_loan_money.php
INFO - 2018-04-13 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:22 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:22 --> Total execution time: 0.5890
INFO - 2018-04-13 23:24:22 --> Config Class Initialized
INFO - 2018-04-13 23:24:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:22 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:22 --> URI Class Initialized
INFO - 2018-04-13 23:24:22 --> Router Class Initialized
INFO - 2018-04-13 23:24:22 --> Output Class Initialized
INFO - 2018-04-13 23:24:22 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:22 --> CSRF cookie sent
INFO - 2018-04-13 23:24:22 --> Input Class Initialized
INFO - 2018-04-13 23:24:22 --> Language Class Initialized
ERROR - 2018-04-13 23:24:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:25 --> Config Class Initialized
INFO - 2018-04-13 23:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:25 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:25 --> URI Class Initialized
INFO - 2018-04-13 23:24:25 --> Router Class Initialized
INFO - 2018-04-13 23:24:25 --> Output Class Initialized
INFO - 2018-04-13 23:24:25 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:25 --> CSRF cookie sent
INFO - 2018-04-13 23:24:25 --> CSRF token verified
INFO - 2018-04-13 23:24:25 --> Input Class Initialized
INFO - 2018-04-13 23:24:25 --> Language Class Initialized
INFO - 2018-04-13 23:24:25 --> Loader Class Initialized
INFO - 2018-04-13 23:24:25 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:25 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:25 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:25 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:25 --> Controller Class Initialized
INFO - 2018-04-13 23:24:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:25 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:26 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:26 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:26 --> Config Class Initialized
INFO - 2018-04-13 23:24:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:26 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:26 --> URI Class Initialized
INFO - 2018-04-13 23:24:26 --> Router Class Initialized
INFO - 2018-04-13 23:24:26 --> Output Class Initialized
INFO - 2018-04-13 23:24:26 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:26 --> CSRF cookie sent
INFO - 2018-04-13 23:24:26 --> Input Class Initialized
INFO - 2018-04-13 23:24:26 --> Language Class Initialized
INFO - 2018-04-13 23:24:26 --> Loader Class Initialized
INFO - 2018-04-13 23:24:26 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:26 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:26 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:26 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:26 --> Controller Class Initialized
INFO - 2018-04-13 23:24:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:26 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:26 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:26 --> File loaded: E:\www\yacopoo\application\views\questions/social_class.php
INFO - 2018-04-13 23:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:26 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:26 --> Total execution time: 0.5899
INFO - 2018-04-13 23:24:27 --> Config Class Initialized
INFO - 2018-04-13 23:24:27 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:27 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:27 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:27 --> URI Class Initialized
INFO - 2018-04-13 23:24:27 --> Router Class Initialized
INFO - 2018-04-13 23:24:27 --> Output Class Initialized
INFO - 2018-04-13 23:24:27 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:27 --> CSRF cookie sent
INFO - 2018-04-13 23:24:27 --> Input Class Initialized
INFO - 2018-04-13 23:24:27 --> Language Class Initialized
ERROR - 2018-04-13 23:24:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:30 --> Config Class Initialized
INFO - 2018-04-13 23:24:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:30 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:30 --> URI Class Initialized
INFO - 2018-04-13 23:24:30 --> Router Class Initialized
INFO - 2018-04-13 23:24:30 --> Output Class Initialized
INFO - 2018-04-13 23:24:30 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:30 --> CSRF cookie sent
INFO - 2018-04-13 23:24:30 --> CSRF token verified
INFO - 2018-04-13 23:24:30 --> Input Class Initialized
INFO - 2018-04-13 23:24:30 --> Language Class Initialized
INFO - 2018-04-13 23:24:30 --> Loader Class Initialized
INFO - 2018-04-13 23:24:30 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:30 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:30 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:30 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:30 --> Controller Class Initialized
INFO - 2018-04-13 23:24:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:30 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:30 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:30 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:30 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:31 --> Config Class Initialized
INFO - 2018-04-13 23:24:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:31 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:31 --> URI Class Initialized
INFO - 2018-04-13 23:24:31 --> Router Class Initialized
INFO - 2018-04-13 23:24:31 --> Output Class Initialized
INFO - 2018-04-13 23:24:31 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:31 --> CSRF cookie sent
INFO - 2018-04-13 23:24:31 --> Input Class Initialized
INFO - 2018-04-13 23:24:31 --> Language Class Initialized
INFO - 2018-04-13 23:24:31 --> Loader Class Initialized
INFO - 2018-04-13 23:24:31 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:31 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:31 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:31 --> Controller Class Initialized
INFO - 2018-04-13 23:24:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:31 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:31 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:31 --> File loaded: E:\www\yacopoo\application\views\questions/s_social_class.php
INFO - 2018-04-13 23:24:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:31 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:31 --> Total execution time: 0.6002
INFO - 2018-04-13 23:24:31 --> Config Class Initialized
INFO - 2018-04-13 23:24:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:32 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:32 --> URI Class Initialized
INFO - 2018-04-13 23:24:32 --> Router Class Initialized
INFO - 2018-04-13 23:24:32 --> Output Class Initialized
INFO - 2018-04-13 23:24:32 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:32 --> CSRF cookie sent
INFO - 2018-04-13 23:24:32 --> Input Class Initialized
INFO - 2018-04-13 23:24:32 --> Language Class Initialized
ERROR - 2018-04-13 23:24:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:24:36 --> Config Class Initialized
INFO - 2018-04-13 23:24:36 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:36 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:36 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:36 --> URI Class Initialized
INFO - 2018-04-13 23:24:36 --> Router Class Initialized
INFO - 2018-04-13 23:24:37 --> Output Class Initialized
INFO - 2018-04-13 23:24:37 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:37 --> CSRF cookie sent
INFO - 2018-04-13 23:24:37 --> CSRF token verified
INFO - 2018-04-13 23:24:37 --> Input Class Initialized
INFO - 2018-04-13 23:24:37 --> Language Class Initialized
INFO - 2018-04-13 23:24:37 --> Loader Class Initialized
INFO - 2018-04-13 23:24:37 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:37 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:37 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:37 --> Controller Class Initialized
INFO - 2018-04-13 23:24:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:37 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:37 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:37 --> Form Validation Class Initialized
INFO - 2018-04-13 23:24:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:24:37 --> Config Class Initialized
INFO - 2018-04-13 23:24:37 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:37 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:37 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:37 --> URI Class Initialized
INFO - 2018-04-13 23:24:37 --> Router Class Initialized
INFO - 2018-04-13 23:24:37 --> Output Class Initialized
INFO - 2018-04-13 23:24:37 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:37 --> CSRF cookie sent
INFO - 2018-04-13 23:24:37 --> Input Class Initialized
INFO - 2018-04-13 23:24:37 --> Language Class Initialized
INFO - 2018-04-13 23:24:37 --> Loader Class Initialized
INFO - 2018-04-13 23:24:37 --> Helper loaded: url_helper
INFO - 2018-04-13 23:24:37 --> Helper loaded: form_helper
INFO - 2018-04-13 23:24:37 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:24:37 --> User Agent Class Initialized
INFO - 2018-04-13 23:24:37 --> Controller Class Initialized
INFO - 2018-04-13 23:24:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:24:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:24:38 --> Pixel_Model class loaded
INFO - 2018-04-13 23:24:38 --> Database Driver Class Initialized
INFO - 2018-04-13 23:24:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:24:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:24:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:24:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:24:38 --> File loaded: E:\www\yacopoo\application\views\questions/s_social_class.php
INFO - 2018-04-13 23:24:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:24:38 --> Final output sent to browser
DEBUG - 2018-04-13 23:24:38 --> Total execution time: 0.6827
INFO - 2018-04-13 23:24:38 --> Config Class Initialized
INFO - 2018-04-13 23:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:24:38 --> Utf8 Class Initialized
INFO - 2018-04-13 23:24:38 --> URI Class Initialized
INFO - 2018-04-13 23:24:38 --> Router Class Initialized
INFO - 2018-04-13 23:24:38 --> Output Class Initialized
INFO - 2018-04-13 23:24:38 --> Security Class Initialized
DEBUG - 2018-04-13 23:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:24:38 --> CSRF cookie sent
INFO - 2018-04-13 23:24:38 --> Input Class Initialized
INFO - 2018-04-13 23:24:38 --> Language Class Initialized
ERROR - 2018-04-13 23:24:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:39:43 --> Config Class Initialized
INFO - 2018-04-13 23:39:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:39:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:39:43 --> Utf8 Class Initialized
INFO - 2018-04-13 23:39:43 --> URI Class Initialized
INFO - 2018-04-13 23:39:43 --> Router Class Initialized
INFO - 2018-04-13 23:39:43 --> Output Class Initialized
INFO - 2018-04-13 23:39:43 --> Security Class Initialized
DEBUG - 2018-04-13 23:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:39:43 --> CSRF cookie sent
INFO - 2018-04-13 23:39:43 --> Input Class Initialized
INFO - 2018-04-13 23:39:43 --> Language Class Initialized
INFO - 2018-04-13 23:39:43 --> Loader Class Initialized
INFO - 2018-04-13 23:39:44 --> Helper loaded: url_helper
INFO - 2018-04-13 23:39:44 --> Helper loaded: form_helper
INFO - 2018-04-13 23:39:44 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:39:44 --> User Agent Class Initialized
INFO - 2018-04-13 23:39:44 --> Controller Class Initialized
INFO - 2018-04-13 23:39:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:39:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:39:44 --> Pixel_Model class loaded
INFO - 2018-04-13 23:39:44 --> Database Driver Class Initialized
INFO - 2018-04-13 23:39:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:39:47 --> File loaded: E:\www\yacopoo\application\views\questions/kids_info.php
INFO - 2018-04-13 23:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:39:47 --> Final output sent to browser
DEBUG - 2018-04-13 23:39:47 --> Total execution time: 3.6456
INFO - 2018-04-13 23:39:47 --> Config Class Initialized
INFO - 2018-04-13 23:39:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:39:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:39:47 --> Utf8 Class Initialized
INFO - 2018-04-13 23:39:47 --> URI Class Initialized
INFO - 2018-04-13 23:39:47 --> Router Class Initialized
INFO - 2018-04-13 23:39:47 --> Output Class Initialized
INFO - 2018-04-13 23:39:47 --> Security Class Initialized
DEBUG - 2018-04-13 23:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:39:48 --> CSRF cookie sent
INFO - 2018-04-13 23:39:48 --> Input Class Initialized
INFO - 2018-04-13 23:39:48 --> Language Class Initialized
ERROR - 2018-04-13 23:39:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:55:07 --> Config Class Initialized
INFO - 2018-04-13 23:55:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:08 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:08 --> URI Class Initialized
INFO - 2018-04-13 23:55:08 --> Router Class Initialized
INFO - 2018-04-13 23:55:08 --> Output Class Initialized
INFO - 2018-04-13 23:55:08 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:08 --> CSRF cookie sent
INFO - 2018-04-13 23:55:08 --> Input Class Initialized
INFO - 2018-04-13 23:55:08 --> Language Class Initialized
INFO - 2018-04-13 23:55:08 --> Loader Class Initialized
INFO - 2018-04-13 23:55:08 --> Helper loaded: url_helper
INFO - 2018-04-13 23:55:08 --> Helper loaded: form_helper
INFO - 2018-04-13 23:55:08 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:55:08 --> User Agent Class Initialized
INFO - 2018-04-13 23:55:08 --> Controller Class Initialized
INFO - 2018-04-13 23:55:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:55:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:55:08 --> Pixel_Model class loaded
INFO - 2018-04-13 23:55:08 --> Database Driver Class Initialized
INFO - 2018-04-13 23:55:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:55:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:55:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:55:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:55:11 --> File loaded: E:\www\yacopoo\application\views\questions/s_social_class.php
INFO - 2018-04-13 23:55:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:55:11 --> Final output sent to browser
DEBUG - 2018-04-13 23:55:11 --> Total execution time: 3.6221
INFO - 2018-04-13 23:55:11 --> Config Class Initialized
INFO - 2018-04-13 23:55:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:11 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:12 --> URI Class Initialized
INFO - 2018-04-13 23:55:12 --> Router Class Initialized
INFO - 2018-04-13 23:55:12 --> Output Class Initialized
INFO - 2018-04-13 23:55:12 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:12 --> CSRF cookie sent
INFO - 2018-04-13 23:55:12 --> Input Class Initialized
INFO - 2018-04-13 23:55:12 --> Language Class Initialized
ERROR - 2018-04-13 23:55:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:55:19 --> Config Class Initialized
INFO - 2018-04-13 23:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:19 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:19 --> URI Class Initialized
INFO - 2018-04-13 23:55:19 --> Router Class Initialized
INFO - 2018-04-13 23:55:19 --> Output Class Initialized
INFO - 2018-04-13 23:55:19 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:19 --> CSRF cookie sent
INFO - 2018-04-13 23:55:19 --> CSRF token verified
INFO - 2018-04-13 23:55:19 --> Input Class Initialized
INFO - 2018-04-13 23:55:19 --> Language Class Initialized
INFO - 2018-04-13 23:55:19 --> Loader Class Initialized
INFO - 2018-04-13 23:55:19 --> Helper loaded: url_helper
INFO - 2018-04-13 23:55:19 --> Helper loaded: form_helper
INFO - 2018-04-13 23:55:19 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:55:19 --> User Agent Class Initialized
INFO - 2018-04-13 23:55:19 --> Controller Class Initialized
INFO - 2018-04-13 23:55:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:55:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:55:19 --> Pixel_Model class loaded
INFO - 2018-04-13 23:55:19 --> Database Driver Class Initialized
INFO - 2018-04-13 23:55:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:55:19 --> Form Validation Class Initialized
INFO - 2018-04-13 23:55:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:55:20 --> Config Class Initialized
INFO - 2018-04-13 23:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:20 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:20 --> URI Class Initialized
INFO - 2018-04-13 23:55:20 --> Router Class Initialized
INFO - 2018-04-13 23:55:20 --> Output Class Initialized
INFO - 2018-04-13 23:55:20 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:20 --> CSRF cookie sent
INFO - 2018-04-13 23:55:20 --> Input Class Initialized
INFO - 2018-04-13 23:55:20 --> Language Class Initialized
INFO - 2018-04-13 23:55:20 --> Loader Class Initialized
INFO - 2018-04-13 23:55:20 --> Helper loaded: url_helper
INFO - 2018-04-13 23:55:20 --> Helper loaded: form_helper
INFO - 2018-04-13 23:55:20 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:55:20 --> User Agent Class Initialized
INFO - 2018-04-13 23:55:20 --> Controller Class Initialized
INFO - 2018-04-13 23:55:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:55:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:55:20 --> Pixel_Model class loaded
INFO - 2018-04-13 23:55:20 --> Database Driver Class Initialized
INFO - 2018-04-13 23:55:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:55:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:55:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:55:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:55:20 --> File loaded: E:\www\yacopoo\application\views\questions/s_social_class.php
INFO - 2018-04-13 23:55:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:55:20 --> Final output sent to browser
DEBUG - 2018-04-13 23:55:20 --> Total execution time: 0.6078
INFO - 2018-04-13 23:55:20 --> Config Class Initialized
INFO - 2018-04-13 23:55:21 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:21 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:21 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:21 --> URI Class Initialized
INFO - 2018-04-13 23:55:21 --> Router Class Initialized
INFO - 2018-04-13 23:55:21 --> Output Class Initialized
INFO - 2018-04-13 23:55:21 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:21 --> CSRF cookie sent
INFO - 2018-04-13 23:55:21 --> Input Class Initialized
INFO - 2018-04-13 23:55:21 --> Language Class Initialized
ERROR - 2018-04-13 23:55:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:55:45 --> Config Class Initialized
INFO - 2018-04-13 23:55:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:45 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:45 --> URI Class Initialized
INFO - 2018-04-13 23:55:45 --> Router Class Initialized
INFO - 2018-04-13 23:55:45 --> Output Class Initialized
INFO - 2018-04-13 23:55:45 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:45 --> CSRF cookie sent
INFO - 2018-04-13 23:55:45 --> CSRF token verified
INFO - 2018-04-13 23:55:45 --> Input Class Initialized
INFO - 2018-04-13 23:55:45 --> Language Class Initialized
INFO - 2018-04-13 23:55:45 --> Loader Class Initialized
INFO - 2018-04-13 23:55:45 --> Helper loaded: url_helper
INFO - 2018-04-13 23:55:45 --> Helper loaded: form_helper
INFO - 2018-04-13 23:55:45 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:55:45 --> User Agent Class Initialized
INFO - 2018-04-13 23:55:45 --> Controller Class Initialized
INFO - 2018-04-13 23:55:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:55:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:55:45 --> Pixel_Model class loaded
INFO - 2018-04-13 23:55:45 --> Database Driver Class Initialized
INFO - 2018-04-13 23:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:55:45 --> Form Validation Class Initialized
INFO - 2018-04-13 23:55:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:55:46 --> Config Class Initialized
INFO - 2018-04-13 23:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:46 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:46 --> URI Class Initialized
INFO - 2018-04-13 23:55:46 --> Router Class Initialized
INFO - 2018-04-13 23:55:46 --> Output Class Initialized
INFO - 2018-04-13 23:55:46 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:46 --> CSRF cookie sent
INFO - 2018-04-13 23:55:46 --> Input Class Initialized
INFO - 2018-04-13 23:55:46 --> Language Class Initialized
INFO - 2018-04-13 23:55:46 --> Loader Class Initialized
INFO - 2018-04-13 23:55:46 --> Helper loaded: url_helper
INFO - 2018-04-13 23:55:46 --> Helper loaded: form_helper
INFO - 2018-04-13 23:55:46 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:55:46 --> User Agent Class Initialized
INFO - 2018-04-13 23:55:46 --> Controller Class Initialized
INFO - 2018-04-13 23:55:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:55:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:55:46 --> Pixel_Model class loaded
INFO - 2018-04-13 23:55:46 --> Database Driver Class Initialized
INFO - 2018-04-13 23:55:46 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:55:46 --> File loaded: E:\www\yacopoo\application\views\questions/s_social_class.php
INFO - 2018-04-13 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:55:46 --> Final output sent to browser
DEBUG - 2018-04-13 23:55:46 --> Total execution time: 0.6110
INFO - 2018-04-13 23:55:47 --> Config Class Initialized
INFO - 2018-04-13 23:55:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:55:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:55:47 --> Utf8 Class Initialized
INFO - 2018-04-13 23:55:47 --> URI Class Initialized
INFO - 2018-04-13 23:55:47 --> Router Class Initialized
INFO - 2018-04-13 23:55:47 --> Output Class Initialized
INFO - 2018-04-13 23:55:47 --> Security Class Initialized
DEBUG - 2018-04-13 23:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:55:47 --> CSRF cookie sent
INFO - 2018-04-13 23:55:47 --> Input Class Initialized
INFO - 2018-04-13 23:55:47 --> Language Class Initialized
ERROR - 2018-04-13 23:55:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:56:31 --> Config Class Initialized
INFO - 2018-04-13 23:56:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:56:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:56:31 --> Utf8 Class Initialized
INFO - 2018-04-13 23:56:31 --> URI Class Initialized
INFO - 2018-04-13 23:56:31 --> Router Class Initialized
INFO - 2018-04-13 23:56:31 --> Output Class Initialized
INFO - 2018-04-13 23:56:31 --> Security Class Initialized
DEBUG - 2018-04-13 23:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:56:31 --> CSRF cookie sent
INFO - 2018-04-13 23:56:31 --> Input Class Initialized
INFO - 2018-04-13 23:56:31 --> Language Class Initialized
INFO - 2018-04-13 23:56:31 --> Loader Class Initialized
INFO - 2018-04-13 23:56:31 --> Helper loaded: url_helper
INFO - 2018-04-13 23:56:31 --> Helper loaded: form_helper
INFO - 2018-04-13 23:56:31 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:56:31 --> User Agent Class Initialized
INFO - 2018-04-13 23:56:31 --> Controller Class Initialized
INFO - 2018-04-13 23:56:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:56:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:56:31 --> Pixel_Model class loaded
INFO - 2018-04-13 23:56:31 --> Database Driver Class Initialized
INFO - 2018-04-13 23:56:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:56:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:56:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:56:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:56:31 --> File loaded: E:\www\yacopoo\application\views\questions/people_confide.php
INFO - 2018-04-13 23:56:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:56:31 --> Final output sent to browser
DEBUG - 2018-04-13 23:56:31 --> Total execution time: 0.6474
INFO - 2018-04-13 23:56:32 --> Config Class Initialized
INFO - 2018-04-13 23:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:56:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:56:32 --> Utf8 Class Initialized
INFO - 2018-04-13 23:56:32 --> URI Class Initialized
INFO - 2018-04-13 23:56:32 --> Router Class Initialized
INFO - 2018-04-13 23:56:32 --> Output Class Initialized
INFO - 2018-04-13 23:56:32 --> Security Class Initialized
DEBUG - 2018-04-13 23:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:56:32 --> CSRF cookie sent
INFO - 2018-04-13 23:56:32 --> Input Class Initialized
INFO - 2018-04-13 23:56:32 --> Language Class Initialized
ERROR - 2018-04-13 23:56:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:56:52 --> Config Class Initialized
INFO - 2018-04-13 23:56:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:56:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:56:52 --> Utf8 Class Initialized
INFO - 2018-04-13 23:56:52 --> URI Class Initialized
INFO - 2018-04-13 23:56:52 --> Router Class Initialized
INFO - 2018-04-13 23:56:52 --> Output Class Initialized
INFO - 2018-04-13 23:56:52 --> Security Class Initialized
DEBUG - 2018-04-13 23:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:56:52 --> CSRF cookie sent
INFO - 2018-04-13 23:56:52 --> Input Class Initialized
INFO - 2018-04-13 23:56:52 --> Language Class Initialized
INFO - 2018-04-13 23:56:52 --> Loader Class Initialized
INFO - 2018-04-13 23:56:52 --> Helper loaded: url_helper
INFO - 2018-04-13 23:56:52 --> Helper loaded: form_helper
INFO - 2018-04-13 23:56:52 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:56:52 --> User Agent Class Initialized
INFO - 2018-04-13 23:56:52 --> Controller Class Initialized
INFO - 2018-04-13 23:56:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:56:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:56:52 --> Pixel_Model class loaded
INFO - 2018-04-13 23:56:52 --> Database Driver Class Initialized
INFO - 2018-04-13 23:56:53 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:56:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:56:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:56:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:56:53 --> File loaded: E:\www\yacopoo\application\views\questions/people_confide.php
INFO - 2018-04-13 23:56:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:56:53 --> Final output sent to browser
DEBUG - 2018-04-13 23:56:53 --> Total execution time: 0.6420
INFO - 2018-04-13 23:56:53 --> Config Class Initialized
INFO - 2018-04-13 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:56:53 --> Utf8 Class Initialized
INFO - 2018-04-13 23:56:53 --> URI Class Initialized
INFO - 2018-04-13 23:56:53 --> Router Class Initialized
INFO - 2018-04-13 23:56:53 --> Output Class Initialized
INFO - 2018-04-13 23:56:53 --> Security Class Initialized
DEBUG - 2018-04-13 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:56:53 --> CSRF cookie sent
INFO - 2018-04-13 23:56:53 --> Input Class Initialized
INFO - 2018-04-13 23:56:53 --> Language Class Initialized
ERROR - 2018-04-13 23:56:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:57:08 --> Config Class Initialized
INFO - 2018-04-13 23:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:57:08 --> Utf8 Class Initialized
INFO - 2018-04-13 23:57:08 --> URI Class Initialized
INFO - 2018-04-13 23:57:08 --> Router Class Initialized
INFO - 2018-04-13 23:57:08 --> Output Class Initialized
INFO - 2018-04-13 23:57:08 --> Security Class Initialized
DEBUG - 2018-04-13 23:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:57:08 --> CSRF cookie sent
INFO - 2018-04-13 23:57:08 --> CSRF token verified
INFO - 2018-04-13 23:57:08 --> Input Class Initialized
INFO - 2018-04-13 23:57:08 --> Language Class Initialized
INFO - 2018-04-13 23:57:08 --> Loader Class Initialized
INFO - 2018-04-13 23:57:08 --> Helper loaded: url_helper
INFO - 2018-04-13 23:57:08 --> Helper loaded: form_helper
INFO - 2018-04-13 23:57:08 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:57:08 --> User Agent Class Initialized
INFO - 2018-04-13 23:57:08 --> Controller Class Initialized
INFO - 2018-04-13 23:57:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:57:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:57:08 --> Pixel_Model class loaded
INFO - 2018-04-13 23:57:08 --> Database Driver Class Initialized
INFO - 2018-04-13 23:57:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:57:11 --> Form Validation Class Initialized
INFO - 2018-04-13 23:57:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:57:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:57:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:57:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:57:12 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-13 23:57:12 --> File loaded: E:\www\yacopoo\application\views\questions/people_confide.php
INFO - 2018-04-13 23:57:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:57:12 --> Final output sent to browser
DEBUG - 2018-04-13 23:57:12 --> Total execution time: 3.7000
INFO - 2018-04-13 23:57:13 --> Config Class Initialized
INFO - 2018-04-13 23:57:13 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:57:13 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:57:13 --> Utf8 Class Initialized
INFO - 2018-04-13 23:57:13 --> URI Class Initialized
INFO - 2018-04-13 23:57:13 --> Router Class Initialized
INFO - 2018-04-13 23:57:13 --> Output Class Initialized
INFO - 2018-04-13 23:57:13 --> Security Class Initialized
DEBUG - 2018-04-13 23:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:57:13 --> CSRF cookie sent
INFO - 2018-04-13 23:57:13 --> Input Class Initialized
INFO - 2018-04-13 23:57:13 --> Language Class Initialized
ERROR - 2018-04-13 23:57:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:57:43 --> Config Class Initialized
INFO - 2018-04-13 23:57:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:57:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:57:43 --> Utf8 Class Initialized
INFO - 2018-04-13 23:57:43 --> URI Class Initialized
INFO - 2018-04-13 23:57:43 --> Router Class Initialized
INFO - 2018-04-13 23:57:43 --> Output Class Initialized
INFO - 2018-04-13 23:57:43 --> Security Class Initialized
DEBUG - 2018-04-13 23:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:57:43 --> CSRF cookie sent
INFO - 2018-04-13 23:57:43 --> CSRF token verified
INFO - 2018-04-13 23:57:43 --> Input Class Initialized
INFO - 2018-04-13 23:57:43 --> Language Class Initialized
INFO - 2018-04-13 23:57:43 --> Loader Class Initialized
INFO - 2018-04-13 23:57:43 --> Helper loaded: url_helper
INFO - 2018-04-13 23:57:43 --> Helper loaded: form_helper
INFO - 2018-04-13 23:57:43 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:57:43 --> User Agent Class Initialized
INFO - 2018-04-13 23:57:43 --> Controller Class Initialized
INFO - 2018-04-13 23:57:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:57:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:57:43 --> Pixel_Model class loaded
INFO - 2018-04-13 23:57:43 --> Database Driver Class Initialized
INFO - 2018-04-13 23:57:43 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:57:43 --> Form Validation Class Initialized
INFO - 2018-04-13 23:57:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\questions/people_confide.php
INFO - 2018-04-13 23:57:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-13 23:57:43 --> Final output sent to browser
DEBUG - 2018-04-13 23:57:44 --> Total execution time: 0.6998
INFO - 2018-04-13 23:57:44 --> Config Class Initialized
INFO - 2018-04-13 23:57:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:57:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:57:44 --> Utf8 Class Initialized
INFO - 2018-04-13 23:57:44 --> URI Class Initialized
INFO - 2018-04-13 23:57:44 --> Router Class Initialized
INFO - 2018-04-13 23:57:44 --> Output Class Initialized
INFO - 2018-04-13 23:57:44 --> Security Class Initialized
DEBUG - 2018-04-13 23:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:57:44 --> CSRF cookie sent
INFO - 2018-04-13 23:57:44 --> Input Class Initialized
INFO - 2018-04-13 23:57:45 --> Language Class Initialized
ERROR - 2018-04-13 23:57:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-13 23:58:38 --> Config Class Initialized
INFO - 2018-04-13 23:58:38 --> Hooks Class Initialized
DEBUG - 2018-04-13 23:58:38 --> UTF-8 Support Enabled
INFO - 2018-04-13 23:58:38 --> Utf8 Class Initialized
INFO - 2018-04-13 23:58:38 --> URI Class Initialized
INFO - 2018-04-13 23:58:38 --> Router Class Initialized
INFO - 2018-04-13 23:58:38 --> Output Class Initialized
INFO - 2018-04-13 23:58:38 --> Security Class Initialized
DEBUG - 2018-04-13 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 23:58:38 --> CSRF cookie sent
INFO - 2018-04-13 23:58:38 --> CSRF token verified
INFO - 2018-04-13 23:58:38 --> Input Class Initialized
INFO - 2018-04-13 23:58:38 --> Language Class Initialized
INFO - 2018-04-13 23:58:38 --> Loader Class Initialized
INFO - 2018-04-13 23:58:38 --> Helper loaded: url_helper
INFO - 2018-04-13 23:58:38 --> Helper loaded: form_helper
INFO - 2018-04-13 23:58:38 --> Helper loaded: language_helper
DEBUG - 2018-04-13 23:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 23:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 23:58:38 --> User Agent Class Initialized
INFO - 2018-04-13 23:58:38 --> Controller Class Initialized
INFO - 2018-04-13 23:58:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-13 23:58:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-13 23:58:38 --> Pixel_Model class loaded
INFO - 2018-04-13 23:58:38 --> Database Driver Class Initialized
INFO - 2018-04-13 23:58:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-13 23:58:38 --> Form Validation Class Initialized
INFO - 2018-04-13 23:58:38 --> Language file loaded: language/english/form_validation_lang.php

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-14 00:02:55 --> Config Class Initialized
INFO - 2018-04-14 00:02:55 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:02:55 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:02:55 --> Utf8 Class Initialized
INFO - 2018-04-14 00:02:55 --> URI Class Initialized
INFO - 2018-04-14 00:02:55 --> Router Class Initialized
INFO - 2018-04-14 00:02:55 --> Output Class Initialized
INFO - 2018-04-14 00:02:55 --> Security Class Initialized
DEBUG - 2018-04-14 00:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:02:55 --> CSRF cookie sent
INFO - 2018-04-14 00:02:55 --> CSRF token verified
INFO - 2018-04-14 00:02:55 --> Input Class Initialized
INFO - 2018-04-14 00:02:55 --> Language Class Initialized
INFO - 2018-04-14 00:02:55 --> Loader Class Initialized
INFO - 2018-04-14 00:02:55 --> Helper loaded: url_helper
INFO - 2018-04-14 00:02:55 --> Helper loaded: form_helper
INFO - 2018-04-14 00:02:55 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:02:56 --> User Agent Class Initialized
INFO - 2018-04-14 00:02:56 --> Controller Class Initialized
INFO - 2018-04-14 00:02:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:02:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:02:56 --> Pixel_Model class loaded
INFO - 2018-04-14 00:02:56 --> Database Driver Class Initialized
INFO - 2018-04-14 00:02:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:02:59 --> Form Validation Class Initialized
INFO - 2018-04-14 00:02:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-14 00:02:59 --> Config Class Initialized
INFO - 2018-04-14 00:02:59 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:02:59 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:02:59 --> Utf8 Class Initialized
INFO - 2018-04-14 00:02:59 --> URI Class Initialized
INFO - 2018-04-14 00:02:59 --> Router Class Initialized
INFO - 2018-04-14 00:02:59 --> Output Class Initialized
INFO - 2018-04-14 00:02:59 --> Security Class Initialized
DEBUG - 2018-04-14 00:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:02:59 --> CSRF cookie sent
INFO - 2018-04-14 00:02:59 --> Input Class Initialized
INFO - 2018-04-14 00:02:59 --> Language Class Initialized
INFO - 2018-04-14 00:02:59 --> Loader Class Initialized
INFO - 2018-04-14 00:02:59 --> Helper loaded: url_helper
INFO - 2018-04-14 00:02:59 --> Helper loaded: form_helper
INFO - 2018-04-14 00:02:59 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:02:59 --> User Agent Class Initialized
INFO - 2018-04-14 00:02:59 --> Controller Class Initialized
INFO - 2018-04-14 00:02:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:02:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:02:59 --> Pixel_Model class loaded
INFO - 2018-04-14 00:02:59 --> Database Driver Class Initialized
INFO - 2018-04-14 00:02:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:04:13 --> Config Class Initialized
INFO - 2018-04-14 00:04:13 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:04:13 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:04:13 --> Utf8 Class Initialized
INFO - 2018-04-14 00:04:13 --> URI Class Initialized
INFO - 2018-04-14 00:04:13 --> Router Class Initialized
INFO - 2018-04-14 00:04:13 --> Output Class Initialized
INFO - 2018-04-14 00:04:13 --> Security Class Initialized
DEBUG - 2018-04-14 00:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:04:13 --> CSRF cookie sent
INFO - 2018-04-14 00:04:13 --> Input Class Initialized
INFO - 2018-04-14 00:04:13 --> Language Class Initialized
INFO - 2018-04-14 00:04:13 --> Loader Class Initialized
INFO - 2018-04-14 00:04:13 --> Helper loaded: url_helper
INFO - 2018-04-14 00:04:13 --> Helper loaded: form_helper
INFO - 2018-04-14 00:04:13 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:04:13 --> User Agent Class Initialized
INFO - 2018-04-14 00:04:13 --> Controller Class Initialized
INFO - 2018-04-14 00:04:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:04:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:04:13 --> Pixel_Model class loaded
INFO - 2018-04-14 00:04:13 --> Database Driver Class Initialized
INFO - 2018-04-14 00:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:04:55 --> Config Class Initialized
INFO - 2018-04-14 00:04:55 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:04:55 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:04:55 --> Utf8 Class Initialized
INFO - 2018-04-14 00:04:55 --> URI Class Initialized
INFO - 2018-04-14 00:04:55 --> Router Class Initialized
INFO - 2018-04-14 00:04:55 --> Output Class Initialized
INFO - 2018-04-14 00:04:55 --> Security Class Initialized
DEBUG - 2018-04-14 00:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:04:55 --> CSRF cookie sent
INFO - 2018-04-14 00:04:55 --> Input Class Initialized
INFO - 2018-04-14 00:04:55 --> Language Class Initialized
INFO - 2018-04-14 00:04:55 --> Loader Class Initialized
INFO - 2018-04-14 00:04:55 --> Helper loaded: url_helper
INFO - 2018-04-14 00:04:55 --> Helper loaded: form_helper
INFO - 2018-04-14 00:04:55 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:04:55 --> User Agent Class Initialized
INFO - 2018-04-14 00:04:55 --> Controller Class Initialized
INFO - 2018-04-14 00:04:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:04:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:04:56 --> Pixel_Model class loaded
INFO - 2018-04-14 00:04:56 --> Database Driver Class Initialized
INFO - 2018-04-14 00:04:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:07:08 --> Config Class Initialized
INFO - 2018-04-14 00:07:08 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:07:08 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:07:08 --> Utf8 Class Initialized
INFO - 2018-04-14 00:07:08 --> URI Class Initialized
INFO - 2018-04-14 00:07:08 --> Router Class Initialized
INFO - 2018-04-14 00:07:08 --> Output Class Initialized
INFO - 2018-04-14 00:07:08 --> Security Class Initialized
DEBUG - 2018-04-14 00:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:07:08 --> CSRF cookie sent
INFO - 2018-04-14 00:07:08 --> Input Class Initialized
INFO - 2018-04-14 00:07:08 --> Language Class Initialized
INFO - 2018-04-14 00:07:08 --> Loader Class Initialized
INFO - 2018-04-14 00:07:08 --> Helper loaded: url_helper
INFO - 2018-04-14 00:07:08 --> Helper loaded: form_helper
INFO - 2018-04-14 00:07:08 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:07:08 --> User Agent Class Initialized
INFO - 2018-04-14 00:07:08 --> Controller Class Initialized
INFO - 2018-04-14 00:07:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:07:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:07:08 --> Pixel_Model class loaded
INFO - 2018-04-14 00:07:08 --> Database Driver Class Initialized
INFO - 2018-04-14 00:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:13:31 --> Config Class Initialized
INFO - 2018-04-14 00:13:31 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:13:31 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:13:31 --> Utf8 Class Initialized
INFO - 2018-04-14 00:13:31 --> URI Class Initialized
INFO - 2018-04-14 00:13:31 --> Router Class Initialized
INFO - 2018-04-14 00:13:31 --> Output Class Initialized
INFO - 2018-04-14 00:13:31 --> Security Class Initialized
DEBUG - 2018-04-14 00:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:13:31 --> CSRF cookie sent
INFO - 2018-04-14 00:13:31 --> Input Class Initialized
INFO - 2018-04-14 00:13:31 --> Language Class Initialized
INFO - 2018-04-14 00:13:31 --> Loader Class Initialized
INFO - 2018-04-14 00:13:31 --> Helper loaded: url_helper
INFO - 2018-04-14 00:13:31 --> Helper loaded: form_helper
INFO - 2018-04-14 00:13:31 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:13:31 --> User Agent Class Initialized
INFO - 2018-04-14 00:13:31 --> Controller Class Initialized
INFO - 2018-04-14 00:13:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:13:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:13:31 --> Pixel_Model class loaded
INFO - 2018-04-14 00:13:31 --> Database Driver Class Initialized
INFO - 2018-04-14 00:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 18
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 21
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 27
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 30
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 36
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 39
ERROR - 2018-04-14 00:13:34 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 45
INFO - 2018-04-14 00:13:34 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:13:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:13:35 --> Final output sent to browser
DEBUG - 2018-04-14 00:13:35 --> Total execution time: 3.4760
INFO - 2018-04-14 00:13:35 --> Config Class Initialized
INFO - 2018-04-14 00:13:35 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:13:35 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:13:35 --> Utf8 Class Initialized
INFO - 2018-04-14 00:13:35 --> URI Class Initialized
INFO - 2018-04-14 00:13:35 --> Router Class Initialized
INFO - 2018-04-14 00:13:35 --> Output Class Initialized
INFO - 2018-04-14 00:13:35 --> Security Class Initialized
DEBUG - 2018-04-14 00:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:13:35 --> CSRF cookie sent
INFO - 2018-04-14 00:13:35 --> Input Class Initialized
INFO - 2018-04-14 00:13:35 --> Language Class Initialized
ERROR - 2018-04-14 00:13:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:14:31 --> Config Class Initialized
INFO - 2018-04-14 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:14:31 --> Utf8 Class Initialized
INFO - 2018-04-14 00:14:31 --> URI Class Initialized
INFO - 2018-04-14 00:14:31 --> Router Class Initialized
INFO - 2018-04-14 00:14:31 --> Output Class Initialized
INFO - 2018-04-14 00:14:31 --> Security Class Initialized
DEBUG - 2018-04-14 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:14:31 --> CSRF cookie sent
INFO - 2018-04-14 00:14:31 --> Input Class Initialized
INFO - 2018-04-14 00:14:31 --> Language Class Initialized
INFO - 2018-04-14 00:14:31 --> Loader Class Initialized
INFO - 2018-04-14 00:14:31 --> Helper loaded: url_helper
INFO - 2018-04-14 00:14:31 --> Helper loaded: form_helper
INFO - 2018-04-14 00:14:31 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:14:32 --> User Agent Class Initialized
INFO - 2018-04-14 00:14:32 --> Controller Class Initialized
INFO - 2018-04-14 00:14:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:14:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:14:32 --> Pixel_Model class loaded
INFO - 2018-04-14 00:14:32 --> Database Driver Class Initialized
INFO - 2018-04-14 00:14:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:14:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:14:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:14:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Undefined index:  E:\www\yacopoo\application\views\questions\influencer_info.php 20
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 20
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:14:32 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:14:32 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:14:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:14:32 --> Final output sent to browser
DEBUG - 2018-04-14 00:14:32 --> Total execution time: 0.4616
INFO - 2018-04-14 00:14:32 --> Config Class Initialized
INFO - 2018-04-14 00:14:32 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:14:32 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:14:32 --> Utf8 Class Initialized
INFO - 2018-04-14 00:14:32 --> URI Class Initialized
INFO - 2018-04-14 00:14:32 --> Router Class Initialized
INFO - 2018-04-14 00:14:32 --> Output Class Initialized
INFO - 2018-04-14 00:14:32 --> Security Class Initialized
DEBUG - 2018-04-14 00:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:14:32 --> CSRF cookie sent
INFO - 2018-04-14 00:14:32 --> Input Class Initialized
INFO - 2018-04-14 00:14:32 --> Language Class Initialized
ERROR - 2018-04-14 00:14:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:05 --> Config Class Initialized
INFO - 2018-04-14 00:15:05 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:05 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:05 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:05 --> URI Class Initialized
INFO - 2018-04-14 00:15:05 --> Router Class Initialized
INFO - 2018-04-14 00:15:05 --> Output Class Initialized
INFO - 2018-04-14 00:15:05 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:05 --> CSRF cookie sent
INFO - 2018-04-14 00:15:05 --> Input Class Initialized
INFO - 2018-04-14 00:15:05 --> Language Class Initialized
INFO - 2018-04-14 00:15:05 --> Loader Class Initialized
INFO - 2018-04-14 00:15:05 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:05 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:05 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:05 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:05 --> Controller Class Initialized
INFO - 2018-04-14 00:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:05 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:05 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Undefined index:  E:\www\yacopoo\application\views\questions\influencer_info.php 20
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 20
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:15:08 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:08 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:09 --> Total execution time: 3.4423
INFO - 2018-04-14 00:15:09 --> Config Class Initialized
INFO - 2018-04-14 00:15:09 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:09 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:09 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:09 --> URI Class Initialized
INFO - 2018-04-14 00:15:09 --> Router Class Initialized
INFO - 2018-04-14 00:15:09 --> Output Class Initialized
INFO - 2018-04-14 00:15:09 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:09 --> CSRF cookie sent
INFO - 2018-04-14 00:15:09 --> Input Class Initialized
INFO - 2018-04-14 00:15:09 --> Language Class Initialized
ERROR - 2018-04-14 00:15:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:44 --> Config Class Initialized
INFO - 2018-04-14 00:15:44 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:44 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:44 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:44 --> URI Class Initialized
INFO - 2018-04-14 00:15:44 --> Router Class Initialized
INFO - 2018-04-14 00:15:44 --> Output Class Initialized
INFO - 2018-04-14 00:15:44 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:44 --> CSRF cookie sent
INFO - 2018-04-14 00:15:44 --> CSRF token verified
INFO - 2018-04-14 00:15:44 --> Input Class Initialized
INFO - 2018-04-14 00:15:44 --> Language Class Initialized
INFO - 2018-04-14 00:15:44 --> Loader Class Initialized
INFO - 2018-04-14 00:15:44 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:44 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:44 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:44 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:44 --> Controller Class Initialized
INFO - 2018-04-14 00:15:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:44 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:44 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:44 --> Form Validation Class Initialized
INFO - 2018-04-14 00:15:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-14 00:15:44 --> Config Class Initialized
INFO - 2018-04-14 00:15:44 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:44 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:44 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:44 --> URI Class Initialized
INFO - 2018-04-14 00:15:44 --> Router Class Initialized
INFO - 2018-04-14 00:15:44 --> Output Class Initialized
INFO - 2018-04-14 00:15:44 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:44 --> CSRF cookie sent
INFO - 2018-04-14 00:15:44 --> Input Class Initialized
INFO - 2018-04-14 00:15:44 --> Language Class Initialized
INFO - 2018-04-14 00:15:44 --> Loader Class Initialized
INFO - 2018-04-14 00:15:44 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:44 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:44 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:44 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:44 --> Controller Class Initialized
INFO - 2018-04-14 00:15:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:44 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:44 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:44 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:45 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:15:45 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:15:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:45 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:45 --> Total execution time: 0.5743
INFO - 2018-04-14 00:15:45 --> Config Class Initialized
INFO - 2018-04-14 00:15:45 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:45 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:45 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:45 --> URI Class Initialized
INFO - 2018-04-14 00:15:45 --> Router Class Initialized
INFO - 2018-04-14 00:15:45 --> Output Class Initialized
INFO - 2018-04-14 00:15:45 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:45 --> CSRF cookie sent
INFO - 2018-04-14 00:15:45 --> Input Class Initialized
INFO - 2018-04-14 00:15:45 --> Language Class Initialized
ERROR - 2018-04-14 00:15:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:47 --> Config Class Initialized
INFO - 2018-04-14 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:47 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:47 --> URI Class Initialized
INFO - 2018-04-14 00:15:47 --> Router Class Initialized
INFO - 2018-04-14 00:15:47 --> Output Class Initialized
INFO - 2018-04-14 00:15:47 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:47 --> CSRF cookie sent
INFO - 2018-04-14 00:15:47 --> CSRF token verified
INFO - 2018-04-14 00:15:47 --> Input Class Initialized
INFO - 2018-04-14 00:15:47 --> Language Class Initialized
INFO - 2018-04-14 00:15:47 --> Loader Class Initialized
INFO - 2018-04-14 00:15:47 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:47 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:47 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:47 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:47 --> Controller Class Initialized
INFO - 2018-04-14 00:15:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:48 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:48 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:48 --> Form Validation Class Initialized
INFO - 2018-04-14 00:15:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-14 00:15:48 --> Config Class Initialized
INFO - 2018-04-14 00:15:48 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:48 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:48 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:48 --> URI Class Initialized
INFO - 2018-04-14 00:15:48 --> Router Class Initialized
INFO - 2018-04-14 00:15:48 --> Output Class Initialized
INFO - 2018-04-14 00:15:48 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:48 --> CSRF cookie sent
INFO - 2018-04-14 00:15:48 --> Input Class Initialized
INFO - 2018-04-14 00:15:48 --> Language Class Initialized
INFO - 2018-04-14 00:15:48 --> Loader Class Initialized
INFO - 2018-04-14 00:15:48 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:48 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:48 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:48 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:48 --> Controller Class Initialized
INFO - 2018-04-14 00:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:48 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:48 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:48 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:15:48 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:15:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:48 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:48 --> Total execution time: 0.5840
INFO - 2018-04-14 00:15:49 --> Config Class Initialized
INFO - 2018-04-14 00:15:49 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:49 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:49 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:49 --> URI Class Initialized
INFO - 2018-04-14 00:15:49 --> Router Class Initialized
INFO - 2018-04-14 00:15:49 --> Output Class Initialized
INFO - 2018-04-14 00:15:49 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:49 --> CSRF cookie sent
INFO - 2018-04-14 00:15:49 --> Input Class Initialized
INFO - 2018-04-14 00:15:49 --> Language Class Initialized
ERROR - 2018-04-14 00:15:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:49 --> Config Class Initialized
INFO - 2018-04-14 00:15:49 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:49 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:49 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:49 --> URI Class Initialized
INFO - 2018-04-14 00:15:49 --> Router Class Initialized
INFO - 2018-04-14 00:15:49 --> Output Class Initialized
INFO - 2018-04-14 00:15:49 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:49 --> CSRF cookie sent
INFO - 2018-04-14 00:15:49 --> CSRF token verified
INFO - 2018-04-14 00:15:49 --> Input Class Initialized
INFO - 2018-04-14 00:15:49 --> Language Class Initialized
INFO - 2018-04-14 00:15:49 --> Loader Class Initialized
INFO - 2018-04-14 00:15:49 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:49 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:49 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:49 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:50 --> Controller Class Initialized
INFO - 2018-04-14 00:15:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:50 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:50 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:50 --> Form Validation Class Initialized
INFO - 2018-04-14 00:15:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-14 00:15:50 --> Config Class Initialized
INFO - 2018-04-14 00:15:50 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:50 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:50 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:50 --> URI Class Initialized
INFO - 2018-04-14 00:15:50 --> Router Class Initialized
INFO - 2018-04-14 00:15:50 --> Output Class Initialized
INFO - 2018-04-14 00:15:50 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:50 --> CSRF cookie sent
INFO - 2018-04-14 00:15:50 --> Input Class Initialized
INFO - 2018-04-14 00:15:50 --> Language Class Initialized
INFO - 2018-04-14 00:15:50 --> Loader Class Initialized
INFO - 2018-04-14 00:15:50 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:50 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:50 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:50 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:50 --> Controller Class Initialized
INFO - 2018-04-14 00:15:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:50 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:50 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:50 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:15:50 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:15:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:50 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:51 --> Total execution time: 0.7956
INFO - 2018-04-14 00:15:51 --> Config Class Initialized
INFO - 2018-04-14 00:15:51 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:51 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:51 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:51 --> URI Class Initialized
INFO - 2018-04-14 00:15:51 --> Router Class Initialized
INFO - 2018-04-14 00:15:51 --> Output Class Initialized
INFO - 2018-04-14 00:15:51 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:51 --> CSRF cookie sent
INFO - 2018-04-14 00:15:51 --> Input Class Initialized
INFO - 2018-04-14 00:15:51 --> Language Class Initialized
ERROR - 2018-04-14 00:15:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:51 --> Config Class Initialized
INFO - 2018-04-14 00:15:51 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:51 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:51 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:51 --> URI Class Initialized
INFO - 2018-04-14 00:15:51 --> Router Class Initialized
INFO - 2018-04-14 00:15:52 --> Output Class Initialized
INFO - 2018-04-14 00:15:52 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:52 --> CSRF cookie sent
INFO - 2018-04-14 00:15:52 --> Input Class Initialized
INFO - 2018-04-14 00:15:52 --> Language Class Initialized
INFO - 2018-04-14 00:15:52 --> Loader Class Initialized
INFO - 2018-04-14 00:15:52 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:52 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:52 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:52 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:52 --> Controller Class Initialized
INFO - 2018-04-14 00:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:52 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:52 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:15:52 --> File loaded: E:\www\yacopoo\application\views\questions/people_confide.php
INFO - 2018-04-14 00:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:52 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:52 --> Total execution time: 0.4532
INFO - 2018-04-14 00:15:52 --> Config Class Initialized
INFO - 2018-04-14 00:15:52 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:52 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:52 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:52 --> URI Class Initialized
INFO - 2018-04-14 00:15:52 --> Router Class Initialized
INFO - 2018-04-14 00:15:52 --> Output Class Initialized
INFO - 2018-04-14 00:15:52 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:52 --> CSRF cookie sent
INFO - 2018-04-14 00:15:53 --> Input Class Initialized
INFO - 2018-04-14 00:15:53 --> Language Class Initialized
ERROR - 2018-04-14 00:15:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:15:54 --> Config Class Initialized
INFO - 2018-04-14 00:15:54 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:54 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:54 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:54 --> URI Class Initialized
INFO - 2018-04-14 00:15:54 --> Router Class Initialized
INFO - 2018-04-14 00:15:54 --> Output Class Initialized
INFO - 2018-04-14 00:15:54 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:54 --> CSRF cookie sent
INFO - 2018-04-14 00:15:54 --> CSRF token verified
INFO - 2018-04-14 00:15:54 --> Input Class Initialized
INFO - 2018-04-14 00:15:54 --> Language Class Initialized
INFO - 2018-04-14 00:15:54 --> Loader Class Initialized
INFO - 2018-04-14 00:15:54 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:54 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:54 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:54 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:54 --> Controller Class Initialized
INFO - 2018-04-14 00:15:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:54 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:54 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:54 --> Form Validation Class Initialized
INFO - 2018-04-14 00:15:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-14 00:15:55 --> Config Class Initialized
INFO - 2018-04-14 00:15:55 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:55 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:55 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:55 --> URI Class Initialized
INFO - 2018-04-14 00:15:55 --> Router Class Initialized
INFO - 2018-04-14 00:15:55 --> Output Class Initialized
INFO - 2018-04-14 00:15:55 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:55 --> CSRF cookie sent
INFO - 2018-04-14 00:15:55 --> Input Class Initialized
INFO - 2018-04-14 00:15:55 --> Language Class Initialized
INFO - 2018-04-14 00:15:55 --> Loader Class Initialized
INFO - 2018-04-14 00:15:55 --> Helper loaded: url_helper
INFO - 2018-04-14 00:15:55 --> Helper loaded: form_helper
INFO - 2018-04-14 00:15:55 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:15:55 --> User Agent Class Initialized
INFO - 2018-04-14 00:15:55 --> Controller Class Initialized
INFO - 2018-04-14 00:15:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:15:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:15:55 --> Pixel_Model class loaded
INFO - 2018-04-14 00:15:55 --> Database Driver Class Initialized
INFO - 2018-04-14 00:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:15:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:15:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:15:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 23
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 29
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 32
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 38
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 41
ERROR - 2018-04-14 00:15:55 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 47
INFO - 2018-04-14 00:15:55 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:15:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:15:55 --> Final output sent to browser
DEBUG - 2018-04-14 00:15:55 --> Total execution time: 0.6466
INFO - 2018-04-14 00:15:56 --> Config Class Initialized
INFO - 2018-04-14 00:15:56 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:15:56 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:15:56 --> Utf8 Class Initialized
INFO - 2018-04-14 00:15:56 --> URI Class Initialized
INFO - 2018-04-14 00:15:56 --> Router Class Initialized
INFO - 2018-04-14 00:15:56 --> Output Class Initialized
INFO - 2018-04-14 00:15:56 --> Security Class Initialized
DEBUG - 2018-04-14 00:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:15:56 --> CSRF cookie sent
INFO - 2018-04-14 00:15:56 --> Input Class Initialized
INFO - 2018-04-14 00:15:56 --> Language Class Initialized
ERROR - 2018-04-14 00:15:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:16:31 --> Config Class Initialized
INFO - 2018-04-14 00:16:31 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:16:31 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:16:31 --> Utf8 Class Initialized
INFO - 2018-04-14 00:16:31 --> URI Class Initialized
INFO - 2018-04-14 00:16:31 --> Router Class Initialized
INFO - 2018-04-14 00:16:31 --> Output Class Initialized
INFO - 2018-04-14 00:16:31 --> Security Class Initialized
DEBUG - 2018-04-14 00:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:16:31 --> CSRF cookie sent
INFO - 2018-04-14 00:16:31 --> Input Class Initialized
INFO - 2018-04-14 00:16:31 --> Language Class Initialized
INFO - 2018-04-14 00:16:31 --> Loader Class Initialized
INFO - 2018-04-14 00:16:31 --> Helper loaded: url_helper
INFO - 2018-04-14 00:16:31 --> Helper loaded: form_helper
INFO - 2018-04-14 00:16:31 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:16:32 --> User Agent Class Initialized
INFO - 2018-04-14 00:16:32 --> Controller Class Initialized
INFO - 2018-04-14 00:16:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:16:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:16:32 --> Pixel_Model class loaded
INFO - 2018-04-14 00:16:32 --> Database Driver Class Initialized
INFO - 2018-04-14 00:16:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:16:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:16:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:16:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:17:05 --> Config Class Initialized
INFO - 2018-04-14 00:17:05 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:17:05 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:17:05 --> Utf8 Class Initialized
INFO - 2018-04-14 00:17:05 --> URI Class Initialized
INFO - 2018-04-14 00:17:05 --> Router Class Initialized
INFO - 2018-04-14 00:17:05 --> Output Class Initialized
INFO - 2018-04-14 00:17:05 --> Security Class Initialized
DEBUG - 2018-04-14 00:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:17:05 --> CSRF cookie sent
INFO - 2018-04-14 00:17:05 --> Input Class Initialized
INFO - 2018-04-14 00:17:05 --> Language Class Initialized
INFO - 2018-04-14 00:17:05 --> Loader Class Initialized
INFO - 2018-04-14 00:17:05 --> Helper loaded: url_helper
INFO - 2018-04-14 00:17:05 --> Helper loaded: form_helper
INFO - 2018-04-14 00:17:05 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:17:05 --> User Agent Class Initialized
INFO - 2018-04-14 00:17:05 --> Controller Class Initialized
INFO - 2018-04-14 00:17:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:17:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:17:05 --> Pixel_Model class loaded
INFO - 2018-04-14 00:17:05 --> Database Driver Class Initialized
INFO - 2018-04-14 00:17:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:17:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:17:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:17:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 30
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 39
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 42
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 48
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 30
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 39
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 42
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 48
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 30
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$when_ask_advice E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 39
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Undefined property: stdClass::$email E:\www\yacopoo\application\views\questions\influencer_info.php 42
ERROR - 2018-04-14 00:17:08 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\questions\influencer_info.php 48
INFO - 2018-04-14 00:17:08 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:17:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:17:08 --> Final output sent to browser
DEBUG - 2018-04-14 00:17:08 --> Total execution time: 3.5808
INFO - 2018-04-14 00:17:09 --> Config Class Initialized
INFO - 2018-04-14 00:17:09 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:17:09 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:17:09 --> Utf8 Class Initialized
INFO - 2018-04-14 00:17:09 --> URI Class Initialized
INFO - 2018-04-14 00:17:09 --> Router Class Initialized
INFO - 2018-04-14 00:17:09 --> Output Class Initialized
INFO - 2018-04-14 00:17:09 --> Security Class Initialized
DEBUG - 2018-04-14 00:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:17:09 --> CSRF cookie sent
INFO - 2018-04-14 00:17:09 --> Input Class Initialized
INFO - 2018-04-14 00:17:09 --> Language Class Initialized
ERROR - 2018-04-14 00:17:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:19:22 --> Config Class Initialized
INFO - 2018-04-14 00:19:22 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:19:22 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:19:22 --> Utf8 Class Initialized
INFO - 2018-04-14 00:19:22 --> URI Class Initialized
INFO - 2018-04-14 00:19:22 --> Router Class Initialized
INFO - 2018-04-14 00:19:22 --> Output Class Initialized
INFO - 2018-04-14 00:19:22 --> Security Class Initialized
DEBUG - 2018-04-14 00:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:19:22 --> CSRF cookie sent
INFO - 2018-04-14 00:19:22 --> Input Class Initialized
INFO - 2018-04-14 00:19:22 --> Language Class Initialized
INFO - 2018-04-14 00:19:22 --> Loader Class Initialized
INFO - 2018-04-14 00:19:22 --> Helper loaded: url_helper
INFO - 2018-04-14 00:19:22 --> Helper loaded: form_helper
INFO - 2018-04-14 00:19:22 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:19:22 --> User Agent Class Initialized
INFO - 2018-04-14 00:19:22 --> Controller Class Initialized
INFO - 2018-04-14 00:19:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:19:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:19:22 --> Pixel_Model class loaded
INFO - 2018-04-14 00:19:22 --> Database Driver Class Initialized
INFO - 2018-04-14 00:19:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:19:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:19:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:19:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-14 00:19:25 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:19:25 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:19:25 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 42
ERROR - 2018-04-14 00:19:25 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:19:25 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:19:26 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 42
ERROR - 2018-04-14 00:19:26 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 24
ERROR - 2018-04-14 00:19:26 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 33
ERROR - 2018-04-14 00:19:26 --> Severity: Notice --> Undefined variable: influencers E:\www\yacopoo\application\views\questions\influencer_info.php 42
INFO - 2018-04-14 00:19:26 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:19:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:19:26 --> Final output sent to browser
DEBUG - 2018-04-14 00:19:26 --> Total execution time: 3.4968
INFO - 2018-04-14 00:19:26 --> Config Class Initialized
INFO - 2018-04-14 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:19:26 --> Utf8 Class Initialized
INFO - 2018-04-14 00:19:26 --> URI Class Initialized
INFO - 2018-04-14 00:19:26 --> Router Class Initialized
INFO - 2018-04-14 00:19:26 --> Output Class Initialized
INFO - 2018-04-14 00:19:26 --> Security Class Initialized
DEBUG - 2018-04-14 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:19:26 --> CSRF cookie sent
INFO - 2018-04-14 00:19:26 --> Input Class Initialized
INFO - 2018-04-14 00:19:26 --> Language Class Initialized
ERROR - 2018-04-14 00:19:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:21:37 --> Config Class Initialized
INFO - 2018-04-14 00:21:37 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:21:37 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:21:37 --> Utf8 Class Initialized
INFO - 2018-04-14 00:21:38 --> URI Class Initialized
INFO - 2018-04-14 00:21:38 --> Router Class Initialized
INFO - 2018-04-14 00:21:38 --> Output Class Initialized
INFO - 2018-04-14 00:21:38 --> Security Class Initialized
DEBUG - 2018-04-14 00:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:21:38 --> CSRF cookie sent
INFO - 2018-04-14 00:21:38 --> Input Class Initialized
INFO - 2018-04-14 00:21:38 --> Language Class Initialized
INFO - 2018-04-14 00:21:38 --> Loader Class Initialized
INFO - 2018-04-14 00:21:38 --> Helper loaded: url_helper
INFO - 2018-04-14 00:21:38 --> Helper loaded: form_helper
INFO - 2018-04-14 00:21:38 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:21:38 --> User Agent Class Initialized
INFO - 2018-04-14 00:21:38 --> Controller Class Initialized
INFO - 2018-04-14 00:21:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:21:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:21:38 --> Pixel_Model class loaded
INFO - 2018-04-14 00:21:38 --> Database Driver Class Initialized
INFO - 2018-04-14 00:21:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:21:41 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:21:41 --> Final output sent to browser
DEBUG - 2018-04-14 00:21:41 --> Total execution time: 3.4475
INFO - 2018-04-14 00:21:41 --> Config Class Initialized
INFO - 2018-04-14 00:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:21:41 --> Utf8 Class Initialized
INFO - 2018-04-14 00:21:41 --> URI Class Initialized
INFO - 2018-04-14 00:21:41 --> Router Class Initialized
INFO - 2018-04-14 00:21:41 --> Output Class Initialized
INFO - 2018-04-14 00:21:41 --> Security Class Initialized
DEBUG - 2018-04-14 00:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:21:41 --> CSRF cookie sent
INFO - 2018-04-14 00:21:41 --> Input Class Initialized
INFO - 2018-04-14 00:21:41 --> Language Class Initialized
ERROR - 2018-04-14 00:21:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:22:57 --> Config Class Initialized
INFO - 2018-04-14 00:22:57 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:22:57 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:22:57 --> Utf8 Class Initialized
INFO - 2018-04-14 00:22:57 --> URI Class Initialized
INFO - 2018-04-14 00:22:57 --> Router Class Initialized
INFO - 2018-04-14 00:22:57 --> Output Class Initialized
INFO - 2018-04-14 00:22:57 --> Security Class Initialized
DEBUG - 2018-04-14 00:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:22:58 --> CSRF cookie sent
INFO - 2018-04-14 00:22:58 --> Input Class Initialized
INFO - 2018-04-14 00:22:58 --> Language Class Initialized
INFO - 2018-04-14 00:22:58 --> Loader Class Initialized
INFO - 2018-04-14 00:22:58 --> Helper loaded: url_helper
INFO - 2018-04-14 00:22:58 --> Helper loaded: form_helper
INFO - 2018-04-14 00:22:58 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:22:58 --> User Agent Class Initialized
INFO - 2018-04-14 00:22:58 --> Controller Class Initialized
INFO - 2018-04-14 00:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:22:58 --> Pixel_Model class loaded
INFO - 2018-04-14 00:22:58 --> Database Driver Class Initialized
INFO - 2018-04-14 00:23:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:23:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:23:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:23:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:23:01 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:23:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:23:01 --> Final output sent to browser
DEBUG - 2018-04-14 00:23:01 --> Total execution time: 3.4659
INFO - 2018-04-14 00:23:01 --> Config Class Initialized
INFO - 2018-04-14 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:23:01 --> Utf8 Class Initialized
INFO - 2018-04-14 00:23:01 --> URI Class Initialized
INFO - 2018-04-14 00:23:01 --> Router Class Initialized
INFO - 2018-04-14 00:23:01 --> Output Class Initialized
INFO - 2018-04-14 00:23:01 --> Security Class Initialized
DEBUG - 2018-04-14 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:23:01 --> CSRF cookie sent
INFO - 2018-04-14 00:23:01 --> Input Class Initialized
INFO - 2018-04-14 00:23:01 --> Language Class Initialized
ERROR - 2018-04-14 00:23:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:23:54 --> Config Class Initialized
INFO - 2018-04-14 00:23:54 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:23:54 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:23:54 --> Utf8 Class Initialized
INFO - 2018-04-14 00:23:54 --> URI Class Initialized
INFO - 2018-04-14 00:23:54 --> Router Class Initialized
INFO - 2018-04-14 00:23:54 --> Output Class Initialized
INFO - 2018-04-14 00:23:54 --> Security Class Initialized
DEBUG - 2018-04-14 00:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:23:54 --> CSRF cookie sent
INFO - 2018-04-14 00:23:54 --> Input Class Initialized
INFO - 2018-04-14 00:23:54 --> Language Class Initialized
INFO - 2018-04-14 00:23:55 --> Loader Class Initialized
INFO - 2018-04-14 00:23:55 --> Helper loaded: url_helper
INFO - 2018-04-14 00:23:55 --> Helper loaded: form_helper
INFO - 2018-04-14 00:23:55 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:23:55 --> User Agent Class Initialized
INFO - 2018-04-14 00:23:55 --> Controller Class Initialized
INFO - 2018-04-14 00:23:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:23:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:23:55 --> Pixel_Model class loaded
INFO - 2018-04-14 00:23:55 --> Database Driver Class Initialized
INFO - 2018-04-14 00:23:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:23:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:23:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:23:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:23:55 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:23:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:23:55 --> Final output sent to browser
DEBUG - 2018-04-14 00:23:55 --> Total execution time: 0.3803
INFO - 2018-04-14 00:23:55 --> Config Class Initialized
INFO - 2018-04-14 00:23:55 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:23:55 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:23:55 --> Utf8 Class Initialized
INFO - 2018-04-14 00:23:55 --> URI Class Initialized
INFO - 2018-04-14 00:23:55 --> Router Class Initialized
INFO - 2018-04-14 00:23:55 --> Output Class Initialized
INFO - 2018-04-14 00:23:55 --> Security Class Initialized
DEBUG - 2018-04-14 00:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:23:55 --> CSRF cookie sent
INFO - 2018-04-14 00:23:55 --> Input Class Initialized
INFO - 2018-04-14 00:23:55 --> Language Class Initialized
ERROR - 2018-04-14 00:23:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:24:35 --> Config Class Initialized
INFO - 2018-04-14 00:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:24:35 --> Utf8 Class Initialized
INFO - 2018-04-14 00:24:35 --> URI Class Initialized
INFO - 2018-04-14 00:24:35 --> Router Class Initialized
INFO - 2018-04-14 00:24:35 --> Output Class Initialized
INFO - 2018-04-14 00:24:35 --> Security Class Initialized
DEBUG - 2018-04-14 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:24:35 --> CSRF cookie sent
INFO - 2018-04-14 00:24:35 --> Input Class Initialized
INFO - 2018-04-14 00:24:35 --> Language Class Initialized
INFO - 2018-04-14 00:24:35 --> Loader Class Initialized
INFO - 2018-04-14 00:24:35 --> Helper loaded: url_helper
INFO - 2018-04-14 00:24:35 --> Helper loaded: form_helper
INFO - 2018-04-14 00:24:35 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:24:35 --> User Agent Class Initialized
INFO - 2018-04-14 00:24:35 --> Controller Class Initialized
INFO - 2018-04-14 00:24:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:24:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:24:35 --> Pixel_Model class loaded
INFO - 2018-04-14 00:24:35 --> Database Driver Class Initialized
INFO - 2018-04-14 00:24:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:24:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:24:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:24:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:24:35 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:24:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:24:35 --> Final output sent to browser
DEBUG - 2018-04-14 00:24:35 --> Total execution time: 0.4260
INFO - 2018-04-14 00:24:35 --> Config Class Initialized
INFO - 2018-04-14 00:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:24:35 --> Utf8 Class Initialized
INFO - 2018-04-14 00:24:35 --> URI Class Initialized
INFO - 2018-04-14 00:24:35 --> Router Class Initialized
INFO - 2018-04-14 00:24:35 --> Output Class Initialized
INFO - 2018-04-14 00:24:35 --> Security Class Initialized
DEBUG - 2018-04-14 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:24:35 --> CSRF cookie sent
INFO - 2018-04-14 00:24:35 --> Input Class Initialized
INFO - 2018-04-14 00:24:35 --> Language Class Initialized
ERROR - 2018-04-14 00:24:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:24:57 --> Config Class Initialized
INFO - 2018-04-14 00:24:57 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:24:57 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:24:57 --> Utf8 Class Initialized
INFO - 2018-04-14 00:24:57 --> URI Class Initialized
INFO - 2018-04-14 00:24:57 --> Router Class Initialized
INFO - 2018-04-14 00:24:57 --> Output Class Initialized
INFO - 2018-04-14 00:24:57 --> Security Class Initialized
DEBUG - 2018-04-14 00:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:24:57 --> CSRF cookie sent
INFO - 2018-04-14 00:24:57 --> Input Class Initialized
INFO - 2018-04-14 00:24:57 --> Language Class Initialized
INFO - 2018-04-14 00:24:57 --> Loader Class Initialized
INFO - 2018-04-14 00:24:57 --> Helper loaded: url_helper
INFO - 2018-04-14 00:24:57 --> Helper loaded: form_helper
INFO - 2018-04-14 00:24:57 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:24:57 --> User Agent Class Initialized
INFO - 2018-04-14 00:24:57 --> Controller Class Initialized
INFO - 2018-04-14 00:24:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:24:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:24:57 --> Pixel_Model class loaded
INFO - 2018-04-14 00:24:57 --> Database Driver Class Initialized
INFO - 2018-04-14 00:25:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:25:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:25:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:25:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:25:00 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:25:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:25:00 --> Final output sent to browser
DEBUG - 2018-04-14 00:25:00 --> Total execution time: 3.4198
INFO - 2018-04-14 00:25:01 --> Config Class Initialized
INFO - 2018-04-14 00:25:01 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:25:01 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:25:01 --> Utf8 Class Initialized
INFO - 2018-04-14 00:25:01 --> URI Class Initialized
INFO - 2018-04-14 00:25:01 --> Router Class Initialized
INFO - 2018-04-14 00:25:01 --> Output Class Initialized
INFO - 2018-04-14 00:25:01 --> Security Class Initialized
DEBUG - 2018-04-14 00:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:25:01 --> CSRF cookie sent
INFO - 2018-04-14 00:25:01 --> Input Class Initialized
INFO - 2018-04-14 00:25:01 --> Language Class Initialized
ERROR - 2018-04-14 00:25:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:25:25 --> Config Class Initialized
INFO - 2018-04-14 00:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:25:25 --> Utf8 Class Initialized
INFO - 2018-04-14 00:25:25 --> URI Class Initialized
INFO - 2018-04-14 00:25:25 --> Router Class Initialized
INFO - 2018-04-14 00:25:25 --> Output Class Initialized
INFO - 2018-04-14 00:25:25 --> Security Class Initialized
DEBUG - 2018-04-14 00:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:25:25 --> CSRF cookie sent
INFO - 2018-04-14 00:25:25 --> Input Class Initialized
INFO - 2018-04-14 00:25:25 --> Language Class Initialized
INFO - 2018-04-14 00:25:25 --> Loader Class Initialized
INFO - 2018-04-14 00:25:25 --> Helper loaded: url_helper
INFO - 2018-04-14 00:25:25 --> Helper loaded: form_helper
INFO - 2018-04-14 00:25:25 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:25:25 --> User Agent Class Initialized
INFO - 2018-04-14 00:25:25 --> Controller Class Initialized
INFO - 2018-04-14 00:25:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:25:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:25:25 --> Pixel_Model class loaded
INFO - 2018-04-14 00:25:25 --> Database Driver Class Initialized
INFO - 2018-04-14 00:25:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:25:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:25:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:25:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:25:25 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:25:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:25:25 --> Final output sent to browser
DEBUG - 2018-04-14 00:25:25 --> Total execution time: 0.4260
INFO - 2018-04-14 00:25:26 --> Config Class Initialized
INFO - 2018-04-14 00:25:26 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:25:26 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:25:26 --> Utf8 Class Initialized
INFO - 2018-04-14 00:25:26 --> URI Class Initialized
INFO - 2018-04-14 00:25:26 --> Router Class Initialized
INFO - 2018-04-14 00:25:26 --> Output Class Initialized
INFO - 2018-04-14 00:25:26 --> Security Class Initialized
DEBUG - 2018-04-14 00:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:25:26 --> CSRF cookie sent
INFO - 2018-04-14 00:25:26 --> Input Class Initialized
INFO - 2018-04-14 00:25:26 --> Language Class Initialized
ERROR - 2018-04-14 00:25:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-14 00:25:42 --> Config Class Initialized
INFO - 2018-04-14 00:25:42 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:25:42 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:25:42 --> Utf8 Class Initialized
INFO - 2018-04-14 00:25:42 --> URI Class Initialized
INFO - 2018-04-14 00:25:42 --> Router Class Initialized
INFO - 2018-04-14 00:25:42 --> Output Class Initialized
INFO - 2018-04-14 00:25:42 --> Security Class Initialized
DEBUG - 2018-04-14 00:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:25:42 --> CSRF cookie sent
INFO - 2018-04-14 00:25:42 --> Input Class Initialized
INFO - 2018-04-14 00:25:42 --> Language Class Initialized
INFO - 2018-04-14 00:25:42 --> Loader Class Initialized
INFO - 2018-04-14 00:25:42 --> Helper loaded: url_helper
INFO - 2018-04-14 00:25:42 --> Helper loaded: form_helper
INFO - 2018-04-14 00:25:42 --> Helper loaded: language_helper
DEBUG - 2018-04-14 00:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 00:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 00:25:42 --> User Agent Class Initialized
INFO - 2018-04-14 00:25:42 --> Controller Class Initialized
INFO - 2018-04-14 00:25:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-14 00:25:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-14 00:25:42 --> Pixel_Model class loaded
INFO - 2018-04-14 00:25:42 --> Database Driver Class Initialized
INFO - 2018-04-14 00:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-14 00:25:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-14 00:25:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-14 00:25:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-14 00:25:42 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-14 00:25:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-14 00:25:42 --> Final output sent to browser
DEBUG - 2018-04-14 00:25:42 --> Total execution time: 0.4865
INFO - 2018-04-14 00:25:43 --> Config Class Initialized
INFO - 2018-04-14 00:25:43 --> Hooks Class Initialized
DEBUG - 2018-04-14 00:25:43 --> UTF-8 Support Enabled
INFO - 2018-04-14 00:25:43 --> Utf8 Class Initialized
INFO - 2018-04-14 00:25:43 --> URI Class Initialized
INFO - 2018-04-14 00:25:43 --> Router Class Initialized
INFO - 2018-04-14 00:25:43 --> Output Class Initialized
INFO - 2018-04-14 00:25:43 --> Security Class Initialized
DEBUG - 2018-04-14 00:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 00:25:43 --> CSRF cookie sent
INFO - 2018-04-14 00:25:43 --> Input Class Initialized
INFO - 2018-04-14 00:25:43 --> Language Class Initialized
ERROR - 2018-04-14 00:25:43 --> 404 Page Not Found: Assets/css

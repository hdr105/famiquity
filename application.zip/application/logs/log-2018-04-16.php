<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-16 15:59:14 --> Config Class Initialized
INFO - 2018-04-16 15:59:14 --> Hooks Class Initialized
DEBUG - 2018-04-16 15:59:15 --> UTF-8 Support Enabled
INFO - 2018-04-16 15:59:15 --> Utf8 Class Initialized
INFO - 2018-04-16 15:59:15 --> URI Class Initialized
INFO - 2018-04-16 15:59:15 --> Router Class Initialized
INFO - 2018-04-16 15:59:16 --> Output Class Initialized
INFO - 2018-04-16 15:59:16 --> Security Class Initialized
DEBUG - 2018-04-16 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 15:59:16 --> CSRF cookie sent
INFO - 2018-04-16 15:59:16 --> Input Class Initialized
INFO - 2018-04-16 15:59:16 --> Language Class Initialized
INFO - 2018-04-16 15:59:17 --> Loader Class Initialized
INFO - 2018-04-16 15:59:17 --> Helper loaded: url_helper
INFO - 2018-04-16 15:59:17 --> Helper loaded: form_helper
INFO - 2018-04-16 15:59:17 --> Helper loaded: language_helper
DEBUG - 2018-04-16 15:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 15:59:17 --> User Agent Class Initialized
INFO - 2018-04-16 15:59:17 --> Controller Class Initialized
INFO - 2018-04-16 15:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 15:59:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 15:59:18 --> Pixel_Model class loaded
INFO - 2018-04-16 15:59:20 --> Database Driver Class Initialized
INFO - 2018-04-16 15:59:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-16 15:59:24 --> Config Class Initialized
INFO - 2018-04-16 15:59:24 --> Hooks Class Initialized
DEBUG - 2018-04-16 15:59:24 --> UTF-8 Support Enabled
INFO - 2018-04-16 15:59:24 --> Utf8 Class Initialized
INFO - 2018-04-16 15:59:24 --> URI Class Initialized
DEBUG - 2018-04-16 15:59:25 --> No URI present. Default controller set.
INFO - 2018-04-16 15:59:26 --> Router Class Initialized
INFO - 2018-04-16 15:59:26 --> Output Class Initialized
INFO - 2018-04-16 15:59:28 --> Security Class Initialized
DEBUG - 2018-04-16 15:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 15:59:29 --> CSRF cookie sent
INFO - 2018-04-16 15:59:30 --> Input Class Initialized
INFO - 2018-04-16 15:59:30 --> Language Class Initialized
INFO - 2018-04-16 15:59:30 --> Loader Class Initialized
INFO - 2018-04-16 15:59:31 --> Helper loaded: url_helper
INFO - 2018-04-16 15:59:31 --> Helper loaded: form_helper
INFO - 2018-04-16 15:59:31 --> Helper loaded: language_helper
DEBUG - 2018-04-16 15:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 15:59:32 --> User Agent Class Initialized
INFO - 2018-04-16 15:59:32 --> Controller Class Initialized
INFO - 2018-04-16 15:59:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 15:59:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 15:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 15:59:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 15:59:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 15:59:38 --> Final output sent to browser
DEBUG - 2018-04-16 15:59:39 --> Total execution time: 14.2012
INFO - 2018-04-16 16:07:37 --> Config Class Initialized
INFO - 2018-04-16 16:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-16 16:07:37 --> UTF-8 Support Enabled
INFO - 2018-04-16 16:07:37 --> Utf8 Class Initialized
INFO - 2018-04-16 16:07:37 --> URI Class Initialized
INFO - 2018-04-16 16:07:37 --> Router Class Initialized
INFO - 2018-04-16 16:07:37 --> Output Class Initialized
INFO - 2018-04-16 16:07:37 --> Security Class Initialized
DEBUG - 2018-04-16 16:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 16:07:37 --> CSRF cookie sent
INFO - 2018-04-16 16:07:37 --> Input Class Initialized
INFO - 2018-04-16 16:07:37 --> Language Class Initialized
ERROR - 2018-04-16 16:07:37 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 19:20:26 --> Config Class Initialized
INFO - 2018-04-16 19:20:26 --> Hooks Class Initialized
DEBUG - 2018-04-16 19:20:26 --> UTF-8 Support Enabled
INFO - 2018-04-16 19:20:26 --> Utf8 Class Initialized
INFO - 2018-04-16 19:20:26 --> URI Class Initialized
DEBUG - 2018-04-16 19:20:26 --> No URI present. Default controller set.
INFO - 2018-04-16 19:20:26 --> Router Class Initialized
INFO - 2018-04-16 19:20:26 --> Output Class Initialized
INFO - 2018-04-16 19:20:26 --> Security Class Initialized
DEBUG - 2018-04-16 19:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 19:20:26 --> CSRF cookie sent
INFO - 2018-04-16 19:20:26 --> Input Class Initialized
INFO - 2018-04-16 19:20:26 --> Language Class Initialized
INFO - 2018-04-16 19:20:26 --> Loader Class Initialized
INFO - 2018-04-16 19:20:26 --> Helper loaded: url_helper
INFO - 2018-04-16 19:20:26 --> Helper loaded: form_helper
INFO - 2018-04-16 19:20:26 --> Helper loaded: language_helper
DEBUG - 2018-04-16 19:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 19:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 19:20:26 --> User Agent Class Initialized
INFO - 2018-04-16 19:20:26 --> Controller Class Initialized
INFO - 2018-04-16 19:20:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 19:20:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 19:20:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 19:20:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 19:20:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 19:20:26 --> Final output sent to browser
DEBUG - 2018-04-16 19:20:26 --> Total execution time: 0.4806
INFO - 2018-04-16 19:20:28 --> Config Class Initialized
INFO - 2018-04-16 19:20:28 --> Hooks Class Initialized
DEBUG - 2018-04-16 19:20:28 --> UTF-8 Support Enabled
INFO - 2018-04-16 19:20:28 --> Utf8 Class Initialized
INFO - 2018-04-16 19:20:28 --> URI Class Initialized
INFO - 2018-04-16 19:20:28 --> Router Class Initialized
INFO - 2018-04-16 19:20:28 --> Output Class Initialized
INFO - 2018-04-16 19:20:28 --> Security Class Initialized
DEBUG - 2018-04-16 19:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 19:20:28 --> CSRF cookie sent
INFO - 2018-04-16 19:20:28 --> Input Class Initialized
INFO - 2018-04-16 19:20:28 --> Language Class Initialized
ERROR - 2018-04-16 19:20:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 19:21:08 --> Config Class Initialized
INFO - 2018-04-16 19:21:08 --> Hooks Class Initialized
DEBUG - 2018-04-16 19:21:08 --> UTF-8 Support Enabled
INFO - 2018-04-16 19:21:08 --> Utf8 Class Initialized
INFO - 2018-04-16 19:21:08 --> URI Class Initialized
INFO - 2018-04-16 19:21:08 --> Router Class Initialized
INFO - 2018-04-16 19:21:08 --> Output Class Initialized
INFO - 2018-04-16 19:21:08 --> Security Class Initialized
DEBUG - 2018-04-16 19:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 19:21:08 --> CSRF cookie sent
INFO - 2018-04-16 19:21:08 --> Input Class Initialized
INFO - 2018-04-16 19:21:08 --> Language Class Initialized
INFO - 2018-04-16 19:21:08 --> Loader Class Initialized
INFO - 2018-04-16 19:21:08 --> Helper loaded: url_helper
INFO - 2018-04-16 19:21:08 --> Helper loaded: form_helper
INFO - 2018-04-16 19:21:08 --> Helper loaded: language_helper
DEBUG - 2018-04-16 19:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 19:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 19:21:08 --> User Agent Class Initialized
INFO - 2018-04-16 19:21:08 --> Controller Class Initialized
INFO - 2018-04-16 19:21:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 19:21:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 19:21:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 19:21:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 19:21:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 19:21:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 19:21:08 --> Could not find the language line "req_email"
INFO - 2018-04-16 19:21:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 19:21:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 19:21:08 --> Final output sent to browser
DEBUG - 2018-04-16 19:21:08 --> Total execution time: 0.5649
INFO - 2018-04-16 21:43:20 --> Config Class Initialized
INFO - 2018-04-16 21:43:20 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:20 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:20 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:20 --> URI Class Initialized
INFO - 2018-04-16 21:43:20 --> Router Class Initialized
INFO - 2018-04-16 21:43:20 --> Output Class Initialized
INFO - 2018-04-16 21:43:20 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:20 --> CSRF cookie sent
INFO - 2018-04-16 21:43:27 --> Config Class Initialized
INFO - 2018-04-16 21:43:27 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:27 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:27 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:27 --> URI Class Initialized
INFO - 2018-04-16 21:43:27 --> Router Class Initialized
INFO - 2018-04-16 21:43:27 --> Output Class Initialized
INFO - 2018-04-16 21:43:27 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:27 --> CSRF cookie sent
INFO - 2018-04-16 21:43:29 --> Config Class Initialized
INFO - 2018-04-16 21:43:29 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:29 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:29 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:29 --> URI Class Initialized
INFO - 2018-04-16 21:43:29 --> Router Class Initialized
INFO - 2018-04-16 21:43:29 --> Output Class Initialized
INFO - 2018-04-16 21:43:29 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:29 --> CSRF cookie sent
INFO - 2018-04-16 21:43:29 --> Input Class Initialized
INFO - 2018-04-16 21:43:29 --> Language Class Initialized
INFO - 2018-04-16 21:43:29 --> Loader Class Initialized
INFO - 2018-04-16 21:43:29 --> Helper loaded: url_helper
INFO - 2018-04-16 21:43:29 --> Helper loaded: form_helper
INFO - 2018-04-16 21:43:29 --> Helper loaded: language_helper
DEBUG - 2018-04-16 21:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 21:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 21:43:29 --> User Agent Class Initialized
INFO - 2018-04-16 21:43:29 --> Controller Class Initialized
INFO - 2018-04-16 21:43:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 21:43:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 21:43:29 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 21:43:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 21:43:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 21:43:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 21:43:29 --> Could not find the language line "req_email"
INFO - 2018-04-16 21:43:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 21:43:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 21:43:29 --> Final output sent to browser
DEBUG - 2018-04-16 21:43:29 --> Total execution time: 0.3838
INFO - 2018-04-16 21:43:35 --> Config Class Initialized
INFO - 2018-04-16 21:43:35 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:35 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:35 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:35 --> URI Class Initialized
INFO - 2018-04-16 21:43:35 --> Router Class Initialized
INFO - 2018-04-16 21:43:35 --> Output Class Initialized
INFO - 2018-04-16 21:43:35 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:35 --> CSRF cookie sent
INFO - 2018-04-16 21:43:35 --> CSRF token verified
INFO - 2018-04-16 21:43:35 --> Input Class Initialized
INFO - 2018-04-16 21:43:35 --> Language Class Initialized
INFO - 2018-04-16 21:43:35 --> Loader Class Initialized
INFO - 2018-04-16 21:43:35 --> Helper loaded: url_helper
INFO - 2018-04-16 21:43:35 --> Helper loaded: form_helper
INFO - 2018-04-16 21:43:35 --> Helper loaded: language_helper
DEBUG - 2018-04-16 21:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 21:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 21:43:35 --> User Agent Class Initialized
INFO - 2018-04-16 21:43:35 --> Controller Class Initialized
INFO - 2018-04-16 21:43:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 21:43:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 21:43:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 21:43:36 --> Form Validation Class Initialized
INFO - 2018-04-16 21:43:36 --> Pixel_Model class loaded
INFO - 2018-04-16 21:43:36 --> Database Driver Class Initialized
INFO - 2018-04-16 21:43:39 --> Model "AuthenticationModel" initialized
INFO - 2018-04-16 21:43:40 --> Config Class Initialized
INFO - 2018-04-16 21:43:40 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:40 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:40 --> URI Class Initialized
DEBUG - 2018-04-16 21:43:40 --> No URI present. Default controller set.
INFO - 2018-04-16 21:43:40 --> Router Class Initialized
INFO - 2018-04-16 21:43:40 --> Output Class Initialized
INFO - 2018-04-16 21:43:40 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:40 --> CSRF cookie sent
INFO - 2018-04-16 21:43:40 --> Input Class Initialized
INFO - 2018-04-16 21:43:40 --> Language Class Initialized
INFO - 2018-04-16 21:43:40 --> Loader Class Initialized
INFO - 2018-04-16 21:43:40 --> Helper loaded: url_helper
INFO - 2018-04-16 21:43:40 --> Helper loaded: form_helper
INFO - 2018-04-16 21:43:40 --> Helper loaded: language_helper
DEBUG - 2018-04-16 21:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 21:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 21:43:40 --> User Agent Class Initialized
INFO - 2018-04-16 21:43:40 --> Controller Class Initialized
INFO - 2018-04-16 21:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 21:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 21:43:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 21:43:40 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 21:43:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 21:43:40 --> Final output sent to browser
DEBUG - 2018-04-16 21:43:40 --> Total execution time: 0.3352
INFO - 2018-04-16 21:43:41 --> Config Class Initialized
INFO - 2018-04-16 21:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:41 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:41 --> URI Class Initialized
INFO - 2018-04-16 21:43:41 --> Router Class Initialized
INFO - 2018-04-16 21:43:41 --> Output Class Initialized
INFO - 2018-04-16 21:43:41 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:41 --> CSRF cookie sent
INFO - 2018-04-16 21:43:41 --> Input Class Initialized
INFO - 2018-04-16 21:43:41 --> Language Class Initialized
ERROR - 2018-04-16 21:43:41 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 21:43:53 --> Config Class Initialized
INFO - 2018-04-16 21:43:53 --> Hooks Class Initialized
DEBUG - 2018-04-16 21:43:53 --> UTF-8 Support Enabled
INFO - 2018-04-16 21:43:53 --> Utf8 Class Initialized
INFO - 2018-04-16 21:43:53 --> URI Class Initialized
INFO - 2018-04-16 21:43:53 --> Router Class Initialized
INFO - 2018-04-16 21:43:53 --> Output Class Initialized
INFO - 2018-04-16 21:43:53 --> Security Class Initialized
DEBUG - 2018-04-16 21:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 21:43:53 --> CSRF cookie sent
INFO - 2018-04-16 21:43:53 --> Input Class Initialized
INFO - 2018-04-16 21:43:53 --> Language Class Initialized
INFO - 2018-04-16 21:43:53 --> Loader Class Initialized
INFO - 2018-04-16 21:43:53 --> Helper loaded: url_helper
INFO - 2018-04-16 21:43:53 --> Helper loaded: form_helper
INFO - 2018-04-16 21:43:53 --> Helper loaded: language_helper
DEBUG - 2018-04-16 21:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 21:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 21:43:53 --> User Agent Class Initialized
INFO - 2018-04-16 21:43:53 --> Controller Class Initialized
INFO - 2018-04-16 21:43:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 21:43:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 21:43:53 --> Pixel_Model class loaded
INFO - 2018-04-16 21:43:53 --> Database Driver Class Initialized
INFO - 2018-04-16 21:43:53 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 21:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 21:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 21:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 21:43:53 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 21:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 21:43:53 --> Final output sent to browser
DEBUG - 2018-04-16 21:43:53 --> Total execution time: 0.5363
INFO - 2018-04-16 22:01:04 --> Config Class Initialized
INFO - 2018-04-16 22:01:04 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:01:04 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:01:04 --> Utf8 Class Initialized
INFO - 2018-04-16 22:01:04 --> URI Class Initialized
INFO - 2018-04-16 22:01:04 --> Router Class Initialized
INFO - 2018-04-16 22:01:04 --> Output Class Initialized
INFO - 2018-04-16 22:01:04 --> Security Class Initialized
DEBUG - 2018-04-16 22:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:01:04 --> CSRF cookie sent
INFO - 2018-04-16 22:01:04 --> Input Class Initialized
INFO - 2018-04-16 22:01:04 --> Language Class Initialized
INFO - 2018-04-16 22:01:04 --> Loader Class Initialized
INFO - 2018-04-16 22:01:04 --> Helper loaded: url_helper
INFO - 2018-04-16 22:01:04 --> Helper loaded: form_helper
INFO - 2018-04-16 22:01:04 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:01:04 --> User Agent Class Initialized
INFO - 2018-04-16 22:01:04 --> Controller Class Initialized
INFO - 2018-04-16 22:01:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:01:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:01:04 --> Pixel_Model class loaded
INFO - 2018-04-16 22:01:04 --> Database Driver Class Initialized
INFO - 2018-04-16 22:01:07 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:01:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:01:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:01:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:01:07 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:01:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:01:07 --> Final output sent to browser
DEBUG - 2018-04-16 22:01:07 --> Total execution time: 3.4089
INFO - 2018-04-16 22:01:44 --> Config Class Initialized
INFO - 2018-04-16 22:01:44 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:01:44 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:01:44 --> Utf8 Class Initialized
INFO - 2018-04-16 22:01:44 --> URI Class Initialized
INFO - 2018-04-16 22:01:44 --> Router Class Initialized
INFO - 2018-04-16 22:01:44 --> Output Class Initialized
INFO - 2018-04-16 22:01:44 --> Security Class Initialized
DEBUG - 2018-04-16 22:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:01:44 --> CSRF cookie sent
INFO - 2018-04-16 22:01:44 --> CSRF token verified
INFO - 2018-04-16 22:01:44 --> Input Class Initialized
INFO - 2018-04-16 22:01:44 --> Language Class Initialized
INFO - 2018-04-16 22:01:44 --> Loader Class Initialized
INFO - 2018-04-16 22:01:44 --> Helper loaded: url_helper
INFO - 2018-04-16 22:01:44 --> Helper loaded: form_helper
INFO - 2018-04-16 22:01:44 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:01:44 --> User Agent Class Initialized
INFO - 2018-04-16 22:01:44 --> Controller Class Initialized
INFO - 2018-04-16 22:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:01:44 --> Upload Class Initialized
INFO - 2018-04-16 22:01:45 --> Pixel_Model class loaded
INFO - 2018-04-16 22:01:45 --> Database Driver Class Initialized
INFO - 2018-04-16 22:01:45 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:01:45 --> Database Driver Class Initialized
INFO - 2018-04-16 22:01:45 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:01:45 --> Helper loaded: string_helper
INFO - 2018-04-16 22:01:45 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-16 22:01:45 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:01:45 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:01:45 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:01:45 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-16 22:01:45 --> Email Class Initialized
DEBUG - 2018-04-16 22:01:46 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:01:46 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:01:46 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:01:46 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:01:46 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-16 22:01:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:01:46 --> Config Class Initialized
INFO - 2018-04-16 22:01:46 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:01:46 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:01:46 --> Utf8 Class Initialized
INFO - 2018-04-16 22:01:46 --> URI Class Initialized
INFO - 2018-04-16 22:01:46 --> Router Class Initialized
INFO - 2018-04-16 22:01:46 --> Output Class Initialized
INFO - 2018-04-16 22:01:46 --> Security Class Initialized
DEBUG - 2018-04-16 22:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:01:46 --> CSRF cookie sent
INFO - 2018-04-16 22:01:46 --> Input Class Initialized
INFO - 2018-04-16 22:01:46 --> Language Class Initialized
ERROR - 2018-04-16 22:01:46 --> 404 Page Not Found: Assets/images
INFO - 2018-04-16 22:04:02 --> Config Class Initialized
INFO - 2018-04-16 22:04:02 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:04:02 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:04:02 --> Utf8 Class Initialized
INFO - 2018-04-16 22:04:02 --> URI Class Initialized
DEBUG - 2018-04-16 22:04:02 --> No URI present. Default controller set.
INFO - 2018-04-16 22:04:02 --> Router Class Initialized
INFO - 2018-04-16 22:04:02 --> Output Class Initialized
INFO - 2018-04-16 22:04:02 --> Security Class Initialized
DEBUG - 2018-04-16 22:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:04:03 --> CSRF cookie sent
INFO - 2018-04-16 22:04:03 --> Input Class Initialized
INFO - 2018-04-16 22:04:03 --> Language Class Initialized
INFO - 2018-04-16 22:04:03 --> Loader Class Initialized
INFO - 2018-04-16 22:04:03 --> Helper loaded: url_helper
INFO - 2018-04-16 22:04:03 --> Helper loaded: form_helper
INFO - 2018-04-16 22:04:03 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:04:03 --> User Agent Class Initialized
INFO - 2018-04-16 22:04:03 --> Controller Class Initialized
INFO - 2018-04-16 22:04:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:04:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:04:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:04:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:04:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:04:03 --> Final output sent to browser
DEBUG - 2018-04-16 22:04:03 --> Total execution time: 0.4777
INFO - 2018-04-16 22:04:05 --> Config Class Initialized
INFO - 2018-04-16 22:04:05 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:04:05 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:04:05 --> Utf8 Class Initialized
INFO - 2018-04-16 22:04:05 --> URI Class Initialized
INFO - 2018-04-16 22:04:05 --> Router Class Initialized
INFO - 2018-04-16 22:04:05 --> Output Class Initialized
INFO - 2018-04-16 22:04:05 --> Security Class Initialized
DEBUG - 2018-04-16 22:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:04:05 --> CSRF cookie sent
INFO - 2018-04-16 22:04:05 --> Input Class Initialized
INFO - 2018-04-16 22:04:05 --> Language Class Initialized
ERROR - 2018-04-16 22:04:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:04:10 --> Config Class Initialized
INFO - 2018-04-16 22:04:10 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:04:10 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:04:10 --> Utf8 Class Initialized
INFO - 2018-04-16 22:04:10 --> URI Class Initialized
INFO - 2018-04-16 22:04:10 --> Router Class Initialized
INFO - 2018-04-16 22:04:10 --> Output Class Initialized
INFO - 2018-04-16 22:04:10 --> Security Class Initialized
DEBUG - 2018-04-16 22:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:04:10 --> CSRF cookie sent
INFO - 2018-04-16 22:04:10 --> Input Class Initialized
INFO - 2018-04-16 22:04:10 --> Language Class Initialized
ERROR - 2018-04-16 22:04:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:05:09 --> Config Class Initialized
INFO - 2018-04-16 22:05:09 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:05:09 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:05:09 --> Utf8 Class Initialized
INFO - 2018-04-16 22:05:09 --> URI Class Initialized
INFO - 2018-04-16 22:05:09 --> Router Class Initialized
INFO - 2018-04-16 22:05:09 --> Output Class Initialized
INFO - 2018-04-16 22:05:09 --> Security Class Initialized
DEBUG - 2018-04-16 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:05:09 --> CSRF cookie sent
INFO - 2018-04-16 22:05:09 --> CSRF token verified
INFO - 2018-04-16 22:05:09 --> Input Class Initialized
INFO - 2018-04-16 22:05:09 --> Language Class Initialized
INFO - 2018-04-16 22:05:09 --> Loader Class Initialized
INFO - 2018-04-16 22:05:09 --> Helper loaded: url_helper
INFO - 2018-04-16 22:05:09 --> Helper loaded: form_helper
INFO - 2018-04-16 22:05:09 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:05:10 --> User Agent Class Initialized
INFO - 2018-04-16 22:05:10 --> Controller Class Initialized
INFO - 2018-04-16 22:05:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:05:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:05:10 --> Upload Class Initialized
INFO - 2018-04-16 22:05:10 --> Pixel_Model class loaded
INFO - 2018-04-16 22:05:10 --> Database Driver Class Initialized
INFO - 2018-04-16 22:05:13 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:05:13 --> Database Driver Class Initialized
INFO - 2018-04-16 22:05:13 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:05:13 --> Helper loaded: string_helper
INFO - 2018-04-16 22:05:13 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-16 22:05:13 --> Email Class Initialized
DEBUG - 2018-04-16 22:05:13 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:05:13 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-16 22:05:14 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:05:14 --> Config Class Initialized
INFO - 2018-04-16 22:05:14 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:05:14 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:05:14 --> Utf8 Class Initialized
INFO - 2018-04-16 22:05:14 --> URI Class Initialized
INFO - 2018-04-16 22:05:14 --> Router Class Initialized
INFO - 2018-04-16 22:05:14 --> Output Class Initialized
INFO - 2018-04-16 22:05:14 --> Security Class Initialized
DEBUG - 2018-04-16 22:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:05:14 --> CSRF cookie sent
INFO - 2018-04-16 22:05:14 --> Input Class Initialized
INFO - 2018-04-16 22:05:14 --> Language Class Initialized
ERROR - 2018-04-16 22:05:14 --> 404 Page Not Found: Assets/images
INFO - 2018-04-16 22:06:19 --> Config Class Initialized
INFO - 2018-04-16 22:06:19 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:19 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:19 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:19 --> URI Class Initialized
INFO - 2018-04-16 22:06:19 --> Router Class Initialized
INFO - 2018-04-16 22:06:19 --> Output Class Initialized
INFO - 2018-04-16 22:06:19 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:19 --> CSRF cookie sent
INFO - 2018-04-16 22:06:19 --> CSRF token verified
INFO - 2018-04-16 22:06:20 --> Input Class Initialized
INFO - 2018-04-16 22:06:20 --> Language Class Initialized
INFO - 2018-04-16 22:06:20 --> Loader Class Initialized
INFO - 2018-04-16 22:06:20 --> Helper loaded: url_helper
INFO - 2018-04-16 22:06:20 --> Helper loaded: form_helper
INFO - 2018-04-16 22:06:20 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:06:20 --> User Agent Class Initialized
INFO - 2018-04-16 22:06:20 --> Controller Class Initialized
INFO - 2018-04-16 22:06:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:06:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:06:20 --> Upload Class Initialized
INFO - 2018-04-16 22:06:20 --> Pixel_Model class loaded
INFO - 2018-04-16 22:06:20 --> Database Driver Class Initialized
INFO - 2018-04-16 22:06:20 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:06:20 --> Database Driver Class Initialized
INFO - 2018-04-16 22:06:20 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 22:06:20 --> Helper loaded: string_helper
INFO - 2018-04-16 22:06:20 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-16 22:06:20 --> Email Class Initialized
DEBUG - 2018-04-16 22:06:20 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 22:06:20 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-16 22:06:20 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-16 22:06:20 --> Config Class Initialized
INFO - 2018-04-16 22:06:20 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:20 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:20 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:20 --> URI Class Initialized
INFO - 2018-04-16 22:06:21 --> Router Class Initialized
INFO - 2018-04-16 22:06:21 --> Output Class Initialized
INFO - 2018-04-16 22:06:21 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:21 --> CSRF cookie sent
INFO - 2018-04-16 22:06:21 --> Input Class Initialized
INFO - 2018-04-16 22:06:21 --> Language Class Initialized
ERROR - 2018-04-16 22:06:21 --> 404 Page Not Found: Assets/images
INFO - 2018-04-16 22:06:43 --> Config Class Initialized
INFO - 2018-04-16 22:06:43 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:43 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:43 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:43 --> URI Class Initialized
INFO - 2018-04-16 22:06:43 --> Router Class Initialized
INFO - 2018-04-16 22:06:43 --> Output Class Initialized
INFO - 2018-04-16 22:06:43 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:43 --> CSRF cookie sent
INFO - 2018-04-16 22:06:43 --> Input Class Initialized
INFO - 2018-04-16 22:06:43 --> Language Class Initialized
INFO - 2018-04-16 22:06:43 --> Loader Class Initialized
INFO - 2018-04-16 22:06:43 --> Helper loaded: url_helper
INFO - 2018-04-16 22:06:43 --> Helper loaded: form_helper
INFO - 2018-04-16 22:06:43 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:06:43 --> User Agent Class Initialized
INFO - 2018-04-16 22:06:43 --> Controller Class Initialized
INFO - 2018-04-16 22:06:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:06:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:06:43 --> CSRF cookie sent
INFO - 2018-04-16 22:06:43 --> Config Class Initialized
INFO - 2018-04-16 22:06:43 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:43 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:43 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:43 --> URI Class Initialized
DEBUG - 2018-04-16 22:06:43 --> No URI present. Default controller set.
INFO - 2018-04-16 22:06:43 --> Router Class Initialized
INFO - 2018-04-16 22:06:43 --> Output Class Initialized
INFO - 2018-04-16 22:06:43 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:43 --> CSRF cookie sent
INFO - 2018-04-16 22:06:43 --> Input Class Initialized
INFO - 2018-04-16 22:06:43 --> Language Class Initialized
INFO - 2018-04-16 22:06:43 --> Loader Class Initialized
INFO - 2018-04-16 22:06:43 --> Helper loaded: url_helper
INFO - 2018-04-16 22:06:43 --> Helper loaded: form_helper
INFO - 2018-04-16 22:06:43 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:06:43 --> User Agent Class Initialized
INFO - 2018-04-16 22:06:43 --> Controller Class Initialized
INFO - 2018-04-16 22:06:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:06:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:06:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:06:43 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:06:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:06:43 --> Final output sent to browser
DEBUG - 2018-04-16 22:06:43 --> Total execution time: 0.3795
INFO - 2018-04-16 22:06:44 --> Config Class Initialized
INFO - 2018-04-16 22:06:44 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:44 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:44 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:44 --> URI Class Initialized
INFO - 2018-04-16 22:06:44 --> Router Class Initialized
INFO - 2018-04-16 22:06:45 --> Output Class Initialized
INFO - 2018-04-16 22:06:45 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:45 --> CSRF cookie sent
INFO - 2018-04-16 22:06:45 --> Input Class Initialized
INFO - 2018-04-16 22:06:45 --> Language Class Initialized
ERROR - 2018-04-16 22:06:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:06:46 --> Config Class Initialized
INFO - 2018-04-16 22:06:46 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:46 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:46 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:46 --> URI Class Initialized
INFO - 2018-04-16 22:06:46 --> Router Class Initialized
INFO - 2018-04-16 22:06:46 --> Output Class Initialized
INFO - 2018-04-16 22:06:46 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:46 --> CSRF cookie sent
INFO - 2018-04-16 22:06:46 --> Input Class Initialized
INFO - 2018-04-16 22:06:46 --> Language Class Initialized
INFO - 2018-04-16 22:06:46 --> Loader Class Initialized
INFO - 2018-04-16 22:06:46 --> Helper loaded: url_helper
INFO - 2018-04-16 22:06:46 --> Helper loaded: form_helper
INFO - 2018-04-16 22:06:46 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:06:46 --> User Agent Class Initialized
INFO - 2018-04-16 22:06:46 --> Controller Class Initialized
INFO - 2018-04-16 22:06:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:06:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:06:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:06:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:06:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:06:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 22:06:46 --> Could not find the language line "req_email"
INFO - 2018-04-16 22:06:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 22:06:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:06:47 --> Final output sent to browser
DEBUG - 2018-04-16 22:06:47 --> Total execution time: 0.5368
INFO - 2018-04-16 22:06:47 --> Config Class Initialized
INFO - 2018-04-16 22:06:47 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:06:47 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:06:47 --> Utf8 Class Initialized
INFO - 2018-04-16 22:06:47 --> URI Class Initialized
INFO - 2018-04-16 22:06:48 --> Router Class Initialized
INFO - 2018-04-16 22:06:48 --> Output Class Initialized
INFO - 2018-04-16 22:06:48 --> Security Class Initialized
DEBUG - 2018-04-16 22:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:06:48 --> CSRF cookie sent
INFO - 2018-04-16 22:06:48 --> Input Class Initialized
INFO - 2018-04-16 22:06:48 --> Language Class Initialized
ERROR - 2018-04-16 22:06:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:07:05 --> Config Class Initialized
INFO - 2018-04-16 22:07:05 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:05 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:05 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:05 --> URI Class Initialized
INFO - 2018-04-16 22:07:05 --> Router Class Initialized
INFO - 2018-04-16 22:07:05 --> Output Class Initialized
INFO - 2018-04-16 22:07:05 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:05 --> CSRF cookie sent
INFO - 2018-04-16 22:07:05 --> CSRF token verified
INFO - 2018-04-16 22:07:05 --> Input Class Initialized
INFO - 2018-04-16 22:07:05 --> Language Class Initialized
INFO - 2018-04-16 22:07:05 --> Loader Class Initialized
INFO - 2018-04-16 22:07:05 --> Helper loaded: url_helper
INFO - 2018-04-16 22:07:05 --> Helper loaded: form_helper
INFO - 2018-04-16 22:07:05 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:07:05 --> User Agent Class Initialized
INFO - 2018-04-16 22:07:05 --> Controller Class Initialized
INFO - 2018-04-16 22:07:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:07:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:07:05 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:07:05 --> Form Validation Class Initialized
INFO - 2018-04-16 22:07:05 --> Pixel_Model class loaded
INFO - 2018-04-16 22:07:05 --> Database Driver Class Initialized
INFO - 2018-04-16 22:07:08 --> Model "AuthenticationModel" initialized
INFO - 2018-04-16 22:07:09 --> Config Class Initialized
INFO - 2018-04-16 22:07:09 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:09 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:09 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:09 --> URI Class Initialized
DEBUG - 2018-04-16 22:07:09 --> No URI present. Default controller set.
INFO - 2018-04-16 22:07:09 --> Router Class Initialized
INFO - 2018-04-16 22:07:09 --> Output Class Initialized
INFO - 2018-04-16 22:07:09 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:09 --> CSRF cookie sent
INFO - 2018-04-16 22:07:09 --> Input Class Initialized
INFO - 2018-04-16 22:07:09 --> Language Class Initialized
INFO - 2018-04-16 22:07:09 --> Loader Class Initialized
INFO - 2018-04-16 22:07:09 --> Helper loaded: url_helper
INFO - 2018-04-16 22:07:09 --> Helper loaded: form_helper
INFO - 2018-04-16 22:07:09 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:07:09 --> User Agent Class Initialized
INFO - 2018-04-16 22:07:09 --> Controller Class Initialized
INFO - 2018-04-16 22:07:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:07:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:07:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:07:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:07:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:07:09 --> Final output sent to browser
DEBUG - 2018-04-16 22:07:09 --> Total execution time: 0.2790
INFO - 2018-04-16 22:07:09 --> Config Class Initialized
INFO - 2018-04-16 22:07:09 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:09 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:09 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:09 --> URI Class Initialized
INFO - 2018-04-16 22:07:09 --> Router Class Initialized
INFO - 2018-04-16 22:07:09 --> Output Class Initialized
INFO - 2018-04-16 22:07:09 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:09 --> CSRF cookie sent
INFO - 2018-04-16 22:07:09 --> Input Class Initialized
INFO - 2018-04-16 22:07:09 --> Language Class Initialized
ERROR - 2018-04-16 22:07:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:07:11 --> Config Class Initialized
INFO - 2018-04-16 22:07:11 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:11 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:11 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:11 --> URI Class Initialized
INFO - 2018-04-16 22:07:11 --> Router Class Initialized
INFO - 2018-04-16 22:07:11 --> Output Class Initialized
INFO - 2018-04-16 22:07:11 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:11 --> CSRF cookie sent
INFO - 2018-04-16 22:07:11 --> Input Class Initialized
INFO - 2018-04-16 22:07:11 --> Language Class Initialized
ERROR - 2018-04-16 22:07:11 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:07:15 --> Config Class Initialized
INFO - 2018-04-16 22:07:15 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:15 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:15 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:15 --> URI Class Initialized
INFO - 2018-04-16 22:07:15 --> Router Class Initialized
INFO - 2018-04-16 22:07:15 --> Output Class Initialized
INFO - 2018-04-16 22:07:15 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:15 --> CSRF cookie sent
INFO - 2018-04-16 22:07:15 --> Input Class Initialized
INFO - 2018-04-16 22:07:15 --> Language Class Initialized
INFO - 2018-04-16 22:07:15 --> Loader Class Initialized
INFO - 2018-04-16 22:07:15 --> Helper loaded: url_helper
INFO - 2018-04-16 22:07:15 --> Helper loaded: form_helper
INFO - 2018-04-16 22:07:15 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:07:15 --> User Agent Class Initialized
INFO - 2018-04-16 22:07:15 --> Controller Class Initialized
INFO - 2018-04-16 22:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:07:15 --> CSRF cookie sent
INFO - 2018-04-16 22:07:15 --> Config Class Initialized
INFO - 2018-04-16 22:07:15 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:15 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:15 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:15 --> URI Class Initialized
DEBUG - 2018-04-16 22:07:15 --> No URI present. Default controller set.
INFO - 2018-04-16 22:07:15 --> Router Class Initialized
INFO - 2018-04-16 22:07:15 --> Output Class Initialized
INFO - 2018-04-16 22:07:15 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:15 --> CSRF cookie sent
INFO - 2018-04-16 22:07:15 --> Input Class Initialized
INFO - 2018-04-16 22:07:15 --> Language Class Initialized
INFO - 2018-04-16 22:07:15 --> Loader Class Initialized
INFO - 2018-04-16 22:07:15 --> Helper loaded: url_helper
INFO - 2018-04-16 22:07:15 --> Helper loaded: form_helper
INFO - 2018-04-16 22:07:15 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:07:15 --> User Agent Class Initialized
INFO - 2018-04-16 22:07:15 --> Controller Class Initialized
INFO - 2018-04-16 22:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:07:15 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:07:15 --> Final output sent to browser
DEBUG - 2018-04-16 22:07:15 --> Total execution time: 0.3170
INFO - 2018-04-16 22:07:16 --> Config Class Initialized
INFO - 2018-04-16 22:07:16 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:16 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:16 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:16 --> URI Class Initialized
INFO - 2018-04-16 22:07:16 --> Router Class Initialized
INFO - 2018-04-16 22:07:16 --> Output Class Initialized
INFO - 2018-04-16 22:07:16 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:16 --> CSRF cookie sent
INFO - 2018-04-16 22:07:16 --> Input Class Initialized
INFO - 2018-04-16 22:07:16 --> Language Class Initialized
ERROR - 2018-04-16 22:07:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:07:18 --> Config Class Initialized
INFO - 2018-04-16 22:07:18 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:07:18 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:07:18 --> Utf8 Class Initialized
INFO - 2018-04-16 22:07:18 --> URI Class Initialized
INFO - 2018-04-16 22:07:18 --> Router Class Initialized
INFO - 2018-04-16 22:07:18 --> Output Class Initialized
INFO - 2018-04-16 22:07:18 --> Security Class Initialized
DEBUG - 2018-04-16 22:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:07:18 --> CSRF cookie sent
INFO - 2018-04-16 22:07:18 --> Input Class Initialized
INFO - 2018-04-16 22:07:18 --> Language Class Initialized
ERROR - 2018-04-16 22:07:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:17:29 --> Config Class Initialized
INFO - 2018-04-16 22:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:17:29 --> Utf8 Class Initialized
INFO - 2018-04-16 22:17:29 --> URI Class Initialized
INFO - 2018-04-16 22:17:29 --> Router Class Initialized
INFO - 2018-04-16 22:17:29 --> Output Class Initialized
INFO - 2018-04-16 22:17:30 --> Security Class Initialized
DEBUG - 2018-04-16 22:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:17:30 --> CSRF cookie sent
INFO - 2018-04-16 22:17:30 --> Input Class Initialized
INFO - 2018-04-16 22:17:30 --> Language Class Initialized
INFO - 2018-04-16 22:17:30 --> Loader Class Initialized
INFO - 2018-04-16 22:17:30 --> Helper loaded: url_helper
INFO - 2018-04-16 22:17:30 --> Helper loaded: form_helper
INFO - 2018-04-16 22:17:30 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:17:30 --> User Agent Class Initialized
INFO - 2018-04-16 22:17:30 --> Controller Class Initialized
INFO - 2018-04-16 22:17:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:17:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:17:30 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
ERROR - 2018-04-16 22:17:30 --> Severity: Notice --> Undefined variable: html E:\www\yacopoo\application\libraries\Smart.php 470
INFO - 2018-04-16 22:17:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:17:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:17:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 22:17:30 --> Could not find the language line "req_email"
INFO - 2018-04-16 22:17:30 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 22:17:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:17:30 --> Final output sent to browser
DEBUG - 2018-04-16 22:17:30 --> Total execution time: 0.3990
INFO - 2018-04-16 22:17:30 --> Config Class Initialized
INFO - 2018-04-16 22:17:30 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:17:30 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:17:30 --> Utf8 Class Initialized
INFO - 2018-04-16 22:17:30 --> URI Class Initialized
INFO - 2018-04-16 22:17:30 --> Router Class Initialized
INFO - 2018-04-16 22:17:30 --> Output Class Initialized
INFO - 2018-04-16 22:17:30 --> Security Class Initialized
DEBUG - 2018-04-16 22:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:17:30 --> CSRF cookie sent
INFO - 2018-04-16 22:17:30 --> Input Class Initialized
INFO - 2018-04-16 22:17:30 --> Language Class Initialized
ERROR - 2018-04-16 22:17:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:17:51 --> Config Class Initialized
INFO - 2018-04-16 22:17:51 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:17:51 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:17:51 --> Utf8 Class Initialized
INFO - 2018-04-16 22:17:51 --> URI Class Initialized
INFO - 2018-04-16 22:17:51 --> Router Class Initialized
INFO - 2018-04-16 22:17:51 --> Output Class Initialized
INFO - 2018-04-16 22:17:51 --> Security Class Initialized
DEBUG - 2018-04-16 22:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:17:51 --> CSRF cookie sent
INFO - 2018-04-16 22:17:51 --> Input Class Initialized
INFO - 2018-04-16 22:17:51 --> Language Class Initialized
INFO - 2018-04-16 22:17:51 --> Loader Class Initialized
INFO - 2018-04-16 22:17:51 --> Helper loaded: url_helper
INFO - 2018-04-16 22:17:51 --> Helper loaded: form_helper
INFO - 2018-04-16 22:17:51 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:17:52 --> User Agent Class Initialized
INFO - 2018-04-16 22:17:52 --> Controller Class Initialized
INFO - 2018-04-16 22:17:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:17:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:17:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:17:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:17:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:17:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 22:17:52 --> Could not find the language line "req_email"
INFO - 2018-04-16 22:17:52 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 22:17:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:17:52 --> Final output sent to browser
DEBUG - 2018-04-16 22:17:52 --> Total execution time: 0.3549
INFO - 2018-04-16 22:17:52 --> Config Class Initialized
INFO - 2018-04-16 22:17:52 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:17:52 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:17:52 --> Utf8 Class Initialized
INFO - 2018-04-16 22:17:52 --> URI Class Initialized
INFO - 2018-04-16 22:17:52 --> Router Class Initialized
INFO - 2018-04-16 22:17:52 --> Output Class Initialized
INFO - 2018-04-16 22:17:52 --> Security Class Initialized
DEBUG - 2018-04-16 22:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:17:52 --> CSRF cookie sent
INFO - 2018-04-16 22:17:52 --> Input Class Initialized
INFO - 2018-04-16 22:17:52 --> Language Class Initialized
ERROR - 2018-04-16 22:17:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:17:58 --> Config Class Initialized
INFO - 2018-04-16 22:17:58 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:17:58 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:17:58 --> Utf8 Class Initialized
INFO - 2018-04-16 22:17:58 --> URI Class Initialized
INFO - 2018-04-16 22:17:58 --> Router Class Initialized
INFO - 2018-04-16 22:17:58 --> Output Class Initialized
INFO - 2018-04-16 22:17:58 --> Security Class Initialized
DEBUG - 2018-04-16 22:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:17:58 --> CSRF cookie sent
INFO - 2018-04-16 22:17:58 --> CSRF token verified
INFO - 2018-04-16 22:17:58 --> Input Class Initialized
INFO - 2018-04-16 22:17:58 --> Language Class Initialized
INFO - 2018-04-16 22:17:58 --> Loader Class Initialized
INFO - 2018-04-16 22:17:59 --> Helper loaded: url_helper
INFO - 2018-04-16 22:17:59 --> Helper loaded: form_helper
INFO - 2018-04-16 22:17:59 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:17:59 --> User Agent Class Initialized
INFO - 2018-04-16 22:17:59 --> Controller Class Initialized
INFO - 2018-04-16 22:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:17:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:17:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:17:59 --> Form Validation Class Initialized
INFO - 2018-04-16 22:17:59 --> Pixel_Model class loaded
INFO - 2018-04-16 22:17:59 --> Database Driver Class Initialized
INFO - 2018-04-16 22:18:02 --> Model "AuthenticationModel" initialized
INFO - 2018-04-16 22:18:02 --> Config Class Initialized
INFO - 2018-04-16 22:18:02 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:02 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:02 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:02 --> URI Class Initialized
DEBUG - 2018-04-16 22:18:02 --> No URI present. Default controller set.
INFO - 2018-04-16 22:18:02 --> Router Class Initialized
INFO - 2018-04-16 22:18:02 --> Output Class Initialized
INFO - 2018-04-16 22:18:02 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:02 --> CSRF cookie sent
INFO - 2018-04-16 22:18:02 --> Input Class Initialized
INFO - 2018-04-16 22:18:02 --> Language Class Initialized
INFO - 2018-04-16 22:18:02 --> Loader Class Initialized
INFO - 2018-04-16 22:18:02 --> Helper loaded: url_helper
INFO - 2018-04-16 22:18:02 --> Helper loaded: form_helper
INFO - 2018-04-16 22:18:02 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:18:02 --> User Agent Class Initialized
INFO - 2018-04-16 22:18:02 --> Controller Class Initialized
INFO - 2018-04-16 22:18:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:18:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:18:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:18:02 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:18:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:18:02 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:18:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:18:03 --> Final output sent to browser
DEBUG - 2018-04-16 22:18:03 --> Total execution time: 0.3261
INFO - 2018-04-16 22:18:03 --> Config Class Initialized
INFO - 2018-04-16 22:18:03 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:03 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:03 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:03 --> URI Class Initialized
INFO - 2018-04-16 22:18:03 --> Router Class Initialized
INFO - 2018-04-16 22:18:03 --> Output Class Initialized
INFO - 2018-04-16 22:18:03 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:03 --> CSRF cookie sent
INFO - 2018-04-16 22:18:03 --> Input Class Initialized
INFO - 2018-04-16 22:18:03 --> Language Class Initialized
ERROR - 2018-04-16 22:18:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:18:05 --> Config Class Initialized
INFO - 2018-04-16 22:18:05 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:05 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:05 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:05 --> URI Class Initialized
INFO - 2018-04-16 22:18:05 --> Router Class Initialized
INFO - 2018-04-16 22:18:05 --> Output Class Initialized
INFO - 2018-04-16 22:18:05 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:05 --> CSRF cookie sent
INFO - 2018-04-16 22:18:05 --> Input Class Initialized
INFO - 2018-04-16 22:18:05 --> Language Class Initialized
ERROR - 2018-04-16 22:18:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:18:07 --> Config Class Initialized
INFO - 2018-04-16 22:18:07 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:07 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:07 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:07 --> URI Class Initialized
INFO - 2018-04-16 22:18:07 --> Router Class Initialized
INFO - 2018-04-16 22:18:07 --> Output Class Initialized
INFO - 2018-04-16 22:18:07 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:07 --> CSRF cookie sent
INFO - 2018-04-16 22:18:08 --> Input Class Initialized
INFO - 2018-04-16 22:18:08 --> Language Class Initialized
INFO - 2018-04-16 22:18:08 --> Loader Class Initialized
INFO - 2018-04-16 22:18:08 --> Helper loaded: url_helper
INFO - 2018-04-16 22:18:08 --> Helper loaded: form_helper
INFO - 2018-04-16 22:18:08 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:18:08 --> User Agent Class Initialized
INFO - 2018-04-16 22:18:08 --> Controller Class Initialized
INFO - 2018-04-16 22:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:18:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:18:08 --> CSRF cookie sent
INFO - 2018-04-16 22:18:08 --> Config Class Initialized
INFO - 2018-04-16 22:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:08 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:08 --> URI Class Initialized
DEBUG - 2018-04-16 22:18:08 --> No URI present. Default controller set.
INFO - 2018-04-16 22:18:08 --> Router Class Initialized
INFO - 2018-04-16 22:18:08 --> Output Class Initialized
INFO - 2018-04-16 22:18:08 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:08 --> CSRF cookie sent
INFO - 2018-04-16 22:18:08 --> Input Class Initialized
INFO - 2018-04-16 22:18:08 --> Language Class Initialized
INFO - 2018-04-16 22:18:08 --> Loader Class Initialized
INFO - 2018-04-16 22:18:08 --> Helper loaded: url_helper
INFO - 2018-04-16 22:18:08 --> Helper loaded: form_helper
INFO - 2018-04-16 22:18:08 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:18:08 --> User Agent Class Initialized
INFO - 2018-04-16 22:18:08 --> Controller Class Initialized
INFO - 2018-04-16 22:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:18:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:18:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:18:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:18:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:18:08 --> Final output sent to browser
DEBUG - 2018-04-16 22:18:08 --> Total execution time: 0.3199
INFO - 2018-04-16 22:18:08 --> Config Class Initialized
INFO - 2018-04-16 22:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:08 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:09 --> URI Class Initialized
INFO - 2018-04-16 22:18:09 --> Router Class Initialized
INFO - 2018-04-16 22:18:09 --> Output Class Initialized
INFO - 2018-04-16 22:18:09 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:09 --> CSRF cookie sent
INFO - 2018-04-16 22:18:09 --> Input Class Initialized
INFO - 2018-04-16 22:18:09 --> Language Class Initialized
ERROR - 2018-04-16 22:18:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:18:10 --> Config Class Initialized
INFO - 2018-04-16 22:18:10 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:10 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:10 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:10 --> URI Class Initialized
INFO - 2018-04-16 22:18:10 --> Router Class Initialized
INFO - 2018-04-16 22:18:10 --> Output Class Initialized
INFO - 2018-04-16 22:18:10 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:10 --> CSRF cookie sent
INFO - 2018-04-16 22:18:10 --> Input Class Initialized
INFO - 2018-04-16 22:18:10 --> Language Class Initialized
ERROR - 2018-04-16 22:18:10 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:18:33 --> Config Class Initialized
INFO - 2018-04-16 22:18:33 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:33 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:33 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:33 --> URI Class Initialized
DEBUG - 2018-04-16 22:18:33 --> No URI present. Default controller set.
INFO - 2018-04-16 22:18:33 --> Router Class Initialized
INFO - 2018-04-16 22:18:33 --> Output Class Initialized
INFO - 2018-04-16 22:18:33 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:33 --> CSRF cookie sent
INFO - 2018-04-16 22:18:33 --> Input Class Initialized
INFO - 2018-04-16 22:18:33 --> Language Class Initialized
INFO - 2018-04-16 22:18:33 --> Loader Class Initialized
INFO - 2018-04-16 22:18:33 --> Helper loaded: url_helper
INFO - 2018-04-16 22:18:33 --> Helper loaded: form_helper
INFO - 2018-04-16 22:18:33 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:18:33 --> User Agent Class Initialized
INFO - 2018-04-16 22:18:34 --> Controller Class Initialized
INFO - 2018-04-16 22:18:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:18:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:18:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:18:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:18:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:18:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:18:34 --> Final output sent to browser
DEBUG - 2018-04-16 22:18:34 --> Total execution time: 0.3996
INFO - 2018-04-16 22:18:34 --> Config Class Initialized
INFO - 2018-04-16 22:18:34 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:34 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:34 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:34 --> URI Class Initialized
INFO - 2018-04-16 22:18:34 --> Router Class Initialized
INFO - 2018-04-16 22:18:34 --> Output Class Initialized
INFO - 2018-04-16 22:18:34 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:34 --> CSRF cookie sent
INFO - 2018-04-16 22:18:34 --> Input Class Initialized
INFO - 2018-04-16 22:18:34 --> Language Class Initialized
ERROR - 2018-04-16 22:18:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:18:36 --> Config Class Initialized
INFO - 2018-04-16 22:18:36 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:18:36 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:18:36 --> Utf8 Class Initialized
INFO - 2018-04-16 22:18:36 --> URI Class Initialized
INFO - 2018-04-16 22:18:36 --> Router Class Initialized
INFO - 2018-04-16 22:18:36 --> Output Class Initialized
INFO - 2018-04-16 22:18:36 --> Security Class Initialized
DEBUG - 2018-04-16 22:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:18:36 --> CSRF cookie sent
INFO - 2018-04-16 22:18:36 --> Input Class Initialized
INFO - 2018-04-16 22:18:36 --> Language Class Initialized
ERROR - 2018-04-16 22:18:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:21:13 --> Config Class Initialized
INFO - 2018-04-16 22:21:13 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:13 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:14 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:14 --> URI Class Initialized
DEBUG - 2018-04-16 22:21:14 --> No URI present. Default controller set.
INFO - 2018-04-16 22:21:14 --> Router Class Initialized
INFO - 2018-04-16 22:21:14 --> Output Class Initialized
INFO - 2018-04-16 22:21:14 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:14 --> CSRF cookie sent
INFO - 2018-04-16 22:21:14 --> Input Class Initialized
INFO - 2018-04-16 22:21:14 --> Language Class Initialized
INFO - 2018-04-16 22:21:14 --> Loader Class Initialized
INFO - 2018-04-16 22:21:14 --> Helper loaded: url_helper
INFO - 2018-04-16 22:21:14 --> Helper loaded: form_helper
INFO - 2018-04-16 22:21:14 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:21:14 --> User Agent Class Initialized
INFO - 2018-04-16 22:21:14 --> Controller Class Initialized
INFO - 2018-04-16 22:21:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:21:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:21:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:21:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:21:14 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:21:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:21:14 --> Final output sent to browser
DEBUG - 2018-04-16 22:21:14 --> Total execution time: 0.4040
INFO - 2018-04-16 22:21:14 --> Config Class Initialized
INFO - 2018-04-16 22:21:14 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:14 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:14 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:14 --> URI Class Initialized
INFO - 2018-04-16 22:21:14 --> Router Class Initialized
INFO - 2018-04-16 22:21:14 --> Output Class Initialized
INFO - 2018-04-16 22:21:14 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:14 --> CSRF cookie sent
INFO - 2018-04-16 22:21:14 --> Input Class Initialized
INFO - 2018-04-16 22:21:14 --> Language Class Initialized
ERROR - 2018-04-16 22:21:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:21:16 --> Config Class Initialized
INFO - 2018-04-16 22:21:16 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:16 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:16 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:16 --> URI Class Initialized
INFO - 2018-04-16 22:21:16 --> Router Class Initialized
INFO - 2018-04-16 22:21:16 --> Output Class Initialized
INFO - 2018-04-16 22:21:16 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:16 --> CSRF cookie sent
INFO - 2018-04-16 22:21:16 --> Input Class Initialized
INFO - 2018-04-16 22:21:16 --> Language Class Initialized
ERROR - 2018-04-16 22:21:16 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:21:17 --> Config Class Initialized
INFO - 2018-04-16 22:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:17 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:17 --> URI Class Initialized
INFO - 2018-04-16 22:21:17 --> Router Class Initialized
INFO - 2018-04-16 22:21:17 --> Output Class Initialized
INFO - 2018-04-16 22:21:17 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:17 --> CSRF cookie sent
INFO - 2018-04-16 22:21:17 --> Input Class Initialized
INFO - 2018-04-16 22:21:17 --> Language Class Initialized
INFO - 2018-04-16 22:21:17 --> Loader Class Initialized
INFO - 2018-04-16 22:21:17 --> Helper loaded: url_helper
INFO - 2018-04-16 22:21:17 --> Helper loaded: form_helper
INFO - 2018-04-16 22:21:17 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:21:17 --> User Agent Class Initialized
INFO - 2018-04-16 22:21:17 --> Controller Class Initialized
INFO - 2018-04-16 22:21:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:21:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:21:17 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 22:21:17 --> Could not find the language line "req_email"
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-16 22:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:21:17 --> Final output sent to browser
DEBUG - 2018-04-16 22:21:17 --> Total execution time: 0.4267
INFO - 2018-04-16 22:21:17 --> Config Class Initialized
INFO - 2018-04-16 22:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:17 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:17 --> URI Class Initialized
INFO - 2018-04-16 22:21:17 --> Router Class Initialized
INFO - 2018-04-16 22:21:17 --> Output Class Initialized
INFO - 2018-04-16 22:21:17 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:17 --> CSRF cookie sent
INFO - 2018-04-16 22:21:17 --> Input Class Initialized
INFO - 2018-04-16 22:21:17 --> Language Class Initialized
ERROR - 2018-04-16 22:21:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:21:22 --> Config Class Initialized
INFO - 2018-04-16 22:21:22 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:22 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:22 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:22 --> URI Class Initialized
INFO - 2018-04-16 22:21:22 --> Router Class Initialized
INFO - 2018-04-16 22:21:22 --> Output Class Initialized
INFO - 2018-04-16 22:21:22 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:22 --> CSRF cookie sent
INFO - 2018-04-16 22:21:22 --> CSRF token verified
INFO - 2018-04-16 22:21:22 --> Input Class Initialized
INFO - 2018-04-16 22:21:22 --> Language Class Initialized
INFO - 2018-04-16 22:21:22 --> Loader Class Initialized
INFO - 2018-04-16 22:21:22 --> Helper loaded: url_helper
INFO - 2018-04-16 22:21:22 --> Helper loaded: form_helper
INFO - 2018-04-16 22:21:22 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:21:22 --> User Agent Class Initialized
INFO - 2018-04-16 22:21:22 --> Controller Class Initialized
INFO - 2018-04-16 22:21:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:21:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-16 22:21:23 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-16 22:21:23 --> Form Validation Class Initialized
INFO - 2018-04-16 22:21:23 --> Pixel_Model class loaded
INFO - 2018-04-16 22:21:23 --> Database Driver Class Initialized
INFO - 2018-04-16 22:21:26 --> Model "AuthenticationModel" initialized
INFO - 2018-04-16 22:21:26 --> Config Class Initialized
INFO - 2018-04-16 22:21:26 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:26 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:26 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:26 --> URI Class Initialized
DEBUG - 2018-04-16 22:21:26 --> No URI present. Default controller set.
INFO - 2018-04-16 22:21:26 --> Router Class Initialized
INFO - 2018-04-16 22:21:26 --> Output Class Initialized
INFO - 2018-04-16 22:21:26 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:26 --> CSRF cookie sent
INFO - 2018-04-16 22:21:26 --> Input Class Initialized
INFO - 2018-04-16 22:21:26 --> Language Class Initialized
INFO - 2018-04-16 22:21:26 --> Loader Class Initialized
INFO - 2018-04-16 22:21:26 --> Helper loaded: url_helper
INFO - 2018-04-16 22:21:26 --> Helper loaded: form_helper
INFO - 2018-04-16 22:21:26 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:21:26 --> User Agent Class Initialized
INFO - 2018-04-16 22:21:26 --> Controller Class Initialized
INFO - 2018-04-16 22:21:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:21:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:21:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:21:26 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:21:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:21:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:21:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:21:26 --> Final output sent to browser
DEBUG - 2018-04-16 22:21:26 --> Total execution time: 0.3046
INFO - 2018-04-16 22:21:27 --> Config Class Initialized
INFO - 2018-04-16 22:21:27 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:27 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:27 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:27 --> URI Class Initialized
INFO - 2018-04-16 22:21:27 --> Router Class Initialized
INFO - 2018-04-16 22:21:27 --> Output Class Initialized
INFO - 2018-04-16 22:21:27 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:27 --> CSRF cookie sent
INFO - 2018-04-16 22:21:27 --> Input Class Initialized
INFO - 2018-04-16 22:21:27 --> Language Class Initialized
ERROR - 2018-04-16 22:21:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:21:29 --> Config Class Initialized
INFO - 2018-04-16 22:21:29 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:21:29 --> Utf8 Class Initialized
INFO - 2018-04-16 22:21:29 --> URI Class Initialized
INFO - 2018-04-16 22:21:29 --> Router Class Initialized
INFO - 2018-04-16 22:21:29 --> Output Class Initialized
INFO - 2018-04-16 22:21:29 --> Security Class Initialized
DEBUG - 2018-04-16 22:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:21:29 --> CSRF cookie sent
INFO - 2018-04-16 22:21:29 --> Input Class Initialized
INFO - 2018-04-16 22:21:29 --> Language Class Initialized
ERROR - 2018-04-16 22:21:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:22:15 --> Config Class Initialized
INFO - 2018-04-16 22:22:15 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:22:15 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:22:15 --> Utf8 Class Initialized
INFO - 2018-04-16 22:22:15 --> URI Class Initialized
INFO - 2018-04-16 22:22:15 --> Router Class Initialized
INFO - 2018-04-16 22:22:15 --> Output Class Initialized
INFO - 2018-04-16 22:22:15 --> Security Class Initialized
DEBUG - 2018-04-16 22:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:22:15 --> CSRF cookie sent
INFO - 2018-04-16 22:22:15 --> Input Class Initialized
INFO - 2018-04-16 22:22:15 --> Language Class Initialized
INFO - 2018-04-16 22:22:15 --> Loader Class Initialized
INFO - 2018-04-16 22:22:15 --> Helper loaded: url_helper
INFO - 2018-04-16 22:22:15 --> Helper loaded: form_helper
INFO - 2018-04-16 22:22:15 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:22:15 --> User Agent Class Initialized
INFO - 2018-04-16 22:22:15 --> Controller Class Initialized
INFO - 2018-04-16 22:22:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:22:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-16 22:22:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:22:16 --> Final output sent to browser
DEBUG - 2018-04-16 22:22:16 --> Total execution time: 0.4985
INFO - 2018-04-16 22:22:16 --> Config Class Initialized
INFO - 2018-04-16 22:22:16 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:22:16 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:22:16 --> Utf8 Class Initialized
INFO - 2018-04-16 22:22:16 --> URI Class Initialized
INFO - 2018-04-16 22:22:16 --> Router Class Initialized
INFO - 2018-04-16 22:22:16 --> Output Class Initialized
INFO - 2018-04-16 22:22:16 --> Security Class Initialized
DEBUG - 2018-04-16 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:22:16 --> CSRF cookie sent
INFO - 2018-04-16 22:22:16 --> Input Class Initialized
INFO - 2018-04-16 22:22:16 --> Language Class Initialized
ERROR - 2018-04-16 22:22:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:22:36 --> Config Class Initialized
INFO - 2018-04-16 22:22:36 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:22:36 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:22:36 --> Utf8 Class Initialized
INFO - 2018-04-16 22:22:36 --> URI Class Initialized
INFO - 2018-04-16 22:22:36 --> Router Class Initialized
INFO - 2018-04-16 22:22:36 --> Output Class Initialized
INFO - 2018-04-16 22:22:36 --> Security Class Initialized
DEBUG - 2018-04-16 22:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:22:36 --> CSRF cookie sent
INFO - 2018-04-16 22:22:36 --> Input Class Initialized
INFO - 2018-04-16 22:22:36 --> Language Class Initialized
INFO - 2018-04-16 22:22:36 --> Loader Class Initialized
INFO - 2018-04-16 22:22:36 --> Helper loaded: url_helper
INFO - 2018-04-16 22:22:36 --> Helper loaded: form_helper
INFO - 2018-04-16 22:22:36 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:22:36 --> User Agent Class Initialized
INFO - 2018-04-16 22:22:36 --> Controller Class Initialized
INFO - 2018-04-16 22:22:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:22:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-16 22:22:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:22:36 --> Final output sent to browser
DEBUG - 2018-04-16 22:22:36 --> Total execution time: 0.3873
INFO - 2018-04-16 22:22:37 --> Config Class Initialized
INFO - 2018-04-16 22:22:37 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:22:37 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:22:37 --> Utf8 Class Initialized
INFO - 2018-04-16 22:22:37 --> URI Class Initialized
INFO - 2018-04-16 22:22:37 --> Router Class Initialized
INFO - 2018-04-16 22:22:37 --> Output Class Initialized
INFO - 2018-04-16 22:22:37 --> Security Class Initialized
DEBUG - 2018-04-16 22:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:22:37 --> CSRF cookie sent
INFO - 2018-04-16 22:22:37 --> Input Class Initialized
INFO - 2018-04-16 22:22:37 --> Language Class Initialized
ERROR - 2018-04-16 22:22:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:24:50 --> Config Class Initialized
INFO - 2018-04-16 22:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:24:50 --> Utf8 Class Initialized
INFO - 2018-04-16 22:24:50 --> URI Class Initialized
INFO - 2018-04-16 22:24:50 --> Router Class Initialized
INFO - 2018-04-16 22:24:50 --> Output Class Initialized
INFO - 2018-04-16 22:24:50 --> Security Class Initialized
DEBUG - 2018-04-16 22:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:24:50 --> CSRF cookie sent
INFO - 2018-04-16 22:24:50 --> Input Class Initialized
INFO - 2018-04-16 22:24:50 --> Language Class Initialized
INFO - 2018-04-16 22:24:50 --> Loader Class Initialized
INFO - 2018-04-16 22:24:50 --> Helper loaded: url_helper
INFO - 2018-04-16 22:24:50 --> Helper loaded: form_helper
INFO - 2018-04-16 22:24:50 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:24:50 --> User Agent Class Initialized
INFO - 2018-04-16 22:24:50 --> Controller Class Initialized
INFO - 2018-04-16 22:24:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:24:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-16 22:24:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:24:50 --> Final output sent to browser
DEBUG - 2018-04-16 22:24:50 --> Total execution time: 0.3560
INFO - 2018-04-16 22:24:51 --> Config Class Initialized
INFO - 2018-04-16 22:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:24:51 --> Utf8 Class Initialized
INFO - 2018-04-16 22:24:51 --> URI Class Initialized
INFO - 2018-04-16 22:24:51 --> Router Class Initialized
INFO - 2018-04-16 22:24:51 --> Output Class Initialized
INFO - 2018-04-16 22:24:51 --> Security Class Initialized
DEBUG - 2018-04-16 22:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:24:51 --> CSRF cookie sent
INFO - 2018-04-16 22:24:51 --> Input Class Initialized
INFO - 2018-04-16 22:24:51 --> Language Class Initialized
ERROR - 2018-04-16 22:24:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:24:54 --> Config Class Initialized
INFO - 2018-04-16 22:24:54 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:24:54 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:24:54 --> Utf8 Class Initialized
INFO - 2018-04-16 22:24:54 --> URI Class Initialized
INFO - 2018-04-16 22:24:54 --> Router Class Initialized
INFO - 2018-04-16 22:24:54 --> Output Class Initialized
INFO - 2018-04-16 22:24:54 --> Security Class Initialized
DEBUG - 2018-04-16 22:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:24:54 --> CSRF cookie sent
INFO - 2018-04-16 22:24:54 --> Input Class Initialized
INFO - 2018-04-16 22:24:54 --> Language Class Initialized
INFO - 2018-04-16 22:24:54 --> Loader Class Initialized
INFO - 2018-04-16 22:24:54 --> Helper loaded: url_helper
INFO - 2018-04-16 22:24:54 --> Helper loaded: form_helper
INFO - 2018-04-16 22:24:54 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:24:54 --> User Agent Class Initialized
INFO - 2018-04-16 22:24:54 --> Controller Class Initialized
INFO - 2018-04-16 22:24:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:24:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:24:54 --> Pixel_Model class loaded
INFO - 2018-04-16 22:24:54 --> Database Driver Class Initialized
INFO - 2018-04-16 22:24:57 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:24:57 --> Pagination Class Initialized
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:24:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:24:57 --> Final output sent to browser
DEBUG - 2018-04-16 22:24:57 --> Total execution time: 3.6281
INFO - 2018-04-16 22:24:58 --> Config Class Initialized
INFO - 2018-04-16 22:24:58 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:24:58 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:24:58 --> Utf8 Class Initialized
INFO - 2018-04-16 22:24:58 --> URI Class Initialized
INFO - 2018-04-16 22:24:58 --> Router Class Initialized
INFO - 2018-04-16 22:24:58 --> Output Class Initialized
INFO - 2018-04-16 22:24:58 --> Security Class Initialized
DEBUG - 2018-04-16 22:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:24:58 --> CSRF cookie sent
INFO - 2018-04-16 22:24:58 --> Input Class Initialized
INFO - 2018-04-16 22:24:58 --> Language Class Initialized
ERROR - 2018-04-16 22:24:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:25:54 --> Config Class Initialized
INFO - 2018-04-16 22:25:54 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:25:54 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:25:54 --> Utf8 Class Initialized
INFO - 2018-04-16 22:25:54 --> URI Class Initialized
INFO - 2018-04-16 22:25:54 --> Router Class Initialized
INFO - 2018-04-16 22:25:54 --> Output Class Initialized
INFO - 2018-04-16 22:25:54 --> Security Class Initialized
DEBUG - 2018-04-16 22:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:25:54 --> CSRF cookie sent
INFO - 2018-04-16 22:25:54 --> Input Class Initialized
INFO - 2018-04-16 22:25:54 --> Language Class Initialized
INFO - 2018-04-16 22:25:54 --> Loader Class Initialized
INFO - 2018-04-16 22:25:54 --> Helper loaded: url_helper
INFO - 2018-04-16 22:25:54 --> Helper loaded: form_helper
INFO - 2018-04-16 22:25:54 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:25:54 --> User Agent Class Initialized
INFO - 2018-04-16 22:25:54 --> Controller Class Initialized
INFO - 2018-04-16 22:25:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:25:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:25:54 --> Pixel_Model class loaded
INFO - 2018-04-16 22:25:54 --> Database Driver Class Initialized
INFO - 2018-04-16 22:25:54 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:25:54 --> Pagination Class Initialized
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:25:54 --> Final output sent to browser
DEBUG - 2018-04-16 22:25:54 --> Total execution time: 0.4480
INFO - 2018-04-16 22:25:55 --> Config Class Initialized
INFO - 2018-04-16 22:25:55 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:25:55 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:25:55 --> Utf8 Class Initialized
INFO - 2018-04-16 22:25:55 --> URI Class Initialized
INFO - 2018-04-16 22:25:55 --> Router Class Initialized
INFO - 2018-04-16 22:25:55 --> Output Class Initialized
INFO - 2018-04-16 22:25:55 --> Security Class Initialized
DEBUG - 2018-04-16 22:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:25:55 --> CSRF cookie sent
INFO - 2018-04-16 22:25:55 --> Input Class Initialized
INFO - 2018-04-16 22:25:55 --> Language Class Initialized
ERROR - 2018-04-16 22:25:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:26:01 --> Config Class Initialized
INFO - 2018-04-16 22:26:01 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:01 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:01 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:01 --> URI Class Initialized
DEBUG - 2018-04-16 22:26:01 --> No URI present. Default controller set.
INFO - 2018-04-16 22:26:01 --> Router Class Initialized
INFO - 2018-04-16 22:26:01 --> Output Class Initialized
INFO - 2018-04-16 22:26:01 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:01 --> CSRF cookie sent
INFO - 2018-04-16 22:26:01 --> Input Class Initialized
INFO - 2018-04-16 22:26:01 --> Language Class Initialized
INFO - 2018-04-16 22:26:01 --> Loader Class Initialized
INFO - 2018-04-16 22:26:01 --> Helper loaded: url_helper
INFO - 2018-04-16 22:26:01 --> Helper loaded: form_helper
INFO - 2018-04-16 22:26:01 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:26:01 --> User Agent Class Initialized
INFO - 2018-04-16 22:26:01 --> Controller Class Initialized
INFO - 2018-04-16 22:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:26:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:26:01 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:26:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:26:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-16 22:26:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:26:01 --> Final output sent to browser
DEBUG - 2018-04-16 22:26:01 --> Total execution time: 0.3442
INFO - 2018-04-16 22:26:01 --> Config Class Initialized
INFO - 2018-04-16 22:26:01 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:01 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:01 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:01 --> URI Class Initialized
INFO - 2018-04-16 22:26:01 --> Router Class Initialized
INFO - 2018-04-16 22:26:01 --> Output Class Initialized
INFO - 2018-04-16 22:26:01 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:01 --> CSRF cookie sent
INFO - 2018-04-16 22:26:01 --> Input Class Initialized
INFO - 2018-04-16 22:26:01 --> Language Class Initialized
ERROR - 2018-04-16 22:26:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:26:03 --> Config Class Initialized
INFO - 2018-04-16 22:26:03 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:03 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:03 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:03 --> URI Class Initialized
INFO - 2018-04-16 22:26:03 --> Router Class Initialized
INFO - 2018-04-16 22:26:03 --> Output Class Initialized
INFO - 2018-04-16 22:26:03 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:03 --> CSRF cookie sent
INFO - 2018-04-16 22:26:03 --> Input Class Initialized
INFO - 2018-04-16 22:26:03 --> Language Class Initialized
ERROR - 2018-04-16 22:26:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-16 22:26:21 --> Config Class Initialized
INFO - 2018-04-16 22:26:21 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:21 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:21 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:21 --> URI Class Initialized
INFO - 2018-04-16 22:26:21 --> Router Class Initialized
INFO - 2018-04-16 22:26:21 --> Output Class Initialized
INFO - 2018-04-16 22:26:21 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:21 --> CSRF cookie sent
INFO - 2018-04-16 22:26:21 --> Input Class Initialized
INFO - 2018-04-16 22:26:21 --> Language Class Initialized
INFO - 2018-04-16 22:26:21 --> Loader Class Initialized
INFO - 2018-04-16 22:26:21 --> Helper loaded: url_helper
INFO - 2018-04-16 22:26:21 --> Helper loaded: form_helper
INFO - 2018-04-16 22:26:21 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:26:21 --> User Agent Class Initialized
INFO - 2018-04-16 22:26:21 --> Controller Class Initialized
INFO - 2018-04-16 22:26:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:26:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:26:21 --> Pixel_Model class loaded
INFO - 2018-04-16 22:26:21 --> Database Driver Class Initialized
INFO - 2018-04-16 22:26:21 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:26:21 --> Pagination Class Initialized
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:26:21 --> Final output sent to browser
DEBUG - 2018-04-16 22:26:21 --> Total execution time: 0.4500
INFO - 2018-04-16 22:26:22 --> Config Class Initialized
INFO - 2018-04-16 22:26:22 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:22 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:22 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:22 --> URI Class Initialized
INFO - 2018-04-16 22:26:22 --> Router Class Initialized
INFO - 2018-04-16 22:26:22 --> Output Class Initialized
INFO - 2018-04-16 22:26:22 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:22 --> CSRF cookie sent
INFO - 2018-04-16 22:26:22 --> Input Class Initialized
INFO - 2018-04-16 22:26:22 --> Language Class Initialized
ERROR - 2018-04-16 22:26:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:26:36 --> Config Class Initialized
INFO - 2018-04-16 22:26:36 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:36 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:36 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:36 --> URI Class Initialized
INFO - 2018-04-16 22:26:36 --> Router Class Initialized
INFO - 2018-04-16 22:26:36 --> Output Class Initialized
INFO - 2018-04-16 22:26:36 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:36 --> CSRF cookie sent
INFO - 2018-04-16 22:26:36 --> Input Class Initialized
INFO - 2018-04-16 22:26:36 --> Language Class Initialized
INFO - 2018-04-16 22:26:36 --> Loader Class Initialized
INFO - 2018-04-16 22:26:36 --> Helper loaded: url_helper
INFO - 2018-04-16 22:26:36 --> Helper loaded: form_helper
INFO - 2018-04-16 22:26:36 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:26:36 --> User Agent Class Initialized
INFO - 2018-04-16 22:26:36 --> Controller Class Initialized
INFO - 2018-04-16 22:26:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:26:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:26:37 --> Pixel_Model class loaded
INFO - 2018-04-16 22:26:37 --> Database Driver Class Initialized
INFO - 2018-04-16 22:26:37 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:26:37 --> Pagination Class Initialized
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:26:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:26:37 --> Final output sent to browser
DEBUG - 2018-04-16 22:26:37 --> Total execution time: 0.4763
INFO - 2018-04-16 22:26:37 --> Config Class Initialized
INFO - 2018-04-16 22:26:37 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:26:37 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:26:37 --> Utf8 Class Initialized
INFO - 2018-04-16 22:26:37 --> URI Class Initialized
INFO - 2018-04-16 22:26:37 --> Router Class Initialized
INFO - 2018-04-16 22:26:37 --> Output Class Initialized
INFO - 2018-04-16 22:26:37 --> Security Class Initialized
DEBUG - 2018-04-16 22:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:26:37 --> CSRF cookie sent
INFO - 2018-04-16 22:26:37 --> Input Class Initialized
INFO - 2018-04-16 22:26:37 --> Language Class Initialized
ERROR - 2018-04-16 22:26:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:27:46 --> Config Class Initialized
INFO - 2018-04-16 22:27:46 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:27:46 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:27:46 --> Utf8 Class Initialized
INFO - 2018-04-16 22:27:46 --> URI Class Initialized
INFO - 2018-04-16 22:27:46 --> Router Class Initialized
INFO - 2018-04-16 22:27:46 --> Output Class Initialized
INFO - 2018-04-16 22:27:46 --> Security Class Initialized
DEBUG - 2018-04-16 22:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:27:46 --> CSRF cookie sent
INFO - 2018-04-16 22:27:46 --> Input Class Initialized
INFO - 2018-04-16 22:27:46 --> Language Class Initialized
INFO - 2018-04-16 22:27:47 --> Loader Class Initialized
INFO - 2018-04-16 22:27:47 --> Helper loaded: url_helper
INFO - 2018-04-16 22:27:47 --> Helper loaded: form_helper
INFO - 2018-04-16 22:27:47 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:27:47 --> User Agent Class Initialized
INFO - 2018-04-16 22:27:47 --> Controller Class Initialized
INFO - 2018-04-16 22:27:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:27:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:27:47 --> Pixel_Model class loaded
INFO - 2018-04-16 22:27:47 --> Database Driver Class Initialized
INFO - 2018-04-16 22:27:50 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:27:50 --> Pagination Class Initialized
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:27:50 --> Final output sent to browser
DEBUG - 2018-04-16 22:27:50 --> Total execution time: 3.5571
INFO - 2018-04-16 22:27:50 --> Config Class Initialized
INFO - 2018-04-16 22:27:50 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:27:50 --> Utf8 Class Initialized
INFO - 2018-04-16 22:27:50 --> URI Class Initialized
INFO - 2018-04-16 22:27:50 --> Router Class Initialized
INFO - 2018-04-16 22:27:50 --> Output Class Initialized
INFO - 2018-04-16 22:27:50 --> Security Class Initialized
DEBUG - 2018-04-16 22:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:27:50 --> CSRF cookie sent
INFO - 2018-04-16 22:27:50 --> Input Class Initialized
INFO - 2018-04-16 22:27:50 --> Language Class Initialized
ERROR - 2018-04-16 22:27:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:28:02 --> Config Class Initialized
INFO - 2018-04-16 22:28:02 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:02 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:02 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:02 --> URI Class Initialized
INFO - 2018-04-16 22:28:02 --> Router Class Initialized
INFO - 2018-04-16 22:28:02 --> Output Class Initialized
INFO - 2018-04-16 22:28:02 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:02 --> CSRF cookie sent
INFO - 2018-04-16 22:28:02 --> Input Class Initialized
INFO - 2018-04-16 22:28:02 --> Language Class Initialized
INFO - 2018-04-16 22:28:02 --> Loader Class Initialized
INFO - 2018-04-16 22:28:02 --> Helper loaded: url_helper
INFO - 2018-04-16 22:28:02 --> Helper loaded: form_helper
INFO - 2018-04-16 22:28:02 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:28:02 --> User Agent Class Initialized
INFO - 2018-04-16 22:28:02 --> Controller Class Initialized
INFO - 2018-04-16 22:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:28:02 --> Pixel_Model class loaded
INFO - 2018-04-16 22:28:02 --> Database Driver Class Initialized
INFO - 2018-04-16 22:28:02 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-16 22:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:28:02 --> Final output sent to browser
DEBUG - 2018-04-16 22:28:02 --> Total execution time: 0.4406
INFO - 2018-04-16 22:28:02 --> Config Class Initialized
INFO - 2018-04-16 22:28:02 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:02 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:02 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:02 --> URI Class Initialized
INFO - 2018-04-16 22:28:03 --> Router Class Initialized
INFO - 2018-04-16 22:28:03 --> Output Class Initialized
INFO - 2018-04-16 22:28:03 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:03 --> CSRF cookie sent
INFO - 2018-04-16 22:28:03 --> Input Class Initialized
INFO - 2018-04-16 22:28:03 --> Language Class Initialized
ERROR - 2018-04-16 22:28:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:28:06 --> Config Class Initialized
INFO - 2018-04-16 22:28:06 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:06 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:06 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:06 --> URI Class Initialized
INFO - 2018-04-16 22:28:06 --> Router Class Initialized
INFO - 2018-04-16 22:28:06 --> Output Class Initialized
INFO - 2018-04-16 22:28:06 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:06 --> CSRF cookie sent
INFO - 2018-04-16 22:28:06 --> CSRF token verified
INFO - 2018-04-16 22:28:06 --> Input Class Initialized
INFO - 2018-04-16 22:28:06 --> Language Class Initialized
INFO - 2018-04-16 22:28:06 --> Loader Class Initialized
INFO - 2018-04-16 22:28:06 --> Helper loaded: url_helper
INFO - 2018-04-16 22:28:06 --> Helper loaded: form_helper
INFO - 2018-04-16 22:28:06 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:28:06 --> User Agent Class Initialized
INFO - 2018-04-16 22:28:06 --> Controller Class Initialized
INFO - 2018-04-16 22:28:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:28:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:28:06 --> Form Validation Class Initialized
INFO - 2018-04-16 22:28:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-16 22:28:07 --> Pixel_Model class loaded
INFO - 2018-04-16 22:28:07 --> Database Driver Class Initialized
INFO - 2018-04-16 22:28:07 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:28:07 --> Config Class Initialized
INFO - 2018-04-16 22:28:07 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:07 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:07 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:07 --> URI Class Initialized
INFO - 2018-04-16 22:28:07 --> Router Class Initialized
INFO - 2018-04-16 22:28:07 --> Output Class Initialized
INFO - 2018-04-16 22:28:07 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:07 --> CSRF cookie sent
INFO - 2018-04-16 22:28:07 --> Input Class Initialized
INFO - 2018-04-16 22:28:07 --> Language Class Initialized
INFO - 2018-04-16 22:28:07 --> Loader Class Initialized
INFO - 2018-04-16 22:28:07 --> Helper loaded: url_helper
INFO - 2018-04-16 22:28:07 --> Helper loaded: form_helper
INFO - 2018-04-16 22:28:07 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:28:07 --> User Agent Class Initialized
INFO - 2018-04-16 22:28:07 --> Controller Class Initialized
INFO - 2018-04-16 22:28:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:28:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:28:07 --> Pixel_Model class loaded
INFO - 2018-04-16 22:28:07 --> Database Driver Class Initialized
INFO - 2018-04-16 22:28:07 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:28:07 --> Pagination Class Initialized
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:28:07 --> Final output sent to browser
DEBUG - 2018-04-16 22:28:07 --> Total execution time: 0.4096
INFO - 2018-04-16 22:28:07 --> Config Class Initialized
INFO - 2018-04-16 22:28:07 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:07 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:07 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:07 --> URI Class Initialized
INFO - 2018-04-16 22:28:08 --> Router Class Initialized
INFO - 2018-04-16 22:28:08 --> Output Class Initialized
INFO - 2018-04-16 22:28:08 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:08 --> CSRF cookie sent
INFO - 2018-04-16 22:28:08 --> Input Class Initialized
INFO - 2018-04-16 22:28:08 --> Language Class Initialized
ERROR - 2018-04-16 22:28:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:28:14 --> Config Class Initialized
INFO - 2018-04-16 22:28:14 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:14 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:14 --> URI Class Initialized
INFO - 2018-04-16 22:28:14 --> Router Class Initialized
INFO - 2018-04-16 22:28:14 --> Output Class Initialized
INFO - 2018-04-16 22:28:14 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:14 --> CSRF cookie sent
INFO - 2018-04-16 22:28:14 --> Input Class Initialized
INFO - 2018-04-16 22:28:14 --> Language Class Initialized
INFO - 2018-04-16 22:28:14 --> Loader Class Initialized
INFO - 2018-04-16 22:28:14 --> Helper loaded: url_helper
INFO - 2018-04-16 22:28:14 --> Helper loaded: form_helper
INFO - 2018-04-16 22:28:14 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:28:14 --> User Agent Class Initialized
INFO - 2018-04-16 22:28:14 --> Controller Class Initialized
INFO - 2018-04-16 22:28:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:28:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:28:14 --> Pixel_Model class loaded
INFO - 2018-04-16 22:28:14 --> Database Driver Class Initialized
INFO - 2018-04-16 22:28:14 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:28:14 --> Final output sent to browser
DEBUG - 2018-04-16 22:28:14 --> Total execution time: 0.4520
INFO - 2018-04-16 22:28:14 --> Config Class Initialized
INFO - 2018-04-16 22:28:14 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:28:14 --> Utf8 Class Initialized
INFO - 2018-04-16 22:28:14 --> URI Class Initialized
INFO - 2018-04-16 22:28:14 --> Router Class Initialized
INFO - 2018-04-16 22:28:14 --> Output Class Initialized
INFO - 2018-04-16 22:28:14 --> Security Class Initialized
DEBUG - 2018-04-16 22:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:28:14 --> CSRF cookie sent
INFO - 2018-04-16 22:28:14 --> Input Class Initialized
INFO - 2018-04-16 22:28:15 --> Language Class Initialized
ERROR - 2018-04-16 22:28:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:31:29 --> Config Class Initialized
INFO - 2018-04-16 22:31:29 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:31:29 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:31:29 --> Utf8 Class Initialized
INFO - 2018-04-16 22:31:29 --> URI Class Initialized
INFO - 2018-04-16 22:31:29 --> Router Class Initialized
INFO - 2018-04-16 22:31:29 --> Output Class Initialized
INFO - 2018-04-16 22:31:29 --> Security Class Initialized
DEBUG - 2018-04-16 22:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:31:29 --> CSRF cookie sent
INFO - 2018-04-16 22:31:29 --> Input Class Initialized
INFO - 2018-04-16 22:31:29 --> Language Class Initialized
INFO - 2018-04-16 22:31:29 --> Loader Class Initialized
INFO - 2018-04-16 22:31:29 --> Helper loaded: url_helper
INFO - 2018-04-16 22:31:29 --> Helper loaded: form_helper
INFO - 2018-04-16 22:31:29 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:31:30 --> User Agent Class Initialized
INFO - 2018-04-16 22:31:30 --> Controller Class Initialized
INFO - 2018-04-16 22:31:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:31:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:31:30 --> Pixel_Model class loaded
INFO - 2018-04-16 22:31:30 --> Database Driver Class Initialized
INFO - 2018-04-16 22:31:33 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:31:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:31:33 --> Final output sent to browser
DEBUG - 2018-04-16 22:31:33 --> Total execution time: 3.4959
INFO - 2018-04-16 22:31:33 --> Config Class Initialized
INFO - 2018-04-16 22:31:33 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:31:33 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:31:33 --> Utf8 Class Initialized
INFO - 2018-04-16 22:31:33 --> URI Class Initialized
INFO - 2018-04-16 22:31:33 --> Router Class Initialized
INFO - 2018-04-16 22:31:33 --> Output Class Initialized
INFO - 2018-04-16 22:31:33 --> Security Class Initialized
DEBUG - 2018-04-16 22:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:31:33 --> CSRF cookie sent
INFO - 2018-04-16 22:31:33 --> Input Class Initialized
INFO - 2018-04-16 22:31:33 --> Language Class Initialized
ERROR - 2018-04-16 22:31:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:33:57 --> Config Class Initialized
INFO - 2018-04-16 22:33:57 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:33:57 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:33:57 --> Utf8 Class Initialized
INFO - 2018-04-16 22:33:57 --> URI Class Initialized
INFO - 2018-04-16 22:33:57 --> Router Class Initialized
INFO - 2018-04-16 22:33:57 --> Output Class Initialized
INFO - 2018-04-16 22:33:57 --> Security Class Initialized
DEBUG - 2018-04-16 22:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:33:57 --> CSRF cookie sent
INFO - 2018-04-16 22:33:57 --> Input Class Initialized
INFO - 2018-04-16 22:33:57 --> Language Class Initialized
INFO - 2018-04-16 22:33:57 --> Loader Class Initialized
INFO - 2018-04-16 22:33:57 --> Helper loaded: url_helper
INFO - 2018-04-16 22:33:57 --> Helper loaded: form_helper
INFO - 2018-04-16 22:33:57 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:33:57 --> User Agent Class Initialized
INFO - 2018-04-16 22:33:57 --> Controller Class Initialized
INFO - 2018-04-16 22:33:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:33:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:33:57 --> Pixel_Model class loaded
INFO - 2018-04-16 22:33:57 --> Database Driver Class Initialized
INFO - 2018-04-16 22:34:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:34:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-16 22:34:00 --> Pagination Class Initialized
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-16 22:34:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:34:00 --> Final output sent to browser
DEBUG - 2018-04-16 22:34:00 --> Total execution time: 3.5172
INFO - 2018-04-16 22:34:00 --> Config Class Initialized
INFO - 2018-04-16 22:34:00 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:34:00 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:34:00 --> Utf8 Class Initialized
INFO - 2018-04-16 22:34:01 --> URI Class Initialized
INFO - 2018-04-16 22:34:01 --> Router Class Initialized
INFO - 2018-04-16 22:34:01 --> Output Class Initialized
INFO - 2018-04-16 22:34:01 --> Security Class Initialized
DEBUG - 2018-04-16 22:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:34:01 --> CSRF cookie sent
INFO - 2018-04-16 22:34:01 --> Input Class Initialized
INFO - 2018-04-16 22:34:01 --> Language Class Initialized
ERROR - 2018-04-16 22:34:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:36:18 --> Config Class Initialized
INFO - 2018-04-16 22:36:18 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:36:18 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:36:18 --> Utf8 Class Initialized
INFO - 2018-04-16 22:36:18 --> URI Class Initialized
INFO - 2018-04-16 22:36:18 --> Router Class Initialized
INFO - 2018-04-16 22:36:18 --> Output Class Initialized
INFO - 2018-04-16 22:36:18 --> Security Class Initialized
DEBUG - 2018-04-16 22:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:36:18 --> CSRF cookie sent
INFO - 2018-04-16 22:36:18 --> Input Class Initialized
INFO - 2018-04-16 22:36:18 --> Language Class Initialized
INFO - 2018-04-16 22:36:18 --> Loader Class Initialized
INFO - 2018-04-16 22:36:18 --> Helper loaded: url_helper
INFO - 2018-04-16 22:36:18 --> Helper loaded: form_helper
INFO - 2018-04-16 22:36:18 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:36:18 --> User Agent Class Initialized
INFO - 2018-04-16 22:36:18 --> Controller Class Initialized
INFO - 2018-04-16 22:36:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:36:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:36:18 --> Pixel_Model class loaded
INFO - 2018-04-16 22:36:18 --> Database Driver Class Initialized
INFO - 2018-04-16 22:36:21 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:36:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:36:21 --> Final output sent to browser
DEBUG - 2018-04-16 22:36:21 --> Total execution time: 3.5000
INFO - 2018-04-16 22:36:22 --> Config Class Initialized
INFO - 2018-04-16 22:36:22 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:36:22 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:36:22 --> Utf8 Class Initialized
INFO - 2018-04-16 22:36:22 --> URI Class Initialized
INFO - 2018-04-16 22:36:22 --> Router Class Initialized
INFO - 2018-04-16 22:36:22 --> Output Class Initialized
INFO - 2018-04-16 22:36:22 --> Security Class Initialized
DEBUG - 2018-04-16 22:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:36:22 --> CSRF cookie sent
INFO - 2018-04-16 22:36:22 --> Input Class Initialized
INFO - 2018-04-16 22:36:22 --> Language Class Initialized
ERROR - 2018-04-16 22:36:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:48:23 --> Config Class Initialized
INFO - 2018-04-16 22:48:23 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:48:23 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:48:23 --> Utf8 Class Initialized
INFO - 2018-04-16 22:48:23 --> URI Class Initialized
INFO - 2018-04-16 22:48:23 --> Router Class Initialized
INFO - 2018-04-16 22:48:23 --> Output Class Initialized
INFO - 2018-04-16 22:48:23 --> Security Class Initialized
DEBUG - 2018-04-16 22:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:48:23 --> CSRF cookie sent
INFO - 2018-04-16 22:48:23 --> Input Class Initialized
INFO - 2018-04-16 22:48:23 --> Language Class Initialized
INFO - 2018-04-16 22:48:23 --> Loader Class Initialized
INFO - 2018-04-16 22:48:23 --> Helper loaded: url_helper
INFO - 2018-04-16 22:48:23 --> Helper loaded: form_helper
INFO - 2018-04-16 22:48:23 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:48:23 --> User Agent Class Initialized
INFO - 2018-04-16 22:48:23 --> Controller Class Initialized
INFO - 2018-04-16 22:48:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:48:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:48:24 --> Pixel_Model class loaded
INFO - 2018-04-16 22:48:24 --> Database Driver Class Initialized
INFO - 2018-04-16 22:48:27 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:48:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:48:27 --> Final output sent to browser
DEBUG - 2018-04-16 22:48:27 --> Total execution time: 3.4952
INFO - 2018-04-16 22:48:27 --> Config Class Initialized
INFO - 2018-04-16 22:48:27 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:48:27 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:48:27 --> Utf8 Class Initialized
INFO - 2018-04-16 22:48:27 --> URI Class Initialized
INFO - 2018-04-16 22:48:27 --> Router Class Initialized
INFO - 2018-04-16 22:48:27 --> Output Class Initialized
INFO - 2018-04-16 22:48:27 --> Security Class Initialized
DEBUG - 2018-04-16 22:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:48:27 --> CSRF cookie sent
INFO - 2018-04-16 22:48:27 --> Input Class Initialized
INFO - 2018-04-16 22:48:27 --> Language Class Initialized
ERROR - 2018-04-16 22:48:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:48:57 --> Config Class Initialized
INFO - 2018-04-16 22:48:57 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:48:57 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:48:57 --> Utf8 Class Initialized
INFO - 2018-04-16 22:48:57 --> URI Class Initialized
INFO - 2018-04-16 22:48:57 --> Router Class Initialized
INFO - 2018-04-16 22:48:57 --> Output Class Initialized
INFO - 2018-04-16 22:48:57 --> Security Class Initialized
DEBUG - 2018-04-16 22:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:48:57 --> CSRF cookie sent
INFO - 2018-04-16 22:48:57 --> Input Class Initialized
INFO - 2018-04-16 22:48:57 --> Language Class Initialized
INFO - 2018-04-16 22:48:57 --> Loader Class Initialized
INFO - 2018-04-16 22:48:57 --> Helper loaded: url_helper
INFO - 2018-04-16 22:48:57 --> Helper loaded: form_helper
INFO - 2018-04-16 22:48:57 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:48:57 --> User Agent Class Initialized
INFO - 2018-04-16 22:48:57 --> Controller Class Initialized
INFO - 2018-04-16 22:48:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:48:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:48:57 --> Pixel_Model class loaded
INFO - 2018-04-16 22:48:57 --> Database Driver Class Initialized
INFO - 2018-04-16 22:49:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:49:00 --> Final output sent to browser
DEBUG - 2018-04-16 22:49:00 --> Total execution time: 3.4865
INFO - 2018-04-16 22:49:01 --> Config Class Initialized
INFO - 2018-04-16 22:49:01 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:49:01 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:49:01 --> Utf8 Class Initialized
INFO - 2018-04-16 22:49:01 --> URI Class Initialized
INFO - 2018-04-16 22:49:01 --> Router Class Initialized
INFO - 2018-04-16 22:49:01 --> Output Class Initialized
INFO - 2018-04-16 22:49:01 --> Security Class Initialized
DEBUG - 2018-04-16 22:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:49:01 --> CSRF cookie sent
INFO - 2018-04-16 22:49:01 --> Input Class Initialized
INFO - 2018-04-16 22:49:01 --> Language Class Initialized
ERROR - 2018-04-16 22:49:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:49:31 --> Config Class Initialized
INFO - 2018-04-16 22:49:31 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:49:31 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:49:32 --> Utf8 Class Initialized
INFO - 2018-04-16 22:49:32 --> URI Class Initialized
INFO - 2018-04-16 22:49:32 --> Router Class Initialized
INFO - 2018-04-16 22:49:32 --> Output Class Initialized
INFO - 2018-04-16 22:49:32 --> Security Class Initialized
DEBUG - 2018-04-16 22:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:49:32 --> CSRF cookie sent
INFO - 2018-04-16 22:49:32 --> Input Class Initialized
INFO - 2018-04-16 22:49:32 --> Language Class Initialized
INFO - 2018-04-16 22:49:32 --> Loader Class Initialized
INFO - 2018-04-16 22:49:32 --> Helper loaded: url_helper
INFO - 2018-04-16 22:49:32 --> Helper loaded: form_helper
INFO - 2018-04-16 22:49:32 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:49:32 --> User Agent Class Initialized
INFO - 2018-04-16 22:49:32 --> Controller Class Initialized
INFO - 2018-04-16 22:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:49:32 --> Pixel_Model class loaded
INFO - 2018-04-16 22:49:32 --> Database Driver Class Initialized
INFO - 2018-04-16 22:49:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 22:49:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:49:32 --> Final output sent to browser
DEBUG - 2018-04-16 22:49:32 --> Total execution time: 0.5040
INFO - 2018-04-16 22:49:32 --> Config Class Initialized
INFO - 2018-04-16 22:49:32 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:49:32 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:49:32 --> Utf8 Class Initialized
INFO - 2018-04-16 22:49:32 --> URI Class Initialized
INFO - 2018-04-16 22:49:32 --> Router Class Initialized
INFO - 2018-04-16 22:49:32 --> Output Class Initialized
INFO - 2018-04-16 22:49:32 --> Security Class Initialized
DEBUG - 2018-04-16 22:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:49:32 --> CSRF cookie sent
INFO - 2018-04-16 22:49:32 --> Input Class Initialized
INFO - 2018-04-16 22:49:32 --> Language Class Initialized
ERROR - 2018-04-16 22:49:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 22:55:34 --> Config Class Initialized
INFO - 2018-04-16 22:55:34 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:55:34 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:55:34 --> Utf8 Class Initialized
INFO - 2018-04-16 22:55:34 --> URI Class Initialized
INFO - 2018-04-16 22:55:34 --> Router Class Initialized
INFO - 2018-04-16 22:55:34 --> Output Class Initialized
INFO - 2018-04-16 22:55:34 --> Security Class Initialized
DEBUG - 2018-04-16 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:55:34 --> CSRF cookie sent
INFO - 2018-04-16 22:55:34 --> Input Class Initialized
INFO - 2018-04-16 22:55:34 --> Language Class Initialized
INFO - 2018-04-16 22:55:34 --> Loader Class Initialized
INFO - 2018-04-16 22:55:34 --> Helper loaded: url_helper
INFO - 2018-04-16 22:55:34 --> Helper loaded: form_helper
INFO - 2018-04-16 22:55:34 --> Helper loaded: language_helper
DEBUG - 2018-04-16 22:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 22:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 22:55:34 --> User Agent Class Initialized
INFO - 2018-04-16 22:55:34 --> Controller Class Initialized
INFO - 2018-04-16 22:55:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 22:55:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 22:55:34 --> Pixel_Model class loaded
INFO - 2018-04-16 22:55:34 --> Database Driver Class Initialized
INFO - 2018-04-16 22:55:37 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 22:55:37 --> Could not find the language line "req_email"
ERROR - 2018-04-16 22:55:37 --> Severity: Notice --> Undefined variable: provinces E:\www\yacopoo\application\views\register\add_client.php 59
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-16 22:55:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 22:55:37 --> Final output sent to browser
DEBUG - 2018-04-16 22:55:38 --> Total execution time: 3.5108
INFO - 2018-04-16 22:55:38 --> Config Class Initialized
INFO - 2018-04-16 22:55:38 --> Hooks Class Initialized
DEBUG - 2018-04-16 22:55:38 --> UTF-8 Support Enabled
INFO - 2018-04-16 22:55:38 --> Utf8 Class Initialized
INFO - 2018-04-16 22:55:38 --> URI Class Initialized
INFO - 2018-04-16 22:55:38 --> Router Class Initialized
INFO - 2018-04-16 22:55:38 --> Output Class Initialized
INFO - 2018-04-16 22:55:38 --> Security Class Initialized
DEBUG - 2018-04-16 22:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 22:55:38 --> CSRF cookie sent
INFO - 2018-04-16 22:55:38 --> Input Class Initialized
INFO - 2018-04-16 22:55:38 --> Language Class Initialized
ERROR - 2018-04-16 22:55:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:24:01 --> Config Class Initialized
INFO - 2018-04-16 23:24:01 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:24:01 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:24:01 --> Utf8 Class Initialized
INFO - 2018-04-16 23:24:01 --> URI Class Initialized
INFO - 2018-04-16 23:24:01 --> Router Class Initialized
INFO - 2018-04-16 23:24:01 --> Output Class Initialized
INFO - 2018-04-16 23:24:01 --> Security Class Initialized
DEBUG - 2018-04-16 23:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:24:01 --> CSRF cookie sent
INFO - 2018-04-16 23:24:01 --> Input Class Initialized
INFO - 2018-04-16 23:24:01 --> Language Class Initialized
INFO - 2018-04-16 23:24:01 --> Loader Class Initialized
INFO - 2018-04-16 23:24:01 --> Helper loaded: url_helper
INFO - 2018-04-16 23:24:01 --> Helper loaded: form_helper
INFO - 2018-04-16 23:24:01 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:24:01 --> User Agent Class Initialized
INFO - 2018-04-16 23:24:01 --> Controller Class Initialized
INFO - 2018-04-16 23:24:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:24:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:24:01 --> Pixel_Model class loaded
INFO - 2018-04-16 23:24:01 --> Database Driver Class Initialized
INFO - 2018-04-16 23:24:04 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:24:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:24:04 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:24:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:24:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:24:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 23:24:05 --> Could not find the language line "req_email"
INFO - 2018-04-16 23:24:05 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-16 23:24:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:24:05 --> Final output sent to browser
DEBUG - 2018-04-16 23:24:05 --> Total execution time: 3.5076
INFO - 2018-04-16 23:24:05 --> Config Class Initialized
INFO - 2018-04-16 23:24:05 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:24:05 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:24:05 --> Utf8 Class Initialized
INFO - 2018-04-16 23:24:05 --> URI Class Initialized
INFO - 2018-04-16 23:24:05 --> Router Class Initialized
INFO - 2018-04-16 23:24:05 --> Output Class Initialized
INFO - 2018-04-16 23:24:05 --> Security Class Initialized
DEBUG - 2018-04-16 23:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:24:05 --> CSRF cookie sent
INFO - 2018-04-16 23:24:05 --> Input Class Initialized
INFO - 2018-04-16 23:24:05 --> Language Class Initialized
ERROR - 2018-04-16 23:24:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:33:02 --> Config Class Initialized
INFO - 2018-04-16 23:33:02 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:02 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:02 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:02 --> URI Class Initialized
INFO - 2018-04-16 23:33:02 --> Router Class Initialized
INFO - 2018-04-16 23:33:02 --> Output Class Initialized
INFO - 2018-04-16 23:33:02 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:02 --> CSRF cookie sent
INFO - 2018-04-16 23:33:02 --> Input Class Initialized
INFO - 2018-04-16 23:33:02 --> Language Class Initialized
INFO - 2018-04-16 23:33:02 --> Loader Class Initialized
INFO - 2018-04-16 23:33:02 --> Helper loaded: url_helper
INFO - 2018-04-16 23:33:02 --> Helper loaded: form_helper
INFO - 2018-04-16 23:33:02 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:33:02 --> User Agent Class Initialized
INFO - 2018-04-16 23:33:02 --> Controller Class Initialized
INFO - 2018-04-16 23:33:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:33:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:33:02 --> Pixel_Model class loaded
INFO - 2018-04-16 23:33:02 --> Database Driver Class Initialized
INFO - 2018-04-16 23:33:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-16 23:33:05 --> Could not find the language line "req_email"
INFO - 2018-04-16 23:33:05 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-16 23:33:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:33:06 --> Final output sent to browser
DEBUG - 2018-04-16 23:33:06 --> Total execution time: 3.5259
INFO - 2018-04-16 23:33:06 --> Config Class Initialized
INFO - 2018-04-16 23:33:06 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:06 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:06 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:06 --> URI Class Initialized
INFO - 2018-04-16 23:33:06 --> Router Class Initialized
INFO - 2018-04-16 23:33:06 --> Output Class Initialized
INFO - 2018-04-16 23:33:06 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:06 --> CSRF cookie sent
INFO - 2018-04-16 23:33:06 --> Input Class Initialized
INFO - 2018-04-16 23:33:06 --> Language Class Initialized
ERROR - 2018-04-16 23:33:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:33:23 --> Config Class Initialized
INFO - 2018-04-16 23:33:23 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:23 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:23 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:23 --> URI Class Initialized
INFO - 2018-04-16 23:33:23 --> Router Class Initialized
INFO - 2018-04-16 23:33:23 --> Output Class Initialized
INFO - 2018-04-16 23:33:23 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:23 --> CSRF cookie sent
INFO - 2018-04-16 23:33:23 --> CSRF token verified
INFO - 2018-04-16 23:33:23 --> Input Class Initialized
INFO - 2018-04-16 23:33:23 --> Language Class Initialized
INFO - 2018-04-16 23:33:23 --> Loader Class Initialized
INFO - 2018-04-16 23:33:23 --> Helper loaded: url_helper
INFO - 2018-04-16 23:33:23 --> Helper loaded: form_helper
INFO - 2018-04-16 23:33:23 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:33:23 --> User Agent Class Initialized
INFO - 2018-04-16 23:33:23 --> Controller Class Initialized
INFO - 2018-04-16 23:33:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:33:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:33:23 --> Form Validation Class Initialized
INFO - 2018-04-16 23:33:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-16 23:33:23 --> Pixel_Model class loaded
INFO - 2018-04-16 23:33:23 --> Database Driver Class Initialized
INFO - 2018-04-16 23:33:23 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 23:33:23 --> Database Driver Class Initialized
INFO - 2018-04-16 23:33:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:33:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:33:23 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
ERROR - 2018-04-16 23:33:24 --> Could not find the language line "req_email"
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-16 23:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:33:24 --> Final output sent to browser
DEBUG - 2018-04-16 23:33:24 --> Total execution time: 0.5503
INFO - 2018-04-16 23:33:24 --> Config Class Initialized
INFO - 2018-04-16 23:33:24 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:24 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:24 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:24 --> URI Class Initialized
INFO - 2018-04-16 23:33:24 --> Router Class Initialized
INFO - 2018-04-16 23:33:24 --> Output Class Initialized
INFO - 2018-04-16 23:33:24 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:24 --> CSRF cookie sent
INFO - 2018-04-16 23:33:24 --> Input Class Initialized
INFO - 2018-04-16 23:33:24 --> Language Class Initialized
ERROR - 2018-04-16 23:33:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:33:39 --> Config Class Initialized
INFO - 2018-04-16 23:33:39 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:39 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:39 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:39 --> URI Class Initialized
INFO - 2018-04-16 23:33:39 --> Router Class Initialized
INFO - 2018-04-16 23:33:39 --> Output Class Initialized
INFO - 2018-04-16 23:33:39 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:39 --> CSRF cookie sent
INFO - 2018-04-16 23:33:39 --> CSRF token verified
INFO - 2018-04-16 23:33:39 --> Input Class Initialized
INFO - 2018-04-16 23:33:39 --> Language Class Initialized
INFO - 2018-04-16 23:33:40 --> Loader Class Initialized
INFO - 2018-04-16 23:33:40 --> Helper loaded: url_helper
INFO - 2018-04-16 23:33:40 --> Helper loaded: form_helper
INFO - 2018-04-16 23:33:40 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:33:40 --> User Agent Class Initialized
INFO - 2018-04-16 23:33:40 --> Controller Class Initialized
INFO - 2018-04-16 23:33:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:33:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:33:40 --> Form Validation Class Initialized
INFO - 2018-04-16 23:33:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-16 23:33:40 --> Pixel_Model class loaded
INFO - 2018-04-16 23:33:40 --> Database Driver Class Initialized
INFO - 2018-04-16 23:33:40 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 23:33:40 --> Helper loaded: string_helper
INFO - 2018-04-16 23:33:40 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-16 23:33:40 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 23:33:40 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 23:33:40 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 23:33:40 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-16 23:33:40 --> Email Class Initialized
ERROR - 2018-04-16 23:33:41 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-16 23:33:41 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-16 23:33:41 --> Config Class Initialized
INFO - 2018-04-16 23:33:41 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:41 --> URI Class Initialized
INFO - 2018-04-16 23:33:41 --> Router Class Initialized
INFO - 2018-04-16 23:33:41 --> Output Class Initialized
INFO - 2018-04-16 23:33:41 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:41 --> CSRF cookie sent
INFO - 2018-04-16 23:33:41 --> Input Class Initialized
INFO - 2018-04-16 23:33:41 --> Language Class Initialized
INFO - 2018-04-16 23:33:41 --> Loader Class Initialized
INFO - 2018-04-16 23:33:42 --> Helper loaded: url_helper
INFO - 2018-04-16 23:33:42 --> Helper loaded: form_helper
INFO - 2018-04-16 23:33:42 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:33:42 --> User Agent Class Initialized
INFO - 2018-04-16 23:33:42 --> Controller Class Initialized
INFO - 2018-04-16 23:33:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:33:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:33:42 --> Pixel_Model class loaded
INFO - 2018-04-16 23:33:42 --> Database Driver Class Initialized
INFO - 2018-04-16 23:33:42 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-16 23:33:42 --> Could not find the language line "req_email"
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-16 23:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:33:42 --> Final output sent to browser
DEBUG - 2018-04-16 23:33:42 --> Total execution time: 0.6606
INFO - 2018-04-16 23:33:42 --> Config Class Initialized
INFO - 2018-04-16 23:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:33:42 --> Utf8 Class Initialized
INFO - 2018-04-16 23:33:42 --> URI Class Initialized
INFO - 2018-04-16 23:33:42 --> Router Class Initialized
INFO - 2018-04-16 23:33:42 --> Output Class Initialized
INFO - 2018-04-16 23:33:43 --> Security Class Initialized
DEBUG - 2018-04-16 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:33:43 --> CSRF cookie sent
INFO - 2018-04-16 23:33:43 --> Input Class Initialized
INFO - 2018-04-16 23:33:43 --> Language Class Initialized
ERROR - 2018-04-16 23:33:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:35:16 --> Config Class Initialized
INFO - 2018-04-16 23:35:16 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:35:16 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:35:16 --> Utf8 Class Initialized
INFO - 2018-04-16 23:35:17 --> URI Class Initialized
INFO - 2018-04-16 23:35:17 --> Router Class Initialized
INFO - 2018-04-16 23:35:17 --> Output Class Initialized
INFO - 2018-04-16 23:35:17 --> Security Class Initialized
DEBUG - 2018-04-16 23:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:35:17 --> CSRF cookie sent
INFO - 2018-04-16 23:35:17 --> Input Class Initialized
INFO - 2018-04-16 23:35:17 --> Language Class Initialized
INFO - 2018-04-16 23:35:17 --> Loader Class Initialized
INFO - 2018-04-16 23:35:17 --> Helper loaded: url_helper
INFO - 2018-04-16 23:35:17 --> Helper loaded: form_helper
INFO - 2018-04-16 23:35:17 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:35:17 --> User Agent Class Initialized
INFO - 2018-04-16 23:35:17 --> Controller Class Initialized
INFO - 2018-04-16 23:35:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:35:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:35:17 --> Pixel_Model class loaded
INFO - 2018-04-16 23:35:17 --> Database Driver Class Initialized
INFO - 2018-04-16 23:35:20 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 23:35:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:35:20 --> Final output sent to browser
DEBUG - 2018-04-16 23:35:20 --> Total execution time: 3.4915
INFO - 2018-04-16 23:35:20 --> Config Class Initialized
INFO - 2018-04-16 23:35:20 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:35:20 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:35:20 --> Utf8 Class Initialized
INFO - 2018-04-16 23:35:20 --> URI Class Initialized
INFO - 2018-04-16 23:35:20 --> Router Class Initialized
INFO - 2018-04-16 23:35:20 --> Output Class Initialized
INFO - 2018-04-16 23:35:20 --> Security Class Initialized
DEBUG - 2018-04-16 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:35:20 --> CSRF cookie sent
INFO - 2018-04-16 23:35:20 --> Input Class Initialized
INFO - 2018-04-16 23:35:20 --> Language Class Initialized
ERROR - 2018-04-16 23:35:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-16 23:35:25 --> Config Class Initialized
INFO - 2018-04-16 23:35:25 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:35:25 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:35:25 --> Utf8 Class Initialized
INFO - 2018-04-16 23:35:25 --> URI Class Initialized
INFO - 2018-04-16 23:35:25 --> Router Class Initialized
INFO - 2018-04-16 23:35:25 --> Output Class Initialized
INFO - 2018-04-16 23:35:25 --> Security Class Initialized
DEBUG - 2018-04-16 23:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:35:25 --> CSRF cookie sent
INFO - 2018-04-16 23:35:25 --> CSRF token verified
INFO - 2018-04-16 23:35:25 --> Input Class Initialized
INFO - 2018-04-16 23:35:25 --> Language Class Initialized
INFO - 2018-04-16 23:35:25 --> Loader Class Initialized
INFO - 2018-04-16 23:35:25 --> Helper loaded: url_helper
INFO - 2018-04-16 23:35:25 --> Helper loaded: form_helper
INFO - 2018-04-16 23:35:25 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:35:25 --> User Agent Class Initialized
INFO - 2018-04-16 23:35:25 --> Controller Class Initialized
INFO - 2018-04-16 23:35:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:35:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:35:25 --> Upload Class Initialized
INFO - 2018-04-16 23:35:25 --> Pixel_Model class loaded
INFO - 2018-04-16 23:35:25 --> Database Driver Class Initialized
INFO - 2018-04-16 23:35:25 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 23:35:25 --> Database Driver Class Initialized
INFO - 2018-04-16 23:35:25 --> Model "RegistrationModel" initialized
INFO - 2018-04-16 23:35:25 --> Helper loaded: string_helper
INFO - 2018-04-16 23:35:25 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-16 23:35:26 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 23:35:26 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 23:35:26 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 23:35:26 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-16 23:35:26 --> Email Class Initialized
ERROR - 2018-04-16 23:35:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-16 23:35:27 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-04-16 23:35:27 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-16 23:35:27 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-16 23:35:27 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-16 23:35:27 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-16 23:35:27 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-16 23:35:27 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-16 23:35:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-16 23:35:28 --> Config Class Initialized
INFO - 2018-04-16 23:35:28 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:35:28 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:35:28 --> Utf8 Class Initialized
INFO - 2018-04-16 23:35:28 --> URI Class Initialized
INFO - 2018-04-16 23:35:28 --> Router Class Initialized
INFO - 2018-04-16 23:35:28 --> Output Class Initialized
INFO - 2018-04-16 23:35:28 --> Security Class Initialized
DEBUG - 2018-04-16 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:35:28 --> CSRF cookie sent
INFO - 2018-04-16 23:35:28 --> Input Class Initialized
INFO - 2018-04-16 23:35:28 --> Language Class Initialized
INFO - 2018-04-16 23:35:28 --> Loader Class Initialized
INFO - 2018-04-16 23:35:29 --> Helper loaded: url_helper
INFO - 2018-04-16 23:35:29 --> Helper loaded: form_helper
INFO - 2018-04-16 23:35:29 --> Helper loaded: language_helper
DEBUG - 2018-04-16 23:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-16 23:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-16 23:35:29 --> User Agent Class Initialized
INFO - 2018-04-16 23:35:29 --> Controller Class Initialized
INFO - 2018-04-16 23:35:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-16 23:35:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-16 23:35:29 --> Pixel_Model class loaded
INFO - 2018-04-16 23:35:29 --> Database Driver Class Initialized
INFO - 2018-04-16 23:35:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-16 23:35:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-16 23:35:29 --> Final output sent to browser
DEBUG - 2018-04-16 23:35:29 --> Total execution time: 0.6519
INFO - 2018-04-16 23:35:29 --> Config Class Initialized
INFO - 2018-04-16 23:35:29 --> Hooks Class Initialized
DEBUG - 2018-04-16 23:35:29 --> UTF-8 Support Enabled
INFO - 2018-04-16 23:35:29 --> Utf8 Class Initialized
INFO - 2018-04-16 23:35:29 --> URI Class Initialized
INFO - 2018-04-16 23:35:29 --> Router Class Initialized
INFO - 2018-04-16 23:35:29 --> Output Class Initialized
INFO - 2018-04-16 23:35:29 --> Security Class Initialized
DEBUG - 2018-04-16 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-16 23:35:29 --> CSRF cookie sent
INFO - 2018-04-16 23:35:29 --> Input Class Initialized
INFO - 2018-04-16 23:35:30 --> Language Class Initialized
ERROR - 2018-04-16 23:35:30 --> 404 Page Not Found: Assets/css

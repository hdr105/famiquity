<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-20 00:37:09 --> Config Class Initialized
INFO - 2018-04-20 00:37:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:37:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:37:09 --> Utf8 Class Initialized
INFO - 2018-04-20 00:37:09 --> URI Class Initialized
INFO - 2018-04-20 00:37:09 --> Router Class Initialized
INFO - 2018-04-20 00:37:09 --> Output Class Initialized
INFO - 2018-04-20 00:37:09 --> Security Class Initialized
DEBUG - 2018-04-20 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:37:09 --> CSRF cookie sent
INFO - 2018-04-20 00:37:09 --> Input Class Initialized
INFO - 2018-04-20 00:37:09 --> Language Class Initialized
INFO - 2018-04-20 00:37:09 --> Loader Class Initialized
INFO - 2018-04-20 00:37:09 --> Helper loaded: url_helper
INFO - 2018-04-20 00:37:09 --> Helper loaded: form_helper
INFO - 2018-04-20 00:37:09 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:37:09 --> User Agent Class Initialized
INFO - 2018-04-20 00:37:09 --> Controller Class Initialized
INFO - 2018-04-20 00:37:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:37:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:37:09 --> Pixel_Model class loaded
INFO - 2018-04-20 00:37:09 --> Database Driver Class Initialized
INFO - 2018-04-20 00:37:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:37:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:37:10 --> Final output sent to browser
DEBUG - 2018-04-20 00:37:10 --> Total execution time: 0.4222
INFO - 2018-04-20 00:40:23 --> Config Class Initialized
INFO - 2018-04-20 00:40:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:23 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:23 --> URI Class Initialized
INFO - 2018-04-20 00:40:23 --> Router Class Initialized
INFO - 2018-04-20 00:40:23 --> Output Class Initialized
INFO - 2018-04-20 00:40:23 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:23 --> CSRF cookie sent
INFO - 2018-04-20 00:40:23 --> Input Class Initialized
INFO - 2018-04-20 00:40:23 --> Language Class Initialized
INFO - 2018-04-20 00:40:23 --> Loader Class Initialized
INFO - 2018-04-20 00:40:23 --> Helper loaded: url_helper
INFO - 2018-04-20 00:40:23 --> Helper loaded: form_helper
INFO - 2018-04-20 00:40:23 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:40:23 --> User Agent Class Initialized
INFO - 2018-04-20 00:40:23 --> Controller Class Initialized
INFO - 2018-04-20 00:40:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:40:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:40:23 --> Pixel_Model class loaded
INFO - 2018-04-20 00:40:23 --> Database Driver Class Initialized
INFO - 2018-04-20 00:40:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:40:23 --> Config Class Initialized
INFO - 2018-04-20 00:40:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:23 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:23 --> URI Class Initialized
INFO - 2018-04-20 00:40:23 --> Router Class Initialized
INFO - 2018-04-20 00:40:23 --> Output Class Initialized
INFO - 2018-04-20 00:40:23 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:23 --> CSRF cookie sent
INFO - 2018-04-20 00:40:23 --> Input Class Initialized
INFO - 2018-04-20 00:40:23 --> Language Class Initialized
ERROR - 2018-04-20 00:40:23 --> 404 Page Not Found: Short-questions/index
INFO - 2018-04-20 00:40:29 --> Config Class Initialized
INFO - 2018-04-20 00:40:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:29 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:29 --> URI Class Initialized
INFO - 2018-04-20 00:40:29 --> Router Class Initialized
INFO - 2018-04-20 00:40:29 --> Output Class Initialized
INFO - 2018-04-20 00:40:29 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:29 --> CSRF cookie sent
INFO - 2018-04-20 00:40:29 --> Input Class Initialized
INFO - 2018-04-20 00:40:29 --> Language Class Initialized
INFO - 2018-04-20 00:40:29 --> Loader Class Initialized
INFO - 2018-04-20 00:40:29 --> Helper loaded: url_helper
INFO - 2018-04-20 00:40:29 --> Helper loaded: form_helper
INFO - 2018-04-20 00:40:29 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:40:29 --> User Agent Class Initialized
INFO - 2018-04-20 00:40:29 --> Controller Class Initialized
INFO - 2018-04-20 00:40:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:40:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:40:29 --> Pixel_Model class loaded
INFO - 2018-04-20 00:40:29 --> Database Driver Class Initialized
INFO - 2018-04-20 00:40:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:40:29 --> Final output sent to browser
DEBUG - 2018-04-20 00:40:29 --> Total execution time: 0.2955
INFO - 2018-04-20 00:40:32 --> Config Class Initialized
INFO - 2018-04-20 00:40:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:32 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:32 --> URI Class Initialized
INFO - 2018-04-20 00:40:32 --> Router Class Initialized
INFO - 2018-04-20 00:40:32 --> Output Class Initialized
INFO - 2018-04-20 00:40:32 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:32 --> CSRF cookie sent
INFO - 2018-04-20 00:40:32 --> Input Class Initialized
INFO - 2018-04-20 00:40:32 --> Language Class Initialized
INFO - 2018-04-20 00:40:32 --> Loader Class Initialized
INFO - 2018-04-20 00:40:32 --> Helper loaded: url_helper
INFO - 2018-04-20 00:40:32 --> Helper loaded: form_helper
INFO - 2018-04-20 00:40:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:40:32 --> User Agent Class Initialized
INFO - 2018-04-20 00:40:32 --> Controller Class Initialized
INFO - 2018-04-20 00:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:40:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:40:32 --> Pixel_Model class loaded
INFO - 2018-04-20 00:40:32 --> Database Driver Class Initialized
INFO - 2018-04-20 00:40:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:40:32 --> Config Class Initialized
INFO - 2018-04-20 00:40:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:32 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:32 --> URI Class Initialized
INFO - 2018-04-20 00:40:32 --> Router Class Initialized
INFO - 2018-04-20 00:40:32 --> Output Class Initialized
INFO - 2018-04-20 00:40:32 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:32 --> CSRF cookie sent
INFO - 2018-04-20 00:40:32 --> Input Class Initialized
INFO - 2018-04-20 00:40:32 --> Language Class Initialized
INFO - 2018-04-20 00:40:32 --> Loader Class Initialized
INFO - 2018-04-20 00:40:32 --> Helper loaded: url_helper
INFO - 2018-04-20 00:40:32 --> Helper loaded: form_helper
INFO - 2018-04-20 00:40:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:40:32 --> User Agent Class Initialized
INFO - 2018-04-20 00:40:32 --> Controller Class Initialized
INFO - 2018-04-20 00:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:40:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:40:32 --> Pixel_Model class loaded
INFO - 2018-04-20 00:40:32 --> Database Driver Class Initialized
INFO - 2018-04-20 00:40:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-20 00:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:40:32 --> Final output sent to browser
DEBUG - 2018-04-20 00:40:32 --> Total execution time: 0.2838
INFO - 2018-04-20 00:40:41 --> Config Class Initialized
INFO - 2018-04-20 00:40:42 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:42 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:42 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:42 --> URI Class Initialized
INFO - 2018-04-20 00:40:42 --> Router Class Initialized
INFO - 2018-04-20 00:40:42 --> Output Class Initialized
INFO - 2018-04-20 00:40:42 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:42 --> CSRF cookie sent
INFO - 2018-04-20 00:40:42 --> Input Class Initialized
INFO - 2018-04-20 00:40:42 --> Language Class Initialized
ERROR - 2018-04-20 00:40:42 --> 404 Page Not Found: Short-question/index
INFO - 2018-04-20 00:40:46 --> Config Class Initialized
INFO - 2018-04-20 00:40:47 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:40:47 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:40:47 --> Utf8 Class Initialized
INFO - 2018-04-20 00:40:47 --> URI Class Initialized
INFO - 2018-04-20 00:40:47 --> Router Class Initialized
INFO - 2018-04-20 00:40:47 --> Output Class Initialized
INFO - 2018-04-20 00:40:47 --> Security Class Initialized
DEBUG - 2018-04-20 00:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:40:47 --> CSRF cookie sent
INFO - 2018-04-20 00:40:47 --> Input Class Initialized
INFO - 2018-04-20 00:40:47 --> Language Class Initialized
ERROR - 2018-04-20 00:40:47 --> 404 Page Not Found: Short-questions/index
INFO - 2018-04-20 00:42:18 --> Config Class Initialized
INFO - 2018-04-20 00:42:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:42:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:42:18 --> Utf8 Class Initialized
INFO - 2018-04-20 00:42:18 --> URI Class Initialized
INFO - 2018-04-20 00:42:18 --> Router Class Initialized
INFO - 2018-04-20 00:42:18 --> Output Class Initialized
INFO - 2018-04-20 00:42:18 --> Security Class Initialized
DEBUG - 2018-04-20 00:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:42:18 --> CSRF cookie sent
INFO - 2018-04-20 00:42:18 --> Input Class Initialized
INFO - 2018-04-20 00:42:18 --> Language Class Initialized
INFO - 2018-04-20 00:42:18 --> Loader Class Initialized
INFO - 2018-04-20 00:42:18 --> Helper loaded: url_helper
INFO - 2018-04-20 00:42:18 --> Helper loaded: form_helper
INFO - 2018-04-20 00:42:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:42:18 --> User Agent Class Initialized
INFO - 2018-04-20 00:42:18 --> Controller Class Initialized
INFO - 2018-04-20 00:42:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:42:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:42:18 --> Pixel_Model class loaded
INFO - 2018-04-20 00:42:18 --> Database Driver Class Initialized
INFO - 2018-04-20 00:42:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:42:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:42:18 --> Final output sent to browser
DEBUG - 2018-04-20 00:42:18 --> Total execution time: 0.3084
INFO - 2018-04-20 00:43:55 --> Config Class Initialized
INFO - 2018-04-20 00:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:43:55 --> Utf8 Class Initialized
INFO - 2018-04-20 00:43:55 --> URI Class Initialized
INFO - 2018-04-20 00:43:55 --> Router Class Initialized
INFO - 2018-04-20 00:43:55 --> Output Class Initialized
INFO - 2018-04-20 00:43:55 --> Security Class Initialized
DEBUG - 2018-04-20 00:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:43:55 --> CSRF cookie sent
INFO - 2018-04-20 00:43:55 --> CSRF token verified
INFO - 2018-04-20 00:43:55 --> Input Class Initialized
INFO - 2018-04-20 00:43:55 --> Language Class Initialized
INFO - 2018-04-20 00:43:55 --> Loader Class Initialized
INFO - 2018-04-20 00:43:55 --> Helper loaded: url_helper
INFO - 2018-04-20 00:43:55 --> Helper loaded: form_helper
INFO - 2018-04-20 00:43:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:43:55 --> User Agent Class Initialized
INFO - 2018-04-20 00:43:55 --> Controller Class Initialized
INFO - 2018-04-20 00:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:43:55 --> Pixel_Model class loaded
INFO - 2018-04-20 00:43:55 --> Database Driver Class Initialized
INFO - 2018-04-20 00:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:43:55 --> Form Validation Class Initialized
INFO - 2018-04-20 00:43:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:43:55 --> Config Class Initialized
INFO - 2018-04-20 00:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:43:55 --> Utf8 Class Initialized
INFO - 2018-04-20 00:43:55 --> URI Class Initialized
INFO - 2018-04-20 00:43:55 --> Router Class Initialized
INFO - 2018-04-20 00:43:55 --> Output Class Initialized
INFO - 2018-04-20 00:43:55 --> Security Class Initialized
DEBUG - 2018-04-20 00:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:43:55 --> CSRF cookie sent
INFO - 2018-04-20 00:43:55 --> Input Class Initialized
INFO - 2018-04-20 00:43:55 --> Language Class Initialized
INFO - 2018-04-20 00:43:55 --> Loader Class Initialized
INFO - 2018-04-20 00:43:56 --> Helper loaded: url_helper
INFO - 2018-04-20 00:43:56 --> Helper loaded: form_helper
INFO - 2018-04-20 00:43:56 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:43:56 --> User Agent Class Initialized
INFO - 2018-04-20 00:43:56 --> Controller Class Initialized
INFO - 2018-04-20 00:43:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:43:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:43:56 --> Pixel_Model class loaded
INFO - 2018-04-20 00:43:56 --> Database Driver Class Initialized
INFO - 2018-04-20 00:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:43:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:43:56 --> Final output sent to browser
DEBUG - 2018-04-20 00:43:56 --> Total execution time: 0.2881
INFO - 2018-04-20 00:44:07 --> Config Class Initialized
INFO - 2018-04-20 00:44:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:07 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:07 --> URI Class Initialized
INFO - 2018-04-20 00:44:07 --> Router Class Initialized
INFO - 2018-04-20 00:44:07 --> Output Class Initialized
INFO - 2018-04-20 00:44:07 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:07 --> CSRF cookie sent
INFO - 2018-04-20 00:44:07 --> Input Class Initialized
INFO - 2018-04-20 00:44:08 --> Language Class Initialized
INFO - 2018-04-20 00:44:08 --> Loader Class Initialized
INFO - 2018-04-20 00:44:08 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:08 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:08 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:08 --> Controller Class Initialized
INFO - 2018-04-20 00:44:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:08 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:08 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:08 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:08 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:08 --> Total execution time: 0.2958
INFO - 2018-04-20 00:44:17 --> Config Class Initialized
INFO - 2018-04-20 00:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:17 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:17 --> URI Class Initialized
INFO - 2018-04-20 00:44:17 --> Router Class Initialized
INFO - 2018-04-20 00:44:17 --> Output Class Initialized
INFO - 2018-04-20 00:44:17 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:17 --> CSRF cookie sent
INFO - 2018-04-20 00:44:17 --> Input Class Initialized
INFO - 2018-04-20 00:44:17 --> Language Class Initialized
INFO - 2018-04-20 00:44:17 --> Loader Class Initialized
INFO - 2018-04-20 00:44:17 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:17 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:17 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:17 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:17 --> Controller Class Initialized
INFO - 2018-04-20 00:44:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:17 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:17 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:17 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:44:17 --> Config Class Initialized
INFO - 2018-04-20 00:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:17 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:17 --> URI Class Initialized
INFO - 2018-04-20 00:44:17 --> Router Class Initialized
INFO - 2018-04-20 00:44:17 --> Output Class Initialized
INFO - 2018-04-20 00:44:17 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:17 --> CSRF cookie sent
INFO - 2018-04-20 00:44:17 --> Input Class Initialized
INFO - 2018-04-20 00:44:17 --> Language Class Initialized
ERROR - 2018-04-20 00:44:17 --> 404 Page Not Found: Short-questions/index
INFO - 2018-04-20 00:44:21 --> Config Class Initialized
INFO - 2018-04-20 00:44:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:21 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:21 --> URI Class Initialized
INFO - 2018-04-20 00:44:21 --> Router Class Initialized
INFO - 2018-04-20 00:44:21 --> Output Class Initialized
INFO - 2018-04-20 00:44:21 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:21 --> CSRF cookie sent
INFO - 2018-04-20 00:44:21 --> Input Class Initialized
INFO - 2018-04-20 00:44:21 --> Language Class Initialized
INFO - 2018-04-20 00:44:21 --> Loader Class Initialized
INFO - 2018-04-20 00:44:21 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:21 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:21 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:21 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:21 --> Controller Class Initialized
INFO - 2018-04-20 00:44:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:21 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:21 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:44:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:21 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:21 --> Total execution time: 0.2970
INFO - 2018-04-20 00:44:25 --> Config Class Initialized
INFO - 2018-04-20 00:44:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:25 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:25 --> URI Class Initialized
INFO - 2018-04-20 00:44:25 --> Router Class Initialized
INFO - 2018-04-20 00:44:25 --> Output Class Initialized
INFO - 2018-04-20 00:44:25 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:25 --> CSRF cookie sent
INFO - 2018-04-20 00:44:25 --> CSRF token verified
INFO - 2018-04-20 00:44:25 --> Input Class Initialized
INFO - 2018-04-20 00:44:25 --> Language Class Initialized
INFO - 2018-04-20 00:44:25 --> Loader Class Initialized
INFO - 2018-04-20 00:44:25 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:25 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:25 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:25 --> Controller Class Initialized
INFO - 2018-04-20 00:44:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:25 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:25 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:25 --> Form Validation Class Initialized
INFO - 2018-04-20 00:44:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:44:25 --> Config Class Initialized
INFO - 2018-04-20 00:44:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:25 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:25 --> URI Class Initialized
INFO - 2018-04-20 00:44:25 --> Router Class Initialized
INFO - 2018-04-20 00:44:25 --> Output Class Initialized
INFO - 2018-04-20 00:44:25 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:25 --> CSRF cookie sent
INFO - 2018-04-20 00:44:25 --> Input Class Initialized
INFO - 2018-04-20 00:44:25 --> Language Class Initialized
INFO - 2018-04-20 00:44:25 --> Loader Class Initialized
INFO - 2018-04-20 00:44:25 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:25 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:25 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:25 --> Controller Class Initialized
INFO - 2018-04-20 00:44:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:25 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:25 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:44:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:25 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:25 --> Total execution time: 0.2845
INFO - 2018-04-20 00:44:33 --> Config Class Initialized
INFO - 2018-04-20 00:44:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:33 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:33 --> URI Class Initialized
INFO - 2018-04-20 00:44:33 --> Router Class Initialized
INFO - 2018-04-20 00:44:33 --> Output Class Initialized
INFO - 2018-04-20 00:44:33 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:33 --> CSRF cookie sent
INFO - 2018-04-20 00:44:33 --> CSRF token verified
INFO - 2018-04-20 00:44:33 --> Input Class Initialized
INFO - 2018-04-20 00:44:33 --> Language Class Initialized
INFO - 2018-04-20 00:44:33 --> Loader Class Initialized
INFO - 2018-04-20 00:44:33 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:33 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:33 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:33 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:33 --> Controller Class Initialized
INFO - 2018-04-20 00:44:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:33 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:33 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:33 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:33 --> Form Validation Class Initialized
INFO - 2018-04-20 00:44:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:44:33 --> Config Class Initialized
INFO - 2018-04-20 00:44:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:33 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:33 --> URI Class Initialized
INFO - 2018-04-20 00:44:33 --> Router Class Initialized
INFO - 2018-04-20 00:44:33 --> Output Class Initialized
INFO - 2018-04-20 00:44:33 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:33 --> CSRF cookie sent
INFO - 2018-04-20 00:44:33 --> Input Class Initialized
INFO - 2018-04-20 00:44:34 --> Language Class Initialized
INFO - 2018-04-20 00:44:34 --> Loader Class Initialized
INFO - 2018-04-20 00:44:34 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:34 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:34 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:34 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:34 --> Controller Class Initialized
INFO - 2018-04-20 00:44:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:34 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:34 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:44:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:34 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:34 --> Total execution time: 0.2889
INFO - 2018-04-20 00:44:36 --> Config Class Initialized
INFO - 2018-04-20 00:44:36 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:36 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:36 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:36 --> URI Class Initialized
INFO - 2018-04-20 00:44:36 --> Router Class Initialized
INFO - 2018-04-20 00:44:36 --> Output Class Initialized
INFO - 2018-04-20 00:44:36 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:36 --> CSRF cookie sent
INFO - 2018-04-20 00:44:36 --> Input Class Initialized
INFO - 2018-04-20 00:44:36 --> Language Class Initialized
INFO - 2018-04-20 00:44:36 --> Loader Class Initialized
INFO - 2018-04-20 00:44:36 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:36 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:36 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:36 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:36 --> Controller Class Initialized
INFO - 2018-04-20 00:44:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:36 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:36 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:44:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:36 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:36 --> Total execution time: 0.3010
INFO - 2018-04-20 00:44:37 --> Config Class Initialized
INFO - 2018-04-20 00:44:37 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:37 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:37 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:37 --> URI Class Initialized
INFO - 2018-04-20 00:44:37 --> Router Class Initialized
INFO - 2018-04-20 00:44:37 --> Output Class Initialized
INFO - 2018-04-20 00:44:37 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:37 --> CSRF cookie sent
INFO - 2018-04-20 00:44:38 --> Input Class Initialized
INFO - 2018-04-20 00:44:38 --> Language Class Initialized
INFO - 2018-04-20 00:44:38 --> Loader Class Initialized
INFO - 2018-04-20 00:44:38 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:38 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:38 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:38 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:38 --> Controller Class Initialized
INFO - 2018-04-20 00:44:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:38 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:38 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:44:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:38 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:38 --> Total execution time: 0.3147
INFO - 2018-04-20 00:44:41 --> Config Class Initialized
INFO - 2018-04-20 00:44:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:41 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:41 --> URI Class Initialized
INFO - 2018-04-20 00:44:41 --> Router Class Initialized
INFO - 2018-04-20 00:44:41 --> Output Class Initialized
INFO - 2018-04-20 00:44:41 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:41 --> CSRF cookie sent
INFO - 2018-04-20 00:44:41 --> Input Class Initialized
INFO - 2018-04-20 00:44:41 --> Language Class Initialized
INFO - 2018-04-20 00:44:41 --> Loader Class Initialized
INFO - 2018-04-20 00:44:41 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:41 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:41 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:41 --> Controller Class Initialized
INFO - 2018-04-20 00:44:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:41 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:41 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:44:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:41 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:41 --> Total execution time: 0.3158
INFO - 2018-04-20 00:44:44 --> Config Class Initialized
INFO - 2018-04-20 00:44:44 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:44 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:44 --> URI Class Initialized
INFO - 2018-04-20 00:44:44 --> Router Class Initialized
INFO - 2018-04-20 00:44:44 --> Output Class Initialized
INFO - 2018-04-20 00:44:44 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:44 --> CSRF cookie sent
INFO - 2018-04-20 00:44:44 --> Input Class Initialized
INFO - 2018-04-20 00:44:44 --> Language Class Initialized
INFO - 2018-04-20 00:44:44 --> Loader Class Initialized
INFO - 2018-04-20 00:44:44 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:44 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:44 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:44 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:44 --> Controller Class Initialized
INFO - 2018-04-20 00:44:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:44 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:44 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:44 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:44:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:44 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:44 --> Total execution time: 0.3182
INFO - 2018-04-20 00:44:52 --> Config Class Initialized
INFO - 2018-04-20 00:44:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:52 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:52 --> URI Class Initialized
INFO - 2018-04-20 00:44:53 --> Router Class Initialized
INFO - 2018-04-20 00:44:53 --> Output Class Initialized
INFO - 2018-04-20 00:44:53 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:53 --> CSRF cookie sent
INFO - 2018-04-20 00:44:53 --> Input Class Initialized
INFO - 2018-04-20 00:44:53 --> Language Class Initialized
INFO - 2018-04-20 00:44:53 --> Loader Class Initialized
INFO - 2018-04-20 00:44:53 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:53 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:53 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:53 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:53 --> Controller Class Initialized
INFO - 2018-04-20 00:44:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:53 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:53 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:53 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:44:53 --> Config Class Initialized
INFO - 2018-04-20 00:44:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:53 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:53 --> URI Class Initialized
INFO - 2018-04-20 00:44:53 --> Router Class Initialized
INFO - 2018-04-20 00:44:53 --> Output Class Initialized
INFO - 2018-04-20 00:44:53 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:53 --> CSRF cookie sent
INFO - 2018-04-20 00:44:53 --> Input Class Initialized
INFO - 2018-04-20 00:44:53 --> Language Class Initialized
INFO - 2018-04-20 00:44:53 --> Loader Class Initialized
INFO - 2018-04-20 00:44:53 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:53 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:53 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:53 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:53 --> Controller Class Initialized
INFO - 2018-04-20 00:44:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:53 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:53 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:53 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:44:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:44:53 --> Final output sent to browser
DEBUG - 2018-04-20 00:44:53 --> Total execution time: 0.2957
INFO - 2018-04-20 00:44:59 --> Config Class Initialized
INFO - 2018-04-20 00:44:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:59 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:59 --> URI Class Initialized
INFO - 2018-04-20 00:44:59 --> Router Class Initialized
INFO - 2018-04-20 00:44:59 --> Output Class Initialized
INFO - 2018-04-20 00:44:59 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:59 --> CSRF cookie sent
INFO - 2018-04-20 00:44:59 --> CSRF token verified
INFO - 2018-04-20 00:44:59 --> Input Class Initialized
INFO - 2018-04-20 00:44:59 --> Language Class Initialized
INFO - 2018-04-20 00:44:59 --> Loader Class Initialized
INFO - 2018-04-20 00:44:59 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:59 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:59 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:59 --> Controller Class Initialized
INFO - 2018-04-20 00:44:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:59 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:59 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:59 --> Form Validation Class Initialized
INFO - 2018-04-20 00:44:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:44:59 --> Config Class Initialized
INFO - 2018-04-20 00:44:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:44:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:44:59 --> Utf8 Class Initialized
INFO - 2018-04-20 00:44:59 --> URI Class Initialized
INFO - 2018-04-20 00:44:59 --> Router Class Initialized
INFO - 2018-04-20 00:44:59 --> Output Class Initialized
INFO - 2018-04-20 00:44:59 --> Security Class Initialized
DEBUG - 2018-04-20 00:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:44:59 --> CSRF cookie sent
INFO - 2018-04-20 00:44:59 --> Input Class Initialized
INFO - 2018-04-20 00:44:59 --> Language Class Initialized
INFO - 2018-04-20 00:44:59 --> Loader Class Initialized
INFO - 2018-04-20 00:44:59 --> Helper loaded: url_helper
INFO - 2018-04-20 00:44:59 --> Helper loaded: form_helper
INFO - 2018-04-20 00:44:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:44:59 --> User Agent Class Initialized
INFO - 2018-04-20 00:44:59 --> Controller Class Initialized
INFO - 2018-04-20 00:44:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:44:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:44:59 --> Pixel_Model class loaded
INFO - 2018-04-20 00:44:59 --> Database Driver Class Initialized
INFO - 2018-04-20 00:44:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:44:59 --> File loaded: E:\www\yacopoo\application\views\questions/kids.php
INFO - 2018-04-20 00:45:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:45:00 --> Final output sent to browser
DEBUG - 2018-04-20 00:45:00 --> Total execution time: 0.3181
INFO - 2018-04-20 00:45:06 --> Config Class Initialized
INFO - 2018-04-20 00:45:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:45:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:45:06 --> Utf8 Class Initialized
INFO - 2018-04-20 00:45:06 --> URI Class Initialized
INFO - 2018-04-20 00:45:06 --> Router Class Initialized
INFO - 2018-04-20 00:45:06 --> Output Class Initialized
INFO - 2018-04-20 00:45:06 --> Security Class Initialized
DEBUG - 2018-04-20 00:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:45:06 --> CSRF cookie sent
INFO - 2018-04-20 00:45:06 --> Input Class Initialized
INFO - 2018-04-20 00:45:06 --> Language Class Initialized
INFO - 2018-04-20 00:45:06 --> Loader Class Initialized
INFO - 2018-04-20 00:45:06 --> Helper loaded: url_helper
INFO - 2018-04-20 00:45:06 --> Helper loaded: form_helper
INFO - 2018-04-20 00:45:06 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:45:06 --> User Agent Class Initialized
INFO - 2018-04-20 00:45:06 --> Controller Class Initialized
INFO - 2018-04-20 00:45:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:45:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:45:06 --> Pixel_Model class loaded
INFO - 2018-04-20 00:45:06 --> Database Driver Class Initialized
INFO - 2018-04-20 00:45:06 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:45:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:45:06 --> Final output sent to browser
DEBUG - 2018-04-20 00:45:06 --> Total execution time: 0.3147
INFO - 2018-04-20 00:45:08 --> Config Class Initialized
INFO - 2018-04-20 00:45:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:45:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:45:08 --> Utf8 Class Initialized
INFO - 2018-04-20 00:45:08 --> URI Class Initialized
INFO - 2018-04-20 00:45:08 --> Router Class Initialized
INFO - 2018-04-20 00:45:08 --> Output Class Initialized
INFO - 2018-04-20 00:45:08 --> Security Class Initialized
DEBUG - 2018-04-20 00:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:45:08 --> CSRF cookie sent
INFO - 2018-04-20 00:45:08 --> Input Class Initialized
INFO - 2018-04-20 00:45:08 --> Language Class Initialized
INFO - 2018-04-20 00:45:08 --> Loader Class Initialized
INFO - 2018-04-20 00:45:08 --> Helper loaded: url_helper
INFO - 2018-04-20 00:45:08 --> Helper loaded: form_helper
INFO - 2018-04-20 00:45:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:45:08 --> User Agent Class Initialized
INFO - 2018-04-20 00:45:08 --> Controller Class Initialized
INFO - 2018-04-20 00:45:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:45:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:45:08 --> Pixel_Model class loaded
INFO - 2018-04-20 00:45:08 --> Database Driver Class Initialized
INFO - 2018-04-20 00:45:08 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:45:08 --> Config Class Initialized
INFO - 2018-04-20 00:45:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:45:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:45:08 --> Utf8 Class Initialized
INFO - 2018-04-20 00:45:08 --> URI Class Initialized
INFO - 2018-04-20 00:45:08 --> Router Class Initialized
INFO - 2018-04-20 00:45:08 --> Output Class Initialized
INFO - 2018-04-20 00:45:08 --> Security Class Initialized
DEBUG - 2018-04-20 00:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:45:08 --> CSRF cookie sent
INFO - 2018-04-20 00:45:08 --> Input Class Initialized
INFO - 2018-04-20 00:45:08 --> Language Class Initialized
INFO - 2018-04-20 00:45:08 --> Loader Class Initialized
INFO - 2018-04-20 00:45:08 --> Helper loaded: url_helper
INFO - 2018-04-20 00:45:08 --> Helper loaded: form_helper
INFO - 2018-04-20 00:45:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:45:08 --> User Agent Class Initialized
INFO - 2018-04-20 00:45:08 --> Controller Class Initialized
INFO - 2018-04-20 00:45:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:45:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:45:08 --> Pixel_Model class loaded
INFO - 2018-04-20 00:45:08 --> Database Driver Class Initialized
INFO - 2018-04-20 00:45:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\questions/kids.php
INFO - 2018-04-20 00:45:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:45:08 --> Final output sent to browser
DEBUG - 2018-04-20 00:45:08 --> Total execution time: 0.3109
INFO - 2018-04-20 00:46:21 --> Config Class Initialized
INFO - 2018-04-20 00:46:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:21 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:21 --> URI Class Initialized
INFO - 2018-04-20 00:46:21 --> Router Class Initialized
INFO - 2018-04-20 00:46:21 --> Output Class Initialized
INFO - 2018-04-20 00:46:21 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:21 --> CSRF cookie sent
INFO - 2018-04-20 00:46:21 --> Input Class Initialized
INFO - 2018-04-20 00:46:21 --> Language Class Initialized
INFO - 2018-04-20 00:46:21 --> Loader Class Initialized
INFO - 2018-04-20 00:46:21 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:21 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:21 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:21 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:21 --> Controller Class Initialized
INFO - 2018-04-20 00:46:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:21 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:21 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:21 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 00:46:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:21 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:21 --> Total execution time: 0.3290
INFO - 2018-04-20 00:46:24 --> Config Class Initialized
INFO - 2018-04-20 00:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:24 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:24 --> URI Class Initialized
INFO - 2018-04-20 00:46:24 --> Router Class Initialized
INFO - 2018-04-20 00:46:24 --> Output Class Initialized
INFO - 2018-04-20 00:46:24 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:24 --> CSRF cookie sent
INFO - 2018-04-20 00:46:24 --> Input Class Initialized
INFO - 2018-04-20 00:46:24 --> Language Class Initialized
INFO - 2018-04-20 00:46:24 --> Loader Class Initialized
INFO - 2018-04-20 00:46:24 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:24 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:24 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:24 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:24 --> Controller Class Initialized
INFO - 2018-04-20 00:46:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:24 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:24 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:24 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 00:46:24 --> Config Class Initialized
INFO - 2018-04-20 00:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:24 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:24 --> URI Class Initialized
INFO - 2018-04-20 00:46:25 --> Router Class Initialized
INFO - 2018-04-20 00:46:25 --> Output Class Initialized
INFO - 2018-04-20 00:46:25 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:25 --> CSRF cookie sent
INFO - 2018-04-20 00:46:25 --> Input Class Initialized
INFO - 2018-04-20 00:46:25 --> Language Class Initialized
INFO - 2018-04-20 00:46:25 --> Loader Class Initialized
INFO - 2018-04-20 00:46:25 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:25 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:25 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:25 --> Controller Class Initialized
INFO - 2018-04-20 00:46:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:25 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:25 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\questions/kids.php
INFO - 2018-04-20 00:46:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:25 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:25 --> Total execution time: 0.3174
INFO - 2018-04-20 00:46:30 --> Config Class Initialized
INFO - 2018-04-20 00:46:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:31 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:31 --> URI Class Initialized
INFO - 2018-04-20 00:46:31 --> Router Class Initialized
INFO - 2018-04-20 00:46:31 --> Output Class Initialized
INFO - 2018-04-20 00:46:31 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:31 --> CSRF cookie sent
INFO - 2018-04-20 00:46:31 --> Input Class Initialized
INFO - 2018-04-20 00:46:31 --> Language Class Initialized
INFO - 2018-04-20 00:46:31 --> Loader Class Initialized
INFO - 2018-04-20 00:46:31 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:31 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:31 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:31 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:31 --> Controller Class Initialized
INFO - 2018-04-20 00:46:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:31 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:31 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:46:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:31 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:31 --> Total execution time: 0.3563
INFO - 2018-04-20 00:46:39 --> Config Class Initialized
INFO - 2018-04-20 00:46:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:39 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:39 --> URI Class Initialized
INFO - 2018-04-20 00:46:39 --> Router Class Initialized
INFO - 2018-04-20 00:46:39 --> Output Class Initialized
INFO - 2018-04-20 00:46:39 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:39 --> CSRF cookie sent
INFO - 2018-04-20 00:46:39 --> CSRF token verified
INFO - 2018-04-20 00:46:39 --> Input Class Initialized
INFO - 2018-04-20 00:46:39 --> Language Class Initialized
INFO - 2018-04-20 00:46:39 --> Loader Class Initialized
INFO - 2018-04-20 00:46:39 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:39 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:39 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:39 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:39 --> Controller Class Initialized
INFO - 2018-04-20 00:46:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:39 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:39 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:39 --> Form Validation Class Initialized
INFO - 2018-04-20 00:46:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:46:39 --> Config Class Initialized
INFO - 2018-04-20 00:46:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:39 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:39 --> URI Class Initialized
INFO - 2018-04-20 00:46:39 --> Router Class Initialized
INFO - 2018-04-20 00:46:39 --> Output Class Initialized
INFO - 2018-04-20 00:46:39 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:39 --> CSRF cookie sent
INFO - 2018-04-20 00:46:39 --> Input Class Initialized
INFO - 2018-04-20 00:46:39 --> Language Class Initialized
INFO - 2018-04-20 00:46:39 --> Loader Class Initialized
INFO - 2018-04-20 00:46:39 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:39 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:39 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:39 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:39 --> Controller Class Initialized
INFO - 2018-04-20 00:46:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:39 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:39 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:39 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:39 --> Total execution time: 0.3362
INFO - 2018-04-20 00:46:41 --> Config Class Initialized
INFO - 2018-04-20 00:46:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:41 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:41 --> URI Class Initialized
INFO - 2018-04-20 00:46:41 --> Router Class Initialized
INFO - 2018-04-20 00:46:41 --> Output Class Initialized
INFO - 2018-04-20 00:46:41 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:41 --> CSRF cookie sent
INFO - 2018-04-20 00:46:41 --> CSRF token verified
INFO - 2018-04-20 00:46:41 --> Input Class Initialized
INFO - 2018-04-20 00:46:41 --> Language Class Initialized
INFO - 2018-04-20 00:46:41 --> Loader Class Initialized
INFO - 2018-04-20 00:46:41 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:41 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:41 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:41 --> Controller Class Initialized
INFO - 2018-04-20 00:46:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:41 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:41 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:41 --> Form Validation Class Initialized
INFO - 2018-04-20 00:46:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:46:41 --> Config Class Initialized
INFO - 2018-04-20 00:46:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:41 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:41 --> URI Class Initialized
INFO - 2018-04-20 00:46:41 --> Router Class Initialized
INFO - 2018-04-20 00:46:41 --> Output Class Initialized
INFO - 2018-04-20 00:46:41 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:41 --> CSRF cookie sent
INFO - 2018-04-20 00:46:41 --> Input Class Initialized
INFO - 2018-04-20 00:46:41 --> Language Class Initialized
INFO - 2018-04-20 00:46:41 --> Loader Class Initialized
INFO - 2018-04-20 00:46:41 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:41 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:42 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:42 --> Controller Class Initialized
INFO - 2018-04-20 00:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:42 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:42 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:46:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:42 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:42 --> Total execution time: 0.3366
INFO - 2018-04-20 00:46:43 --> Config Class Initialized
INFO - 2018-04-20 00:46:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:43 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:43 --> URI Class Initialized
INFO - 2018-04-20 00:46:43 --> Router Class Initialized
INFO - 2018-04-20 00:46:43 --> Output Class Initialized
INFO - 2018-04-20 00:46:43 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:43 --> CSRF cookie sent
INFO - 2018-04-20 00:46:43 --> CSRF token verified
INFO - 2018-04-20 00:46:43 --> Input Class Initialized
INFO - 2018-04-20 00:46:43 --> Language Class Initialized
INFO - 2018-04-20 00:46:43 --> Loader Class Initialized
INFO - 2018-04-20 00:46:43 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:43 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:43 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:43 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:44 --> Controller Class Initialized
INFO - 2018-04-20 00:46:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:44 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:44 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:44 --> Form Validation Class Initialized
INFO - 2018-04-20 00:46:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:46:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:44 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:44 --> Total execution time: 0.3985
INFO - 2018-04-20 00:46:47 --> Config Class Initialized
INFO - 2018-04-20 00:46:47 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:47 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:47 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:47 --> URI Class Initialized
INFO - 2018-04-20 00:46:47 --> Router Class Initialized
INFO - 2018-04-20 00:46:47 --> Output Class Initialized
INFO - 2018-04-20 00:46:47 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:48 --> CSRF cookie sent
INFO - 2018-04-20 00:46:48 --> CSRF token verified
INFO - 2018-04-20 00:46:48 --> Input Class Initialized
INFO - 2018-04-20 00:46:48 --> Language Class Initialized
INFO - 2018-04-20 00:46:48 --> Loader Class Initialized
INFO - 2018-04-20 00:46:48 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:48 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:48 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:48 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:48 --> Controller Class Initialized
INFO - 2018-04-20 00:46:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:48 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:48 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:48 --> Form Validation Class Initialized
INFO - 2018-04-20 00:46:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:46:48 --> Config Class Initialized
INFO - 2018-04-20 00:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:48 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:48 --> URI Class Initialized
INFO - 2018-04-20 00:46:48 --> Router Class Initialized
INFO - 2018-04-20 00:46:48 --> Output Class Initialized
INFO - 2018-04-20 00:46:48 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:48 --> CSRF cookie sent
INFO - 2018-04-20 00:46:48 --> Input Class Initialized
INFO - 2018-04-20 00:46:48 --> Language Class Initialized
INFO - 2018-04-20 00:46:48 --> Loader Class Initialized
INFO - 2018-04-20 00:46:48 --> Helper loaded: url_helper
INFO - 2018-04-20 00:46:48 --> Helper loaded: form_helper
INFO - 2018-04-20 00:46:48 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:46:48 --> User Agent Class Initialized
INFO - 2018-04-20 00:46:48 --> Controller Class Initialized
INFO - 2018-04-20 00:46:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:46:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:46:48 --> Pixel_Model class loaded
INFO - 2018-04-20 00:46:48 --> Database Driver Class Initialized
INFO - 2018-04-20 00:46:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\questions/kids.php
INFO - 2018-04-20 00:46:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:46:48 --> Final output sent to browser
DEBUG - 2018-04-20 00:46:48 --> Total execution time: 0.3433
INFO - 2018-04-20 00:46:52 --> Config Class Initialized
INFO - 2018-04-20 00:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:46:52 --> Utf8 Class Initialized
INFO - 2018-04-20 00:46:52 --> URI Class Initialized
INFO - 2018-04-20 00:46:52 --> Router Class Initialized
INFO - 2018-04-20 00:46:52 --> Output Class Initialized
INFO - 2018-04-20 00:46:52 --> Security Class Initialized
DEBUG - 2018-04-20 00:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:46:52 --> CSRF cookie sent
INFO - 2018-04-20 00:46:52 --> Input Class Initialized
INFO - 2018-04-20 00:46:52 --> Language Class Initialized
ERROR - 2018-04-20 00:46:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:47:01 --> Config Class Initialized
INFO - 2018-04-20 00:47:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:01 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:01 --> URI Class Initialized
INFO - 2018-04-20 00:47:01 --> Router Class Initialized
INFO - 2018-04-20 00:47:01 --> Output Class Initialized
INFO - 2018-04-20 00:47:01 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:01 --> CSRF cookie sent
INFO - 2018-04-20 00:47:01 --> CSRF token verified
INFO - 2018-04-20 00:47:01 --> Input Class Initialized
INFO - 2018-04-20 00:47:01 --> Language Class Initialized
INFO - 2018-04-20 00:47:01 --> Loader Class Initialized
INFO - 2018-04-20 00:47:01 --> Helper loaded: url_helper
INFO - 2018-04-20 00:47:01 --> Helper loaded: form_helper
INFO - 2018-04-20 00:47:01 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:47:01 --> User Agent Class Initialized
INFO - 2018-04-20 00:47:01 --> Controller Class Initialized
INFO - 2018-04-20 00:47:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:47:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:47:01 --> Pixel_Model class loaded
INFO - 2018-04-20 00:47:01 --> Database Driver Class Initialized
INFO - 2018-04-20 00:47:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:47:01 --> Form Validation Class Initialized
INFO - 2018-04-20 00:47:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:47:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:47:01 --> Final output sent to browser
DEBUG - 2018-04-20 00:47:01 --> Total execution time: 0.4010
INFO - 2018-04-20 00:47:02 --> Config Class Initialized
INFO - 2018-04-20 00:47:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:02 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:02 --> URI Class Initialized
INFO - 2018-04-20 00:47:02 --> Router Class Initialized
INFO - 2018-04-20 00:47:02 --> Output Class Initialized
INFO - 2018-04-20 00:47:02 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:02 --> CSRF cookie sent
INFO - 2018-04-20 00:47:02 --> Input Class Initialized
INFO - 2018-04-20 00:47:02 --> Language Class Initialized
ERROR - 2018-04-20 00:47:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:47:02 --> Config Class Initialized
INFO - 2018-04-20 00:47:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:02 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:02 --> URI Class Initialized
INFO - 2018-04-20 00:47:02 --> Router Class Initialized
INFO - 2018-04-20 00:47:02 --> Output Class Initialized
INFO - 2018-04-20 00:47:02 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:02 --> CSRF cookie sent
INFO - 2018-04-20 00:47:02 --> Input Class Initialized
INFO - 2018-04-20 00:47:02 --> Language Class Initialized
INFO - 2018-04-20 00:47:02 --> Loader Class Initialized
INFO - 2018-04-20 00:47:02 --> Helper loaded: url_helper
INFO - 2018-04-20 00:47:03 --> Helper loaded: form_helper
INFO - 2018-04-20 00:47:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:47:03 --> User Agent Class Initialized
INFO - 2018-04-20 00:47:03 --> Controller Class Initialized
INFO - 2018-04-20 00:47:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:47:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:47:03 --> Pixel_Model class loaded
INFO - 2018-04-20 00:47:03 --> Database Driver Class Initialized
INFO - 2018-04-20 00:47:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:47:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:47:03 --> Final output sent to browser
DEBUG - 2018-04-20 00:47:03 --> Total execution time: 0.3810
INFO - 2018-04-20 00:47:03 --> Config Class Initialized
INFO - 2018-04-20 00:47:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:03 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:03 --> URI Class Initialized
INFO - 2018-04-20 00:47:03 --> Router Class Initialized
INFO - 2018-04-20 00:47:03 --> Output Class Initialized
INFO - 2018-04-20 00:47:03 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:03 --> CSRF cookie sent
INFO - 2018-04-20 00:47:03 --> Input Class Initialized
INFO - 2018-04-20 00:47:03 --> Language Class Initialized
ERROR - 2018-04-20 00:47:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:47:05 --> Config Class Initialized
INFO - 2018-04-20 00:47:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:05 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:05 --> URI Class Initialized
INFO - 2018-04-20 00:47:05 --> Router Class Initialized
INFO - 2018-04-20 00:47:05 --> Output Class Initialized
INFO - 2018-04-20 00:47:05 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:05 --> CSRF cookie sent
INFO - 2018-04-20 00:47:05 --> Input Class Initialized
INFO - 2018-04-20 00:47:05 --> Language Class Initialized
INFO - 2018-04-20 00:47:05 --> Loader Class Initialized
INFO - 2018-04-20 00:47:05 --> Helper loaded: url_helper
INFO - 2018-04-20 00:47:05 --> Helper loaded: form_helper
INFO - 2018-04-20 00:47:05 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:47:05 --> User Agent Class Initialized
INFO - 2018-04-20 00:47:05 --> Controller Class Initialized
INFO - 2018-04-20 00:47:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:47:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:47:05 --> Pixel_Model class loaded
INFO - 2018-04-20 00:47:05 --> Database Driver Class Initialized
INFO - 2018-04-20 00:47:05 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:47:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:47:05 --> Final output sent to browser
DEBUG - 2018-04-20 00:47:05 --> Total execution time: 0.3612
INFO - 2018-04-20 00:47:05 --> Config Class Initialized
INFO - 2018-04-20 00:47:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:05 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:05 --> URI Class Initialized
INFO - 2018-04-20 00:47:05 --> Router Class Initialized
INFO - 2018-04-20 00:47:06 --> Output Class Initialized
INFO - 2018-04-20 00:47:06 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:06 --> CSRF cookie sent
INFO - 2018-04-20 00:47:06 --> Input Class Initialized
INFO - 2018-04-20 00:47:06 --> Language Class Initialized
ERROR - 2018-04-20 00:47:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:47:06 --> Config Class Initialized
INFO - 2018-04-20 00:47:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:06 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:06 --> URI Class Initialized
INFO - 2018-04-20 00:47:06 --> Router Class Initialized
INFO - 2018-04-20 00:47:06 --> Output Class Initialized
INFO - 2018-04-20 00:47:06 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:07 --> CSRF cookie sent
INFO - 2018-04-20 00:47:07 --> Input Class Initialized
INFO - 2018-04-20 00:47:07 --> Language Class Initialized
INFO - 2018-04-20 00:47:07 --> Loader Class Initialized
INFO - 2018-04-20 00:47:07 --> Helper loaded: url_helper
INFO - 2018-04-20 00:47:07 --> Helper loaded: form_helper
INFO - 2018-04-20 00:47:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:47:07 --> User Agent Class Initialized
INFO - 2018-04-20 00:47:07 --> Controller Class Initialized
INFO - 2018-04-20 00:47:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:47:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:47:07 --> Pixel_Model class loaded
INFO - 2018-04-20 00:47:07 --> Database Driver Class Initialized
INFO - 2018-04-20 00:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:47:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:47:07 --> Final output sent to browser
DEBUG - 2018-04-20 00:47:07 --> Total execution time: 0.3931
INFO - 2018-04-20 00:47:07 --> Config Class Initialized
INFO - 2018-04-20 00:47:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:47:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:47:07 --> Utf8 Class Initialized
INFO - 2018-04-20 00:47:07 --> URI Class Initialized
INFO - 2018-04-20 00:47:07 --> Router Class Initialized
INFO - 2018-04-20 00:47:07 --> Output Class Initialized
INFO - 2018-04-20 00:47:07 --> Security Class Initialized
DEBUG - 2018-04-20 00:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:47:07 --> CSRF cookie sent
INFO - 2018-04-20 00:47:07 --> Input Class Initialized
INFO - 2018-04-20 00:47:07 --> Language Class Initialized
ERROR - 2018-04-20 00:47:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:48:41 --> Config Class Initialized
INFO - 2018-04-20 00:48:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:48:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:48:41 --> Utf8 Class Initialized
INFO - 2018-04-20 00:48:41 --> URI Class Initialized
INFO - 2018-04-20 00:48:41 --> Router Class Initialized
INFO - 2018-04-20 00:48:41 --> Output Class Initialized
INFO - 2018-04-20 00:48:41 --> Security Class Initialized
DEBUG - 2018-04-20 00:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:48:41 --> CSRF cookie sent
INFO - 2018-04-20 00:48:41 --> Input Class Initialized
INFO - 2018-04-20 00:48:41 --> Language Class Initialized
INFO - 2018-04-20 00:48:41 --> Loader Class Initialized
INFO - 2018-04-20 00:48:41 --> Helper loaded: url_helper
INFO - 2018-04-20 00:48:41 --> Helper loaded: form_helper
INFO - 2018-04-20 00:48:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:48:41 --> User Agent Class Initialized
INFO - 2018-04-20 00:48:41 --> Controller Class Initialized
INFO - 2018-04-20 00:48:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:48:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:48:41 --> Pixel_Model class loaded
INFO - 2018-04-20 00:48:41 --> Database Driver Class Initialized
INFO - 2018-04-20 00:48:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:48:41 --> Final output sent to browser
DEBUG - 2018-04-20 00:48:41 --> Total execution time: 0.3767
INFO - 2018-04-20 00:48:42 --> Config Class Initialized
INFO - 2018-04-20 00:48:42 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:48:42 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:48:42 --> Utf8 Class Initialized
INFO - 2018-04-20 00:48:42 --> URI Class Initialized
INFO - 2018-04-20 00:48:42 --> Router Class Initialized
INFO - 2018-04-20 00:48:42 --> Output Class Initialized
INFO - 2018-04-20 00:48:42 --> Security Class Initialized
DEBUG - 2018-04-20 00:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:48:42 --> CSRF cookie sent
INFO - 2018-04-20 00:48:42 --> Input Class Initialized
INFO - 2018-04-20 00:48:42 --> Language Class Initialized
ERROR - 2018-04-20 00:48:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:49:14 --> Config Class Initialized
INFO - 2018-04-20 00:49:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:14 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:14 --> URI Class Initialized
INFO - 2018-04-20 00:49:14 --> Router Class Initialized
INFO - 2018-04-20 00:49:14 --> Output Class Initialized
INFO - 2018-04-20 00:49:14 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:14 --> CSRF cookie sent
INFO - 2018-04-20 00:49:14 --> Input Class Initialized
INFO - 2018-04-20 00:49:14 --> Language Class Initialized
INFO - 2018-04-20 00:49:14 --> Loader Class Initialized
INFO - 2018-04-20 00:49:14 --> Helper loaded: url_helper
INFO - 2018-04-20 00:49:14 --> Helper loaded: form_helper
INFO - 2018-04-20 00:49:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:49:14 --> User Agent Class Initialized
INFO - 2018-04-20 00:49:14 --> Controller Class Initialized
INFO - 2018-04-20 00:49:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:49:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:49:14 --> Pixel_Model class loaded
INFO - 2018-04-20 00:49:14 --> Database Driver Class Initialized
INFO - 2018-04-20 00:49:14 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 00:49:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:49:14 --> Final output sent to browser
DEBUG - 2018-04-20 00:49:14 --> Total execution time: 0.3989
INFO - 2018-04-20 00:49:15 --> Config Class Initialized
INFO - 2018-04-20 00:49:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:15 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:15 --> URI Class Initialized
INFO - 2018-04-20 00:49:15 --> Router Class Initialized
INFO - 2018-04-20 00:49:15 --> Output Class Initialized
INFO - 2018-04-20 00:49:15 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:15 --> CSRF cookie sent
INFO - 2018-04-20 00:49:15 --> Input Class Initialized
INFO - 2018-04-20 00:49:15 --> Language Class Initialized
ERROR - 2018-04-20 00:49:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:49:17 --> Config Class Initialized
INFO - 2018-04-20 00:49:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:17 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:17 --> URI Class Initialized
INFO - 2018-04-20 00:49:17 --> Router Class Initialized
INFO - 2018-04-20 00:49:17 --> Output Class Initialized
INFO - 2018-04-20 00:49:17 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:17 --> CSRF cookie sent
INFO - 2018-04-20 00:49:17 --> CSRF token verified
INFO - 2018-04-20 00:49:17 --> Input Class Initialized
INFO - 2018-04-20 00:49:17 --> Language Class Initialized
INFO - 2018-04-20 00:49:17 --> Loader Class Initialized
INFO - 2018-04-20 00:49:17 --> Helper loaded: url_helper
INFO - 2018-04-20 00:49:18 --> Helper loaded: form_helper
INFO - 2018-04-20 00:49:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:49:18 --> User Agent Class Initialized
INFO - 2018-04-20 00:49:18 --> Controller Class Initialized
INFO - 2018-04-20 00:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:49:18 --> Pixel_Model class loaded
INFO - 2018-04-20 00:49:18 --> Database Driver Class Initialized
INFO - 2018-04-20 00:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:49:18 --> Form Validation Class Initialized
INFO - 2018-04-20 00:49:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:49:18 --> Config Class Initialized
INFO - 2018-04-20 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:18 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:18 --> URI Class Initialized
INFO - 2018-04-20 00:49:18 --> Router Class Initialized
INFO - 2018-04-20 00:49:18 --> Output Class Initialized
INFO - 2018-04-20 00:49:18 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:18 --> CSRF cookie sent
INFO - 2018-04-20 00:49:18 --> Input Class Initialized
INFO - 2018-04-20 00:49:18 --> Language Class Initialized
INFO - 2018-04-20 00:49:18 --> Loader Class Initialized
INFO - 2018-04-20 00:49:18 --> Helper loaded: url_helper
INFO - 2018-04-20 00:49:18 --> Helper loaded: form_helper
INFO - 2018-04-20 00:49:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:49:18 --> User Agent Class Initialized
INFO - 2018-04-20 00:49:18 --> Controller Class Initialized
INFO - 2018-04-20 00:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:49:18 --> Pixel_Model class loaded
INFO - 2018-04-20 00:49:18 --> Database Driver Class Initialized
INFO - 2018-04-20 00:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 00:49:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:49:18 --> Final output sent to browser
DEBUG - 2018-04-20 00:49:18 --> Total execution time: 0.3813
INFO - 2018-04-20 00:49:18 --> Config Class Initialized
INFO - 2018-04-20 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:18 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:19 --> URI Class Initialized
INFO - 2018-04-20 00:49:19 --> Router Class Initialized
INFO - 2018-04-20 00:49:19 --> Output Class Initialized
INFO - 2018-04-20 00:49:19 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:19 --> CSRF cookie sent
INFO - 2018-04-20 00:49:19 --> Input Class Initialized
INFO - 2018-04-20 00:49:19 --> Language Class Initialized
ERROR - 2018-04-20 00:49:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 00:49:20 --> Config Class Initialized
INFO - 2018-04-20 00:49:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:20 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:20 --> URI Class Initialized
INFO - 2018-04-20 00:49:20 --> Router Class Initialized
INFO - 2018-04-20 00:49:20 --> Output Class Initialized
INFO - 2018-04-20 00:49:20 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:20 --> CSRF cookie sent
INFO - 2018-04-20 00:49:20 --> CSRF token verified
INFO - 2018-04-20 00:49:20 --> Input Class Initialized
INFO - 2018-04-20 00:49:20 --> Language Class Initialized
INFO - 2018-04-20 00:49:20 --> Loader Class Initialized
INFO - 2018-04-20 00:49:20 --> Helper loaded: url_helper
INFO - 2018-04-20 00:49:20 --> Helper loaded: form_helper
INFO - 2018-04-20 00:49:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:49:20 --> User Agent Class Initialized
INFO - 2018-04-20 00:49:20 --> Controller Class Initialized
INFO - 2018-04-20 00:49:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:49:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:49:20 --> Pixel_Model class loaded
INFO - 2018-04-20 00:49:20 --> Database Driver Class Initialized
INFO - 2018-04-20 00:49:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:49:20 --> Form Validation Class Initialized
INFO - 2018-04-20 00:49:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 00:49:20 --> Config Class Initialized
INFO - 2018-04-20 00:49:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:20 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:20 --> URI Class Initialized
INFO - 2018-04-20 00:49:20 --> Router Class Initialized
INFO - 2018-04-20 00:49:20 --> Output Class Initialized
INFO - 2018-04-20 00:49:20 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:20 --> CSRF cookie sent
INFO - 2018-04-20 00:49:20 --> Input Class Initialized
INFO - 2018-04-20 00:49:20 --> Language Class Initialized
INFO - 2018-04-20 00:49:20 --> Loader Class Initialized
INFO - 2018-04-20 00:49:20 --> Helper loaded: url_helper
INFO - 2018-04-20 00:49:20 --> Helper loaded: form_helper
INFO - 2018-04-20 00:49:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 00:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 00:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 00:49:20 --> User Agent Class Initialized
INFO - 2018-04-20 00:49:20 --> Controller Class Initialized
INFO - 2018-04-20 00:49:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 00:49:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 00:49:20 --> Pixel_Model class loaded
INFO - 2018-04-20 00:49:20 --> Database Driver Class Initialized
INFO - 2018-04-20 00:49:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 00:49:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 00:49:21 --> Final output sent to browser
DEBUG - 2018-04-20 00:49:21 --> Total execution time: 0.3652
INFO - 2018-04-20 00:49:21 --> Config Class Initialized
INFO - 2018-04-20 00:49:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 00:49:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 00:49:21 --> Utf8 Class Initialized
INFO - 2018-04-20 00:49:21 --> URI Class Initialized
INFO - 2018-04-20 00:49:21 --> Router Class Initialized
INFO - 2018-04-20 00:49:21 --> Output Class Initialized
INFO - 2018-04-20 00:49:21 --> Security Class Initialized
DEBUG - 2018-04-20 00:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 00:49:21 --> CSRF cookie sent
INFO - 2018-04-20 00:49:21 --> Input Class Initialized
INFO - 2018-04-20 00:49:21 --> Language Class Initialized
ERROR - 2018-04-20 00:49:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:00:37 --> Config Class Initialized
INFO - 2018-04-20 01:00:37 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:00:37 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:00:37 --> Utf8 Class Initialized
INFO - 2018-04-20 01:00:37 --> URI Class Initialized
INFO - 2018-04-20 01:00:37 --> Router Class Initialized
INFO - 2018-04-20 01:00:37 --> Output Class Initialized
INFO - 2018-04-20 01:00:37 --> Security Class Initialized
DEBUG - 2018-04-20 01:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:00:37 --> CSRF cookie sent
INFO - 2018-04-20 01:00:38 --> Input Class Initialized
INFO - 2018-04-20 01:00:38 --> Language Class Initialized
INFO - 2018-04-20 01:00:38 --> Loader Class Initialized
INFO - 2018-04-20 01:00:38 --> Helper loaded: url_helper
INFO - 2018-04-20 01:00:38 --> Helper loaded: form_helper
INFO - 2018-04-20 01:00:38 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:00:38 --> User Agent Class Initialized
INFO - 2018-04-20 01:00:38 --> Controller Class Initialized
INFO - 2018-04-20 01:00:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:00:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:00:38 --> Pixel_Model class loaded
INFO - 2018-04-20 01:00:38 --> Database Driver Class Initialized
INFO - 2018-04-20 01:00:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:00:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:00:38 --> Final output sent to browser
DEBUG - 2018-04-20 01:00:38 --> Total execution time: 0.3692
INFO - 2018-04-20 01:00:38 --> Config Class Initialized
INFO - 2018-04-20 01:00:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:00:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:00:38 --> Utf8 Class Initialized
INFO - 2018-04-20 01:00:38 --> URI Class Initialized
INFO - 2018-04-20 01:00:38 --> Router Class Initialized
INFO - 2018-04-20 01:00:38 --> Output Class Initialized
INFO - 2018-04-20 01:00:38 --> Security Class Initialized
DEBUG - 2018-04-20 01:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:00:38 --> CSRF cookie sent
INFO - 2018-04-20 01:00:38 --> Input Class Initialized
INFO - 2018-04-20 01:00:38 --> Language Class Initialized
ERROR - 2018-04-20 01:00:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:01:41 --> Config Class Initialized
INFO - 2018-04-20 01:01:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:01:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:01:41 --> Utf8 Class Initialized
INFO - 2018-04-20 01:01:41 --> URI Class Initialized
INFO - 2018-04-20 01:01:41 --> Router Class Initialized
INFO - 2018-04-20 01:01:41 --> Output Class Initialized
INFO - 2018-04-20 01:01:41 --> Security Class Initialized
DEBUG - 2018-04-20 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:01:41 --> CSRF cookie sent
INFO - 2018-04-20 01:01:41 --> CSRF token verified
INFO - 2018-04-20 01:01:41 --> Input Class Initialized
INFO - 2018-04-20 01:01:41 --> Language Class Initialized
INFO - 2018-04-20 01:01:41 --> Loader Class Initialized
INFO - 2018-04-20 01:01:41 --> Helper loaded: url_helper
INFO - 2018-04-20 01:01:41 --> Helper loaded: form_helper
INFO - 2018-04-20 01:01:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:01:41 --> User Agent Class Initialized
INFO - 2018-04-20 01:01:41 --> Controller Class Initialized
INFO - 2018-04-20 01:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:01:41 --> Pixel_Model class loaded
INFO - 2018-04-20 01:01:41 --> Database Driver Class Initialized
INFO - 2018-04-20 01:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:01:41 --> Form Validation Class Initialized
INFO - 2018-04-20 01:01:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:01:41 --> Config Class Initialized
INFO - 2018-04-20 01:01:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:01:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:01:41 --> Utf8 Class Initialized
INFO - 2018-04-20 01:01:41 --> URI Class Initialized
INFO - 2018-04-20 01:01:41 --> Router Class Initialized
INFO - 2018-04-20 01:01:41 --> Output Class Initialized
INFO - 2018-04-20 01:01:41 --> Security Class Initialized
DEBUG - 2018-04-20 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:01:41 --> CSRF cookie sent
INFO - 2018-04-20 01:01:41 --> Input Class Initialized
INFO - 2018-04-20 01:01:41 --> Language Class Initialized
INFO - 2018-04-20 01:01:41 --> Loader Class Initialized
INFO - 2018-04-20 01:01:41 --> Helper loaded: url_helper
INFO - 2018-04-20 01:01:41 --> Helper loaded: form_helper
INFO - 2018-04-20 01:01:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:01:41 --> User Agent Class Initialized
INFO - 2018-04-20 01:01:41 --> Controller Class Initialized
INFO - 2018-04-20 01:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:01:41 --> Pixel_Model class loaded
INFO - 2018-04-20 01:01:41 --> Database Driver Class Initialized
INFO - 2018-04-20 01:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:01:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:01:41 --> Final output sent to browser
DEBUG - 2018-04-20 01:01:41 --> Total execution time: 0.3687
INFO - 2018-04-20 01:01:42 --> Config Class Initialized
INFO - 2018-04-20 01:01:42 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:01:42 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:01:42 --> Utf8 Class Initialized
INFO - 2018-04-20 01:01:42 --> URI Class Initialized
INFO - 2018-04-20 01:01:42 --> Router Class Initialized
INFO - 2018-04-20 01:01:42 --> Output Class Initialized
INFO - 2018-04-20 01:01:42 --> Security Class Initialized
DEBUG - 2018-04-20 01:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:01:42 --> CSRF cookie sent
INFO - 2018-04-20 01:01:42 --> Input Class Initialized
INFO - 2018-04-20 01:01:42 --> Language Class Initialized
ERROR - 2018-04-20 01:01:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:02:05 --> Config Class Initialized
INFO - 2018-04-20 01:02:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:02:05 --> Utf8 Class Initialized
INFO - 2018-04-20 01:02:05 --> URI Class Initialized
INFO - 2018-04-20 01:02:05 --> Router Class Initialized
INFO - 2018-04-20 01:02:05 --> Output Class Initialized
INFO - 2018-04-20 01:02:05 --> Security Class Initialized
DEBUG - 2018-04-20 01:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:02:05 --> CSRF cookie sent
INFO - 2018-04-20 01:02:05 --> Input Class Initialized
INFO - 2018-04-20 01:02:05 --> Language Class Initialized
INFO - 2018-04-20 01:02:05 --> Loader Class Initialized
INFO - 2018-04-20 01:02:05 --> Helper loaded: url_helper
INFO - 2018-04-20 01:02:05 --> Helper loaded: form_helper
INFO - 2018-04-20 01:02:05 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:02:05 --> User Agent Class Initialized
INFO - 2018-04-20 01:02:05 --> Controller Class Initialized
INFO - 2018-04-20 01:02:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:02:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:02:05 --> Pixel_Model class loaded
INFO - 2018-04-20 01:02:05 --> Database Driver Class Initialized
INFO - 2018-04-20 01:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:02:05 --> Final output sent to browser
DEBUG - 2018-04-20 01:02:05 --> Total execution time: 0.3874
INFO - 2018-04-20 01:02:05 --> Config Class Initialized
INFO - 2018-04-20 01:02:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:02:05 --> Utf8 Class Initialized
INFO - 2018-04-20 01:02:05 --> URI Class Initialized
INFO - 2018-04-20 01:02:05 --> Router Class Initialized
INFO - 2018-04-20 01:02:05 --> Output Class Initialized
INFO - 2018-04-20 01:02:05 --> Security Class Initialized
DEBUG - 2018-04-20 01:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:02:05 --> CSRF cookie sent
INFO - 2018-04-20 01:02:05 --> Input Class Initialized
INFO - 2018-04-20 01:02:05 --> Language Class Initialized
ERROR - 2018-04-20 01:02:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:02:34 --> Config Class Initialized
INFO - 2018-04-20 01:02:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:02:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:02:34 --> Utf8 Class Initialized
INFO - 2018-04-20 01:02:34 --> URI Class Initialized
INFO - 2018-04-20 01:02:34 --> Router Class Initialized
INFO - 2018-04-20 01:02:34 --> Output Class Initialized
INFO - 2018-04-20 01:02:34 --> Security Class Initialized
DEBUG - 2018-04-20 01:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:02:34 --> CSRF cookie sent
INFO - 2018-04-20 01:02:34 --> Input Class Initialized
INFO - 2018-04-20 01:02:34 --> Language Class Initialized
INFO - 2018-04-20 01:02:34 --> Loader Class Initialized
INFO - 2018-04-20 01:02:34 --> Helper loaded: url_helper
INFO - 2018-04-20 01:02:34 --> Helper loaded: form_helper
INFO - 2018-04-20 01:02:34 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:02:34 --> User Agent Class Initialized
INFO - 2018-04-20 01:02:34 --> Controller Class Initialized
INFO - 2018-04-20 01:02:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:02:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:02:34 --> Pixel_Model class loaded
INFO - 2018-04-20 01:02:34 --> Database Driver Class Initialized
INFO - 2018-04-20 01:02:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:02:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:02:34 --> Final output sent to browser
DEBUG - 2018-04-20 01:02:34 --> Total execution time: 0.4173
INFO - 2018-04-20 01:02:34 --> Config Class Initialized
INFO - 2018-04-20 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:02:35 --> Utf8 Class Initialized
INFO - 2018-04-20 01:02:35 --> URI Class Initialized
INFO - 2018-04-20 01:02:35 --> Router Class Initialized
INFO - 2018-04-20 01:02:35 --> Output Class Initialized
INFO - 2018-04-20 01:02:35 --> Security Class Initialized
DEBUG - 2018-04-20 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:02:35 --> CSRF cookie sent
INFO - 2018-04-20 01:02:35 --> Input Class Initialized
INFO - 2018-04-20 01:02:35 --> Language Class Initialized
ERROR - 2018-04-20 01:02:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:03:35 --> Config Class Initialized
INFO - 2018-04-20 01:03:35 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:03:35 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:03:35 --> Utf8 Class Initialized
INFO - 2018-04-20 01:03:35 --> URI Class Initialized
INFO - 2018-04-20 01:03:35 --> Router Class Initialized
INFO - 2018-04-20 01:03:35 --> Output Class Initialized
INFO - 2018-04-20 01:03:35 --> Security Class Initialized
DEBUG - 2018-04-20 01:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:03:35 --> CSRF cookie sent
INFO - 2018-04-20 01:03:35 --> Input Class Initialized
INFO - 2018-04-20 01:03:35 --> Language Class Initialized
INFO - 2018-04-20 01:03:35 --> Loader Class Initialized
INFO - 2018-04-20 01:03:35 --> Helper loaded: url_helper
INFO - 2018-04-20 01:03:35 --> Helper loaded: form_helper
INFO - 2018-04-20 01:03:35 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:03:35 --> User Agent Class Initialized
INFO - 2018-04-20 01:03:35 --> Controller Class Initialized
INFO - 2018-04-20 01:03:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:03:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:03:35 --> Pixel_Model class loaded
INFO - 2018-04-20 01:03:35 --> Database Driver Class Initialized
INFO - 2018-04-20 01:03:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:03:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:03:36 --> Final output sent to browser
DEBUG - 2018-04-20 01:03:36 --> Total execution time: 0.4020
INFO - 2018-04-20 01:03:36 --> Config Class Initialized
INFO - 2018-04-20 01:03:36 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:03:36 --> Utf8 Class Initialized
INFO - 2018-04-20 01:03:36 --> URI Class Initialized
INFO - 2018-04-20 01:03:36 --> Router Class Initialized
INFO - 2018-04-20 01:03:36 --> Output Class Initialized
INFO - 2018-04-20 01:03:36 --> Security Class Initialized
DEBUG - 2018-04-20 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:03:36 --> CSRF cookie sent
INFO - 2018-04-20 01:03:36 --> Input Class Initialized
INFO - 2018-04-20 01:03:36 --> Language Class Initialized
ERROR - 2018-04-20 01:03:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:04:41 --> Config Class Initialized
INFO - 2018-04-20 01:04:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:04:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:04:41 --> Utf8 Class Initialized
INFO - 2018-04-20 01:04:41 --> URI Class Initialized
INFO - 2018-04-20 01:04:41 --> Router Class Initialized
INFO - 2018-04-20 01:04:41 --> Output Class Initialized
INFO - 2018-04-20 01:04:41 --> Security Class Initialized
DEBUG - 2018-04-20 01:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:04:41 --> CSRF cookie sent
INFO - 2018-04-20 01:04:41 --> Input Class Initialized
INFO - 2018-04-20 01:04:41 --> Language Class Initialized
INFO - 2018-04-20 01:04:41 --> Loader Class Initialized
INFO - 2018-04-20 01:04:41 --> Helper loaded: url_helper
INFO - 2018-04-20 01:04:41 --> Helper loaded: form_helper
INFO - 2018-04-20 01:04:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:04:41 --> User Agent Class Initialized
INFO - 2018-04-20 01:04:41 --> Controller Class Initialized
INFO - 2018-04-20 01:04:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:04:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:04:41 --> Pixel_Model class loaded
INFO - 2018-04-20 01:04:41 --> Database Driver Class Initialized
INFO - 2018-04-20 01:04:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:04:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:04:41 --> Final output sent to browser
DEBUG - 2018-04-20 01:04:41 --> Total execution time: 0.3929
INFO - 2018-04-20 01:04:42 --> Config Class Initialized
INFO - 2018-04-20 01:04:42 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:04:42 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:04:42 --> Utf8 Class Initialized
INFO - 2018-04-20 01:04:42 --> URI Class Initialized
INFO - 2018-04-20 01:04:42 --> Router Class Initialized
INFO - 2018-04-20 01:04:42 --> Output Class Initialized
INFO - 2018-04-20 01:04:42 --> Security Class Initialized
DEBUG - 2018-04-20 01:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:04:42 --> CSRF cookie sent
INFO - 2018-04-20 01:04:42 --> Input Class Initialized
INFO - 2018-04-20 01:04:42 --> Language Class Initialized
ERROR - 2018-04-20 01:04:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:06:16 --> Config Class Initialized
INFO - 2018-04-20 01:06:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:06:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:06:16 --> Utf8 Class Initialized
INFO - 2018-04-20 01:06:16 --> URI Class Initialized
INFO - 2018-04-20 01:06:16 --> Router Class Initialized
INFO - 2018-04-20 01:06:16 --> Output Class Initialized
INFO - 2018-04-20 01:06:16 --> Security Class Initialized
DEBUG - 2018-04-20 01:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:06:16 --> CSRF cookie sent
INFO - 2018-04-20 01:06:16 --> Input Class Initialized
INFO - 2018-04-20 01:06:16 --> Language Class Initialized
INFO - 2018-04-20 01:06:16 --> Loader Class Initialized
INFO - 2018-04-20 01:06:16 --> Helper loaded: url_helper
INFO - 2018-04-20 01:06:16 --> Helper loaded: form_helper
INFO - 2018-04-20 01:06:16 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:06:16 --> User Agent Class Initialized
INFO - 2018-04-20 01:06:16 --> Controller Class Initialized
INFO - 2018-04-20 01:06:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:06:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:06:16 --> Pixel_Model class loaded
INFO - 2018-04-20 01:06:16 --> Database Driver Class Initialized
INFO - 2018-04-20 01:06:16 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:06:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:06:16 --> Final output sent to browser
DEBUG - 2018-04-20 01:06:16 --> Total execution time: 0.3779
INFO - 2018-04-20 01:06:16 --> Config Class Initialized
INFO - 2018-04-20 01:06:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:06:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:06:16 --> Utf8 Class Initialized
INFO - 2018-04-20 01:06:16 --> URI Class Initialized
INFO - 2018-04-20 01:06:16 --> Router Class Initialized
INFO - 2018-04-20 01:06:16 --> Output Class Initialized
INFO - 2018-04-20 01:06:17 --> Security Class Initialized
DEBUG - 2018-04-20 01:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:06:17 --> CSRF cookie sent
INFO - 2018-04-20 01:06:17 --> Input Class Initialized
INFO - 2018-04-20 01:06:17 --> Language Class Initialized
ERROR - 2018-04-20 01:06:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:07:07 --> Config Class Initialized
INFO - 2018-04-20 01:07:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:07:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:07:07 --> Utf8 Class Initialized
INFO - 2018-04-20 01:07:07 --> URI Class Initialized
INFO - 2018-04-20 01:07:07 --> Router Class Initialized
INFO - 2018-04-20 01:07:07 --> Output Class Initialized
INFO - 2018-04-20 01:07:07 --> Security Class Initialized
DEBUG - 2018-04-20 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:07:07 --> CSRF cookie sent
INFO - 2018-04-20 01:07:07 --> Input Class Initialized
INFO - 2018-04-20 01:07:07 --> Language Class Initialized
INFO - 2018-04-20 01:07:07 --> Loader Class Initialized
INFO - 2018-04-20 01:07:07 --> Helper loaded: url_helper
INFO - 2018-04-20 01:07:07 --> Helper loaded: form_helper
INFO - 2018-04-20 01:07:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:07:07 --> User Agent Class Initialized
INFO - 2018-04-20 01:07:07 --> Controller Class Initialized
INFO - 2018-04-20 01:07:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:07:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:07:07 --> Pixel_Model class loaded
INFO - 2018-04-20 01:07:07 --> Database Driver Class Initialized
INFO - 2018-04-20 01:07:07 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:07:07 --> Final output sent to browser
DEBUG - 2018-04-20 01:07:07 --> Total execution time: 0.3833
INFO - 2018-04-20 01:07:07 --> Config Class Initialized
INFO - 2018-04-20 01:07:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:07:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:07:07 --> Utf8 Class Initialized
INFO - 2018-04-20 01:07:07 --> URI Class Initialized
INFO - 2018-04-20 01:07:08 --> Router Class Initialized
INFO - 2018-04-20 01:07:08 --> Output Class Initialized
INFO - 2018-04-20 01:07:08 --> Security Class Initialized
DEBUG - 2018-04-20 01:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:07:08 --> CSRF cookie sent
INFO - 2018-04-20 01:07:08 --> Input Class Initialized
INFO - 2018-04-20 01:07:08 --> Language Class Initialized
ERROR - 2018-04-20 01:07:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:08:03 --> Config Class Initialized
INFO - 2018-04-20 01:08:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:03 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:03 --> URI Class Initialized
INFO - 2018-04-20 01:08:03 --> Router Class Initialized
INFO - 2018-04-20 01:08:03 --> Output Class Initialized
INFO - 2018-04-20 01:08:04 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:04 --> CSRF cookie sent
INFO - 2018-04-20 01:08:04 --> Input Class Initialized
INFO - 2018-04-20 01:08:04 --> Language Class Initialized
INFO - 2018-04-20 01:08:04 --> Loader Class Initialized
INFO - 2018-04-20 01:08:04 --> Helper loaded: url_helper
INFO - 2018-04-20 01:08:04 --> Helper loaded: form_helper
INFO - 2018-04-20 01:08:04 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:08:04 --> User Agent Class Initialized
INFO - 2018-04-20 01:08:04 --> Controller Class Initialized
INFO - 2018-04-20 01:08:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:08:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:08:04 --> Pixel_Model class loaded
INFO - 2018-04-20 01:08:04 --> Database Driver Class Initialized
INFO - 2018-04-20 01:08:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:08:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:08:04 --> Final output sent to browser
DEBUG - 2018-04-20 01:08:04 --> Total execution time: 0.3963
INFO - 2018-04-20 01:08:04 --> Config Class Initialized
INFO - 2018-04-20 01:08:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:04 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:04 --> URI Class Initialized
INFO - 2018-04-20 01:08:04 --> Router Class Initialized
INFO - 2018-04-20 01:08:04 --> Output Class Initialized
INFO - 2018-04-20 01:08:04 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:04 --> CSRF cookie sent
INFO - 2018-04-20 01:08:04 --> Input Class Initialized
INFO - 2018-04-20 01:08:04 --> Language Class Initialized
ERROR - 2018-04-20 01:08:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:08:19 --> Config Class Initialized
INFO - 2018-04-20 01:08:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:19 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:19 --> URI Class Initialized
INFO - 2018-04-20 01:08:19 --> Router Class Initialized
INFO - 2018-04-20 01:08:19 --> Output Class Initialized
INFO - 2018-04-20 01:08:19 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:19 --> CSRF cookie sent
INFO - 2018-04-20 01:08:19 --> Input Class Initialized
INFO - 2018-04-20 01:08:19 --> Language Class Initialized
INFO - 2018-04-20 01:08:19 --> Loader Class Initialized
INFO - 2018-04-20 01:08:19 --> Helper loaded: url_helper
INFO - 2018-04-20 01:08:19 --> Helper loaded: form_helper
INFO - 2018-04-20 01:08:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:08:19 --> User Agent Class Initialized
INFO - 2018-04-20 01:08:19 --> Controller Class Initialized
INFO - 2018-04-20 01:08:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:08:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:08:19 --> Pixel_Model class loaded
INFO - 2018-04-20 01:08:19 --> Database Driver Class Initialized
INFO - 2018-04-20 01:08:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:08:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:08:20 --> Final output sent to browser
DEBUG - 2018-04-20 01:08:20 --> Total execution time: 0.4163
INFO - 2018-04-20 01:08:20 --> Config Class Initialized
INFO - 2018-04-20 01:08:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:20 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:20 --> URI Class Initialized
INFO - 2018-04-20 01:08:20 --> Router Class Initialized
INFO - 2018-04-20 01:08:20 --> Output Class Initialized
INFO - 2018-04-20 01:08:20 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:20 --> CSRF cookie sent
INFO - 2018-04-20 01:08:20 --> Input Class Initialized
INFO - 2018-04-20 01:08:20 --> Language Class Initialized
ERROR - 2018-04-20 01:08:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:08:39 --> Config Class Initialized
INFO - 2018-04-20 01:08:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:39 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:39 --> URI Class Initialized
INFO - 2018-04-20 01:08:39 --> Router Class Initialized
INFO - 2018-04-20 01:08:39 --> Output Class Initialized
INFO - 2018-04-20 01:08:39 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:39 --> CSRF cookie sent
INFO - 2018-04-20 01:08:39 --> Input Class Initialized
INFO - 2018-04-20 01:08:39 --> Language Class Initialized
INFO - 2018-04-20 01:08:39 --> Loader Class Initialized
INFO - 2018-04-20 01:08:39 --> Helper loaded: url_helper
INFO - 2018-04-20 01:08:39 --> Helper loaded: form_helper
INFO - 2018-04-20 01:08:39 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:08:39 --> User Agent Class Initialized
INFO - 2018-04-20 01:08:39 --> Controller Class Initialized
INFO - 2018-04-20 01:08:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:08:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:08:39 --> Pixel_Model class loaded
INFO - 2018-04-20 01:08:39 --> Database Driver Class Initialized
INFO - 2018-04-20 01:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:08:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:08:39 --> Final output sent to browser
DEBUG - 2018-04-20 01:08:39 --> Total execution time: 0.4163
INFO - 2018-04-20 01:08:40 --> Config Class Initialized
INFO - 2018-04-20 01:08:40 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:08:40 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:08:40 --> Utf8 Class Initialized
INFO - 2018-04-20 01:08:40 --> URI Class Initialized
INFO - 2018-04-20 01:08:40 --> Router Class Initialized
INFO - 2018-04-20 01:08:40 --> Output Class Initialized
INFO - 2018-04-20 01:08:40 --> Security Class Initialized
DEBUG - 2018-04-20 01:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:08:40 --> CSRF cookie sent
INFO - 2018-04-20 01:08:40 --> Input Class Initialized
INFO - 2018-04-20 01:08:40 --> Language Class Initialized
ERROR - 2018-04-20 01:08:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:09:25 --> Config Class Initialized
INFO - 2018-04-20 01:09:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:09:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:09:25 --> Utf8 Class Initialized
INFO - 2018-04-20 01:09:25 --> URI Class Initialized
INFO - 2018-04-20 01:09:25 --> Router Class Initialized
INFO - 2018-04-20 01:09:25 --> Output Class Initialized
INFO - 2018-04-20 01:09:25 --> Security Class Initialized
DEBUG - 2018-04-20 01:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:09:25 --> CSRF cookie sent
INFO - 2018-04-20 01:09:25 --> Input Class Initialized
INFO - 2018-04-20 01:09:25 --> Language Class Initialized
INFO - 2018-04-20 01:09:25 --> Loader Class Initialized
INFO - 2018-04-20 01:09:25 --> Helper loaded: url_helper
INFO - 2018-04-20 01:09:25 --> Helper loaded: form_helper
INFO - 2018-04-20 01:09:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:09:25 --> User Agent Class Initialized
INFO - 2018-04-20 01:09:25 --> Controller Class Initialized
INFO - 2018-04-20 01:09:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:09:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:09:25 --> Pixel_Model class loaded
INFO - 2018-04-20 01:09:25 --> Database Driver Class Initialized
INFO - 2018-04-20 01:09:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:09:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:09:25 --> Final output sent to browser
DEBUG - 2018-04-20 01:09:25 --> Total execution time: 0.4133
INFO - 2018-04-20 01:09:25 --> Config Class Initialized
INFO - 2018-04-20 01:09:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:09:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:09:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:09:26 --> URI Class Initialized
INFO - 2018-04-20 01:09:26 --> Router Class Initialized
INFO - 2018-04-20 01:09:26 --> Output Class Initialized
INFO - 2018-04-20 01:09:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:09:26 --> CSRF cookie sent
INFO - 2018-04-20 01:09:26 --> Input Class Initialized
INFO - 2018-04-20 01:09:26 --> Language Class Initialized
ERROR - 2018-04-20 01:09:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:10:00 --> Config Class Initialized
INFO - 2018-04-20 01:10:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:10:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:10:00 --> Utf8 Class Initialized
INFO - 2018-04-20 01:10:00 --> URI Class Initialized
INFO - 2018-04-20 01:10:00 --> Router Class Initialized
INFO - 2018-04-20 01:10:00 --> Output Class Initialized
INFO - 2018-04-20 01:10:00 --> Security Class Initialized
DEBUG - 2018-04-20 01:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:10:00 --> CSRF cookie sent
INFO - 2018-04-20 01:10:00 --> Input Class Initialized
INFO - 2018-04-20 01:10:00 --> Language Class Initialized
INFO - 2018-04-20 01:10:00 --> Loader Class Initialized
INFO - 2018-04-20 01:10:00 --> Helper loaded: url_helper
INFO - 2018-04-20 01:10:00 --> Helper loaded: form_helper
INFO - 2018-04-20 01:10:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:10:00 --> User Agent Class Initialized
INFO - 2018-04-20 01:10:00 --> Controller Class Initialized
INFO - 2018-04-20 01:10:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:10:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:10:00 --> Pixel_Model class loaded
INFO - 2018-04-20 01:10:00 --> Database Driver Class Initialized
INFO - 2018-04-20 01:10:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:10:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:10:00 --> Final output sent to browser
DEBUG - 2018-04-20 01:10:00 --> Total execution time: 0.3982
INFO - 2018-04-20 01:10:01 --> Config Class Initialized
INFO - 2018-04-20 01:10:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:10:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:10:01 --> Utf8 Class Initialized
INFO - 2018-04-20 01:10:01 --> URI Class Initialized
INFO - 2018-04-20 01:10:01 --> Router Class Initialized
INFO - 2018-04-20 01:10:01 --> Output Class Initialized
INFO - 2018-04-20 01:10:01 --> Security Class Initialized
DEBUG - 2018-04-20 01:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:10:01 --> CSRF cookie sent
INFO - 2018-04-20 01:10:01 --> Input Class Initialized
INFO - 2018-04-20 01:10:01 --> Language Class Initialized
ERROR - 2018-04-20 01:10:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:12:43 --> Config Class Initialized
INFO - 2018-04-20 01:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:12:43 --> Utf8 Class Initialized
INFO - 2018-04-20 01:12:43 --> URI Class Initialized
INFO - 2018-04-20 01:12:43 --> Router Class Initialized
INFO - 2018-04-20 01:12:43 --> Output Class Initialized
INFO - 2018-04-20 01:12:43 --> Security Class Initialized
DEBUG - 2018-04-20 01:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:12:43 --> CSRF cookie sent
INFO - 2018-04-20 01:12:43 --> Input Class Initialized
INFO - 2018-04-20 01:12:44 --> Language Class Initialized
INFO - 2018-04-20 01:12:44 --> Loader Class Initialized
INFO - 2018-04-20 01:12:44 --> Helper loaded: url_helper
INFO - 2018-04-20 01:12:44 --> Helper loaded: form_helper
INFO - 2018-04-20 01:12:44 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:12:44 --> User Agent Class Initialized
INFO - 2018-04-20 01:12:44 --> Controller Class Initialized
INFO - 2018-04-20 01:12:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:12:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:12:44 --> Pixel_Model class loaded
INFO - 2018-04-20 01:12:44 --> Database Driver Class Initialized
INFO - 2018-04-20 01:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:12:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:12:44 --> Final output sent to browser
DEBUG - 2018-04-20 01:12:44 --> Total execution time: 0.4309
INFO - 2018-04-20 01:12:44 --> Config Class Initialized
INFO - 2018-04-20 01:12:44 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:12:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:12:44 --> Utf8 Class Initialized
INFO - 2018-04-20 01:12:44 --> URI Class Initialized
INFO - 2018-04-20 01:12:44 --> Router Class Initialized
INFO - 2018-04-20 01:12:44 --> Output Class Initialized
INFO - 2018-04-20 01:12:44 --> Security Class Initialized
DEBUG - 2018-04-20 01:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:12:44 --> CSRF cookie sent
INFO - 2018-04-20 01:12:44 --> Input Class Initialized
INFO - 2018-04-20 01:12:44 --> Language Class Initialized
ERROR - 2018-04-20 01:12:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:15:08 --> Config Class Initialized
INFO - 2018-04-20 01:15:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:08 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:08 --> URI Class Initialized
INFO - 2018-04-20 01:15:08 --> Router Class Initialized
INFO - 2018-04-20 01:15:08 --> Output Class Initialized
INFO - 2018-04-20 01:15:08 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:08 --> CSRF cookie sent
INFO - 2018-04-20 01:15:08 --> Input Class Initialized
INFO - 2018-04-20 01:15:08 --> Language Class Initialized
INFO - 2018-04-20 01:15:08 --> Loader Class Initialized
INFO - 2018-04-20 01:15:08 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:08 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:08 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:08 --> Controller Class Initialized
INFO - 2018-04-20 01:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:08 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:08 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 01:15:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:15:08 --> Final output sent to browser
DEBUG - 2018-04-20 01:15:08 --> Total execution time: 0.3947
INFO - 2018-04-20 01:15:09 --> Config Class Initialized
INFO - 2018-04-20 01:15:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:09 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:09 --> URI Class Initialized
INFO - 2018-04-20 01:15:09 --> Router Class Initialized
INFO - 2018-04-20 01:15:09 --> Output Class Initialized
INFO - 2018-04-20 01:15:09 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:09 --> CSRF cookie sent
INFO - 2018-04-20 01:15:09 --> Input Class Initialized
INFO - 2018-04-20 01:15:09 --> Language Class Initialized
ERROR - 2018-04-20 01:15:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:15:11 --> Config Class Initialized
INFO - 2018-04-20 01:15:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:11 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:11 --> URI Class Initialized
INFO - 2018-04-20 01:15:11 --> Router Class Initialized
INFO - 2018-04-20 01:15:11 --> Output Class Initialized
INFO - 2018-04-20 01:15:11 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:11 --> CSRF cookie sent
INFO - 2018-04-20 01:15:11 --> CSRF token verified
INFO - 2018-04-20 01:15:11 --> Input Class Initialized
INFO - 2018-04-20 01:15:11 --> Language Class Initialized
INFO - 2018-04-20 01:15:11 --> Loader Class Initialized
INFO - 2018-04-20 01:15:11 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:11 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:11 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:11 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:11 --> Controller Class Initialized
INFO - 2018-04-20 01:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:11 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:11 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:11 --> Form Validation Class Initialized
INFO - 2018-04-20 01:15:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:15:11 --> Config Class Initialized
INFO - 2018-04-20 01:15:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:11 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:11 --> URI Class Initialized
INFO - 2018-04-20 01:15:11 --> Router Class Initialized
INFO - 2018-04-20 01:15:11 --> Output Class Initialized
INFO - 2018-04-20 01:15:11 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:11 --> CSRF cookie sent
INFO - 2018-04-20 01:15:11 --> Input Class Initialized
INFO - 2018-04-20 01:15:11 --> Language Class Initialized
INFO - 2018-04-20 01:15:11 --> Loader Class Initialized
INFO - 2018-04-20 01:15:11 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:11 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:11 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:11 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:11 --> Controller Class Initialized
INFO - 2018-04-20 01:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:11 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:11 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:15:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:15:11 --> Final output sent to browser
DEBUG - 2018-04-20 01:15:11 --> Total execution time: 0.3832
INFO - 2018-04-20 01:15:12 --> Config Class Initialized
INFO - 2018-04-20 01:15:12 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:12 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:12 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:12 --> URI Class Initialized
INFO - 2018-04-20 01:15:12 --> Router Class Initialized
INFO - 2018-04-20 01:15:12 --> Output Class Initialized
INFO - 2018-04-20 01:15:12 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:12 --> CSRF cookie sent
INFO - 2018-04-20 01:15:12 --> Input Class Initialized
INFO - 2018-04-20 01:15:12 --> Language Class Initialized
ERROR - 2018-04-20 01:15:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:15:15 --> Config Class Initialized
INFO - 2018-04-20 01:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:15 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:15 --> URI Class Initialized
INFO - 2018-04-20 01:15:15 --> Router Class Initialized
INFO - 2018-04-20 01:15:15 --> Output Class Initialized
INFO - 2018-04-20 01:15:15 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:15 --> CSRF cookie sent
INFO - 2018-04-20 01:15:15 --> CSRF token verified
INFO - 2018-04-20 01:15:15 --> Input Class Initialized
INFO - 2018-04-20 01:15:15 --> Language Class Initialized
INFO - 2018-04-20 01:15:15 --> Loader Class Initialized
INFO - 2018-04-20 01:15:15 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:15 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:15 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:15 --> Controller Class Initialized
INFO - 2018-04-20 01:15:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:15 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:15 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:15 --> Form Validation Class Initialized
INFO - 2018-04-20 01:15:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:15:15 --> Config Class Initialized
INFO - 2018-04-20 01:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:15 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:15 --> URI Class Initialized
INFO - 2018-04-20 01:15:15 --> Router Class Initialized
INFO - 2018-04-20 01:15:15 --> Output Class Initialized
INFO - 2018-04-20 01:15:15 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:15 --> CSRF cookie sent
INFO - 2018-04-20 01:15:15 --> Input Class Initialized
INFO - 2018-04-20 01:15:15 --> Language Class Initialized
INFO - 2018-04-20 01:15:15 --> Loader Class Initialized
INFO - 2018-04-20 01:15:15 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:15 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:15 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:16 --> Controller Class Initialized
INFO - 2018-04-20 01:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:16 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:16 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:15:16 --> Final output sent to browser
DEBUG - 2018-04-20 01:15:16 --> Total execution time: 0.3903
INFO - 2018-04-20 01:15:16 --> Config Class Initialized
INFO - 2018-04-20 01:15:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:16 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:16 --> URI Class Initialized
INFO - 2018-04-20 01:15:16 --> Router Class Initialized
INFO - 2018-04-20 01:15:16 --> Output Class Initialized
INFO - 2018-04-20 01:15:16 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:16 --> CSRF cookie sent
INFO - 2018-04-20 01:15:16 --> Input Class Initialized
INFO - 2018-04-20 01:15:16 --> Language Class Initialized
ERROR - 2018-04-20 01:15:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:15:20 --> Config Class Initialized
INFO - 2018-04-20 01:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:20 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:20 --> URI Class Initialized
INFO - 2018-04-20 01:15:20 --> Router Class Initialized
INFO - 2018-04-20 01:15:20 --> Output Class Initialized
INFO - 2018-04-20 01:15:20 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:20 --> CSRF cookie sent
INFO - 2018-04-20 01:15:20 --> Input Class Initialized
INFO - 2018-04-20 01:15:20 --> Language Class Initialized
INFO - 2018-04-20 01:15:20 --> Loader Class Initialized
INFO - 2018-04-20 01:15:20 --> Helper loaded: url_helper
INFO - 2018-04-20 01:15:20 --> Helper loaded: form_helper
INFO - 2018-04-20 01:15:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:15:20 --> User Agent Class Initialized
INFO - 2018-04-20 01:15:20 --> Controller Class Initialized
INFO - 2018-04-20 01:15:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:15:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:15:20 --> Pixel_Model class loaded
INFO - 2018-04-20 01:15:20 --> Database Driver Class Initialized
INFO - 2018-04-20 01:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:15:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:15:20 --> Final output sent to browser
DEBUG - 2018-04-20 01:15:20 --> Total execution time: 0.3912
INFO - 2018-04-20 01:15:21 --> Config Class Initialized
INFO - 2018-04-20 01:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:15:21 --> Utf8 Class Initialized
INFO - 2018-04-20 01:15:21 --> URI Class Initialized
INFO - 2018-04-20 01:15:21 --> Router Class Initialized
INFO - 2018-04-20 01:15:21 --> Output Class Initialized
INFO - 2018-04-20 01:15:21 --> Security Class Initialized
DEBUG - 2018-04-20 01:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:15:21 --> CSRF cookie sent
INFO - 2018-04-20 01:15:21 --> Input Class Initialized
INFO - 2018-04-20 01:15:21 --> Language Class Initialized
ERROR - 2018-04-20 01:15:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:17:31 --> Config Class Initialized
INFO - 2018-04-20 01:17:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:17:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:17:31 --> Utf8 Class Initialized
INFO - 2018-04-20 01:17:31 --> URI Class Initialized
INFO - 2018-04-20 01:17:31 --> Router Class Initialized
INFO - 2018-04-20 01:17:31 --> Output Class Initialized
INFO - 2018-04-20 01:17:31 --> Security Class Initialized
DEBUG - 2018-04-20 01:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:17:31 --> CSRF cookie sent
INFO - 2018-04-20 01:17:31 --> Input Class Initialized
INFO - 2018-04-20 01:17:31 --> Language Class Initialized
INFO - 2018-04-20 01:17:31 --> Loader Class Initialized
INFO - 2018-04-20 01:17:31 --> Helper loaded: url_helper
INFO - 2018-04-20 01:17:31 --> Helper loaded: form_helper
INFO - 2018-04-20 01:17:31 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:17:31 --> User Agent Class Initialized
INFO - 2018-04-20 01:17:31 --> Controller Class Initialized
INFO - 2018-04-20 01:17:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:17:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:17:31 --> Pixel_Model class loaded
INFO - 2018-04-20 01:17:31 --> Database Driver Class Initialized
INFO - 2018-04-20 01:17:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 01:17:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:17:31 --> Final output sent to browser
DEBUG - 2018-04-20 01:17:31 --> Total execution time: 0.4338
INFO - 2018-04-20 01:17:31 --> Config Class Initialized
INFO - 2018-04-20 01:17:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:17:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:17:32 --> Utf8 Class Initialized
INFO - 2018-04-20 01:17:32 --> URI Class Initialized
INFO - 2018-04-20 01:17:32 --> Router Class Initialized
INFO - 2018-04-20 01:17:32 --> Output Class Initialized
INFO - 2018-04-20 01:17:32 --> Security Class Initialized
DEBUG - 2018-04-20 01:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:17:32 --> CSRF cookie sent
INFO - 2018-04-20 01:17:32 --> Input Class Initialized
INFO - 2018-04-20 01:17:32 --> Language Class Initialized
ERROR - 2018-04-20 01:17:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:11 --> Config Class Initialized
INFO - 2018-04-20 01:23:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:11 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:11 --> URI Class Initialized
INFO - 2018-04-20 01:23:11 --> Router Class Initialized
INFO - 2018-04-20 01:23:11 --> Output Class Initialized
INFO - 2018-04-20 01:23:11 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:11 --> CSRF cookie sent
INFO - 2018-04-20 01:23:11 --> Input Class Initialized
INFO - 2018-04-20 01:23:11 --> Language Class Initialized
INFO - 2018-04-20 01:23:11 --> Loader Class Initialized
INFO - 2018-04-20 01:23:11 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:11 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:11 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:11 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:11 --> Controller Class Initialized
INFO - 2018-04-20 01:23:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:11 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:11 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:11 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:23:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:11 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:11 --> Total execution time: 0.5789
INFO - 2018-04-20 01:23:12 --> Config Class Initialized
INFO - 2018-04-20 01:23:12 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:12 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:12 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:12 --> URI Class Initialized
INFO - 2018-04-20 01:23:12 --> Router Class Initialized
INFO - 2018-04-20 01:23:12 --> Output Class Initialized
INFO - 2018-04-20 01:23:12 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:12 --> CSRF cookie sent
INFO - 2018-04-20 01:23:12 --> Input Class Initialized
INFO - 2018-04-20 01:23:12 --> Language Class Initialized
ERROR - 2018-04-20 01:23:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:17 --> Config Class Initialized
INFO - 2018-04-20 01:23:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:17 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:17 --> URI Class Initialized
INFO - 2018-04-20 01:23:17 --> Router Class Initialized
INFO - 2018-04-20 01:23:17 --> Output Class Initialized
INFO - 2018-04-20 01:23:17 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:17 --> CSRF cookie sent
INFO - 2018-04-20 01:23:17 --> Input Class Initialized
INFO - 2018-04-20 01:23:17 --> Language Class Initialized
INFO - 2018-04-20 01:23:17 --> Loader Class Initialized
INFO - 2018-04-20 01:23:17 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:17 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:17 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:17 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:17 --> Controller Class Initialized
INFO - 2018-04-20 01:23:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:17 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:17 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:17 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:23:17 --> Config Class Initialized
INFO - 2018-04-20 01:23:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:17 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:17 --> URI Class Initialized
INFO - 2018-04-20 01:23:17 --> Router Class Initialized
INFO - 2018-04-20 01:23:17 --> Output Class Initialized
INFO - 2018-04-20 01:23:17 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:17 --> CSRF cookie sent
INFO - 2018-04-20 01:23:17 --> Input Class Initialized
INFO - 2018-04-20 01:23:17 --> Language Class Initialized
INFO - 2018-04-20 01:23:17 --> Loader Class Initialized
INFO - 2018-04-20 01:23:17 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:17 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:17 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:17 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:17 --> Controller Class Initialized
INFO - 2018-04-20 01:23:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:17 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:17 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:17 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:23:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:17 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:18 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:23:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:18 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:18 --> Total execution time: 0.3887
INFO - 2018-04-20 01:23:18 --> Config Class Initialized
INFO - 2018-04-20 01:23:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:18 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:18 --> URI Class Initialized
INFO - 2018-04-20 01:23:18 --> Router Class Initialized
INFO - 2018-04-20 01:23:18 --> Output Class Initialized
INFO - 2018-04-20 01:23:18 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:18 --> CSRF cookie sent
INFO - 2018-04-20 01:23:18 --> Input Class Initialized
INFO - 2018-04-20 01:23:18 --> Language Class Initialized
ERROR - 2018-04-20 01:23:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:22 --> Config Class Initialized
INFO - 2018-04-20 01:23:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:22 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:22 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:22 --> URI Class Initialized
INFO - 2018-04-20 01:23:22 --> Router Class Initialized
INFO - 2018-04-20 01:23:22 --> Output Class Initialized
INFO - 2018-04-20 01:23:22 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:22 --> CSRF cookie sent
INFO - 2018-04-20 01:23:22 --> Input Class Initialized
INFO - 2018-04-20 01:23:22 --> Language Class Initialized
INFO - 2018-04-20 01:23:22 --> Loader Class Initialized
INFO - 2018-04-20 01:23:22 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:22 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:22 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:22 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:22 --> Controller Class Initialized
INFO - 2018-04-20 01:23:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:22 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:22 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 01:23:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:22 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:22 --> Total execution time: 0.4102
INFO - 2018-04-20 01:23:23 --> Config Class Initialized
INFO - 2018-04-20 01:23:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:23 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:23 --> URI Class Initialized
INFO - 2018-04-20 01:23:23 --> Router Class Initialized
INFO - 2018-04-20 01:23:23 --> Output Class Initialized
INFO - 2018-04-20 01:23:23 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:23 --> CSRF cookie sent
INFO - 2018-04-20 01:23:23 --> Input Class Initialized
INFO - 2018-04-20 01:23:23 --> Language Class Initialized
ERROR - 2018-04-20 01:23:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:25 --> Config Class Initialized
INFO - 2018-04-20 01:23:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:26 --> URI Class Initialized
INFO - 2018-04-20 01:23:26 --> Router Class Initialized
INFO - 2018-04-20 01:23:26 --> Output Class Initialized
INFO - 2018-04-20 01:23:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:26 --> CSRF cookie sent
INFO - 2018-04-20 01:23:26 --> CSRF token verified
INFO - 2018-04-20 01:23:26 --> Input Class Initialized
INFO - 2018-04-20 01:23:26 --> Language Class Initialized
INFO - 2018-04-20 01:23:26 --> Loader Class Initialized
INFO - 2018-04-20 01:23:26 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:26 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:26 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:26 --> Controller Class Initialized
INFO - 2018-04-20 01:23:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:26 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:26 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:23:26 --> Form Validation Class Initialized
INFO - 2018-04-20 01:23:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:23:26 --> Config Class Initialized
INFO - 2018-04-20 01:23:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:26 --> URI Class Initialized
INFO - 2018-04-20 01:23:26 --> Router Class Initialized
INFO - 2018-04-20 01:23:26 --> Output Class Initialized
INFO - 2018-04-20 01:23:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:26 --> CSRF cookie sent
INFO - 2018-04-20 01:23:26 --> Input Class Initialized
INFO - 2018-04-20 01:23:26 --> Language Class Initialized
INFO - 2018-04-20 01:23:26 --> Loader Class Initialized
INFO - 2018-04-20 01:23:26 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:26 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:26 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:26 --> Controller Class Initialized
INFO - 2018-04-20 01:23:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:26 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:26 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:26 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:26 --> Total execution time: 0.3960
INFO - 2018-04-20 01:23:27 --> Config Class Initialized
INFO - 2018-04-20 01:23:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:27 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:27 --> URI Class Initialized
INFO - 2018-04-20 01:23:27 --> Router Class Initialized
INFO - 2018-04-20 01:23:27 --> Output Class Initialized
INFO - 2018-04-20 01:23:27 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:27 --> CSRF cookie sent
INFO - 2018-04-20 01:23:27 --> Input Class Initialized
INFO - 2018-04-20 01:23:27 --> Language Class Initialized
ERROR - 2018-04-20 01:23:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:31 --> Config Class Initialized
INFO - 2018-04-20 01:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:31 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:31 --> URI Class Initialized
INFO - 2018-04-20 01:23:31 --> Router Class Initialized
INFO - 2018-04-20 01:23:31 --> Output Class Initialized
INFO - 2018-04-20 01:23:31 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:31 --> CSRF cookie sent
INFO - 2018-04-20 01:23:31 --> Input Class Initialized
INFO - 2018-04-20 01:23:31 --> Language Class Initialized
INFO - 2018-04-20 01:23:31 --> Loader Class Initialized
INFO - 2018-04-20 01:23:31 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:31 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:31 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:31 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:31 --> Controller Class Initialized
INFO - 2018-04-20 01:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:31 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:31 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:23:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:31 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:31 --> Total execution time: 0.4110
INFO - 2018-04-20 01:23:32 --> Config Class Initialized
INFO - 2018-04-20 01:23:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:32 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:32 --> URI Class Initialized
INFO - 2018-04-20 01:23:32 --> Router Class Initialized
INFO - 2018-04-20 01:23:32 --> Output Class Initialized
INFO - 2018-04-20 01:23:32 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:32 --> CSRF cookie sent
INFO - 2018-04-20 01:23:32 --> Input Class Initialized
INFO - 2018-04-20 01:23:32 --> Language Class Initialized
ERROR - 2018-04-20 01:23:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:23:33 --> Config Class Initialized
INFO - 2018-04-20 01:23:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:33 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:33 --> URI Class Initialized
INFO - 2018-04-20 01:23:33 --> Router Class Initialized
INFO - 2018-04-20 01:23:33 --> Output Class Initialized
INFO - 2018-04-20 01:23:33 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:33 --> CSRF cookie sent
INFO - 2018-04-20 01:23:33 --> Input Class Initialized
INFO - 2018-04-20 01:23:33 --> Language Class Initialized
INFO - 2018-04-20 01:23:33 --> Loader Class Initialized
INFO - 2018-04-20 01:23:33 --> Helper loaded: url_helper
INFO - 2018-04-20 01:23:33 --> Helper loaded: form_helper
INFO - 2018-04-20 01:23:33 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:23:33 --> User Agent Class Initialized
INFO - 2018-04-20 01:23:33 --> Controller Class Initialized
INFO - 2018-04-20 01:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:23:33 --> Pixel_Model class loaded
INFO - 2018-04-20 01:23:33 --> Database Driver Class Initialized
INFO - 2018-04-20 01:23:33 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:23:34 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:23:34 --> Final output sent to browser
DEBUG - 2018-04-20 01:23:34 --> Total execution time: 0.4124
INFO - 2018-04-20 01:23:34 --> Config Class Initialized
INFO - 2018-04-20 01:23:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:23:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:23:34 --> Utf8 Class Initialized
INFO - 2018-04-20 01:23:34 --> URI Class Initialized
INFO - 2018-04-20 01:23:34 --> Router Class Initialized
INFO - 2018-04-20 01:23:34 --> Output Class Initialized
INFO - 2018-04-20 01:23:34 --> Security Class Initialized
DEBUG - 2018-04-20 01:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:23:34 --> CSRF cookie sent
INFO - 2018-04-20 01:23:34 --> Input Class Initialized
INFO - 2018-04-20 01:23:34 --> Language Class Initialized
ERROR - 2018-04-20 01:23:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:24:05 --> Config Class Initialized
INFO - 2018-04-20 01:24:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:06 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:06 --> URI Class Initialized
INFO - 2018-04-20 01:24:06 --> Router Class Initialized
INFO - 2018-04-20 01:24:06 --> Output Class Initialized
INFO - 2018-04-20 01:24:06 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:06 --> CSRF cookie sent
INFO - 2018-04-20 01:24:06 --> Input Class Initialized
INFO - 2018-04-20 01:24:06 --> Language Class Initialized
INFO - 2018-04-20 01:24:06 --> Loader Class Initialized
INFO - 2018-04-20 01:24:06 --> Helper loaded: url_helper
INFO - 2018-04-20 01:24:06 --> Helper loaded: form_helper
INFO - 2018-04-20 01:24:06 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:24:06 --> User Agent Class Initialized
INFO - 2018-04-20 01:24:06 --> Controller Class Initialized
INFO - 2018-04-20 01:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:24:06 --> Pixel_Model class loaded
INFO - 2018-04-20 01:24:06 --> Database Driver Class Initialized
INFO - 2018-04-20 01:24:06 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:24:06 --> Config Class Initialized
INFO - 2018-04-20 01:24:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:06 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:06 --> URI Class Initialized
INFO - 2018-04-20 01:24:06 --> Router Class Initialized
INFO - 2018-04-20 01:24:06 --> Output Class Initialized
INFO - 2018-04-20 01:24:06 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:06 --> CSRF cookie sent
INFO - 2018-04-20 01:24:06 --> Input Class Initialized
INFO - 2018-04-20 01:24:06 --> Language Class Initialized
INFO - 2018-04-20 01:24:06 --> Loader Class Initialized
INFO - 2018-04-20 01:24:06 --> Helper loaded: url_helper
INFO - 2018-04-20 01:24:06 --> Helper loaded: form_helper
INFO - 2018-04-20 01:24:06 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:24:06 --> User Agent Class Initialized
INFO - 2018-04-20 01:24:06 --> Controller Class Initialized
INFO - 2018-04-20 01:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:24:06 --> Pixel_Model class loaded
INFO - 2018-04-20 01:24:06 --> Database Driver Class Initialized
INFO - 2018-04-20 01:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:24:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:24:06 --> Final output sent to browser
DEBUG - 2018-04-20 01:24:06 --> Total execution time: 0.4201
INFO - 2018-04-20 01:24:07 --> Config Class Initialized
INFO - 2018-04-20 01:24:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:07 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:07 --> URI Class Initialized
INFO - 2018-04-20 01:24:07 --> Router Class Initialized
INFO - 2018-04-20 01:24:07 --> Output Class Initialized
INFO - 2018-04-20 01:24:07 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:07 --> CSRF cookie sent
INFO - 2018-04-20 01:24:07 --> Input Class Initialized
INFO - 2018-04-20 01:24:07 --> Language Class Initialized
ERROR - 2018-04-20 01:24:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:24:10 --> Config Class Initialized
INFO - 2018-04-20 01:24:10 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:10 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:10 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:10 --> URI Class Initialized
INFO - 2018-04-20 01:24:10 --> Router Class Initialized
INFO - 2018-04-20 01:24:10 --> Output Class Initialized
INFO - 2018-04-20 01:24:10 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:10 --> CSRF cookie sent
INFO - 2018-04-20 01:24:10 --> Input Class Initialized
INFO - 2018-04-20 01:24:10 --> Language Class Initialized
INFO - 2018-04-20 01:24:10 --> Loader Class Initialized
INFO - 2018-04-20 01:24:10 --> Helper loaded: url_helper
INFO - 2018-04-20 01:24:10 --> Helper loaded: form_helper
INFO - 2018-04-20 01:24:10 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:24:10 --> User Agent Class Initialized
INFO - 2018-04-20 01:24:10 --> Controller Class Initialized
INFO - 2018-04-20 01:24:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:24:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:24:10 --> Pixel_Model class loaded
INFO - 2018-04-20 01:24:10 --> Database Driver Class Initialized
INFO - 2018-04-20 01:24:10 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:24:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:24:10 --> Final output sent to browser
DEBUG - 2018-04-20 01:24:10 --> Total execution time: 0.4132
INFO - 2018-04-20 01:24:11 --> Config Class Initialized
INFO - 2018-04-20 01:24:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:11 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:11 --> URI Class Initialized
INFO - 2018-04-20 01:24:11 --> Router Class Initialized
INFO - 2018-04-20 01:24:11 --> Output Class Initialized
INFO - 2018-04-20 01:24:11 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:11 --> CSRF cookie sent
INFO - 2018-04-20 01:24:11 --> Input Class Initialized
INFO - 2018-04-20 01:24:11 --> Language Class Initialized
ERROR - 2018-04-20 01:24:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:24:12 --> Config Class Initialized
INFO - 2018-04-20 01:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:12 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:12 --> URI Class Initialized
INFO - 2018-04-20 01:24:12 --> Router Class Initialized
INFO - 2018-04-20 01:24:12 --> Output Class Initialized
INFO - 2018-04-20 01:24:12 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:12 --> CSRF cookie sent
INFO - 2018-04-20 01:24:12 --> Input Class Initialized
INFO - 2018-04-20 01:24:12 --> Language Class Initialized
INFO - 2018-04-20 01:24:12 --> Loader Class Initialized
INFO - 2018-04-20 01:24:12 --> Helper loaded: url_helper
INFO - 2018-04-20 01:24:12 --> Helper loaded: form_helper
INFO - 2018-04-20 01:24:12 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:24:12 --> User Agent Class Initialized
INFO - 2018-04-20 01:24:12 --> Controller Class Initialized
INFO - 2018-04-20 01:24:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:24:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:24:12 --> Pixel_Model class loaded
INFO - 2018-04-20 01:24:12 --> Database Driver Class Initialized
INFO - 2018-04-20 01:24:12 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:24:12 --> Config Class Initialized
INFO - 2018-04-20 01:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:12 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:12 --> URI Class Initialized
INFO - 2018-04-20 01:24:12 --> Router Class Initialized
INFO - 2018-04-20 01:24:12 --> Output Class Initialized
INFO - 2018-04-20 01:24:12 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:12 --> CSRF cookie sent
INFO - 2018-04-20 01:24:12 --> Input Class Initialized
INFO - 2018-04-20 01:24:12 --> Language Class Initialized
INFO - 2018-04-20 01:24:12 --> Loader Class Initialized
INFO - 2018-04-20 01:24:12 --> Helper loaded: url_helper
INFO - 2018-04-20 01:24:12 --> Helper loaded: form_helper
INFO - 2018-04-20 01:24:12 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:24:12 --> User Agent Class Initialized
INFO - 2018-04-20 01:24:12 --> Controller Class Initialized
INFO - 2018-04-20 01:24:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:24:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:24:12 --> Pixel_Model class loaded
INFO - 2018-04-20 01:24:12 --> Database Driver Class Initialized
INFO - 2018-04-20 01:24:12 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:24:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:24:12 --> Final output sent to browser
DEBUG - 2018-04-20 01:24:13 --> Total execution time: 0.4258
INFO - 2018-04-20 01:24:13 --> Config Class Initialized
INFO - 2018-04-20 01:24:13 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:24:13 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:24:13 --> Utf8 Class Initialized
INFO - 2018-04-20 01:24:13 --> URI Class Initialized
INFO - 2018-04-20 01:24:13 --> Router Class Initialized
INFO - 2018-04-20 01:24:13 --> Output Class Initialized
INFO - 2018-04-20 01:24:13 --> Security Class Initialized
DEBUG - 2018-04-20 01:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:24:13 --> CSRF cookie sent
INFO - 2018-04-20 01:24:13 --> Input Class Initialized
INFO - 2018-04-20 01:24:13 --> Language Class Initialized
ERROR - 2018-04-20 01:24:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:25:26 --> Config Class Initialized
INFO - 2018-04-20 01:25:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:26 --> URI Class Initialized
INFO - 2018-04-20 01:25:26 --> Router Class Initialized
INFO - 2018-04-20 01:25:26 --> Output Class Initialized
INFO - 2018-04-20 01:25:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:26 --> CSRF cookie sent
INFO - 2018-04-20 01:25:26 --> Input Class Initialized
INFO - 2018-04-20 01:25:26 --> Language Class Initialized
INFO - 2018-04-20 01:25:26 --> Loader Class Initialized
INFO - 2018-04-20 01:25:26 --> Helper loaded: url_helper
INFO - 2018-04-20 01:25:26 --> Helper loaded: form_helper
INFO - 2018-04-20 01:25:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:25:26 --> User Agent Class Initialized
INFO - 2018-04-20 01:25:26 --> Controller Class Initialized
INFO - 2018-04-20 01:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:25:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:25:26 --> Pixel_Model class loaded
INFO - 2018-04-20 01:25:26 --> Database Driver Class Initialized
INFO - 2018-04-20 01:25:26 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:25:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:25:26 --> Final output sent to browser
DEBUG - 2018-04-20 01:25:26 --> Total execution time: 0.4069
INFO - 2018-04-20 01:25:27 --> Config Class Initialized
INFO - 2018-04-20 01:25:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:27 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:27 --> URI Class Initialized
INFO - 2018-04-20 01:25:27 --> Router Class Initialized
INFO - 2018-04-20 01:25:27 --> Output Class Initialized
INFO - 2018-04-20 01:25:27 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:27 --> CSRF cookie sent
INFO - 2018-04-20 01:25:27 --> Input Class Initialized
INFO - 2018-04-20 01:25:27 --> Language Class Initialized
ERROR - 2018-04-20 01:25:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:25:29 --> Config Class Initialized
INFO - 2018-04-20 01:25:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:29 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:29 --> URI Class Initialized
INFO - 2018-04-20 01:25:29 --> Router Class Initialized
INFO - 2018-04-20 01:25:29 --> Output Class Initialized
INFO - 2018-04-20 01:25:29 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:29 --> CSRF cookie sent
INFO - 2018-04-20 01:25:29 --> Input Class Initialized
INFO - 2018-04-20 01:25:29 --> Language Class Initialized
INFO - 2018-04-20 01:25:29 --> Loader Class Initialized
INFO - 2018-04-20 01:25:29 --> Helper loaded: url_helper
INFO - 2018-04-20 01:25:29 --> Helper loaded: form_helper
INFO - 2018-04-20 01:25:29 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:25:29 --> User Agent Class Initialized
INFO - 2018-04-20 01:25:29 --> Controller Class Initialized
INFO - 2018-04-20 01:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:25:29 --> Pixel_Model class loaded
INFO - 2018-04-20 01:25:29 --> Database Driver Class Initialized
INFO - 2018-04-20 01:25:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:25:31 --> Config Class Initialized
INFO - 2018-04-20 01:25:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:32 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:32 --> URI Class Initialized
INFO - 2018-04-20 01:25:32 --> Router Class Initialized
INFO - 2018-04-20 01:25:32 --> Output Class Initialized
INFO - 2018-04-20 01:25:32 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:32 --> CSRF cookie sent
INFO - 2018-04-20 01:25:32 --> Input Class Initialized
INFO - 2018-04-20 01:25:32 --> Language Class Initialized
INFO - 2018-04-20 01:25:32 --> Loader Class Initialized
INFO - 2018-04-20 01:25:32 --> Helper loaded: url_helper
INFO - 2018-04-20 01:25:32 --> Helper loaded: form_helper
INFO - 2018-04-20 01:25:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:25:32 --> User Agent Class Initialized
INFO - 2018-04-20 01:25:32 --> Controller Class Initialized
INFO - 2018-04-20 01:25:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:25:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:25:32 --> Pixel_Model class loaded
INFO - 2018-04-20 01:25:32 --> Database Driver Class Initialized
INFO - 2018-04-20 01:25:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:25:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:25:32 --> Final output sent to browser
DEBUG - 2018-04-20 01:25:32 --> Total execution time: 0.4234
INFO - 2018-04-20 01:25:32 --> Config Class Initialized
INFO - 2018-04-20 01:25:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:32 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:32 --> URI Class Initialized
INFO - 2018-04-20 01:25:32 --> Router Class Initialized
INFO - 2018-04-20 01:25:32 --> Output Class Initialized
INFO - 2018-04-20 01:25:32 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:32 --> CSRF cookie sent
INFO - 2018-04-20 01:25:32 --> Input Class Initialized
INFO - 2018-04-20 01:25:32 --> Language Class Initialized
ERROR - 2018-04-20 01:25:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:25:33 --> Config Class Initialized
INFO - 2018-04-20 01:25:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:25:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:25:34 --> Utf8 Class Initialized
INFO - 2018-04-20 01:25:34 --> URI Class Initialized
INFO - 2018-04-20 01:25:34 --> Router Class Initialized
INFO - 2018-04-20 01:25:34 --> Output Class Initialized
INFO - 2018-04-20 01:25:34 --> Security Class Initialized
DEBUG - 2018-04-20 01:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:25:34 --> CSRF cookie sent
INFO - 2018-04-20 01:25:34 --> Input Class Initialized
INFO - 2018-04-20 01:25:34 --> Language Class Initialized
INFO - 2018-04-20 01:25:34 --> Loader Class Initialized
INFO - 2018-04-20 01:25:34 --> Helper loaded: url_helper
INFO - 2018-04-20 01:25:34 --> Helper loaded: form_helper
INFO - 2018-04-20 01:25:34 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:25:34 --> User Agent Class Initialized
INFO - 2018-04-20 01:25:34 --> Controller Class Initialized
INFO - 2018-04-20 01:25:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:25:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:25:34 --> Pixel_Model class loaded
INFO - 2018-04-20 01:25:34 --> Database Driver Class Initialized
INFO - 2018-04-20 01:25:34 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:26:19 --> Config Class Initialized
INFO - 2018-04-20 01:26:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:19 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:19 --> URI Class Initialized
INFO - 2018-04-20 01:26:19 --> Router Class Initialized
INFO - 2018-04-20 01:26:19 --> Output Class Initialized
INFO - 2018-04-20 01:26:19 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:19 --> CSRF cookie sent
INFO - 2018-04-20 01:26:19 --> Input Class Initialized
INFO - 2018-04-20 01:26:19 --> Language Class Initialized
INFO - 2018-04-20 01:26:19 --> Loader Class Initialized
INFO - 2018-04-20 01:26:19 --> Helper loaded: url_helper
INFO - 2018-04-20 01:26:19 --> Helper loaded: form_helper
INFO - 2018-04-20 01:26:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:26:19 --> User Agent Class Initialized
INFO - 2018-04-20 01:26:19 --> Controller Class Initialized
INFO - 2018-04-20 01:26:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:26:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:26:19 --> Pixel_Model class loaded
INFO - 2018-04-20 01:26:19 --> Database Driver Class Initialized
INFO - 2018-04-20 01:26:19 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:26:19 --> Config Class Initialized
INFO - 2018-04-20 01:26:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:19 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:19 --> URI Class Initialized
INFO - 2018-04-20 01:26:19 --> Router Class Initialized
INFO - 2018-04-20 01:26:19 --> Output Class Initialized
INFO - 2018-04-20 01:26:19 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:19 --> CSRF cookie sent
INFO - 2018-04-20 01:26:19 --> Input Class Initialized
INFO - 2018-04-20 01:26:19 --> Language Class Initialized
INFO - 2018-04-20 01:26:19 --> Loader Class Initialized
INFO - 2018-04-20 01:26:19 --> Helper loaded: url_helper
INFO - 2018-04-20 01:26:19 --> Helper loaded: form_helper
INFO - 2018-04-20 01:26:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:26:19 --> User Agent Class Initialized
INFO - 2018-04-20 01:26:19 --> Controller Class Initialized
INFO - 2018-04-20 01:26:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:26:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:26:19 --> Pixel_Model class loaded
INFO - 2018-04-20 01:26:19 --> Database Driver Class Initialized
INFO - 2018-04-20 01:26:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:26:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:26:19 --> Final output sent to browser
DEBUG - 2018-04-20 01:26:20 --> Total execution time: 0.4076
INFO - 2018-04-20 01:26:20 --> Config Class Initialized
INFO - 2018-04-20 01:26:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:20 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:20 --> URI Class Initialized
INFO - 2018-04-20 01:26:20 --> Router Class Initialized
INFO - 2018-04-20 01:26:20 --> Output Class Initialized
INFO - 2018-04-20 01:26:20 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:20 --> CSRF cookie sent
INFO - 2018-04-20 01:26:20 --> Input Class Initialized
INFO - 2018-04-20 01:26:20 --> Language Class Initialized
ERROR - 2018-04-20 01:26:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:26:23 --> Config Class Initialized
INFO - 2018-04-20 01:26:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:23 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:23 --> URI Class Initialized
INFO - 2018-04-20 01:26:23 --> Router Class Initialized
INFO - 2018-04-20 01:26:23 --> Output Class Initialized
INFO - 2018-04-20 01:26:23 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:23 --> CSRF cookie sent
INFO - 2018-04-20 01:26:23 --> CSRF token verified
INFO - 2018-04-20 01:26:23 --> Input Class Initialized
INFO - 2018-04-20 01:26:23 --> Language Class Initialized
INFO - 2018-04-20 01:26:23 --> Loader Class Initialized
INFO - 2018-04-20 01:26:23 --> Helper loaded: url_helper
INFO - 2018-04-20 01:26:23 --> Helper loaded: form_helper
INFO - 2018-04-20 01:26:23 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:26:23 --> User Agent Class Initialized
INFO - 2018-04-20 01:26:23 --> Controller Class Initialized
INFO - 2018-04-20 01:26:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:26:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:26:23 --> Pixel_Model class loaded
INFO - 2018-04-20 01:26:23 --> Database Driver Class Initialized
INFO - 2018-04-20 01:26:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:26:23 --> Form Validation Class Initialized
INFO - 2018-04-20 01:26:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:26:26 --> Config Class Initialized
INFO - 2018-04-20 01:26:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:26 --> URI Class Initialized
INFO - 2018-04-20 01:26:26 --> Router Class Initialized
INFO - 2018-04-20 01:26:26 --> Output Class Initialized
INFO - 2018-04-20 01:26:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:26 --> CSRF cookie sent
INFO - 2018-04-20 01:26:26 --> Input Class Initialized
INFO - 2018-04-20 01:26:26 --> Language Class Initialized
INFO - 2018-04-20 01:26:26 --> Loader Class Initialized
INFO - 2018-04-20 01:26:26 --> Helper loaded: url_helper
INFO - 2018-04-20 01:26:26 --> Helper loaded: form_helper
INFO - 2018-04-20 01:26:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:26:26 --> User Agent Class Initialized
INFO - 2018-04-20 01:26:26 --> Controller Class Initialized
INFO - 2018-04-20 01:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:26:26 --> Pixel_Model class loaded
INFO - 2018-04-20 01:26:26 --> Database Driver Class Initialized
INFO - 2018-04-20 01:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:26:26 --> Final output sent to browser
DEBUG - 2018-04-20 01:26:27 --> Total execution time: 0.4508
INFO - 2018-04-20 01:26:27 --> Config Class Initialized
INFO - 2018-04-20 01:26:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:26:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:26:27 --> Utf8 Class Initialized
INFO - 2018-04-20 01:26:27 --> URI Class Initialized
INFO - 2018-04-20 01:26:27 --> Router Class Initialized
INFO - 2018-04-20 01:26:27 --> Output Class Initialized
INFO - 2018-04-20 01:26:27 --> Security Class Initialized
DEBUG - 2018-04-20 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:26:27 --> CSRF cookie sent
INFO - 2018-04-20 01:26:27 --> Input Class Initialized
INFO - 2018-04-20 01:26:27 --> Language Class Initialized
ERROR - 2018-04-20 01:26:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:02 --> Config Class Initialized
INFO - 2018-04-20 01:27:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:02 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:02 --> URI Class Initialized
INFO - 2018-04-20 01:27:02 --> Router Class Initialized
INFO - 2018-04-20 01:27:02 --> Output Class Initialized
INFO - 2018-04-20 01:27:02 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:02 --> CSRF cookie sent
INFO - 2018-04-20 01:27:02 --> CSRF token verified
INFO - 2018-04-20 01:27:02 --> Input Class Initialized
INFO - 2018-04-20 01:27:02 --> Language Class Initialized
INFO - 2018-04-20 01:27:02 --> Loader Class Initialized
INFO - 2018-04-20 01:27:02 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:03 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:03 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:03 --> Controller Class Initialized
INFO - 2018-04-20 01:27:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:03 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:03 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:27:03 --> Form Validation Class Initialized
INFO - 2018-04-20 01:27:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 01:27:03 --> Config Class Initialized
INFO - 2018-04-20 01:27:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:03 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:03 --> URI Class Initialized
INFO - 2018-04-20 01:27:03 --> Router Class Initialized
INFO - 2018-04-20 01:27:03 --> Output Class Initialized
INFO - 2018-04-20 01:27:03 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:03 --> CSRF cookie sent
INFO - 2018-04-20 01:27:03 --> Input Class Initialized
INFO - 2018-04-20 01:27:03 --> Language Class Initialized
INFO - 2018-04-20 01:27:03 --> Loader Class Initialized
INFO - 2018-04-20 01:27:03 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:03 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:03 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:03 --> Controller Class Initialized
INFO - 2018-04-20 01:27:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:03 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:03 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:03 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:03 --> Total execution time: 0.4271
INFO - 2018-04-20 01:27:04 --> Config Class Initialized
INFO - 2018-04-20 01:27:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:04 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:04 --> URI Class Initialized
INFO - 2018-04-20 01:27:04 --> Router Class Initialized
INFO - 2018-04-20 01:27:04 --> Output Class Initialized
INFO - 2018-04-20 01:27:04 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:04 --> CSRF cookie sent
INFO - 2018-04-20 01:27:04 --> Input Class Initialized
INFO - 2018-04-20 01:27:04 --> Language Class Initialized
ERROR - 2018-04-20 01:27:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:25 --> Config Class Initialized
INFO - 2018-04-20 01:27:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:25 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:25 --> URI Class Initialized
INFO - 2018-04-20 01:27:25 --> Router Class Initialized
INFO - 2018-04-20 01:27:25 --> Output Class Initialized
INFO - 2018-04-20 01:27:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:26 --> CSRF cookie sent
INFO - 2018-04-20 01:27:26 --> Input Class Initialized
INFO - 2018-04-20 01:27:26 --> Language Class Initialized
INFO - 2018-04-20 01:27:26 --> Loader Class Initialized
INFO - 2018-04-20 01:27:26 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:26 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:26 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:26 --> Controller Class Initialized
INFO - 2018-04-20 01:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:26 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:26 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:26 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:26 --> Total execution time: 0.4442
INFO - 2018-04-20 01:27:26 --> Config Class Initialized
INFO - 2018-04-20 01:27:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:26 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:26 --> URI Class Initialized
INFO - 2018-04-20 01:27:26 --> Router Class Initialized
INFO - 2018-04-20 01:27:26 --> Output Class Initialized
INFO - 2018-04-20 01:27:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:26 --> CSRF cookie sent
INFO - 2018-04-20 01:27:26 --> Input Class Initialized
INFO - 2018-04-20 01:27:26 --> Language Class Initialized
ERROR - 2018-04-20 01:27:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:28 --> Config Class Initialized
INFO - 2018-04-20 01:27:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:28 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:28 --> URI Class Initialized
INFO - 2018-04-20 01:27:28 --> Router Class Initialized
INFO - 2018-04-20 01:27:28 --> Output Class Initialized
INFO - 2018-04-20 01:27:28 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:28 --> CSRF cookie sent
INFO - 2018-04-20 01:27:28 --> Input Class Initialized
INFO - 2018-04-20 01:27:28 --> Language Class Initialized
INFO - 2018-04-20 01:27:28 --> Loader Class Initialized
INFO - 2018-04-20 01:27:28 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:28 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:28 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:28 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:28 --> Controller Class Initialized
INFO - 2018-04-20 01:27:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:28 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:28 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:27:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:28 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:28 --> Total execution time: 0.4569
INFO - 2018-04-20 01:27:29 --> Config Class Initialized
INFO - 2018-04-20 01:27:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:29 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:29 --> URI Class Initialized
INFO - 2018-04-20 01:27:29 --> Router Class Initialized
INFO - 2018-04-20 01:27:29 --> Output Class Initialized
INFO - 2018-04-20 01:27:29 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:29 --> CSRF cookie sent
INFO - 2018-04-20 01:27:29 --> Input Class Initialized
INFO - 2018-04-20 01:27:29 --> Language Class Initialized
ERROR - 2018-04-20 01:27:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:51 --> Config Class Initialized
INFO - 2018-04-20 01:27:51 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:51 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:51 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:51 --> URI Class Initialized
INFO - 2018-04-20 01:27:51 --> Router Class Initialized
INFO - 2018-04-20 01:27:51 --> Output Class Initialized
INFO - 2018-04-20 01:27:51 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:51 --> CSRF cookie sent
INFO - 2018-04-20 01:27:51 --> Input Class Initialized
INFO - 2018-04-20 01:27:51 --> Language Class Initialized
INFO - 2018-04-20 01:27:51 --> Loader Class Initialized
INFO - 2018-04-20 01:27:51 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:51 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:51 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:51 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:51 --> Controller Class Initialized
INFO - 2018-04-20 01:27:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:51 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:51 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:51 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:51 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:27:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:52 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:52 --> Total execution time: 0.4405
INFO - 2018-04-20 01:27:52 --> Config Class Initialized
INFO - 2018-04-20 01:27:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:52 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:52 --> URI Class Initialized
INFO - 2018-04-20 01:27:52 --> Router Class Initialized
INFO - 2018-04-20 01:27:52 --> Output Class Initialized
INFO - 2018-04-20 01:27:52 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:52 --> CSRF cookie sent
INFO - 2018-04-20 01:27:52 --> Input Class Initialized
INFO - 2018-04-20 01:27:52 --> Language Class Initialized
ERROR - 2018-04-20 01:27:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:54 --> Config Class Initialized
INFO - 2018-04-20 01:27:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:54 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:54 --> URI Class Initialized
INFO - 2018-04-20 01:27:54 --> Router Class Initialized
INFO - 2018-04-20 01:27:54 --> Output Class Initialized
INFO - 2018-04-20 01:27:54 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:54 --> CSRF cookie sent
INFO - 2018-04-20 01:27:54 --> Input Class Initialized
INFO - 2018-04-20 01:27:54 --> Language Class Initialized
INFO - 2018-04-20 01:27:54 --> Loader Class Initialized
INFO - 2018-04-20 01:27:54 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:54 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:55 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:55 --> Controller Class Initialized
INFO - 2018-04-20 01:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:55 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:55 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:27:55 --> Config Class Initialized
INFO - 2018-04-20 01:27:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:55 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:55 --> URI Class Initialized
INFO - 2018-04-20 01:27:55 --> Router Class Initialized
INFO - 2018-04-20 01:27:55 --> Output Class Initialized
INFO - 2018-04-20 01:27:55 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:55 --> CSRF cookie sent
INFO - 2018-04-20 01:27:55 --> Input Class Initialized
INFO - 2018-04-20 01:27:55 --> Language Class Initialized
INFO - 2018-04-20 01:27:55 --> Loader Class Initialized
INFO - 2018-04-20 01:27:55 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:55 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:55 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:55 --> Controller Class Initialized
INFO - 2018-04-20 01:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:55 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:55 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:55 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:55 --> Total execution time: 0.4312
INFO - 2018-04-20 01:27:55 --> Config Class Initialized
INFO - 2018-04-20 01:27:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:56 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:56 --> URI Class Initialized
INFO - 2018-04-20 01:27:56 --> Router Class Initialized
INFO - 2018-04-20 01:27:56 --> Output Class Initialized
INFO - 2018-04-20 01:27:56 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:56 --> CSRF cookie sent
INFO - 2018-04-20 01:27:56 --> Input Class Initialized
INFO - 2018-04-20 01:27:56 --> Language Class Initialized
ERROR - 2018-04-20 01:27:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:27:58 --> Config Class Initialized
INFO - 2018-04-20 01:27:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:58 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:58 --> URI Class Initialized
INFO - 2018-04-20 01:27:58 --> Router Class Initialized
INFO - 2018-04-20 01:27:58 --> Output Class Initialized
INFO - 2018-04-20 01:27:58 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:58 --> CSRF cookie sent
INFO - 2018-04-20 01:27:58 --> Input Class Initialized
INFO - 2018-04-20 01:27:58 --> Language Class Initialized
INFO - 2018-04-20 01:27:58 --> Loader Class Initialized
INFO - 2018-04-20 01:27:58 --> Helper loaded: url_helper
INFO - 2018-04-20 01:27:58 --> Helper loaded: form_helper
INFO - 2018-04-20 01:27:58 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:27:58 --> User Agent Class Initialized
INFO - 2018-04-20 01:27:58 --> Controller Class Initialized
INFO - 2018-04-20 01:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:27:58 --> Pixel_Model class loaded
INFO - 2018-04-20 01:27:58 --> Database Driver Class Initialized
INFO - 2018-04-20 01:27:58 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:27:58 --> Final output sent to browser
DEBUG - 2018-04-20 01:27:58 --> Total execution time: 0.4651
INFO - 2018-04-20 01:27:59 --> Config Class Initialized
INFO - 2018-04-20 01:27:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:27:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:27:59 --> Utf8 Class Initialized
INFO - 2018-04-20 01:27:59 --> URI Class Initialized
INFO - 2018-04-20 01:27:59 --> Router Class Initialized
INFO - 2018-04-20 01:27:59 --> Output Class Initialized
INFO - 2018-04-20 01:27:59 --> Security Class Initialized
DEBUG - 2018-04-20 01:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:27:59 --> CSRF cookie sent
INFO - 2018-04-20 01:27:59 --> Input Class Initialized
INFO - 2018-04-20 01:27:59 --> Language Class Initialized
ERROR - 2018-04-20 01:27:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:28:00 --> Config Class Initialized
INFO - 2018-04-20 01:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:00 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:00 --> URI Class Initialized
INFO - 2018-04-20 01:28:00 --> Router Class Initialized
INFO - 2018-04-20 01:28:00 --> Output Class Initialized
INFO - 2018-04-20 01:28:00 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:00 --> CSRF cookie sent
INFO - 2018-04-20 01:28:00 --> Input Class Initialized
INFO - 2018-04-20 01:28:00 --> Language Class Initialized
INFO - 2018-04-20 01:28:00 --> Loader Class Initialized
INFO - 2018-04-20 01:28:00 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:00 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:00 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:00 --> Controller Class Initialized
INFO - 2018-04-20 01:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:00 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:00 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:28:00 --> Config Class Initialized
INFO - 2018-04-20 01:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:00 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:00 --> URI Class Initialized
INFO - 2018-04-20 01:28:00 --> Router Class Initialized
INFO - 2018-04-20 01:28:01 --> Output Class Initialized
INFO - 2018-04-20 01:28:01 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:01 --> CSRF cookie sent
INFO - 2018-04-20 01:28:01 --> Input Class Initialized
INFO - 2018-04-20 01:28:01 --> Language Class Initialized
INFO - 2018-04-20 01:28:01 --> Loader Class Initialized
INFO - 2018-04-20 01:28:01 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:01 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:01 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:01 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:01 --> Controller Class Initialized
INFO - 2018-04-20 01:28:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:01 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:01 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 01:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:28:01 --> Final output sent to browser
DEBUG - 2018-04-20 01:28:01 --> Total execution time: 0.4441
INFO - 2018-04-20 01:28:01 --> Config Class Initialized
INFO - 2018-04-20 01:28:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:01 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:01 --> URI Class Initialized
INFO - 2018-04-20 01:28:01 --> Router Class Initialized
INFO - 2018-04-20 01:28:01 --> Output Class Initialized
INFO - 2018-04-20 01:28:01 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:01 --> CSRF cookie sent
INFO - 2018-04-20 01:28:01 --> Input Class Initialized
INFO - 2018-04-20 01:28:01 --> Language Class Initialized
ERROR - 2018-04-20 01:28:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:28:06 --> Config Class Initialized
INFO - 2018-04-20 01:28:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:06 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:06 --> URI Class Initialized
INFO - 2018-04-20 01:28:06 --> Router Class Initialized
INFO - 2018-04-20 01:28:06 --> Output Class Initialized
INFO - 2018-04-20 01:28:06 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:06 --> CSRF cookie sent
INFO - 2018-04-20 01:28:06 --> Input Class Initialized
INFO - 2018-04-20 01:28:06 --> Language Class Initialized
INFO - 2018-04-20 01:28:06 --> Loader Class Initialized
INFO - 2018-04-20 01:28:07 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:07 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:07 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:07 --> Controller Class Initialized
INFO - 2018-04-20 01:28:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:07 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:07 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:07 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 01:28:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:28:07 --> Final output sent to browser
DEBUG - 2018-04-20 01:28:07 --> Total execution time: 0.4302
INFO - 2018-04-20 01:28:07 --> Config Class Initialized
INFO - 2018-04-20 01:28:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:07 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:07 --> URI Class Initialized
INFO - 2018-04-20 01:28:07 --> Router Class Initialized
INFO - 2018-04-20 01:28:07 --> Output Class Initialized
INFO - 2018-04-20 01:28:07 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:07 --> CSRF cookie sent
INFO - 2018-04-20 01:28:07 --> Input Class Initialized
INFO - 2018-04-20 01:28:07 --> Language Class Initialized
ERROR - 2018-04-20 01:28:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:28:14 --> Config Class Initialized
INFO - 2018-04-20 01:28:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:14 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:14 --> URI Class Initialized
INFO - 2018-04-20 01:28:14 --> Router Class Initialized
INFO - 2018-04-20 01:28:14 --> Output Class Initialized
INFO - 2018-04-20 01:28:14 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:14 --> CSRF cookie sent
INFO - 2018-04-20 01:28:14 --> Input Class Initialized
INFO - 2018-04-20 01:28:14 --> Language Class Initialized
INFO - 2018-04-20 01:28:14 --> Loader Class Initialized
INFO - 2018-04-20 01:28:14 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:14 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:14 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:14 --> Controller Class Initialized
INFO - 2018-04-20 01:28:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:14 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:14 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:14 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:28:14 --> Final output sent to browser
DEBUG - 2018-04-20 01:28:14 --> Total execution time: 0.4427
INFO - 2018-04-20 01:28:14 --> Config Class Initialized
INFO - 2018-04-20 01:28:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:14 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:14 --> URI Class Initialized
INFO - 2018-04-20 01:28:15 --> Router Class Initialized
INFO - 2018-04-20 01:28:15 --> Output Class Initialized
INFO - 2018-04-20 01:28:15 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:15 --> CSRF cookie sent
INFO - 2018-04-20 01:28:15 --> Input Class Initialized
INFO - 2018-04-20 01:28:15 --> Language Class Initialized
ERROR - 2018-04-20 01:28:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:28:24 --> Config Class Initialized
INFO - 2018-04-20 01:28:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:25 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:25 --> URI Class Initialized
INFO - 2018-04-20 01:28:25 --> Router Class Initialized
INFO - 2018-04-20 01:28:25 --> Output Class Initialized
INFO - 2018-04-20 01:28:25 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:25 --> CSRF cookie sent
INFO - 2018-04-20 01:28:25 --> Input Class Initialized
INFO - 2018-04-20 01:28:25 --> Language Class Initialized
INFO - 2018-04-20 01:28:25 --> Loader Class Initialized
INFO - 2018-04-20 01:28:25 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:25 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:25 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:25 --> Controller Class Initialized
INFO - 2018-04-20 01:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:25 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:25 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:25 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-20 01:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:28:25 --> Final output sent to browser
DEBUG - 2018-04-20 01:28:25 --> Total execution time: 0.4801
INFO - 2018-04-20 01:28:25 --> Config Class Initialized
INFO - 2018-04-20 01:28:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:25 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:25 --> URI Class Initialized
INFO - 2018-04-20 01:28:25 --> Router Class Initialized
INFO - 2018-04-20 01:28:25 --> Output Class Initialized
INFO - 2018-04-20 01:28:26 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:26 --> CSRF cookie sent
INFO - 2018-04-20 01:28:26 --> Input Class Initialized
INFO - 2018-04-20 01:28:26 --> Language Class Initialized
ERROR - 2018-04-20 01:28:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 01:28:31 --> Config Class Initialized
INFO - 2018-04-20 01:28:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:31 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:31 --> URI Class Initialized
INFO - 2018-04-20 01:28:31 --> Router Class Initialized
INFO - 2018-04-20 01:28:31 --> Output Class Initialized
INFO - 2018-04-20 01:28:31 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:32 --> CSRF cookie sent
INFO - 2018-04-20 01:28:32 --> Input Class Initialized
INFO - 2018-04-20 01:28:32 --> Language Class Initialized
INFO - 2018-04-20 01:28:32 --> Loader Class Initialized
INFO - 2018-04-20 01:28:32 --> Helper loaded: url_helper
INFO - 2018-04-20 01:28:32 --> Helper loaded: form_helper
INFO - 2018-04-20 01:28:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 01:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 01:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 01:28:32 --> User Agent Class Initialized
INFO - 2018-04-20 01:28:32 --> Controller Class Initialized
INFO - 2018-04-20 01:28:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 01:28:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 01:28:32 --> Pixel_Model class loaded
INFO - 2018-04-20 01:28:32 --> Database Driver Class Initialized
INFO - 2018-04-20 01:28:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 01:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 01:28:32 --> Final output sent to browser
DEBUG - 2018-04-20 01:28:32 --> Total execution time: 0.4547
INFO - 2018-04-20 01:28:32 --> Config Class Initialized
INFO - 2018-04-20 01:28:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 01:28:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 01:28:32 --> Utf8 Class Initialized
INFO - 2018-04-20 01:28:32 --> URI Class Initialized
INFO - 2018-04-20 01:28:32 --> Router Class Initialized
INFO - 2018-04-20 01:28:32 --> Output Class Initialized
INFO - 2018-04-20 01:28:32 --> Security Class Initialized
DEBUG - 2018-04-20 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 01:28:32 --> CSRF cookie sent
INFO - 2018-04-20 01:28:32 --> Input Class Initialized
INFO - 2018-04-20 01:28:32 --> Language Class Initialized
ERROR - 2018-04-20 01:28:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:35:24 --> Config Class Initialized
INFO - 2018-04-20 21:35:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:35:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:35:24 --> Utf8 Class Initialized
INFO - 2018-04-20 21:35:24 --> URI Class Initialized
DEBUG - 2018-04-20 21:35:24 --> No URI present. Default controller set.
INFO - 2018-04-20 21:35:24 --> Router Class Initialized
INFO - 2018-04-20 21:35:24 --> Output Class Initialized
INFO - 2018-04-20 21:35:24 --> Security Class Initialized
DEBUG - 2018-04-20 21:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:35:24 --> CSRF cookie sent
INFO - 2018-04-20 21:35:24 --> Input Class Initialized
INFO - 2018-04-20 21:35:24 --> Language Class Initialized
INFO - 2018-04-20 21:35:25 --> Loader Class Initialized
INFO - 2018-04-20 21:35:25 --> Helper loaded: url_helper
INFO - 2018-04-20 21:35:25 --> Helper loaded: form_helper
INFO - 2018-04-20 21:35:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:35:25 --> User Agent Class Initialized
INFO - 2018-04-20 21:35:25 --> Controller Class Initialized
INFO - 2018-04-20 21:35:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:35:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:35:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:35:25 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 21:35:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:35:26 --> Final output sent to browser
DEBUG - 2018-04-20 21:35:26 --> Total execution time: 2.1200
INFO - 2018-04-20 21:35:28 --> Config Class Initialized
INFO - 2018-04-20 21:35:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:35:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:35:28 --> Utf8 Class Initialized
INFO - 2018-04-20 21:35:28 --> URI Class Initialized
INFO - 2018-04-20 21:35:28 --> Router Class Initialized
INFO - 2018-04-20 21:35:28 --> Output Class Initialized
INFO - 2018-04-20 21:35:28 --> Security Class Initialized
DEBUG - 2018-04-20 21:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:35:28 --> CSRF cookie sent
INFO - 2018-04-20 21:35:28 --> Input Class Initialized
INFO - 2018-04-20 21:35:28 --> Language Class Initialized
ERROR - 2018-04-20 21:35:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 21:35:53 --> Config Class Initialized
INFO - 2018-04-20 21:35:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:35:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:35:53 --> Utf8 Class Initialized
INFO - 2018-04-20 21:35:53 --> URI Class Initialized
INFO - 2018-04-20 21:35:53 --> Router Class Initialized
INFO - 2018-04-20 21:35:53 --> Output Class Initialized
INFO - 2018-04-20 21:35:53 --> Security Class Initialized
DEBUG - 2018-04-20 21:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:35:53 --> CSRF cookie sent
INFO - 2018-04-20 21:35:53 --> Input Class Initialized
INFO - 2018-04-20 21:35:53 --> Language Class Initialized
INFO - 2018-04-20 21:35:54 --> Loader Class Initialized
INFO - 2018-04-20 21:35:54 --> Helper loaded: url_helper
INFO - 2018-04-20 21:35:54 --> Helper loaded: form_helper
INFO - 2018-04-20 21:35:54 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:35:54 --> User Agent Class Initialized
INFO - 2018-04-20 21:35:54 --> Controller Class Initialized
INFO - 2018-04-20 21:35:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:35:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 21:35:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 21:35:54 --> Could not find the language line "req_email"
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:35:54 --> Final output sent to browser
DEBUG - 2018-04-20 21:35:54 --> Total execution time: 0.5361
INFO - 2018-04-20 21:35:54 --> Config Class Initialized
INFO - 2018-04-20 21:35:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:35:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:35:54 --> Utf8 Class Initialized
INFO - 2018-04-20 21:35:54 --> URI Class Initialized
INFO - 2018-04-20 21:35:54 --> Router Class Initialized
INFO - 2018-04-20 21:35:54 --> Output Class Initialized
INFO - 2018-04-20 21:35:54 --> Security Class Initialized
DEBUG - 2018-04-20 21:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:35:54 --> CSRF cookie sent
INFO - 2018-04-20 21:35:54 --> Input Class Initialized
INFO - 2018-04-20 21:35:54 --> Language Class Initialized
ERROR - 2018-04-20 21:35:54 --> 404 Page Not Found: Assets/images
INFO - 2018-04-20 21:36:03 --> Config Class Initialized
INFO - 2018-04-20 21:36:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:03 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:03 --> URI Class Initialized
INFO - 2018-04-20 21:36:03 --> Router Class Initialized
INFO - 2018-04-20 21:36:03 --> Output Class Initialized
INFO - 2018-04-20 21:36:03 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:03 --> CSRF cookie sent
INFO - 2018-04-20 21:36:03 --> CSRF token verified
INFO - 2018-04-20 21:36:03 --> Input Class Initialized
INFO - 2018-04-20 21:36:03 --> Language Class Initialized
INFO - 2018-04-20 21:36:03 --> Loader Class Initialized
INFO - 2018-04-20 21:36:03 --> Helper loaded: url_helper
INFO - 2018-04-20 21:36:03 --> Helper loaded: form_helper
INFO - 2018-04-20 21:36:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:36:03 --> User Agent Class Initialized
INFO - 2018-04-20 21:36:03 --> Controller Class Initialized
INFO - 2018-04-20 21:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:36:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 21:36:03 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 21:36:04 --> Form Validation Class Initialized
INFO - 2018-04-20 21:36:04 --> Pixel_Model class loaded
INFO - 2018-04-20 21:36:04 --> Database Driver Class Initialized
INFO - 2018-04-20 21:36:04 --> Model "AuthenticationModel" initialized
INFO - 2018-04-20 21:36:04 --> Config Class Initialized
INFO - 2018-04-20 21:36:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:04 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:04 --> URI Class Initialized
DEBUG - 2018-04-20 21:36:04 --> No URI present. Default controller set.
INFO - 2018-04-20 21:36:04 --> Router Class Initialized
INFO - 2018-04-20 21:36:04 --> Output Class Initialized
INFO - 2018-04-20 21:36:04 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:04 --> CSRF cookie sent
INFO - 2018-04-20 21:36:04 --> Input Class Initialized
INFO - 2018-04-20 21:36:04 --> Language Class Initialized
INFO - 2018-04-20 21:36:04 --> Loader Class Initialized
INFO - 2018-04-20 21:36:05 --> Helper loaded: url_helper
INFO - 2018-04-20 21:36:05 --> Helper loaded: form_helper
INFO - 2018-04-20 21:36:05 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:36:05 --> User Agent Class Initialized
INFO - 2018-04-20 21:36:05 --> Controller Class Initialized
INFO - 2018-04-20 21:36:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:36:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:36:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 21:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:36:05 --> Final output sent to browser
DEBUG - 2018-04-20 21:36:05 --> Total execution time: 0.4133
INFO - 2018-04-20 21:36:06 --> Config Class Initialized
INFO - 2018-04-20 21:36:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:06 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:06 --> URI Class Initialized
INFO - 2018-04-20 21:36:06 --> Router Class Initialized
INFO - 2018-04-20 21:36:06 --> Output Class Initialized
INFO - 2018-04-20 21:36:06 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:06 --> CSRF cookie sent
INFO - 2018-04-20 21:36:06 --> Input Class Initialized
INFO - 2018-04-20 21:36:06 --> Language Class Initialized
ERROR - 2018-04-20 21:36:06 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 21:36:33 --> Config Class Initialized
INFO - 2018-04-20 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:33 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:33 --> URI Class Initialized
DEBUG - 2018-04-20 21:36:33 --> No URI present. Default controller set.
INFO - 2018-04-20 21:36:33 --> Router Class Initialized
INFO - 2018-04-20 21:36:33 --> Output Class Initialized
INFO - 2018-04-20 21:36:33 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:33 --> CSRF cookie sent
INFO - 2018-04-20 21:36:33 --> Input Class Initialized
INFO - 2018-04-20 21:36:33 --> Language Class Initialized
INFO - 2018-04-20 21:36:33 --> Loader Class Initialized
INFO - 2018-04-20 21:36:33 --> Helper loaded: url_helper
INFO - 2018-04-20 21:36:33 --> Helper loaded: form_helper
INFO - 2018-04-20 21:36:33 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:36:33 --> User Agent Class Initialized
INFO - 2018-04-20 21:36:34 --> Controller Class Initialized
INFO - 2018-04-20 21:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:36:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:36:34 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:36:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:36:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 21:36:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:36:34 --> Final output sent to browser
DEBUG - 2018-04-20 21:36:34 --> Total execution time: 0.4506
INFO - 2018-04-20 21:36:35 --> Config Class Initialized
INFO - 2018-04-20 21:36:35 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:35 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:35 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:35 --> URI Class Initialized
INFO - 2018-04-20 21:36:35 --> Router Class Initialized
INFO - 2018-04-20 21:36:35 --> Output Class Initialized
INFO - 2018-04-20 21:36:35 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:35 --> CSRF cookie sent
INFO - 2018-04-20 21:36:35 --> Input Class Initialized
INFO - 2018-04-20 21:36:35 --> Language Class Initialized
ERROR - 2018-04-20 21:36:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 21:36:38 --> Config Class Initialized
INFO - 2018-04-20 21:36:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:36:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:36:38 --> Utf8 Class Initialized
INFO - 2018-04-20 21:36:38 --> URI Class Initialized
INFO - 2018-04-20 21:36:38 --> Router Class Initialized
INFO - 2018-04-20 21:36:38 --> Output Class Initialized
INFO - 2018-04-20 21:36:38 --> Security Class Initialized
DEBUG - 2018-04-20 21:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:36:38 --> CSRF cookie sent
INFO - 2018-04-20 21:36:38 --> Input Class Initialized
INFO - 2018-04-20 21:36:38 --> Language Class Initialized
INFO - 2018-04-20 21:36:38 --> Loader Class Initialized
INFO - 2018-04-20 21:36:38 --> Helper loaded: url_helper
INFO - 2018-04-20 21:36:38 --> Helper loaded: form_helper
INFO - 2018-04-20 21:36:38 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:36:38 --> User Agent Class Initialized
INFO - 2018-04-20 21:36:38 --> Controller Class Initialized
INFO - 2018-04-20 21:36:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:36:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:36:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:36:38 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:36:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:36:39 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:36:39 --> Final output sent to browser
DEBUG - 2018-04-20 21:36:39 --> Total execution time: 0.5609
INFO - 2018-04-20 21:37:17 --> Config Class Initialized
INFO - 2018-04-20 21:37:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:37:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:37:17 --> Utf8 Class Initialized
INFO - 2018-04-20 21:37:17 --> URI Class Initialized
INFO - 2018-04-20 21:37:17 --> Router Class Initialized
INFO - 2018-04-20 21:37:17 --> Output Class Initialized
INFO - 2018-04-20 21:37:17 --> Security Class Initialized
DEBUG - 2018-04-20 21:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:37:17 --> CSRF cookie sent
INFO - 2018-04-20 21:37:18 --> Input Class Initialized
INFO - 2018-04-20 21:37:18 --> Language Class Initialized
INFO - 2018-04-20 21:37:18 --> Loader Class Initialized
INFO - 2018-04-20 21:37:18 --> Helper loaded: url_helper
INFO - 2018-04-20 21:37:18 --> Helper loaded: form_helper
INFO - 2018-04-20 21:37:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:37:18 --> User Agent Class Initialized
INFO - 2018-04-20 21:37:18 --> Controller Class Initialized
INFO - 2018-04-20 21:37:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:37:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:37:18 --> CSRF cookie sent
INFO - 2018-04-20 21:37:18 --> Config Class Initialized
INFO - 2018-04-20 21:37:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:37:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:37:18 --> Utf8 Class Initialized
INFO - 2018-04-20 21:37:18 --> URI Class Initialized
DEBUG - 2018-04-20 21:37:18 --> No URI present. Default controller set.
INFO - 2018-04-20 21:37:18 --> Router Class Initialized
INFO - 2018-04-20 21:37:18 --> Output Class Initialized
INFO - 2018-04-20 21:37:18 --> Security Class Initialized
DEBUG - 2018-04-20 21:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:37:18 --> CSRF cookie sent
INFO - 2018-04-20 21:37:18 --> Input Class Initialized
INFO - 2018-04-20 21:37:18 --> Language Class Initialized
INFO - 2018-04-20 21:37:18 --> Loader Class Initialized
INFO - 2018-04-20 21:37:18 --> Helper loaded: url_helper
INFO - 2018-04-20 21:37:18 --> Helper loaded: form_helper
INFO - 2018-04-20 21:37:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:37:18 --> User Agent Class Initialized
INFO - 2018-04-20 21:37:18 --> Controller Class Initialized
INFO - 2018-04-20 21:37:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:37:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:37:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:37:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:37:18 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 21:37:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:37:18 --> Final output sent to browser
DEBUG - 2018-04-20 21:37:18 --> Total execution time: 0.3690
INFO - 2018-04-20 21:37:20 --> Config Class Initialized
INFO - 2018-04-20 21:37:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:37:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:37:20 --> Utf8 Class Initialized
INFO - 2018-04-20 21:37:20 --> URI Class Initialized
INFO - 2018-04-20 21:37:20 --> Router Class Initialized
INFO - 2018-04-20 21:37:20 --> Output Class Initialized
INFO - 2018-04-20 21:37:20 --> Security Class Initialized
DEBUG - 2018-04-20 21:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:37:20 --> CSRF cookie sent
INFO - 2018-04-20 21:37:20 --> Input Class Initialized
INFO - 2018-04-20 21:37:20 --> Language Class Initialized
ERROR - 2018-04-20 21:37:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 21:37:20 --> Config Class Initialized
INFO - 2018-04-20 21:37:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:37:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:37:20 --> Utf8 Class Initialized
INFO - 2018-04-20 21:37:20 --> URI Class Initialized
INFO - 2018-04-20 21:37:20 --> Router Class Initialized
INFO - 2018-04-20 21:37:20 --> Output Class Initialized
INFO - 2018-04-20 21:37:20 --> Security Class Initialized
DEBUG - 2018-04-20 21:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:37:20 --> CSRF cookie sent
INFO - 2018-04-20 21:37:20 --> Input Class Initialized
INFO - 2018-04-20 21:37:20 --> Language Class Initialized
INFO - 2018-04-20 21:37:20 --> Loader Class Initialized
INFO - 2018-04-20 21:37:20 --> Helper loaded: url_helper
INFO - 2018-04-20 21:37:20 --> Helper loaded: form_helper
INFO - 2018-04-20 21:37:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:37:20 --> User Agent Class Initialized
INFO - 2018-04-20 21:37:20 --> Controller Class Initialized
INFO - 2018-04-20 21:37:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:37:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 21:37:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 21:37:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:37:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:37:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:37:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 21:37:21 --> Could not find the language line "req_email"
INFO - 2018-04-20 21:37:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 21:37:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:37:21 --> Final output sent to browser
DEBUG - 2018-04-20 21:37:21 --> Total execution time: 0.4619
INFO - 2018-04-20 21:37:27 --> Config Class Initialized
INFO - 2018-04-20 21:37:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:37:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:37:27 --> Utf8 Class Initialized
INFO - 2018-04-20 21:37:27 --> URI Class Initialized
INFO - 2018-04-20 21:37:27 --> Router Class Initialized
INFO - 2018-04-20 21:37:27 --> Output Class Initialized
INFO - 2018-04-20 21:37:27 --> Security Class Initialized
DEBUG - 2018-04-20 21:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:37:27 --> CSRF cookie sent
INFO - 2018-04-20 21:37:27 --> Input Class Initialized
INFO - 2018-04-20 21:37:27 --> Language Class Initialized
INFO - 2018-04-20 21:37:27 --> Loader Class Initialized
INFO - 2018-04-20 21:37:27 --> Helper loaded: url_helper
INFO - 2018-04-20 21:37:27 --> Helper loaded: form_helper
INFO - 2018-04-20 21:37:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:37:27 --> User Agent Class Initialized
INFO - 2018-04-20 21:37:27 --> Controller Class Initialized
INFO - 2018-04-20 21:37:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:37:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 21:37:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 21:37:27 --> Could not find the language line "req_email"
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 21:37:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:37:28 --> Final output sent to browser
DEBUG - 2018-04-20 21:37:28 --> Total execution time: 0.4335
INFO - 2018-04-20 21:38:06 --> Config Class Initialized
INFO - 2018-04-20 21:38:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:38:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:38:06 --> Utf8 Class Initialized
INFO - 2018-04-20 21:38:06 --> URI Class Initialized
INFO - 2018-04-20 21:38:06 --> Router Class Initialized
INFO - 2018-04-20 21:38:06 --> Output Class Initialized
INFO - 2018-04-20 21:38:06 --> Security Class Initialized
DEBUG - 2018-04-20 21:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:38:06 --> CSRF cookie sent
INFO - 2018-04-20 21:38:06 --> CSRF token verified
INFO - 2018-04-20 21:38:07 --> Input Class Initialized
INFO - 2018-04-20 21:38:07 --> Language Class Initialized
INFO - 2018-04-20 21:38:07 --> Loader Class Initialized
INFO - 2018-04-20 21:38:07 --> Helper loaded: url_helper
INFO - 2018-04-20 21:38:07 --> Helper loaded: form_helper
INFO - 2018-04-20 21:38:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:38:07 --> User Agent Class Initialized
INFO - 2018-04-20 21:38:07 --> Controller Class Initialized
INFO - 2018-04-20 21:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:38:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 21:38:07 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 21:38:07 --> Form Validation Class Initialized
INFO - 2018-04-20 21:38:07 --> Pixel_Model class loaded
INFO - 2018-04-20 21:38:07 --> Database Driver Class Initialized
INFO - 2018-04-20 21:38:07 --> Model "AuthenticationModel" initialized
INFO - 2018-04-20 21:38:07 --> Config Class Initialized
INFO - 2018-04-20 21:38:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:38:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:38:07 --> Utf8 Class Initialized
INFO - 2018-04-20 21:38:07 --> URI Class Initialized
DEBUG - 2018-04-20 21:38:07 --> No URI present. Default controller set.
INFO - 2018-04-20 21:38:07 --> Router Class Initialized
INFO - 2018-04-20 21:38:07 --> Output Class Initialized
INFO - 2018-04-20 21:38:07 --> Security Class Initialized
DEBUG - 2018-04-20 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:38:07 --> CSRF cookie sent
INFO - 2018-04-20 21:38:07 --> Input Class Initialized
INFO - 2018-04-20 21:38:07 --> Language Class Initialized
INFO - 2018-04-20 21:38:07 --> Loader Class Initialized
INFO - 2018-04-20 21:38:07 --> Helper loaded: url_helper
INFO - 2018-04-20 21:38:07 --> Helper loaded: form_helper
INFO - 2018-04-20 21:38:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:38:07 --> User Agent Class Initialized
INFO - 2018-04-20 21:38:07 --> Controller Class Initialized
INFO - 2018-04-20 21:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:38:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:38:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:38:08 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:38:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:38:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 21:38:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:38:08 --> Final output sent to browser
DEBUG - 2018-04-20 21:38:08 --> Total execution time: 0.3865
INFO - 2018-04-20 21:38:09 --> Config Class Initialized
INFO - 2018-04-20 21:38:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:38:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:38:09 --> Utf8 Class Initialized
INFO - 2018-04-20 21:38:09 --> URI Class Initialized
INFO - 2018-04-20 21:38:09 --> Router Class Initialized
INFO - 2018-04-20 21:38:09 --> Output Class Initialized
INFO - 2018-04-20 21:38:09 --> Security Class Initialized
DEBUG - 2018-04-20 21:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:38:09 --> CSRF cookie sent
INFO - 2018-04-20 21:38:09 --> Input Class Initialized
INFO - 2018-04-20 21:38:09 --> Language Class Initialized
ERROR - 2018-04-20 21:38:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 21:38:11 --> Config Class Initialized
INFO - 2018-04-20 21:38:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:38:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:38:11 --> Utf8 Class Initialized
INFO - 2018-04-20 21:38:11 --> URI Class Initialized
INFO - 2018-04-20 21:38:11 --> Router Class Initialized
INFO - 2018-04-20 21:38:11 --> Output Class Initialized
INFO - 2018-04-20 21:38:11 --> Security Class Initialized
DEBUG - 2018-04-20 21:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:38:11 --> CSRF cookie sent
INFO - 2018-04-20 21:38:11 --> Input Class Initialized
INFO - 2018-04-20 21:38:11 --> Language Class Initialized
INFO - 2018-04-20 21:38:11 --> Loader Class Initialized
INFO - 2018-04-20 21:38:11 --> Helper loaded: url_helper
INFO - 2018-04-20 21:38:11 --> Helper loaded: form_helper
INFO - 2018-04-20 21:38:11 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:38:11 --> User Agent Class Initialized
INFO - 2018-04-20 21:38:11 --> Controller Class Initialized
INFO - 2018-04-20 21:38:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:38:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:38:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:38:11 --> Final output sent to browser
DEBUG - 2018-04-20 21:38:11 --> Total execution time: 0.4567
INFO - 2018-04-20 21:42:59 --> Config Class Initialized
INFO - 2018-04-20 21:42:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:42:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:42:59 --> Utf8 Class Initialized
INFO - 2018-04-20 21:42:59 --> URI Class Initialized
INFO - 2018-04-20 21:42:59 --> Router Class Initialized
INFO - 2018-04-20 21:42:59 --> Output Class Initialized
INFO - 2018-04-20 21:42:59 --> Security Class Initialized
DEBUG - 2018-04-20 21:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:42:59 --> CSRF cookie sent
INFO - 2018-04-20 21:42:59 --> Input Class Initialized
INFO - 2018-04-20 21:43:00 --> Language Class Initialized
INFO - 2018-04-20 21:43:00 --> Loader Class Initialized
INFO - 2018-04-20 21:43:00 --> Helper loaded: url_helper
INFO - 2018-04-20 21:43:00 --> Helper loaded: form_helper
INFO - 2018-04-20 21:43:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:43:00 --> User Agent Class Initialized
INFO - 2018-04-20 21:43:00 --> Controller Class Initialized
INFO - 2018-04-20 21:43:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:43:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:43:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:43:00 --> Final output sent to browser
DEBUG - 2018-04-20 21:43:00 --> Total execution time: 0.4350
INFO - 2018-04-20 21:43:27 --> Config Class Initialized
INFO - 2018-04-20 21:43:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:43:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:43:27 --> Utf8 Class Initialized
INFO - 2018-04-20 21:43:27 --> URI Class Initialized
INFO - 2018-04-20 21:43:27 --> Router Class Initialized
INFO - 2018-04-20 21:43:27 --> Output Class Initialized
INFO - 2018-04-20 21:43:28 --> Security Class Initialized
DEBUG - 2018-04-20 21:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:43:28 --> CSRF cookie sent
INFO - 2018-04-20 21:43:28 --> Input Class Initialized
INFO - 2018-04-20 21:43:28 --> Language Class Initialized
INFO - 2018-04-20 21:43:28 --> Loader Class Initialized
INFO - 2018-04-20 21:43:28 --> Helper loaded: url_helper
INFO - 2018-04-20 21:43:28 --> Helper loaded: form_helper
INFO - 2018-04-20 21:43:28 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:43:28 --> User Agent Class Initialized
INFO - 2018-04-20 21:43:28 --> Controller Class Initialized
INFO - 2018-04-20 21:43:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:43:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:43:28 --> Final output sent to browser
DEBUG - 2018-04-20 21:43:28 --> Total execution time: 0.4148
INFO - 2018-04-20 21:44:18 --> Config Class Initialized
INFO - 2018-04-20 21:44:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:44:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:44:18 --> Utf8 Class Initialized
INFO - 2018-04-20 21:44:18 --> URI Class Initialized
INFO - 2018-04-20 21:44:18 --> Router Class Initialized
INFO - 2018-04-20 21:44:18 --> Output Class Initialized
INFO - 2018-04-20 21:44:18 --> Security Class Initialized
DEBUG - 2018-04-20 21:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:44:18 --> CSRF cookie sent
INFO - 2018-04-20 21:44:18 --> Input Class Initialized
INFO - 2018-04-20 21:44:18 --> Language Class Initialized
INFO - 2018-04-20 21:44:18 --> Loader Class Initialized
INFO - 2018-04-20 21:44:18 --> Helper loaded: url_helper
INFO - 2018-04-20 21:44:18 --> Helper loaded: form_helper
INFO - 2018-04-20 21:44:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:44:18 --> User Agent Class Initialized
INFO - 2018-04-20 21:44:18 --> Controller Class Initialized
INFO - 2018-04-20 21:44:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:44:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:44:18 --> Final output sent to browser
DEBUG - 2018-04-20 21:44:18 --> Total execution time: 0.4084
INFO - 2018-04-20 21:44:26 --> Config Class Initialized
INFO - 2018-04-20 21:44:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:44:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:44:26 --> Utf8 Class Initialized
INFO - 2018-04-20 21:44:26 --> URI Class Initialized
INFO - 2018-04-20 21:44:26 --> Router Class Initialized
INFO - 2018-04-20 21:44:26 --> Output Class Initialized
INFO - 2018-04-20 21:44:26 --> Security Class Initialized
DEBUG - 2018-04-20 21:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:44:26 --> CSRF cookie sent
INFO - 2018-04-20 21:44:26 --> Input Class Initialized
INFO - 2018-04-20 21:44:26 --> Language Class Initialized
ERROR - 2018-04-20 21:44:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:46:27 --> Config Class Initialized
INFO - 2018-04-20 21:46:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:46:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:46:27 --> Utf8 Class Initialized
INFO - 2018-04-20 21:46:27 --> URI Class Initialized
INFO - 2018-04-20 21:46:27 --> Router Class Initialized
INFO - 2018-04-20 21:46:27 --> Output Class Initialized
INFO - 2018-04-20 21:46:27 --> Security Class Initialized
DEBUG - 2018-04-20 21:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:46:27 --> CSRF cookie sent
INFO - 2018-04-20 21:46:27 --> Input Class Initialized
INFO - 2018-04-20 21:46:27 --> Language Class Initialized
INFO - 2018-04-20 21:46:27 --> Loader Class Initialized
INFO - 2018-04-20 21:46:27 --> Helper loaded: url_helper
INFO - 2018-04-20 21:46:27 --> Helper loaded: form_helper
INFO - 2018-04-20 21:46:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:46:27 --> User Agent Class Initialized
INFO - 2018-04-20 21:46:27 --> Controller Class Initialized
INFO - 2018-04-20 21:46:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:46:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:46:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:46:27 --> Final output sent to browser
DEBUG - 2018-04-20 21:46:27 --> Total execution time: 0.4342
INFO - 2018-04-20 21:46:27 --> Config Class Initialized
INFO - 2018-04-20 21:46:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:46:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:46:27 --> Utf8 Class Initialized
INFO - 2018-04-20 21:46:27 --> URI Class Initialized
INFO - 2018-04-20 21:46:27 --> Router Class Initialized
INFO - 2018-04-20 21:46:28 --> Output Class Initialized
INFO - 2018-04-20 21:46:28 --> Security Class Initialized
DEBUG - 2018-04-20 21:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:46:28 --> CSRF cookie sent
INFO - 2018-04-20 21:46:28 --> Input Class Initialized
INFO - 2018-04-20 21:46:28 --> Language Class Initialized
ERROR - 2018-04-20 21:46:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:49:14 --> Config Class Initialized
INFO - 2018-04-20 21:49:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:49:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:49:14 --> Utf8 Class Initialized
INFO - 2018-04-20 21:49:15 --> URI Class Initialized
INFO - 2018-04-20 21:49:15 --> Router Class Initialized
INFO - 2018-04-20 21:49:15 --> Output Class Initialized
INFO - 2018-04-20 21:49:15 --> Security Class Initialized
DEBUG - 2018-04-20 21:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:49:15 --> CSRF cookie sent
INFO - 2018-04-20 21:49:15 --> Input Class Initialized
INFO - 2018-04-20 21:49:15 --> Language Class Initialized
INFO - 2018-04-20 21:49:15 --> Loader Class Initialized
INFO - 2018-04-20 21:49:15 --> Helper loaded: url_helper
INFO - 2018-04-20 21:49:15 --> Helper loaded: form_helper
INFO - 2018-04-20 21:49:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:49:15 --> User Agent Class Initialized
INFO - 2018-04-20 21:49:15 --> Controller Class Initialized
INFO - 2018-04-20 21:49:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:49:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:49:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:49:15 --> Final output sent to browser
DEBUG - 2018-04-20 21:49:15 --> Total execution time: 0.4237
INFO - 2018-04-20 21:49:15 --> Config Class Initialized
INFO - 2018-04-20 21:49:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:49:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:49:15 --> Utf8 Class Initialized
INFO - 2018-04-20 21:49:15 --> URI Class Initialized
INFO - 2018-04-20 21:49:15 --> Router Class Initialized
INFO - 2018-04-20 21:49:15 --> Output Class Initialized
INFO - 2018-04-20 21:49:15 --> Security Class Initialized
DEBUG - 2018-04-20 21:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:49:15 --> CSRF cookie sent
INFO - 2018-04-20 21:49:15 --> Input Class Initialized
INFO - 2018-04-20 21:49:15 --> Language Class Initialized
ERROR - 2018-04-20 21:49:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:55:24 --> Config Class Initialized
INFO - 2018-04-20 21:55:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:55:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:55:24 --> Utf8 Class Initialized
INFO - 2018-04-20 21:55:24 --> URI Class Initialized
INFO - 2018-04-20 21:55:24 --> Router Class Initialized
INFO - 2018-04-20 21:55:24 --> Output Class Initialized
INFO - 2018-04-20 21:55:24 --> Security Class Initialized
DEBUG - 2018-04-20 21:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:55:24 --> CSRF cookie sent
INFO - 2018-04-20 21:55:24 --> Input Class Initialized
INFO - 2018-04-20 21:55:24 --> Language Class Initialized
INFO - 2018-04-20 21:55:24 --> Loader Class Initialized
INFO - 2018-04-20 21:55:24 --> Helper loaded: url_helper
INFO - 2018-04-20 21:55:24 --> Helper loaded: form_helper
INFO - 2018-04-20 21:55:24 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:55:24 --> User Agent Class Initialized
INFO - 2018-04-20 21:55:24 --> Controller Class Initialized
INFO - 2018-04-20 21:55:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:55:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:55:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:55:24 --> Final output sent to browser
DEBUG - 2018-04-20 21:55:24 --> Total execution time: 0.4165
INFO - 2018-04-20 21:55:24 --> Config Class Initialized
INFO - 2018-04-20 21:55:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:55:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:55:24 --> Utf8 Class Initialized
INFO - 2018-04-20 21:55:25 --> URI Class Initialized
INFO - 2018-04-20 21:55:25 --> Router Class Initialized
INFO - 2018-04-20 21:55:25 --> Output Class Initialized
INFO - 2018-04-20 21:55:25 --> Security Class Initialized
DEBUG - 2018-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:55:25 --> CSRF cookie sent
INFO - 2018-04-20 21:55:25 --> Input Class Initialized
INFO - 2018-04-20 21:55:25 --> Language Class Initialized
ERROR - 2018-04-20 21:55:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:58:18 --> Config Class Initialized
INFO - 2018-04-20 21:58:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:18 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:18 --> URI Class Initialized
INFO - 2018-04-20 21:58:18 --> Router Class Initialized
INFO - 2018-04-20 21:58:19 --> Output Class Initialized
INFO - 2018-04-20 21:58:19 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:19 --> CSRF cookie sent
INFO - 2018-04-20 21:58:19 --> Input Class Initialized
INFO - 2018-04-20 21:58:19 --> Language Class Initialized
INFO - 2018-04-20 21:58:19 --> Loader Class Initialized
INFO - 2018-04-20 21:58:19 --> Helper loaded: url_helper
INFO - 2018-04-20 21:58:19 --> Helper loaded: form_helper
INFO - 2018-04-20 21:58:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:58:19 --> User Agent Class Initialized
INFO - 2018-04-20 21:58:19 --> Controller Class Initialized
INFO - 2018-04-20 21:58:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:58:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:58:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:58:19 --> Final output sent to browser
DEBUG - 2018-04-20 21:58:19 --> Total execution time: 0.4358
INFO - 2018-04-20 21:58:19 --> Config Class Initialized
INFO - 2018-04-20 21:58:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:19 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:19 --> URI Class Initialized
INFO - 2018-04-20 21:58:19 --> Router Class Initialized
INFO - 2018-04-20 21:58:19 --> Output Class Initialized
INFO - 2018-04-20 21:58:19 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:19 --> CSRF cookie sent
INFO - 2018-04-20 21:58:19 --> Input Class Initialized
INFO - 2018-04-20 21:58:19 --> Language Class Initialized
ERROR - 2018-04-20 21:58:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:58:29 --> Config Class Initialized
INFO - 2018-04-20 21:58:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:29 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:29 --> URI Class Initialized
INFO - 2018-04-20 21:58:29 --> Router Class Initialized
INFO - 2018-04-20 21:58:29 --> Output Class Initialized
INFO - 2018-04-20 21:58:29 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:29 --> CSRF cookie sent
INFO - 2018-04-20 21:58:29 --> Input Class Initialized
INFO - 2018-04-20 21:58:29 --> Language Class Initialized
INFO - 2018-04-20 21:58:29 --> Loader Class Initialized
INFO - 2018-04-20 21:58:29 --> Helper loaded: url_helper
INFO - 2018-04-20 21:58:29 --> Helper loaded: form_helper
INFO - 2018-04-20 21:58:29 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:58:29 --> User Agent Class Initialized
INFO - 2018-04-20 21:58:29 --> Controller Class Initialized
INFO - 2018-04-20 21:58:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:58:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:58:29 --> Final output sent to browser
DEBUG - 2018-04-20 21:58:29 --> Total execution time: 0.4387
INFO - 2018-04-20 21:58:29 --> Config Class Initialized
INFO - 2018-04-20 21:58:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:29 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:29 --> URI Class Initialized
INFO - 2018-04-20 21:58:29 --> Router Class Initialized
INFO - 2018-04-20 21:58:29 --> Output Class Initialized
INFO - 2018-04-20 21:58:29 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:30 --> CSRF cookie sent
INFO - 2018-04-20 21:58:30 --> Input Class Initialized
INFO - 2018-04-20 21:58:30 --> Language Class Initialized
ERROR - 2018-04-20 21:58:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 21:58:44 --> Config Class Initialized
INFO - 2018-04-20 21:58:44 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:44 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:44 --> URI Class Initialized
INFO - 2018-04-20 21:58:44 --> Router Class Initialized
INFO - 2018-04-20 21:58:44 --> Output Class Initialized
INFO - 2018-04-20 21:58:44 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:44 --> CSRF cookie sent
INFO - 2018-04-20 21:58:44 --> Input Class Initialized
INFO - 2018-04-20 21:58:44 --> Language Class Initialized
INFO - 2018-04-20 21:58:44 --> Loader Class Initialized
INFO - 2018-04-20 21:58:44 --> Helper loaded: url_helper
INFO - 2018-04-20 21:58:44 --> Helper loaded: form_helper
INFO - 2018-04-20 21:58:44 --> Helper loaded: language_helper
DEBUG - 2018-04-20 21:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 21:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 21:58:44 --> User Agent Class Initialized
INFO - 2018-04-20 21:58:44 --> Controller Class Initialized
INFO - 2018-04-20 21:58:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 21:58:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 21:58:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 21:58:44 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 21:58:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 21:58:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 21:58:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 21:58:45 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 21:58:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 21:58:45 --> Final output sent to browser
DEBUG - 2018-04-20 21:58:45 --> Total execution time: 0.4466
INFO - 2018-04-20 21:58:45 --> Config Class Initialized
INFO - 2018-04-20 21:58:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 21:58:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 21:58:45 --> Utf8 Class Initialized
INFO - 2018-04-20 21:58:45 --> URI Class Initialized
INFO - 2018-04-20 21:58:45 --> Router Class Initialized
INFO - 2018-04-20 21:58:45 --> Output Class Initialized
INFO - 2018-04-20 21:58:45 --> Security Class Initialized
DEBUG - 2018-04-20 21:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 21:58:45 --> CSRF cookie sent
INFO - 2018-04-20 21:58:45 --> Input Class Initialized
INFO - 2018-04-20 21:58:45 --> Language Class Initialized
ERROR - 2018-04-20 21:58:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:00:41 --> Config Class Initialized
INFO - 2018-04-20 22:00:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:00:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:00:41 --> Utf8 Class Initialized
INFO - 2018-04-20 22:00:41 --> URI Class Initialized
INFO - 2018-04-20 22:00:41 --> Router Class Initialized
INFO - 2018-04-20 22:00:41 --> Output Class Initialized
INFO - 2018-04-20 22:00:41 --> Security Class Initialized
DEBUG - 2018-04-20 22:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:00:41 --> CSRF cookie sent
INFO - 2018-04-20 22:00:41 --> Input Class Initialized
INFO - 2018-04-20 22:00:41 --> Language Class Initialized
INFO - 2018-04-20 22:00:41 --> Loader Class Initialized
INFO - 2018-04-20 22:00:41 --> Helper loaded: url_helper
INFO - 2018-04-20 22:00:41 --> Helper loaded: form_helper
INFO - 2018-04-20 22:00:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:00:41 --> User Agent Class Initialized
INFO - 2018-04-20 22:00:41 --> Controller Class Initialized
INFO - 2018-04-20 22:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:00:41 --> Final output sent to browser
DEBUG - 2018-04-20 22:00:41 --> Total execution time: 0.4431
INFO - 2018-04-20 22:00:41 --> Config Class Initialized
INFO - 2018-04-20 22:00:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:00:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:00:41 --> Utf8 Class Initialized
INFO - 2018-04-20 22:00:41 --> URI Class Initialized
INFO - 2018-04-20 22:00:41 --> Router Class Initialized
INFO - 2018-04-20 22:00:41 --> Output Class Initialized
INFO - 2018-04-20 22:00:42 --> Security Class Initialized
DEBUG - 2018-04-20 22:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:00:42 --> CSRF cookie sent
INFO - 2018-04-20 22:00:42 --> Input Class Initialized
INFO - 2018-04-20 22:00:42 --> Language Class Initialized
ERROR - 2018-04-20 22:00:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:02:31 --> Config Class Initialized
INFO - 2018-04-20 22:02:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:02:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:02:31 --> Utf8 Class Initialized
INFO - 2018-04-20 22:02:31 --> URI Class Initialized
INFO - 2018-04-20 22:02:31 --> Router Class Initialized
INFO - 2018-04-20 22:02:31 --> Output Class Initialized
INFO - 2018-04-20 22:02:31 --> Security Class Initialized
DEBUG - 2018-04-20 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:02:31 --> CSRF cookie sent
INFO - 2018-04-20 22:02:31 --> Input Class Initialized
INFO - 2018-04-20 22:02:31 --> Language Class Initialized
INFO - 2018-04-20 22:02:31 --> Loader Class Initialized
INFO - 2018-04-20 22:02:31 --> Helper loaded: url_helper
INFO - 2018-04-20 22:02:31 --> Helper loaded: form_helper
INFO - 2018-04-20 22:02:31 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:02:31 --> User Agent Class Initialized
INFO - 2018-04-20 22:02:31 --> Controller Class Initialized
INFO - 2018-04-20 22:02:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:02:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:02:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:02:31 --> Final output sent to browser
DEBUG - 2018-04-20 22:02:32 --> Total execution time: 0.4525
INFO - 2018-04-20 22:02:32 --> Config Class Initialized
INFO - 2018-04-20 22:02:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:02:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:02:32 --> Utf8 Class Initialized
INFO - 2018-04-20 22:02:32 --> URI Class Initialized
INFO - 2018-04-20 22:02:32 --> Router Class Initialized
INFO - 2018-04-20 22:02:32 --> Output Class Initialized
INFO - 2018-04-20 22:02:32 --> Security Class Initialized
DEBUG - 2018-04-20 22:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:02:32 --> CSRF cookie sent
INFO - 2018-04-20 22:02:32 --> Input Class Initialized
INFO - 2018-04-20 22:02:32 --> Language Class Initialized
ERROR - 2018-04-20 22:02:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:03:02 --> Config Class Initialized
INFO - 2018-04-20 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:03:02 --> Utf8 Class Initialized
INFO - 2018-04-20 22:03:02 --> URI Class Initialized
INFO - 2018-04-20 22:03:02 --> Router Class Initialized
INFO - 2018-04-20 22:03:02 --> Output Class Initialized
INFO - 2018-04-20 22:03:02 --> Security Class Initialized
DEBUG - 2018-04-20 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:03:02 --> CSRF cookie sent
INFO - 2018-04-20 22:03:02 --> Input Class Initialized
INFO - 2018-04-20 22:03:02 --> Language Class Initialized
INFO - 2018-04-20 22:03:02 --> Loader Class Initialized
INFO - 2018-04-20 22:03:02 --> Helper loaded: url_helper
INFO - 2018-04-20 22:03:02 --> Helper loaded: form_helper
INFO - 2018-04-20 22:03:02 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:03:02 --> User Agent Class Initialized
INFO - 2018-04-20 22:03:02 --> Controller Class Initialized
INFO - 2018-04-20 22:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:03:02 --> Final output sent to browser
DEBUG - 2018-04-20 22:03:02 --> Total execution time: 0.4734
INFO - 2018-04-20 22:03:03 --> Config Class Initialized
INFO - 2018-04-20 22:03:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:03:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:03:03 --> Utf8 Class Initialized
INFO - 2018-04-20 22:03:03 --> URI Class Initialized
INFO - 2018-04-20 22:03:03 --> Router Class Initialized
INFO - 2018-04-20 22:03:03 --> Output Class Initialized
INFO - 2018-04-20 22:03:03 --> Security Class Initialized
DEBUG - 2018-04-20 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:03:03 --> CSRF cookie sent
INFO - 2018-04-20 22:03:03 --> Input Class Initialized
INFO - 2018-04-20 22:03:03 --> Language Class Initialized
ERROR - 2018-04-20 22:03:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:08:54 --> Config Class Initialized
INFO - 2018-04-20 22:08:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:08:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:08:54 --> Utf8 Class Initialized
INFO - 2018-04-20 22:08:55 --> URI Class Initialized
INFO - 2018-04-20 22:08:55 --> Router Class Initialized
INFO - 2018-04-20 22:08:55 --> Output Class Initialized
INFO - 2018-04-20 22:08:55 --> Security Class Initialized
DEBUG - 2018-04-20 22:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:08:55 --> CSRF cookie sent
INFO - 2018-04-20 22:08:55 --> Input Class Initialized
INFO - 2018-04-20 22:08:55 --> Language Class Initialized
INFO - 2018-04-20 22:08:55 --> Loader Class Initialized
INFO - 2018-04-20 22:08:55 --> Helper loaded: url_helper
INFO - 2018-04-20 22:08:55 --> Helper loaded: form_helper
INFO - 2018-04-20 22:08:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:08:55 --> User Agent Class Initialized
INFO - 2018-04-20 22:08:55 --> Controller Class Initialized
INFO - 2018-04-20 22:08:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:08:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:08:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:08:55 --> Final output sent to browser
DEBUG - 2018-04-20 22:08:55 --> Total execution time: 0.4322
INFO - 2018-04-20 22:08:55 --> Config Class Initialized
INFO - 2018-04-20 22:08:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:08:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:08:55 --> Utf8 Class Initialized
INFO - 2018-04-20 22:08:55 --> URI Class Initialized
INFO - 2018-04-20 22:08:55 --> Router Class Initialized
INFO - 2018-04-20 22:08:55 --> Output Class Initialized
INFO - 2018-04-20 22:08:55 --> Security Class Initialized
DEBUG - 2018-04-20 22:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:08:55 --> CSRF cookie sent
INFO - 2018-04-20 22:08:55 --> Input Class Initialized
INFO - 2018-04-20 22:08:55 --> Language Class Initialized
ERROR - 2018-04-20 22:08:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:09:50 --> Config Class Initialized
INFO - 2018-04-20 22:09:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:09:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:09:50 --> Utf8 Class Initialized
INFO - 2018-04-20 22:09:50 --> URI Class Initialized
INFO - 2018-04-20 22:09:50 --> Router Class Initialized
INFO - 2018-04-20 22:09:50 --> Output Class Initialized
INFO - 2018-04-20 22:09:50 --> Security Class Initialized
DEBUG - 2018-04-20 22:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:09:50 --> CSRF cookie sent
INFO - 2018-04-20 22:09:50 --> Input Class Initialized
INFO - 2018-04-20 22:09:50 --> Language Class Initialized
INFO - 2018-04-20 22:09:50 --> Loader Class Initialized
INFO - 2018-04-20 22:09:50 --> Helper loaded: url_helper
INFO - 2018-04-20 22:09:50 --> Helper loaded: form_helper
INFO - 2018-04-20 22:09:50 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:09:50 --> User Agent Class Initialized
INFO - 2018-04-20 22:09:50 --> Controller Class Initialized
INFO - 2018-04-20 22:09:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:09:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:09:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:09:50 --> Final output sent to browser
DEBUG - 2018-04-20 22:09:51 --> Total execution time: 0.4379
INFO - 2018-04-20 22:09:51 --> Config Class Initialized
INFO - 2018-04-20 22:09:51 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:09:51 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:09:51 --> Utf8 Class Initialized
INFO - 2018-04-20 22:09:51 --> URI Class Initialized
INFO - 2018-04-20 22:09:51 --> Router Class Initialized
INFO - 2018-04-20 22:09:51 --> Output Class Initialized
INFO - 2018-04-20 22:09:51 --> Security Class Initialized
DEBUG - 2018-04-20 22:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:09:51 --> CSRF cookie sent
INFO - 2018-04-20 22:09:51 --> Input Class Initialized
INFO - 2018-04-20 22:09:51 --> Language Class Initialized
ERROR - 2018-04-20 22:09:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:29:27 --> Config Class Initialized
INFO - 2018-04-20 22:29:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:29:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:29:27 --> Utf8 Class Initialized
INFO - 2018-04-20 22:29:27 --> URI Class Initialized
INFO - 2018-04-20 22:29:27 --> Router Class Initialized
INFO - 2018-04-20 22:29:27 --> Output Class Initialized
INFO - 2018-04-20 22:29:27 --> Security Class Initialized
DEBUG - 2018-04-20 22:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:29:27 --> CSRF cookie sent
INFO - 2018-04-20 22:29:27 --> Input Class Initialized
INFO - 2018-04-20 22:29:27 --> Language Class Initialized
INFO - 2018-04-20 22:29:27 --> Loader Class Initialized
INFO - 2018-04-20 22:29:27 --> Helper loaded: url_helper
INFO - 2018-04-20 22:29:27 --> Helper loaded: form_helper
INFO - 2018-04-20 22:29:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:29:27 --> User Agent Class Initialized
INFO - 2018-04-20 22:29:27 --> Controller Class Initialized
INFO - 2018-04-20 22:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:29:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:29:28 --> Final output sent to browser
DEBUG - 2018-04-20 22:29:28 --> Total execution time: 0.4414
INFO - 2018-04-20 22:29:28 --> Config Class Initialized
INFO - 2018-04-20 22:29:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:29:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:29:28 --> Utf8 Class Initialized
INFO - 2018-04-20 22:29:28 --> URI Class Initialized
INFO - 2018-04-20 22:29:28 --> Router Class Initialized
INFO - 2018-04-20 22:29:28 --> Output Class Initialized
INFO - 2018-04-20 22:29:28 --> Security Class Initialized
DEBUG - 2018-04-20 22:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:29:28 --> CSRF cookie sent
INFO - 2018-04-20 22:29:28 --> Input Class Initialized
INFO - 2018-04-20 22:29:28 --> Language Class Initialized
ERROR - 2018-04-20 22:29:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:30:05 --> Config Class Initialized
INFO - 2018-04-20 22:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:30:05 --> Utf8 Class Initialized
INFO - 2018-04-20 22:30:05 --> URI Class Initialized
INFO - 2018-04-20 22:30:05 --> Router Class Initialized
INFO - 2018-04-20 22:30:05 --> Output Class Initialized
INFO - 2018-04-20 22:30:05 --> Security Class Initialized
DEBUG - 2018-04-20 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:30:05 --> CSRF cookie sent
INFO - 2018-04-20 22:30:05 --> CSRF token verified
INFO - 2018-04-20 22:30:05 --> Input Class Initialized
INFO - 2018-04-20 22:30:05 --> Language Class Initialized
INFO - 2018-04-20 22:30:05 --> Loader Class Initialized
INFO - 2018-04-20 22:30:05 --> Helper loaded: url_helper
INFO - 2018-04-20 22:30:05 --> Helper loaded: form_helper
INFO - 2018-04-20 22:30:05 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:30:05 --> User Agent Class Initialized
INFO - 2018-04-20 22:30:05 --> Controller Class Initialized
INFO - 2018-04-20 22:30:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:30:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:30:05 --> Upload Class Initialized
INFO - 2018-04-20 22:30:05 --> Pixel_Model class loaded
INFO - 2018-04-20 22:30:05 --> Database Driver Class Initialized
INFO - 2018-04-20 22:30:05 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:30:05 --> Database Driver Class Initialized
INFO - 2018-04-20 22:30:05 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:30:05 --> Helper loaded: string_helper
INFO - 2018-04-20 22:30:05 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 22:30:06 --> Email Class Initialized
DEBUG - 2018-04-20 22:30:06 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:30:06 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 22:30:06 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:30:06 --> Config Class Initialized
INFO - 2018-04-20 22:30:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:30:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:30:06 --> Utf8 Class Initialized
INFO - 2018-04-20 22:30:06 --> URI Class Initialized
INFO - 2018-04-20 22:30:06 --> Router Class Initialized
INFO - 2018-04-20 22:30:06 --> Output Class Initialized
INFO - 2018-04-20 22:30:07 --> Security Class Initialized
DEBUG - 2018-04-20 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:30:07 --> CSRF cookie sent
INFO - 2018-04-20 22:30:07 --> Input Class Initialized
DEBUG - 2018-04-20 22:30:07 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:30:07 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:30:07 --> Language Class Initialized
INFO - 2018-04-20 22:30:07 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
ERROR - 2018-04-20 22:30:07 --> 404 Page Not Found: Assets/images
INFO - 2018-04-20 22:30:07 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:30:07 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 22:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:30:07 --> Final output sent to browser
DEBUG - 2018-04-20 22:30:07 --> Total execution time: 2.1623
INFO - 2018-04-20 22:30:07 --> Config Class Initialized
INFO - 2018-04-20 22:30:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:30:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:30:07 --> Utf8 Class Initialized
INFO - 2018-04-20 22:30:07 --> URI Class Initialized
INFO - 2018-04-20 22:30:07 --> Router Class Initialized
INFO - 2018-04-20 22:30:07 --> Output Class Initialized
INFO - 2018-04-20 22:30:07 --> Security Class Initialized
DEBUG - 2018-04-20 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:30:07 --> CSRF cookie sent
INFO - 2018-04-20 22:30:07 --> Input Class Initialized
INFO - 2018-04-20 22:30:07 --> Language Class Initialized
ERROR - 2018-04-20 22:30:07 --> 404 Page Not Found: Assets/images
INFO - 2018-04-20 22:33:24 --> Config Class Initialized
INFO - 2018-04-20 22:33:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:24 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:24 --> URI Class Initialized
INFO - 2018-04-20 22:33:24 --> Router Class Initialized
INFO - 2018-04-20 22:33:24 --> Output Class Initialized
INFO - 2018-04-20 22:33:24 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:24 --> CSRF cookie sent
INFO - 2018-04-20 22:33:24 --> Input Class Initialized
INFO - 2018-04-20 22:33:24 --> Language Class Initialized
INFO - 2018-04-20 22:33:24 --> Loader Class Initialized
INFO - 2018-04-20 22:33:24 --> Helper loaded: url_helper
INFO - 2018-04-20 22:33:24 --> Helper loaded: form_helper
INFO - 2018-04-20 22:33:24 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:33:24 --> User Agent Class Initialized
INFO - 2018-04-20 22:33:24 --> Controller Class Initialized
INFO - 2018-04-20 22:33:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:33:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:33:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:33:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:33:25 --> Final output sent to browser
DEBUG - 2018-04-20 22:33:25 --> Total execution time: 0.4463
INFO - 2018-04-20 22:33:25 --> Config Class Initialized
INFO - 2018-04-20 22:33:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:25 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:25 --> URI Class Initialized
INFO - 2018-04-20 22:33:25 --> Router Class Initialized
INFO - 2018-04-20 22:33:25 --> Output Class Initialized
INFO - 2018-04-20 22:33:25 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:25 --> CSRF cookie sent
INFO - 2018-04-20 22:33:25 --> Input Class Initialized
INFO - 2018-04-20 22:33:25 --> Language Class Initialized
ERROR - 2018-04-20 22:33:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:33:26 --> Config Class Initialized
INFO - 2018-04-20 22:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:26 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:26 --> URI Class Initialized
INFO - 2018-04-20 22:33:26 --> Router Class Initialized
INFO - 2018-04-20 22:33:26 --> Output Class Initialized
INFO - 2018-04-20 22:33:26 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:27 --> CSRF cookie sent
INFO - 2018-04-20 22:33:27 --> Input Class Initialized
INFO - 2018-04-20 22:33:27 --> Language Class Initialized
INFO - 2018-04-20 22:33:27 --> Loader Class Initialized
INFO - 2018-04-20 22:33:27 --> Helper loaded: url_helper
INFO - 2018-04-20 22:33:27 --> Helper loaded: form_helper
INFO - 2018-04-20 22:33:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:33:27 --> User Agent Class Initialized
INFO - 2018-04-20 22:33:27 --> Controller Class Initialized
INFO - 2018-04-20 22:33:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:33:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:33:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:33:27 --> Final output sent to browser
DEBUG - 2018-04-20 22:33:27 --> Total execution time: 0.4637
INFO - 2018-04-20 22:33:27 --> Config Class Initialized
INFO - 2018-04-20 22:33:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:27 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:27 --> URI Class Initialized
INFO - 2018-04-20 22:33:27 --> Router Class Initialized
INFO - 2018-04-20 22:33:27 --> Output Class Initialized
INFO - 2018-04-20 22:33:27 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:27 --> CSRF cookie sent
INFO - 2018-04-20 22:33:27 --> Input Class Initialized
INFO - 2018-04-20 22:33:27 --> Language Class Initialized
ERROR - 2018-04-20 22:33:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:33:34 --> Config Class Initialized
INFO - 2018-04-20 22:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:34 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:34 --> URI Class Initialized
INFO - 2018-04-20 22:33:34 --> Router Class Initialized
INFO - 2018-04-20 22:33:34 --> Output Class Initialized
INFO - 2018-04-20 22:33:34 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:34 --> CSRF cookie sent
INFO - 2018-04-20 22:33:34 --> CSRF token verified
INFO - 2018-04-20 22:33:34 --> Input Class Initialized
INFO - 2018-04-20 22:33:34 --> Language Class Initialized
INFO - 2018-04-20 22:33:34 --> Loader Class Initialized
INFO - 2018-04-20 22:33:34 --> Helper loaded: url_helper
INFO - 2018-04-20 22:33:34 --> Helper loaded: form_helper
INFO - 2018-04-20 22:33:34 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:33:34 --> User Agent Class Initialized
INFO - 2018-04-20 22:33:34 --> Controller Class Initialized
INFO - 2018-04-20 22:33:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:33:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:33:34 --> Upload Class Initialized
INFO - 2018-04-20 22:33:34 --> Pixel_Model class loaded
INFO - 2018-04-20 22:33:34 --> Database Driver Class Initialized
INFO - 2018-04-20 22:33:34 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:33:34 --> Database Driver Class Initialized
INFO - 2018-04-20 22:33:34 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:33:34 --> Helper loaded: string_helper
INFO - 2018-04-20 22:33:34 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 22:33:34 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:33:34 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:33:34 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:33:34 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 22:33:34 --> Email Class Initialized
ERROR - 2018-04-20 22:33:36 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 22:33:36 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-04-20 22:33:36 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:33:36 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:33:36 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:33:36 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:33:36 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 22:33:36 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-20 22:33:37 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
DEBUG - 2018-04-20 22:33:37 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 22:33:37 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:33:37 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:33:37 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:33:37 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 22:33:37 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-20 22:33:38 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 22:33:38 --> Config Class Initialized
INFO - 2018-04-20 22:33:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:39 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:39 --> URI Class Initialized
INFO - 2018-04-20 22:33:39 --> Router Class Initialized
INFO - 2018-04-20 22:33:39 --> Output Class Initialized
INFO - 2018-04-20 22:33:39 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:39 --> CSRF cookie sent
INFO - 2018-04-20 22:33:39 --> Input Class Initialized
INFO - 2018-04-20 22:33:39 --> Language Class Initialized
INFO - 2018-04-20 22:33:39 --> Loader Class Initialized
INFO - 2018-04-20 22:33:39 --> Helper loaded: url_helper
INFO - 2018-04-20 22:33:39 --> Helper loaded: form_helper
INFO - 2018-04-20 22:33:39 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:33:39 --> User Agent Class Initialized
INFO - 2018-04-20 22:33:39 --> Controller Class Initialized
INFO - 2018-04-20 22:33:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:33:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:33:39 --> Final output sent to browser
DEBUG - 2018-04-20 22:33:39 --> Total execution time: 0.4606
INFO - 2018-04-20 22:33:39 --> Config Class Initialized
INFO - 2018-04-20 22:33:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:33:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:33:39 --> Utf8 Class Initialized
INFO - 2018-04-20 22:33:39 --> URI Class Initialized
INFO - 2018-04-20 22:33:39 --> Router Class Initialized
INFO - 2018-04-20 22:33:39 --> Output Class Initialized
INFO - 2018-04-20 22:33:39 --> Security Class Initialized
DEBUG - 2018-04-20 22:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:33:40 --> CSRF cookie sent
INFO - 2018-04-20 22:33:40 --> Input Class Initialized
INFO - 2018-04-20 22:33:40 --> Language Class Initialized
ERROR - 2018-04-20 22:33:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:36:05 --> Config Class Initialized
INFO - 2018-04-20 22:36:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:36:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:36:05 --> Utf8 Class Initialized
INFO - 2018-04-20 22:36:05 --> URI Class Initialized
INFO - 2018-04-20 22:36:05 --> Router Class Initialized
INFO - 2018-04-20 22:36:05 --> Output Class Initialized
INFO - 2018-04-20 22:36:05 --> Security Class Initialized
DEBUG - 2018-04-20 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:36:05 --> CSRF cookie sent
INFO - 2018-04-20 22:36:05 --> Input Class Initialized
INFO - 2018-04-20 22:36:05 --> Language Class Initialized
INFO - 2018-04-20 22:36:05 --> Loader Class Initialized
INFO - 2018-04-20 22:36:05 --> Helper loaded: url_helper
INFO - 2018-04-20 22:36:05 --> Helper loaded: form_helper
INFO - 2018-04-20 22:36:05 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:36:05 --> User Agent Class Initialized
INFO - 2018-04-20 22:36:05 --> Controller Class Initialized
INFO - 2018-04-20 22:36:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:36:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:36:05 --> Pixel_Model class loaded
INFO - 2018-04-20 22:36:05 --> Database Driver Class Initialized
INFO - 2018-04-20 22:36:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:36:05 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:36:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:36:05 --> Final output sent to browser
DEBUG - 2018-04-20 22:36:05 --> Total execution time: 0.6129
INFO - 2018-04-20 22:36:06 --> Config Class Initialized
INFO - 2018-04-20 22:36:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:36:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:36:06 --> Utf8 Class Initialized
INFO - 2018-04-20 22:36:06 --> URI Class Initialized
INFO - 2018-04-20 22:36:06 --> Router Class Initialized
INFO - 2018-04-20 22:36:06 --> Output Class Initialized
INFO - 2018-04-20 22:36:06 --> Security Class Initialized
DEBUG - 2018-04-20 22:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:36:06 --> CSRF cookie sent
INFO - 2018-04-20 22:36:06 --> Input Class Initialized
INFO - 2018-04-20 22:36:06 --> Language Class Initialized
ERROR - 2018-04-20 22:36:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:37:47 --> Config Class Initialized
INFO - 2018-04-20 22:37:47 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:37:47 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:37:47 --> Utf8 Class Initialized
INFO - 2018-04-20 22:37:47 --> URI Class Initialized
INFO - 2018-04-20 22:37:47 --> Router Class Initialized
INFO - 2018-04-20 22:37:47 --> Output Class Initialized
INFO - 2018-04-20 22:37:47 --> Security Class Initialized
DEBUG - 2018-04-20 22:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:37:47 --> CSRF cookie sent
INFO - 2018-04-20 22:37:47 --> Input Class Initialized
INFO - 2018-04-20 22:37:47 --> Language Class Initialized
INFO - 2018-04-20 22:37:47 --> Loader Class Initialized
INFO - 2018-04-20 22:37:47 --> Helper loaded: url_helper
INFO - 2018-04-20 22:37:47 --> Helper loaded: form_helper
INFO - 2018-04-20 22:37:47 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:37:47 --> User Agent Class Initialized
INFO - 2018-04-20 22:37:47 --> Controller Class Initialized
INFO - 2018-04-20 22:37:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:37:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:37:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:37:47 --> Final output sent to browser
DEBUG - 2018-04-20 22:37:47 --> Total execution time: 0.4467
INFO - 2018-04-20 22:37:48 --> Config Class Initialized
INFO - 2018-04-20 22:37:48 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:37:48 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:37:48 --> Utf8 Class Initialized
INFO - 2018-04-20 22:37:48 --> URI Class Initialized
INFO - 2018-04-20 22:37:48 --> Router Class Initialized
INFO - 2018-04-20 22:37:48 --> Output Class Initialized
INFO - 2018-04-20 22:37:48 --> Security Class Initialized
DEBUG - 2018-04-20 22:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:37:48 --> CSRF cookie sent
INFO - 2018-04-20 22:37:48 --> Input Class Initialized
INFO - 2018-04-20 22:37:48 --> Language Class Initialized
ERROR - 2018-04-20 22:37:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:38:40 --> Config Class Initialized
INFO - 2018-04-20 22:38:40 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:38:40 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:38:40 --> Utf8 Class Initialized
INFO - 2018-04-20 22:38:40 --> URI Class Initialized
INFO - 2018-04-20 22:38:40 --> Router Class Initialized
INFO - 2018-04-20 22:38:40 --> Output Class Initialized
INFO - 2018-04-20 22:38:40 --> Security Class Initialized
DEBUG - 2018-04-20 22:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:38:41 --> CSRF cookie sent
INFO - 2018-04-20 22:38:41 --> Input Class Initialized
INFO - 2018-04-20 22:38:41 --> Language Class Initialized
INFO - 2018-04-20 22:38:41 --> Loader Class Initialized
INFO - 2018-04-20 22:38:41 --> Helper loaded: url_helper
INFO - 2018-04-20 22:38:41 --> Helper loaded: form_helper
INFO - 2018-04-20 22:38:41 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:38:41 --> User Agent Class Initialized
INFO - 2018-04-20 22:38:41 --> Controller Class Initialized
INFO - 2018-04-20 22:38:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:38:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:38:41 --> Pixel_Model class loaded
INFO - 2018-04-20 22:38:41 --> Database Driver Class Initialized
INFO - 2018-04-20 22:38:41 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:38:41 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:38:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:38:41 --> Final output sent to browser
DEBUG - 2018-04-20 22:38:41 --> Total execution time: 0.5170
INFO - 2018-04-20 22:38:41 --> Config Class Initialized
INFO - 2018-04-20 22:38:41 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:38:41 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:38:41 --> Utf8 Class Initialized
INFO - 2018-04-20 22:38:41 --> URI Class Initialized
INFO - 2018-04-20 22:38:41 --> Router Class Initialized
INFO - 2018-04-20 22:38:41 --> Output Class Initialized
INFO - 2018-04-20 22:38:41 --> Security Class Initialized
DEBUG - 2018-04-20 22:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:38:41 --> CSRF cookie sent
INFO - 2018-04-20 22:38:41 --> Input Class Initialized
INFO - 2018-04-20 22:38:41 --> Language Class Initialized
ERROR - 2018-04-20 22:38:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:54:53 --> Config Class Initialized
INFO - 2018-04-20 22:54:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:54:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:54:53 --> Utf8 Class Initialized
INFO - 2018-04-20 22:54:53 --> URI Class Initialized
INFO - 2018-04-20 22:54:53 --> Router Class Initialized
INFO - 2018-04-20 22:54:53 --> Output Class Initialized
INFO - 2018-04-20 22:54:53 --> Security Class Initialized
DEBUG - 2018-04-20 22:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:54:53 --> CSRF cookie sent
INFO - 2018-04-20 22:54:53 --> Input Class Initialized
INFO - 2018-04-20 22:54:53 --> Language Class Initialized
INFO - 2018-04-20 22:54:53 --> Loader Class Initialized
INFO - 2018-04-20 22:54:53 --> Helper loaded: url_helper
INFO - 2018-04-20 22:54:53 --> Helper loaded: form_helper
INFO - 2018-04-20 22:54:53 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:54:53 --> User Agent Class Initialized
INFO - 2018-04-20 22:54:53 --> Controller Class Initialized
INFO - 2018-04-20 22:54:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:54:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:54:53 --> Pixel_Model class loaded
INFO - 2018-04-20 22:54:53 --> Database Driver Class Initialized
INFO - 2018-04-20 22:54:53 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:54:53 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:54:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:54:53 --> Final output sent to browser
DEBUG - 2018-04-20 22:54:53 --> Total execution time: 0.5449
INFO - 2018-04-20 22:54:54 --> Config Class Initialized
INFO - 2018-04-20 22:54:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:54:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:54:54 --> Utf8 Class Initialized
INFO - 2018-04-20 22:54:54 --> URI Class Initialized
INFO - 2018-04-20 22:54:54 --> Router Class Initialized
INFO - 2018-04-20 22:54:54 --> Output Class Initialized
INFO - 2018-04-20 22:54:54 --> Security Class Initialized
DEBUG - 2018-04-20 22:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:54:54 --> CSRF cookie sent
INFO - 2018-04-20 22:54:54 --> Input Class Initialized
INFO - 2018-04-20 22:54:54 --> Language Class Initialized
ERROR - 2018-04-20 22:54:54 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:55:29 --> Config Class Initialized
INFO - 2018-04-20 22:55:29 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:55:29 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:55:29 --> Utf8 Class Initialized
INFO - 2018-04-20 22:55:29 --> URI Class Initialized
INFO - 2018-04-20 22:55:29 --> Router Class Initialized
INFO - 2018-04-20 22:55:29 --> Output Class Initialized
INFO - 2018-04-20 22:55:29 --> Security Class Initialized
DEBUG - 2018-04-20 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:55:29 --> CSRF cookie sent
INFO - 2018-04-20 22:55:29 --> CSRF token verified
INFO - 2018-04-20 22:55:29 --> Input Class Initialized
INFO - 2018-04-20 22:55:29 --> Language Class Initialized
INFO - 2018-04-20 22:55:29 --> Loader Class Initialized
INFO - 2018-04-20 22:55:29 --> Helper loaded: url_helper
INFO - 2018-04-20 22:55:29 --> Helper loaded: form_helper
INFO - 2018-04-20 22:55:29 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:55:29 --> User Agent Class Initialized
INFO - 2018-04-20 22:55:29 --> Controller Class Initialized
INFO - 2018-04-20 22:55:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:55:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:55:29 --> Form Validation Class Initialized
INFO - 2018-04-20 22:55:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 22:55:29 --> Pixel_Model class loaded
INFO - 2018-04-20 22:55:29 --> Database Driver Class Initialized
INFO - 2018-04-20 22:55:29 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:55:29 --> Helper loaded: string_helper
INFO - 2018-04-20 22:55:29 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 22:55:30 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:55:30 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:55:30 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:55:30 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 22:55:30 --> Email Class Initialized
ERROR - 2018-04-20 22:55:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 22:55:31 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-20 22:55:31 --> Config Class Initialized
INFO - 2018-04-20 22:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:55:31 --> Utf8 Class Initialized
INFO - 2018-04-20 22:55:31 --> URI Class Initialized
INFO - 2018-04-20 22:55:31 --> Router Class Initialized
INFO - 2018-04-20 22:55:31 --> Output Class Initialized
INFO - 2018-04-20 22:55:31 --> Security Class Initialized
DEBUG - 2018-04-20 22:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:55:31 --> CSRF cookie sent
INFO - 2018-04-20 22:55:31 --> Input Class Initialized
INFO - 2018-04-20 22:55:31 --> Language Class Initialized
INFO - 2018-04-20 22:55:31 --> Loader Class Initialized
INFO - 2018-04-20 22:55:31 --> Helper loaded: url_helper
INFO - 2018-04-20 22:55:31 --> Helper loaded: form_helper
INFO - 2018-04-20 22:55:31 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:55:31 --> User Agent Class Initialized
INFO - 2018-04-20 22:55:31 --> Controller Class Initialized
INFO - 2018-04-20 22:55:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:55:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:55:31 --> Config Class Initialized
INFO - 2018-04-20 22:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:55:31 --> Utf8 Class Initialized
INFO - 2018-04-20 22:55:31 --> URI Class Initialized
DEBUG - 2018-04-20 22:55:31 --> No URI present. Default controller set.
INFO - 2018-04-20 22:55:31 --> Router Class Initialized
INFO - 2018-04-20 22:55:31 --> Output Class Initialized
INFO - 2018-04-20 22:55:31 --> Security Class Initialized
DEBUG - 2018-04-20 22:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:55:31 --> CSRF cookie sent
INFO - 2018-04-20 22:55:31 --> Input Class Initialized
INFO - 2018-04-20 22:55:31 --> Language Class Initialized
INFO - 2018-04-20 22:55:32 --> Loader Class Initialized
INFO - 2018-04-20 22:55:32 --> Helper loaded: url_helper
INFO - 2018-04-20 22:55:32 --> Helper loaded: form_helper
INFO - 2018-04-20 22:55:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:55:32 --> User Agent Class Initialized
INFO - 2018-04-20 22:55:32 --> Controller Class Initialized
INFO - 2018-04-20 22:55:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:55:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:55:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:55:32 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:55:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:55:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 22:55:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:55:32 --> Final output sent to browser
DEBUG - 2018-04-20 22:55:32 --> Total execution time: 0.5475
INFO - 2018-04-20 22:55:32 --> Config Class Initialized
INFO - 2018-04-20 22:55:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:55:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:55:32 --> Utf8 Class Initialized
INFO - 2018-04-20 22:55:32 --> URI Class Initialized
INFO - 2018-04-20 22:55:32 --> Router Class Initialized
INFO - 2018-04-20 22:55:32 --> Output Class Initialized
INFO - 2018-04-20 22:55:32 --> Security Class Initialized
DEBUG - 2018-04-20 22:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:55:32 --> CSRF cookie sent
INFO - 2018-04-20 22:55:32 --> Input Class Initialized
INFO - 2018-04-20 22:55:32 --> Language Class Initialized
ERROR - 2018-04-20 22:55:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:55:34 --> Config Class Initialized
INFO - 2018-04-20 22:55:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:55:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:55:34 --> Utf8 Class Initialized
INFO - 2018-04-20 22:55:34 --> URI Class Initialized
INFO - 2018-04-20 22:55:34 --> Router Class Initialized
INFO - 2018-04-20 22:55:34 --> Output Class Initialized
INFO - 2018-04-20 22:55:34 --> Security Class Initialized
DEBUG - 2018-04-20 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:55:34 --> CSRF cookie sent
INFO - 2018-04-20 22:55:34 --> Input Class Initialized
INFO - 2018-04-20 22:55:34 --> Language Class Initialized
ERROR - 2018-04-20 22:55:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 22:56:00 --> Config Class Initialized
INFO - 2018-04-20 22:56:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:00 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:00 --> URI Class Initialized
INFO - 2018-04-20 22:56:00 --> Router Class Initialized
INFO - 2018-04-20 22:56:00 --> Output Class Initialized
INFO - 2018-04-20 22:56:00 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:00 --> CSRF cookie sent
INFO - 2018-04-20 22:56:00 --> Input Class Initialized
INFO - 2018-04-20 22:56:00 --> Language Class Initialized
INFO - 2018-04-20 22:56:00 --> Loader Class Initialized
INFO - 2018-04-20 22:56:00 --> Helper loaded: url_helper
INFO - 2018-04-20 22:56:00 --> Helper loaded: form_helper
INFO - 2018-04-20 22:56:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:56:00 --> User Agent Class Initialized
INFO - 2018-04-20 22:56:00 --> Controller Class Initialized
INFO - 2018-04-20 22:56:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:56:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:56:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:56:01 --> Final output sent to browser
DEBUG - 2018-04-20 22:56:01 --> Total execution time: 0.4739
INFO - 2018-04-20 22:56:01 --> Config Class Initialized
INFO - 2018-04-20 22:56:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:01 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:01 --> URI Class Initialized
INFO - 2018-04-20 22:56:01 --> Router Class Initialized
INFO - 2018-04-20 22:56:01 --> Output Class Initialized
INFO - 2018-04-20 22:56:01 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:01 --> CSRF cookie sent
INFO - 2018-04-20 22:56:01 --> Input Class Initialized
INFO - 2018-04-20 22:56:01 --> Language Class Initialized
ERROR - 2018-04-20 22:56:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:56:02 --> Config Class Initialized
INFO - 2018-04-20 22:56:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:03 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:03 --> URI Class Initialized
INFO - 2018-04-20 22:56:03 --> Router Class Initialized
INFO - 2018-04-20 22:56:03 --> Output Class Initialized
INFO - 2018-04-20 22:56:03 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:03 --> CSRF cookie sent
INFO - 2018-04-20 22:56:03 --> Input Class Initialized
INFO - 2018-04-20 22:56:03 --> Language Class Initialized
INFO - 2018-04-20 22:56:03 --> Loader Class Initialized
INFO - 2018-04-20 22:56:03 --> Helper loaded: url_helper
INFO - 2018-04-20 22:56:03 --> Helper loaded: form_helper
INFO - 2018-04-20 22:56:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:56:03 --> User Agent Class Initialized
INFO - 2018-04-20 22:56:03 --> Controller Class Initialized
INFO - 2018-04-20 22:56:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:56:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:56:03 --> Pixel_Model class loaded
INFO - 2018-04-20 22:56:03 --> Database Driver Class Initialized
INFO - 2018-04-20 22:56:03 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:56:03 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:56:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:56:03 --> Final output sent to browser
DEBUG - 2018-04-20 22:56:03 --> Total execution time: 0.5678
INFO - 2018-04-20 22:56:03 --> Config Class Initialized
INFO - 2018-04-20 22:56:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:03 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:04 --> URI Class Initialized
INFO - 2018-04-20 22:56:04 --> Router Class Initialized
INFO - 2018-04-20 22:56:04 --> Output Class Initialized
INFO - 2018-04-20 22:56:04 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:04 --> CSRF cookie sent
INFO - 2018-04-20 22:56:04 --> Input Class Initialized
INFO - 2018-04-20 22:56:04 --> Language Class Initialized
ERROR - 2018-04-20 22:56:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:56:45 --> Config Class Initialized
INFO - 2018-04-20 22:56:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:45 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:45 --> URI Class Initialized
INFO - 2018-04-20 22:56:45 --> Router Class Initialized
INFO - 2018-04-20 22:56:45 --> Output Class Initialized
INFO - 2018-04-20 22:56:45 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:45 --> CSRF cookie sent
INFO - 2018-04-20 22:56:45 --> Input Class Initialized
INFO - 2018-04-20 22:56:45 --> Language Class Initialized
INFO - 2018-04-20 22:56:45 --> Loader Class Initialized
INFO - 2018-04-20 22:56:45 --> Helper loaded: url_helper
INFO - 2018-04-20 22:56:45 --> Helper loaded: form_helper
INFO - 2018-04-20 22:56:45 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:56:45 --> User Agent Class Initialized
INFO - 2018-04-20 22:56:45 --> Controller Class Initialized
INFO - 2018-04-20 22:56:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:56:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:56:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:56:45 --> Final output sent to browser
DEBUG - 2018-04-20 22:56:45 --> Total execution time: 0.4670
INFO - 2018-04-20 22:56:46 --> Config Class Initialized
INFO - 2018-04-20 22:56:46 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:56:46 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:56:46 --> Utf8 Class Initialized
INFO - 2018-04-20 22:56:46 --> URI Class Initialized
INFO - 2018-04-20 22:56:46 --> Router Class Initialized
INFO - 2018-04-20 22:56:46 --> Output Class Initialized
INFO - 2018-04-20 22:56:46 --> Security Class Initialized
DEBUG - 2018-04-20 22:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:56:46 --> CSRF cookie sent
INFO - 2018-04-20 22:56:46 --> Input Class Initialized
INFO - 2018-04-20 22:56:46 --> Language Class Initialized
ERROR - 2018-04-20 22:56:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:57:22 --> Config Class Initialized
INFO - 2018-04-20 22:57:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:57:22 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:57:22 --> Utf8 Class Initialized
INFO - 2018-04-20 22:57:22 --> URI Class Initialized
INFO - 2018-04-20 22:57:22 --> Router Class Initialized
INFO - 2018-04-20 22:57:22 --> Output Class Initialized
INFO - 2018-04-20 22:57:22 --> Security Class Initialized
DEBUG - 2018-04-20 22:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:57:22 --> CSRF cookie sent
INFO - 2018-04-20 22:57:22 --> Input Class Initialized
INFO - 2018-04-20 22:57:22 --> Language Class Initialized
INFO - 2018-04-20 22:57:22 --> Loader Class Initialized
INFO - 2018-04-20 22:57:22 --> Helper loaded: url_helper
INFO - 2018-04-20 22:57:22 --> Helper loaded: form_helper
INFO - 2018-04-20 22:57:22 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:57:22 --> User Agent Class Initialized
INFO - 2018-04-20 22:57:22 --> Controller Class Initialized
INFO - 2018-04-20 22:57:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:57:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:57:23 --> Pixel_Model class loaded
INFO - 2018-04-20 22:57:23 --> Database Driver Class Initialized
INFO - 2018-04-20 22:57:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:57:23 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:57:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:57:23 --> Final output sent to browser
DEBUG - 2018-04-20 22:57:23 --> Total execution time: 0.5194
INFO - 2018-04-20 22:57:23 --> Config Class Initialized
INFO - 2018-04-20 22:57:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:57:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:57:23 --> Utf8 Class Initialized
INFO - 2018-04-20 22:57:23 --> URI Class Initialized
INFO - 2018-04-20 22:57:23 --> Router Class Initialized
INFO - 2018-04-20 22:57:23 --> Output Class Initialized
INFO - 2018-04-20 22:57:23 --> Security Class Initialized
DEBUG - 2018-04-20 22:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:57:23 --> CSRF cookie sent
INFO - 2018-04-20 22:57:23 --> Input Class Initialized
INFO - 2018-04-20 22:57:23 --> Language Class Initialized
ERROR - 2018-04-20 22:57:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:58:36 --> Config Class Initialized
INFO - 2018-04-20 22:58:36 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:58:36 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:58:36 --> Utf8 Class Initialized
INFO - 2018-04-20 22:58:36 --> URI Class Initialized
INFO - 2018-04-20 22:58:36 --> Router Class Initialized
INFO - 2018-04-20 22:58:36 --> Output Class Initialized
INFO - 2018-04-20 22:58:36 --> Security Class Initialized
DEBUG - 2018-04-20 22:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:58:36 --> CSRF cookie sent
INFO - 2018-04-20 22:58:36 --> Input Class Initialized
INFO - 2018-04-20 22:58:36 --> Language Class Initialized
ERROR - 2018-04-20 22:58:36 --> 404 Page Not Found: Add-adviser/index
INFO - 2018-04-20 22:58:52 --> Config Class Initialized
INFO - 2018-04-20 22:58:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:58:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:58:52 --> Utf8 Class Initialized
INFO - 2018-04-20 22:58:52 --> URI Class Initialized
INFO - 2018-04-20 22:58:52 --> Router Class Initialized
INFO - 2018-04-20 22:58:52 --> Output Class Initialized
INFO - 2018-04-20 22:58:52 --> Security Class Initialized
DEBUG - 2018-04-20 22:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:58:52 --> CSRF cookie sent
INFO - 2018-04-20 22:58:52 --> Input Class Initialized
INFO - 2018-04-20 22:58:52 --> Language Class Initialized
INFO - 2018-04-20 22:58:52 --> Loader Class Initialized
INFO - 2018-04-20 22:58:52 --> Helper loaded: url_helper
INFO - 2018-04-20 22:58:52 --> Helper loaded: form_helper
INFO - 2018-04-20 22:58:52 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:58:52 --> User Agent Class Initialized
INFO - 2018-04-20 22:58:52 --> Controller Class Initialized
INFO - 2018-04-20 22:58:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:58:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-20 22:58:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:58:52 --> Final output sent to browser
DEBUG - 2018-04-20 22:58:53 --> Total execution time: 0.4593
INFO - 2018-04-20 22:58:53 --> Config Class Initialized
INFO - 2018-04-20 22:58:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:58:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:58:53 --> Utf8 Class Initialized
INFO - 2018-04-20 22:58:53 --> URI Class Initialized
INFO - 2018-04-20 22:58:53 --> Router Class Initialized
INFO - 2018-04-20 22:58:53 --> Output Class Initialized
INFO - 2018-04-20 22:58:53 --> Security Class Initialized
DEBUG - 2018-04-20 22:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:58:53 --> CSRF cookie sent
INFO - 2018-04-20 22:58:53 --> Input Class Initialized
INFO - 2018-04-20 22:58:53 --> Language Class Initialized
ERROR - 2018-04-20 22:58:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:58:55 --> Config Class Initialized
INFO - 2018-04-20 22:58:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:58:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:58:55 --> Utf8 Class Initialized
INFO - 2018-04-20 22:58:55 --> URI Class Initialized
INFO - 2018-04-20 22:58:55 --> Router Class Initialized
INFO - 2018-04-20 22:58:55 --> Output Class Initialized
INFO - 2018-04-20 22:58:55 --> Security Class Initialized
DEBUG - 2018-04-20 22:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:58:55 --> CSRF cookie sent
INFO - 2018-04-20 22:58:55 --> Input Class Initialized
INFO - 2018-04-20 22:58:55 --> Language Class Initialized
INFO - 2018-04-20 22:58:55 --> Loader Class Initialized
INFO - 2018-04-20 22:58:55 --> Helper loaded: url_helper
INFO - 2018-04-20 22:58:55 --> Helper loaded: form_helper
INFO - 2018-04-20 22:58:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:58:55 --> User Agent Class Initialized
INFO - 2018-04-20 22:58:55 --> Controller Class Initialized
INFO - 2018-04-20 22:58:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:58:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:58:55 --> Pixel_Model class loaded
INFO - 2018-04-20 22:58:55 --> Database Driver Class Initialized
INFO - 2018-04-20 22:58:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 22:58:55 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:58:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:58:55 --> Final output sent to browser
DEBUG - 2018-04-20 22:58:55 --> Total execution time: 0.5291
INFO - 2018-04-20 22:58:56 --> Config Class Initialized
INFO - 2018-04-20 22:58:56 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:58:56 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:58:56 --> Utf8 Class Initialized
INFO - 2018-04-20 22:58:56 --> URI Class Initialized
INFO - 2018-04-20 22:58:56 --> Router Class Initialized
INFO - 2018-04-20 22:58:56 --> Output Class Initialized
INFO - 2018-04-20 22:58:56 --> Security Class Initialized
DEBUG - 2018-04-20 22:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:58:56 --> CSRF cookie sent
INFO - 2018-04-20 22:58:56 --> Input Class Initialized
INFO - 2018-04-20 22:58:56 --> Language Class Initialized
ERROR - 2018-04-20 22:58:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 22:59:16 --> Config Class Initialized
INFO - 2018-04-20 22:59:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:59:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:59:16 --> Utf8 Class Initialized
INFO - 2018-04-20 22:59:16 --> URI Class Initialized
INFO - 2018-04-20 22:59:16 --> Router Class Initialized
INFO - 2018-04-20 22:59:16 --> Output Class Initialized
INFO - 2018-04-20 22:59:16 --> Security Class Initialized
DEBUG - 2018-04-20 22:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:59:16 --> CSRF cookie sent
INFO - 2018-04-20 22:59:16 --> CSRF token verified
INFO - 2018-04-20 22:59:16 --> Input Class Initialized
INFO - 2018-04-20 22:59:16 --> Language Class Initialized
INFO - 2018-04-20 22:59:16 --> Loader Class Initialized
INFO - 2018-04-20 22:59:16 --> Helper loaded: url_helper
INFO - 2018-04-20 22:59:16 --> Helper loaded: form_helper
INFO - 2018-04-20 22:59:16 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:59:16 --> User Agent Class Initialized
INFO - 2018-04-20 22:59:16 --> Controller Class Initialized
INFO - 2018-04-20 22:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:59:16 --> Form Validation Class Initialized
INFO - 2018-04-20 22:59:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 22:59:16 --> Pixel_Model class loaded
INFO - 2018-04-20 22:59:16 --> Database Driver Class Initialized
INFO - 2018-04-20 22:59:16 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 22:59:16 --> Helper loaded: string_helper
INFO - 2018-04-20 22:59:16 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 22:59:17 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 22:59:17 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 22:59:17 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 22:59:17 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 22:59:17 --> Email Class Initialized
ERROR - 2018-04-20 22:59:18 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 22:59:18 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-20 22:59:18 --> Config Class Initialized
INFO - 2018-04-20 22:59:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:59:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:59:18 --> Utf8 Class Initialized
INFO - 2018-04-20 22:59:18 --> URI Class Initialized
INFO - 2018-04-20 22:59:18 --> Router Class Initialized
INFO - 2018-04-20 22:59:18 --> Output Class Initialized
INFO - 2018-04-20 22:59:18 --> Security Class Initialized
DEBUG - 2018-04-20 22:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:59:18 --> CSRF cookie sent
INFO - 2018-04-20 22:59:18 --> Input Class Initialized
INFO - 2018-04-20 22:59:18 --> Language Class Initialized
INFO - 2018-04-20 22:59:18 --> Loader Class Initialized
INFO - 2018-04-20 22:59:18 --> Helper loaded: url_helper
INFO - 2018-04-20 22:59:18 --> Helper loaded: form_helper
INFO - 2018-04-20 22:59:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 22:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 22:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 22:59:18 --> User Agent Class Initialized
INFO - 2018-04-20 22:59:18 --> Controller Class Initialized
INFO - 2018-04-20 22:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 22:59:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 22:59:18 --> Pixel_Model class loaded
INFO - 2018-04-20 22:59:18 --> Database Driver Class Initialized
INFO - 2018-04-20 22:59:18 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-20 22:59:18 --> Could not find the language line "req_email"
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-20 22:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 22:59:18 --> Final output sent to browser
DEBUG - 2018-04-20 22:59:18 --> Total execution time: 0.5651
INFO - 2018-04-20 22:59:19 --> Config Class Initialized
INFO - 2018-04-20 22:59:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 22:59:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 22:59:19 --> Utf8 Class Initialized
INFO - 2018-04-20 22:59:19 --> URI Class Initialized
INFO - 2018-04-20 22:59:19 --> Router Class Initialized
INFO - 2018-04-20 22:59:19 --> Output Class Initialized
INFO - 2018-04-20 22:59:19 --> Security Class Initialized
DEBUG - 2018-04-20 22:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 22:59:19 --> CSRF cookie sent
INFO - 2018-04-20 22:59:19 --> Input Class Initialized
INFO - 2018-04-20 22:59:19 --> Language Class Initialized
ERROR - 2018-04-20 22:59:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:00:14 --> Config Class Initialized
INFO - 2018-04-20 23:00:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:14 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:14 --> URI Class Initialized
INFO - 2018-04-20 23:00:14 --> Router Class Initialized
INFO - 2018-04-20 23:00:14 --> Output Class Initialized
INFO - 2018-04-20 23:00:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:14 --> CSRF cookie sent
INFO - 2018-04-20 23:00:14 --> Input Class Initialized
INFO - 2018-04-20 23:00:14 --> Language Class Initialized
INFO - 2018-04-20 23:00:14 --> Loader Class Initialized
INFO - 2018-04-20 23:00:14 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:14 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:14 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:14 --> Controller Class Initialized
INFO - 2018-04-20 23:00:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:14 --> CSRF cookie sent
INFO - 2018-04-20 23:00:14 --> Config Class Initialized
INFO - 2018-04-20 23:00:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:14 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:14 --> URI Class Initialized
DEBUG - 2018-04-20 23:00:14 --> No URI present. Default controller set.
INFO - 2018-04-20 23:00:14 --> Router Class Initialized
INFO - 2018-04-20 23:00:14 --> Output Class Initialized
INFO - 2018-04-20 23:00:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:14 --> CSRF cookie sent
INFO - 2018-04-20 23:00:14 --> Input Class Initialized
INFO - 2018-04-20 23:00:14 --> Language Class Initialized
INFO - 2018-04-20 23:00:14 --> Loader Class Initialized
INFO - 2018-04-20 23:00:14 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:14 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:14 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:14 --> Controller Class Initialized
INFO - 2018-04-20 23:00:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:00:15 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:00:15 --> Final output sent to browser
DEBUG - 2018-04-20 23:00:15 --> Total execution time: 0.4284
INFO - 2018-04-20 23:00:15 --> Config Class Initialized
INFO - 2018-04-20 23:00:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:15 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:15 --> URI Class Initialized
INFO - 2018-04-20 23:00:15 --> Router Class Initialized
INFO - 2018-04-20 23:00:15 --> Output Class Initialized
INFO - 2018-04-20 23:00:15 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:15 --> CSRF cookie sent
INFO - 2018-04-20 23:00:15 --> Input Class Initialized
INFO - 2018-04-20 23:00:15 --> Language Class Initialized
ERROR - 2018-04-20 23:00:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:00:17 --> Config Class Initialized
INFO - 2018-04-20 23:00:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:17 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:17 --> URI Class Initialized
INFO - 2018-04-20 23:00:17 --> Router Class Initialized
INFO - 2018-04-20 23:00:17 --> Output Class Initialized
INFO - 2018-04-20 23:00:17 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:17 --> CSRF cookie sent
INFO - 2018-04-20 23:00:17 --> Input Class Initialized
INFO - 2018-04-20 23:00:17 --> Language Class Initialized
ERROR - 2018-04-20 23:00:17 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:00:25 --> Config Class Initialized
INFO - 2018-04-20 23:00:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:25 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:25 --> URI Class Initialized
INFO - 2018-04-20 23:00:25 --> Router Class Initialized
INFO - 2018-04-20 23:00:26 --> Output Class Initialized
INFO - 2018-04-20 23:00:26 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:26 --> CSRF cookie sent
INFO - 2018-04-20 23:00:26 --> Input Class Initialized
INFO - 2018-04-20 23:00:26 --> Language Class Initialized
INFO - 2018-04-20 23:00:26 --> Loader Class Initialized
INFO - 2018-04-20 23:00:26 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:26 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:26 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:26 --> Controller Class Initialized
INFO - 2018-04-20 23:00:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:26 --> Pixel_Model class loaded
INFO - 2018-04-20 23:00:26 --> Database Driver Class Initialized
INFO - 2018-04-20 23:00:26 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-20 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:00:26 --> Final output sent to browser
DEBUG - 2018-04-20 23:00:26 --> Total execution time: 0.5551
INFO - 2018-04-20 23:00:26 --> Config Class Initialized
INFO - 2018-04-20 23:00:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:26 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:26 --> URI Class Initialized
INFO - 2018-04-20 23:00:26 --> Router Class Initialized
INFO - 2018-04-20 23:00:26 --> Output Class Initialized
INFO - 2018-04-20 23:00:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:27 --> CSRF cookie sent
INFO - 2018-04-20 23:00:27 --> Input Class Initialized
INFO - 2018-04-20 23:00:27 --> Language Class Initialized
ERROR - 2018-04-20 23:00:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:00:48 --> Config Class Initialized
INFO - 2018-04-20 23:00:48 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:48 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:48 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:48 --> URI Class Initialized
INFO - 2018-04-20 23:00:48 --> Router Class Initialized
INFO - 2018-04-20 23:00:48 --> Output Class Initialized
INFO - 2018-04-20 23:00:48 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:48 --> CSRF cookie sent
INFO - 2018-04-20 23:00:48 --> Input Class Initialized
INFO - 2018-04-20 23:00:48 --> Language Class Initialized
INFO - 2018-04-20 23:00:48 --> Loader Class Initialized
INFO - 2018-04-20 23:00:48 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:48 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:48 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:48 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:48 --> Controller Class Initialized
INFO - 2018-04-20 23:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:48 --> Pixel_Model class loaded
INFO - 2018-04-20 23:00:48 --> Database Driver Class Initialized
INFO - 2018-04-20 23:00:48 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-20 23:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:00:48 --> Final output sent to browser
DEBUG - 2018-04-20 23:00:48 --> Total execution time: 0.6269
INFO - 2018-04-20 23:00:49 --> Config Class Initialized
INFO - 2018-04-20 23:00:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:49 --> URI Class Initialized
INFO - 2018-04-20 23:00:49 --> Router Class Initialized
INFO - 2018-04-20 23:00:49 --> Output Class Initialized
INFO - 2018-04-20 23:00:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:49 --> CSRF cookie sent
INFO - 2018-04-20 23:00:49 --> Input Class Initialized
INFO - 2018-04-20 23:00:49 --> Language Class Initialized
ERROR - 2018-04-20 23:00:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:00:58 --> Config Class Initialized
INFO - 2018-04-20 23:00:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:58 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:58 --> URI Class Initialized
INFO - 2018-04-20 23:00:58 --> Router Class Initialized
INFO - 2018-04-20 23:00:58 --> Output Class Initialized
INFO - 2018-04-20 23:00:58 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:58 --> CSRF cookie sent
INFO - 2018-04-20 23:00:58 --> CSRF token verified
INFO - 2018-04-20 23:00:58 --> Input Class Initialized
INFO - 2018-04-20 23:00:59 --> Language Class Initialized
INFO - 2018-04-20 23:00:59 --> Loader Class Initialized
INFO - 2018-04-20 23:00:59 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:59 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:59 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:59 --> Controller Class Initialized
INFO - 2018-04-20 23:00:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:59 --> Pixel_Model class loaded
INFO - 2018-04-20 23:00:59 --> Database Driver Class Initialized
INFO - 2018-04-20 23:00:59 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:00:59 --> Form Validation Class Initialized
INFO - 2018-04-20 23:00:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:00:59 --> Config Class Initialized
INFO - 2018-04-20 23:00:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:00:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:00:59 --> Utf8 Class Initialized
INFO - 2018-04-20 23:00:59 --> URI Class Initialized
DEBUG - 2018-04-20 23:00:59 --> No URI present. Default controller set.
INFO - 2018-04-20 23:00:59 --> Router Class Initialized
INFO - 2018-04-20 23:00:59 --> Output Class Initialized
INFO - 2018-04-20 23:00:59 --> Security Class Initialized
DEBUG - 2018-04-20 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:00:59 --> CSRF cookie sent
INFO - 2018-04-20 23:00:59 --> Input Class Initialized
INFO - 2018-04-20 23:00:59 --> Language Class Initialized
INFO - 2018-04-20 23:00:59 --> Loader Class Initialized
INFO - 2018-04-20 23:00:59 --> Helper loaded: url_helper
INFO - 2018-04-20 23:00:59 --> Helper loaded: form_helper
INFO - 2018-04-20 23:00:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:00:59 --> User Agent Class Initialized
INFO - 2018-04-20 23:00:59 --> Controller Class Initialized
INFO - 2018-04-20 23:00:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:00:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:00:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:00:59 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:00:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:00:59 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:00:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:00:59 --> Final output sent to browser
DEBUG - 2018-04-20 23:01:00 --> Total execution time: 0.4502
INFO - 2018-04-20 23:01:00 --> Config Class Initialized
INFO - 2018-04-20 23:01:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:00 --> URI Class Initialized
INFO - 2018-04-20 23:01:00 --> Router Class Initialized
INFO - 2018-04-20 23:01:00 --> Output Class Initialized
INFO - 2018-04-20 23:01:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:00 --> CSRF cookie sent
INFO - 2018-04-20 23:01:00 --> Input Class Initialized
INFO - 2018-04-20 23:01:00 --> Language Class Initialized
ERROR - 2018-04-20 23:01:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:01:01 --> Config Class Initialized
INFO - 2018-04-20 23:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:02 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:02 --> URI Class Initialized
INFO - 2018-04-20 23:01:02 --> Router Class Initialized
INFO - 2018-04-20 23:01:02 --> Output Class Initialized
INFO - 2018-04-20 23:01:02 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:02 --> CSRF cookie sent
INFO - 2018-04-20 23:01:02 --> Input Class Initialized
INFO - 2018-04-20 23:01:02 --> Language Class Initialized
ERROR - 2018-04-20 23:01:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:01:04 --> Config Class Initialized
INFO - 2018-04-20 23:01:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:04 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:04 --> URI Class Initialized
INFO - 2018-04-20 23:01:04 --> Router Class Initialized
INFO - 2018-04-20 23:01:04 --> Output Class Initialized
INFO - 2018-04-20 23:01:04 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:04 --> CSRF cookie sent
INFO - 2018-04-20 23:01:04 --> Input Class Initialized
INFO - 2018-04-20 23:01:04 --> Language Class Initialized
INFO - 2018-04-20 23:01:04 --> Loader Class Initialized
INFO - 2018-04-20 23:01:04 --> Helper loaded: url_helper
INFO - 2018-04-20 23:01:04 --> Helper loaded: form_helper
INFO - 2018-04-20 23:01:04 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:01:04 --> User Agent Class Initialized
INFO - 2018-04-20 23:01:05 --> Controller Class Initialized
INFO - 2018-04-20 23:01:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:01:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:01:05 --> Pixel_Model class loaded
INFO - 2018-04-20 23:01:05 --> Database Driver Class Initialized
INFO - 2018-04-20 23:01:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-20 23:01:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:01:05 --> Final output sent to browser
DEBUG - 2018-04-20 23:01:05 --> Total execution time: 0.5411
INFO - 2018-04-20 23:01:05 --> Config Class Initialized
INFO - 2018-04-20 23:01:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:05 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:05 --> URI Class Initialized
INFO - 2018-04-20 23:01:05 --> Router Class Initialized
INFO - 2018-04-20 23:01:05 --> Output Class Initialized
INFO - 2018-04-20 23:01:05 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:05 --> CSRF cookie sent
INFO - 2018-04-20 23:01:05 --> Input Class Initialized
INFO - 2018-04-20 23:01:05 --> Language Class Initialized
ERROR - 2018-04-20 23:01:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:01:15 --> Config Class Initialized
INFO - 2018-04-20 23:01:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:15 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:15 --> URI Class Initialized
INFO - 2018-04-20 23:01:15 --> Router Class Initialized
INFO - 2018-04-20 23:01:15 --> Output Class Initialized
INFO - 2018-04-20 23:01:15 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:15 --> CSRF cookie sent
INFO - 2018-04-20 23:01:15 --> Input Class Initialized
INFO - 2018-04-20 23:01:15 --> Language Class Initialized
INFO - 2018-04-20 23:01:15 --> Loader Class Initialized
INFO - 2018-04-20 23:01:15 --> Helper loaded: url_helper
INFO - 2018-04-20 23:01:15 --> Helper loaded: form_helper
INFO - 2018-04-20 23:01:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:01:15 --> User Agent Class Initialized
INFO - 2018-04-20 23:01:15 --> Controller Class Initialized
INFO - 2018-04-20 23:01:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:01:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:01:15 --> Pixel_Model class loaded
INFO - 2018-04-20 23:01:15 --> Database Driver Class Initialized
INFO - 2018-04-20 23:01:15 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:01:15 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:01:15 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-20 23:01:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:01:16 --> Final output sent to browser
DEBUG - 2018-04-20 23:01:16 --> Total execution time: 0.6230
INFO - 2018-04-20 23:01:16 --> Config Class Initialized
INFO - 2018-04-20 23:01:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:16 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:16 --> URI Class Initialized
INFO - 2018-04-20 23:01:16 --> Router Class Initialized
INFO - 2018-04-20 23:01:16 --> Output Class Initialized
INFO - 2018-04-20 23:01:16 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:16 --> CSRF cookie sent
INFO - 2018-04-20 23:01:16 --> Input Class Initialized
INFO - 2018-04-20 23:01:16 --> Language Class Initialized
ERROR - 2018-04-20 23:01:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:01:49 --> Config Class Initialized
INFO - 2018-04-20 23:01:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:49 --> URI Class Initialized
INFO - 2018-04-20 23:01:49 --> Router Class Initialized
INFO - 2018-04-20 23:01:49 --> Output Class Initialized
INFO - 2018-04-20 23:01:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:49 --> CSRF cookie sent
INFO - 2018-04-20 23:01:49 --> Input Class Initialized
INFO - 2018-04-20 23:01:49 --> Language Class Initialized
INFO - 2018-04-20 23:01:49 --> Loader Class Initialized
INFO - 2018-04-20 23:01:49 --> Helper loaded: url_helper
INFO - 2018-04-20 23:01:49 --> Helper loaded: form_helper
INFO - 2018-04-20 23:01:49 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:01:49 --> User Agent Class Initialized
INFO - 2018-04-20 23:01:49 --> Controller Class Initialized
INFO - 2018-04-20 23:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:01:49 --> Pixel_Model class loaded
INFO - 2018-04-20 23:01:49 --> Database Driver Class Initialized
INFO - 2018-04-20 23:01:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:01:49 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-20 23:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:01:49 --> Final output sent to browser
DEBUG - 2018-04-20 23:01:49 --> Total execution time: 0.5654
INFO - 2018-04-20 23:01:50 --> Config Class Initialized
INFO - 2018-04-20 23:01:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:01:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:01:50 --> Utf8 Class Initialized
INFO - 2018-04-20 23:01:50 --> URI Class Initialized
INFO - 2018-04-20 23:01:50 --> Router Class Initialized
INFO - 2018-04-20 23:01:50 --> Output Class Initialized
INFO - 2018-04-20 23:01:50 --> Security Class Initialized
DEBUG - 2018-04-20 23:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:01:50 --> CSRF cookie sent
INFO - 2018-04-20 23:01:50 --> Input Class Initialized
INFO - 2018-04-20 23:01:50 --> Language Class Initialized
ERROR - 2018-04-20 23:01:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:02:08 --> Config Class Initialized
INFO - 2018-04-20 23:02:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:02:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:02:08 --> Utf8 Class Initialized
INFO - 2018-04-20 23:02:08 --> URI Class Initialized
INFO - 2018-04-20 23:02:08 --> Router Class Initialized
INFO - 2018-04-20 23:02:08 --> Output Class Initialized
INFO - 2018-04-20 23:02:08 --> Security Class Initialized
DEBUG - 2018-04-20 23:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:02:08 --> CSRF cookie sent
INFO - 2018-04-20 23:02:08 --> CSRF token verified
INFO - 2018-04-20 23:02:08 --> Input Class Initialized
INFO - 2018-04-20 23:02:08 --> Language Class Initialized
INFO - 2018-04-20 23:02:08 --> Loader Class Initialized
INFO - 2018-04-20 23:02:08 --> Helper loaded: url_helper
INFO - 2018-04-20 23:02:08 --> Helper loaded: form_helper
INFO - 2018-04-20 23:02:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:02:09 --> User Agent Class Initialized
INFO - 2018-04-20 23:02:09 --> Controller Class Initialized
INFO - 2018-04-20 23:02:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:02:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:02:09 --> Form Validation Class Initialized
INFO - 2018-04-20 23:02:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:02:09 --> Pixel_Model class loaded
INFO - 2018-04-20 23:02:09 --> Database Driver Class Initialized
INFO - 2018-04-20 23:02:09 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:02:09 --> Helper loaded: string_helper
INFO - 2018-04-20 23:02:09 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 23:02:09 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 23:02:09 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 23:02:09 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 23:02:09 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 23:02:09 --> Email Class Initialized
ERROR - 2018-04-20 23:02:10 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 23:02:10 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-20 23:02:10 --> Config Class Initialized
INFO - 2018-04-20 23:02:10 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:02:10 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:02:10 --> Utf8 Class Initialized
INFO - 2018-04-20 23:02:10 --> URI Class Initialized
INFO - 2018-04-20 23:02:10 --> Router Class Initialized
INFO - 2018-04-20 23:02:10 --> Output Class Initialized
INFO - 2018-04-20 23:02:10 --> Security Class Initialized
DEBUG - 2018-04-20 23:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:02:10 --> CSRF cookie sent
INFO - 2018-04-20 23:02:10 --> Input Class Initialized
INFO - 2018-04-20 23:02:10 --> Language Class Initialized
INFO - 2018-04-20 23:02:10 --> Loader Class Initialized
INFO - 2018-04-20 23:02:10 --> Helper loaded: url_helper
INFO - 2018-04-20 23:02:10 --> Helper loaded: form_helper
INFO - 2018-04-20 23:02:10 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:02:10 --> User Agent Class Initialized
INFO - 2018-04-20 23:02:10 --> Controller Class Initialized
INFO - 2018-04-20 23:02:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:02:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:02:10 --> Pixel_Model class loaded
INFO - 2018-04-20 23:02:10 --> Database Driver Class Initialized
INFO - 2018-04-20 23:02:10 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-20 23:02:11 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-20 23:02:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:02:11 --> Final output sent to browser
DEBUG - 2018-04-20 23:02:11 --> Total execution time: 0.5628
INFO - 2018-04-20 23:02:11 --> Config Class Initialized
INFO - 2018-04-20 23:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:02:11 --> Utf8 Class Initialized
INFO - 2018-04-20 23:02:11 --> URI Class Initialized
INFO - 2018-04-20 23:02:11 --> Router Class Initialized
INFO - 2018-04-20 23:02:11 --> Output Class Initialized
INFO - 2018-04-20 23:02:11 --> Security Class Initialized
DEBUG - 2018-04-20 23:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:02:11 --> CSRF cookie sent
INFO - 2018-04-20 23:02:11 --> Input Class Initialized
INFO - 2018-04-20 23:02:11 --> Language Class Initialized
ERROR - 2018-04-20 23:02:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:02:17 --> Config Class Initialized
INFO - 2018-04-20 23:02:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:02:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:02:17 --> Utf8 Class Initialized
INFO - 2018-04-20 23:02:17 --> URI Class Initialized
INFO - 2018-04-20 23:02:17 --> Router Class Initialized
INFO - 2018-04-20 23:02:17 --> Output Class Initialized
INFO - 2018-04-20 23:02:17 --> Security Class Initialized
DEBUG - 2018-04-20 23:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:02:17 --> CSRF cookie sent
INFO - 2018-04-20 23:02:17 --> Input Class Initialized
INFO - 2018-04-20 23:02:17 --> Language Class Initialized
INFO - 2018-04-20 23:02:17 --> Loader Class Initialized
INFO - 2018-04-20 23:02:17 --> Helper loaded: url_helper
INFO - 2018-04-20 23:02:17 --> Helper loaded: form_helper
INFO - 2018-04-20 23:02:17 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:02:17 --> User Agent Class Initialized
INFO - 2018-04-20 23:02:17 --> Controller Class Initialized
INFO - 2018-04-20 23:02:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:02:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:02:17 --> Pixel_Model class loaded
INFO - 2018-04-20 23:02:17 --> Database Driver Class Initialized
INFO - 2018-04-20 23:02:17 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-20 23:02:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:02:17 --> Final output sent to browser
DEBUG - 2018-04-20 23:02:17 --> Total execution time: 0.5583
INFO - 2018-04-20 23:02:18 --> Config Class Initialized
INFO - 2018-04-20 23:02:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:02:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:02:18 --> Utf8 Class Initialized
INFO - 2018-04-20 23:02:18 --> URI Class Initialized
INFO - 2018-04-20 23:02:18 --> Router Class Initialized
INFO - 2018-04-20 23:02:18 --> Output Class Initialized
INFO - 2018-04-20 23:02:18 --> Security Class Initialized
DEBUG - 2018-04-20 23:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:02:18 --> CSRF cookie sent
INFO - 2018-04-20 23:02:18 --> Input Class Initialized
INFO - 2018-04-20 23:02:18 --> Language Class Initialized
ERROR - 2018-04-20 23:02:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:03:28 --> Config Class Initialized
INFO - 2018-04-20 23:03:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:03:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:03:28 --> Utf8 Class Initialized
INFO - 2018-04-20 23:03:28 --> URI Class Initialized
INFO - 2018-04-20 23:03:28 --> Router Class Initialized
INFO - 2018-04-20 23:03:28 --> Output Class Initialized
INFO - 2018-04-20 23:03:28 --> Security Class Initialized
DEBUG - 2018-04-20 23:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:03:28 --> CSRF cookie sent
INFO - 2018-04-20 23:03:28 --> CSRF token verified
INFO - 2018-04-20 23:03:28 --> Input Class Initialized
INFO - 2018-04-20 23:03:28 --> Language Class Initialized
INFO - 2018-04-20 23:03:28 --> Loader Class Initialized
INFO - 2018-04-20 23:03:28 --> Helper loaded: url_helper
INFO - 2018-04-20 23:03:28 --> Helper loaded: form_helper
INFO - 2018-04-20 23:03:28 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:03:28 --> User Agent Class Initialized
INFO - 2018-04-20 23:03:28 --> Controller Class Initialized
INFO - 2018-04-20 23:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:03:28 --> Upload Class Initialized
INFO - 2018-04-20 23:03:28 --> Pixel_Model class loaded
INFO - 2018-04-20 23:03:28 --> Database Driver Class Initialized
INFO - 2018-04-20 23:03:28 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:03:28 --> Database Driver Class Initialized
INFO - 2018-04-20 23:03:28 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:03:28 --> Helper loaded: string_helper
INFO - 2018-04-20 23:03:28 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-20 23:03:28 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 23:03:28 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 23:03:28 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 23:03:28 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-20 23:03:29 --> Email Class Initialized
ERROR - 2018-04-20 23:03:30 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 23:03:30 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-04-20 23:03:30 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 23:03:30 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 23:03:30 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 23:03:30 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 23:03:30 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 23:03:30 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-20 23:03:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
DEBUG - 2018-04-20 23:03:31 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-20 23:03:31 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-20 23:03:31 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-20 23:03:31 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-20 23:03:31 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-20 23:03:32 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-20 23:03:33 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-20 23:03:33 --> Config Class Initialized
INFO - 2018-04-20 23:03:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:03:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:03:33 --> Utf8 Class Initialized
INFO - 2018-04-20 23:03:33 --> URI Class Initialized
INFO - 2018-04-20 23:03:33 --> Router Class Initialized
INFO - 2018-04-20 23:03:33 --> Output Class Initialized
INFO - 2018-04-20 23:03:33 --> Security Class Initialized
DEBUG - 2018-04-20 23:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:03:33 --> CSRF cookie sent
INFO - 2018-04-20 23:03:33 --> Input Class Initialized
INFO - 2018-04-20 23:03:33 --> Language Class Initialized
INFO - 2018-04-20 23:03:33 --> Loader Class Initialized
INFO - 2018-04-20 23:03:33 --> Helper loaded: url_helper
INFO - 2018-04-20 23:03:33 --> Helper loaded: form_helper
INFO - 2018-04-20 23:03:33 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:03:33 --> User Agent Class Initialized
INFO - 2018-04-20 23:03:33 --> Controller Class Initialized
INFO - 2018-04-20 23:03:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:03:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:03:33 --> Pixel_Model class loaded
INFO - 2018-04-20 23:03:33 --> Database Driver Class Initialized
INFO - 2018-04-20 23:03:33 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-20 23:03:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:03:33 --> Final output sent to browser
DEBUG - 2018-04-20 23:03:33 --> Total execution time: 0.5662
INFO - 2018-04-20 23:03:34 --> Config Class Initialized
INFO - 2018-04-20 23:03:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:03:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:03:34 --> Utf8 Class Initialized
INFO - 2018-04-20 23:03:34 --> URI Class Initialized
INFO - 2018-04-20 23:03:34 --> Router Class Initialized
INFO - 2018-04-20 23:03:34 --> Output Class Initialized
INFO - 2018-04-20 23:03:34 --> Security Class Initialized
DEBUG - 2018-04-20 23:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:03:34 --> CSRF cookie sent
INFO - 2018-04-20 23:03:34 --> Input Class Initialized
INFO - 2018-04-20 23:03:34 --> Language Class Initialized
ERROR - 2018-04-20 23:03:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:06:18 --> Config Class Initialized
INFO - 2018-04-20 23:06:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:18 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:18 --> URI Class Initialized
INFO - 2018-04-20 23:06:18 --> Router Class Initialized
INFO - 2018-04-20 23:06:18 --> Output Class Initialized
INFO - 2018-04-20 23:06:18 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:18 --> CSRF cookie sent
INFO - 2018-04-20 23:06:18 --> Input Class Initialized
INFO - 2018-04-20 23:06:18 --> Language Class Initialized
INFO - 2018-04-20 23:06:18 --> Loader Class Initialized
INFO - 2018-04-20 23:06:18 --> Helper loaded: url_helper
INFO - 2018-04-20 23:06:18 --> Helper loaded: form_helper
INFO - 2018-04-20 23:06:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:06:19 --> User Agent Class Initialized
INFO - 2018-04-20 23:06:19 --> Controller Class Initialized
INFO - 2018-04-20 23:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:06:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:06:19 --> CSRF cookie sent
INFO - 2018-04-20 23:06:19 --> Config Class Initialized
INFO - 2018-04-20 23:06:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:19 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:19 --> URI Class Initialized
DEBUG - 2018-04-20 23:06:19 --> No URI present. Default controller set.
INFO - 2018-04-20 23:06:19 --> Router Class Initialized
INFO - 2018-04-20 23:06:19 --> Output Class Initialized
INFO - 2018-04-20 23:06:19 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:19 --> CSRF cookie sent
INFO - 2018-04-20 23:06:19 --> Input Class Initialized
INFO - 2018-04-20 23:06:19 --> Language Class Initialized
INFO - 2018-04-20 23:06:19 --> Loader Class Initialized
INFO - 2018-04-20 23:06:19 --> Helper loaded: url_helper
INFO - 2018-04-20 23:06:19 --> Helper loaded: form_helper
INFO - 2018-04-20 23:06:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:06:19 --> User Agent Class Initialized
INFO - 2018-04-20 23:06:19 --> Controller Class Initialized
INFO - 2018-04-20 23:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:06:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:06:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:06:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:06:19 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:06:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:06:19 --> Final output sent to browser
DEBUG - 2018-04-20 23:06:19 --> Total execution time: 0.4718
INFO - 2018-04-20 23:06:19 --> Config Class Initialized
INFO - 2018-04-20 23:06:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:20 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:20 --> URI Class Initialized
INFO - 2018-04-20 23:06:20 --> Router Class Initialized
INFO - 2018-04-20 23:06:20 --> Output Class Initialized
INFO - 2018-04-20 23:06:20 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:20 --> CSRF cookie sent
INFO - 2018-04-20 23:06:20 --> Input Class Initialized
INFO - 2018-04-20 23:06:20 --> Language Class Initialized
ERROR - 2018-04-20 23:06:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:06:21 --> Config Class Initialized
INFO - 2018-04-20 23:06:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:21 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:21 --> URI Class Initialized
INFO - 2018-04-20 23:06:21 --> Router Class Initialized
INFO - 2018-04-20 23:06:21 --> Output Class Initialized
INFO - 2018-04-20 23:06:21 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:22 --> CSRF cookie sent
INFO - 2018-04-20 23:06:22 --> Input Class Initialized
INFO - 2018-04-20 23:06:22 --> Language Class Initialized
ERROR - 2018-04-20 23:06:22 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:06:25 --> Config Class Initialized
INFO - 2018-04-20 23:06:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:25 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:25 --> URI Class Initialized
INFO - 2018-04-20 23:06:25 --> Router Class Initialized
INFO - 2018-04-20 23:06:25 --> Output Class Initialized
INFO - 2018-04-20 23:06:25 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:25 --> CSRF cookie sent
INFO - 2018-04-20 23:06:25 --> Input Class Initialized
INFO - 2018-04-20 23:06:25 --> Language Class Initialized
INFO - 2018-04-20 23:06:25 --> Loader Class Initialized
INFO - 2018-04-20 23:06:25 --> Helper loaded: url_helper
INFO - 2018-04-20 23:06:25 --> Helper loaded: form_helper
INFO - 2018-04-20 23:06:25 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:06:25 --> User Agent Class Initialized
INFO - 2018-04-20 23:06:25 --> Controller Class Initialized
INFO - 2018-04-20 23:06:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:06:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:06:25 --> Pixel_Model class loaded
INFO - 2018-04-20 23:06:25 --> Database Driver Class Initialized
INFO - 2018-04-20 23:06:25 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:06:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:06:26 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-20 23:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:06:26 --> Final output sent to browser
DEBUG - 2018-04-20 23:06:26 --> Total execution time: 0.6077
INFO - 2018-04-20 23:06:26 --> Config Class Initialized
INFO - 2018-04-20 23:06:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:06:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:06:26 --> Utf8 Class Initialized
INFO - 2018-04-20 23:06:26 --> URI Class Initialized
INFO - 2018-04-20 23:06:26 --> Router Class Initialized
INFO - 2018-04-20 23:06:26 --> Output Class Initialized
INFO - 2018-04-20 23:06:26 --> Security Class Initialized
DEBUG - 2018-04-20 23:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:06:26 --> CSRF cookie sent
INFO - 2018-04-20 23:06:26 --> Input Class Initialized
INFO - 2018-04-20 23:06:26 --> Language Class Initialized
ERROR - 2018-04-20 23:06:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:07:43 --> Config Class Initialized
INFO - 2018-04-20 23:07:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:43 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:43 --> URI Class Initialized
INFO - 2018-04-20 23:07:43 --> Router Class Initialized
INFO - 2018-04-20 23:07:43 --> Output Class Initialized
INFO - 2018-04-20 23:07:43 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:43 --> CSRF cookie sent
INFO - 2018-04-20 23:07:43 --> Input Class Initialized
INFO - 2018-04-20 23:07:43 --> Language Class Initialized
INFO - 2018-04-20 23:07:43 --> Loader Class Initialized
INFO - 2018-04-20 23:07:43 --> Helper loaded: url_helper
INFO - 2018-04-20 23:07:43 --> Helper loaded: form_helper
INFO - 2018-04-20 23:07:43 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:07:43 --> User Agent Class Initialized
INFO - 2018-04-20 23:07:43 --> Controller Class Initialized
INFO - 2018-04-20 23:07:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:07:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:07:43 --> Pixel_Model class loaded
INFO - 2018-04-20 23:07:43 --> Database Driver Class Initialized
INFO - 2018-04-20 23:07:43 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-20 23:07:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:07:43 --> Final output sent to browser
DEBUG - 2018-04-20 23:07:43 --> Total execution time: 0.5572
INFO - 2018-04-20 23:07:43 --> Config Class Initialized
INFO - 2018-04-20 23:07:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:44 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:44 --> URI Class Initialized
INFO - 2018-04-20 23:07:44 --> Router Class Initialized
INFO - 2018-04-20 23:07:44 --> Output Class Initialized
INFO - 2018-04-20 23:07:44 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:44 --> CSRF cookie sent
INFO - 2018-04-20 23:07:44 --> Input Class Initialized
INFO - 2018-04-20 23:07:44 --> Language Class Initialized
ERROR - 2018-04-20 23:07:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:07:50 --> Config Class Initialized
INFO - 2018-04-20 23:07:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:50 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:50 --> URI Class Initialized
INFO - 2018-04-20 23:07:50 --> Router Class Initialized
INFO - 2018-04-20 23:07:50 --> Output Class Initialized
INFO - 2018-04-20 23:07:50 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:50 --> CSRF cookie sent
INFO - 2018-04-20 23:07:51 --> Input Class Initialized
INFO - 2018-04-20 23:07:51 --> Language Class Initialized
INFO - 2018-04-20 23:07:51 --> Loader Class Initialized
INFO - 2018-04-20 23:07:51 --> Helper loaded: url_helper
INFO - 2018-04-20 23:07:51 --> Helper loaded: form_helper
INFO - 2018-04-20 23:07:51 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:07:51 --> User Agent Class Initialized
INFO - 2018-04-20 23:07:51 --> Controller Class Initialized
INFO - 2018-04-20 23:07:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:07:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:07:51 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:07:51 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 23:07:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:07:51 --> Final output sent to browser
DEBUG - 2018-04-20 23:07:51 --> Total execution time: 0.6800
INFO - 2018-04-20 23:07:51 --> Config Class Initialized
INFO - 2018-04-20 23:07:51 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:51 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:51 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:51 --> URI Class Initialized
INFO - 2018-04-20 23:07:52 --> Router Class Initialized
INFO - 2018-04-20 23:07:52 --> Output Class Initialized
INFO - 2018-04-20 23:07:52 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:52 --> CSRF cookie sent
INFO - 2018-04-20 23:07:52 --> Input Class Initialized
INFO - 2018-04-20 23:07:52 --> Language Class Initialized
ERROR - 2018-04-20 23:07:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:07:57 --> Config Class Initialized
INFO - 2018-04-20 23:07:57 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:57 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:57 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:57 --> URI Class Initialized
INFO - 2018-04-20 23:07:57 --> Router Class Initialized
INFO - 2018-04-20 23:07:57 --> Output Class Initialized
INFO - 2018-04-20 23:07:57 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:57 --> CSRF cookie sent
INFO - 2018-04-20 23:07:57 --> Input Class Initialized
INFO - 2018-04-20 23:07:57 --> Language Class Initialized
INFO - 2018-04-20 23:07:57 --> Loader Class Initialized
INFO - 2018-04-20 23:07:57 --> Helper loaded: url_helper
INFO - 2018-04-20 23:07:57 --> Helper loaded: form_helper
INFO - 2018-04-20 23:07:57 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:07:57 --> User Agent Class Initialized
INFO - 2018-04-20 23:07:57 --> Controller Class Initialized
INFO - 2018-04-20 23:07:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:07:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:07:57 --> Pixel_Model class loaded
INFO - 2018-04-20 23:07:57 --> Database Driver Class Initialized
INFO - 2018-04-20 23:07:57 --> Model "RegistrationModel" initialized
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-20 23:07:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:07:58 --> Final output sent to browser
DEBUG - 2018-04-20 23:07:58 --> Total execution time: 0.5950
INFO - 2018-04-20 23:07:58 --> Config Class Initialized
INFO - 2018-04-20 23:07:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:07:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:07:58 --> Utf8 Class Initialized
INFO - 2018-04-20 23:07:58 --> URI Class Initialized
INFO - 2018-04-20 23:07:58 --> Router Class Initialized
INFO - 2018-04-20 23:07:58 --> Output Class Initialized
INFO - 2018-04-20 23:07:58 --> Security Class Initialized
DEBUG - 2018-04-20 23:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:07:58 --> CSRF cookie sent
INFO - 2018-04-20 23:07:58 --> Input Class Initialized
INFO - 2018-04-20 23:07:58 --> Language Class Initialized
ERROR - 2018-04-20 23:07:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:08:00 --> Config Class Initialized
INFO - 2018-04-20 23:08:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:00 --> URI Class Initialized
INFO - 2018-04-20 23:08:00 --> Router Class Initialized
INFO - 2018-04-20 23:08:00 --> Output Class Initialized
INFO - 2018-04-20 23:08:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:00 --> CSRF cookie sent
INFO - 2018-04-20 23:08:00 --> Input Class Initialized
INFO - 2018-04-20 23:08:00 --> Language Class Initialized
INFO - 2018-04-20 23:08:00 --> Loader Class Initialized
INFO - 2018-04-20 23:08:00 --> Helper loaded: url_helper
INFO - 2018-04-20 23:08:00 --> Helper loaded: form_helper
INFO - 2018-04-20 23:08:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:08:00 --> User Agent Class Initialized
INFO - 2018-04-20 23:08:00 --> Controller Class Initialized
INFO - 2018-04-20 23:08:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:08:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:08:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:08:00 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 23:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:08:00 --> Final output sent to browser
DEBUG - 2018-04-20 23:08:00 --> Total execution time: 0.5125
INFO - 2018-04-20 23:08:00 --> Config Class Initialized
INFO - 2018-04-20 23:08:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:01 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:01 --> URI Class Initialized
INFO - 2018-04-20 23:08:01 --> Router Class Initialized
INFO - 2018-04-20 23:08:01 --> Output Class Initialized
INFO - 2018-04-20 23:08:01 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:01 --> CSRF cookie sent
INFO - 2018-04-20 23:08:01 --> Input Class Initialized
INFO - 2018-04-20 23:08:01 --> Language Class Initialized
ERROR - 2018-04-20 23:08:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:08:45 --> Config Class Initialized
INFO - 2018-04-20 23:08:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:45 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:45 --> URI Class Initialized
INFO - 2018-04-20 23:08:45 --> Router Class Initialized
INFO - 2018-04-20 23:08:45 --> Output Class Initialized
INFO - 2018-04-20 23:08:45 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:45 --> CSRF cookie sent
INFO - 2018-04-20 23:08:45 --> Input Class Initialized
INFO - 2018-04-20 23:08:45 --> Language Class Initialized
INFO - 2018-04-20 23:08:45 --> Loader Class Initialized
INFO - 2018-04-20 23:08:45 --> Helper loaded: url_helper
INFO - 2018-04-20 23:08:45 --> Helper loaded: form_helper
INFO - 2018-04-20 23:08:45 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:08:45 --> User Agent Class Initialized
INFO - 2018-04-20 23:08:45 --> Controller Class Initialized
INFO - 2018-04-20 23:08:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:08:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:08:45 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:08:45 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 23:08:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:08:45 --> Final output sent to browser
DEBUG - 2018-04-20 23:08:45 --> Total execution time: 0.5464
INFO - 2018-04-20 23:08:46 --> Config Class Initialized
INFO - 2018-04-20 23:08:46 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:46 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:46 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:46 --> URI Class Initialized
INFO - 2018-04-20 23:08:46 --> Router Class Initialized
INFO - 2018-04-20 23:08:46 --> Output Class Initialized
INFO - 2018-04-20 23:08:46 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:46 --> CSRF cookie sent
INFO - 2018-04-20 23:08:46 --> Input Class Initialized
INFO - 2018-04-20 23:08:46 --> Language Class Initialized
ERROR - 2018-04-20 23:08:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:08:58 --> Config Class Initialized
INFO - 2018-04-20 23:08:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:58 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:58 --> URI Class Initialized
INFO - 2018-04-20 23:08:58 --> Router Class Initialized
INFO - 2018-04-20 23:08:58 --> Output Class Initialized
INFO - 2018-04-20 23:08:58 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:58 --> CSRF cookie sent
INFO - 2018-04-20 23:08:58 --> Input Class Initialized
INFO - 2018-04-20 23:08:58 --> Language Class Initialized
INFO - 2018-04-20 23:08:58 --> Loader Class Initialized
INFO - 2018-04-20 23:08:58 --> Helper loaded: url_helper
INFO - 2018-04-20 23:08:58 --> Helper loaded: form_helper
INFO - 2018-04-20 23:08:58 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:08:58 --> User Agent Class Initialized
INFO - 2018-04-20 23:08:58 --> Controller Class Initialized
INFO - 2018-04-20 23:08:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:08:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:08:58 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:08:58 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-20 23:08:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:08:58 --> Final output sent to browser
DEBUG - 2018-04-20 23:08:58 --> Total execution time: 0.5776
INFO - 2018-04-20 23:08:59 --> Config Class Initialized
INFO - 2018-04-20 23:08:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:08:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:08:59 --> Utf8 Class Initialized
INFO - 2018-04-20 23:08:59 --> URI Class Initialized
INFO - 2018-04-20 23:08:59 --> Router Class Initialized
INFO - 2018-04-20 23:08:59 --> Output Class Initialized
INFO - 2018-04-20 23:08:59 --> Security Class Initialized
DEBUG - 2018-04-20 23:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:08:59 --> CSRF cookie sent
INFO - 2018-04-20 23:08:59 --> Input Class Initialized
INFO - 2018-04-20 23:08:59 --> Language Class Initialized
ERROR - 2018-04-20 23:08:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:09:18 --> Config Class Initialized
INFO - 2018-04-20 23:09:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:09:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:09:18 --> Utf8 Class Initialized
INFO - 2018-04-20 23:09:18 --> URI Class Initialized
INFO - 2018-04-20 23:09:18 --> Router Class Initialized
INFO - 2018-04-20 23:09:18 --> Output Class Initialized
INFO - 2018-04-20 23:09:18 --> Security Class Initialized
DEBUG - 2018-04-20 23:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:09:18 --> CSRF cookie sent
INFO - 2018-04-20 23:09:18 --> Input Class Initialized
INFO - 2018-04-20 23:09:18 --> Language Class Initialized
INFO - 2018-04-20 23:09:18 --> Loader Class Initialized
INFO - 2018-04-20 23:09:18 --> Helper loaded: url_helper
INFO - 2018-04-20 23:09:18 --> Helper loaded: form_helper
INFO - 2018-04-20 23:09:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:09:18 --> User Agent Class Initialized
INFO - 2018-04-20 23:09:18 --> Controller Class Initialized
INFO - 2018-04-20 23:09:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:09:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:09:19 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:09:19 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-20 23:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:09:19 --> Final output sent to browser
DEBUG - 2018-04-20 23:09:19 --> Total execution time: 0.5433
INFO - 2018-04-20 23:09:19 --> Config Class Initialized
INFO - 2018-04-20 23:09:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:09:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:09:19 --> Utf8 Class Initialized
INFO - 2018-04-20 23:09:19 --> URI Class Initialized
INFO - 2018-04-20 23:09:19 --> Router Class Initialized
INFO - 2018-04-20 23:09:19 --> Output Class Initialized
INFO - 2018-04-20 23:09:19 --> Security Class Initialized
DEBUG - 2018-04-20 23:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:09:19 --> CSRF cookie sent
INFO - 2018-04-20 23:09:19 --> Input Class Initialized
INFO - 2018-04-20 23:09:19 --> Language Class Initialized
ERROR - 2018-04-20 23:09:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:09:55 --> Config Class Initialized
INFO - 2018-04-20 23:09:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:09:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:09:55 --> Utf8 Class Initialized
INFO - 2018-04-20 23:09:55 --> URI Class Initialized
INFO - 2018-04-20 23:09:55 --> Router Class Initialized
INFO - 2018-04-20 23:09:55 --> Output Class Initialized
INFO - 2018-04-20 23:09:55 --> Security Class Initialized
DEBUG - 2018-04-20 23:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:09:55 --> CSRF cookie sent
INFO - 2018-04-20 23:09:55 --> Input Class Initialized
INFO - 2018-04-20 23:09:55 --> Language Class Initialized
INFO - 2018-04-20 23:09:55 --> Loader Class Initialized
INFO - 2018-04-20 23:09:55 --> Helper loaded: url_helper
INFO - 2018-04-20 23:09:55 --> Helper loaded: form_helper
INFO - 2018-04-20 23:09:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:09:55 --> User Agent Class Initialized
INFO - 2018-04-20 23:09:55 --> Controller Class Initialized
INFO - 2018-04-20 23:09:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:09:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:09:55 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:09:55 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-20 23:09:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:09:55 --> Final output sent to browser
DEBUG - 2018-04-20 23:09:55 --> Total execution time: 0.5850
INFO - 2018-04-20 23:09:55 --> Config Class Initialized
INFO - 2018-04-20 23:09:56 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:09:56 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:09:56 --> Utf8 Class Initialized
INFO - 2018-04-20 23:09:56 --> URI Class Initialized
INFO - 2018-04-20 23:09:56 --> Router Class Initialized
INFO - 2018-04-20 23:09:56 --> Output Class Initialized
INFO - 2018-04-20 23:09:56 --> Security Class Initialized
DEBUG - 2018-04-20 23:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:09:56 --> CSRF cookie sent
INFO - 2018-04-20 23:09:56 --> Input Class Initialized
INFO - 2018-04-20 23:09:56 --> Language Class Initialized
ERROR - 2018-04-20 23:09:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:12:27 --> Config Class Initialized
INFO - 2018-04-20 23:12:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:12:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:12:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:12:27 --> URI Class Initialized
INFO - 2018-04-20 23:12:27 --> Router Class Initialized
INFO - 2018-04-20 23:12:27 --> Output Class Initialized
INFO - 2018-04-20 23:12:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:12:27 --> CSRF cookie sent
INFO - 2018-04-20 23:12:27 --> Input Class Initialized
INFO - 2018-04-20 23:12:27 --> Language Class Initialized
INFO - 2018-04-20 23:12:27 --> Loader Class Initialized
INFO - 2018-04-20 23:12:27 --> Helper loaded: url_helper
INFO - 2018-04-20 23:12:27 --> Helper loaded: form_helper
INFO - 2018-04-20 23:12:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:12:27 --> User Agent Class Initialized
INFO - 2018-04-20 23:12:27 --> Controller Class Initialized
INFO - 2018-04-20 23:12:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:12:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:12:27 --> Pixel_Model class loaded
INFO - 2018-04-20 23:12:27 --> Database Driver Class Initialized
INFO - 2018-04-20 23:12:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:12:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:12:27 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:12:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:12:27 --> Final output sent to browser
DEBUG - 2018-04-20 23:12:27 --> Total execution time: 0.6279
INFO - 2018-04-20 23:12:28 --> Config Class Initialized
INFO - 2018-04-20 23:12:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:12:28 --> Utf8 Class Initialized
INFO - 2018-04-20 23:12:28 --> URI Class Initialized
INFO - 2018-04-20 23:12:28 --> Router Class Initialized
INFO - 2018-04-20 23:12:28 --> Output Class Initialized
INFO - 2018-04-20 23:12:28 --> Security Class Initialized
DEBUG - 2018-04-20 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:12:28 --> CSRF cookie sent
INFO - 2018-04-20 23:12:28 --> Input Class Initialized
INFO - 2018-04-20 23:12:28 --> Language Class Initialized
ERROR - 2018-04-20 23:12:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:13:00 --> Config Class Initialized
INFO - 2018-04-20 23:13:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:00 --> URI Class Initialized
INFO - 2018-04-20 23:13:00 --> Router Class Initialized
INFO - 2018-04-20 23:13:00 --> Output Class Initialized
INFO - 2018-04-20 23:13:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:00 --> CSRF cookie sent
INFO - 2018-04-20 23:13:00 --> Input Class Initialized
INFO - 2018-04-20 23:13:00 --> Language Class Initialized
INFO - 2018-04-20 23:13:00 --> Loader Class Initialized
INFO - 2018-04-20 23:13:00 --> Helper loaded: url_helper
INFO - 2018-04-20 23:13:00 --> Helper loaded: form_helper
INFO - 2018-04-20 23:13:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:13:00 --> User Agent Class Initialized
INFO - 2018-04-20 23:13:00 --> Controller Class Initialized
INFO - 2018-04-20 23:13:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:13:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:13:00 --> Pixel_Model class loaded
INFO - 2018-04-20 23:13:00 --> Database Driver Class Initialized
INFO - 2018-04-20 23:13:00 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:13:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:13:00 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:13:00 --> Final output sent to browser
DEBUG - 2018-04-20 23:13:00 --> Total execution time: 0.6379
INFO - 2018-04-20 23:13:01 --> Config Class Initialized
INFO - 2018-04-20 23:13:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:01 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:01 --> URI Class Initialized
INFO - 2018-04-20 23:13:01 --> Router Class Initialized
INFO - 2018-04-20 23:13:01 --> Output Class Initialized
INFO - 2018-04-20 23:13:01 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:01 --> CSRF cookie sent
INFO - 2018-04-20 23:13:01 --> Input Class Initialized
INFO - 2018-04-20 23:13:01 --> Language Class Initialized
ERROR - 2018-04-20 23:13:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:13:24 --> Config Class Initialized
INFO - 2018-04-20 23:13:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:24 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:24 --> URI Class Initialized
INFO - 2018-04-20 23:13:24 --> Router Class Initialized
INFO - 2018-04-20 23:13:24 --> Output Class Initialized
INFO - 2018-04-20 23:13:24 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:24 --> CSRF cookie sent
INFO - 2018-04-20 23:13:24 --> Input Class Initialized
INFO - 2018-04-20 23:13:24 --> Language Class Initialized
INFO - 2018-04-20 23:13:24 --> Loader Class Initialized
INFO - 2018-04-20 23:13:24 --> Helper loaded: url_helper
INFO - 2018-04-20 23:13:24 --> Helper loaded: form_helper
INFO - 2018-04-20 23:13:24 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:13:24 --> User Agent Class Initialized
INFO - 2018-04-20 23:13:24 --> Controller Class Initialized
INFO - 2018-04-20 23:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:13:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:13:24 --> Pixel_Model class loaded
INFO - 2018-04-20 23:13:24 --> Database Driver Class Initialized
INFO - 2018-04-20 23:13:24 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:13:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:13:24 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\register/signup_fa.php
INFO - 2018-04-20 23:13:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:13:24 --> Final output sent to browser
DEBUG - 2018-04-20 23:13:24 --> Total execution time: 0.5857
INFO - 2018-04-20 23:13:25 --> Config Class Initialized
INFO - 2018-04-20 23:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:25 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:25 --> URI Class Initialized
INFO - 2018-04-20 23:13:25 --> Router Class Initialized
INFO - 2018-04-20 23:13:25 --> Output Class Initialized
INFO - 2018-04-20 23:13:25 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:25 --> CSRF cookie sent
INFO - 2018-04-20 23:13:25 --> Input Class Initialized
INFO - 2018-04-20 23:13:25 --> Language Class Initialized
ERROR - 2018-04-20 23:13:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:13:38 --> Config Class Initialized
INFO - 2018-04-20 23:13:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:38 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:38 --> URI Class Initialized
INFO - 2018-04-20 23:13:38 --> Router Class Initialized
INFO - 2018-04-20 23:13:38 --> Output Class Initialized
INFO - 2018-04-20 23:13:38 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:38 --> CSRF cookie sent
INFO - 2018-04-20 23:13:38 --> Input Class Initialized
INFO - 2018-04-20 23:13:38 --> Language Class Initialized
INFO - 2018-04-20 23:13:38 --> Loader Class Initialized
INFO - 2018-04-20 23:13:38 --> Helper loaded: url_helper
INFO - 2018-04-20 23:13:38 --> Helper loaded: form_helper
INFO - 2018-04-20 23:13:38 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:13:38 --> User Agent Class Initialized
INFO - 2018-04-20 23:13:38 --> Controller Class Initialized
INFO - 2018-04-20 23:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:13:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:13:38 --> Pixel_Model class loaded
INFO - 2018-04-20 23:13:38 --> Database Driver Class Initialized
INFO - 2018-04-20 23:13:38 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:13:38 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:13:38 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-20 23:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:13:38 --> Final output sent to browser
DEBUG - 2018-04-20 23:13:38 --> Total execution time: 0.5865
INFO - 2018-04-20 23:13:39 --> Config Class Initialized
INFO - 2018-04-20 23:13:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:39 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:39 --> URI Class Initialized
INFO - 2018-04-20 23:13:39 --> Router Class Initialized
INFO - 2018-04-20 23:13:39 --> Output Class Initialized
INFO - 2018-04-20 23:13:39 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:39 --> CSRF cookie sent
INFO - 2018-04-20 23:13:39 --> Input Class Initialized
INFO - 2018-04-20 23:13:39 --> Language Class Initialized
ERROR - 2018-04-20 23:13:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:13:48 --> Config Class Initialized
INFO - 2018-04-20 23:13:48 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:48 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:48 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:48 --> URI Class Initialized
INFO - 2018-04-20 23:13:48 --> Router Class Initialized
INFO - 2018-04-20 23:13:48 --> Output Class Initialized
INFO - 2018-04-20 23:13:48 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:48 --> CSRF cookie sent
INFO - 2018-04-20 23:13:48 --> Input Class Initialized
INFO - 2018-04-20 23:13:48 --> Language Class Initialized
INFO - 2018-04-20 23:13:48 --> Loader Class Initialized
INFO - 2018-04-20 23:13:49 --> Helper loaded: url_helper
INFO - 2018-04-20 23:13:49 --> Helper loaded: form_helper
INFO - 2018-04-20 23:13:49 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:13:49 --> User Agent Class Initialized
INFO - 2018-04-20 23:13:49 --> Controller Class Initialized
INFO - 2018-04-20 23:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:13:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:13:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:13:49 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 23:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:13:49 --> Final output sent to browser
DEBUG - 2018-04-20 23:13:49 --> Total execution time: 0.5265
INFO - 2018-04-20 23:13:49 --> Config Class Initialized
INFO - 2018-04-20 23:13:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:13:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:13:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:13:49 --> URI Class Initialized
INFO - 2018-04-20 23:13:49 --> Router Class Initialized
INFO - 2018-04-20 23:13:49 --> Output Class Initialized
INFO - 2018-04-20 23:13:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:13:49 --> CSRF cookie sent
INFO - 2018-04-20 23:13:49 --> Input Class Initialized
INFO - 2018-04-20 23:13:49 --> Language Class Initialized
ERROR - 2018-04-20 23:13:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:14:11 --> Config Class Initialized
INFO - 2018-04-20 23:14:11 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:14:11 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:14:11 --> Utf8 Class Initialized
INFO - 2018-04-20 23:14:12 --> URI Class Initialized
INFO - 2018-04-20 23:14:12 --> Router Class Initialized
INFO - 2018-04-20 23:14:12 --> Output Class Initialized
INFO - 2018-04-20 23:14:12 --> Security Class Initialized
DEBUG - 2018-04-20 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:14:12 --> CSRF cookie sent
INFO - 2018-04-20 23:14:12 --> CSRF token verified
INFO - 2018-04-20 23:14:12 --> Input Class Initialized
INFO - 2018-04-20 23:14:12 --> Language Class Initialized
INFO - 2018-04-20 23:14:12 --> Loader Class Initialized
INFO - 2018-04-20 23:14:12 --> Helper loaded: url_helper
INFO - 2018-04-20 23:14:12 --> Helper loaded: form_helper
INFO - 2018-04-20 23:14:12 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:14:12 --> User Agent Class Initialized
INFO - 2018-04-20 23:14:12 --> Controller Class Initialized
INFO - 2018-04-20 23:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:14:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:14:12 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:14:12 --> Form Validation Class Initialized
INFO - 2018-04-20 23:14:12 --> Pixel_Model class loaded
INFO - 2018-04-20 23:14:12 --> Database Driver Class Initialized
INFO - 2018-04-20 23:14:12 --> Model "AuthenticationModel" initialized
INFO - 2018-04-20 23:14:13 --> Config Class Initialized
INFO - 2018-04-20 23:14:13 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:14:13 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:14:13 --> Utf8 Class Initialized
INFO - 2018-04-20 23:14:13 --> URI Class Initialized
DEBUG - 2018-04-20 23:14:13 --> No URI present. Default controller set.
INFO - 2018-04-20 23:14:13 --> Router Class Initialized
INFO - 2018-04-20 23:14:13 --> Output Class Initialized
INFO - 2018-04-20 23:14:13 --> Security Class Initialized
DEBUG - 2018-04-20 23:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:14:13 --> CSRF cookie sent
INFO - 2018-04-20 23:14:13 --> Input Class Initialized
INFO - 2018-04-20 23:14:13 --> Language Class Initialized
INFO - 2018-04-20 23:14:13 --> Loader Class Initialized
INFO - 2018-04-20 23:14:13 --> Helper loaded: url_helper
INFO - 2018-04-20 23:14:13 --> Helper loaded: form_helper
INFO - 2018-04-20 23:14:13 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:14:13 --> User Agent Class Initialized
INFO - 2018-04-20 23:14:13 --> Controller Class Initialized
INFO - 2018-04-20 23:14:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:14:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:14:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:14:13 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:14:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:14:13 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:14:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:14:13 --> Final output sent to browser
DEBUG - 2018-04-20 23:14:13 --> Total execution time: 0.4812
INFO - 2018-04-20 23:14:13 --> Config Class Initialized
INFO - 2018-04-20 23:14:13 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:14:13 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:14:13 --> Utf8 Class Initialized
INFO - 2018-04-20 23:14:14 --> URI Class Initialized
INFO - 2018-04-20 23:14:14 --> Router Class Initialized
INFO - 2018-04-20 23:14:14 --> Output Class Initialized
INFO - 2018-04-20 23:14:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:14:14 --> CSRF cookie sent
INFO - 2018-04-20 23:14:14 --> Input Class Initialized
INFO - 2018-04-20 23:14:14 --> Language Class Initialized
ERROR - 2018-04-20 23:14:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:14:15 --> Config Class Initialized
INFO - 2018-04-20 23:14:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:14:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:14:15 --> Utf8 Class Initialized
INFO - 2018-04-20 23:14:15 --> URI Class Initialized
INFO - 2018-04-20 23:14:15 --> Router Class Initialized
INFO - 2018-04-20 23:14:15 --> Output Class Initialized
INFO - 2018-04-20 23:14:16 --> Security Class Initialized
DEBUG - 2018-04-20 23:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:14:16 --> CSRF cookie sent
INFO - 2018-04-20 23:14:16 --> Input Class Initialized
INFO - 2018-04-20 23:14:16 --> Language Class Initialized
ERROR - 2018-04-20 23:14:16 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:18:26 --> Config Class Initialized
INFO - 2018-04-20 23:18:26 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:18:26 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:18:26 --> Utf8 Class Initialized
INFO - 2018-04-20 23:18:26 --> URI Class Initialized
INFO - 2018-04-20 23:18:26 --> Router Class Initialized
INFO - 2018-04-20 23:18:26 --> Output Class Initialized
INFO - 2018-04-20 23:18:26 --> Security Class Initialized
DEBUG - 2018-04-20 23:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:18:26 --> CSRF cookie sent
INFO - 2018-04-20 23:18:26 --> Input Class Initialized
INFO - 2018-04-20 23:18:26 --> Language Class Initialized
INFO - 2018-04-20 23:18:26 --> Loader Class Initialized
INFO - 2018-04-20 23:18:26 --> Helper loaded: url_helper
INFO - 2018-04-20 23:18:26 --> Helper loaded: form_helper
INFO - 2018-04-20 23:18:26 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:18:26 --> User Agent Class Initialized
INFO - 2018-04-20 23:18:26 --> Controller Class Initialized
INFO - 2018-04-20 23:18:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:18:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:18:26 --> Pixel_Model class loaded
INFO - 2018-04-20 23:18:26 --> Database Driver Class Initialized
INFO - 2018-04-20 23:18:26 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:18:26 --> Pagination Class Initialized
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-20 23:18:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:18:26 --> Final output sent to browser
DEBUG - 2018-04-20 23:18:27 --> Total execution time: 0.7347
INFO - 2018-04-20 23:18:27 --> Config Class Initialized
INFO - 2018-04-20 23:18:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:18:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:18:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:18:27 --> URI Class Initialized
INFO - 2018-04-20 23:18:27 --> Router Class Initialized
INFO - 2018-04-20 23:18:27 --> Output Class Initialized
INFO - 2018-04-20 23:18:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:18:27 --> CSRF cookie sent
INFO - 2018-04-20 23:18:27 --> Input Class Initialized
INFO - 2018-04-20 23:18:27 --> Language Class Initialized
ERROR - 2018-04-20 23:18:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:20:15 --> Config Class Initialized
INFO - 2018-04-20 23:20:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:16 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:16 --> URI Class Initialized
INFO - 2018-04-20 23:20:16 --> Router Class Initialized
INFO - 2018-04-20 23:20:16 --> Output Class Initialized
INFO - 2018-04-20 23:20:16 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:16 --> CSRF cookie sent
INFO - 2018-04-20 23:20:16 --> Input Class Initialized
INFO - 2018-04-20 23:20:16 --> Language Class Initialized
INFO - 2018-04-20 23:20:16 --> Loader Class Initialized
INFO - 2018-04-20 23:20:16 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:16 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:16 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:16 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:16 --> Controller Class Initialized
INFO - 2018-04-20 23:20:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:16 --> Pixel_Model class loaded
INFO - 2018-04-20 23:20:16 --> Database Driver Class Initialized
INFO - 2018-04-20 23:20:16 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:20:16 --> Pagination Class Initialized
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:20:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:20:16 --> Final output sent to browser
DEBUG - 2018-04-20 23:20:16 --> Total execution time: 0.6285
INFO - 2018-04-20 23:20:16 --> Config Class Initialized
INFO - 2018-04-20 23:20:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:17 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:17 --> URI Class Initialized
INFO - 2018-04-20 23:20:17 --> Router Class Initialized
INFO - 2018-04-20 23:20:17 --> Output Class Initialized
INFO - 2018-04-20 23:20:17 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:17 --> CSRF cookie sent
INFO - 2018-04-20 23:20:17 --> Input Class Initialized
INFO - 2018-04-20 23:20:17 --> Language Class Initialized
ERROR - 2018-04-20 23:20:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:20:27 --> Config Class Initialized
INFO - 2018-04-20 23:20:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:27 --> URI Class Initialized
INFO - 2018-04-20 23:20:27 --> Router Class Initialized
INFO - 2018-04-20 23:20:27 --> Output Class Initialized
INFO - 2018-04-20 23:20:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:27 --> CSRF cookie sent
INFO - 2018-04-20 23:20:27 --> Input Class Initialized
INFO - 2018-04-20 23:20:27 --> Language Class Initialized
INFO - 2018-04-20 23:20:27 --> Loader Class Initialized
INFO - 2018-04-20 23:20:27 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:27 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:27 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:27 --> Controller Class Initialized
INFO - 2018-04-20 23:20:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:27 --> Config Class Initialized
INFO - 2018-04-20 23:20:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:27 --> URI Class Initialized
DEBUG - 2018-04-20 23:20:27 --> No URI present. Default controller set.
INFO - 2018-04-20 23:20:27 --> Router Class Initialized
INFO - 2018-04-20 23:20:27 --> Output Class Initialized
INFO - 2018-04-20 23:20:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:27 --> CSRF cookie sent
INFO - 2018-04-20 23:20:27 --> Input Class Initialized
INFO - 2018-04-20 23:20:27 --> Language Class Initialized
INFO - 2018-04-20 23:20:27 --> Loader Class Initialized
INFO - 2018-04-20 23:20:27 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:27 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:27 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:27 --> Controller Class Initialized
INFO - 2018-04-20 23:20:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:20:27 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:20:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:20:27 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:20:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:20:27 --> Final output sent to browser
DEBUG - 2018-04-20 23:20:27 --> Total execution time: 0.4924
INFO - 2018-04-20 23:20:28 --> Config Class Initialized
INFO - 2018-04-20 23:20:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:28 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:28 --> URI Class Initialized
INFO - 2018-04-20 23:20:28 --> Router Class Initialized
INFO - 2018-04-20 23:20:28 --> Output Class Initialized
INFO - 2018-04-20 23:20:28 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:28 --> CSRF cookie sent
INFO - 2018-04-20 23:20:28 --> Input Class Initialized
INFO - 2018-04-20 23:20:28 --> Language Class Initialized
ERROR - 2018-04-20 23:20:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:20:30 --> Config Class Initialized
INFO - 2018-04-20 23:20:30 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:30 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:30 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:30 --> URI Class Initialized
INFO - 2018-04-20 23:20:30 --> Router Class Initialized
INFO - 2018-04-20 23:20:30 --> Output Class Initialized
INFO - 2018-04-20 23:20:30 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:30 --> CSRF cookie sent
INFO - 2018-04-20 23:20:30 --> Input Class Initialized
INFO - 2018-04-20 23:20:30 --> Language Class Initialized
ERROR - 2018-04-20 23:20:30 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:20:33 --> Config Class Initialized
INFO - 2018-04-20 23:20:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:33 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:33 --> URI Class Initialized
INFO - 2018-04-20 23:20:33 --> Router Class Initialized
INFO - 2018-04-20 23:20:33 --> Output Class Initialized
INFO - 2018-04-20 23:20:33 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:33 --> CSRF cookie sent
INFO - 2018-04-20 23:20:33 --> Input Class Initialized
INFO - 2018-04-20 23:20:33 --> Language Class Initialized
INFO - 2018-04-20 23:20:33 --> Loader Class Initialized
INFO - 2018-04-20 23:20:33 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:33 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:33 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:33 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:33 --> Controller Class Initialized
INFO - 2018-04-20 23:20:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:33 --> Pixel_Model class loaded
INFO - 2018-04-20 23:20:33 --> Database Driver Class Initialized
INFO - 2018-04-20 23:20:33 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:20:33 --> Pagination Class Initialized
INFO - 2018-04-20 23:20:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:20:33 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:20:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:20:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:20:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:20:34 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:20:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:20:34 --> Final output sent to browser
DEBUG - 2018-04-20 23:20:34 --> Total execution time: 0.6759
INFO - 2018-04-20 23:20:34 --> Config Class Initialized
INFO - 2018-04-20 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:34 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:34 --> URI Class Initialized
INFO - 2018-04-20 23:20:34 --> Router Class Initialized
INFO - 2018-04-20 23:20:34 --> Output Class Initialized
INFO - 2018-04-20 23:20:34 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:34 --> CSRF cookie sent
INFO - 2018-04-20 23:20:34 --> Input Class Initialized
INFO - 2018-04-20 23:20:34 --> Language Class Initialized
ERROR - 2018-04-20 23:20:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:20:46 --> Config Class Initialized
INFO - 2018-04-20 23:20:46 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:46 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:46 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:46 --> URI Class Initialized
INFO - 2018-04-20 23:20:46 --> Router Class Initialized
INFO - 2018-04-20 23:20:46 --> Output Class Initialized
INFO - 2018-04-20 23:20:46 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:46 --> CSRF cookie sent
INFO - 2018-04-20 23:20:46 --> Input Class Initialized
INFO - 2018-04-20 23:20:46 --> Language Class Initialized
INFO - 2018-04-20 23:20:46 --> Loader Class Initialized
INFO - 2018-04-20 23:20:46 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:46 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:46 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:46 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:46 --> Controller Class Initialized
INFO - 2018-04-20 23:20:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:46 --> Pixel_Model class loaded
INFO - 2018-04-20 23:20:46 --> Database Driver Class Initialized
INFO - 2018-04-20 23:20:46 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:20:46 --> Pagination Class Initialized
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:20:46 --> Final output sent to browser
DEBUG - 2018-04-20 23:20:46 --> Total execution time: 0.6097
INFO - 2018-04-20 23:20:47 --> Config Class Initialized
INFO - 2018-04-20 23:20:47 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:47 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:47 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:47 --> URI Class Initialized
INFO - 2018-04-20 23:20:47 --> Router Class Initialized
INFO - 2018-04-20 23:20:47 --> Output Class Initialized
INFO - 2018-04-20 23:20:47 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:47 --> CSRF cookie sent
INFO - 2018-04-20 23:20:47 --> Input Class Initialized
INFO - 2018-04-20 23:20:47 --> Language Class Initialized
ERROR - 2018-04-20 23:20:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:20:51 --> Config Class Initialized
INFO - 2018-04-20 23:20:51 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:51 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:51 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:51 --> URI Class Initialized
INFO - 2018-04-20 23:20:51 --> Router Class Initialized
INFO - 2018-04-20 23:20:51 --> Output Class Initialized
INFO - 2018-04-20 23:20:51 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:51 --> CSRF cookie sent
INFO - 2018-04-20 23:20:51 --> Input Class Initialized
INFO - 2018-04-20 23:20:51 --> Language Class Initialized
INFO - 2018-04-20 23:20:51 --> Loader Class Initialized
INFO - 2018-04-20 23:20:51 --> Helper loaded: url_helper
INFO - 2018-04-20 23:20:51 --> Helper loaded: form_helper
INFO - 2018-04-20 23:20:51 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:20:51 --> User Agent Class Initialized
INFO - 2018-04-20 23:20:51 --> Controller Class Initialized
INFO - 2018-04-20 23:20:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:20:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:20:51 --> Pixel_Model class loaded
INFO - 2018-04-20 23:20:51 --> Database Driver Class Initialized
INFO - 2018-04-20 23:20:51 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:20:51 --> Pagination Class Initialized
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:20:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:20:51 --> Final output sent to browser
DEBUG - 2018-04-20 23:20:51 --> Total execution time: 0.6125
INFO - 2018-04-20 23:20:52 --> Config Class Initialized
INFO - 2018-04-20 23:20:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:20:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:20:52 --> Utf8 Class Initialized
INFO - 2018-04-20 23:20:52 --> URI Class Initialized
INFO - 2018-04-20 23:20:52 --> Router Class Initialized
INFO - 2018-04-20 23:20:52 --> Output Class Initialized
INFO - 2018-04-20 23:20:52 --> Security Class Initialized
DEBUG - 2018-04-20 23:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:20:52 --> CSRF cookie sent
INFO - 2018-04-20 23:20:52 --> Input Class Initialized
INFO - 2018-04-20 23:20:52 --> Language Class Initialized
ERROR - 2018-04-20 23:20:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:22:27 --> Config Class Initialized
INFO - 2018-04-20 23:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:22:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:22:27 --> URI Class Initialized
INFO - 2018-04-20 23:22:27 --> Router Class Initialized
INFO - 2018-04-20 23:22:27 --> Output Class Initialized
INFO - 2018-04-20 23:22:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:22:27 --> CSRF cookie sent
INFO - 2018-04-20 23:22:27 --> Input Class Initialized
INFO - 2018-04-20 23:22:27 --> Language Class Initialized
INFO - 2018-04-20 23:22:27 --> Loader Class Initialized
INFO - 2018-04-20 23:22:27 --> Helper loaded: url_helper
INFO - 2018-04-20 23:22:27 --> Helper loaded: form_helper
INFO - 2018-04-20 23:22:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:22:28 --> User Agent Class Initialized
INFO - 2018-04-20 23:22:28 --> Controller Class Initialized
INFO - 2018-04-20 23:22:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:22:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:22:28 --> Pixel_Model class loaded
INFO - 2018-04-20 23:22:28 --> Database Driver Class Initialized
INFO - 2018-04-20 23:22:28 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:22:28 --> Pagination Class Initialized
ERROR - 2018-04-20 23:22:28 --> Query error: Unknown column 'parent_ids' in 'where clause' - Invalid query: SELECT *, (select name from roles where roles.id=users.role_id) AS role
FROM `users`
WHERE `role_id` IN(2, 4, 3, 5)
AND  `first_name` LIKE '%saqib%' ESCAPE '!'
OR  `last_name` LIKE '%saqib%' ESCAPE '!'
OR  `email` LIKE '%saqib%' ESCAPE '!'
AND `parent_ids` = '39'
 LIMIT 12
INFO - 2018-04-20 23:22:28 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-20 23:24:09 --> Config Class Initialized
INFO - 2018-04-20 23:24:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:24:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:24:10 --> Utf8 Class Initialized
INFO - 2018-04-20 23:24:10 --> URI Class Initialized
INFO - 2018-04-20 23:24:10 --> Router Class Initialized
INFO - 2018-04-20 23:24:10 --> Output Class Initialized
INFO - 2018-04-20 23:24:10 --> Security Class Initialized
DEBUG - 2018-04-20 23:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:24:10 --> CSRF cookie sent
INFO - 2018-04-20 23:24:10 --> Input Class Initialized
INFO - 2018-04-20 23:24:10 --> Language Class Initialized
INFO - 2018-04-20 23:24:10 --> Loader Class Initialized
INFO - 2018-04-20 23:24:10 --> Helper loaded: url_helper
INFO - 2018-04-20 23:24:10 --> Helper loaded: form_helper
INFO - 2018-04-20 23:24:10 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:24:10 --> User Agent Class Initialized
INFO - 2018-04-20 23:24:10 --> Controller Class Initialized
INFO - 2018-04-20 23:24:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:24:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:24:10 --> Pixel_Model class loaded
INFO - 2018-04-20 23:24:10 --> Database Driver Class Initialized
INFO - 2018-04-20 23:24:10 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:24:10 --> Pagination Class Initialized
ERROR - 2018-04-20 23:24:10 --> Query error: Unknown column 'parent_ids' in 'where clause' - Invalid query: SELECT *, (select name from roles where roles.id=users.role_id) AS role
FROM `users`
WHERE `role_id` IN(2, 4, 3, 5)
AND   (
`first_name` LIKE '%saqib%' ESCAPE '!'
OR  `last_name` LIKE '%saqib%' ESCAPE '!'
OR  `email` LIKE '%saqib%' ESCAPE '!'
 )
AND `parent_ids` = '39'
 LIMIT 12
INFO - 2018-04-20 23:24:10 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-20 23:24:22 --> Config Class Initialized
INFO - 2018-04-20 23:24:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:24:22 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:24:22 --> Utf8 Class Initialized
INFO - 2018-04-20 23:24:22 --> URI Class Initialized
INFO - 2018-04-20 23:24:22 --> Router Class Initialized
INFO - 2018-04-20 23:24:22 --> Output Class Initialized
INFO - 2018-04-20 23:24:22 --> Security Class Initialized
DEBUG - 2018-04-20 23:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:24:22 --> CSRF cookie sent
INFO - 2018-04-20 23:24:22 --> Input Class Initialized
INFO - 2018-04-20 23:24:22 --> Language Class Initialized
INFO - 2018-04-20 23:24:22 --> Loader Class Initialized
INFO - 2018-04-20 23:24:22 --> Helper loaded: url_helper
INFO - 2018-04-20 23:24:22 --> Helper loaded: form_helper
INFO - 2018-04-20 23:24:22 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:24:22 --> User Agent Class Initialized
INFO - 2018-04-20 23:24:22 --> Controller Class Initialized
INFO - 2018-04-20 23:24:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:24:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:24:22 --> Pixel_Model class loaded
INFO - 2018-04-20 23:24:22 --> Database Driver Class Initialized
INFO - 2018-04-20 23:24:22 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:24:22 --> Pagination Class Initialized
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:24:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:24:22 --> Final output sent to browser
DEBUG - 2018-04-20 23:24:22 --> Total execution time: 0.5917
INFO - 2018-04-20 23:24:23 --> Config Class Initialized
INFO - 2018-04-20 23:24:23 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:24:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:24:23 --> Utf8 Class Initialized
INFO - 2018-04-20 23:24:23 --> URI Class Initialized
INFO - 2018-04-20 23:24:23 --> Router Class Initialized
INFO - 2018-04-20 23:24:23 --> Output Class Initialized
INFO - 2018-04-20 23:24:23 --> Security Class Initialized
DEBUG - 2018-04-20 23:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:24:23 --> CSRF cookie sent
INFO - 2018-04-20 23:24:23 --> Input Class Initialized
INFO - 2018-04-20 23:24:23 --> Language Class Initialized
ERROR - 2018-04-20 23:24:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:24:31 --> Config Class Initialized
INFO - 2018-04-20 23:24:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:24:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:24:32 --> Utf8 Class Initialized
INFO - 2018-04-20 23:24:32 --> URI Class Initialized
INFO - 2018-04-20 23:24:32 --> Router Class Initialized
INFO - 2018-04-20 23:24:32 --> Output Class Initialized
INFO - 2018-04-20 23:24:32 --> Security Class Initialized
DEBUG - 2018-04-20 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:24:32 --> CSRF cookie sent
INFO - 2018-04-20 23:24:32 --> Input Class Initialized
INFO - 2018-04-20 23:24:32 --> Language Class Initialized
INFO - 2018-04-20 23:24:32 --> Loader Class Initialized
INFO - 2018-04-20 23:24:32 --> Helper loaded: url_helper
INFO - 2018-04-20 23:24:32 --> Helper loaded: form_helper
INFO - 2018-04-20 23:24:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:24:32 --> User Agent Class Initialized
INFO - 2018-04-20 23:24:32 --> Controller Class Initialized
INFO - 2018-04-20 23:24:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:24:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:24:32 --> Pixel_Model class loaded
INFO - 2018-04-20 23:24:32 --> Database Driver Class Initialized
INFO - 2018-04-20 23:24:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:24:32 --> Pagination Class Initialized
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:24:32 --> Final output sent to browser
DEBUG - 2018-04-20 23:24:32 --> Total execution time: 0.6124
INFO - 2018-04-20 23:24:32 --> Config Class Initialized
INFO - 2018-04-20 23:24:33 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:24:33 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:24:33 --> Utf8 Class Initialized
INFO - 2018-04-20 23:24:33 --> URI Class Initialized
INFO - 2018-04-20 23:24:33 --> Router Class Initialized
INFO - 2018-04-20 23:24:33 --> Output Class Initialized
INFO - 2018-04-20 23:24:33 --> Security Class Initialized
DEBUG - 2018-04-20 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:24:33 --> CSRF cookie sent
INFO - 2018-04-20 23:24:33 --> Input Class Initialized
INFO - 2018-04-20 23:24:33 --> Language Class Initialized
ERROR - 2018-04-20 23:24:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:25:06 --> Config Class Initialized
INFO - 2018-04-20 23:25:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:25:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:25:06 --> Utf8 Class Initialized
INFO - 2018-04-20 23:25:06 --> URI Class Initialized
INFO - 2018-04-20 23:25:06 --> Router Class Initialized
INFO - 2018-04-20 23:25:06 --> Output Class Initialized
INFO - 2018-04-20 23:25:06 --> Security Class Initialized
DEBUG - 2018-04-20 23:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:25:06 --> CSRF cookie sent
INFO - 2018-04-20 23:25:06 --> Input Class Initialized
INFO - 2018-04-20 23:25:06 --> Language Class Initialized
INFO - 2018-04-20 23:25:06 --> Loader Class Initialized
INFO - 2018-04-20 23:25:06 --> Helper loaded: url_helper
INFO - 2018-04-20 23:25:06 --> Helper loaded: form_helper
INFO - 2018-04-20 23:25:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:25:07 --> User Agent Class Initialized
INFO - 2018-04-20 23:25:07 --> Controller Class Initialized
INFO - 2018-04-20 23:25:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:25:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:25:07 --> Pixel_Model class loaded
INFO - 2018-04-20 23:25:07 --> Database Driver Class Initialized
INFO - 2018-04-20 23:25:07 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:25:07 --> Pagination Class Initialized
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:25:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:25:07 --> Final output sent to browser
DEBUG - 2018-04-20 23:25:07 --> Total execution time: 0.6126
INFO - 2018-04-20 23:25:07 --> Config Class Initialized
INFO - 2018-04-20 23:25:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:25:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:25:07 --> Utf8 Class Initialized
INFO - 2018-04-20 23:25:07 --> URI Class Initialized
INFO - 2018-04-20 23:25:07 --> Router Class Initialized
INFO - 2018-04-20 23:25:07 --> Output Class Initialized
INFO - 2018-04-20 23:25:07 --> Security Class Initialized
DEBUG - 2018-04-20 23:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:25:07 --> CSRF cookie sent
INFO - 2018-04-20 23:25:07 --> Input Class Initialized
INFO - 2018-04-20 23:25:07 --> Language Class Initialized
ERROR - 2018-04-20 23:25:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:27:02 --> Config Class Initialized
INFO - 2018-04-20 23:27:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:02 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:02 --> URI Class Initialized
INFO - 2018-04-20 23:27:02 --> Router Class Initialized
INFO - 2018-04-20 23:27:02 --> Output Class Initialized
INFO - 2018-04-20 23:27:02 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:02 --> CSRF cookie sent
INFO - 2018-04-20 23:27:02 --> Input Class Initialized
INFO - 2018-04-20 23:27:02 --> Language Class Initialized
INFO - 2018-04-20 23:27:02 --> Loader Class Initialized
INFO - 2018-04-20 23:27:02 --> Helper loaded: url_helper
INFO - 2018-04-20 23:27:02 --> Helper loaded: form_helper
INFO - 2018-04-20 23:27:02 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:27:02 --> User Agent Class Initialized
INFO - 2018-04-20 23:27:02 --> Controller Class Initialized
INFO - 2018-04-20 23:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:27:02 --> Pixel_Model class loaded
INFO - 2018-04-20 23:27:02 --> Database Driver Class Initialized
INFO - 2018-04-20 23:27:03 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:27:03 --> Pagination Class Initialized
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:27:03 --> Final output sent to browser
DEBUG - 2018-04-20 23:27:03 --> Total execution time: 0.6156
INFO - 2018-04-20 23:27:03 --> Config Class Initialized
INFO - 2018-04-20 23:27:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:03 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:03 --> URI Class Initialized
INFO - 2018-04-20 23:27:03 --> Router Class Initialized
INFO - 2018-04-20 23:27:03 --> Output Class Initialized
INFO - 2018-04-20 23:27:03 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:03 --> CSRF cookie sent
INFO - 2018-04-20 23:27:03 --> Input Class Initialized
INFO - 2018-04-20 23:27:03 --> Language Class Initialized
ERROR - 2018-04-20 23:27:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:27:49 --> Config Class Initialized
INFO - 2018-04-20 23:27:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:49 --> URI Class Initialized
INFO - 2018-04-20 23:27:49 --> Router Class Initialized
INFO - 2018-04-20 23:27:49 --> Output Class Initialized
INFO - 2018-04-20 23:27:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:50 --> CSRF cookie sent
INFO - 2018-04-20 23:27:50 --> Input Class Initialized
INFO - 2018-04-20 23:27:50 --> Language Class Initialized
INFO - 2018-04-20 23:27:50 --> Loader Class Initialized
INFO - 2018-04-20 23:27:50 --> Helper loaded: url_helper
INFO - 2018-04-20 23:27:50 --> Helper loaded: form_helper
INFO - 2018-04-20 23:27:50 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:27:50 --> User Agent Class Initialized
INFO - 2018-04-20 23:27:50 --> Controller Class Initialized
INFO - 2018-04-20 23:27:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:27:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:27:50 --> Pixel_Model class loaded
INFO - 2018-04-20 23:27:50 --> Database Driver Class Initialized
INFO - 2018-04-20 23:27:50 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:27:50 --> Pagination Class Initialized
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:27:50 --> Final output sent to browser
DEBUG - 2018-04-20 23:27:50 --> Total execution time: 0.6024
INFO - 2018-04-20 23:27:50 --> Config Class Initialized
INFO - 2018-04-20 23:27:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:50 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:50 --> URI Class Initialized
INFO - 2018-04-20 23:27:50 --> Router Class Initialized
INFO - 2018-04-20 23:27:50 --> Output Class Initialized
INFO - 2018-04-20 23:27:51 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:51 --> CSRF cookie sent
INFO - 2018-04-20 23:27:51 --> Input Class Initialized
INFO - 2018-04-20 23:27:51 --> Language Class Initialized
ERROR - 2018-04-20 23:27:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:27:53 --> Config Class Initialized
INFO - 2018-04-20 23:27:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:53 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:53 --> URI Class Initialized
INFO - 2018-04-20 23:27:53 --> Router Class Initialized
INFO - 2018-04-20 23:27:53 --> Output Class Initialized
INFO - 2018-04-20 23:27:53 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:53 --> CSRF cookie sent
INFO - 2018-04-20 23:27:53 --> Input Class Initialized
INFO - 2018-04-20 23:27:53 --> Language Class Initialized
INFO - 2018-04-20 23:27:53 --> Loader Class Initialized
INFO - 2018-04-20 23:27:53 --> Helper loaded: url_helper
INFO - 2018-04-20 23:27:54 --> Helper loaded: form_helper
INFO - 2018-04-20 23:27:54 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:27:54 --> User Agent Class Initialized
INFO - 2018-04-20 23:27:54 --> Controller Class Initialized
INFO - 2018-04-20 23:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:27:54 --> Pixel_Model class loaded
INFO - 2018-04-20 23:27:54 --> Database Driver Class Initialized
INFO - 2018-04-20 23:27:54 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:27:54 --> Pagination Class Initialized
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:27:54 --> Final output sent to browser
DEBUG - 2018-04-20 23:27:54 --> Total execution time: 0.5931
INFO - 2018-04-20 23:27:54 --> Config Class Initialized
INFO - 2018-04-20 23:27:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:27:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:27:54 --> Utf8 Class Initialized
INFO - 2018-04-20 23:27:54 --> URI Class Initialized
INFO - 2018-04-20 23:27:54 --> Router Class Initialized
INFO - 2018-04-20 23:27:54 --> Output Class Initialized
INFO - 2018-04-20 23:27:54 --> Security Class Initialized
DEBUG - 2018-04-20 23:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:27:54 --> CSRF cookie sent
INFO - 2018-04-20 23:27:54 --> Input Class Initialized
INFO - 2018-04-20 23:27:54 --> Language Class Initialized
ERROR - 2018-04-20 23:27:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:29:31 --> Config Class Initialized
INFO - 2018-04-20 23:29:31 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:29:31 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:29:31 --> Utf8 Class Initialized
INFO - 2018-04-20 23:29:31 --> URI Class Initialized
INFO - 2018-04-20 23:29:31 --> Router Class Initialized
INFO - 2018-04-20 23:29:31 --> Output Class Initialized
INFO - 2018-04-20 23:29:31 --> Security Class Initialized
DEBUG - 2018-04-20 23:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:29:31 --> CSRF cookie sent
INFO - 2018-04-20 23:29:31 --> Input Class Initialized
INFO - 2018-04-20 23:29:31 --> Language Class Initialized
INFO - 2018-04-20 23:29:32 --> Loader Class Initialized
INFO - 2018-04-20 23:29:32 --> Helper loaded: url_helper
INFO - 2018-04-20 23:29:32 --> Helper loaded: form_helper
INFO - 2018-04-20 23:29:32 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:29:32 --> User Agent Class Initialized
INFO - 2018-04-20 23:29:32 --> Controller Class Initialized
INFO - 2018-04-20 23:29:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:29:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:29:32 --> Pixel_Model class loaded
INFO - 2018-04-20 23:29:32 --> Database Driver Class Initialized
INFO - 2018-04-20 23:29:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:29:32 --> Pagination Class Initialized
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:29:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:29:32 --> Final output sent to browser
DEBUG - 2018-04-20 23:29:32 --> Total execution time: 0.6190
INFO - 2018-04-20 23:29:32 --> Config Class Initialized
INFO - 2018-04-20 23:29:32 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:29:32 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:29:32 --> Utf8 Class Initialized
INFO - 2018-04-20 23:29:32 --> URI Class Initialized
INFO - 2018-04-20 23:29:32 --> Router Class Initialized
INFO - 2018-04-20 23:29:32 --> Output Class Initialized
INFO - 2018-04-20 23:29:32 --> Security Class Initialized
DEBUG - 2018-04-20 23:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:29:32 --> CSRF cookie sent
INFO - 2018-04-20 23:29:33 --> Input Class Initialized
INFO - 2018-04-20 23:29:33 --> Language Class Initialized
ERROR - 2018-04-20 23:29:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:29:53 --> Config Class Initialized
INFO - 2018-04-20 23:29:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:29:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:29:53 --> Utf8 Class Initialized
INFO - 2018-04-20 23:29:53 --> URI Class Initialized
INFO - 2018-04-20 23:29:53 --> Router Class Initialized
INFO - 2018-04-20 23:29:53 --> Output Class Initialized
INFO - 2018-04-20 23:29:53 --> Security Class Initialized
DEBUG - 2018-04-20 23:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:29:53 --> CSRF cookie sent
INFO - 2018-04-20 23:29:53 --> Input Class Initialized
INFO - 2018-04-20 23:29:53 --> Language Class Initialized
INFO - 2018-04-20 23:29:53 --> Loader Class Initialized
INFO - 2018-04-20 23:29:53 --> Helper loaded: url_helper
INFO - 2018-04-20 23:29:53 --> Helper loaded: form_helper
INFO - 2018-04-20 23:29:53 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:29:53 --> User Agent Class Initialized
INFO - 2018-04-20 23:29:53 --> Controller Class Initialized
INFO - 2018-04-20 23:29:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:29:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:29:53 --> Pixel_Model class loaded
INFO - 2018-04-20 23:29:53 --> Database Driver Class Initialized
INFO - 2018-04-20 23:29:53 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:29:53 --> Pagination Class Initialized
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:29:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:29:53 --> Final output sent to browser
DEBUG - 2018-04-20 23:29:53 --> Total execution time: 0.6137
INFO - 2018-04-20 23:29:54 --> Config Class Initialized
INFO - 2018-04-20 23:29:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:29:54 --> Utf8 Class Initialized
INFO - 2018-04-20 23:29:54 --> URI Class Initialized
INFO - 2018-04-20 23:29:54 --> Router Class Initialized
INFO - 2018-04-20 23:29:54 --> Output Class Initialized
INFO - 2018-04-20 23:29:54 --> Security Class Initialized
DEBUG - 2018-04-20 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:29:54 --> CSRF cookie sent
INFO - 2018-04-20 23:29:54 --> Input Class Initialized
INFO - 2018-04-20 23:29:54 --> Language Class Initialized
ERROR - 2018-04-20 23:29:54 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:31:09 --> Config Class Initialized
INFO - 2018-04-20 23:31:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:31:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:31:09 --> Utf8 Class Initialized
INFO - 2018-04-20 23:31:09 --> URI Class Initialized
INFO - 2018-04-20 23:31:09 --> Router Class Initialized
INFO - 2018-04-20 23:31:09 --> Output Class Initialized
INFO - 2018-04-20 23:31:09 --> Security Class Initialized
DEBUG - 2018-04-20 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:31:09 --> CSRF cookie sent
INFO - 2018-04-20 23:31:09 --> Input Class Initialized
INFO - 2018-04-20 23:31:09 --> Language Class Initialized
INFO - 2018-04-20 23:31:09 --> Loader Class Initialized
INFO - 2018-04-20 23:31:09 --> Helper loaded: url_helper
INFO - 2018-04-20 23:31:09 --> Helper loaded: form_helper
INFO - 2018-04-20 23:31:09 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:31:09 --> User Agent Class Initialized
INFO - 2018-04-20 23:31:09 --> Controller Class Initialized
INFO - 2018-04-20 23:31:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:31:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:31:09 --> Pixel_Model class loaded
INFO - 2018-04-20 23:31:09 --> Database Driver Class Initialized
INFO - 2018-04-20 23:31:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:31:09 --> Pagination Class Initialized
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:31:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:31:09 --> Final output sent to browser
DEBUG - 2018-04-20 23:31:09 --> Total execution time: 0.6181
INFO - 2018-04-20 23:31:10 --> Config Class Initialized
INFO - 2018-04-20 23:31:10 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:31:10 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:31:10 --> Utf8 Class Initialized
INFO - 2018-04-20 23:31:10 --> URI Class Initialized
INFO - 2018-04-20 23:31:10 --> Router Class Initialized
INFO - 2018-04-20 23:31:10 --> Output Class Initialized
INFO - 2018-04-20 23:31:10 --> Security Class Initialized
DEBUG - 2018-04-20 23:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:31:10 --> CSRF cookie sent
INFO - 2018-04-20 23:31:10 --> Input Class Initialized
INFO - 2018-04-20 23:31:10 --> Language Class Initialized
ERROR - 2018-04-20 23:31:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:34:20 --> Config Class Initialized
INFO - 2018-04-20 23:34:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:34:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:34:20 --> Utf8 Class Initialized
INFO - 2018-04-20 23:34:20 --> URI Class Initialized
INFO - 2018-04-20 23:34:20 --> Router Class Initialized
INFO - 2018-04-20 23:34:20 --> Output Class Initialized
INFO - 2018-04-20 23:34:20 --> Security Class Initialized
DEBUG - 2018-04-20 23:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:34:20 --> CSRF cookie sent
INFO - 2018-04-20 23:34:20 --> Input Class Initialized
INFO - 2018-04-20 23:34:20 --> Language Class Initialized
INFO - 2018-04-20 23:34:20 --> Loader Class Initialized
INFO - 2018-04-20 23:34:20 --> Helper loaded: url_helper
INFO - 2018-04-20 23:34:20 --> Helper loaded: form_helper
INFO - 2018-04-20 23:34:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:34:20 --> User Agent Class Initialized
INFO - 2018-04-20 23:34:20 --> Controller Class Initialized
INFO - 2018-04-20 23:34:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:34:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:34:20 --> Pixel_Model class loaded
INFO - 2018-04-20 23:34:20 --> Database Driver Class Initialized
INFO - 2018-04-20 23:34:20 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:34:20 --> Pagination Class Initialized
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:34:21 --> Final output sent to browser
DEBUG - 2018-04-20 23:34:21 --> Total execution time: 0.6060
INFO - 2018-04-20 23:34:21 --> Config Class Initialized
INFO - 2018-04-20 23:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:34:21 --> Utf8 Class Initialized
INFO - 2018-04-20 23:34:21 --> URI Class Initialized
INFO - 2018-04-20 23:34:21 --> Router Class Initialized
INFO - 2018-04-20 23:34:21 --> Output Class Initialized
INFO - 2018-04-20 23:34:21 --> Security Class Initialized
DEBUG - 2018-04-20 23:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:34:21 --> CSRF cookie sent
INFO - 2018-04-20 23:34:21 --> Input Class Initialized
INFO - 2018-04-20 23:34:21 --> Language Class Initialized
ERROR - 2018-04-20 23:34:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:34:45 --> Config Class Initialized
INFO - 2018-04-20 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:34:45 --> Utf8 Class Initialized
INFO - 2018-04-20 23:34:45 --> URI Class Initialized
INFO - 2018-04-20 23:34:45 --> Router Class Initialized
INFO - 2018-04-20 23:34:45 --> Output Class Initialized
INFO - 2018-04-20 23:34:45 --> Security Class Initialized
DEBUG - 2018-04-20 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:34:45 --> CSRF cookie sent
INFO - 2018-04-20 23:34:45 --> Input Class Initialized
INFO - 2018-04-20 23:34:45 --> Language Class Initialized
INFO - 2018-04-20 23:34:45 --> Loader Class Initialized
INFO - 2018-04-20 23:34:45 --> Helper loaded: url_helper
INFO - 2018-04-20 23:34:45 --> Helper loaded: form_helper
INFO - 2018-04-20 23:34:45 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:34:45 --> User Agent Class Initialized
INFO - 2018-04-20 23:34:45 --> Controller Class Initialized
INFO - 2018-04-20 23:34:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:34:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:34:45 --> Pixel_Model class loaded
INFO - 2018-04-20 23:34:45 --> Database Driver Class Initialized
INFO - 2018-04-20 23:34:45 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:34:45 --> Pagination Class Initialized
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:34:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:34:45 --> Final output sent to browser
DEBUG - 2018-04-20 23:34:45 --> Total execution time: 0.6196
INFO - 2018-04-20 23:34:46 --> Config Class Initialized
INFO - 2018-04-20 23:34:46 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:34:46 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:34:46 --> Utf8 Class Initialized
INFO - 2018-04-20 23:34:46 --> URI Class Initialized
INFO - 2018-04-20 23:34:46 --> Router Class Initialized
INFO - 2018-04-20 23:34:46 --> Output Class Initialized
INFO - 2018-04-20 23:34:46 --> Security Class Initialized
DEBUG - 2018-04-20 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:34:46 --> CSRF cookie sent
INFO - 2018-04-20 23:34:46 --> Input Class Initialized
INFO - 2018-04-20 23:34:46 --> Language Class Initialized
ERROR - 2018-04-20 23:34:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:35:49 --> Config Class Initialized
INFO - 2018-04-20 23:35:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:35:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:35:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:35:49 --> URI Class Initialized
INFO - 2018-04-20 23:35:49 --> Router Class Initialized
INFO - 2018-04-20 23:35:49 --> Output Class Initialized
INFO - 2018-04-20 23:35:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:35:49 --> CSRF cookie sent
INFO - 2018-04-20 23:35:49 --> Input Class Initialized
INFO - 2018-04-20 23:35:49 --> Language Class Initialized
INFO - 2018-04-20 23:35:49 --> Loader Class Initialized
INFO - 2018-04-20 23:35:49 --> Helper loaded: url_helper
INFO - 2018-04-20 23:35:49 --> Helper loaded: form_helper
INFO - 2018-04-20 23:35:49 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:35:49 --> User Agent Class Initialized
INFO - 2018-04-20 23:35:49 --> Controller Class Initialized
INFO - 2018-04-20 23:35:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:35:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:35:49 --> Pixel_Model class loaded
INFO - 2018-04-20 23:35:49 --> Database Driver Class Initialized
INFO - 2018-04-20 23:35:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:35:49 --> Pagination Class Initialized
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:35:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:35:49 --> Final output sent to browser
DEBUG - 2018-04-20 23:35:49 --> Total execution time: 0.6230
INFO - 2018-04-20 23:35:50 --> Config Class Initialized
INFO - 2018-04-20 23:35:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:35:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:35:50 --> Utf8 Class Initialized
INFO - 2018-04-20 23:35:50 --> URI Class Initialized
INFO - 2018-04-20 23:35:50 --> Router Class Initialized
INFO - 2018-04-20 23:35:50 --> Output Class Initialized
INFO - 2018-04-20 23:35:50 --> Security Class Initialized
DEBUG - 2018-04-20 23:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:35:50 --> CSRF cookie sent
INFO - 2018-04-20 23:35:50 --> Input Class Initialized
INFO - 2018-04-20 23:35:50 --> Language Class Initialized
ERROR - 2018-04-20 23:35:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:36:08 --> Config Class Initialized
INFO - 2018-04-20 23:36:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:36:08 --> Utf8 Class Initialized
INFO - 2018-04-20 23:36:08 --> URI Class Initialized
INFO - 2018-04-20 23:36:08 --> Router Class Initialized
INFO - 2018-04-20 23:36:08 --> Output Class Initialized
INFO - 2018-04-20 23:36:08 --> Security Class Initialized
DEBUG - 2018-04-20 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:36:08 --> CSRF cookie sent
INFO - 2018-04-20 23:36:08 --> Input Class Initialized
INFO - 2018-04-20 23:36:08 --> Language Class Initialized
INFO - 2018-04-20 23:36:08 --> Loader Class Initialized
INFO - 2018-04-20 23:36:08 --> Helper loaded: url_helper
INFO - 2018-04-20 23:36:08 --> Helper loaded: form_helper
INFO - 2018-04-20 23:36:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:36:08 --> User Agent Class Initialized
INFO - 2018-04-20 23:36:08 --> Controller Class Initialized
INFO - 2018-04-20 23:36:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:36:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:36:09 --> Pixel_Model class loaded
INFO - 2018-04-20 23:36:09 --> Database Driver Class Initialized
INFO - 2018-04-20 23:36:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:36:09 --> Pagination Class Initialized
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:36:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:36:09 --> Final output sent to browser
DEBUG - 2018-04-20 23:36:09 --> Total execution time: 0.6472
INFO - 2018-04-20 23:36:09 --> Config Class Initialized
INFO - 2018-04-20 23:36:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:36:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:36:09 --> Utf8 Class Initialized
INFO - 2018-04-20 23:36:09 --> URI Class Initialized
INFO - 2018-04-20 23:36:09 --> Router Class Initialized
INFO - 2018-04-20 23:36:09 --> Output Class Initialized
INFO - 2018-04-20 23:36:09 --> Security Class Initialized
DEBUG - 2018-04-20 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:36:09 --> CSRF cookie sent
INFO - 2018-04-20 23:36:09 --> Input Class Initialized
INFO - 2018-04-20 23:36:09 --> Language Class Initialized
ERROR - 2018-04-20 23:36:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:36:53 --> Config Class Initialized
INFO - 2018-04-20 23:36:53 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:36:53 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:36:53 --> Utf8 Class Initialized
INFO - 2018-04-20 23:36:53 --> URI Class Initialized
INFO - 2018-04-20 23:36:53 --> Router Class Initialized
INFO - 2018-04-20 23:36:53 --> Output Class Initialized
INFO - 2018-04-20 23:36:53 --> Security Class Initialized
DEBUG - 2018-04-20 23:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:36:53 --> CSRF cookie sent
INFO - 2018-04-20 23:36:53 --> Input Class Initialized
INFO - 2018-04-20 23:36:53 --> Language Class Initialized
INFO - 2018-04-20 23:36:53 --> Loader Class Initialized
INFO - 2018-04-20 23:36:53 --> Helper loaded: url_helper
INFO - 2018-04-20 23:36:53 --> Helper loaded: form_helper
INFO - 2018-04-20 23:36:53 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:36:53 --> User Agent Class Initialized
INFO - 2018-04-20 23:36:53 --> Controller Class Initialized
INFO - 2018-04-20 23:36:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:36:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:36:53 --> Pixel_Model class loaded
INFO - 2018-04-20 23:36:53 --> Database Driver Class Initialized
INFO - 2018-04-20 23:36:53 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:36:53 --> Pagination Class Initialized
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:36:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:36:53 --> Final output sent to browser
DEBUG - 2018-04-20 23:36:53 --> Total execution time: 0.6396
INFO - 2018-04-20 23:36:54 --> Config Class Initialized
INFO - 2018-04-20 23:36:54 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:36:54 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:36:54 --> Utf8 Class Initialized
INFO - 2018-04-20 23:36:54 --> URI Class Initialized
INFO - 2018-04-20 23:36:54 --> Router Class Initialized
INFO - 2018-04-20 23:36:54 --> Output Class Initialized
INFO - 2018-04-20 23:36:54 --> Security Class Initialized
DEBUG - 2018-04-20 23:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:36:54 --> CSRF cookie sent
INFO - 2018-04-20 23:36:54 --> Input Class Initialized
INFO - 2018-04-20 23:36:54 --> Language Class Initialized
ERROR - 2018-04-20 23:36:54 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:41:04 --> Config Class Initialized
INFO - 2018-04-20 23:41:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:04 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:04 --> URI Class Initialized
INFO - 2018-04-20 23:41:04 --> Router Class Initialized
INFO - 2018-04-20 23:41:04 --> Output Class Initialized
INFO - 2018-04-20 23:41:04 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:04 --> CSRF cookie sent
INFO - 2018-04-20 23:41:04 --> Input Class Initialized
INFO - 2018-04-20 23:41:04 --> Language Class Initialized
INFO - 2018-04-20 23:41:04 --> Loader Class Initialized
INFO - 2018-04-20 23:41:04 --> Helper loaded: url_helper
INFO - 2018-04-20 23:41:04 --> Helper loaded: form_helper
INFO - 2018-04-20 23:41:04 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:41:04 --> User Agent Class Initialized
INFO - 2018-04-20 23:41:04 --> Controller Class Initialized
INFO - 2018-04-20 23:41:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:41:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:41:04 --> Pixel_Model class loaded
INFO - 2018-04-20 23:41:04 --> Database Driver Class Initialized
INFO - 2018-04-20 23:41:04 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:41:04 --> Pagination Class Initialized
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:41:04 --> Final output sent to browser
DEBUG - 2018-04-20 23:41:04 --> Total execution time: 0.6384
INFO - 2018-04-20 23:41:05 --> Config Class Initialized
INFO - 2018-04-20 23:41:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:05 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:05 --> URI Class Initialized
INFO - 2018-04-20 23:41:05 --> Router Class Initialized
INFO - 2018-04-20 23:41:05 --> Output Class Initialized
INFO - 2018-04-20 23:41:05 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:05 --> CSRF cookie sent
INFO - 2018-04-20 23:41:05 --> Input Class Initialized
INFO - 2018-04-20 23:41:05 --> Language Class Initialized
ERROR - 2018-04-20 23:41:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:41:44 --> Config Class Initialized
INFO - 2018-04-20 23:41:44 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:44 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:44 --> URI Class Initialized
INFO - 2018-04-20 23:41:44 --> Router Class Initialized
INFO - 2018-04-20 23:41:44 --> Output Class Initialized
INFO - 2018-04-20 23:41:44 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:44 --> CSRF cookie sent
INFO - 2018-04-20 23:41:44 --> Input Class Initialized
INFO - 2018-04-20 23:41:44 --> Language Class Initialized
INFO - 2018-04-20 23:41:44 --> Loader Class Initialized
INFO - 2018-04-20 23:41:44 --> Helper loaded: url_helper
INFO - 2018-04-20 23:41:44 --> Helper loaded: form_helper
INFO - 2018-04-20 23:41:44 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:41:44 --> User Agent Class Initialized
INFO - 2018-04-20 23:41:44 --> Controller Class Initialized
INFO - 2018-04-20 23:41:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:41:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:41:44 --> Pixel_Model class loaded
INFO - 2018-04-20 23:41:44 --> Database Driver Class Initialized
INFO - 2018-04-20 23:41:45 --> Model "MyAccountModel" initialized
INFO - 2018-04-20 23:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-20 23:41:45 --> Pagination Class Initialized
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\myaccount/client_list.php
INFO - 2018-04-20 23:41:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:41:45 --> Final output sent to browser
DEBUG - 2018-04-20 23:41:45 --> Total execution time: 0.6277
INFO - 2018-04-20 23:41:45 --> Config Class Initialized
INFO - 2018-04-20 23:41:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:45 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:45 --> URI Class Initialized
INFO - 2018-04-20 23:41:45 --> Router Class Initialized
INFO - 2018-04-20 23:41:45 --> Output Class Initialized
INFO - 2018-04-20 23:41:45 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:45 --> CSRF cookie sent
INFO - 2018-04-20 23:41:45 --> Input Class Initialized
INFO - 2018-04-20 23:41:45 --> Language Class Initialized
ERROR - 2018-04-20 23:41:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:41:48 --> Config Class Initialized
INFO - 2018-04-20 23:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:48 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:48 --> URI Class Initialized
INFO - 2018-04-20 23:41:48 --> Router Class Initialized
INFO - 2018-04-20 23:41:48 --> Output Class Initialized
INFO - 2018-04-20 23:41:48 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:48 --> CSRF cookie sent
INFO - 2018-04-20 23:41:48 --> Input Class Initialized
INFO - 2018-04-20 23:41:48 --> Language Class Initialized
INFO - 2018-04-20 23:41:48 --> Loader Class Initialized
INFO - 2018-04-20 23:41:48 --> Helper loaded: url_helper
INFO - 2018-04-20 23:41:48 --> Helper loaded: form_helper
INFO - 2018-04-20 23:41:48 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:41:48 --> User Agent Class Initialized
INFO - 2018-04-20 23:41:48 --> Controller Class Initialized
INFO - 2018-04-20 23:41:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:41:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:41:48 --> Pixel_Model class loaded
INFO - 2018-04-20 23:41:49 --> Database Driver Class Initialized
INFO - 2018-04-20 23:41:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-20 23:41:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:41:49 --> Final output sent to browser
DEBUG - 2018-04-20 23:41:49 --> Total execution time: 0.6553
INFO - 2018-04-20 23:41:49 --> Config Class Initialized
INFO - 2018-04-20 23:41:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:41:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:41:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:41:49 --> URI Class Initialized
INFO - 2018-04-20 23:41:49 --> Router Class Initialized
INFO - 2018-04-20 23:41:49 --> Output Class Initialized
INFO - 2018-04-20 23:41:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:41:49 --> CSRF cookie sent
INFO - 2018-04-20 23:41:49 --> Input Class Initialized
INFO - 2018-04-20 23:41:49 --> Language Class Initialized
ERROR - 2018-04-20 23:41:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:42:44 --> Config Class Initialized
INFO - 2018-04-20 23:42:44 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:42:44 --> Utf8 Class Initialized
INFO - 2018-04-20 23:42:44 --> URI Class Initialized
INFO - 2018-04-20 23:42:44 --> Router Class Initialized
INFO - 2018-04-20 23:42:44 --> Output Class Initialized
INFO - 2018-04-20 23:42:44 --> Security Class Initialized
DEBUG - 2018-04-20 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:42:44 --> CSRF cookie sent
INFO - 2018-04-20 23:42:44 --> Input Class Initialized
INFO - 2018-04-20 23:42:44 --> Language Class Initialized
INFO - 2018-04-20 23:42:44 --> Loader Class Initialized
INFO - 2018-04-20 23:42:44 --> Helper loaded: url_helper
INFO - 2018-04-20 23:42:44 --> Helper loaded: form_helper
INFO - 2018-04-20 23:42:44 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:42:44 --> User Agent Class Initialized
INFO - 2018-04-20 23:42:45 --> Controller Class Initialized
INFO - 2018-04-20 23:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:42:45 --> Pixel_Model class loaded
INFO - 2018-04-20 23:42:45 --> Database Driver Class Initialized
INFO - 2018-04-20 23:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-20 23:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:42:45 --> Final output sent to browser
DEBUG - 2018-04-20 23:42:45 --> Total execution time: 0.6090
INFO - 2018-04-20 23:42:45 --> Config Class Initialized
INFO - 2018-04-20 23:42:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:42:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:42:45 --> Utf8 Class Initialized
INFO - 2018-04-20 23:42:45 --> URI Class Initialized
INFO - 2018-04-20 23:42:45 --> Router Class Initialized
INFO - 2018-04-20 23:42:45 --> Output Class Initialized
INFO - 2018-04-20 23:42:45 --> Security Class Initialized
DEBUG - 2018-04-20 23:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:42:45 --> CSRF cookie sent
INFO - 2018-04-20 23:42:45 --> Input Class Initialized
INFO - 2018-04-20 23:42:45 --> Language Class Initialized
ERROR - 2018-04-20 23:42:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:43:03 --> Config Class Initialized
INFO - 2018-04-20 23:43:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:03 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:03 --> URI Class Initialized
INFO - 2018-04-20 23:43:03 --> Router Class Initialized
INFO - 2018-04-20 23:43:03 --> Output Class Initialized
INFO - 2018-04-20 23:43:03 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:03 --> CSRF cookie sent
INFO - 2018-04-20 23:43:03 --> Input Class Initialized
INFO - 2018-04-20 23:43:03 --> Language Class Initialized
INFO - 2018-04-20 23:43:03 --> Loader Class Initialized
INFO - 2018-04-20 23:43:03 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:04 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:04 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:04 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:04 --> Controller Class Initialized
INFO - 2018-04-20 23:43:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:04 --> Pixel_Model class loaded
INFO - 2018-04-20 23:43:04 --> Database Driver Class Initialized
INFO - 2018-04-20 23:43:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-20 23:43:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:43:04 --> Final output sent to browser
DEBUG - 2018-04-20 23:43:04 --> Total execution time: 0.6123
INFO - 2018-04-20 23:43:04 --> Config Class Initialized
INFO - 2018-04-20 23:43:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:04 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:04 --> URI Class Initialized
INFO - 2018-04-20 23:43:04 --> Router Class Initialized
INFO - 2018-04-20 23:43:04 --> Output Class Initialized
INFO - 2018-04-20 23:43:04 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:04 --> CSRF cookie sent
INFO - 2018-04-20 23:43:04 --> Input Class Initialized
INFO - 2018-04-20 23:43:04 --> Language Class Initialized
ERROR - 2018-04-20 23:43:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:43:18 --> Config Class Initialized
INFO - 2018-04-20 23:43:18 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:18 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:18 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:18 --> URI Class Initialized
INFO - 2018-04-20 23:43:18 --> Router Class Initialized
INFO - 2018-04-20 23:43:18 --> Output Class Initialized
INFO - 2018-04-20 23:43:18 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:18 --> CSRF cookie sent
INFO - 2018-04-20 23:43:18 --> CSRF token verified
INFO - 2018-04-20 23:43:18 --> Input Class Initialized
INFO - 2018-04-20 23:43:18 --> Language Class Initialized
INFO - 2018-04-20 23:43:18 --> Loader Class Initialized
INFO - 2018-04-20 23:43:18 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:18 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:18 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:19 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:19 --> Controller Class Initialized
INFO - 2018-04-20 23:43:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:19 --> Pixel_Model class loaded
INFO - 2018-04-20 23:43:19 --> Database Driver Class Initialized
INFO - 2018-04-20 23:43:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:43:19 --> Form Validation Class Initialized
INFO - 2018-04-20 23:43:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:43:19 --> Config Class Initialized
INFO - 2018-04-20 23:43:19 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:19 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:19 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:19 --> URI Class Initialized
INFO - 2018-04-20 23:43:19 --> Router Class Initialized
INFO - 2018-04-20 23:43:19 --> Output Class Initialized
INFO - 2018-04-20 23:43:19 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:19 --> CSRF cookie sent
INFO - 2018-04-20 23:43:19 --> Input Class Initialized
INFO - 2018-04-20 23:43:19 --> Language Class Initialized
INFO - 2018-04-20 23:43:19 --> Loader Class Initialized
INFO - 2018-04-20 23:43:19 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:19 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:19 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:19 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:19 --> Controller Class Initialized
INFO - 2018-04-20 23:43:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:19 --> Pixel_Model class loaded
INFO - 2018-04-20 23:43:19 --> Database Driver Class Initialized
INFO - 2018-04-20 23:43:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:43:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:43:19 --> Final output sent to browser
DEBUG - 2018-04-20 23:43:19 --> Total execution time: 0.6300
INFO - 2018-04-20 23:43:20 --> Config Class Initialized
INFO - 2018-04-20 23:43:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:20 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:20 --> URI Class Initialized
INFO - 2018-04-20 23:43:20 --> Router Class Initialized
INFO - 2018-04-20 23:43:20 --> Output Class Initialized
INFO - 2018-04-20 23:43:20 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:20 --> CSRF cookie sent
INFO - 2018-04-20 23:43:20 --> Input Class Initialized
INFO - 2018-04-20 23:43:20 --> Language Class Initialized
ERROR - 2018-04-20 23:43:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:43:55 --> Config Class Initialized
INFO - 2018-04-20 23:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:55 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:55 --> URI Class Initialized
INFO - 2018-04-20 23:43:55 --> Router Class Initialized
INFO - 2018-04-20 23:43:55 --> Output Class Initialized
INFO - 2018-04-20 23:43:55 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:55 --> CSRF cookie sent
INFO - 2018-04-20 23:43:55 --> Input Class Initialized
INFO - 2018-04-20 23:43:55 --> Language Class Initialized
INFO - 2018-04-20 23:43:55 --> Loader Class Initialized
INFO - 2018-04-20 23:43:55 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:55 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:55 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:55 --> Controller Class Initialized
INFO - 2018-04-20 23:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:55 --> CSRF cookie sent
INFO - 2018-04-20 23:43:55 --> Config Class Initialized
INFO - 2018-04-20 23:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:55 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:55 --> URI Class Initialized
DEBUG - 2018-04-20 23:43:55 --> No URI present. Default controller set.
INFO - 2018-04-20 23:43:55 --> Router Class Initialized
INFO - 2018-04-20 23:43:55 --> Output Class Initialized
INFO - 2018-04-20 23:43:55 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:55 --> CSRF cookie sent
INFO - 2018-04-20 23:43:55 --> Input Class Initialized
INFO - 2018-04-20 23:43:55 --> Language Class Initialized
INFO - 2018-04-20 23:43:55 --> Loader Class Initialized
INFO - 2018-04-20 23:43:55 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:55 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:55 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:55 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:55 --> Controller Class Initialized
INFO - 2018-04-20 23:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:43:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:43:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:43:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:43:56 --> Final output sent to browser
DEBUG - 2018-04-20 23:43:56 --> Total execution time: 0.4865
INFO - 2018-04-20 23:43:56 --> Config Class Initialized
INFO - 2018-04-20 23:43:56 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:56 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:56 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:56 --> URI Class Initialized
INFO - 2018-04-20 23:43:56 --> Router Class Initialized
INFO - 2018-04-20 23:43:56 --> Output Class Initialized
INFO - 2018-04-20 23:43:56 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:56 --> CSRF cookie sent
INFO - 2018-04-20 23:43:56 --> Input Class Initialized
INFO - 2018-04-20 23:43:56 --> Language Class Initialized
ERROR - 2018-04-20 23:43:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:43:58 --> Config Class Initialized
INFO - 2018-04-20 23:43:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:58 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:58 --> URI Class Initialized
INFO - 2018-04-20 23:43:58 --> Router Class Initialized
INFO - 2018-04-20 23:43:58 --> Output Class Initialized
INFO - 2018-04-20 23:43:58 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:58 --> CSRF cookie sent
INFO - 2018-04-20 23:43:58 --> Input Class Initialized
INFO - 2018-04-20 23:43:58 --> Language Class Initialized
ERROR - 2018-04-20 23:43:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:43:58 --> Config Class Initialized
INFO - 2018-04-20 23:43:58 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:58 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:58 --> Utf8 Class Initialized
INFO - 2018-04-20 23:43:58 --> URI Class Initialized
INFO - 2018-04-20 23:43:58 --> Router Class Initialized
INFO - 2018-04-20 23:43:58 --> Output Class Initialized
INFO - 2018-04-20 23:43:58 --> Security Class Initialized
DEBUG - 2018-04-20 23:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:43:58 --> CSRF cookie sent
INFO - 2018-04-20 23:43:58 --> Input Class Initialized
INFO - 2018-04-20 23:43:59 --> Language Class Initialized
INFO - 2018-04-20 23:43:59 --> Loader Class Initialized
INFO - 2018-04-20 23:43:59 --> Helper loaded: url_helper
INFO - 2018-04-20 23:43:59 --> Helper loaded: form_helper
INFO - 2018-04-20 23:43:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:43:59 --> User Agent Class Initialized
INFO - 2018-04-20 23:43:59 --> Controller Class Initialized
INFO - 2018-04-20 23:43:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:43:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:43:59 --> Pixel_Model class loaded
INFO - 2018-04-20 23:43:59 --> Database Driver Class Initialized
INFO - 2018-04-20 23:43:59 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:43:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:43:59 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:43:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:43:59 --> Final output sent to browser
DEBUG - 2018-04-20 23:43:59 --> Total execution time: 0.7498
INFO - 2018-04-20 23:43:59 --> Config Class Initialized
INFO - 2018-04-20 23:43:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:43:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:43:59 --> Utf8 Class Initialized
INFO - 2018-04-20 23:44:00 --> URI Class Initialized
INFO - 2018-04-20 23:44:00 --> Router Class Initialized
INFO - 2018-04-20 23:44:00 --> Output Class Initialized
INFO - 2018-04-20 23:44:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:44:00 --> CSRF cookie sent
INFO - 2018-04-20 23:44:00 --> Input Class Initialized
INFO - 2018-04-20 23:44:00 --> Language Class Initialized
ERROR - 2018-04-20 23:44:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:44:20 --> Config Class Initialized
INFO - 2018-04-20 23:44:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:44:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:44:20 --> Utf8 Class Initialized
INFO - 2018-04-20 23:44:20 --> URI Class Initialized
INFO - 2018-04-20 23:44:20 --> Router Class Initialized
INFO - 2018-04-20 23:44:20 --> Output Class Initialized
INFO - 2018-04-20 23:44:20 --> Security Class Initialized
DEBUG - 2018-04-20 23:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:44:20 --> CSRF cookie sent
INFO - 2018-04-20 23:44:20 --> Input Class Initialized
INFO - 2018-04-20 23:44:20 --> Language Class Initialized
INFO - 2018-04-20 23:44:20 --> Loader Class Initialized
INFO - 2018-04-20 23:44:20 --> Helper loaded: url_helper
INFO - 2018-04-20 23:44:20 --> Helper loaded: form_helper
INFO - 2018-04-20 23:44:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:44:20 --> User Agent Class Initialized
INFO - 2018-04-20 23:44:20 --> Controller Class Initialized
INFO - 2018-04-20 23:44:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:44:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:44:20 --> Pixel_Model class loaded
INFO - 2018-04-20 23:44:20 --> Database Driver Class Initialized
INFO - 2018-04-20 23:44:20 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:44:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:44:20 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:44:20 --> Final output sent to browser
DEBUG - 2018-04-20 23:44:20 --> Total execution time: 0.6410
INFO - 2018-04-20 23:44:21 --> Config Class Initialized
INFO - 2018-04-20 23:44:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:44:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:44:21 --> Utf8 Class Initialized
INFO - 2018-04-20 23:44:21 --> URI Class Initialized
INFO - 2018-04-20 23:44:21 --> Router Class Initialized
INFO - 2018-04-20 23:44:21 --> Output Class Initialized
INFO - 2018-04-20 23:44:21 --> Security Class Initialized
DEBUG - 2018-04-20 23:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:44:21 --> CSRF cookie sent
INFO - 2018-04-20 23:44:21 --> Input Class Initialized
INFO - 2018-04-20 23:44:21 --> Language Class Initialized
ERROR - 2018-04-20 23:44:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:44:37 --> Config Class Initialized
INFO - 2018-04-20 23:44:37 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:44:37 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:44:37 --> Utf8 Class Initialized
INFO - 2018-04-20 23:44:37 --> URI Class Initialized
INFO - 2018-04-20 23:44:37 --> Router Class Initialized
INFO - 2018-04-20 23:44:37 --> Output Class Initialized
INFO - 2018-04-20 23:44:37 --> Security Class Initialized
DEBUG - 2018-04-20 23:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:44:37 --> CSRF cookie sent
INFO - 2018-04-20 23:44:37 --> Input Class Initialized
INFO - 2018-04-20 23:44:37 --> Language Class Initialized
INFO - 2018-04-20 23:44:37 --> Loader Class Initialized
INFO - 2018-04-20 23:44:37 --> Helper loaded: url_helper
INFO - 2018-04-20 23:44:37 --> Helper loaded: form_helper
INFO - 2018-04-20 23:44:37 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:44:37 --> User Agent Class Initialized
INFO - 2018-04-20 23:44:37 --> Controller Class Initialized
INFO - 2018-04-20 23:44:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:44:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:44:37 --> Pixel_Model class loaded
INFO - 2018-04-20 23:44:37 --> Database Driver Class Initialized
INFO - 2018-04-20 23:44:37 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:44:37 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:44:37 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:44:37 --> Final output sent to browser
DEBUG - 2018-04-20 23:44:38 --> Total execution time: 0.6793
INFO - 2018-04-20 23:44:38 --> Config Class Initialized
INFO - 2018-04-20 23:44:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:44:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:44:38 --> Utf8 Class Initialized
INFO - 2018-04-20 23:44:38 --> URI Class Initialized
INFO - 2018-04-20 23:44:38 --> Router Class Initialized
INFO - 2018-04-20 23:44:38 --> Output Class Initialized
INFO - 2018-04-20 23:44:38 --> Security Class Initialized
DEBUG - 2018-04-20 23:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:44:38 --> CSRF cookie sent
INFO - 2018-04-20 23:44:38 --> Input Class Initialized
INFO - 2018-04-20 23:44:38 --> Language Class Initialized
ERROR - 2018-04-20 23:44:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:45:01 --> Config Class Initialized
INFO - 2018-04-20 23:45:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:45:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:45:01 --> Utf8 Class Initialized
INFO - 2018-04-20 23:45:01 --> URI Class Initialized
INFO - 2018-04-20 23:45:01 --> Router Class Initialized
INFO - 2018-04-20 23:45:01 --> Output Class Initialized
INFO - 2018-04-20 23:45:01 --> Security Class Initialized
DEBUG - 2018-04-20 23:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:45:01 --> CSRF cookie sent
INFO - 2018-04-20 23:45:01 --> Input Class Initialized
INFO - 2018-04-20 23:45:01 --> Language Class Initialized
INFO - 2018-04-20 23:45:01 --> Loader Class Initialized
INFO - 2018-04-20 23:45:01 --> Helper loaded: url_helper
INFO - 2018-04-20 23:45:01 --> Helper loaded: form_helper
INFO - 2018-04-20 23:45:01 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:45:01 --> User Agent Class Initialized
INFO - 2018-04-20 23:45:01 --> Controller Class Initialized
INFO - 2018-04-20 23:45:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:45:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:45:01 --> Pixel_Model class loaded
INFO - 2018-04-20 23:45:01 --> Database Driver Class Initialized
INFO - 2018-04-20 23:45:01 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-20 23:45:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:45:01 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-20 23:45:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:45:01 --> Final output sent to browser
DEBUG - 2018-04-20 23:45:01 --> Total execution time: 0.6295
INFO - 2018-04-20 23:45:02 --> Config Class Initialized
INFO - 2018-04-20 23:45:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:45:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:45:02 --> Utf8 Class Initialized
INFO - 2018-04-20 23:45:02 --> URI Class Initialized
INFO - 2018-04-20 23:45:02 --> Router Class Initialized
INFO - 2018-04-20 23:45:02 --> Output Class Initialized
INFO - 2018-04-20 23:45:02 --> Security Class Initialized
DEBUG - 2018-04-20 23:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:45:02 --> CSRF cookie sent
INFO - 2018-04-20 23:45:02 --> Input Class Initialized
INFO - 2018-04-20 23:45:02 --> Language Class Initialized
ERROR - 2018-04-20 23:45:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:45:51 --> Config Class Initialized
INFO - 2018-04-20 23:45:51 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:45:51 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:45:51 --> Utf8 Class Initialized
INFO - 2018-04-20 23:45:51 --> URI Class Initialized
INFO - 2018-04-20 23:45:51 --> Router Class Initialized
INFO - 2018-04-20 23:45:51 --> Output Class Initialized
INFO - 2018-04-20 23:45:51 --> Security Class Initialized
DEBUG - 2018-04-20 23:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:45:51 --> CSRF cookie sent
INFO - 2018-04-20 23:45:51 --> Input Class Initialized
INFO - 2018-04-20 23:45:51 --> Language Class Initialized
INFO - 2018-04-20 23:45:51 --> Loader Class Initialized
INFO - 2018-04-20 23:45:51 --> Helper loaded: url_helper
INFO - 2018-04-20 23:45:51 --> Helper loaded: form_helper
INFO - 2018-04-20 23:45:51 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:45:52 --> User Agent Class Initialized
INFO - 2018-04-20 23:45:52 --> Controller Class Initialized
INFO - 2018-04-20 23:45:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:45:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:45:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-20 23:45:52 --> Could not find the language line "req_email"
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-20 23:45:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:45:52 --> Final output sent to browser
DEBUG - 2018-04-20 23:45:52 --> Total execution time: 0.5660
INFO - 2018-04-20 23:45:52 --> Config Class Initialized
INFO - 2018-04-20 23:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:45:52 --> Utf8 Class Initialized
INFO - 2018-04-20 23:45:52 --> URI Class Initialized
INFO - 2018-04-20 23:45:52 --> Router Class Initialized
INFO - 2018-04-20 23:45:52 --> Output Class Initialized
INFO - 2018-04-20 23:45:52 --> Security Class Initialized
DEBUG - 2018-04-20 23:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:45:52 --> CSRF cookie sent
INFO - 2018-04-20 23:45:52 --> Input Class Initialized
INFO - 2018-04-20 23:45:52 --> Language Class Initialized
ERROR - 2018-04-20 23:45:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:45:58 --> Config Class Initialized
INFO - 2018-04-20 23:45:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:45:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:45:59 --> Utf8 Class Initialized
INFO - 2018-04-20 23:45:59 --> URI Class Initialized
INFO - 2018-04-20 23:45:59 --> Router Class Initialized
INFO - 2018-04-20 23:45:59 --> Output Class Initialized
INFO - 2018-04-20 23:45:59 --> Security Class Initialized
DEBUG - 2018-04-20 23:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:45:59 --> CSRF cookie sent
INFO - 2018-04-20 23:45:59 --> CSRF token verified
INFO - 2018-04-20 23:45:59 --> Input Class Initialized
INFO - 2018-04-20 23:45:59 --> Language Class Initialized
INFO - 2018-04-20 23:45:59 --> Loader Class Initialized
INFO - 2018-04-20 23:45:59 --> Helper loaded: url_helper
INFO - 2018-04-20 23:45:59 --> Helper loaded: form_helper
INFO - 2018-04-20 23:45:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:45:59 --> User Agent Class Initialized
INFO - 2018-04-20 23:45:59 --> Controller Class Initialized
INFO - 2018-04-20 23:45:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:45:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-20 23:45:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-20 23:45:59 --> Form Validation Class Initialized
INFO - 2018-04-20 23:45:59 --> Pixel_Model class loaded
INFO - 2018-04-20 23:45:59 --> Database Driver Class Initialized
INFO - 2018-04-20 23:45:59 --> Model "AuthenticationModel" initialized
INFO - 2018-04-20 23:46:00 --> Config Class Initialized
INFO - 2018-04-20 23:46:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:00 --> URI Class Initialized
DEBUG - 2018-04-20 23:46:00 --> No URI present. Default controller set.
INFO - 2018-04-20 23:46:00 --> Router Class Initialized
INFO - 2018-04-20 23:46:00 --> Output Class Initialized
INFO - 2018-04-20 23:46:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:00 --> CSRF cookie sent
INFO - 2018-04-20 23:46:00 --> Input Class Initialized
INFO - 2018-04-20 23:46:00 --> Language Class Initialized
INFO - 2018-04-20 23:46:00 --> Loader Class Initialized
INFO - 2018-04-20 23:46:00 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:00 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:00 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:00 --> Controller Class Initialized
INFO - 2018-04-20 23:46:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:46:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-20 23:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:46:00 --> Final output sent to browser
DEBUG - 2018-04-20 23:46:00 --> Total execution time: 0.5162
INFO - 2018-04-20 23:46:00 --> Config Class Initialized
INFO - 2018-04-20 23:46:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:01 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:01 --> URI Class Initialized
INFO - 2018-04-20 23:46:01 --> Router Class Initialized
INFO - 2018-04-20 23:46:01 --> Output Class Initialized
INFO - 2018-04-20 23:46:01 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:01 --> CSRF cookie sent
INFO - 2018-04-20 23:46:01 --> Input Class Initialized
INFO - 2018-04-20 23:46:01 --> Language Class Initialized
ERROR - 2018-04-20 23:46:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:46:02 --> Config Class Initialized
INFO - 2018-04-20 23:46:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:02 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:03 --> URI Class Initialized
INFO - 2018-04-20 23:46:03 --> Router Class Initialized
INFO - 2018-04-20 23:46:03 --> Output Class Initialized
INFO - 2018-04-20 23:46:03 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:03 --> CSRF cookie sent
INFO - 2018-04-20 23:46:03 --> Input Class Initialized
INFO - 2018-04-20 23:46:03 --> Language Class Initialized
ERROR - 2018-04-20 23:46:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-20 23:46:03 --> Config Class Initialized
INFO - 2018-04-20 23:46:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:03 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:03 --> URI Class Initialized
INFO - 2018-04-20 23:46:03 --> Router Class Initialized
INFO - 2018-04-20 23:46:03 --> Output Class Initialized
INFO - 2018-04-20 23:46:03 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:03 --> CSRF cookie sent
INFO - 2018-04-20 23:46:03 --> Input Class Initialized
INFO - 2018-04-20 23:46:03 --> Language Class Initialized
INFO - 2018-04-20 23:46:03 --> Loader Class Initialized
INFO - 2018-04-20 23:46:03 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:03 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:03 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:03 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:03 --> Controller Class Initialized
INFO - 2018-04-20 23:46:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:04 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:04 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:04 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-20 23:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:46:04 --> Final output sent to browser
DEBUG - 2018-04-20 23:46:04 --> Total execution time: 0.6725
INFO - 2018-04-20 23:46:04 --> Config Class Initialized
INFO - 2018-04-20 23:46:04 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:04 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:04 --> URI Class Initialized
INFO - 2018-04-20 23:46:04 --> Router Class Initialized
INFO - 2018-04-20 23:46:04 --> Output Class Initialized
INFO - 2018-04-20 23:46:04 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:04 --> CSRF cookie sent
INFO - 2018-04-20 23:46:04 --> Input Class Initialized
INFO - 2018-04-20 23:46:04 --> Language Class Initialized
ERROR - 2018-04-20 23:46:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:46:07 --> Config Class Initialized
INFO - 2018-04-20 23:46:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:07 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:07 --> URI Class Initialized
INFO - 2018-04-20 23:46:07 --> Router Class Initialized
INFO - 2018-04-20 23:46:07 --> Output Class Initialized
INFO - 2018-04-20 23:46:07 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:07 --> CSRF cookie sent
INFO - 2018-04-20 23:46:07 --> CSRF token verified
INFO - 2018-04-20 23:46:07 --> Input Class Initialized
INFO - 2018-04-20 23:46:07 --> Language Class Initialized
INFO - 2018-04-20 23:46:07 --> Loader Class Initialized
INFO - 2018-04-20 23:46:07 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:07 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:07 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:07 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:07 --> Controller Class Initialized
INFO - 2018-04-20 23:46:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:07 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:07 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:07 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:07 --> Form Validation Class Initialized
INFO - 2018-04-20 23:46:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:46:08 --> Config Class Initialized
INFO - 2018-04-20 23:46:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:08 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:08 --> URI Class Initialized
INFO - 2018-04-20 23:46:08 --> Router Class Initialized
INFO - 2018-04-20 23:46:08 --> Output Class Initialized
INFO - 2018-04-20 23:46:08 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:08 --> CSRF cookie sent
INFO - 2018-04-20 23:46:08 --> Input Class Initialized
INFO - 2018-04-20 23:46:08 --> Language Class Initialized
INFO - 2018-04-20 23:46:08 --> Loader Class Initialized
INFO - 2018-04-20 23:46:08 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:08 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:08 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:08 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:08 --> Controller Class Initialized
INFO - 2018-04-20 23:46:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:08 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:08 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:08 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:46:08 --> Final output sent to browser
DEBUG - 2018-04-20 23:46:08 --> Total execution time: 0.6153
INFO - 2018-04-20 23:46:08 --> Config Class Initialized
INFO - 2018-04-20 23:46:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:09 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:09 --> URI Class Initialized
INFO - 2018-04-20 23:46:09 --> Router Class Initialized
INFO - 2018-04-20 23:46:09 --> Output Class Initialized
INFO - 2018-04-20 23:46:09 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:09 --> CSRF cookie sent
INFO - 2018-04-20 23:46:09 --> Input Class Initialized
INFO - 2018-04-20 23:46:09 --> Language Class Initialized
ERROR - 2018-04-20 23:46:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:46:14 --> Config Class Initialized
INFO - 2018-04-20 23:46:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:14 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:14 --> URI Class Initialized
INFO - 2018-04-20 23:46:14 --> Router Class Initialized
INFO - 2018-04-20 23:46:14 --> Output Class Initialized
INFO - 2018-04-20 23:46:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:14 --> CSRF cookie sent
INFO - 2018-04-20 23:46:14 --> CSRF token verified
INFO - 2018-04-20 23:46:14 --> Input Class Initialized
INFO - 2018-04-20 23:46:14 --> Language Class Initialized
INFO - 2018-04-20 23:46:14 --> Loader Class Initialized
INFO - 2018-04-20 23:46:14 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:14 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:14 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:14 --> Controller Class Initialized
INFO - 2018-04-20 23:46:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:14 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:14 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:14 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:14 --> Form Validation Class Initialized
INFO - 2018-04-20 23:46:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:46:14 --> Config Class Initialized
INFO - 2018-04-20 23:46:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:14 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:14 --> URI Class Initialized
INFO - 2018-04-20 23:46:14 --> Router Class Initialized
INFO - 2018-04-20 23:46:14 --> Output Class Initialized
INFO - 2018-04-20 23:46:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:14 --> CSRF cookie sent
INFO - 2018-04-20 23:46:15 --> Input Class Initialized
INFO - 2018-04-20 23:46:15 --> Language Class Initialized
INFO - 2018-04-20 23:46:15 --> Loader Class Initialized
INFO - 2018-04-20 23:46:15 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:15 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:15 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:15 --> Controller Class Initialized
INFO - 2018-04-20 23:46:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:15 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:15 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 23:46:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:46:15 --> Final output sent to browser
DEBUG - 2018-04-20 23:46:15 --> Total execution time: 0.6534
INFO - 2018-04-20 23:46:15 --> Config Class Initialized
INFO - 2018-04-20 23:46:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:15 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:15 --> URI Class Initialized
INFO - 2018-04-20 23:46:15 --> Router Class Initialized
INFO - 2018-04-20 23:46:15 --> Output Class Initialized
INFO - 2018-04-20 23:46:15 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:16 --> CSRF cookie sent
INFO - 2018-04-20 23:46:16 --> Input Class Initialized
INFO - 2018-04-20 23:46:16 --> Language Class Initialized
ERROR - 2018-04-20 23:46:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:46:22 --> Config Class Initialized
INFO - 2018-04-20 23:46:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:22 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:22 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:22 --> URI Class Initialized
INFO - 2018-04-20 23:46:22 --> Router Class Initialized
INFO - 2018-04-20 23:46:22 --> Output Class Initialized
INFO - 2018-04-20 23:46:22 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:22 --> CSRF cookie sent
INFO - 2018-04-20 23:46:22 --> CSRF token verified
INFO - 2018-04-20 23:46:22 --> Input Class Initialized
INFO - 2018-04-20 23:46:22 --> Language Class Initialized
INFO - 2018-04-20 23:46:22 --> Loader Class Initialized
INFO - 2018-04-20 23:46:22 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:22 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:22 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:22 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:22 --> Controller Class Initialized
INFO - 2018-04-20 23:46:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:22 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:22 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:22 --> Form Validation Class Initialized
INFO - 2018-04-20 23:46:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:46:22 --> Config Class Initialized
INFO - 2018-04-20 23:46:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:23 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:23 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:23 --> URI Class Initialized
INFO - 2018-04-20 23:46:23 --> Router Class Initialized
INFO - 2018-04-20 23:46:23 --> Output Class Initialized
INFO - 2018-04-20 23:46:23 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:23 --> CSRF cookie sent
INFO - 2018-04-20 23:46:23 --> Input Class Initialized
INFO - 2018-04-20 23:46:23 --> Language Class Initialized
INFO - 2018-04-20 23:46:23 --> Loader Class Initialized
INFO - 2018-04-20 23:46:23 --> Helper loaded: url_helper
INFO - 2018-04-20 23:46:23 --> Helper loaded: form_helper
INFO - 2018-04-20 23:46:23 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:46:23 --> User Agent Class Initialized
INFO - 2018-04-20 23:46:23 --> Controller Class Initialized
INFO - 2018-04-20 23:46:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:46:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:46:23 --> Pixel_Model class loaded
INFO - 2018-04-20 23:46:23 --> Database Driver Class Initialized
INFO - 2018-04-20 23:46:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:46:23 --> Final output sent to browser
DEBUG - 2018-04-20 23:46:23 --> Total execution time: 0.6396
INFO - 2018-04-20 23:46:23 --> Config Class Initialized
INFO - 2018-04-20 23:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:46:24 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:46:24 --> Utf8 Class Initialized
INFO - 2018-04-20 23:46:24 --> URI Class Initialized
INFO - 2018-04-20 23:46:24 --> Router Class Initialized
INFO - 2018-04-20 23:46:24 --> Output Class Initialized
INFO - 2018-04-20 23:46:24 --> Security Class Initialized
DEBUG - 2018-04-20 23:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:46:24 --> CSRF cookie sent
INFO - 2018-04-20 23:46:24 --> Input Class Initialized
INFO - 2018-04-20 23:46:24 --> Language Class Initialized
ERROR - 2018-04-20 23:46:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:00 --> Config Class Initialized
INFO - 2018-04-20 23:50:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:00 --> URI Class Initialized
INFO - 2018-04-20 23:50:00 --> Router Class Initialized
INFO - 2018-04-20 23:50:00 --> Output Class Initialized
INFO - 2018-04-20 23:50:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:00 --> CSRF cookie sent
INFO - 2018-04-20 23:50:00 --> Input Class Initialized
INFO - 2018-04-20 23:50:00 --> Language Class Initialized
INFO - 2018-04-20 23:50:00 --> Loader Class Initialized
INFO - 2018-04-20 23:50:00 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:00 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:00 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:00 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:00 --> Controller Class Initialized
INFO - 2018-04-20 23:50:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:00 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:00 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:50:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:01 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:01 --> Total execution time: 0.6398
INFO - 2018-04-20 23:50:01 --> Config Class Initialized
INFO - 2018-04-20 23:50:01 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:01 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:01 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:01 --> URI Class Initialized
INFO - 2018-04-20 23:50:01 --> Router Class Initialized
INFO - 2018-04-20 23:50:01 --> Output Class Initialized
INFO - 2018-04-20 23:50:01 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:01 --> CSRF cookie sent
INFO - 2018-04-20 23:50:01 --> Input Class Initialized
INFO - 2018-04-20 23:50:01 --> Language Class Initialized
ERROR - 2018-04-20 23:50:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:05 --> Config Class Initialized
INFO - 2018-04-20 23:50:05 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:05 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:05 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:05 --> URI Class Initialized
INFO - 2018-04-20 23:50:05 --> Router Class Initialized
INFO - 2018-04-20 23:50:05 --> Output Class Initialized
INFO - 2018-04-20 23:50:05 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:05 --> CSRF cookie sent
INFO - 2018-04-20 23:50:06 --> CSRF token verified
INFO - 2018-04-20 23:50:06 --> Input Class Initialized
INFO - 2018-04-20 23:50:06 --> Language Class Initialized
INFO - 2018-04-20 23:50:06 --> Loader Class Initialized
INFO - 2018-04-20 23:50:06 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:06 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:06 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:06 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:06 --> Controller Class Initialized
INFO - 2018-04-20 23:50:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:06 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:06 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:06 --> Form Validation Class Initialized
INFO - 2018-04-20 23:50:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:50:06 --> Config Class Initialized
INFO - 2018-04-20 23:50:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:06 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:06 --> URI Class Initialized
INFO - 2018-04-20 23:50:06 --> Router Class Initialized
INFO - 2018-04-20 23:50:06 --> Output Class Initialized
INFO - 2018-04-20 23:50:06 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:06 --> CSRF cookie sent
INFO - 2018-04-20 23:50:06 --> Input Class Initialized
INFO - 2018-04-20 23:50:06 --> Language Class Initialized
INFO - 2018-04-20 23:50:06 --> Loader Class Initialized
INFO - 2018-04-20 23:50:06 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:06 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:06 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:06 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:06 --> Controller Class Initialized
INFO - 2018-04-20 23:50:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:06 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:06 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:07 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:50:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:07 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:07 --> Total execution time: 0.6312
INFO - 2018-04-20 23:50:07 --> Config Class Initialized
INFO - 2018-04-20 23:50:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:07 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:07 --> URI Class Initialized
INFO - 2018-04-20 23:50:07 --> Router Class Initialized
INFO - 2018-04-20 23:50:07 --> Output Class Initialized
INFO - 2018-04-20 23:50:07 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:07 --> CSRF cookie sent
INFO - 2018-04-20 23:50:07 --> Input Class Initialized
INFO - 2018-04-20 23:50:07 --> Language Class Initialized
ERROR - 2018-04-20 23:50:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:09 --> Config Class Initialized
INFO - 2018-04-20 23:50:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:09 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:09 --> URI Class Initialized
INFO - 2018-04-20 23:50:09 --> Router Class Initialized
INFO - 2018-04-20 23:50:09 --> Output Class Initialized
INFO - 2018-04-20 23:50:09 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:09 --> CSRF cookie sent
INFO - 2018-04-20 23:50:09 --> Input Class Initialized
INFO - 2018-04-20 23:50:09 --> Language Class Initialized
INFO - 2018-04-20 23:50:09 --> Loader Class Initialized
INFO - 2018-04-20 23:50:09 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:09 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:09 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:09 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:09 --> Controller Class Initialized
INFO - 2018-04-20 23:50:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:09 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:09 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:10 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:10 --> Total execution time: 0.6269
INFO - 2018-04-20 23:50:10 --> Config Class Initialized
INFO - 2018-04-20 23:50:10 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:10 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:10 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:10 --> URI Class Initialized
INFO - 2018-04-20 23:50:10 --> Router Class Initialized
INFO - 2018-04-20 23:50:10 --> Output Class Initialized
INFO - 2018-04-20 23:50:10 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:10 --> CSRF cookie sent
INFO - 2018-04-20 23:50:10 --> Input Class Initialized
INFO - 2018-04-20 23:50:10 --> Language Class Initialized
ERROR - 2018-04-20 23:50:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:12 --> Config Class Initialized
INFO - 2018-04-20 23:50:12 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:12 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:12 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:12 --> URI Class Initialized
INFO - 2018-04-20 23:50:12 --> Router Class Initialized
INFO - 2018-04-20 23:50:12 --> Output Class Initialized
INFO - 2018-04-20 23:50:12 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:12 --> CSRF cookie sent
INFO - 2018-04-20 23:50:12 --> Input Class Initialized
INFO - 2018-04-20 23:50:12 --> Language Class Initialized
INFO - 2018-04-20 23:50:12 --> Loader Class Initialized
INFO - 2018-04-20 23:50:12 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:12 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:12 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:12 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:12 --> Controller Class Initialized
INFO - 2018-04-20 23:50:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:12 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:13 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:13 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:50:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:13 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:13 --> Total execution time: 0.6500
INFO - 2018-04-20 23:50:13 --> Config Class Initialized
INFO - 2018-04-20 23:50:13 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:13 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:13 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:13 --> URI Class Initialized
INFO - 2018-04-20 23:50:13 --> Router Class Initialized
INFO - 2018-04-20 23:50:13 --> Output Class Initialized
INFO - 2018-04-20 23:50:13 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:13 --> CSRF cookie sent
INFO - 2018-04-20 23:50:13 --> Input Class Initialized
INFO - 2018-04-20 23:50:13 --> Language Class Initialized
ERROR - 2018-04-20 23:50:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:38 --> Config Class Initialized
INFO - 2018-04-20 23:50:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:38 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:38 --> URI Class Initialized
INFO - 2018-04-20 23:50:38 --> Router Class Initialized
INFO - 2018-04-20 23:50:38 --> Output Class Initialized
INFO - 2018-04-20 23:50:38 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:38 --> CSRF cookie sent
INFO - 2018-04-20 23:50:38 --> Input Class Initialized
INFO - 2018-04-20 23:50:38 --> Language Class Initialized
INFO - 2018-04-20 23:50:38 --> Loader Class Initialized
INFO - 2018-04-20 23:50:38 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:38 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:38 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:38 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:38 --> Controller Class Initialized
INFO - 2018-04-20 23:50:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:38 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:38 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:50:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:39 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:39 --> Total execution time: 0.6713
INFO - 2018-04-20 23:50:39 --> Config Class Initialized
INFO - 2018-04-20 23:50:39 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:39 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:39 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:39 --> URI Class Initialized
INFO - 2018-04-20 23:50:39 --> Router Class Initialized
INFO - 2018-04-20 23:50:39 --> Output Class Initialized
INFO - 2018-04-20 23:50:39 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:39 --> CSRF cookie sent
INFO - 2018-04-20 23:50:39 --> Input Class Initialized
INFO - 2018-04-20 23:50:39 --> Language Class Initialized
ERROR - 2018-04-20 23:50:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:49 --> Config Class Initialized
INFO - 2018-04-20 23:50:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:49 --> URI Class Initialized
INFO - 2018-04-20 23:50:49 --> Router Class Initialized
INFO - 2018-04-20 23:50:49 --> Output Class Initialized
INFO - 2018-04-20 23:50:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:49 --> CSRF cookie sent
INFO - 2018-04-20 23:50:49 --> CSRF token verified
INFO - 2018-04-20 23:50:49 --> Input Class Initialized
INFO - 2018-04-20 23:50:49 --> Language Class Initialized
INFO - 2018-04-20 23:50:49 --> Loader Class Initialized
INFO - 2018-04-20 23:50:49 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:49 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:49 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:49 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:49 --> Controller Class Initialized
INFO - 2018-04-20 23:50:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:49 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:49 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:49 --> Form Validation Class Initialized
INFO - 2018-04-20 23:50:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:50:49 --> Config Class Initialized
INFO - 2018-04-20 23:50:49 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:49 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:49 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:49 --> URI Class Initialized
INFO - 2018-04-20 23:50:49 --> Router Class Initialized
INFO - 2018-04-20 23:50:49 --> Output Class Initialized
INFO - 2018-04-20 23:50:49 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:49 --> CSRF cookie sent
INFO - 2018-04-20 23:50:49 --> Input Class Initialized
INFO - 2018-04-20 23:50:49 --> Language Class Initialized
INFO - 2018-04-20 23:50:49 --> Loader Class Initialized
INFO - 2018-04-20 23:50:49 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:49 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:49 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:50 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:50 --> Controller Class Initialized
INFO - 2018-04-20 23:50:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:50 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:50 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:50:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:50 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:50 --> Total execution time: 0.6393
INFO - 2018-04-20 23:50:50 --> Config Class Initialized
INFO - 2018-04-20 23:50:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:50 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:50 --> URI Class Initialized
INFO - 2018-04-20 23:50:50 --> Router Class Initialized
INFO - 2018-04-20 23:50:50 --> Output Class Initialized
INFO - 2018-04-20 23:50:50 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:50 --> CSRF cookie sent
INFO - 2018-04-20 23:50:50 --> Input Class Initialized
INFO - 2018-04-20 23:50:51 --> Language Class Initialized
ERROR - 2018-04-20 23:50:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:50:59 --> Config Class Initialized
INFO - 2018-04-20 23:50:59 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:50:59 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:50:59 --> Utf8 Class Initialized
INFO - 2018-04-20 23:50:59 --> URI Class Initialized
INFO - 2018-04-20 23:50:59 --> Router Class Initialized
INFO - 2018-04-20 23:50:59 --> Output Class Initialized
INFO - 2018-04-20 23:50:59 --> Security Class Initialized
DEBUG - 2018-04-20 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:50:59 --> CSRF cookie sent
INFO - 2018-04-20 23:50:59 --> Input Class Initialized
INFO - 2018-04-20 23:50:59 --> Language Class Initialized
INFO - 2018-04-20 23:50:59 --> Loader Class Initialized
INFO - 2018-04-20 23:50:59 --> Helper loaded: url_helper
INFO - 2018-04-20 23:50:59 --> Helper loaded: form_helper
INFO - 2018-04-20 23:50:59 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:50:59 --> User Agent Class Initialized
INFO - 2018-04-20 23:50:59 --> Controller Class Initialized
INFO - 2018-04-20 23:50:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:50:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:50:59 --> Pixel_Model class loaded
INFO - 2018-04-20 23:50:59 --> Database Driver Class Initialized
INFO - 2018-04-20 23:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-20 23:50:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:50:59 --> Final output sent to browser
DEBUG - 2018-04-20 23:50:59 --> Total execution time: 0.6226
INFO - 2018-04-20 23:51:00 --> Config Class Initialized
INFO - 2018-04-20 23:51:00 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:00 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:00 --> URI Class Initialized
INFO - 2018-04-20 23:51:00 --> Router Class Initialized
INFO - 2018-04-20 23:51:00 --> Output Class Initialized
INFO - 2018-04-20 23:51:00 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:00 --> CSRF cookie sent
INFO - 2018-04-20 23:51:00 --> Input Class Initialized
INFO - 2018-04-20 23:51:00 --> Language Class Initialized
ERROR - 2018-04-20 23:51:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:51:14 --> Config Class Initialized
INFO - 2018-04-20 23:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:14 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:14 --> URI Class Initialized
INFO - 2018-04-20 23:51:14 --> Router Class Initialized
INFO - 2018-04-20 23:51:14 --> Output Class Initialized
INFO - 2018-04-20 23:51:14 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:14 --> CSRF cookie sent
INFO - 2018-04-20 23:51:14 --> CSRF token verified
INFO - 2018-04-20 23:51:14 --> Input Class Initialized
INFO - 2018-04-20 23:51:14 --> Language Class Initialized
INFO - 2018-04-20 23:51:14 --> Loader Class Initialized
INFO - 2018-04-20 23:51:14 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:14 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:14 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:14 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:14 --> Controller Class Initialized
INFO - 2018-04-20 23:51:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:14 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:15 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:15 --> Form Validation Class Initialized
INFO - 2018-04-20 23:51:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:51:15 --> Config Class Initialized
INFO - 2018-04-20 23:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:15 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:15 --> URI Class Initialized
INFO - 2018-04-20 23:51:15 --> Router Class Initialized
INFO - 2018-04-20 23:51:15 --> Output Class Initialized
INFO - 2018-04-20 23:51:15 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:15 --> CSRF cookie sent
INFO - 2018-04-20 23:51:15 --> Input Class Initialized
INFO - 2018-04-20 23:51:15 --> Language Class Initialized
INFO - 2018-04-20 23:51:15 --> Loader Class Initialized
INFO - 2018-04-20 23:51:15 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:15 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:15 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:15 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:15 --> Controller Class Initialized
INFO - 2018-04-20 23:51:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:15 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:15 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:51:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:51:15 --> Final output sent to browser
DEBUG - 2018-04-20 23:51:15 --> Total execution time: 0.6469
INFO - 2018-04-20 23:51:16 --> Config Class Initialized
INFO - 2018-04-20 23:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:16 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:16 --> URI Class Initialized
INFO - 2018-04-20 23:51:16 --> Router Class Initialized
INFO - 2018-04-20 23:51:16 --> Output Class Initialized
INFO - 2018-04-20 23:51:16 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:16 --> CSRF cookie sent
INFO - 2018-04-20 23:51:16 --> Input Class Initialized
INFO - 2018-04-20 23:51:16 --> Language Class Initialized
ERROR - 2018-04-20 23:51:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:51:20 --> Config Class Initialized
INFO - 2018-04-20 23:51:20 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:20 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:20 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:20 --> URI Class Initialized
INFO - 2018-04-20 23:51:20 --> Router Class Initialized
INFO - 2018-04-20 23:51:20 --> Output Class Initialized
INFO - 2018-04-20 23:51:20 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:20 --> CSRF cookie sent
INFO - 2018-04-20 23:51:20 --> CSRF token verified
INFO - 2018-04-20 23:51:20 --> Input Class Initialized
INFO - 2018-04-20 23:51:20 --> Language Class Initialized
INFO - 2018-04-20 23:51:20 --> Loader Class Initialized
INFO - 2018-04-20 23:51:20 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:20 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:20 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:20 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:20 --> Controller Class Initialized
INFO - 2018-04-20 23:51:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:20 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:20 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:21 --> Form Validation Class Initialized
INFO - 2018-04-20 23:51:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:51:21 --> Config Class Initialized
INFO - 2018-04-20 23:51:21 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:21 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:21 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:21 --> URI Class Initialized
INFO - 2018-04-20 23:51:21 --> Router Class Initialized
INFO - 2018-04-20 23:51:21 --> Output Class Initialized
INFO - 2018-04-20 23:51:21 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:21 --> CSRF cookie sent
INFO - 2018-04-20 23:51:21 --> Input Class Initialized
INFO - 2018-04-20 23:51:21 --> Language Class Initialized
INFO - 2018-04-20 23:51:21 --> Loader Class Initialized
INFO - 2018-04-20 23:51:21 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:21 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:21 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:21 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:21 --> Controller Class Initialized
INFO - 2018-04-20 23:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:21 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:21 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-20 23:51:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:51:21 --> Final output sent to browser
DEBUG - 2018-04-20 23:51:21 --> Total execution time: 0.6536
INFO - 2018-04-20 23:51:22 --> Config Class Initialized
INFO - 2018-04-20 23:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:22 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:22 --> URI Class Initialized
INFO - 2018-04-20 23:51:22 --> Router Class Initialized
INFO - 2018-04-20 23:51:22 --> Output Class Initialized
INFO - 2018-04-20 23:51:22 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:22 --> CSRF cookie sent
INFO - 2018-04-20 23:51:22 --> Input Class Initialized
INFO - 2018-04-20 23:51:22 --> Language Class Initialized
ERROR - 2018-04-20 23:51:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:51:27 --> Config Class Initialized
INFO - 2018-04-20 23:51:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:27 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:27 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:27 --> URI Class Initialized
INFO - 2018-04-20 23:51:27 --> Router Class Initialized
INFO - 2018-04-20 23:51:27 --> Output Class Initialized
INFO - 2018-04-20 23:51:27 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:27 --> CSRF cookie sent
INFO - 2018-04-20 23:51:27 --> CSRF token verified
INFO - 2018-04-20 23:51:27 --> Input Class Initialized
INFO - 2018-04-20 23:51:27 --> Language Class Initialized
INFO - 2018-04-20 23:51:27 --> Loader Class Initialized
INFO - 2018-04-20 23:51:27 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:27 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:27 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:27 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:27 --> Controller Class Initialized
INFO - 2018-04-20 23:51:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:27 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:27 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:27 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:27 --> Form Validation Class Initialized
INFO - 2018-04-20 23:51:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:51:27 --> Config Class Initialized
INFO - 2018-04-20 23:51:27 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:28 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:28 --> URI Class Initialized
INFO - 2018-04-20 23:51:28 --> Router Class Initialized
INFO - 2018-04-20 23:51:28 --> Output Class Initialized
INFO - 2018-04-20 23:51:28 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:28 --> CSRF cookie sent
INFO - 2018-04-20 23:51:28 --> Input Class Initialized
INFO - 2018-04-20 23:51:28 --> Language Class Initialized
INFO - 2018-04-20 23:51:28 --> Loader Class Initialized
INFO - 2018-04-20 23:51:28 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:28 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:28 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:28 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:28 --> Controller Class Initialized
INFO - 2018-04-20 23:51:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:28 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:28 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-04-20 23:51:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:51:28 --> Final output sent to browser
DEBUG - 2018-04-20 23:51:28 --> Total execution time: 0.6348
INFO - 2018-04-20 23:51:28 --> Config Class Initialized
INFO - 2018-04-20 23:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:29 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:29 --> URI Class Initialized
INFO - 2018-04-20 23:51:29 --> Router Class Initialized
INFO - 2018-04-20 23:51:29 --> Output Class Initialized
INFO - 2018-04-20 23:51:29 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:29 --> CSRF cookie sent
INFO - 2018-04-20 23:51:29 --> Input Class Initialized
INFO - 2018-04-20 23:51:29 --> Language Class Initialized
ERROR - 2018-04-20 23:51:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-20 23:51:35 --> Config Class Initialized
INFO - 2018-04-20 23:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:35 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:35 --> URI Class Initialized
INFO - 2018-04-20 23:51:35 --> Router Class Initialized
INFO - 2018-04-20 23:51:35 --> Output Class Initialized
INFO - 2018-04-20 23:51:35 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:35 --> CSRF cookie sent
INFO - 2018-04-20 23:51:35 --> CSRF token verified
INFO - 2018-04-20 23:51:35 --> Input Class Initialized
INFO - 2018-04-20 23:51:35 --> Language Class Initialized
INFO - 2018-04-20 23:51:35 --> Loader Class Initialized
INFO - 2018-04-20 23:51:35 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:35 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:35 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:35 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:35 --> Controller Class Initialized
INFO - 2018-04-20 23:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:35 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:36 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:36 --> Form Validation Class Initialized
INFO - 2018-04-20 23:51:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-20 23:51:36 --> Config Class Initialized
INFO - 2018-04-20 23:51:36 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:36 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:36 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:36 --> URI Class Initialized
INFO - 2018-04-20 23:51:36 --> Router Class Initialized
INFO - 2018-04-20 23:51:36 --> Output Class Initialized
INFO - 2018-04-20 23:51:36 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:36 --> CSRF cookie sent
INFO - 2018-04-20 23:51:36 --> Input Class Initialized
INFO - 2018-04-20 23:51:36 --> Language Class Initialized
INFO - 2018-04-20 23:51:36 --> Loader Class Initialized
INFO - 2018-04-20 23:51:36 --> Helper loaded: url_helper
INFO - 2018-04-20 23:51:36 --> Helper loaded: form_helper
INFO - 2018-04-20 23:51:36 --> Helper loaded: language_helper
DEBUG - 2018-04-20 23:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 23:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 23:51:36 --> User Agent Class Initialized
INFO - 2018-04-20 23:51:36 --> Controller Class Initialized
INFO - 2018-04-20 23:51:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-20 23:51:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-20 23:51:36 --> Pixel_Model class loaded
INFO - 2018-04-20 23:51:36 --> Database Driver Class Initialized
INFO - 2018-04-20 23:51:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-20 23:51:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-20 23:51:36 --> Final output sent to browser
DEBUG - 2018-04-20 23:51:36 --> Total execution time: 0.6423
INFO - 2018-04-20 23:51:37 --> Config Class Initialized
INFO - 2018-04-20 23:51:37 --> Hooks Class Initialized
DEBUG - 2018-04-20 23:51:37 --> UTF-8 Support Enabled
INFO - 2018-04-20 23:51:37 --> Utf8 Class Initialized
INFO - 2018-04-20 23:51:37 --> URI Class Initialized
INFO - 2018-04-20 23:51:37 --> Router Class Initialized
INFO - 2018-04-20 23:51:37 --> Output Class Initialized
INFO - 2018-04-20 23:51:37 --> Security Class Initialized
DEBUG - 2018-04-20 23:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 23:51:37 --> CSRF cookie sent
INFO - 2018-04-20 23:51:37 --> Input Class Initialized
INFO - 2018-04-20 23:51:37 --> Language Class Initialized
ERROR - 2018-04-20 23:51:37 --> 404 Page Not Found: Assets/css

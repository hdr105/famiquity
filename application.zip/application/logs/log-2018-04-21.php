<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-21 00:16:31 --> Config Class Initialized
INFO - 2018-04-21 00:16:31 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:31 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:31 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:31 --> URI Class Initialized
DEBUG - 2018-04-21 00:16:31 --> No URI present. Default controller set.
INFO - 2018-04-21 00:16:31 --> Router Class Initialized
INFO - 2018-04-21 00:16:31 --> Output Class Initialized
INFO - 2018-04-21 00:16:31 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:31 --> CSRF cookie sent
INFO - 2018-04-21 00:16:31 --> Input Class Initialized
INFO - 2018-04-21 00:16:31 --> Language Class Initialized
INFO - 2018-04-21 00:16:31 --> Loader Class Initialized
INFO - 2018-04-21 00:16:31 --> Helper loaded: url_helper
INFO - 2018-04-21 00:16:31 --> Helper loaded: form_helper
INFO - 2018-04-21 00:16:31 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:16:31 --> User Agent Class Initialized
INFO - 2018-04-21 00:16:31 --> Controller Class Initialized
INFO - 2018-04-21 00:16:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:16:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:16:31 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-21 00:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:16:31 --> Final output sent to browser
DEBUG - 2018-04-21 00:16:31 --> Total execution time: 0.3135
INFO - 2018-04-21 00:16:32 --> Config Class Initialized
INFO - 2018-04-21 00:16:32 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:32 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:32 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:32 --> URI Class Initialized
INFO - 2018-04-21 00:16:32 --> Router Class Initialized
INFO - 2018-04-21 00:16:32 --> Output Class Initialized
INFO - 2018-04-21 00:16:32 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:32 --> CSRF cookie sent
INFO - 2018-04-21 00:16:32 --> Input Class Initialized
INFO - 2018-04-21 00:16:32 --> Language Class Initialized
ERROR - 2018-04-21 00:16:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:16:34 --> Config Class Initialized
INFO - 2018-04-21 00:16:34 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:34 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:34 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:34 --> URI Class Initialized
INFO - 2018-04-21 00:16:34 --> Router Class Initialized
INFO - 2018-04-21 00:16:34 --> Output Class Initialized
INFO - 2018-04-21 00:16:34 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:34 --> CSRF cookie sent
INFO - 2018-04-21 00:16:34 --> Input Class Initialized
INFO - 2018-04-21 00:16:34 --> Language Class Initialized
ERROR - 2018-04-21 00:16:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-21 00:16:35 --> Config Class Initialized
INFO - 2018-04-21 00:16:35 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:35 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:35 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:35 --> URI Class Initialized
INFO - 2018-04-21 00:16:35 --> Router Class Initialized
INFO - 2018-04-21 00:16:35 --> Output Class Initialized
INFO - 2018-04-21 00:16:35 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:35 --> CSRF cookie sent
INFO - 2018-04-21 00:16:35 --> Input Class Initialized
INFO - 2018-04-21 00:16:35 --> Language Class Initialized
INFO - 2018-04-21 00:16:35 --> Loader Class Initialized
INFO - 2018-04-21 00:16:35 --> Helper loaded: url_helper
INFO - 2018-04-21 00:16:35 --> Helper loaded: form_helper
INFO - 2018-04-21 00:16:35 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:16:35 --> User Agent Class Initialized
INFO - 2018-04-21 00:16:35 --> Controller Class Initialized
INFO - 2018-04-21 00:16:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:16:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-21 00:16:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:16:35 --> Final output sent to browser
DEBUG - 2018-04-21 00:16:35 --> Total execution time: 0.3463
INFO - 2018-04-21 00:16:36 --> Config Class Initialized
INFO - 2018-04-21 00:16:36 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:36 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:36 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:36 --> URI Class Initialized
INFO - 2018-04-21 00:16:36 --> Router Class Initialized
INFO - 2018-04-21 00:16:36 --> Output Class Initialized
INFO - 2018-04-21 00:16:36 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:36 --> CSRF cookie sent
INFO - 2018-04-21 00:16:36 --> Input Class Initialized
INFO - 2018-04-21 00:16:36 --> Language Class Initialized
ERROR - 2018-04-21 00:16:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:16:53 --> Config Class Initialized
INFO - 2018-04-21 00:16:53 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:53 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:53 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:53 --> URI Class Initialized
INFO - 2018-04-21 00:16:53 --> Router Class Initialized
INFO - 2018-04-21 00:16:53 --> Output Class Initialized
INFO - 2018-04-21 00:16:53 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:53 --> CSRF cookie sent
INFO - 2018-04-21 00:16:53 --> Input Class Initialized
INFO - 2018-04-21 00:16:53 --> Language Class Initialized
INFO - 2018-04-21 00:16:53 --> Loader Class Initialized
INFO - 2018-04-21 00:16:53 --> Helper loaded: url_helper
INFO - 2018-04-21 00:16:53 --> Helper loaded: form_helper
INFO - 2018-04-21 00:16:53 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:16:53 --> User Agent Class Initialized
INFO - 2018-04-21 00:16:53 --> Controller Class Initialized
INFO - 2018-04-21 00:16:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:16:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-21 00:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:16:53 --> Final output sent to browser
DEBUG - 2018-04-21 00:16:53 --> Total execution time: 0.2768
INFO - 2018-04-21 00:16:54 --> Config Class Initialized
INFO - 2018-04-21 00:16:54 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:16:54 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:16:54 --> Utf8 Class Initialized
INFO - 2018-04-21 00:16:54 --> URI Class Initialized
INFO - 2018-04-21 00:16:54 --> Router Class Initialized
INFO - 2018-04-21 00:16:54 --> Output Class Initialized
INFO - 2018-04-21 00:16:54 --> Security Class Initialized
DEBUG - 2018-04-21 00:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:16:54 --> CSRF cookie sent
INFO - 2018-04-21 00:16:54 --> Input Class Initialized
INFO - 2018-04-21 00:16:54 --> Language Class Initialized
ERROR - 2018-04-21 00:16:54 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:17:18 --> Config Class Initialized
INFO - 2018-04-21 00:17:18 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:17:18 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:17:18 --> Utf8 Class Initialized
INFO - 2018-04-21 00:17:18 --> URI Class Initialized
INFO - 2018-04-21 00:17:18 --> Router Class Initialized
INFO - 2018-04-21 00:17:18 --> Output Class Initialized
INFO - 2018-04-21 00:17:18 --> Security Class Initialized
DEBUG - 2018-04-21 00:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:17:18 --> CSRF cookie sent
INFO - 2018-04-21 00:17:18 --> Input Class Initialized
INFO - 2018-04-21 00:17:18 --> Language Class Initialized
INFO - 2018-04-21 00:17:18 --> Loader Class Initialized
INFO - 2018-04-21 00:17:18 --> Helper loaded: url_helper
INFO - 2018-04-21 00:17:18 --> Helper loaded: form_helper
INFO - 2018-04-21 00:17:18 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:17:18 --> User Agent Class Initialized
INFO - 2018-04-21 00:17:18 --> Controller Class Initialized
INFO - 2018-04-21 00:17:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:17:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-21 00:17:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:17:18 --> Final output sent to browser
DEBUG - 2018-04-21 00:17:18 --> Total execution time: 0.2811
INFO - 2018-04-21 00:17:18 --> Config Class Initialized
INFO - 2018-04-21 00:17:18 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:17:18 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:17:18 --> Utf8 Class Initialized
INFO - 2018-04-21 00:17:18 --> URI Class Initialized
INFO - 2018-04-21 00:17:18 --> Router Class Initialized
INFO - 2018-04-21 00:17:18 --> Output Class Initialized
INFO - 2018-04-21 00:17:18 --> Security Class Initialized
DEBUG - 2018-04-21 00:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:17:18 --> CSRF cookie sent
INFO - 2018-04-21 00:17:18 --> Input Class Initialized
INFO - 2018-04-21 00:17:18 --> Language Class Initialized
ERROR - 2018-04-21 00:17:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:19:16 --> Config Class Initialized
INFO - 2018-04-21 00:19:16 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:19:16 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:19:16 --> Utf8 Class Initialized
INFO - 2018-04-21 00:19:16 --> URI Class Initialized
INFO - 2018-04-21 00:19:16 --> Router Class Initialized
INFO - 2018-04-21 00:19:16 --> Output Class Initialized
INFO - 2018-04-21 00:19:16 --> Security Class Initialized
DEBUG - 2018-04-21 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:19:16 --> CSRF cookie sent
INFO - 2018-04-21 00:19:16 --> Input Class Initialized
INFO - 2018-04-21 00:19:16 --> Language Class Initialized
INFO - 2018-04-21 00:19:16 --> Loader Class Initialized
INFO - 2018-04-21 00:19:16 --> Helper loaded: url_helper
INFO - 2018-04-21 00:19:16 --> Helper loaded: form_helper
INFO - 2018-04-21 00:19:16 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:19:16 --> User Agent Class Initialized
INFO - 2018-04-21 00:19:16 --> Controller Class Initialized
INFO - 2018-04-21 00:19:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:19:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-21 00:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:19:16 --> Final output sent to browser
DEBUG - 2018-04-21 00:19:16 --> Total execution time: 0.2650
INFO - 2018-04-21 00:19:17 --> Config Class Initialized
INFO - 2018-04-21 00:19:17 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:19:17 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:19:17 --> Utf8 Class Initialized
INFO - 2018-04-21 00:19:17 --> URI Class Initialized
INFO - 2018-04-21 00:19:17 --> Router Class Initialized
INFO - 2018-04-21 00:19:17 --> Output Class Initialized
INFO - 2018-04-21 00:19:17 --> Security Class Initialized
DEBUG - 2018-04-21 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:19:17 --> CSRF cookie sent
INFO - 2018-04-21 00:19:17 --> Input Class Initialized
INFO - 2018-04-21 00:19:17 --> Language Class Initialized
ERROR - 2018-04-21 00:19:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:19:22 --> Config Class Initialized
INFO - 2018-04-21 00:19:22 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:19:22 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:19:22 --> Utf8 Class Initialized
INFO - 2018-04-21 00:19:22 --> URI Class Initialized
INFO - 2018-04-21 00:19:22 --> Router Class Initialized
INFO - 2018-04-21 00:19:22 --> Output Class Initialized
INFO - 2018-04-21 00:19:22 --> Security Class Initialized
DEBUG - 2018-04-21 00:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:19:22 --> CSRF cookie sent
INFO - 2018-04-21 00:19:22 --> CSRF token verified
INFO - 2018-04-21 00:19:22 --> Input Class Initialized
INFO - 2018-04-21 00:19:22 --> Language Class Initialized
INFO - 2018-04-21 00:19:22 --> Loader Class Initialized
INFO - 2018-04-21 00:19:22 --> Helper loaded: url_helper
INFO - 2018-04-21 00:19:22 --> Helper loaded: form_helper
INFO - 2018-04-21 00:19:22 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:19:22 --> User Agent Class Initialized
INFO - 2018-04-21 00:19:22 --> Controller Class Initialized
INFO - 2018-04-21 00:19:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:19:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:19:22 --> Upload Class Initialized
INFO - 2018-04-21 00:19:22 --> Pixel_Model class loaded
INFO - 2018-04-21 00:19:22 --> Database Driver Class Initialized
INFO - 2018-04-21 00:19:22 --> Model "RegistrationModel" initialized
INFO - 2018-04-21 00:19:22 --> Database Driver Class Initialized
INFO - 2018-04-21 00:19:22 --> Model "RegistrationModel" initialized
INFO - 2018-04-21 00:19:22 --> Helper loaded: string_helper
INFO - 2018-04-21 00:19:22 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-21 00:19:22 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-21 00:19:22 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-21 00:19:22 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-21 00:19:22 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-21 00:19:23 --> Email Class Initialized
ERROR - 2018-04-21 00:19:24 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-21 00:19:24 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-04-21 00:19:24 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-21 00:19:24 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-21 00:19:24 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-21 00:19:24 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-21 00:19:24 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-21 00:19:24 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-21 00:19:25 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
DEBUG - 2018-04-21 00:19:25 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-21 00:19:25 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-21 00:19:25 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-21 00:19:25 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-21 00:19:25 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-21 00:19:25 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-21 00:19:26 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-04-21 00:19:26 --> Config Class Initialized
INFO - 2018-04-21 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:19:26 --> Utf8 Class Initialized
INFO - 2018-04-21 00:19:26 --> URI Class Initialized
INFO - 2018-04-21 00:19:26 --> Router Class Initialized
INFO - 2018-04-21 00:19:26 --> Output Class Initialized
INFO - 2018-04-21 00:19:26 --> Security Class Initialized
DEBUG - 2018-04-21 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:19:26 --> CSRF cookie sent
INFO - 2018-04-21 00:19:26 --> Input Class Initialized
INFO - 2018-04-21 00:19:26 --> Language Class Initialized
INFO - 2018-04-21 00:19:27 --> Loader Class Initialized
INFO - 2018-04-21 00:19:27 --> Helper loaded: url_helper
INFO - 2018-04-21 00:19:27 --> Helper loaded: form_helper
INFO - 2018-04-21 00:19:27 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:19:27 --> User Agent Class Initialized
INFO - 2018-04-21 00:19:27 --> Controller Class Initialized
INFO - 2018-04-21 00:19:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:19:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-21 00:19:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:19:27 --> Final output sent to browser
DEBUG - 2018-04-21 00:19:27 --> Total execution time: 0.2771
INFO - 2018-04-21 00:19:27 --> Config Class Initialized
INFO - 2018-04-21 00:19:27 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:19:27 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:19:27 --> Utf8 Class Initialized
INFO - 2018-04-21 00:19:27 --> URI Class Initialized
INFO - 2018-04-21 00:19:27 --> Router Class Initialized
INFO - 2018-04-21 00:19:27 --> Output Class Initialized
INFO - 2018-04-21 00:19:27 --> Security Class Initialized
DEBUG - 2018-04-21 00:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:19:27 --> CSRF cookie sent
INFO - 2018-04-21 00:19:27 --> Input Class Initialized
INFO - 2018-04-21 00:19:27 --> Language Class Initialized
ERROR - 2018-04-21 00:19:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:21:35 --> Config Class Initialized
INFO - 2018-04-21 00:21:35 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:21:35 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:21:35 --> Utf8 Class Initialized
INFO - 2018-04-21 00:21:35 --> URI Class Initialized
INFO - 2018-04-21 00:21:35 --> Router Class Initialized
INFO - 2018-04-21 00:21:35 --> Output Class Initialized
INFO - 2018-04-21 00:21:35 --> Security Class Initialized
DEBUG - 2018-04-21 00:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:21:35 --> CSRF cookie sent
INFO - 2018-04-21 00:21:35 --> Input Class Initialized
INFO - 2018-04-21 00:21:35 --> Language Class Initialized
INFO - 2018-04-21 00:21:35 --> Loader Class Initialized
INFO - 2018-04-21 00:21:35 --> Helper loaded: url_helper
INFO - 2018-04-21 00:21:35 --> Helper loaded: form_helper
INFO - 2018-04-21 00:21:35 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:21:35 --> User Agent Class Initialized
INFO - 2018-04-21 00:21:35 --> Controller Class Initialized
INFO - 2018-04-21 00:21:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:21:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-21 00:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:21:35 --> Final output sent to browser
DEBUG - 2018-04-21 00:21:35 --> Total execution time: 0.2714
INFO - 2018-04-21 00:21:36 --> Config Class Initialized
INFO - 2018-04-21 00:21:36 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:21:36 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:21:36 --> Utf8 Class Initialized
INFO - 2018-04-21 00:21:36 --> URI Class Initialized
INFO - 2018-04-21 00:21:36 --> Router Class Initialized
INFO - 2018-04-21 00:21:36 --> Output Class Initialized
INFO - 2018-04-21 00:21:36 --> Security Class Initialized
DEBUG - 2018-04-21 00:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:21:36 --> CSRF cookie sent
INFO - 2018-04-21 00:21:36 --> Input Class Initialized
INFO - 2018-04-21 00:21:36 --> Language Class Initialized
ERROR - 2018-04-21 00:21:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:21:40 --> Config Class Initialized
INFO - 2018-04-21 00:21:40 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:21:40 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:21:40 --> Utf8 Class Initialized
INFO - 2018-04-21 00:21:40 --> URI Class Initialized
INFO - 2018-04-21 00:21:40 --> Router Class Initialized
INFO - 2018-04-21 00:21:40 --> Output Class Initialized
INFO - 2018-04-21 00:21:40 --> Security Class Initialized
DEBUG - 2018-04-21 00:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:21:40 --> CSRF cookie sent
INFO - 2018-04-21 00:21:40 --> CSRF token verified
INFO - 2018-04-21 00:21:40 --> Input Class Initialized
INFO - 2018-04-21 00:21:40 --> Language Class Initialized
INFO - 2018-04-21 00:21:40 --> Loader Class Initialized
INFO - 2018-04-21 00:21:40 --> Helper loaded: url_helper
INFO - 2018-04-21 00:21:40 --> Helper loaded: form_helper
INFO - 2018-04-21 00:21:40 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:21:41 --> User Agent Class Initialized
INFO - 2018-04-21 00:21:41 --> Controller Class Initialized
INFO - 2018-04-21 00:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:21:41 --> Upload Class Initialized
INFO - 2018-04-21 00:21:41 --> Pixel_Model class loaded
INFO - 2018-04-21 00:21:41 --> Database Driver Class Initialized
INFO - 2018-04-21 00:21:41 --> Model "RegistrationModel" initialized
INFO - 2018-04-21 00:21:41 --> Config Class Initialized
INFO - 2018-04-21 00:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:21:41 --> Utf8 Class Initialized
INFO - 2018-04-21 00:21:41 --> URI Class Initialized
INFO - 2018-04-21 00:21:41 --> Router Class Initialized
INFO - 2018-04-21 00:21:41 --> Output Class Initialized
INFO - 2018-04-21 00:21:41 --> Security Class Initialized
DEBUG - 2018-04-21 00:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:21:41 --> CSRF cookie sent
INFO - 2018-04-21 00:21:41 --> Input Class Initialized
INFO - 2018-04-21 00:21:41 --> Language Class Initialized
INFO - 2018-04-21 00:21:41 --> Loader Class Initialized
INFO - 2018-04-21 00:21:41 --> Helper loaded: url_helper
INFO - 2018-04-21 00:21:41 --> Helper loaded: form_helper
INFO - 2018-04-21 00:21:41 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:21:41 --> User Agent Class Initialized
INFO - 2018-04-21 00:21:41 --> Controller Class Initialized
INFO - 2018-04-21 00:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-21 00:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:21:41 --> Final output sent to browser
DEBUG - 2018-04-21 00:21:41 --> Total execution time: 0.2606
INFO - 2018-04-21 00:21:41 --> Config Class Initialized
INFO - 2018-04-21 00:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:21:41 --> Utf8 Class Initialized
INFO - 2018-04-21 00:21:41 --> URI Class Initialized
INFO - 2018-04-21 00:21:41 --> Router Class Initialized
INFO - 2018-04-21 00:21:41 --> Output Class Initialized
INFO - 2018-04-21 00:21:41 --> Security Class Initialized
DEBUG - 2018-04-21 00:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:21:41 --> CSRF cookie sent
INFO - 2018-04-21 00:21:41 --> Input Class Initialized
INFO - 2018-04-21 00:21:41 --> Language Class Initialized
ERROR - 2018-04-21 00:21:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-21 00:28:33 --> Config Class Initialized
INFO - 2018-04-21 00:28:33 --> Hooks Class Initialized
DEBUG - 2018-04-21 00:28:33 --> UTF-8 Support Enabled
INFO - 2018-04-21 00:28:33 --> Utf8 Class Initialized
INFO - 2018-04-21 00:28:33 --> URI Class Initialized
INFO - 2018-04-21 00:28:33 --> Router Class Initialized
INFO - 2018-04-21 00:28:33 --> Output Class Initialized
INFO - 2018-04-21 00:28:33 --> Security Class Initialized
DEBUG - 2018-04-21 00:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-21 00:28:33 --> CSRF cookie sent
INFO - 2018-04-21 00:28:33 --> Input Class Initialized
INFO - 2018-04-21 00:28:33 --> Language Class Initialized
INFO - 2018-04-21 00:28:33 --> Loader Class Initialized
INFO - 2018-04-21 00:28:33 --> Helper loaded: url_helper
INFO - 2018-04-21 00:28:33 --> Helper loaded: form_helper
INFO - 2018-04-21 00:28:33 --> Helper loaded: language_helper
DEBUG - 2018-04-21 00:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-21 00:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-21 00:28:33 --> User Agent Class Initialized
INFO - 2018-04-21 00:28:33 --> Controller Class Initialized
INFO - 2018-04-21 00:28:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-21 00:28:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-21 00:28:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-21 00:28:33 --> Final output sent to browser
DEBUG - 2018-04-21 00:28:33 --> Total execution time: 0.3538

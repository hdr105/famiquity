<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-25 00:41:57 --> Config Class Initialized
INFO - 2018-04-25 00:41:57 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:41:57 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:41:57 --> Utf8 Class Initialized
INFO - 2018-04-25 00:41:57 --> URI Class Initialized
DEBUG - 2018-04-25 00:41:57 --> No URI present. Default controller set.
INFO - 2018-04-25 00:41:57 --> Router Class Initialized
INFO - 2018-04-25 00:41:57 --> Output Class Initialized
INFO - 2018-04-25 00:41:57 --> Security Class Initialized
DEBUG - 2018-04-25 00:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:41:57 --> CSRF cookie sent
INFO - 2018-04-25 00:41:57 --> Input Class Initialized
INFO - 2018-04-25 00:41:57 --> Language Class Initialized
INFO - 2018-04-25 00:41:57 --> Loader Class Initialized
INFO - 2018-04-25 00:41:57 --> Helper loaded: url_helper
INFO - 2018-04-25 00:41:57 --> Helper loaded: form_helper
INFO - 2018-04-25 00:41:57 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:41:57 --> User Agent Class Initialized
INFO - 2018-04-25 00:41:57 --> Controller Class Initialized
INFO - 2018-04-25 00:41:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:41:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:41:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:41:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:41:57 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:41:58 --> Final output sent to browser
DEBUG - 2018-04-25 00:41:58 --> Total execution time: 0.2512
INFO - 2018-04-25 00:41:59 --> Config Class Initialized
INFO - 2018-04-25 00:41:59 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:41:59 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:41:59 --> Utf8 Class Initialized
INFO - 2018-04-25 00:41:59 --> URI Class Initialized
INFO - 2018-04-25 00:41:59 --> Router Class Initialized
INFO - 2018-04-25 00:41:59 --> Output Class Initialized
INFO - 2018-04-25 00:41:59 --> Security Class Initialized
DEBUG - 2018-04-25 00:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:41:59 --> CSRF cookie sent
INFO - 2018-04-25 00:41:59 --> Input Class Initialized
INFO - 2018-04-25 00:41:59 --> Language Class Initialized
ERROR - 2018-04-25 00:41:59 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:42:03 --> Config Class Initialized
INFO - 2018-04-25 00:42:03 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:42:03 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:42:03 --> Utf8 Class Initialized
INFO - 2018-04-25 00:42:03 --> URI Class Initialized
INFO - 2018-04-25 00:42:03 --> Router Class Initialized
INFO - 2018-04-25 00:42:03 --> Output Class Initialized
INFO - 2018-04-25 00:42:03 --> Security Class Initialized
DEBUG - 2018-04-25 00:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:42:03 --> CSRF cookie sent
INFO - 2018-04-25 00:42:03 --> Input Class Initialized
INFO - 2018-04-25 00:42:03 --> Language Class Initialized
ERROR - 2018-04-25 00:42:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 00:42:27 --> Config Class Initialized
INFO - 2018-04-25 00:42:27 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:42:27 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:42:27 --> Utf8 Class Initialized
INFO - 2018-04-25 00:42:27 --> URI Class Initialized
DEBUG - 2018-04-25 00:42:27 --> No URI present. Default controller set.
INFO - 2018-04-25 00:42:27 --> Router Class Initialized
INFO - 2018-04-25 00:42:27 --> Output Class Initialized
INFO - 2018-04-25 00:42:27 --> Security Class Initialized
DEBUG - 2018-04-25 00:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:42:27 --> CSRF cookie sent
INFO - 2018-04-25 00:42:27 --> Input Class Initialized
INFO - 2018-04-25 00:42:27 --> Language Class Initialized
INFO - 2018-04-25 00:42:27 --> Loader Class Initialized
INFO - 2018-04-25 00:42:28 --> Helper loaded: url_helper
INFO - 2018-04-25 00:42:28 --> Helper loaded: form_helper
INFO - 2018-04-25 00:42:28 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:42:28 --> User Agent Class Initialized
INFO - 2018-04-25 00:42:28 --> Controller Class Initialized
INFO - 2018-04-25 00:42:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:42:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:42:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:42:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:42:28 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:42:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:42:28 --> Final output sent to browser
DEBUG - 2018-04-25 00:42:28 --> Total execution time: 0.2908
INFO - 2018-04-25 00:42:28 --> Config Class Initialized
INFO - 2018-04-25 00:42:28 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:42:28 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:42:28 --> Utf8 Class Initialized
INFO - 2018-04-25 00:42:28 --> URI Class Initialized
INFO - 2018-04-25 00:42:28 --> Router Class Initialized
INFO - 2018-04-25 00:42:28 --> Output Class Initialized
INFO - 2018-04-25 00:42:28 --> Security Class Initialized
DEBUG - 2018-04-25 00:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:42:28 --> CSRF cookie sent
INFO - 2018-04-25 00:42:28 --> Input Class Initialized
INFO - 2018-04-25 00:42:28 --> Language Class Initialized
ERROR - 2018-04-25 00:42:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 00:42:29 --> Config Class Initialized
INFO - 2018-04-25 00:42:29 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:42:30 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:42:30 --> Utf8 Class Initialized
INFO - 2018-04-25 00:42:30 --> URI Class Initialized
INFO - 2018-04-25 00:42:30 --> Router Class Initialized
INFO - 2018-04-25 00:42:30 --> Output Class Initialized
INFO - 2018-04-25 00:42:30 --> Security Class Initialized
DEBUG - 2018-04-25 00:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:42:30 --> CSRF cookie sent
INFO - 2018-04-25 00:42:30 --> Input Class Initialized
INFO - 2018-04-25 00:42:30 --> Language Class Initialized
ERROR - 2018-04-25 00:42:30 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:42:47 --> Config Class Initialized
INFO - 2018-04-25 00:42:47 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:42:47 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:42:47 --> Utf8 Class Initialized
INFO - 2018-04-25 00:42:47 --> URI Class Initialized
INFO - 2018-04-25 00:42:47 --> Router Class Initialized
INFO - 2018-04-25 00:42:47 --> Output Class Initialized
INFO - 2018-04-25 00:42:47 --> Security Class Initialized
DEBUG - 2018-04-25 00:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:42:47 --> CSRF cookie sent
INFO - 2018-04-25 00:42:47 --> Input Class Initialized
INFO - 2018-04-25 00:42:47 --> Language Class Initialized
ERROR - 2018-04-25 00:42:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 00:43:12 --> Config Class Initialized
INFO - 2018-04-25 00:43:12 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:12 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:12 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:12 --> URI Class Initialized
DEBUG - 2018-04-25 00:43:12 --> No URI present. Default controller set.
INFO - 2018-04-25 00:43:12 --> Router Class Initialized
INFO - 2018-04-25 00:43:12 --> Output Class Initialized
INFO - 2018-04-25 00:43:12 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:12 --> CSRF cookie sent
INFO - 2018-04-25 00:43:12 --> Input Class Initialized
INFO - 2018-04-25 00:43:12 --> Language Class Initialized
INFO - 2018-04-25 00:43:12 --> Loader Class Initialized
INFO - 2018-04-25 00:43:12 --> Helper loaded: url_helper
INFO - 2018-04-25 00:43:12 --> Helper loaded: form_helper
INFO - 2018-04-25 00:43:12 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:43:12 --> User Agent Class Initialized
INFO - 2018-04-25 00:43:12 --> Controller Class Initialized
INFO - 2018-04-25 00:43:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:43:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:43:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:43:12 --> Final output sent to browser
DEBUG - 2018-04-25 00:43:12 --> Total execution time: 0.2866
INFO - 2018-04-25 00:43:12 --> Config Class Initialized
INFO - 2018-04-25 00:43:12 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:13 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:13 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:13 --> URI Class Initialized
INFO - 2018-04-25 00:43:13 --> Router Class Initialized
INFO - 2018-04-25 00:43:13 --> Output Class Initialized
INFO - 2018-04-25 00:43:13 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:13 --> CSRF cookie sent
INFO - 2018-04-25 00:43:13 --> Input Class Initialized
INFO - 2018-04-25 00:43:13 --> Language Class Initialized
ERROR - 2018-04-25 00:43:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 00:43:14 --> Config Class Initialized
INFO - 2018-04-25 00:43:14 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:14 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:14 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:14 --> URI Class Initialized
INFO - 2018-04-25 00:43:14 --> Router Class Initialized
INFO - 2018-04-25 00:43:14 --> Output Class Initialized
INFO - 2018-04-25 00:43:14 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:14 --> CSRF cookie sent
INFO - 2018-04-25 00:43:14 --> Input Class Initialized
INFO - 2018-04-25 00:43:14 --> Language Class Initialized
ERROR - 2018-04-25 00:43:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:43:32 --> Config Class Initialized
INFO - 2018-04-25 00:43:32 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:32 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:32 --> URI Class Initialized
DEBUG - 2018-04-25 00:43:32 --> No URI present. Default controller set.
INFO - 2018-04-25 00:43:32 --> Router Class Initialized
INFO - 2018-04-25 00:43:32 --> Output Class Initialized
INFO - 2018-04-25 00:43:32 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:32 --> CSRF cookie sent
INFO - 2018-04-25 00:43:32 --> Input Class Initialized
INFO - 2018-04-25 00:43:32 --> Language Class Initialized
INFO - 2018-04-25 00:43:32 --> Loader Class Initialized
INFO - 2018-04-25 00:43:32 --> Helper loaded: url_helper
INFO - 2018-04-25 00:43:32 --> Helper loaded: form_helper
INFO - 2018-04-25 00:43:32 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:43:32 --> User Agent Class Initialized
INFO - 2018-04-25 00:43:32 --> Controller Class Initialized
INFO - 2018-04-25 00:43:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:43:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:43:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:43:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:43:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:43:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:43:32 --> Final output sent to browser
DEBUG - 2018-04-25 00:43:32 --> Total execution time: 0.3044
INFO - 2018-04-25 00:43:32 --> Config Class Initialized
INFO - 2018-04-25 00:43:32 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:32 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:32 --> URI Class Initialized
INFO - 2018-04-25 00:43:32 --> Router Class Initialized
INFO - 2018-04-25 00:43:32 --> Output Class Initialized
INFO - 2018-04-25 00:43:32 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:32 --> CSRF cookie sent
INFO - 2018-04-25 00:43:32 --> Input Class Initialized
INFO - 2018-04-25 00:43:32 --> Language Class Initialized
ERROR - 2018-04-25 00:43:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 00:43:34 --> Config Class Initialized
INFO - 2018-04-25 00:43:34 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:34 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:34 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:34 --> URI Class Initialized
INFO - 2018-04-25 00:43:34 --> Router Class Initialized
INFO - 2018-04-25 00:43:34 --> Output Class Initialized
INFO - 2018-04-25 00:43:34 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:34 --> CSRF cookie sent
INFO - 2018-04-25 00:43:34 --> Input Class Initialized
INFO - 2018-04-25 00:43:34 --> Language Class Initialized
ERROR - 2018-04-25 00:43:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:43:42 --> Config Class Initialized
INFO - 2018-04-25 00:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:42 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:42 --> URI Class Initialized
DEBUG - 2018-04-25 00:43:42 --> No URI present. Default controller set.
INFO - 2018-04-25 00:43:42 --> Router Class Initialized
INFO - 2018-04-25 00:43:42 --> Output Class Initialized
INFO - 2018-04-25 00:43:42 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:42 --> CSRF cookie sent
INFO - 2018-04-25 00:43:42 --> Input Class Initialized
INFO - 2018-04-25 00:43:42 --> Language Class Initialized
INFO - 2018-04-25 00:43:42 --> Loader Class Initialized
INFO - 2018-04-25 00:43:42 --> Helper loaded: url_helper
INFO - 2018-04-25 00:43:42 --> Helper loaded: form_helper
INFO - 2018-04-25 00:43:42 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:43:42 --> User Agent Class Initialized
INFO - 2018-04-25 00:43:42 --> Controller Class Initialized
INFO - 2018-04-25 00:43:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:43:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:43:42 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:43:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:43:42 --> Final output sent to browser
DEBUG - 2018-04-25 00:43:42 --> Total execution time: 0.2835
INFO - 2018-04-25 00:43:44 --> Config Class Initialized
INFO - 2018-04-25 00:43:44 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:43:44 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:43:44 --> Utf8 Class Initialized
INFO - 2018-04-25 00:43:44 --> URI Class Initialized
INFO - 2018-04-25 00:43:44 --> Router Class Initialized
INFO - 2018-04-25 00:43:44 --> Output Class Initialized
INFO - 2018-04-25 00:43:44 --> Security Class Initialized
DEBUG - 2018-04-25 00:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:43:44 --> CSRF cookie sent
INFO - 2018-04-25 00:43:44 --> Input Class Initialized
INFO - 2018-04-25 00:43:44 --> Language Class Initialized
ERROR - 2018-04-25 00:43:44 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:44:26 --> Config Class Initialized
INFO - 2018-04-25 00:44:26 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:44:26 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:44:26 --> Utf8 Class Initialized
INFO - 2018-04-25 00:44:26 --> URI Class Initialized
DEBUG - 2018-04-25 00:44:26 --> No URI present. Default controller set.
INFO - 2018-04-25 00:44:26 --> Router Class Initialized
INFO - 2018-04-25 00:44:26 --> Output Class Initialized
INFO - 2018-04-25 00:44:26 --> Security Class Initialized
DEBUG - 2018-04-25 00:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:44:26 --> CSRF cookie sent
INFO - 2018-04-25 00:44:26 --> Input Class Initialized
INFO - 2018-04-25 00:44:26 --> Language Class Initialized
INFO - 2018-04-25 00:44:26 --> Loader Class Initialized
INFO - 2018-04-25 00:44:26 --> Helper loaded: url_helper
INFO - 2018-04-25 00:44:26 --> Helper loaded: form_helper
INFO - 2018-04-25 00:44:26 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:44:26 --> User Agent Class Initialized
INFO - 2018-04-25 00:44:26 --> Controller Class Initialized
INFO - 2018-04-25 00:44:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:44:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:44:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:44:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:44:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:44:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:44:26 --> Final output sent to browser
DEBUG - 2018-04-25 00:44:26 --> Total execution time: 0.2899
INFO - 2018-04-25 00:44:27 --> Config Class Initialized
INFO - 2018-04-25 00:44:28 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:44:28 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:44:28 --> Utf8 Class Initialized
INFO - 2018-04-25 00:44:28 --> URI Class Initialized
INFO - 2018-04-25 00:44:28 --> Router Class Initialized
INFO - 2018-04-25 00:44:28 --> Output Class Initialized
INFO - 2018-04-25 00:44:28 --> Security Class Initialized
DEBUG - 2018-04-25 00:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:44:28 --> CSRF cookie sent
INFO - 2018-04-25 00:44:28 --> Input Class Initialized
INFO - 2018-04-25 00:44:28 --> Language Class Initialized
ERROR - 2018-04-25 00:44:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:45:39 --> Config Class Initialized
INFO - 2018-04-25 00:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:45:39 --> Utf8 Class Initialized
INFO - 2018-04-25 00:45:39 --> URI Class Initialized
DEBUG - 2018-04-25 00:45:39 --> No URI present. Default controller set.
INFO - 2018-04-25 00:45:39 --> Router Class Initialized
INFO - 2018-04-25 00:45:39 --> Output Class Initialized
INFO - 2018-04-25 00:45:39 --> Security Class Initialized
DEBUG - 2018-04-25 00:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:45:39 --> CSRF cookie sent
INFO - 2018-04-25 00:45:39 --> Input Class Initialized
INFO - 2018-04-25 00:45:39 --> Language Class Initialized
INFO - 2018-04-25 00:45:39 --> Loader Class Initialized
INFO - 2018-04-25 00:45:39 --> Helper loaded: url_helper
INFO - 2018-04-25 00:45:39 --> Helper loaded: form_helper
INFO - 2018-04-25 00:45:39 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:45:39 --> User Agent Class Initialized
INFO - 2018-04-25 00:45:39 --> Controller Class Initialized
INFO - 2018-04-25 00:45:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:45:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:45:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:45:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:45:39 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:45:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:45:39 --> Final output sent to browser
DEBUG - 2018-04-25 00:45:39 --> Total execution time: 0.2673
INFO - 2018-04-25 00:45:40 --> Config Class Initialized
INFO - 2018-04-25 00:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:45:40 --> Utf8 Class Initialized
INFO - 2018-04-25 00:45:40 --> URI Class Initialized
INFO - 2018-04-25 00:45:40 --> Router Class Initialized
INFO - 2018-04-25 00:45:40 --> Output Class Initialized
INFO - 2018-04-25 00:45:40 --> Security Class Initialized
DEBUG - 2018-04-25 00:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:45:40 --> CSRF cookie sent
INFO - 2018-04-25 00:45:40 --> Input Class Initialized
INFO - 2018-04-25 00:45:40 --> Language Class Initialized
ERROR - 2018-04-25 00:45:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:46:07 --> Config Class Initialized
INFO - 2018-04-25 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:46:07 --> Utf8 Class Initialized
INFO - 2018-04-25 00:46:07 --> URI Class Initialized
DEBUG - 2018-04-25 00:46:07 --> No URI present. Default controller set.
INFO - 2018-04-25 00:46:07 --> Router Class Initialized
INFO - 2018-04-25 00:46:07 --> Output Class Initialized
INFO - 2018-04-25 00:46:07 --> Security Class Initialized
DEBUG - 2018-04-25 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:46:07 --> CSRF cookie sent
INFO - 2018-04-25 00:46:07 --> Input Class Initialized
INFO - 2018-04-25 00:46:07 --> Language Class Initialized
INFO - 2018-04-25 00:46:07 --> Loader Class Initialized
INFO - 2018-04-25 00:46:08 --> Helper loaded: url_helper
INFO - 2018-04-25 00:46:08 --> Helper loaded: form_helper
INFO - 2018-04-25 00:46:08 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:46:08 --> User Agent Class Initialized
INFO - 2018-04-25 00:46:08 --> Controller Class Initialized
INFO - 2018-04-25 00:46:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:46:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:46:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:46:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:46:08 --> Final output sent to browser
DEBUG - 2018-04-25 00:46:08 --> Total execution time: 0.2606
INFO - 2018-04-25 00:46:09 --> Config Class Initialized
INFO - 2018-04-25 00:46:09 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:46:09 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:46:09 --> Utf8 Class Initialized
INFO - 2018-04-25 00:46:09 --> URI Class Initialized
INFO - 2018-04-25 00:46:09 --> Router Class Initialized
INFO - 2018-04-25 00:46:09 --> Output Class Initialized
INFO - 2018-04-25 00:46:09 --> Security Class Initialized
DEBUG - 2018-04-25 00:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:46:09 --> CSRF cookie sent
INFO - 2018-04-25 00:46:09 --> Input Class Initialized
INFO - 2018-04-25 00:46:09 --> Language Class Initialized
ERROR - 2018-04-25 00:46:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:46:34 --> Config Class Initialized
INFO - 2018-04-25 00:46:34 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:46:34 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:46:34 --> Utf8 Class Initialized
INFO - 2018-04-25 00:46:34 --> URI Class Initialized
DEBUG - 2018-04-25 00:46:34 --> No URI present. Default controller set.
INFO - 2018-04-25 00:46:34 --> Router Class Initialized
INFO - 2018-04-25 00:46:34 --> Output Class Initialized
INFO - 2018-04-25 00:46:34 --> Security Class Initialized
DEBUG - 2018-04-25 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:46:34 --> CSRF cookie sent
INFO - 2018-04-25 00:46:34 --> Input Class Initialized
INFO - 2018-04-25 00:46:34 --> Language Class Initialized
INFO - 2018-04-25 00:46:34 --> Loader Class Initialized
INFO - 2018-04-25 00:46:34 --> Helper loaded: url_helper
INFO - 2018-04-25 00:46:34 --> Helper loaded: form_helper
INFO - 2018-04-25 00:46:34 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:46:34 --> User Agent Class Initialized
INFO - 2018-04-25 00:46:34 --> Controller Class Initialized
INFO - 2018-04-25 00:46:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:46:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:46:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:46:35 --> Final output sent to browser
DEBUG - 2018-04-25 00:46:35 --> Total execution time: 0.2819
INFO - 2018-04-25 00:46:36 --> Config Class Initialized
INFO - 2018-04-25 00:46:36 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:46:36 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:46:36 --> Utf8 Class Initialized
INFO - 2018-04-25 00:46:36 --> URI Class Initialized
INFO - 2018-04-25 00:46:36 --> Router Class Initialized
INFO - 2018-04-25 00:46:36 --> Output Class Initialized
INFO - 2018-04-25 00:46:36 --> Security Class Initialized
DEBUG - 2018-04-25 00:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:46:36 --> CSRF cookie sent
INFO - 2018-04-25 00:46:36 --> Input Class Initialized
INFO - 2018-04-25 00:46:36 --> Language Class Initialized
ERROR - 2018-04-25 00:46:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:47:02 --> Config Class Initialized
INFO - 2018-04-25 00:47:02 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:02 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:02 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:02 --> URI Class Initialized
DEBUG - 2018-04-25 00:47:02 --> No URI present. Default controller set.
INFO - 2018-04-25 00:47:02 --> Router Class Initialized
INFO - 2018-04-25 00:47:02 --> Output Class Initialized
INFO - 2018-04-25 00:47:02 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:02 --> CSRF cookie sent
INFO - 2018-04-25 00:47:02 --> Input Class Initialized
INFO - 2018-04-25 00:47:02 --> Language Class Initialized
INFO - 2018-04-25 00:47:02 --> Loader Class Initialized
INFO - 2018-04-25 00:47:02 --> Helper loaded: url_helper
INFO - 2018-04-25 00:47:02 --> Helper loaded: form_helper
INFO - 2018-04-25 00:47:02 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:47:02 --> User Agent Class Initialized
INFO - 2018-04-25 00:47:02 --> Controller Class Initialized
INFO - 2018-04-25 00:47:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:47:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:47:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:47:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:47:02 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:47:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:47:02 --> Final output sent to browser
DEBUG - 2018-04-25 00:47:02 --> Total execution time: 0.2759
INFO - 2018-04-25 00:47:03 --> Config Class Initialized
INFO - 2018-04-25 00:47:03 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:03 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:03 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:03 --> URI Class Initialized
INFO - 2018-04-25 00:47:03 --> Router Class Initialized
INFO - 2018-04-25 00:47:03 --> Output Class Initialized
INFO - 2018-04-25 00:47:03 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:03 --> CSRF cookie sent
INFO - 2018-04-25 00:47:03 --> Input Class Initialized
INFO - 2018-04-25 00:47:03 --> Language Class Initialized
ERROR - 2018-04-25 00:47:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:47:16 --> Config Class Initialized
INFO - 2018-04-25 00:47:16 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:16 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:16 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:16 --> URI Class Initialized
DEBUG - 2018-04-25 00:47:16 --> No URI present. Default controller set.
INFO - 2018-04-25 00:47:16 --> Router Class Initialized
INFO - 2018-04-25 00:47:16 --> Output Class Initialized
INFO - 2018-04-25 00:47:16 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:16 --> CSRF cookie sent
INFO - 2018-04-25 00:47:16 --> Input Class Initialized
INFO - 2018-04-25 00:47:16 --> Language Class Initialized
INFO - 2018-04-25 00:47:17 --> Loader Class Initialized
INFO - 2018-04-25 00:47:17 --> Helper loaded: url_helper
INFO - 2018-04-25 00:47:17 --> Helper loaded: form_helper
INFO - 2018-04-25 00:47:17 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:47:17 --> User Agent Class Initialized
INFO - 2018-04-25 00:47:17 --> Controller Class Initialized
INFO - 2018-04-25 00:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:47:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:47:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:47:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:47:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:47:17 --> Final output sent to browser
DEBUG - 2018-04-25 00:47:17 --> Total execution time: 0.2985
INFO - 2018-04-25 00:47:18 --> Config Class Initialized
INFO - 2018-04-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:18 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:18 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:18 --> URI Class Initialized
INFO - 2018-04-25 00:47:18 --> Router Class Initialized
INFO - 2018-04-25 00:47:18 --> Output Class Initialized
INFO - 2018-04-25 00:47:18 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:18 --> CSRF cookie sent
INFO - 2018-04-25 00:47:18 --> Input Class Initialized
INFO - 2018-04-25 00:47:18 --> Language Class Initialized
ERROR - 2018-04-25 00:47:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:47:36 --> Config Class Initialized
INFO - 2018-04-25 00:47:36 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:36 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:36 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:36 --> URI Class Initialized
DEBUG - 2018-04-25 00:47:36 --> No URI present. Default controller set.
INFO - 2018-04-25 00:47:36 --> Router Class Initialized
INFO - 2018-04-25 00:47:36 --> Output Class Initialized
INFO - 2018-04-25 00:47:36 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:36 --> CSRF cookie sent
INFO - 2018-04-25 00:47:36 --> Input Class Initialized
INFO - 2018-04-25 00:47:36 --> Language Class Initialized
INFO - 2018-04-25 00:47:36 --> Loader Class Initialized
INFO - 2018-04-25 00:47:36 --> Helper loaded: url_helper
INFO - 2018-04-25 00:47:36 --> Helper loaded: form_helper
INFO - 2018-04-25 00:47:36 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:47:36 --> User Agent Class Initialized
INFO - 2018-04-25 00:47:36 --> Controller Class Initialized
INFO - 2018-04-25 00:47:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:47:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:47:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:47:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:47:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:47:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:47:36 --> Final output sent to browser
DEBUG - 2018-04-25 00:47:36 --> Total execution time: 0.2938
INFO - 2018-04-25 00:47:37 --> Config Class Initialized
INFO - 2018-04-25 00:47:37 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:47:37 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:47:37 --> Utf8 Class Initialized
INFO - 2018-04-25 00:47:37 --> URI Class Initialized
INFO - 2018-04-25 00:47:37 --> Router Class Initialized
INFO - 2018-04-25 00:47:37 --> Output Class Initialized
INFO - 2018-04-25 00:47:37 --> Security Class Initialized
DEBUG - 2018-04-25 00:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:47:37 --> CSRF cookie sent
INFO - 2018-04-25 00:47:38 --> Input Class Initialized
INFO - 2018-04-25 00:47:38 --> Language Class Initialized
ERROR - 2018-04-25 00:47:38 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:48:35 --> Config Class Initialized
INFO - 2018-04-25 00:48:35 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:35 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:35 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:35 --> URI Class Initialized
DEBUG - 2018-04-25 00:48:35 --> No URI present. Default controller set.
INFO - 2018-04-25 00:48:35 --> Router Class Initialized
INFO - 2018-04-25 00:48:35 --> Output Class Initialized
INFO - 2018-04-25 00:48:35 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:35 --> CSRF cookie sent
INFO - 2018-04-25 00:48:35 --> Input Class Initialized
INFO - 2018-04-25 00:48:35 --> Language Class Initialized
INFO - 2018-04-25 00:48:35 --> Loader Class Initialized
INFO - 2018-04-25 00:48:35 --> Helper loaded: url_helper
INFO - 2018-04-25 00:48:35 --> Helper loaded: form_helper
INFO - 2018-04-25 00:48:35 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:48:35 --> User Agent Class Initialized
INFO - 2018-04-25 00:48:35 --> Controller Class Initialized
INFO - 2018-04-25 00:48:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:48:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:48:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:48:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:48:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:48:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:48:35 --> Final output sent to browser
DEBUG - 2018-04-25 00:48:35 --> Total execution time: 0.3120
INFO - 2018-04-25 00:48:36 --> Config Class Initialized
INFO - 2018-04-25 00:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:36 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:36 --> URI Class Initialized
INFO - 2018-04-25 00:48:36 --> Router Class Initialized
INFO - 2018-04-25 00:48:36 --> Output Class Initialized
INFO - 2018-04-25 00:48:36 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:36 --> CSRF cookie sent
INFO - 2018-04-25 00:48:36 --> Input Class Initialized
INFO - 2018-04-25 00:48:36 --> Language Class Initialized
ERROR - 2018-04-25 00:48:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:48:40 --> Config Class Initialized
INFO - 2018-04-25 00:48:40 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:41 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:41 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:41 --> URI Class Initialized
DEBUG - 2018-04-25 00:48:41 --> No URI present. Default controller set.
INFO - 2018-04-25 00:48:41 --> Router Class Initialized
INFO - 2018-04-25 00:48:41 --> Output Class Initialized
INFO - 2018-04-25 00:48:41 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:41 --> CSRF cookie sent
INFO - 2018-04-25 00:48:41 --> Input Class Initialized
INFO - 2018-04-25 00:48:41 --> Language Class Initialized
INFO - 2018-04-25 00:48:41 --> Loader Class Initialized
INFO - 2018-04-25 00:48:41 --> Helper loaded: url_helper
INFO - 2018-04-25 00:48:41 --> Helper loaded: form_helper
INFO - 2018-04-25 00:48:41 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:48:41 --> User Agent Class Initialized
INFO - 2018-04-25 00:48:41 --> Controller Class Initialized
INFO - 2018-04-25 00:48:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:48:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:48:41 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:48:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:48:41 --> Final output sent to browser
DEBUG - 2018-04-25 00:48:41 --> Total execution time: 0.3024
INFO - 2018-04-25 00:48:42 --> Config Class Initialized
INFO - 2018-04-25 00:48:42 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:42 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:42 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:42 --> URI Class Initialized
INFO - 2018-04-25 00:48:42 --> Router Class Initialized
INFO - 2018-04-25 00:48:42 --> Output Class Initialized
INFO - 2018-04-25 00:48:42 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:42 --> CSRF cookie sent
INFO - 2018-04-25 00:48:42 --> Input Class Initialized
INFO - 2018-04-25 00:48:42 --> Language Class Initialized
ERROR - 2018-04-25 00:48:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:48:53 --> Config Class Initialized
INFO - 2018-04-25 00:48:53 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:53 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:53 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:53 --> URI Class Initialized
DEBUG - 2018-04-25 00:48:53 --> No URI present. Default controller set.
INFO - 2018-04-25 00:48:53 --> Router Class Initialized
INFO - 2018-04-25 00:48:53 --> Output Class Initialized
INFO - 2018-04-25 00:48:53 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:53 --> CSRF cookie sent
INFO - 2018-04-25 00:48:53 --> Input Class Initialized
INFO - 2018-04-25 00:48:53 --> Language Class Initialized
INFO - 2018-04-25 00:48:53 --> Loader Class Initialized
INFO - 2018-04-25 00:48:53 --> Helper loaded: url_helper
INFO - 2018-04-25 00:48:53 --> Helper loaded: form_helper
INFO - 2018-04-25 00:48:53 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:48:53 --> User Agent Class Initialized
INFO - 2018-04-25 00:48:53 --> Controller Class Initialized
INFO - 2018-04-25 00:48:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:48:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:48:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:48:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:48:53 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:48:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:48:53 --> Final output sent to browser
DEBUG - 2018-04-25 00:48:53 --> Total execution time: 0.3008
INFO - 2018-04-25 00:48:54 --> Config Class Initialized
INFO - 2018-04-25 00:48:54 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:48:54 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:48:54 --> Utf8 Class Initialized
INFO - 2018-04-25 00:48:54 --> URI Class Initialized
INFO - 2018-04-25 00:48:54 --> Router Class Initialized
INFO - 2018-04-25 00:48:54 --> Output Class Initialized
INFO - 2018-04-25 00:48:54 --> Security Class Initialized
DEBUG - 2018-04-25 00:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:48:54 --> CSRF cookie sent
INFO - 2018-04-25 00:48:54 --> Input Class Initialized
INFO - 2018-04-25 00:48:54 --> Language Class Initialized
ERROR - 2018-04-25 00:48:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:49:00 --> Config Class Initialized
INFO - 2018-04-25 00:49:00 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:49:00 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:49:00 --> Utf8 Class Initialized
INFO - 2018-04-25 00:49:00 --> URI Class Initialized
DEBUG - 2018-04-25 00:49:00 --> No URI present. Default controller set.
INFO - 2018-04-25 00:49:00 --> Router Class Initialized
INFO - 2018-04-25 00:49:00 --> Output Class Initialized
INFO - 2018-04-25 00:49:00 --> Security Class Initialized
DEBUG - 2018-04-25 00:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:49:00 --> CSRF cookie sent
INFO - 2018-04-25 00:49:00 --> Input Class Initialized
INFO - 2018-04-25 00:49:00 --> Language Class Initialized
INFO - 2018-04-25 00:49:00 --> Loader Class Initialized
INFO - 2018-04-25 00:49:00 --> Helper loaded: url_helper
INFO - 2018-04-25 00:49:00 --> Helper loaded: form_helper
INFO - 2018-04-25 00:49:00 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:49:00 --> User Agent Class Initialized
INFO - 2018-04-25 00:49:00 --> Controller Class Initialized
INFO - 2018-04-25 00:49:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:49:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:49:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:49:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:49:00 --> Final output sent to browser
DEBUG - 2018-04-25 00:49:00 --> Total execution time: 0.3292
INFO - 2018-04-25 00:49:01 --> Config Class Initialized
INFO - 2018-04-25 00:49:01 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:49:01 --> Utf8 Class Initialized
INFO - 2018-04-25 00:49:01 --> URI Class Initialized
INFO - 2018-04-25 00:49:01 --> Router Class Initialized
INFO - 2018-04-25 00:49:01 --> Output Class Initialized
INFO - 2018-04-25 00:49:02 --> Security Class Initialized
DEBUG - 2018-04-25 00:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:49:02 --> CSRF cookie sent
INFO - 2018-04-25 00:49:02 --> Input Class Initialized
INFO - 2018-04-25 00:49:02 --> Language Class Initialized
ERROR - 2018-04-25 00:49:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:51:55 --> Config Class Initialized
INFO - 2018-04-25 00:51:55 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:51:55 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:51:55 --> Utf8 Class Initialized
INFO - 2018-04-25 00:51:55 --> URI Class Initialized
DEBUG - 2018-04-25 00:51:55 --> No URI present. Default controller set.
INFO - 2018-04-25 00:51:55 --> Router Class Initialized
INFO - 2018-04-25 00:51:55 --> Output Class Initialized
INFO - 2018-04-25 00:51:55 --> Security Class Initialized
DEBUG - 2018-04-25 00:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:51:55 --> CSRF cookie sent
INFO - 2018-04-25 00:51:55 --> Input Class Initialized
INFO - 2018-04-25 00:51:55 --> Language Class Initialized
INFO - 2018-04-25 00:51:55 --> Loader Class Initialized
INFO - 2018-04-25 00:51:55 --> Helper loaded: url_helper
INFO - 2018-04-25 00:51:55 --> Helper loaded: form_helper
INFO - 2018-04-25 00:51:55 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:51:55 --> User Agent Class Initialized
INFO - 2018-04-25 00:51:55 --> Controller Class Initialized
INFO - 2018-04-25 00:51:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:51:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:51:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:51:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:51:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:51:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:51:56 --> Final output sent to browser
DEBUG - 2018-04-25 00:51:56 --> Total execution time: 0.3019
INFO - 2018-04-25 00:51:57 --> Config Class Initialized
INFO - 2018-04-25 00:51:57 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:51:57 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:51:57 --> Utf8 Class Initialized
INFO - 2018-04-25 00:51:57 --> URI Class Initialized
INFO - 2018-04-25 00:51:57 --> Router Class Initialized
INFO - 2018-04-25 00:51:57 --> Output Class Initialized
INFO - 2018-04-25 00:51:57 --> Security Class Initialized
DEBUG - 2018-04-25 00:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:51:57 --> CSRF cookie sent
INFO - 2018-04-25 00:51:57 --> Input Class Initialized
INFO - 2018-04-25 00:51:57 --> Language Class Initialized
ERROR - 2018-04-25 00:51:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:53:45 --> Config Class Initialized
INFO - 2018-04-25 00:53:45 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:53:45 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:53:45 --> Utf8 Class Initialized
INFO - 2018-04-25 00:53:45 --> URI Class Initialized
DEBUG - 2018-04-25 00:53:45 --> No URI present. Default controller set.
INFO - 2018-04-25 00:53:45 --> Router Class Initialized
INFO - 2018-04-25 00:53:45 --> Output Class Initialized
INFO - 2018-04-25 00:53:45 --> Security Class Initialized
DEBUG - 2018-04-25 00:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:53:45 --> CSRF cookie sent
INFO - 2018-04-25 00:53:45 --> Input Class Initialized
INFO - 2018-04-25 00:53:45 --> Language Class Initialized
INFO - 2018-04-25 00:53:45 --> Loader Class Initialized
INFO - 2018-04-25 00:53:45 --> Helper loaded: url_helper
INFO - 2018-04-25 00:53:45 --> Helper loaded: form_helper
INFO - 2018-04-25 00:53:45 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:53:45 --> User Agent Class Initialized
INFO - 2018-04-25 00:53:45 --> Controller Class Initialized
INFO - 2018-04-25 00:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:53:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:53:46 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:53:46 --> Final output sent to browser
DEBUG - 2018-04-25 00:53:46 --> Total execution time: 0.2784
INFO - 2018-04-25 00:53:47 --> Config Class Initialized
INFO - 2018-04-25 00:53:47 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:53:47 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:53:47 --> Utf8 Class Initialized
INFO - 2018-04-25 00:53:47 --> URI Class Initialized
INFO - 2018-04-25 00:53:47 --> Router Class Initialized
INFO - 2018-04-25 00:53:47 --> Output Class Initialized
INFO - 2018-04-25 00:53:47 --> Security Class Initialized
DEBUG - 2018-04-25 00:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:53:47 --> CSRF cookie sent
INFO - 2018-04-25 00:53:47 --> Input Class Initialized
INFO - 2018-04-25 00:53:47 --> Language Class Initialized
ERROR - 2018-04-25 00:53:47 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:54:34 --> Config Class Initialized
INFO - 2018-04-25 00:54:34 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:54:34 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:54:34 --> Utf8 Class Initialized
INFO - 2018-04-25 00:54:34 --> URI Class Initialized
DEBUG - 2018-04-25 00:54:34 --> No URI present. Default controller set.
INFO - 2018-04-25 00:54:34 --> Router Class Initialized
INFO - 2018-04-25 00:54:34 --> Output Class Initialized
INFO - 2018-04-25 00:54:34 --> Security Class Initialized
DEBUG - 2018-04-25 00:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:54:34 --> CSRF cookie sent
INFO - 2018-04-25 00:54:34 --> Input Class Initialized
INFO - 2018-04-25 00:54:34 --> Language Class Initialized
INFO - 2018-04-25 00:54:34 --> Loader Class Initialized
INFO - 2018-04-25 00:54:34 --> Helper loaded: url_helper
INFO - 2018-04-25 00:54:34 --> Helper loaded: form_helper
INFO - 2018-04-25 00:54:34 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:54:34 --> User Agent Class Initialized
INFO - 2018-04-25 00:54:34 --> Controller Class Initialized
INFO - 2018-04-25 00:54:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:54:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:54:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:54:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:54:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:54:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:54:34 --> Final output sent to browser
DEBUG - 2018-04-25 00:54:34 --> Total execution time: 0.2892
INFO - 2018-04-25 00:54:36 --> Config Class Initialized
INFO - 2018-04-25 00:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:54:36 --> Utf8 Class Initialized
INFO - 2018-04-25 00:54:36 --> URI Class Initialized
INFO - 2018-04-25 00:54:36 --> Router Class Initialized
INFO - 2018-04-25 00:54:36 --> Output Class Initialized
INFO - 2018-04-25 00:54:36 --> Security Class Initialized
DEBUG - 2018-04-25 00:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:54:36 --> CSRF cookie sent
INFO - 2018-04-25 00:54:36 --> Input Class Initialized
INFO - 2018-04-25 00:54:36 --> Language Class Initialized
ERROR - 2018-04-25 00:54:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:54:45 --> Config Class Initialized
INFO - 2018-04-25 00:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:54:45 --> Utf8 Class Initialized
INFO - 2018-04-25 00:54:45 --> URI Class Initialized
DEBUG - 2018-04-25 00:54:45 --> No URI present. Default controller set.
INFO - 2018-04-25 00:54:45 --> Router Class Initialized
INFO - 2018-04-25 00:54:45 --> Output Class Initialized
INFO - 2018-04-25 00:54:45 --> Security Class Initialized
DEBUG - 2018-04-25 00:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:54:45 --> CSRF cookie sent
INFO - 2018-04-25 00:54:45 --> Input Class Initialized
INFO - 2018-04-25 00:54:45 --> Language Class Initialized
INFO - 2018-04-25 00:54:45 --> Loader Class Initialized
INFO - 2018-04-25 00:54:45 --> Helper loaded: url_helper
INFO - 2018-04-25 00:54:45 --> Helper loaded: form_helper
INFO - 2018-04-25 00:54:45 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:54:45 --> User Agent Class Initialized
INFO - 2018-04-25 00:54:45 --> Controller Class Initialized
INFO - 2018-04-25 00:54:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:54:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:54:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:54:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:54:46 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:54:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:54:46 --> Final output sent to browser
DEBUG - 2018-04-25 00:54:46 --> Total execution time: 0.2829
INFO - 2018-04-25 00:54:47 --> Config Class Initialized
INFO - 2018-04-25 00:54:47 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:54:47 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:54:47 --> Utf8 Class Initialized
INFO - 2018-04-25 00:54:47 --> URI Class Initialized
INFO - 2018-04-25 00:54:47 --> Router Class Initialized
INFO - 2018-04-25 00:54:47 --> Output Class Initialized
INFO - 2018-04-25 00:54:47 --> Security Class Initialized
DEBUG - 2018-04-25 00:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:54:47 --> CSRF cookie sent
INFO - 2018-04-25 00:54:47 --> Input Class Initialized
INFO - 2018-04-25 00:54:47 --> Language Class Initialized
ERROR - 2018-04-25 00:54:47 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:54:58 --> Config Class Initialized
INFO - 2018-04-25 00:54:58 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:54:58 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:54:58 --> Utf8 Class Initialized
INFO - 2018-04-25 00:54:58 --> URI Class Initialized
DEBUG - 2018-04-25 00:54:58 --> No URI present. Default controller set.
INFO - 2018-04-25 00:54:58 --> Router Class Initialized
INFO - 2018-04-25 00:54:58 --> Output Class Initialized
INFO - 2018-04-25 00:54:58 --> Security Class Initialized
DEBUG - 2018-04-25 00:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:54:58 --> CSRF cookie sent
INFO - 2018-04-25 00:54:58 --> Input Class Initialized
INFO - 2018-04-25 00:54:58 --> Language Class Initialized
INFO - 2018-04-25 00:54:58 --> Loader Class Initialized
INFO - 2018-04-25 00:54:58 --> Helper loaded: url_helper
INFO - 2018-04-25 00:54:58 --> Helper loaded: form_helper
INFO - 2018-04-25 00:54:58 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:54:58 --> User Agent Class Initialized
INFO - 2018-04-25 00:54:58 --> Controller Class Initialized
INFO - 2018-04-25 00:54:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:54:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:54:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:54:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:54:58 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:54:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:54:58 --> Final output sent to browser
DEBUG - 2018-04-25 00:54:58 --> Total execution time: 0.2818
INFO - 2018-04-25 00:55:00 --> Config Class Initialized
INFO - 2018-04-25 00:55:00 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:55:00 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:55:00 --> Utf8 Class Initialized
INFO - 2018-04-25 00:55:00 --> URI Class Initialized
INFO - 2018-04-25 00:55:00 --> Router Class Initialized
INFO - 2018-04-25 00:55:00 --> Output Class Initialized
INFO - 2018-04-25 00:55:00 --> Security Class Initialized
DEBUG - 2018-04-25 00:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:55:00 --> CSRF cookie sent
INFO - 2018-04-25 00:55:00 --> Input Class Initialized
INFO - 2018-04-25 00:55:00 --> Language Class Initialized
ERROR - 2018-04-25 00:55:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:57:54 --> Config Class Initialized
INFO - 2018-04-25 00:57:54 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:57:54 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:57:54 --> Utf8 Class Initialized
INFO - 2018-04-25 00:57:54 --> URI Class Initialized
DEBUG - 2018-04-25 00:57:54 --> No URI present. Default controller set.
INFO - 2018-04-25 00:57:54 --> Router Class Initialized
INFO - 2018-04-25 00:57:54 --> Output Class Initialized
INFO - 2018-04-25 00:57:54 --> Security Class Initialized
DEBUG - 2018-04-25 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:57:54 --> CSRF cookie sent
INFO - 2018-04-25 00:57:54 --> Input Class Initialized
INFO - 2018-04-25 00:57:54 --> Language Class Initialized
INFO - 2018-04-25 00:57:55 --> Loader Class Initialized
INFO - 2018-04-25 00:57:55 --> Helper loaded: url_helper
INFO - 2018-04-25 00:57:55 --> Helper loaded: form_helper
INFO - 2018-04-25 00:57:55 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:57:55 --> User Agent Class Initialized
INFO - 2018-04-25 00:57:55 --> Controller Class Initialized
INFO - 2018-04-25 00:57:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:57:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:57:55 --> Pixel_Model class loaded
INFO - 2018-04-25 00:57:55 --> Database Driver Class Initialized
INFO - 2018-04-25 00:57:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 00:57:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:57:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:57:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:57:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:57:55 --> Final output sent to browser
DEBUG - 2018-04-25 00:57:55 --> Total execution time: 0.6659
INFO - 2018-04-25 00:57:57 --> Config Class Initialized
INFO - 2018-04-25 00:57:57 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:57:57 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:57:57 --> Utf8 Class Initialized
INFO - 2018-04-25 00:57:57 --> URI Class Initialized
INFO - 2018-04-25 00:57:57 --> Router Class Initialized
INFO - 2018-04-25 00:57:57 --> Output Class Initialized
INFO - 2018-04-25 00:57:57 --> Security Class Initialized
DEBUG - 2018-04-25 00:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:57:57 --> CSRF cookie sent
INFO - 2018-04-25 00:57:57 --> Input Class Initialized
INFO - 2018-04-25 00:57:57 --> Language Class Initialized
ERROR - 2018-04-25 00:57:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:58:59 --> Config Class Initialized
INFO - 2018-04-25 00:58:59 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:58:59 --> Utf8 Class Initialized
INFO - 2018-04-25 00:58:59 --> URI Class Initialized
DEBUG - 2018-04-25 00:58:59 --> No URI present. Default controller set.
INFO - 2018-04-25 00:58:59 --> Router Class Initialized
INFO - 2018-04-25 00:58:59 --> Output Class Initialized
INFO - 2018-04-25 00:58:59 --> Security Class Initialized
DEBUG - 2018-04-25 00:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:58:59 --> CSRF cookie sent
INFO - 2018-04-25 00:58:59 --> Input Class Initialized
INFO - 2018-04-25 00:58:59 --> Language Class Initialized
INFO - 2018-04-25 00:58:59 --> Loader Class Initialized
INFO - 2018-04-25 00:58:59 --> Helper loaded: url_helper
INFO - 2018-04-25 00:58:59 --> Helper loaded: form_helper
INFO - 2018-04-25 00:58:59 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:58:59 --> User Agent Class Initialized
INFO - 2018-04-25 00:58:59 --> Controller Class Initialized
INFO - 2018-04-25 00:58:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:58:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:58:59 --> Pixel_Model class loaded
INFO - 2018-04-25 00:58:59 --> Database Driver Class Initialized
INFO - 2018-04-25 00:58:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 00:58:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:58:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:58:59 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:58:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:58:59 --> Final output sent to browser
DEBUG - 2018-04-25 00:58:59 --> Total execution time: 0.3669
INFO - 2018-04-25 00:59:01 --> Config Class Initialized
INFO - 2018-04-25 00:59:01 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:59:01 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:59:01 --> Utf8 Class Initialized
INFO - 2018-04-25 00:59:01 --> URI Class Initialized
INFO - 2018-04-25 00:59:01 --> Router Class Initialized
INFO - 2018-04-25 00:59:01 --> Output Class Initialized
INFO - 2018-04-25 00:59:01 --> Security Class Initialized
DEBUG - 2018-04-25 00:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:59:01 --> CSRF cookie sent
INFO - 2018-04-25 00:59:01 --> Input Class Initialized
INFO - 2018-04-25 00:59:01 --> Language Class Initialized
ERROR - 2018-04-25 00:59:01 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:59:21 --> Config Class Initialized
INFO - 2018-04-25 00:59:21 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:59:21 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:59:21 --> Utf8 Class Initialized
INFO - 2018-04-25 00:59:21 --> URI Class Initialized
DEBUG - 2018-04-25 00:59:21 --> No URI present. Default controller set.
INFO - 2018-04-25 00:59:21 --> Router Class Initialized
INFO - 2018-04-25 00:59:21 --> Output Class Initialized
INFO - 2018-04-25 00:59:21 --> Security Class Initialized
DEBUG - 2018-04-25 00:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:59:21 --> CSRF cookie sent
INFO - 2018-04-25 00:59:21 --> Input Class Initialized
INFO - 2018-04-25 00:59:21 --> Language Class Initialized
INFO - 2018-04-25 00:59:21 --> Loader Class Initialized
INFO - 2018-04-25 00:59:21 --> Helper loaded: url_helper
INFO - 2018-04-25 00:59:21 --> Helper loaded: form_helper
INFO - 2018-04-25 00:59:21 --> Helper loaded: language_helper
DEBUG - 2018-04-25 00:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 00:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 00:59:21 --> User Agent Class Initialized
INFO - 2018-04-25 00:59:21 --> Controller Class Initialized
INFO - 2018-04-25 00:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 00:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 00:59:22 --> Pixel_Model class loaded
INFO - 2018-04-25 00:59:22 --> Database Driver Class Initialized
INFO - 2018-04-25 00:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 00:59:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 00:59:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 00:59:22 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 00:59:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 00:59:22 --> Final output sent to browser
DEBUG - 2018-04-25 00:59:22 --> Total execution time: 0.3625
INFO - 2018-04-25 00:59:23 --> Config Class Initialized
INFO - 2018-04-25 00:59:23 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:59:23 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:59:23 --> Utf8 Class Initialized
INFO - 2018-04-25 00:59:23 --> URI Class Initialized
INFO - 2018-04-25 00:59:23 --> Router Class Initialized
INFO - 2018-04-25 00:59:23 --> Output Class Initialized
INFO - 2018-04-25 00:59:23 --> Security Class Initialized
DEBUG - 2018-04-25 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:59:23 --> CSRF cookie sent
INFO - 2018-04-25 00:59:23 --> Input Class Initialized
INFO - 2018-04-25 00:59:23 --> Language Class Initialized
ERROR - 2018-04-25 00:59:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 00:59:47 --> Config Class Initialized
INFO - 2018-04-25 00:59:47 --> Hooks Class Initialized
DEBUG - 2018-04-25 00:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-25 00:59:47 --> Utf8 Class Initialized
INFO - 2018-04-25 00:59:47 --> URI Class Initialized
INFO - 2018-04-25 00:59:47 --> Router Class Initialized
INFO - 2018-04-25 00:59:47 --> Output Class Initialized
INFO - 2018-04-25 00:59:47 --> Security Class Initialized
DEBUG - 2018-04-25 00:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 00:59:47 --> CSRF cookie sent
INFO - 2018-04-25 00:59:47 --> Input Class Initialized
INFO - 2018-04-25 00:59:47 --> Language Class Initialized
ERROR - 2018-04-25 00:59:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:01:10 --> Config Class Initialized
INFO - 2018-04-25 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:01:10 --> Utf8 Class Initialized
INFO - 2018-04-25 01:01:10 --> URI Class Initialized
DEBUG - 2018-04-25 01:01:10 --> No URI present. Default controller set.
INFO - 2018-04-25 01:01:10 --> Router Class Initialized
INFO - 2018-04-25 01:01:10 --> Output Class Initialized
INFO - 2018-04-25 01:01:11 --> Security Class Initialized
DEBUG - 2018-04-25 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:01:11 --> CSRF cookie sent
INFO - 2018-04-25 01:01:11 --> Input Class Initialized
INFO - 2018-04-25 01:01:11 --> Language Class Initialized
INFO - 2018-04-25 01:01:11 --> Loader Class Initialized
INFO - 2018-04-25 01:01:11 --> Helper loaded: url_helper
INFO - 2018-04-25 01:01:11 --> Helper loaded: form_helper
INFO - 2018-04-25 01:01:11 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:01:11 --> User Agent Class Initialized
INFO - 2018-04-25 01:01:11 --> Controller Class Initialized
INFO - 2018-04-25 01:01:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:01:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:01:11 --> Pixel_Model class loaded
INFO - 2018-04-25 01:01:11 --> Database Driver Class Initialized
INFO - 2018-04-25 01:01:11 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:01:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:01:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:01:11 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:01:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:01:11 --> Final output sent to browser
DEBUG - 2018-04-25 01:01:11 --> Total execution time: 0.3344
INFO - 2018-04-25 01:01:11 --> Config Class Initialized
INFO - 2018-04-25 01:01:11 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:01:11 --> Utf8 Class Initialized
INFO - 2018-04-25 01:01:11 --> URI Class Initialized
INFO - 2018-04-25 01:01:11 --> Router Class Initialized
INFO - 2018-04-25 01:01:11 --> Output Class Initialized
INFO - 2018-04-25 01:01:11 --> Security Class Initialized
DEBUG - 2018-04-25 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:01:11 --> CSRF cookie sent
INFO - 2018-04-25 01:01:11 --> Input Class Initialized
INFO - 2018-04-25 01:01:11 --> Language Class Initialized
ERROR - 2018-04-25 01:01:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:01:13 --> Config Class Initialized
INFO - 2018-04-25 01:01:13 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:01:13 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:01:13 --> Utf8 Class Initialized
INFO - 2018-04-25 01:01:13 --> URI Class Initialized
INFO - 2018-04-25 01:01:13 --> Router Class Initialized
INFO - 2018-04-25 01:01:13 --> Output Class Initialized
INFO - 2018-04-25 01:01:13 --> Security Class Initialized
DEBUG - 2018-04-25 01:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:01:13 --> CSRF cookie sent
INFO - 2018-04-25 01:01:13 --> Input Class Initialized
INFO - 2018-04-25 01:01:13 --> Language Class Initialized
ERROR - 2018-04-25 01:01:13 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:02:02 --> Config Class Initialized
INFO - 2018-04-25 01:02:02 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:02 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:02 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:02 --> URI Class Initialized
DEBUG - 2018-04-25 01:02:02 --> No URI present. Default controller set.
INFO - 2018-04-25 01:02:02 --> Router Class Initialized
INFO - 2018-04-25 01:02:02 --> Output Class Initialized
INFO - 2018-04-25 01:02:02 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:02 --> CSRF cookie sent
INFO - 2018-04-25 01:02:02 --> Input Class Initialized
INFO - 2018-04-25 01:02:02 --> Language Class Initialized
INFO - 2018-04-25 01:02:02 --> Loader Class Initialized
INFO - 2018-04-25 01:02:02 --> Helper loaded: url_helper
INFO - 2018-04-25 01:02:02 --> Helper loaded: form_helper
INFO - 2018-04-25 01:02:02 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:02:03 --> User Agent Class Initialized
INFO - 2018-04-25 01:02:03 --> Controller Class Initialized
INFO - 2018-04-25 01:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:02:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:02:03 --> Pixel_Model class loaded
INFO - 2018-04-25 01:02:03 --> Database Driver Class Initialized
INFO - 2018-04-25 01:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:02:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:02:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:02:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:02:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:02:03 --> Final output sent to browser
DEBUG - 2018-04-25 01:02:03 --> Total execution time: 0.3329
INFO - 2018-04-25 01:02:05 --> Config Class Initialized
INFO - 2018-04-25 01:02:05 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:05 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:05 --> URI Class Initialized
INFO - 2018-04-25 01:02:05 --> Router Class Initialized
INFO - 2018-04-25 01:02:05 --> Output Class Initialized
INFO - 2018-04-25 01:02:05 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:05 --> CSRF cookie sent
INFO - 2018-04-25 01:02:05 --> Input Class Initialized
INFO - 2018-04-25 01:02:05 --> Language Class Initialized
ERROR - 2018-04-25 01:02:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:02:28 --> Config Class Initialized
INFO - 2018-04-25 01:02:28 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:28 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:28 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:28 --> URI Class Initialized
DEBUG - 2018-04-25 01:02:28 --> No URI present. Default controller set.
INFO - 2018-04-25 01:02:28 --> Router Class Initialized
INFO - 2018-04-25 01:02:28 --> Output Class Initialized
INFO - 2018-04-25 01:02:28 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:28 --> CSRF cookie sent
INFO - 2018-04-25 01:02:28 --> Input Class Initialized
INFO - 2018-04-25 01:02:28 --> Language Class Initialized
INFO - 2018-04-25 01:02:28 --> Loader Class Initialized
INFO - 2018-04-25 01:02:28 --> Helper loaded: url_helper
INFO - 2018-04-25 01:02:28 --> Helper loaded: form_helper
INFO - 2018-04-25 01:02:28 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:02:28 --> User Agent Class Initialized
INFO - 2018-04-25 01:02:29 --> Controller Class Initialized
INFO - 2018-04-25 01:02:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:02:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:02:29 --> Pixel_Model class loaded
INFO - 2018-04-25 01:02:29 --> Database Driver Class Initialized
INFO - 2018-04-25 01:02:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:02:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:02:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:02:29 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:02:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:02:29 --> Final output sent to browser
DEBUG - 2018-04-25 01:02:29 --> Total execution time: 0.3711
INFO - 2018-04-25 01:02:30 --> Config Class Initialized
INFO - 2018-04-25 01:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:30 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:30 --> URI Class Initialized
INFO - 2018-04-25 01:02:30 --> Router Class Initialized
INFO - 2018-04-25 01:02:30 --> Output Class Initialized
INFO - 2018-04-25 01:02:30 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:30 --> CSRF cookie sent
INFO - 2018-04-25 01:02:30 --> Input Class Initialized
INFO - 2018-04-25 01:02:30 --> Language Class Initialized
ERROR - 2018-04-25 01:02:30 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:02:38 --> Config Class Initialized
INFO - 2018-04-25 01:02:38 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:38 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:38 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:38 --> URI Class Initialized
DEBUG - 2018-04-25 01:02:38 --> No URI present. Default controller set.
INFO - 2018-04-25 01:02:38 --> Router Class Initialized
INFO - 2018-04-25 01:02:38 --> Output Class Initialized
INFO - 2018-04-25 01:02:38 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:38 --> CSRF cookie sent
INFO - 2018-04-25 01:02:38 --> Input Class Initialized
INFO - 2018-04-25 01:02:38 --> Language Class Initialized
INFO - 2018-04-25 01:02:38 --> Loader Class Initialized
INFO - 2018-04-25 01:02:38 --> Helper loaded: url_helper
INFO - 2018-04-25 01:02:38 --> Helper loaded: form_helper
INFO - 2018-04-25 01:02:38 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:02:38 --> User Agent Class Initialized
INFO - 2018-04-25 01:02:38 --> Controller Class Initialized
INFO - 2018-04-25 01:02:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:02:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:02:38 --> Pixel_Model class loaded
INFO - 2018-04-25 01:02:38 --> Database Driver Class Initialized
INFO - 2018-04-25 01:02:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:02:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:02:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:02:38 --> Final output sent to browser
DEBUG - 2018-04-25 01:02:38 --> Total execution time: 0.3825
INFO - 2018-04-25 01:02:40 --> Config Class Initialized
INFO - 2018-04-25 01:02:40 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:40 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:40 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:40 --> URI Class Initialized
INFO - 2018-04-25 01:02:40 --> Router Class Initialized
INFO - 2018-04-25 01:02:40 --> Output Class Initialized
INFO - 2018-04-25 01:02:40 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:40 --> CSRF cookie sent
INFO - 2018-04-25 01:02:40 --> Input Class Initialized
INFO - 2018-04-25 01:02:40 --> Language Class Initialized
ERROR - 2018-04-25 01:02:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:02:48 --> Config Class Initialized
INFO - 2018-04-25 01:02:48 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:48 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:48 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:48 --> URI Class Initialized
DEBUG - 2018-04-25 01:02:48 --> No URI present. Default controller set.
INFO - 2018-04-25 01:02:48 --> Router Class Initialized
INFO - 2018-04-25 01:02:48 --> Output Class Initialized
INFO - 2018-04-25 01:02:48 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:48 --> CSRF cookie sent
INFO - 2018-04-25 01:02:48 --> Input Class Initialized
INFO - 2018-04-25 01:02:48 --> Language Class Initialized
INFO - 2018-04-25 01:02:48 --> Loader Class Initialized
INFO - 2018-04-25 01:02:48 --> Helper loaded: url_helper
INFO - 2018-04-25 01:02:48 --> Helper loaded: form_helper
INFO - 2018-04-25 01:02:48 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:02:48 --> User Agent Class Initialized
INFO - 2018-04-25 01:02:48 --> Controller Class Initialized
INFO - 2018-04-25 01:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:02:48 --> Pixel_Model class loaded
INFO - 2018-04-25 01:02:48 --> Database Driver Class Initialized
INFO - 2018-04-25 01:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:02:48 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:02:48 --> Final output sent to browser
DEBUG - 2018-04-25 01:02:48 --> Total execution time: 0.3774
INFO - 2018-04-25 01:02:50 --> Config Class Initialized
INFO - 2018-04-25 01:02:50 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:02:50 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:02:50 --> Utf8 Class Initialized
INFO - 2018-04-25 01:02:50 --> URI Class Initialized
INFO - 2018-04-25 01:02:50 --> Router Class Initialized
INFO - 2018-04-25 01:02:50 --> Output Class Initialized
INFO - 2018-04-25 01:02:50 --> Security Class Initialized
DEBUG - 2018-04-25 01:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:02:50 --> CSRF cookie sent
INFO - 2018-04-25 01:02:50 --> Input Class Initialized
INFO - 2018-04-25 01:02:50 --> Language Class Initialized
ERROR - 2018-04-25 01:02:50 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:03:12 --> Config Class Initialized
INFO - 2018-04-25 01:03:12 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:12 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:12 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:12 --> URI Class Initialized
DEBUG - 2018-04-25 01:03:12 --> No URI present. Default controller set.
INFO - 2018-04-25 01:03:12 --> Router Class Initialized
INFO - 2018-04-25 01:03:12 --> Output Class Initialized
INFO - 2018-04-25 01:03:12 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:12 --> CSRF cookie sent
INFO - 2018-04-25 01:03:12 --> Input Class Initialized
INFO - 2018-04-25 01:03:12 --> Language Class Initialized
INFO - 2018-04-25 01:03:12 --> Loader Class Initialized
INFO - 2018-04-25 01:03:12 --> Helper loaded: url_helper
INFO - 2018-04-25 01:03:12 --> Helper loaded: form_helper
INFO - 2018-04-25 01:03:12 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:03:12 --> User Agent Class Initialized
INFO - 2018-04-25 01:03:12 --> Controller Class Initialized
INFO - 2018-04-25 01:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:03:12 --> Pixel_Model class loaded
INFO - 2018-04-25 01:03:12 --> Database Driver Class Initialized
INFO - 2018-04-25 01:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:03:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:03:12 --> Final output sent to browser
DEBUG - 2018-04-25 01:03:12 --> Total execution time: 0.3727
INFO - 2018-04-25 01:03:14 --> Config Class Initialized
INFO - 2018-04-25 01:03:14 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:14 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:14 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:14 --> URI Class Initialized
INFO - 2018-04-25 01:03:14 --> Router Class Initialized
INFO - 2018-04-25 01:03:14 --> Output Class Initialized
INFO - 2018-04-25 01:03:14 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:14 --> CSRF cookie sent
INFO - 2018-04-25 01:03:14 --> Input Class Initialized
INFO - 2018-04-25 01:03:14 --> Language Class Initialized
ERROR - 2018-04-25 01:03:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:03:20 --> Config Class Initialized
INFO - 2018-04-25 01:03:20 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:20 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:20 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:20 --> URI Class Initialized
DEBUG - 2018-04-25 01:03:20 --> No URI present. Default controller set.
INFO - 2018-04-25 01:03:20 --> Router Class Initialized
INFO - 2018-04-25 01:03:20 --> Output Class Initialized
INFO - 2018-04-25 01:03:20 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:20 --> CSRF cookie sent
INFO - 2018-04-25 01:03:20 --> Input Class Initialized
INFO - 2018-04-25 01:03:20 --> Language Class Initialized
INFO - 2018-04-25 01:03:20 --> Loader Class Initialized
INFO - 2018-04-25 01:03:20 --> Helper loaded: url_helper
INFO - 2018-04-25 01:03:20 --> Helper loaded: form_helper
INFO - 2018-04-25 01:03:20 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:03:20 --> User Agent Class Initialized
INFO - 2018-04-25 01:03:20 --> Controller Class Initialized
INFO - 2018-04-25 01:03:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:03:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:03:20 --> Pixel_Model class loaded
INFO - 2018-04-25 01:03:20 --> Database Driver Class Initialized
INFO - 2018-04-25 01:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:03:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:03:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:03:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:03:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:03:20 --> Final output sent to browser
DEBUG - 2018-04-25 01:03:20 --> Total execution time: 0.3911
INFO - 2018-04-25 01:03:22 --> Config Class Initialized
INFO - 2018-04-25 01:03:22 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:22 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:22 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:22 --> URI Class Initialized
INFO - 2018-04-25 01:03:22 --> Router Class Initialized
INFO - 2018-04-25 01:03:22 --> Output Class Initialized
INFO - 2018-04-25 01:03:22 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:22 --> CSRF cookie sent
INFO - 2018-04-25 01:03:22 --> Input Class Initialized
INFO - 2018-04-25 01:03:22 --> Language Class Initialized
ERROR - 2018-04-25 01:03:22 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:03:27 --> Config Class Initialized
INFO - 2018-04-25 01:03:27 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:27 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:27 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:27 --> URI Class Initialized
INFO - 2018-04-25 01:03:27 --> Router Class Initialized
INFO - 2018-04-25 01:03:27 --> Output Class Initialized
INFO - 2018-04-25 01:03:27 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:27 --> CSRF cookie sent
INFO - 2018-04-25 01:03:27 --> Input Class Initialized
INFO - 2018-04-25 01:03:27 --> Language Class Initialized
ERROR - 2018-04-25 01:03:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:03:37 --> Config Class Initialized
INFO - 2018-04-25 01:03:37 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:37 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:37 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:37 --> URI Class Initialized
DEBUG - 2018-04-25 01:03:37 --> No URI present. Default controller set.
INFO - 2018-04-25 01:03:37 --> Router Class Initialized
INFO - 2018-04-25 01:03:37 --> Output Class Initialized
INFO - 2018-04-25 01:03:37 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:37 --> CSRF cookie sent
INFO - 2018-04-25 01:03:37 --> Input Class Initialized
INFO - 2018-04-25 01:03:37 --> Language Class Initialized
INFO - 2018-04-25 01:03:38 --> Loader Class Initialized
INFO - 2018-04-25 01:03:38 --> Helper loaded: url_helper
INFO - 2018-04-25 01:03:38 --> Helper loaded: form_helper
INFO - 2018-04-25 01:03:38 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:03:38 --> User Agent Class Initialized
INFO - 2018-04-25 01:03:38 --> Controller Class Initialized
INFO - 2018-04-25 01:03:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:03:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:03:38 --> Pixel_Model class loaded
INFO - 2018-04-25 01:03:38 --> Database Driver Class Initialized
INFO - 2018-04-25 01:03:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:03:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:03:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:03:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:03:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:03:38 --> Final output sent to browser
DEBUG - 2018-04-25 01:03:38 --> Total execution time: 0.3374
INFO - 2018-04-25 01:03:38 --> Config Class Initialized
INFO - 2018-04-25 01:03:38 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:38 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:38 --> URI Class Initialized
INFO - 2018-04-25 01:03:38 --> Router Class Initialized
INFO - 2018-04-25 01:03:38 --> Output Class Initialized
INFO - 2018-04-25 01:03:38 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:38 --> CSRF cookie sent
INFO - 2018-04-25 01:03:38 --> Input Class Initialized
INFO - 2018-04-25 01:03:38 --> Language Class Initialized
ERROR - 2018-04-25 01:03:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:03:40 --> Config Class Initialized
INFO - 2018-04-25 01:03:40 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:40 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:40 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:40 --> URI Class Initialized
INFO - 2018-04-25 01:03:40 --> Router Class Initialized
INFO - 2018-04-25 01:03:40 --> Output Class Initialized
INFO - 2018-04-25 01:03:40 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:40 --> CSRF cookie sent
INFO - 2018-04-25 01:03:40 --> Input Class Initialized
INFO - 2018-04-25 01:03:40 --> Language Class Initialized
ERROR - 2018-04-25 01:03:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:03:50 --> Config Class Initialized
INFO - 2018-04-25 01:03:50 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:50 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:50 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:50 --> URI Class Initialized
DEBUG - 2018-04-25 01:03:50 --> No URI present. Default controller set.
INFO - 2018-04-25 01:03:50 --> Router Class Initialized
INFO - 2018-04-25 01:03:50 --> Output Class Initialized
INFO - 2018-04-25 01:03:50 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:50 --> CSRF cookie sent
INFO - 2018-04-25 01:03:50 --> Input Class Initialized
INFO - 2018-04-25 01:03:50 --> Language Class Initialized
INFO - 2018-04-25 01:03:50 --> Loader Class Initialized
INFO - 2018-04-25 01:03:50 --> Helper loaded: url_helper
INFO - 2018-04-25 01:03:50 --> Helper loaded: form_helper
INFO - 2018-04-25 01:03:50 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:03:50 --> User Agent Class Initialized
INFO - 2018-04-25 01:03:50 --> Controller Class Initialized
INFO - 2018-04-25 01:03:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:03:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:03:50 --> Pixel_Model class loaded
INFO - 2018-04-25 01:03:50 --> Database Driver Class Initialized
INFO - 2018-04-25 01:03:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:03:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:03:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:03:50 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:03:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:03:50 --> Final output sent to browser
DEBUG - 2018-04-25 01:03:50 --> Total execution time: 0.3624
INFO - 2018-04-25 01:03:50 --> Config Class Initialized
INFO - 2018-04-25 01:03:50 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:50 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:50 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:50 --> URI Class Initialized
INFO - 2018-04-25 01:03:50 --> Router Class Initialized
INFO - 2018-04-25 01:03:50 --> Output Class Initialized
INFO - 2018-04-25 01:03:50 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:51 --> CSRF cookie sent
INFO - 2018-04-25 01:03:51 --> Input Class Initialized
INFO - 2018-04-25 01:03:51 --> Language Class Initialized
ERROR - 2018-04-25 01:03:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:03:52 --> Config Class Initialized
INFO - 2018-04-25 01:03:52 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:03:52 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:03:52 --> Utf8 Class Initialized
INFO - 2018-04-25 01:03:52 --> URI Class Initialized
INFO - 2018-04-25 01:03:52 --> Router Class Initialized
INFO - 2018-04-25 01:03:52 --> Output Class Initialized
INFO - 2018-04-25 01:03:52 --> Security Class Initialized
DEBUG - 2018-04-25 01:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:03:52 --> CSRF cookie sent
INFO - 2018-04-25 01:03:52 --> Input Class Initialized
INFO - 2018-04-25 01:03:52 --> Language Class Initialized
ERROR - 2018-04-25 01:03:52 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:04:00 --> Config Class Initialized
INFO - 2018-04-25 01:04:00 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:04:00 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:04:00 --> Utf8 Class Initialized
INFO - 2018-04-25 01:04:00 --> URI Class Initialized
DEBUG - 2018-04-25 01:04:00 --> No URI present. Default controller set.
INFO - 2018-04-25 01:04:00 --> Router Class Initialized
INFO - 2018-04-25 01:04:00 --> Output Class Initialized
INFO - 2018-04-25 01:04:00 --> Security Class Initialized
DEBUG - 2018-04-25 01:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:04:00 --> CSRF cookie sent
INFO - 2018-04-25 01:04:00 --> Input Class Initialized
INFO - 2018-04-25 01:04:00 --> Language Class Initialized
INFO - 2018-04-25 01:04:00 --> Loader Class Initialized
INFO - 2018-04-25 01:04:00 --> Helper loaded: url_helper
INFO - 2018-04-25 01:04:00 --> Helper loaded: form_helper
INFO - 2018-04-25 01:04:00 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:04:00 --> User Agent Class Initialized
INFO - 2018-04-25 01:04:00 --> Controller Class Initialized
INFO - 2018-04-25 01:04:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:04:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:04:00 --> Pixel_Model class loaded
INFO - 2018-04-25 01:04:00 --> Database Driver Class Initialized
INFO - 2018-04-25 01:04:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:04:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:04:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:04:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:04:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:04:00 --> Final output sent to browser
DEBUG - 2018-04-25 01:04:00 --> Total execution time: 0.3722
INFO - 2018-04-25 01:04:00 --> Config Class Initialized
INFO - 2018-04-25 01:04:00 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:04:00 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:04:01 --> Utf8 Class Initialized
INFO - 2018-04-25 01:04:01 --> URI Class Initialized
INFO - 2018-04-25 01:04:01 --> Router Class Initialized
INFO - 2018-04-25 01:04:01 --> Output Class Initialized
INFO - 2018-04-25 01:04:01 --> Security Class Initialized
DEBUG - 2018-04-25 01:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:04:01 --> CSRF cookie sent
INFO - 2018-04-25 01:04:01 --> Input Class Initialized
INFO - 2018-04-25 01:04:01 --> Language Class Initialized
ERROR - 2018-04-25 01:04:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-25 01:04:02 --> Config Class Initialized
INFO - 2018-04-25 01:04:02 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:04:02 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:04:02 --> Utf8 Class Initialized
INFO - 2018-04-25 01:04:02 --> URI Class Initialized
INFO - 2018-04-25 01:04:02 --> Router Class Initialized
INFO - 2018-04-25 01:04:02 --> Output Class Initialized
INFO - 2018-04-25 01:04:02 --> Security Class Initialized
DEBUG - 2018-04-25 01:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:04:02 --> CSRF cookie sent
INFO - 2018-04-25 01:04:02 --> Input Class Initialized
INFO - 2018-04-25 01:04:02 --> Language Class Initialized
ERROR - 2018-04-25 01:04:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 01:06:25 --> Config Class Initialized
INFO - 2018-04-25 01:06:25 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:06:25 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:06:25 --> Utf8 Class Initialized
INFO - 2018-04-25 01:06:25 --> URI Class Initialized
DEBUG - 2018-04-25 01:06:25 --> No URI present. Default controller set.
INFO - 2018-04-25 01:06:25 --> Router Class Initialized
INFO - 2018-04-25 01:06:25 --> Output Class Initialized
INFO - 2018-04-25 01:06:25 --> Security Class Initialized
DEBUG - 2018-04-25 01:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:06:25 --> CSRF cookie sent
INFO - 2018-04-25 01:06:25 --> Input Class Initialized
INFO - 2018-04-25 01:06:25 --> Language Class Initialized
INFO - 2018-04-25 01:06:25 --> Loader Class Initialized
INFO - 2018-04-25 01:06:25 --> Helper loaded: url_helper
INFO - 2018-04-25 01:06:26 --> Helper loaded: form_helper
INFO - 2018-04-25 01:06:26 --> Helper loaded: language_helper
DEBUG - 2018-04-25 01:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 01:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 01:06:26 --> User Agent Class Initialized
INFO - 2018-04-25 01:06:26 --> Controller Class Initialized
INFO - 2018-04-25 01:06:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 01:06:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 01:06:26 --> Pixel_Model class loaded
INFO - 2018-04-25 01:06:26 --> Database Driver Class Initialized
INFO - 2018-04-25 01:06:26 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 01:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 01:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 01:06:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 01:06:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 01:06:26 --> Final output sent to browser
DEBUG - 2018-04-25 01:06:26 --> Total execution time: 0.3495
INFO - 2018-04-25 01:06:27 --> Config Class Initialized
INFO - 2018-04-25 01:06:27 --> Hooks Class Initialized
DEBUG - 2018-04-25 01:06:27 --> UTF-8 Support Enabled
INFO - 2018-04-25 01:06:27 --> Utf8 Class Initialized
INFO - 2018-04-25 01:06:27 --> URI Class Initialized
INFO - 2018-04-25 01:06:27 --> Router Class Initialized
INFO - 2018-04-25 01:06:27 --> Output Class Initialized
INFO - 2018-04-25 01:06:27 --> Security Class Initialized
DEBUG - 2018-04-25 01:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 01:06:27 --> CSRF cookie sent
INFO - 2018-04-25 01:06:27 --> Input Class Initialized
INFO - 2018-04-25 01:06:27 --> Language Class Initialized
ERROR - 2018-04-25 01:06:27 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 21:26:45 --> Config Class Initialized
INFO - 2018-04-25 21:26:45 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:26:45 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:26:45 --> Utf8 Class Initialized
INFO - 2018-04-25 21:26:45 --> URI Class Initialized
DEBUG - 2018-04-25 21:26:45 --> No URI present. Default controller set.
INFO - 2018-04-25 21:26:45 --> Router Class Initialized
INFO - 2018-04-25 21:26:45 --> Output Class Initialized
INFO - 2018-04-25 21:26:45 --> Security Class Initialized
DEBUG - 2018-04-25 21:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:26:45 --> CSRF cookie sent
INFO - 2018-04-25 21:26:45 --> Input Class Initialized
INFO - 2018-04-25 21:26:45 --> Language Class Initialized
INFO - 2018-04-25 21:26:46 --> Loader Class Initialized
INFO - 2018-04-25 21:26:46 --> Helper loaded: url_helper
INFO - 2018-04-25 21:26:46 --> Helper loaded: form_helper
INFO - 2018-04-25 21:26:46 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:26:46 --> User Agent Class Initialized
INFO - 2018-04-25 21:26:46 --> Controller Class Initialized
INFO - 2018-04-25 21:26:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:26:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:26:46 --> Pixel_Model class loaded
INFO - 2018-04-25 21:26:46 --> Database Driver Class Initialized
INFO - 2018-04-25 21:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:26:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 21:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:26:47 --> Final output sent to browser
DEBUG - 2018-04-25 21:26:47 --> Total execution time: 1.9740
INFO - 2018-04-25 21:26:49 --> Config Class Initialized
INFO - 2018-04-25 21:26:49 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:26:49 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:26:49 --> Utf8 Class Initialized
INFO - 2018-04-25 21:26:49 --> URI Class Initialized
INFO - 2018-04-25 21:26:49 --> Router Class Initialized
INFO - 2018-04-25 21:26:49 --> Output Class Initialized
INFO - 2018-04-25 21:26:49 --> Security Class Initialized
DEBUG - 2018-04-25 21:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:26:49 --> CSRF cookie sent
INFO - 2018-04-25 21:26:49 --> Input Class Initialized
INFO - 2018-04-25 21:26:49 --> Config Class Initialized
INFO - 2018-04-25 21:26:49 --> Hooks Class Initialized
INFO - 2018-04-25 21:26:49 --> Language Class Initialized
DEBUG - 2018-04-25 21:26:49 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:26:49 --> Utf8 Class Initialized
INFO - 2018-04-25 21:26:49 --> Loader Class Initialized
INFO - 2018-04-25 21:26:49 --> URI Class Initialized
INFO - 2018-04-25 21:26:49 --> Helper loaded: url_helper
INFO - 2018-04-25 21:26:49 --> Router Class Initialized
INFO - 2018-04-25 21:26:49 --> Helper loaded: form_helper
INFO - 2018-04-25 21:26:49 --> Helper loaded: language_helper
INFO - 2018-04-25 21:26:49 --> Output Class Initialized
INFO - 2018-04-25 21:26:49 --> Security Class Initialized
DEBUG - 2018-04-25 21:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:26:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-25 21:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:26:49 --> CSRF cookie sent
INFO - 2018-04-25 21:26:49 --> User Agent Class Initialized
INFO - 2018-04-25 21:26:49 --> Input Class Initialized
INFO - 2018-04-25 21:26:49 --> Controller Class Initialized
INFO - 2018-04-25 21:26:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:26:49 --> Language Class Initialized
INFO - 2018-04-25 21:26:49 --> Language file loaded: language/en/form_validation_lang.php
ERROR - 2018-04-25 21:26:49 --> 404 Page Not Found: Revolution/assets
DEBUG - 2018-04-25 21:26:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-25 21:26:49 --> Could not find the language line "req_email"
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-25 21:26:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:26:49 --> Final output sent to browser
DEBUG - 2018-04-25 21:26:49 --> Total execution time: 0.6006
INFO - 2018-04-25 21:27:01 --> Config Class Initialized
INFO - 2018-04-25 21:27:01 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:01 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:01 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:01 --> URI Class Initialized
INFO - 2018-04-25 21:27:01 --> Router Class Initialized
INFO - 2018-04-25 21:27:02 --> Output Class Initialized
INFO - 2018-04-25 21:27:02 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:02 --> CSRF cookie sent
INFO - 2018-04-25 21:27:02 --> CSRF token verified
INFO - 2018-04-25 21:27:02 --> Input Class Initialized
INFO - 2018-04-25 21:27:02 --> Language Class Initialized
INFO - 2018-04-25 21:27:02 --> Loader Class Initialized
INFO - 2018-04-25 21:27:02 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:02 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:02 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:02 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:02 --> Controller Class Initialized
INFO - 2018-04-25 21:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-25 21:27:02 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-25 21:27:03 --> Form Validation Class Initialized
INFO - 2018-04-25 21:27:03 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:03 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:03 --> Model "AuthenticationModel" initialized
INFO - 2018-04-25 21:27:03 --> Config Class Initialized
INFO - 2018-04-25 21:27:03 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:03 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:03 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:03 --> URI Class Initialized
DEBUG - 2018-04-25 21:27:03 --> No URI present. Default controller set.
INFO - 2018-04-25 21:27:03 --> Router Class Initialized
INFO - 2018-04-25 21:27:03 --> Output Class Initialized
INFO - 2018-04-25 21:27:03 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:03 --> CSRF cookie sent
INFO - 2018-04-25 21:27:03 --> Input Class Initialized
INFO - 2018-04-25 21:27:03 --> Language Class Initialized
INFO - 2018-04-25 21:27:03 --> Loader Class Initialized
INFO - 2018-04-25 21:27:03 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:03 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:03 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:03 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:03 --> Controller Class Initialized
INFO - 2018-04-25 21:27:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:27:03 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:03 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:27:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-25 21:27:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:27:03 --> Final output sent to browser
DEBUG - 2018-04-25 21:27:04 --> Total execution time: 0.6022
INFO - 2018-04-25 21:27:05 --> Config Class Initialized
INFO - 2018-04-25 21:27:05 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:05 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:05 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:05 --> URI Class Initialized
INFO - 2018-04-25 21:27:05 --> Router Class Initialized
INFO - 2018-04-25 21:27:05 --> Output Class Initialized
INFO - 2018-04-25 21:27:05 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:05 --> CSRF cookie sent
INFO - 2018-04-25 21:27:05 --> Input Class Initialized
INFO - 2018-04-25 21:27:05 --> Language Class Initialized
ERROR - 2018-04-25 21:27:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-25 21:27:15 --> Config Class Initialized
INFO - 2018-04-25 21:27:15 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:15 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:15 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:15 --> URI Class Initialized
INFO - 2018-04-25 21:27:15 --> Router Class Initialized
INFO - 2018-04-25 21:27:15 --> Output Class Initialized
INFO - 2018-04-25 21:27:15 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:15 --> CSRF cookie sent
INFO - 2018-04-25 21:27:15 --> Input Class Initialized
INFO - 2018-04-25 21:27:15 --> Language Class Initialized
INFO - 2018-04-25 21:27:15 --> Loader Class Initialized
INFO - 2018-04-25 21:27:15 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:15 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:15 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:15 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:15 --> Controller Class Initialized
INFO - 2018-04-25 21:27:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:27:15 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:15 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:15 --> Model "MyAccountModel" initialized
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-25 21:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:27:15 --> Final output sent to browser
DEBUG - 2018-04-25 21:27:15 --> Total execution time: 0.4919
INFO - 2018-04-25 21:27:18 --> Config Class Initialized
INFO - 2018-04-25 21:27:18 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:18 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:18 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:18 --> URI Class Initialized
INFO - 2018-04-25 21:27:18 --> Router Class Initialized
INFO - 2018-04-25 21:27:18 --> Output Class Initialized
INFO - 2018-04-25 21:27:18 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:18 --> CSRF cookie sent
INFO - 2018-04-25 21:27:18 --> Input Class Initialized
INFO - 2018-04-25 21:27:18 --> Language Class Initialized
INFO - 2018-04-25 21:27:18 --> Loader Class Initialized
INFO - 2018-04-25 21:27:18 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:18 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:18 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:18 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:18 --> Controller Class Initialized
INFO - 2018-04-25 21:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:27:18 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:18 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:18 --> Model "MyAccountModel" initialized
INFO - 2018-04-25 21:27:18 --> Config Class Initialized
INFO - 2018-04-25 21:27:18 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:18 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:18 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:18 --> URI Class Initialized
INFO - 2018-04-25 21:27:18 --> Router Class Initialized
INFO - 2018-04-25 21:27:18 --> Output Class Initialized
INFO - 2018-04-25 21:27:18 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:18 --> CSRF cookie sent
INFO - 2018-04-25 21:27:18 --> Input Class Initialized
INFO - 2018-04-25 21:27:18 --> Language Class Initialized
INFO - 2018-04-25 21:27:18 --> Loader Class Initialized
INFO - 2018-04-25 21:27:18 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:18 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:18 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:18 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:18 --> Controller Class Initialized
INFO - 2018-04-25 21:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:27:18 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:18 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-25 21:27:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:27:19 --> Final output sent to browser
DEBUG - 2018-04-25 21:27:19 --> Total execution time: 0.4525
INFO - 2018-04-25 21:27:41 --> Config Class Initialized
INFO - 2018-04-25 21:27:41 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:27:41 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:27:41 --> Utf8 Class Initialized
INFO - 2018-04-25 21:27:42 --> URI Class Initialized
INFO - 2018-04-25 21:27:42 --> Router Class Initialized
INFO - 2018-04-25 21:27:42 --> Output Class Initialized
INFO - 2018-04-25 21:27:42 --> Security Class Initialized
DEBUG - 2018-04-25 21:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:27:42 --> CSRF cookie sent
INFO - 2018-04-25 21:27:42 --> Input Class Initialized
INFO - 2018-04-25 21:27:42 --> Language Class Initialized
INFO - 2018-04-25 21:27:42 --> Loader Class Initialized
INFO - 2018-04-25 21:27:42 --> Helper loaded: url_helper
INFO - 2018-04-25 21:27:42 --> Helper loaded: form_helper
INFO - 2018-04-25 21:27:42 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:27:42 --> User Agent Class Initialized
INFO - 2018-04-25 21:27:42 --> Controller Class Initialized
INFO - 2018-04-25 21:27:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:27:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:27:42 --> Pixel_Model class loaded
INFO - 2018-04-25 21:27:42 --> Database Driver Class Initialized
INFO - 2018-04-25 21:27:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-25 21:27:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:27:42 --> Final output sent to browser
DEBUG - 2018-04-25 21:27:42 --> Total execution time: 0.3729
INFO - 2018-04-25 21:28:41 --> Config Class Initialized
INFO - 2018-04-25 21:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:28:41 --> Utf8 Class Initialized
INFO - 2018-04-25 21:28:41 --> URI Class Initialized
INFO - 2018-04-25 21:28:41 --> Router Class Initialized
INFO - 2018-04-25 21:28:41 --> Output Class Initialized
INFO - 2018-04-25 21:28:41 --> Security Class Initialized
DEBUG - 2018-04-25 21:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:28:42 --> CSRF cookie sent
INFO - 2018-04-25 21:28:42 --> Input Class Initialized
INFO - 2018-04-25 21:28:42 --> Language Class Initialized
INFO - 2018-04-25 21:28:42 --> Loader Class Initialized
INFO - 2018-04-25 21:28:42 --> Helper loaded: url_helper
INFO - 2018-04-25 21:28:42 --> Helper loaded: form_helper
INFO - 2018-04-25 21:28:42 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:28:42 --> User Agent Class Initialized
INFO - 2018-04-25 21:28:42 --> Controller Class Initialized
INFO - 2018-04-25 21:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:28:42 --> Pixel_Model class loaded
INFO - 2018-04-25 21:28:42 --> Database Driver Class Initialized
INFO - 2018-04-25 21:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-25 21:28:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:28:42 --> Final output sent to browser
DEBUG - 2018-04-25 21:28:42 --> Total execution time: 0.3504
INFO - 2018-04-25 21:28:46 --> Config Class Initialized
INFO - 2018-04-25 21:28:46 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:28:46 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:28:46 --> Utf8 Class Initialized
INFO - 2018-04-25 21:28:46 --> URI Class Initialized
INFO - 2018-04-25 21:28:46 --> Router Class Initialized
INFO - 2018-04-25 21:28:46 --> Output Class Initialized
INFO - 2018-04-25 21:28:46 --> Security Class Initialized
DEBUG - 2018-04-25 21:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:28:46 --> CSRF cookie sent
INFO - 2018-04-25 21:28:46 --> Input Class Initialized
INFO - 2018-04-25 21:28:46 --> Language Class Initialized
INFO - 2018-04-25 21:28:46 --> Loader Class Initialized
INFO - 2018-04-25 21:28:46 --> Helper loaded: url_helper
INFO - 2018-04-25 21:28:46 --> Helper loaded: form_helper
INFO - 2018-04-25 21:28:46 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:28:46 --> User Agent Class Initialized
INFO - 2018-04-25 21:28:46 --> Controller Class Initialized
INFO - 2018-04-25 21:28:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:28:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:28:46 --> Pixel_Model class loaded
INFO - 2018-04-25 21:28:46 --> Database Driver Class Initialized
INFO - 2018-04-25 21:28:46 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:28:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:28:46 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:28:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:28:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:28:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:28:47 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-25 21:28:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:28:47 --> Final output sent to browser
DEBUG - 2018-04-25 21:28:47 --> Total execution time: 0.3472
INFO - 2018-04-25 21:31:28 --> Config Class Initialized
INFO - 2018-04-25 21:31:28 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:31:28 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:31:28 --> Utf8 Class Initialized
INFO - 2018-04-25 21:31:28 --> URI Class Initialized
INFO - 2018-04-25 21:31:28 --> Router Class Initialized
INFO - 2018-04-25 21:31:28 --> Output Class Initialized
INFO - 2018-04-25 21:31:28 --> Security Class Initialized
DEBUG - 2018-04-25 21:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:31:28 --> CSRF cookie sent
INFO - 2018-04-25 21:31:28 --> Input Class Initialized
INFO - 2018-04-25 21:31:28 --> Language Class Initialized
INFO - 2018-04-25 21:31:28 --> Loader Class Initialized
INFO - 2018-04-25 21:31:28 --> Helper loaded: url_helper
INFO - 2018-04-25 21:31:28 --> Helper loaded: form_helper
INFO - 2018-04-25 21:31:28 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:31:28 --> User Agent Class Initialized
INFO - 2018-04-25 21:31:28 --> Controller Class Initialized
INFO - 2018-04-25 21:31:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:31:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:31:28 --> Pixel_Model class loaded
INFO - 2018-04-25 21:31:28 --> Database Driver Class Initialized
INFO - 2018-04-25 21:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-25 21:31:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:31:28 --> Final output sent to browser
DEBUG - 2018-04-25 21:31:29 --> Total execution time: 0.3554
INFO - 2018-04-25 21:31:39 --> Config Class Initialized
INFO - 2018-04-25 21:31:39 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:31:39 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:31:39 --> Utf8 Class Initialized
INFO - 2018-04-25 21:31:39 --> URI Class Initialized
INFO - 2018-04-25 21:31:39 --> Router Class Initialized
INFO - 2018-04-25 21:31:39 --> Output Class Initialized
INFO - 2018-04-25 21:31:39 --> Security Class Initialized
DEBUG - 2018-04-25 21:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:31:39 --> CSRF cookie sent
INFO - 2018-04-25 21:31:39 --> CSRF token verified
INFO - 2018-04-25 21:31:39 --> Input Class Initialized
INFO - 2018-04-25 21:31:39 --> Language Class Initialized
INFO - 2018-04-25 21:31:39 --> Loader Class Initialized
INFO - 2018-04-25 21:31:39 --> Helper loaded: url_helper
INFO - 2018-04-25 21:31:39 --> Helper loaded: form_helper
INFO - 2018-04-25 21:31:39 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:31:39 --> User Agent Class Initialized
INFO - 2018-04-25 21:31:39 --> Controller Class Initialized
INFO - 2018-04-25 21:31:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:31:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:31:39 --> Pixel_Model class loaded
INFO - 2018-04-25 21:31:39 --> Database Driver Class Initialized
INFO - 2018-04-25 21:31:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:31:39 --> Form Validation Class Initialized
INFO - 2018-04-25 21:31:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-25 21:31:39 --> Config Class Initialized
INFO - 2018-04-25 21:31:39 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:31:39 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:31:39 --> Utf8 Class Initialized
INFO - 2018-04-25 21:31:39 --> URI Class Initialized
INFO - 2018-04-25 21:31:39 --> Router Class Initialized
INFO - 2018-04-25 21:31:39 --> Output Class Initialized
INFO - 2018-04-25 21:31:39 --> Security Class Initialized
DEBUG - 2018-04-25 21:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:31:39 --> CSRF cookie sent
INFO - 2018-04-25 21:31:39 --> Input Class Initialized
INFO - 2018-04-25 21:31:39 --> Language Class Initialized
INFO - 2018-04-25 21:31:39 --> Loader Class Initialized
INFO - 2018-04-25 21:31:39 --> Helper loaded: url_helper
INFO - 2018-04-25 21:31:39 --> Helper loaded: form_helper
INFO - 2018-04-25 21:31:39 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:31:39 --> User Agent Class Initialized
INFO - 2018-04-25 21:31:39 --> Controller Class Initialized
INFO - 2018-04-25 21:31:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:31:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:31:39 --> Pixel_Model class loaded
INFO - 2018-04-25 21:31:39 --> Database Driver Class Initialized
INFO - 2018-04-25 21:31:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-25 21:31:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:31:40 --> Final output sent to browser
DEBUG - 2018-04-25 21:31:40 --> Total execution time: 0.4107
INFO - 2018-04-25 21:36:44 --> Config Class Initialized
INFO - 2018-04-25 21:36:44 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:36:44 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:36:44 --> Utf8 Class Initialized
INFO - 2018-04-25 21:36:44 --> URI Class Initialized
INFO - 2018-04-25 21:36:44 --> Router Class Initialized
INFO - 2018-04-25 21:36:44 --> Output Class Initialized
INFO - 2018-04-25 21:36:44 --> Security Class Initialized
DEBUG - 2018-04-25 21:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:36:44 --> CSRF cookie sent
INFO - 2018-04-25 21:36:44 --> CSRF token verified
INFO - 2018-04-25 21:36:44 --> Input Class Initialized
INFO - 2018-04-25 21:36:44 --> Language Class Initialized
INFO - 2018-04-25 21:36:44 --> Loader Class Initialized
INFO - 2018-04-25 21:36:44 --> Helper loaded: url_helper
INFO - 2018-04-25 21:36:45 --> Helper loaded: form_helper
INFO - 2018-04-25 21:36:45 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:36:45 --> User Agent Class Initialized
INFO - 2018-04-25 21:36:45 --> Controller Class Initialized
INFO - 2018-04-25 21:36:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:36:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:36:45 --> Pixel_Model class loaded
INFO - 2018-04-25 21:36:45 --> Database Driver Class Initialized
INFO - 2018-04-25 21:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:36:45 --> Form Validation Class Initialized
INFO - 2018-04-25 21:36:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-25 21:36:45 --> Config Class Initialized
INFO - 2018-04-25 21:36:45 --> Hooks Class Initialized
DEBUG - 2018-04-25 21:36:45 --> UTF-8 Support Enabled
INFO - 2018-04-25 21:36:45 --> Utf8 Class Initialized
INFO - 2018-04-25 21:36:45 --> URI Class Initialized
INFO - 2018-04-25 21:36:45 --> Router Class Initialized
INFO - 2018-04-25 21:36:45 --> Output Class Initialized
INFO - 2018-04-25 21:36:45 --> Security Class Initialized
DEBUG - 2018-04-25 21:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 21:36:45 --> CSRF cookie sent
INFO - 2018-04-25 21:36:45 --> Input Class Initialized
INFO - 2018-04-25 21:36:45 --> Language Class Initialized
INFO - 2018-04-25 21:36:45 --> Loader Class Initialized
INFO - 2018-04-25 21:36:45 --> Helper loaded: url_helper
INFO - 2018-04-25 21:36:45 --> Helper loaded: form_helper
INFO - 2018-04-25 21:36:45 --> Helper loaded: language_helper
DEBUG - 2018-04-25 21:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 21:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 21:36:45 --> User Agent Class Initialized
INFO - 2018-04-25 21:36:45 --> Controller Class Initialized
INFO - 2018-04-25 21:36:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 21:36:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 21:36:45 --> Pixel_Model class loaded
INFO - 2018-04-25 21:36:45 --> Database Driver Class Initialized
INFO - 2018-04-25 21:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-25 21:36:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-25 21:36:45 --> Final output sent to browser
DEBUG - 2018-04-25 21:36:45 --> Total execution time: 0.3509
INFO - 2018-04-25 22:24:06 --> Config Class Initialized
INFO - 2018-04-25 22:24:06 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:24:06 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:24:06 --> Utf8 Class Initialized
INFO - 2018-04-25 22:24:06 --> URI Class Initialized
INFO - 2018-04-25 22:24:06 --> Router Class Initialized
INFO - 2018-04-25 22:24:06 --> Output Class Initialized
INFO - 2018-04-25 22:24:06 --> Security Class Initialized
DEBUG - 2018-04-25 22:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:24:06 --> CSRF cookie sent
INFO - 2018-04-25 22:24:06 --> Input Class Initialized
INFO - 2018-04-25 22:24:06 --> Language Class Initialized
INFO - 2018-04-25 22:24:06 --> Loader Class Initialized
INFO - 2018-04-25 22:24:06 --> Helper loaded: url_helper
INFO - 2018-04-25 22:24:06 --> Helper loaded: form_helper
INFO - 2018-04-25 22:24:06 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:24:06 --> User Agent Class Initialized
INFO - 2018-04-25 22:24:06 --> Controller Class Initialized
INFO - 2018-04-25 22:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:24:06 --> Pixel_Model class loaded
INFO - 2018-04-25 22:24:06 --> Database Driver Class Initialized
INFO - 2018-04-25 22:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:25:32 --> Config Class Initialized
INFO - 2018-04-25 22:25:32 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:25:33 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:25:33 --> Utf8 Class Initialized
INFO - 2018-04-25 22:25:33 --> URI Class Initialized
INFO - 2018-04-25 22:25:33 --> Router Class Initialized
INFO - 2018-04-25 22:25:33 --> Output Class Initialized
INFO - 2018-04-25 22:25:33 --> Security Class Initialized
DEBUG - 2018-04-25 22:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:25:33 --> CSRF cookie sent
INFO - 2018-04-25 22:25:33 --> Input Class Initialized
INFO - 2018-04-25 22:25:33 --> Language Class Initialized
INFO - 2018-04-25 22:25:33 --> Loader Class Initialized
INFO - 2018-04-25 22:25:33 --> Helper loaded: url_helper
INFO - 2018-04-25 22:25:33 --> Helper loaded: form_helper
INFO - 2018-04-25 22:25:33 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:25:33 --> User Agent Class Initialized
INFO - 2018-04-25 22:25:33 --> Controller Class Initialized
INFO - 2018-04-25 22:25:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:25:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:25:33 --> Pixel_Model class loaded
INFO - 2018-04-25 22:25:33 --> Database Driver Class Initialized
INFO - 2018-04-25 22:25:33 --> Model "QuestionsModel" initialized
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Undefined variable: app E:\www\yacopoo\application\controllers\QuestionnaireController.php 113
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\libraries\Smart.php 500
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Undefined index:  E:\www\yacopoo\application\libraries\Smart.php 500
INFO - 2018-04-25 22:25:33 --> Database Driver Class Initialized
INFO - 2018-04-25 22:25:33 --> Model "QuestionsModel" initialized
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\libraries\Smart.php 503
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\libraries\Smart.php 503
ERROR - 2018-04-25 22:25:33 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\libraries\Smart.php 511
INFO - 2018-04-25 22:25:49 --> Config Class Initialized
INFO - 2018-04-25 22:25:49 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:25:49 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:25:49 --> Utf8 Class Initialized
INFO - 2018-04-25 22:25:49 --> URI Class Initialized
INFO - 2018-04-25 22:25:49 --> Router Class Initialized
INFO - 2018-04-25 22:25:49 --> Output Class Initialized
INFO - 2018-04-25 22:25:49 --> Security Class Initialized
DEBUG - 2018-04-25 22:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:25:49 --> CSRF cookie sent
INFO - 2018-04-25 22:25:49 --> Input Class Initialized
INFO - 2018-04-25 22:25:49 --> Language Class Initialized
INFO - 2018-04-25 22:25:49 --> Loader Class Initialized
INFO - 2018-04-25 22:25:49 --> Helper loaded: url_helper
INFO - 2018-04-25 22:25:49 --> Helper loaded: form_helper
INFO - 2018-04-25 22:25:49 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:25:49 --> User Agent Class Initialized
INFO - 2018-04-25 22:25:49 --> Controller Class Initialized
INFO - 2018-04-25 22:25:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:25:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:25:49 --> Pixel_Model class loaded
INFO - 2018-04-25 22:25:49 --> Database Driver Class Initialized
INFO - 2018-04-25 22:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:25:49 --> Database Driver Class Initialized
INFO - 2018-04-25 22:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:27:02 --> Config Class Initialized
INFO - 2018-04-25 22:27:02 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:27:02 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:27:02 --> Utf8 Class Initialized
INFO - 2018-04-25 22:27:02 --> URI Class Initialized
INFO - 2018-04-25 22:27:02 --> Router Class Initialized
INFO - 2018-04-25 22:27:02 --> Output Class Initialized
INFO - 2018-04-25 22:27:02 --> Security Class Initialized
DEBUG - 2018-04-25 22:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:27:02 --> CSRF cookie sent
INFO - 2018-04-25 22:27:02 --> Input Class Initialized
INFO - 2018-04-25 22:27:02 --> Language Class Initialized
INFO - 2018-04-25 22:27:02 --> Loader Class Initialized
INFO - 2018-04-25 22:27:02 --> Helper loaded: url_helper
INFO - 2018-04-25 22:27:02 --> Helper loaded: form_helper
INFO - 2018-04-25 22:27:02 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:27:57 --> Config Class Initialized
INFO - 2018-04-25 22:27:57 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:27:57 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:27:57 --> Utf8 Class Initialized
INFO - 2018-04-25 22:27:57 --> URI Class Initialized
INFO - 2018-04-25 22:27:57 --> Router Class Initialized
INFO - 2018-04-25 22:27:57 --> Output Class Initialized
INFO - 2018-04-25 22:27:57 --> Security Class Initialized
DEBUG - 2018-04-25 22:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:27:57 --> CSRF cookie sent
INFO - 2018-04-25 22:27:57 --> Input Class Initialized
INFO - 2018-04-25 22:27:57 --> Language Class Initialized
INFO - 2018-04-25 22:27:57 --> Loader Class Initialized
INFO - 2018-04-25 22:27:57 --> Helper loaded: url_helper
INFO - 2018-04-25 22:27:57 --> Helper loaded: form_helper
INFO - 2018-04-25 22:27:57 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:27:58 --> User Agent Class Initialized
INFO - 2018-04-25 22:27:58 --> Controller Class Initialized
INFO - 2018-04-25 22:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:27:58 --> Pixel_Model class loaded
INFO - 2018-04-25 22:27:58 --> Database Driver Class Initialized
INFO - 2018-04-25 22:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:27:58 --> Database Driver Class Initialized
INFO - 2018-04-25 22:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:54:57 --> Config Class Initialized
INFO - 2018-04-25 22:54:57 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:54:57 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:54:57 --> Utf8 Class Initialized
INFO - 2018-04-25 22:54:58 --> URI Class Initialized
INFO - 2018-04-25 22:54:58 --> Router Class Initialized
INFO - 2018-04-25 22:54:58 --> Output Class Initialized
INFO - 2018-04-25 22:54:58 --> Security Class Initialized
DEBUG - 2018-04-25 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:54:58 --> CSRF cookie sent
INFO - 2018-04-25 22:54:58 --> Input Class Initialized
INFO - 2018-04-25 22:54:58 --> Language Class Initialized
INFO - 2018-04-25 22:54:58 --> Loader Class Initialized
INFO - 2018-04-25 22:54:58 --> Helper loaded: url_helper
INFO - 2018-04-25 22:54:58 --> Helper loaded: form_helper
INFO - 2018-04-25 22:54:58 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:54:58 --> User Agent Class Initialized
INFO - 2018-04-25 22:54:58 --> Controller Class Initialized
INFO - 2018-04-25 22:54:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:54:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:54:58 --> Pixel_Model class loaded
INFO - 2018-04-25 22:54:58 --> Database Driver Class Initialized
INFO - 2018-04-25 22:54:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:54:58 --> Database Driver Class Initialized
INFO - 2018-04-25 22:54:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:54:59 --> Config Class Initialized
INFO - 2018-04-25 22:54:59 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:54:59 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:54:59 --> Utf8 Class Initialized
INFO - 2018-04-25 22:54:59 --> URI Class Initialized
INFO - 2018-04-25 22:54:59 --> Router Class Initialized
INFO - 2018-04-25 22:54:59 --> Output Class Initialized
INFO - 2018-04-25 22:54:59 --> Security Class Initialized
DEBUG - 2018-04-25 22:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:54:59 --> CSRF cookie sent
INFO - 2018-04-25 22:54:59 --> Input Class Initialized
INFO - 2018-04-25 22:54:59 --> Language Class Initialized
INFO - 2018-04-25 22:54:59 --> Loader Class Initialized
INFO - 2018-04-25 22:54:59 --> Helper loaded: url_helper
INFO - 2018-04-25 22:54:59 --> Helper loaded: form_helper
INFO - 2018-04-25 22:54:59 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:54:59 --> User Agent Class Initialized
INFO - 2018-04-25 22:54:59 --> Controller Class Initialized
INFO - 2018-04-25 22:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:54:59 --> Pixel_Model class loaded
INFO - 2018-04-25 22:54:59 --> Database Driver Class Initialized
INFO - 2018-04-25 22:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:54:59 --> Database Driver Class Initialized
INFO - 2018-04-25 22:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:56:10 --> Config Class Initialized
INFO - 2018-04-25 22:56:10 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:56:10 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:56:10 --> Utf8 Class Initialized
INFO - 2018-04-25 22:56:10 --> URI Class Initialized
INFO - 2018-04-25 22:56:10 --> Router Class Initialized
INFO - 2018-04-25 22:56:10 --> Output Class Initialized
INFO - 2018-04-25 22:56:10 --> Security Class Initialized
DEBUG - 2018-04-25 22:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:56:10 --> CSRF cookie sent
INFO - 2018-04-25 22:56:10 --> Input Class Initialized
INFO - 2018-04-25 22:56:10 --> Language Class Initialized
INFO - 2018-04-25 22:56:10 --> Loader Class Initialized
INFO - 2018-04-25 22:56:10 --> Helper loaded: url_helper
INFO - 2018-04-25 22:56:10 --> Helper loaded: form_helper
INFO - 2018-04-25 22:56:10 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:56:10 --> User Agent Class Initialized
INFO - 2018-04-25 22:56:10 --> Controller Class Initialized
INFO - 2018-04-25 22:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:56:10 --> Pixel_Model class loaded
INFO - 2018-04-25 22:56:10 --> Database Driver Class Initialized
INFO - 2018-04-25 22:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:56:10 --> Database Driver Class Initialized
INFO - 2018-04-25 22:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:56:24 --> Config Class Initialized
INFO - 2018-04-25 22:56:24 --> Hooks Class Initialized
DEBUG - 2018-04-25 22:56:24 --> UTF-8 Support Enabled
INFO - 2018-04-25 22:56:24 --> Utf8 Class Initialized
INFO - 2018-04-25 22:56:24 --> URI Class Initialized
INFO - 2018-04-25 22:56:24 --> Router Class Initialized
INFO - 2018-04-25 22:56:24 --> Output Class Initialized
INFO - 2018-04-25 22:56:24 --> Security Class Initialized
DEBUG - 2018-04-25 22:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 22:56:24 --> CSRF cookie sent
INFO - 2018-04-25 22:56:24 --> Input Class Initialized
INFO - 2018-04-25 22:56:24 --> Language Class Initialized
INFO - 2018-04-25 22:56:24 --> Loader Class Initialized
INFO - 2018-04-25 22:56:24 --> Helper loaded: url_helper
INFO - 2018-04-25 22:56:24 --> Helper loaded: form_helper
INFO - 2018-04-25 22:56:24 --> Helper loaded: language_helper
DEBUG - 2018-04-25 22:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 22:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 22:56:24 --> User Agent Class Initialized
INFO - 2018-04-25 22:56:24 --> Controller Class Initialized
INFO - 2018-04-25 22:56:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 22:56:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 22:56:24 --> Pixel_Model class loaded
INFO - 2018-04-25 22:56:24 --> Database Driver Class Initialized
INFO - 2018-04-25 22:56:24 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 22:56:24 --> Database Driver Class Initialized
INFO - 2018-04-25 22:56:24 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:02:41 --> Config Class Initialized
INFO - 2018-04-25 23:02:41 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:02:41 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:02:41 --> Utf8 Class Initialized
INFO - 2018-04-25 23:02:41 --> URI Class Initialized
INFO - 2018-04-25 23:02:41 --> Router Class Initialized
INFO - 2018-04-25 23:02:41 --> Output Class Initialized
INFO - 2018-04-25 23:02:41 --> Security Class Initialized
DEBUG - 2018-04-25 23:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:02:41 --> CSRF cookie sent
INFO - 2018-04-25 23:02:41 --> Input Class Initialized
INFO - 2018-04-25 23:02:41 --> Language Class Initialized
INFO - 2018-04-25 23:02:41 --> Loader Class Initialized
INFO - 2018-04-25 23:02:41 --> Helper loaded: url_helper
INFO - 2018-04-25 23:02:41 --> Helper loaded: form_helper
INFO - 2018-04-25 23:02:41 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:02:41 --> User Agent Class Initialized
INFO - 2018-04-25 23:02:41 --> Controller Class Initialized
INFO - 2018-04-25 23:02:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:02:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:02:41 --> Pixel_Model class loaded
INFO - 2018-04-25 23:02:41 --> Database Driver Class Initialized
INFO - 2018-04-25 23:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:02:41 --> Database Driver Class Initialized
INFO - 2018-04-25 23:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:30:42 --> Config Class Initialized
INFO - 2018-04-25 23:30:42 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:30:42 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:30:42 --> Utf8 Class Initialized
INFO - 2018-04-25 23:30:42 --> URI Class Initialized
INFO - 2018-04-25 23:30:42 --> Router Class Initialized
INFO - 2018-04-25 23:30:42 --> Output Class Initialized
INFO - 2018-04-25 23:30:42 --> Security Class Initialized
DEBUG - 2018-04-25 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:30:42 --> CSRF cookie sent
INFO - 2018-04-25 23:30:42 --> Input Class Initialized
INFO - 2018-04-25 23:30:42 --> Language Class Initialized
INFO - 2018-04-25 23:30:42 --> Loader Class Initialized
INFO - 2018-04-25 23:30:42 --> Helper loaded: url_helper
INFO - 2018-04-25 23:30:42 --> Helper loaded: form_helper
INFO - 2018-04-25 23:30:42 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:30:42 --> User Agent Class Initialized
INFO - 2018-04-25 23:30:42 --> Controller Class Initialized
INFO - 2018-04-25 23:30:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:30:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:30:42 --> Pixel_Model class loaded
INFO - 2018-04-25 23:30:42 --> Database Driver Class Initialized
INFO - 2018-04-25 23:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:30:42 --> Database Driver Class Initialized
INFO - 2018-04-25 23:30:42 --> Model "QuestionsModel" initialized
ERROR - 2018-04-25 23:30:42 --> Severity: Notice --> Undefined variable: next E:\www\yacopoo\application\libraries\Smart.php 523
ERROR - 2018-04-25 23:30:42 --> Severity: Notice --> Undefined variable: previous E:\www\yacopoo\application\libraries\Smart.php 523
INFO - 2018-04-25 23:32:25 --> Config Class Initialized
INFO - 2018-04-25 23:32:25 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:32:25 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:32:25 --> Utf8 Class Initialized
INFO - 2018-04-25 23:32:25 --> URI Class Initialized
INFO - 2018-04-25 23:32:25 --> Router Class Initialized
INFO - 2018-04-25 23:32:25 --> Output Class Initialized
INFO - 2018-04-25 23:32:25 --> Security Class Initialized
DEBUG - 2018-04-25 23:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:32:25 --> CSRF cookie sent
INFO - 2018-04-25 23:32:25 --> Input Class Initialized
INFO - 2018-04-25 23:32:25 --> Language Class Initialized
INFO - 2018-04-25 23:32:25 --> Loader Class Initialized
INFO - 2018-04-25 23:32:25 --> Helper loaded: url_helper
INFO - 2018-04-25 23:32:25 --> Helper loaded: form_helper
INFO - 2018-04-25 23:32:25 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:32:25 --> User Agent Class Initialized
INFO - 2018-04-25 23:32:25 --> Controller Class Initialized
INFO - 2018-04-25 23:32:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:32:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:32:25 --> Pixel_Model class loaded
INFO - 2018-04-25 23:32:25 --> Database Driver Class Initialized
INFO - 2018-04-25 23:32:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:32:25 --> Database Driver Class Initialized
INFO - 2018-04-25 23:32:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:33:19 --> Config Class Initialized
INFO - 2018-04-25 23:33:19 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:33:19 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:33:19 --> Utf8 Class Initialized
INFO - 2018-04-25 23:33:19 --> URI Class Initialized
INFO - 2018-04-25 23:33:19 --> Router Class Initialized
INFO - 2018-04-25 23:33:19 --> Output Class Initialized
INFO - 2018-04-25 23:33:19 --> Security Class Initialized
DEBUG - 2018-04-25 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:33:19 --> CSRF cookie sent
INFO - 2018-04-25 23:33:19 --> Input Class Initialized
INFO - 2018-04-25 23:33:19 --> Language Class Initialized
INFO - 2018-04-25 23:33:19 --> Loader Class Initialized
INFO - 2018-04-25 23:33:19 --> Helper loaded: url_helper
INFO - 2018-04-25 23:33:19 --> Helper loaded: form_helper
INFO - 2018-04-25 23:33:19 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:33:19 --> User Agent Class Initialized
INFO - 2018-04-25 23:33:19 --> Controller Class Initialized
INFO - 2018-04-25 23:33:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:33:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:33:19 --> Pixel_Model class loaded
INFO - 2018-04-25 23:33:19 --> Database Driver Class Initialized
INFO - 2018-04-25 23:33:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:33:19 --> Database Driver Class Initialized
INFO - 2018-04-25 23:33:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:33:34 --> Config Class Initialized
INFO - 2018-04-25 23:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:33:34 --> Utf8 Class Initialized
INFO - 2018-04-25 23:33:34 --> URI Class Initialized
INFO - 2018-04-25 23:33:34 --> Router Class Initialized
INFO - 2018-04-25 23:33:34 --> Output Class Initialized
INFO - 2018-04-25 23:33:34 --> Security Class Initialized
DEBUG - 2018-04-25 23:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:33:34 --> CSRF cookie sent
INFO - 2018-04-25 23:33:34 --> Input Class Initialized
INFO - 2018-04-25 23:33:34 --> Language Class Initialized
INFO - 2018-04-25 23:33:34 --> Loader Class Initialized
INFO - 2018-04-25 23:33:34 --> Helper loaded: url_helper
INFO - 2018-04-25 23:33:34 --> Helper loaded: form_helper
INFO - 2018-04-25 23:33:34 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:33:34 --> User Agent Class Initialized
INFO - 2018-04-25 23:33:34 --> Controller Class Initialized
INFO - 2018-04-25 23:33:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:33:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:33:34 --> Pixel_Model class loaded
INFO - 2018-04-25 23:33:34 --> Database Driver Class Initialized
INFO - 2018-04-25 23:33:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:33:34 --> Database Driver Class Initialized
INFO - 2018-04-25 23:33:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:34:06 --> Config Class Initialized
INFO - 2018-04-25 23:34:06 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:34:06 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:34:06 --> Utf8 Class Initialized
INFO - 2018-04-25 23:34:06 --> URI Class Initialized
INFO - 2018-04-25 23:34:06 --> Router Class Initialized
INFO - 2018-04-25 23:34:06 --> Output Class Initialized
INFO - 2018-04-25 23:34:06 --> Security Class Initialized
DEBUG - 2018-04-25 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:34:06 --> CSRF cookie sent
INFO - 2018-04-25 23:34:06 --> Input Class Initialized
INFO - 2018-04-25 23:34:06 --> Language Class Initialized
INFO - 2018-04-25 23:34:06 --> Loader Class Initialized
INFO - 2018-04-25 23:34:06 --> Helper loaded: url_helper
INFO - 2018-04-25 23:34:06 --> Helper loaded: form_helper
INFO - 2018-04-25 23:34:06 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:34:06 --> User Agent Class Initialized
INFO - 2018-04-25 23:34:06 --> Controller Class Initialized
INFO - 2018-04-25 23:34:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:34:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:34:06 --> Pixel_Model class loaded
INFO - 2018-04-25 23:34:06 --> Database Driver Class Initialized
INFO - 2018-04-25 23:34:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:34:06 --> Database Driver Class Initialized
INFO - 2018-04-25 23:34:06 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:38:54 --> Config Class Initialized
INFO - 2018-04-25 23:38:54 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:38:54 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:38:54 --> Utf8 Class Initialized
INFO - 2018-04-25 23:38:54 --> URI Class Initialized
INFO - 2018-04-25 23:38:54 --> Router Class Initialized
INFO - 2018-04-25 23:38:54 --> Output Class Initialized
INFO - 2018-04-25 23:38:54 --> Security Class Initialized
DEBUG - 2018-04-25 23:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:38:54 --> CSRF cookie sent
INFO - 2018-04-25 23:38:54 --> Input Class Initialized
INFO - 2018-04-25 23:38:54 --> Language Class Initialized
INFO - 2018-04-25 23:38:54 --> Loader Class Initialized
INFO - 2018-04-25 23:38:54 --> Helper loaded: url_helper
INFO - 2018-04-25 23:38:54 --> Helper loaded: form_helper
INFO - 2018-04-25 23:38:54 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:38:54 --> User Agent Class Initialized
INFO - 2018-04-25 23:38:54 --> Controller Class Initialized
INFO - 2018-04-25 23:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:38:55 --> Pixel_Model class loaded
INFO - 2018-04-25 23:38:55 --> Database Driver Class Initialized
INFO - 2018-04-25 23:38:55 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:38:55 --> Database Driver Class Initialized
INFO - 2018-04-25 23:38:55 --> Model "QuestionsModel" initialized
ERROR - 2018-04-25 23:38:55 --> Severity: Notice --> Undefined variable: previous E:\www\yacopoo\application\libraries\Smart.php 526
INFO - 2018-04-25 23:40:19 --> Config Class Initialized
INFO - 2018-04-25 23:40:19 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:40:19 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:40:19 --> Utf8 Class Initialized
INFO - 2018-04-25 23:40:19 --> URI Class Initialized
INFO - 2018-04-25 23:40:19 --> Router Class Initialized
INFO - 2018-04-25 23:40:19 --> Output Class Initialized
INFO - 2018-04-25 23:40:19 --> Security Class Initialized
DEBUG - 2018-04-25 23:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:40:19 --> CSRF cookie sent
INFO - 2018-04-25 23:40:19 --> Input Class Initialized
INFO - 2018-04-25 23:40:19 --> Language Class Initialized
INFO - 2018-04-25 23:40:19 --> Loader Class Initialized
INFO - 2018-04-25 23:40:19 --> Helper loaded: url_helper
INFO - 2018-04-25 23:40:19 --> Helper loaded: form_helper
INFO - 2018-04-25 23:40:19 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:40:19 --> User Agent Class Initialized
INFO - 2018-04-25 23:40:19 --> Controller Class Initialized
INFO - 2018-04-25 23:40:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:40:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:40:19 --> Pixel_Model class loaded
INFO - 2018-04-25 23:40:19 --> Database Driver Class Initialized
INFO - 2018-04-25 23:40:19 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:40:19 --> Database Driver Class Initialized
INFO - 2018-04-25 23:40:19 --> Model "QuestionsModel" initialized
ERROR - 2018-04-25 23:40:19 --> Severity: Notice --> Undefined variable: previous E:\www\yacopoo\application\libraries\Smart.php 526
INFO - 2018-04-25 23:40:37 --> Config Class Initialized
INFO - 2018-04-25 23:40:37 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:40:37 --> Utf8 Class Initialized
INFO - 2018-04-25 23:40:37 --> URI Class Initialized
INFO - 2018-04-25 23:40:37 --> Router Class Initialized
INFO - 2018-04-25 23:40:37 --> Output Class Initialized
INFO - 2018-04-25 23:40:37 --> Security Class Initialized
DEBUG - 2018-04-25 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:40:37 --> CSRF cookie sent
INFO - 2018-04-25 23:40:37 --> Input Class Initialized
INFO - 2018-04-25 23:40:37 --> Language Class Initialized
INFO - 2018-04-25 23:40:37 --> Loader Class Initialized
INFO - 2018-04-25 23:40:37 --> Helper loaded: url_helper
INFO - 2018-04-25 23:40:37 --> Helper loaded: form_helper
INFO - 2018-04-25 23:40:37 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:40:37 --> User Agent Class Initialized
INFO - 2018-04-25 23:40:37 --> Controller Class Initialized
INFO - 2018-04-25 23:40:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:40:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:40:37 --> Pixel_Model class loaded
INFO - 2018-04-25 23:40:37 --> Database Driver Class Initialized
INFO - 2018-04-25 23:40:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:40:37 --> Database Driver Class Initialized
INFO - 2018-04-25 23:40:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:41:00 --> Config Class Initialized
INFO - 2018-04-25 23:41:00 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:41:00 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:41:00 --> Utf8 Class Initialized
INFO - 2018-04-25 23:41:00 --> URI Class Initialized
INFO - 2018-04-25 23:41:00 --> Router Class Initialized
INFO - 2018-04-25 23:41:00 --> Output Class Initialized
INFO - 2018-04-25 23:41:00 --> Security Class Initialized
DEBUG - 2018-04-25 23:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:41:00 --> CSRF cookie sent
INFO - 2018-04-25 23:41:00 --> Input Class Initialized
INFO - 2018-04-25 23:41:00 --> Language Class Initialized
INFO - 2018-04-25 23:41:00 --> Loader Class Initialized
INFO - 2018-04-25 23:41:00 --> Helper loaded: url_helper
INFO - 2018-04-25 23:41:00 --> Helper loaded: form_helper
INFO - 2018-04-25 23:41:00 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:41:00 --> User Agent Class Initialized
INFO - 2018-04-25 23:41:00 --> Controller Class Initialized
INFO - 2018-04-25 23:41:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:41:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:41:00 --> Pixel_Model class loaded
INFO - 2018-04-25 23:41:00 --> Database Driver Class Initialized
INFO - 2018-04-25 23:41:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:41:00 --> Database Driver Class Initialized
INFO - 2018-04-25 23:41:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:42:50 --> Config Class Initialized
INFO - 2018-04-25 23:42:50 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:42:50 --> Utf8 Class Initialized
INFO - 2018-04-25 23:42:50 --> URI Class Initialized
INFO - 2018-04-25 23:42:50 --> Router Class Initialized
INFO - 2018-04-25 23:42:50 --> Output Class Initialized
INFO - 2018-04-25 23:42:50 --> Security Class Initialized
DEBUG - 2018-04-25 23:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:42:50 --> CSRF cookie sent
INFO - 2018-04-25 23:42:50 --> Input Class Initialized
INFO - 2018-04-25 23:42:50 --> Language Class Initialized
INFO - 2018-04-25 23:42:50 --> Loader Class Initialized
INFO - 2018-04-25 23:42:50 --> Helper loaded: url_helper
INFO - 2018-04-25 23:42:50 --> Helper loaded: form_helper
INFO - 2018-04-25 23:42:50 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:42:50 --> User Agent Class Initialized
INFO - 2018-04-25 23:42:50 --> Controller Class Initialized
INFO - 2018-04-25 23:42:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:42:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:42:50 --> Pixel_Model class loaded
INFO - 2018-04-25 23:42:50 --> Database Driver Class Initialized
INFO - 2018-04-25 23:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:42:50 --> Database Driver Class Initialized
INFO - 2018-04-25 23:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:58:38 --> Config Class Initialized
INFO - 2018-04-25 23:58:38 --> Hooks Class Initialized
DEBUG - 2018-04-25 23:58:38 --> UTF-8 Support Enabled
INFO - 2018-04-25 23:58:38 --> Utf8 Class Initialized
INFO - 2018-04-25 23:58:38 --> URI Class Initialized
INFO - 2018-04-25 23:58:38 --> Router Class Initialized
INFO - 2018-04-25 23:58:38 --> Output Class Initialized
INFO - 2018-04-25 23:58:38 --> Security Class Initialized
DEBUG - 2018-04-25 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-25 23:58:38 --> CSRF cookie sent
INFO - 2018-04-25 23:58:38 --> Input Class Initialized
INFO - 2018-04-25 23:58:38 --> Language Class Initialized
INFO - 2018-04-25 23:58:38 --> Loader Class Initialized
INFO - 2018-04-25 23:58:38 --> Helper loaded: url_helper
INFO - 2018-04-25 23:58:38 --> Helper loaded: form_helper
INFO - 2018-04-25 23:58:38 --> Helper loaded: language_helper
DEBUG - 2018-04-25 23:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-25 23:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-25 23:58:38 --> User Agent Class Initialized
INFO - 2018-04-25 23:58:38 --> Controller Class Initialized
INFO - 2018-04-25 23:58:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-25 23:58:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-25 23:58:38 --> Pixel_Model class loaded
INFO - 2018-04-25 23:58:38 --> Database Driver Class Initialized
INFO - 2018-04-25 23:58:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-25 23:58:38 --> Database Driver Class Initialized
INFO - 2018-04-25 23:58:38 --> Model "QuestionsModel" initialized

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-29 17:19:14 --> Config Class Initialized
INFO - 2018-04-29 17:19:14 --> Hooks Class Initialized
DEBUG - 2018-04-29 17:19:14 --> UTF-8 Support Enabled
INFO - 2018-04-29 17:19:14 --> Utf8 Class Initialized
INFO - 2018-04-29 17:19:14 --> URI Class Initialized
INFO - 2018-04-29 17:19:14 --> Router Class Initialized
INFO - 2018-04-29 17:19:14 --> Output Class Initialized
INFO - 2018-04-29 17:19:14 --> Security Class Initialized
DEBUG - 2018-04-29 17:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-29 17:19:14 --> CSRF cookie sent
INFO - 2018-04-29 17:19:14 --> Input Class Initialized
INFO - 2018-04-29 17:19:14 --> Language Class Initialized
INFO - 2018-04-29 17:19:14 --> Loader Class Initialized
INFO - 2018-04-29 17:19:15 --> Helper loaded: url_helper
INFO - 2018-04-29 17:19:15 --> Helper loaded: form_helper
INFO - 2018-04-29 17:19:15 --> Helper loaded: language_helper
DEBUG - 2018-04-29 17:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-29 17:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-29 17:19:15 --> User Agent Class Initialized
INFO - 2018-04-29 17:19:15 --> Controller Class Initialized
INFO - 2018-04-29 17:19:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-29 17:19:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-29 17:19:15 --> Pixel_Model class loaded
INFO - 2018-04-29 17:19:15 --> Database Driver Class Initialized
INFO - 2018-04-29 17:19:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-29 17:19:15 --> Config Class Initialized
INFO - 2018-04-29 17:19:15 --> Hooks Class Initialized
DEBUG - 2018-04-29 17:19:15 --> UTF-8 Support Enabled
INFO - 2018-04-29 17:19:15 --> Utf8 Class Initialized
INFO - 2018-04-29 17:19:15 --> URI Class Initialized
DEBUG - 2018-04-29 17:19:15 --> No URI present. Default controller set.
INFO - 2018-04-29 17:19:15 --> Router Class Initialized
INFO - 2018-04-29 17:19:15 --> Output Class Initialized
INFO - 2018-04-29 17:19:15 --> Security Class Initialized
DEBUG - 2018-04-29 17:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-29 17:19:15 --> CSRF cookie sent
INFO - 2018-04-29 17:19:15 --> Input Class Initialized
INFO - 2018-04-29 17:19:15 --> Language Class Initialized
INFO - 2018-04-29 17:19:15 --> Loader Class Initialized
INFO - 2018-04-29 17:19:15 --> Helper loaded: url_helper
INFO - 2018-04-29 17:19:15 --> Helper loaded: form_helper
INFO - 2018-04-29 17:19:15 --> Helper loaded: language_helper
DEBUG - 2018-04-29 17:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-29 17:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-29 17:19:15 --> User Agent Class Initialized
INFO - 2018-04-29 17:19:15 --> Controller Class Initialized
INFO - 2018-04-29 17:19:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-29 17:19:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-29 17:19:15 --> Pixel_Model class loaded
INFO - 2018-04-29 17:19:15 --> Database Driver Class Initialized
INFO - 2018-04-29 17:19:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-29 17:19:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-29 17:19:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-29 17:19:15 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-29 17:19:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-29 17:19:16 --> Final output sent to browser
DEBUG - 2018-04-29 17:19:16 --> Total execution time: 0.5619
INFO - 2018-04-29 17:20:45 --> Config Class Initialized
INFO - 2018-04-29 17:20:45 --> Hooks Class Initialized
DEBUG - 2018-04-29 17:20:45 --> UTF-8 Support Enabled
INFO - 2018-04-29 17:20:45 --> Utf8 Class Initialized
INFO - 2018-04-29 17:20:45 --> URI Class Initialized
INFO - 2018-04-29 17:20:45 --> Router Class Initialized
INFO - 2018-04-29 17:20:45 --> Output Class Initialized
INFO - 2018-04-29 17:20:45 --> Security Class Initialized
DEBUG - 2018-04-29 17:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-29 17:20:45 --> CSRF cookie sent
INFO - 2018-04-29 17:20:45 --> Input Class Initialized
INFO - 2018-04-29 17:20:45 --> Language Class Initialized
ERROR - 2018-04-29 17:20:45 --> 404 Page Not Found: Revolution/assets

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-20 00:04:10 --> Config Class Initialized
INFO - 2018-06-20 00:04:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:04:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:04:10 --> Utf8 Class Initialized
INFO - 2018-06-20 00:04:10 --> URI Class Initialized
DEBUG - 2018-06-20 00:04:10 --> No URI present. Default controller set.
INFO - 2018-06-20 00:04:10 --> Router Class Initialized
INFO - 2018-06-20 00:04:10 --> Output Class Initialized
INFO - 2018-06-20 00:04:10 --> Security Class Initialized
DEBUG - 2018-06-20 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:04:10 --> CSRF cookie sent
INFO - 2018-06-20 00:04:10 --> Input Class Initialized
INFO - 2018-06-20 00:04:10 --> Language Class Initialized
INFO - 2018-06-20 00:04:10 --> Loader Class Initialized
INFO - 2018-06-20 00:04:10 --> Helper loaded: url_helper
INFO - 2018-06-20 00:04:10 --> Helper loaded: form_helper
INFO - 2018-06-20 00:04:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:04:10 --> User Agent Class Initialized
INFO - 2018-06-20 00:04:10 --> Controller Class Initialized
INFO - 2018-06-20 00:04:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:04:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:04:10 --> Pixel_Model class loaded
INFO - 2018-06-20 00:04:10 --> Database Driver Class Initialized
INFO - 2018-06-20 00:04:10 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 00:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 00:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:04:10 --> Final output sent to browser
DEBUG - 2018-06-20 00:04:10 --> Total execution time: 0.0641
INFO - 2018-06-20 00:04:23 --> Config Class Initialized
INFO - 2018-06-20 00:04:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:04:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:04:23 --> Utf8 Class Initialized
INFO - 2018-06-20 00:04:23 --> URI Class Initialized
INFO - 2018-06-20 00:04:23 --> Router Class Initialized
INFO - 2018-06-20 00:04:23 --> Output Class Initialized
INFO - 2018-06-20 00:04:23 --> Security Class Initialized
DEBUG - 2018-06-20 00:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:04:23 --> CSRF cookie sent
INFO - 2018-06-20 00:04:23 --> Input Class Initialized
INFO - 2018-06-20 00:04:23 --> Language Class Initialized
INFO - 2018-06-20 00:04:23 --> Loader Class Initialized
INFO - 2018-06-20 00:04:23 --> Helper loaded: url_helper
INFO - 2018-06-20 00:04:23 --> Helper loaded: form_helper
INFO - 2018-06-20 00:04:23 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:04:23 --> User Agent Class Initialized
INFO - 2018-06-20 00:04:23 --> Controller Class Initialized
INFO - 2018-06-20 00:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 00:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:04:23 --> Final output sent to browser
DEBUG - 2018-06-20 00:04:23 --> Total execution time: 0.0336
INFO - 2018-06-20 00:09:38 --> Config Class Initialized
INFO - 2018-06-20 00:09:38 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:09:38 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:09:38 --> Utf8 Class Initialized
INFO - 2018-06-20 00:09:38 --> URI Class Initialized
DEBUG - 2018-06-20 00:09:38 --> No URI present. Default controller set.
INFO - 2018-06-20 00:09:38 --> Router Class Initialized
INFO - 2018-06-20 00:09:38 --> Output Class Initialized
INFO - 2018-06-20 00:09:38 --> Security Class Initialized
DEBUG - 2018-06-20 00:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:09:38 --> CSRF cookie sent
INFO - 2018-06-20 00:09:38 --> Input Class Initialized
INFO - 2018-06-20 00:09:38 --> Language Class Initialized
INFO - 2018-06-20 00:09:38 --> Loader Class Initialized
INFO - 2018-06-20 00:09:38 --> Helper loaded: url_helper
INFO - 2018-06-20 00:09:38 --> Helper loaded: form_helper
INFO - 2018-06-20 00:09:38 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:09:38 --> User Agent Class Initialized
INFO - 2018-06-20 00:09:38 --> Controller Class Initialized
INFO - 2018-06-20 00:09:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:09:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:09:38 --> Pixel_Model class loaded
INFO - 2018-06-20 00:09:38 --> Database Driver Class Initialized
INFO - 2018-06-20 00:09:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 00:09:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:09:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:09:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 00:09:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:09:38 --> Final output sent to browser
DEBUG - 2018-06-20 00:09:38 --> Total execution time: 0.1114
INFO - 2018-06-20 00:51:31 --> Config Class Initialized
INFO - 2018-06-20 00:51:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:51:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:51:31 --> Utf8 Class Initialized
INFO - 2018-06-20 00:51:31 --> URI Class Initialized
INFO - 2018-06-20 00:51:31 --> Router Class Initialized
INFO - 2018-06-20 00:51:31 --> Output Class Initialized
INFO - 2018-06-20 00:51:31 --> Security Class Initialized
DEBUG - 2018-06-20 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:51:31 --> CSRF cookie sent
INFO - 2018-06-20 00:51:31 --> Input Class Initialized
INFO - 2018-06-20 00:51:31 --> Language Class Initialized
INFO - 2018-06-20 00:51:31 --> Loader Class Initialized
INFO - 2018-06-20 00:51:31 --> Helper loaded: url_helper
INFO - 2018-06-20 00:51:31 --> Helper loaded: form_helper
INFO - 2018-06-20 00:51:31 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:51:31 --> User Agent Class Initialized
INFO - 2018-06-20 00:51:31 --> Controller Class Initialized
INFO - 2018-06-20 00:51:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:51:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 00:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:51:31 --> Final output sent to browser
DEBUG - 2018-06-20 00:51:31 --> Total execution time: 0.0503
INFO - 2018-06-20 00:51:37 --> Config Class Initialized
INFO - 2018-06-20 00:51:37 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:51:37 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:51:37 --> Utf8 Class Initialized
INFO - 2018-06-20 00:51:37 --> URI Class Initialized
INFO - 2018-06-20 00:51:37 --> Router Class Initialized
INFO - 2018-06-20 00:51:37 --> Output Class Initialized
INFO - 2018-06-20 00:51:37 --> Security Class Initialized
DEBUG - 2018-06-20 00:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:51:37 --> CSRF cookie sent
INFO - 2018-06-20 00:51:37 --> Input Class Initialized
INFO - 2018-06-20 00:51:37 --> Language Class Initialized
INFO - 2018-06-20 00:51:37 --> Loader Class Initialized
INFO - 2018-06-20 00:51:38 --> Helper loaded: url_helper
INFO - 2018-06-20 00:51:38 --> Helper loaded: form_helper
INFO - 2018-06-20 00:51:38 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:51:38 --> User Agent Class Initialized
INFO - 2018-06-20 00:51:38 --> Controller Class Initialized
INFO - 2018-06-20 00:51:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:51:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-20 00:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:51:38 --> Final output sent to browser
DEBUG - 2018-06-20 00:51:38 --> Total execution time: 0.0492
INFO - 2018-06-20 00:51:44 --> Config Class Initialized
INFO - 2018-06-20 00:51:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:51:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:51:44 --> Utf8 Class Initialized
INFO - 2018-06-20 00:51:44 --> URI Class Initialized
INFO - 2018-06-20 00:51:44 --> Router Class Initialized
INFO - 2018-06-20 00:51:44 --> Output Class Initialized
INFO - 2018-06-20 00:51:44 --> Security Class Initialized
DEBUG - 2018-06-20 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:51:44 --> CSRF cookie sent
INFO - 2018-06-20 00:51:44 --> Input Class Initialized
INFO - 2018-06-20 00:51:44 --> Language Class Initialized
INFO - 2018-06-20 00:51:44 --> Loader Class Initialized
INFO - 2018-06-20 00:51:44 --> Helper loaded: url_helper
INFO - 2018-06-20 00:51:44 --> Helper loaded: form_helper
INFO - 2018-06-20 00:51:44 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:51:44 --> User Agent Class Initialized
INFO - 2018-06-20 00:51:44 --> Controller Class Initialized
INFO - 2018-06-20 00:51:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:51:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 00:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:51:44 --> Final output sent to browser
DEBUG - 2018-06-20 00:51:44 --> Total execution time: 0.0407
INFO - 2018-06-20 00:51:51 --> Config Class Initialized
INFO - 2018-06-20 00:51:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 00:51:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 00:51:51 --> Utf8 Class Initialized
INFO - 2018-06-20 00:51:51 --> URI Class Initialized
INFO - 2018-06-20 00:51:51 --> Router Class Initialized
INFO - 2018-06-20 00:51:51 --> Output Class Initialized
INFO - 2018-06-20 00:51:51 --> Security Class Initialized
DEBUG - 2018-06-20 00:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 00:51:51 --> CSRF cookie sent
INFO - 2018-06-20 00:51:51 --> Input Class Initialized
INFO - 2018-06-20 00:51:51 --> Language Class Initialized
INFO - 2018-06-20 00:51:51 --> Loader Class Initialized
INFO - 2018-06-20 00:51:51 --> Helper loaded: url_helper
INFO - 2018-06-20 00:51:51 --> Helper loaded: form_helper
INFO - 2018-06-20 00:51:51 --> Helper loaded: language_helper
DEBUG - 2018-06-20 00:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 00:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 00:51:51 --> User Agent Class Initialized
INFO - 2018-06-20 00:51:51 --> Controller Class Initialized
INFO - 2018-06-20 00:51:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 00:51:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 00:51:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 00:51:51 --> Final output sent to browser
DEBUG - 2018-06-20 00:51:51 --> Total execution time: 0.0559
INFO - 2018-06-20 01:27:01 --> Config Class Initialized
INFO - 2018-06-20 01:27:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:27:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:27:01 --> Utf8 Class Initialized
INFO - 2018-06-20 01:27:01 --> URI Class Initialized
DEBUG - 2018-06-20 01:27:01 --> No URI present. Default controller set.
INFO - 2018-06-20 01:27:01 --> Router Class Initialized
INFO - 2018-06-20 01:27:01 --> Output Class Initialized
INFO - 2018-06-20 01:27:01 --> Security Class Initialized
DEBUG - 2018-06-20 01:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:27:01 --> CSRF cookie sent
INFO - 2018-06-20 01:27:01 --> Input Class Initialized
INFO - 2018-06-20 01:27:01 --> Language Class Initialized
INFO - 2018-06-20 01:27:01 --> Loader Class Initialized
INFO - 2018-06-20 01:27:01 --> Helper loaded: url_helper
INFO - 2018-06-20 01:27:01 --> Helper loaded: form_helper
INFO - 2018-06-20 01:27:01 --> Helper loaded: language_helper
DEBUG - 2018-06-20 01:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:27:01 --> User Agent Class Initialized
INFO - 2018-06-20 01:27:01 --> Controller Class Initialized
INFO - 2018-06-20 01:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 01:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 01:27:01 --> Pixel_Model class loaded
INFO - 2018-06-20 01:27:02 --> Database Driver Class Initialized
INFO - 2018-06-20 01:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 01:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 01:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 01:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 01:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 01:27:02 --> Final output sent to browser
DEBUG - 2018-06-20 01:27:02 --> Total execution time: 0.0921
INFO - 2018-06-20 01:28:16 --> Config Class Initialized
INFO - 2018-06-20 01:28:16 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:16 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:16 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:16 --> URI Class Initialized
DEBUG - 2018-06-20 01:28:16 --> No URI present. Default controller set.
INFO - 2018-06-20 01:28:16 --> Router Class Initialized
INFO - 2018-06-20 01:28:16 --> Output Class Initialized
INFO - 2018-06-20 01:28:16 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:16 --> CSRF cookie sent
INFO - 2018-06-20 01:28:16 --> Input Class Initialized
INFO - 2018-06-20 01:28:16 --> Language Class Initialized
INFO - 2018-06-20 01:28:16 --> Loader Class Initialized
INFO - 2018-06-20 01:28:16 --> Helper loaded: url_helper
INFO - 2018-06-20 01:28:16 --> Helper loaded: form_helper
INFO - 2018-06-20 01:28:16 --> Helper loaded: language_helper
DEBUG - 2018-06-20 01:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:28:16 --> User Agent Class Initialized
INFO - 2018-06-20 01:28:16 --> Controller Class Initialized
INFO - 2018-06-20 01:28:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 01:28:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 01:28:16 --> Pixel_Model class loaded
INFO - 2018-06-20 01:28:16 --> Database Driver Class Initialized
INFO - 2018-06-20 01:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 01:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 01:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 01:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 01:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 01:28:16 --> Final output sent to browser
DEBUG - 2018-06-20 01:28:16 --> Total execution time: 0.0862
INFO - 2018-06-20 01:28:28 --> Config Class Initialized
INFO - 2018-06-20 01:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:28 --> URI Class Initialized
DEBUG - 2018-06-20 01:28:28 --> No URI present. Default controller set.
INFO - 2018-06-20 01:28:28 --> Router Class Initialized
INFO - 2018-06-20 01:28:28 --> Output Class Initialized
INFO - 2018-06-20 01:28:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:28 --> CSRF cookie sent
INFO - 2018-06-20 01:28:28 --> Input Class Initialized
INFO - 2018-06-20 01:28:28 --> Language Class Initialized
INFO - 2018-06-20 01:28:28 --> Loader Class Initialized
INFO - 2018-06-20 01:28:28 --> Helper loaded: url_helper
INFO - 2018-06-20 01:28:28 --> Helper loaded: form_helper
INFO - 2018-06-20 01:28:28 --> Helper loaded: language_helper
DEBUG - 2018-06-20 01:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:28:28 --> User Agent Class Initialized
INFO - 2018-06-20 01:28:28 --> Controller Class Initialized
INFO - 2018-06-20 01:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 01:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 01:28:28 --> Pixel_Model class loaded
INFO - 2018-06-20 01:28:28 --> Database Driver Class Initialized
INFO - 2018-06-20 01:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 01:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 01:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 01:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 01:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 01:28:28 --> Final output sent to browser
DEBUG - 2018-06-20 01:28:28 --> Total execution time: 0.0831
INFO - 2018-06-20 01:28:28 --> Config Class Initialized
INFO - 2018-06-20 01:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:28 --> URI Class Initialized
INFO - 2018-06-20 01:28:28 --> Router Class Initialized
INFO - 2018-06-20 01:28:28 --> Output Class Initialized
INFO - 2018-06-20 01:28:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:28 --> CSRF cookie sent
INFO - 2018-06-20 01:28:28 --> Input Class Initialized
INFO - 2018-06-20 01:28:28 --> Language Class Initialized
ERROR - 2018-06-20 01:28:28 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-06-20 01:28:28 --> Config Class Initialized
INFO - 2018-06-20 01:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:28 --> URI Class Initialized
INFO - 2018-06-20 01:28:28 --> Router Class Initialized
INFO - 2018-06-20 01:28:28 --> Output Class Initialized
INFO - 2018-06-20 01:28:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:28 --> CSRF cookie sent
INFO - 2018-06-20 01:28:28 --> Input Class Initialized
INFO - 2018-06-20 01:28:28 --> Language Class Initialized
ERROR - 2018-06-20 01:28:28 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-06-20 01:28:28 --> Config Class Initialized
INFO - 2018-06-20 01:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:28 --> URI Class Initialized
INFO - 2018-06-20 01:28:28 --> Router Class Initialized
INFO - 2018-06-20 01:28:28 --> Output Class Initialized
INFO - 2018-06-20 01:28:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:28 --> CSRF cookie sent
INFO - 2018-06-20 01:28:28 --> Input Class Initialized
INFO - 2018-06-20 01:28:28 --> Language Class Initialized
ERROR - 2018-06-20 01:28:28 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-06-20 01:28:28 --> Config Class Initialized
INFO - 2018-06-20 01:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:28:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:28:28 --> URI Class Initialized
INFO - 2018-06-20 01:28:28 --> Router Class Initialized
INFO - 2018-06-20 01:28:28 --> Output Class Initialized
INFO - 2018-06-20 01:28:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:28:28 --> CSRF cookie sent
INFO - 2018-06-20 01:28:28 --> Input Class Initialized
INFO - 2018-06-20 01:28:28 --> Language Class Initialized
ERROR - 2018-06-20 01:28:28 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-06-20 01:49:01 --> Config Class Initialized
INFO - 2018-06-20 01:49:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:49:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:49:01 --> Utf8 Class Initialized
INFO - 2018-06-20 01:49:01 --> URI Class Initialized
DEBUG - 2018-06-20 01:49:01 --> No URI present. Default controller set.
INFO - 2018-06-20 01:49:01 --> Router Class Initialized
INFO - 2018-06-20 01:49:01 --> Output Class Initialized
INFO - 2018-06-20 01:49:01 --> Security Class Initialized
DEBUG - 2018-06-20 01:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:49:01 --> CSRF cookie sent
INFO - 2018-06-20 01:49:01 --> Input Class Initialized
INFO - 2018-06-20 01:49:01 --> Language Class Initialized
INFO - 2018-06-20 01:49:01 --> Loader Class Initialized
INFO - 2018-06-20 01:49:01 --> Helper loaded: url_helper
INFO - 2018-06-20 01:49:01 --> Helper loaded: form_helper
INFO - 2018-06-20 01:49:01 --> Helper loaded: language_helper
DEBUG - 2018-06-20 01:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:49:01 --> User Agent Class Initialized
INFO - 2018-06-20 01:49:01 --> Controller Class Initialized
INFO - 2018-06-20 01:49:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 01:49:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 01:49:01 --> Pixel_Model class loaded
INFO - 2018-06-20 01:49:01 --> Database Driver Class Initialized
INFO - 2018-06-20 01:49:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 01:49:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 01:49:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 01:49:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 01:49:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 01:49:01 --> Final output sent to browser
DEBUG - 2018-06-20 01:49:01 --> Total execution time: 0.0752
INFO - 2018-06-20 02:11:21 --> Config Class Initialized
INFO - 2018-06-20 02:11:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:11:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:11:21 --> Utf8 Class Initialized
INFO - 2018-06-20 02:11:21 --> URI Class Initialized
DEBUG - 2018-06-20 02:11:21 --> No URI present. Default controller set.
INFO - 2018-06-20 02:11:21 --> Router Class Initialized
INFO - 2018-06-20 02:11:21 --> Output Class Initialized
INFO - 2018-06-20 02:11:21 --> Security Class Initialized
DEBUG - 2018-06-20 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:11:21 --> CSRF cookie sent
INFO - 2018-06-20 02:11:21 --> Input Class Initialized
INFO - 2018-06-20 02:11:21 --> Language Class Initialized
INFO - 2018-06-20 02:11:21 --> Loader Class Initialized
INFO - 2018-06-20 02:11:21 --> Helper loaded: url_helper
INFO - 2018-06-20 02:11:21 --> Helper loaded: form_helper
INFO - 2018-06-20 02:11:21 --> Helper loaded: language_helper
DEBUG - 2018-06-20 02:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:11:21 --> User Agent Class Initialized
INFO - 2018-06-20 02:11:21 --> Controller Class Initialized
INFO - 2018-06-20 02:11:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 02:11:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 02:11:21 --> Pixel_Model class loaded
INFO - 2018-06-20 02:11:21 --> Database Driver Class Initialized
INFO - 2018-06-20 02:11:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 02:11:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 02:11:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 02:11:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 02:11:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 02:11:21 --> Final output sent to browser
DEBUG - 2018-06-20 02:11:21 --> Total execution time: 0.0659
INFO - 2018-06-20 02:12:49 --> Config Class Initialized
INFO - 2018-06-20 02:12:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:12:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:12:49 --> Utf8 Class Initialized
INFO - 2018-06-20 02:12:49 --> URI Class Initialized
INFO - 2018-06-20 02:12:49 --> Router Class Initialized
INFO - 2018-06-20 02:12:49 --> Output Class Initialized
INFO - 2018-06-20 02:12:49 --> Security Class Initialized
DEBUG - 2018-06-20 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:12:49 --> CSRF cookie sent
INFO - 2018-06-20 02:12:49 --> Input Class Initialized
INFO - 2018-06-20 02:12:49 --> Language Class Initialized
INFO - 2018-06-20 02:12:49 --> Loader Class Initialized
INFO - 2018-06-20 02:12:49 --> Helper loaded: url_helper
INFO - 2018-06-20 02:12:49 --> Helper loaded: form_helper
INFO - 2018-06-20 02:12:49 --> Helper loaded: language_helper
DEBUG - 2018-06-20 02:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:12:49 --> User Agent Class Initialized
INFO - 2018-06-20 02:12:49 --> Controller Class Initialized
INFO - 2018-06-20 02:12:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 02:12:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 02:12:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 02:12:49 --> Final output sent to browser
DEBUG - 2018-06-20 02:12:49 --> Total execution time: 0.0332
INFO - 2018-06-20 02:13:23 --> Config Class Initialized
INFO - 2018-06-20 02:13:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:13:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:13:23 --> Utf8 Class Initialized
INFO - 2018-06-20 02:13:23 --> URI Class Initialized
INFO - 2018-06-20 02:13:23 --> Router Class Initialized
INFO - 2018-06-20 02:13:23 --> Output Class Initialized
INFO - 2018-06-20 02:13:23 --> Security Class Initialized
DEBUG - 2018-06-20 02:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:13:23 --> CSRF cookie sent
INFO - 2018-06-20 02:13:23 --> Input Class Initialized
INFO - 2018-06-20 02:13:23 --> Language Class Initialized
INFO - 2018-06-20 02:13:23 --> Loader Class Initialized
INFO - 2018-06-20 02:13:23 --> Helper loaded: url_helper
INFO - 2018-06-20 02:13:23 --> Helper loaded: form_helper
INFO - 2018-06-20 02:13:23 --> Helper loaded: language_helper
DEBUG - 2018-06-20 02:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:13:23 --> User Agent Class Initialized
INFO - 2018-06-20 02:13:23 --> Controller Class Initialized
INFO - 2018-06-20 02:13:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 02:13:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 02:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 02:13:23 --> Final output sent to browser
DEBUG - 2018-06-20 02:13:23 --> Total execution time: 0.0282
INFO - 2018-06-20 02:14:12 --> Config Class Initialized
INFO - 2018-06-20 02:14:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:14:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:14:12 --> Utf8 Class Initialized
INFO - 2018-06-20 02:14:12 --> URI Class Initialized
INFO - 2018-06-20 02:14:12 --> Router Class Initialized
INFO - 2018-06-20 02:14:12 --> Output Class Initialized
INFO - 2018-06-20 02:14:12 --> Security Class Initialized
DEBUG - 2018-06-20 02:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:14:12 --> CSRF cookie sent
INFO - 2018-06-20 02:14:12 --> Input Class Initialized
INFO - 2018-06-20 02:14:12 --> Language Class Initialized
INFO - 2018-06-20 02:14:12 --> Loader Class Initialized
INFO - 2018-06-20 02:14:12 --> Helper loaded: url_helper
INFO - 2018-06-20 02:14:12 --> Helper loaded: form_helper
INFO - 2018-06-20 02:14:12 --> Helper loaded: language_helper
DEBUG - 2018-06-20 02:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:14:12 --> User Agent Class Initialized
INFO - 2018-06-20 02:14:12 --> Controller Class Initialized
INFO - 2018-06-20 02:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 02:14:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 02:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 02:14:12 --> Final output sent to browser
DEBUG - 2018-06-20 02:14:12 --> Total execution time: 0.0652
INFO - 2018-06-20 02:14:26 --> Config Class Initialized
INFO - 2018-06-20 02:14:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:14:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:14:26 --> Utf8 Class Initialized
INFO - 2018-06-20 02:14:26 --> URI Class Initialized
INFO - 2018-06-20 02:14:26 --> Router Class Initialized
INFO - 2018-06-20 02:14:26 --> Output Class Initialized
INFO - 2018-06-20 02:14:26 --> Security Class Initialized
DEBUG - 2018-06-20 02:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:14:26 --> CSRF cookie sent
INFO - 2018-06-20 02:14:26 --> Input Class Initialized
INFO - 2018-06-20 02:14:26 --> Language Class Initialized
INFO - 2018-06-20 02:14:26 --> Loader Class Initialized
INFO - 2018-06-20 02:14:26 --> Helper loaded: url_helper
INFO - 2018-06-20 02:14:26 --> Helper loaded: form_helper
INFO - 2018-06-20 02:14:26 --> Helper loaded: language_helper
DEBUG - 2018-06-20 02:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:14:26 --> User Agent Class Initialized
INFO - 2018-06-20 02:14:26 --> Controller Class Initialized
INFO - 2018-06-20 02:14:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 02:14:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 02:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 02:14:26 --> Final output sent to browser
DEBUG - 2018-06-20 02:14:26 --> Total execution time: 0.0375
INFO - 2018-06-20 03:00:04 --> Config Class Initialized
INFO - 2018-06-20 03:00:04 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:00:04 --> Utf8 Class Initialized
INFO - 2018-06-20 03:00:04 --> URI Class Initialized
INFO - 2018-06-20 03:00:04 --> Router Class Initialized
INFO - 2018-06-20 03:00:04 --> Output Class Initialized
INFO - 2018-06-20 03:00:04 --> Security Class Initialized
DEBUG - 2018-06-20 03:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:00:04 --> CSRF cookie sent
INFO - 2018-06-20 03:00:04 --> Input Class Initialized
INFO - 2018-06-20 03:00:04 --> Language Class Initialized
INFO - 2018-06-20 03:00:04 --> Loader Class Initialized
INFO - 2018-06-20 03:00:04 --> Helper loaded: url_helper
INFO - 2018-06-20 03:00:04 --> Helper loaded: form_helper
INFO - 2018-06-20 03:00:04 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:00:04 --> User Agent Class Initialized
INFO - 2018-06-20 03:00:04 --> Controller Class Initialized
INFO - 2018-06-20 03:00:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:00:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 03:00:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:00:04 --> Final output sent to browser
DEBUG - 2018-06-20 03:00:04 --> Total execution time: 0.0488
INFO - 2018-06-20 03:00:37 --> Config Class Initialized
INFO - 2018-06-20 03:00:37 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:00:37 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:00:37 --> Utf8 Class Initialized
INFO - 2018-06-20 03:00:37 --> URI Class Initialized
DEBUG - 2018-06-20 03:00:37 --> No URI present. Default controller set.
INFO - 2018-06-20 03:00:37 --> Router Class Initialized
INFO - 2018-06-20 03:00:37 --> Output Class Initialized
INFO - 2018-06-20 03:00:37 --> Security Class Initialized
DEBUG - 2018-06-20 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:00:37 --> CSRF cookie sent
INFO - 2018-06-20 03:00:37 --> Input Class Initialized
INFO - 2018-06-20 03:00:37 --> Language Class Initialized
INFO - 2018-06-20 03:00:37 --> Loader Class Initialized
INFO - 2018-06-20 03:00:37 --> Helper loaded: url_helper
INFO - 2018-06-20 03:00:37 --> Helper loaded: form_helper
INFO - 2018-06-20 03:00:37 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:00:37 --> User Agent Class Initialized
INFO - 2018-06-20 03:00:37 --> Controller Class Initialized
INFO - 2018-06-20 03:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:00:37 --> Pixel_Model class loaded
INFO - 2018-06-20 03:00:37 --> Database Driver Class Initialized
INFO - 2018-06-20 03:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:00:37 --> Final output sent to browser
DEBUG - 2018-06-20 03:00:37 --> Total execution time: 0.1131
INFO - 2018-06-20 03:00:39 --> Config Class Initialized
INFO - 2018-06-20 03:00:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:00:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:00:39 --> Utf8 Class Initialized
INFO - 2018-06-20 03:00:39 --> URI Class Initialized
INFO - 2018-06-20 03:00:39 --> Router Class Initialized
INFO - 2018-06-20 03:00:39 --> Output Class Initialized
INFO - 2018-06-20 03:00:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:00:39 --> CSRF cookie sent
INFO - 2018-06-20 03:00:39 --> Input Class Initialized
INFO - 2018-06-20 03:00:39 --> Language Class Initialized
INFO - 2018-06-20 03:00:39 --> Loader Class Initialized
INFO - 2018-06-20 03:00:39 --> Helper loaded: url_helper
INFO - 2018-06-20 03:00:39 --> Helper loaded: form_helper
INFO - 2018-06-20 03:00:39 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:00:39 --> User Agent Class Initialized
INFO - 2018-06-20 03:00:39 --> Controller Class Initialized
INFO - 2018-06-20 03:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-20 03:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:00:39 --> Final output sent to browser
DEBUG - 2018-06-20 03:00:39 --> Total execution time: 0.0353
INFO - 2018-06-20 03:00:44 --> Config Class Initialized
INFO - 2018-06-20 03:00:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:00:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:00:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:00:44 --> URI Class Initialized
INFO - 2018-06-20 03:00:44 --> Router Class Initialized
INFO - 2018-06-20 03:00:44 --> Output Class Initialized
INFO - 2018-06-20 03:00:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:00:44 --> CSRF cookie sent
INFO - 2018-06-20 03:00:44 --> Input Class Initialized
INFO - 2018-06-20 03:00:44 --> Language Class Initialized
INFO - 2018-06-20 03:00:44 --> Loader Class Initialized
INFO - 2018-06-20 03:00:44 --> Helper loaded: url_helper
INFO - 2018-06-20 03:00:44 --> Helper loaded: form_helper
INFO - 2018-06-20 03:00:44 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:00:44 --> User Agent Class Initialized
INFO - 2018-06-20 03:00:44 --> Controller Class Initialized
INFO - 2018-06-20 03:00:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:00:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 03:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:00:44 --> Final output sent to browser
DEBUG - 2018-06-20 03:00:44 --> Total execution time: 0.0473
INFO - 2018-06-20 03:01:01 --> Config Class Initialized
INFO - 2018-06-20 03:01:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:01:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:01:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:01:01 --> URI Class Initialized
INFO - 2018-06-20 03:01:01 --> Router Class Initialized
INFO - 2018-06-20 03:01:01 --> Output Class Initialized
INFO - 2018-06-20 03:01:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:01:01 --> CSRF cookie sent
INFO - 2018-06-20 03:01:01 --> Input Class Initialized
INFO - 2018-06-20 03:01:01 --> Language Class Initialized
INFO - 2018-06-20 03:01:01 --> Loader Class Initialized
INFO - 2018-06-20 03:01:01 --> Helper loaded: url_helper
INFO - 2018-06-20 03:01:01 --> Helper loaded: form_helper
INFO - 2018-06-20 03:01:01 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:01:01 --> User Agent Class Initialized
INFO - 2018-06-20 03:01:01 --> Controller Class Initialized
INFO - 2018-06-20 03:01:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:01:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:01:01 --> Final output sent to browser
DEBUG - 2018-06-20 03:01:01 --> Total execution time: 0.0385
INFO - 2018-06-20 03:01:32 --> Config Class Initialized
INFO - 2018-06-20 03:01:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:01:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:01:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:01:32 --> URI Class Initialized
DEBUG - 2018-06-20 03:01:32 --> No URI present. Default controller set.
INFO - 2018-06-20 03:01:32 --> Router Class Initialized
INFO - 2018-06-20 03:01:32 --> Output Class Initialized
INFO - 2018-06-20 03:01:32 --> Security Class Initialized
DEBUG - 2018-06-20 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:01:32 --> CSRF cookie sent
INFO - 2018-06-20 03:01:32 --> Input Class Initialized
INFO - 2018-06-20 03:01:32 --> Language Class Initialized
INFO - 2018-06-20 03:01:32 --> Loader Class Initialized
INFO - 2018-06-20 03:01:32 --> Helper loaded: url_helper
INFO - 2018-06-20 03:01:32 --> Helper loaded: form_helper
INFO - 2018-06-20 03:01:32 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:01:32 --> User Agent Class Initialized
INFO - 2018-06-20 03:01:32 --> Controller Class Initialized
INFO - 2018-06-20 03:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:01:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:01:32 --> Pixel_Model class loaded
INFO - 2018-06-20 03:01:32 --> Database Driver Class Initialized
INFO - 2018-06-20 03:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:01:32 --> Final output sent to browser
DEBUG - 2018-06-20 03:01:32 --> Total execution time: 0.0689
INFO - 2018-06-20 03:08:57 --> Config Class Initialized
INFO - 2018-06-20 03:08:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:08:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:08:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:08:57 --> URI Class Initialized
INFO - 2018-06-20 03:08:57 --> Router Class Initialized
INFO - 2018-06-20 03:08:57 --> Output Class Initialized
INFO - 2018-06-20 03:08:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:08:57 --> CSRF cookie sent
INFO - 2018-06-20 03:08:57 --> Input Class Initialized
INFO - 2018-06-20 03:08:57 --> Language Class Initialized
INFO - 2018-06-20 03:08:57 --> Loader Class Initialized
INFO - 2018-06-20 03:08:57 --> Helper loaded: url_helper
INFO - 2018-06-20 03:08:57 --> Helper loaded: form_helper
INFO - 2018-06-20 03:08:57 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:08:57 --> User Agent Class Initialized
INFO - 2018-06-20 03:08:57 --> Controller Class Initialized
INFO - 2018-06-20 03:08:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:08:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:08:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:08:57 --> Final output sent to browser
DEBUG - 2018-06-20 03:08:57 --> Total execution time: 0.0338
INFO - 2018-06-20 03:10:03 --> Config Class Initialized
INFO - 2018-06-20 03:10:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:10:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:10:03 --> Utf8 Class Initialized
INFO - 2018-06-20 03:10:03 --> URI Class Initialized
DEBUG - 2018-06-20 03:10:03 --> No URI present. Default controller set.
INFO - 2018-06-20 03:10:03 --> Router Class Initialized
INFO - 2018-06-20 03:10:03 --> Output Class Initialized
INFO - 2018-06-20 03:10:03 --> Security Class Initialized
DEBUG - 2018-06-20 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:10:03 --> CSRF cookie sent
INFO - 2018-06-20 03:10:03 --> Input Class Initialized
INFO - 2018-06-20 03:10:03 --> Language Class Initialized
INFO - 2018-06-20 03:10:03 --> Loader Class Initialized
INFO - 2018-06-20 03:10:03 --> Helper loaded: url_helper
INFO - 2018-06-20 03:10:03 --> Helper loaded: form_helper
INFO - 2018-06-20 03:10:03 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:10:03 --> User Agent Class Initialized
INFO - 2018-06-20 03:10:03 --> Controller Class Initialized
INFO - 2018-06-20 03:10:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:10:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:10:03 --> Pixel_Model class loaded
INFO - 2018-06-20 03:10:03 --> Database Driver Class Initialized
INFO - 2018-06-20 03:10:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:10:03 --> Final output sent to browser
DEBUG - 2018-06-20 03:10:03 --> Total execution time: 0.0849
INFO - 2018-06-20 03:10:30 --> Config Class Initialized
INFO - 2018-06-20 03:10:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:10:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:10:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:10:30 --> URI Class Initialized
INFO - 2018-06-20 03:10:30 --> Router Class Initialized
INFO - 2018-06-20 03:10:30 --> Output Class Initialized
INFO - 2018-06-20 03:10:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:10:30 --> CSRF cookie sent
INFO - 2018-06-20 03:10:30 --> Input Class Initialized
INFO - 2018-06-20 03:10:30 --> Language Class Initialized
INFO - 2018-06-20 03:10:30 --> Loader Class Initialized
INFO - 2018-06-20 03:10:30 --> Helper loaded: url_helper
INFO - 2018-06-20 03:10:30 --> Helper loaded: form_helper
INFO - 2018-06-20 03:10:30 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:10:30 --> User Agent Class Initialized
INFO - 2018-06-20 03:10:30 --> Controller Class Initialized
INFO - 2018-06-20 03:10:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:10:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:10:30 --> Pixel_Model class loaded
INFO - 2018-06-20 03:10:30 --> Database Driver Class Initialized
INFO - 2018-06-20 03:10:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:10:30 --> Config Class Initialized
INFO - 2018-06-20 03:10:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:10:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:10:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:10:30 --> URI Class Initialized
INFO - 2018-06-20 03:10:30 --> Router Class Initialized
INFO - 2018-06-20 03:10:30 --> Output Class Initialized
INFO - 2018-06-20 03:10:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:10:30 --> CSRF cookie sent
INFO - 2018-06-20 03:10:30 --> Input Class Initialized
INFO - 2018-06-20 03:10:30 --> Language Class Initialized
INFO - 2018-06-20 03:10:30 --> Loader Class Initialized
INFO - 2018-06-20 03:10:30 --> Helper loaded: url_helper
INFO - 2018-06-20 03:10:30 --> Helper loaded: form_helper
INFO - 2018-06-20 03:10:30 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:10:30 --> User Agent Class Initialized
INFO - 2018-06-20 03:10:30 --> Controller Class Initialized
INFO - 2018-06-20 03:10:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:10:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-20 03:10:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-20 03:10:30 --> Could not find the language line "req_email"
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-20 03:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:10:30 --> Final output sent to browser
DEBUG - 2018-06-20 03:10:30 --> Total execution time: 0.0456
INFO - 2018-06-20 03:10:33 --> Config Class Initialized
INFO - 2018-06-20 03:10:33 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:10:33 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:10:33 --> Utf8 Class Initialized
INFO - 2018-06-20 03:10:33 --> URI Class Initialized
INFO - 2018-06-20 03:10:33 --> Router Class Initialized
INFO - 2018-06-20 03:10:33 --> Output Class Initialized
INFO - 2018-06-20 03:10:33 --> Security Class Initialized
DEBUG - 2018-06-20 03:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:10:33 --> CSRF cookie sent
INFO - 2018-06-20 03:10:33 --> Input Class Initialized
INFO - 2018-06-20 03:10:33 --> Language Class Initialized
INFO - 2018-06-20 03:10:33 --> Loader Class Initialized
INFO - 2018-06-20 03:10:33 --> Helper loaded: url_helper
INFO - 2018-06-20 03:10:33 --> Helper loaded: form_helper
INFO - 2018-06-20 03:10:33 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:10:33 --> User Agent Class Initialized
INFO - 2018-06-20 03:10:33 --> Controller Class Initialized
INFO - 2018-06-20 03:10:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:10:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:10:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:10:33 --> Final output sent to browser
DEBUG - 2018-06-20 03:10:33 --> Total execution time: 0.0365
INFO - 2018-06-20 03:13:59 --> Config Class Initialized
INFO - 2018-06-20 03:13:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:13:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:13:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:13:59 --> URI Class Initialized
INFO - 2018-06-20 03:13:59 --> Router Class Initialized
INFO - 2018-06-20 03:13:59 --> Output Class Initialized
INFO - 2018-06-20 03:13:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:13:59 --> CSRF cookie sent
INFO - 2018-06-20 03:13:59 --> Input Class Initialized
INFO - 2018-06-20 03:13:59 --> Language Class Initialized
INFO - 2018-06-20 03:13:59 --> Loader Class Initialized
INFO - 2018-06-20 03:13:59 --> Helper loaded: url_helper
INFO - 2018-06-20 03:13:59 --> Helper loaded: form_helper
INFO - 2018-06-20 03:13:59 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:13:59 --> User Agent Class Initialized
INFO - 2018-06-20 03:13:59 --> Controller Class Initialized
INFO - 2018-06-20 03:13:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:13:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:13:59 --> Final output sent to browser
DEBUG - 2018-06-20 03:13:59 --> Total execution time: 0.0391
INFO - 2018-06-20 03:14:01 --> Config Class Initialized
INFO - 2018-06-20 03:14:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:01 --> URI Class Initialized
INFO - 2018-06-20 03:14:01 --> Router Class Initialized
INFO - 2018-06-20 03:14:01 --> Output Class Initialized
INFO - 2018-06-20 03:14:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:01 --> CSRF cookie sent
INFO - 2018-06-20 03:14:01 --> Input Class Initialized
INFO - 2018-06-20 03:14:01 --> Language Class Initialized
INFO - 2018-06-20 03:14:01 --> Loader Class Initialized
INFO - 2018-06-20 03:14:01 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:01 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:01 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:01 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:01 --> Controller Class Initialized
INFO - 2018-06-20 03:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:01 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:01 --> Total execution time: 0.0370
INFO - 2018-06-20 03:14:09 --> Config Class Initialized
INFO - 2018-06-20 03:14:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:09 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:09 --> URI Class Initialized
INFO - 2018-06-20 03:14:09 --> Router Class Initialized
INFO - 2018-06-20 03:14:09 --> Output Class Initialized
INFO - 2018-06-20 03:14:09 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:09 --> CSRF cookie sent
INFO - 2018-06-20 03:14:09 --> Input Class Initialized
INFO - 2018-06-20 03:14:09 --> Language Class Initialized
INFO - 2018-06-20 03:14:09 --> Loader Class Initialized
INFO - 2018-06-20 03:14:09 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:09 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:09 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:09 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:09 --> Controller Class Initialized
INFO - 2018-06-20 03:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:09 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:09 --> Total execution time: 0.0650
INFO - 2018-06-20 03:14:09 --> Config Class Initialized
INFO - 2018-06-20 03:14:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:09 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:09 --> URI Class Initialized
INFO - 2018-06-20 03:14:09 --> Router Class Initialized
INFO - 2018-06-20 03:14:09 --> Output Class Initialized
INFO - 2018-06-20 03:14:09 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:09 --> CSRF cookie sent
INFO - 2018-06-20 03:14:09 --> Input Class Initialized
INFO - 2018-06-20 03:14:09 --> Language Class Initialized
INFO - 2018-06-20 03:14:09 --> Loader Class Initialized
INFO - 2018-06-20 03:14:09 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:09 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:09 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:09 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:09 --> Controller Class Initialized
INFO - 2018-06-20 03:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:09 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:09 --> Total execution time: 0.0330
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:10 --> Controller Class Initialized
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:10 --> Total execution time: 0.0308
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:10 --> Controller Class Initialized
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:10 --> Total execution time: 0.0407
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:10 --> Controller Class Initialized
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:10 --> Total execution time: 0.0336
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:10 --> Controller Class Initialized
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:10 --> Total execution time: 0.0336
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:10 --> Controller Class Initialized
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:10 --> Total execution time: 0.0347
INFO - 2018-06-20 03:14:10 --> Config Class Initialized
INFO - 2018-06-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:10 --> URI Class Initialized
INFO - 2018-06-20 03:14:10 --> Router Class Initialized
INFO - 2018-06-20 03:14:10 --> Output Class Initialized
INFO - 2018-06-20 03:14:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:10 --> CSRF cookie sent
INFO - 2018-06-20 03:14:10 --> Input Class Initialized
INFO - 2018-06-20 03:14:10 --> Language Class Initialized
INFO - 2018-06-20 03:14:10 --> Loader Class Initialized
INFO - 2018-06-20 03:14:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:10 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:11 --> Controller Class Initialized
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:11 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:11 --> Total execution time: 0.0752
INFO - 2018-06-20 03:14:11 --> Config Class Initialized
INFO - 2018-06-20 03:14:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:11 --> URI Class Initialized
INFO - 2018-06-20 03:14:11 --> Router Class Initialized
INFO - 2018-06-20 03:14:11 --> Output Class Initialized
INFO - 2018-06-20 03:14:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:11 --> CSRF cookie sent
INFO - 2018-06-20 03:14:11 --> Input Class Initialized
INFO - 2018-06-20 03:14:11 --> Language Class Initialized
INFO - 2018-06-20 03:14:11 --> Loader Class Initialized
INFO - 2018-06-20 03:14:11 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:11 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:11 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:11 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:11 --> Controller Class Initialized
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:11 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:11 --> Total execution time: 0.0280
INFO - 2018-06-20 03:14:11 --> Config Class Initialized
INFO - 2018-06-20 03:14:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:11 --> URI Class Initialized
INFO - 2018-06-20 03:14:11 --> Router Class Initialized
INFO - 2018-06-20 03:14:11 --> Output Class Initialized
INFO - 2018-06-20 03:14:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:11 --> CSRF cookie sent
INFO - 2018-06-20 03:14:11 --> Input Class Initialized
INFO - 2018-06-20 03:14:11 --> Language Class Initialized
INFO - 2018-06-20 03:14:11 --> Loader Class Initialized
INFO - 2018-06-20 03:14:11 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:11 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:11 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:11 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:11 --> Controller Class Initialized
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:11 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:11 --> Total execution time: 0.0210
INFO - 2018-06-20 03:14:38 --> Config Class Initialized
INFO - 2018-06-20 03:14:38 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:38 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:38 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:38 --> URI Class Initialized
INFO - 2018-06-20 03:14:38 --> Router Class Initialized
INFO - 2018-06-20 03:14:38 --> Output Class Initialized
INFO - 2018-06-20 03:14:38 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:38 --> CSRF cookie sent
INFO - 2018-06-20 03:14:38 --> Input Class Initialized
INFO - 2018-06-20 03:14:38 --> Language Class Initialized
INFO - 2018-06-20 03:14:38 --> Loader Class Initialized
INFO - 2018-06-20 03:14:38 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:38 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:38 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:38 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:38 --> Controller Class Initialized
INFO - 2018-06-20 03:14:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:38 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:38 --> Total execution time: 0.0524
INFO - 2018-06-20 03:14:39 --> Config Class Initialized
INFO - 2018-06-20 03:14:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:39 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:39 --> URI Class Initialized
INFO - 2018-06-20 03:14:39 --> Router Class Initialized
INFO - 2018-06-20 03:14:39 --> Output Class Initialized
INFO - 2018-06-20 03:14:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:39 --> CSRF cookie sent
INFO - 2018-06-20 03:14:39 --> Input Class Initialized
INFO - 2018-06-20 03:14:39 --> Language Class Initialized
INFO - 2018-06-20 03:14:39 --> Loader Class Initialized
INFO - 2018-06-20 03:14:39 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:39 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:39 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:39 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:39 --> Controller Class Initialized
INFO - 2018-06-20 03:14:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:39 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:39 --> Total execution time: 0.0902
INFO - 2018-06-20 03:14:39 --> Config Class Initialized
INFO - 2018-06-20 03:14:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:39 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:39 --> URI Class Initialized
INFO - 2018-06-20 03:14:39 --> Router Class Initialized
INFO - 2018-06-20 03:14:39 --> Output Class Initialized
INFO - 2018-06-20 03:14:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:39 --> CSRF cookie sent
INFO - 2018-06-20 03:14:39 --> Input Class Initialized
INFO - 2018-06-20 03:14:39 --> Language Class Initialized
INFO - 2018-06-20 03:14:39 --> Loader Class Initialized
INFO - 2018-06-20 03:14:39 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:39 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:39 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:39 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:39 --> Controller Class Initialized
INFO - 2018-06-20 03:14:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:39 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:39 --> Total execution time: 0.0500
INFO - 2018-06-20 03:14:44 --> Config Class Initialized
INFO - 2018-06-20 03:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:44 --> URI Class Initialized
INFO - 2018-06-20 03:14:44 --> Router Class Initialized
INFO - 2018-06-20 03:14:44 --> Output Class Initialized
INFO - 2018-06-20 03:14:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:44 --> CSRF cookie sent
INFO - 2018-06-20 03:14:44 --> Input Class Initialized
INFO - 2018-06-20 03:14:44 --> Language Class Initialized
INFO - 2018-06-20 03:14:44 --> Loader Class Initialized
INFO - 2018-06-20 03:14:44 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:44 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:44 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:44 --> User Agent Class Initialized
INFO - 2018-06-20 03:14:44 --> Controller Class Initialized
INFO - 2018-06-20 03:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:14:44 --> Final output sent to browser
DEBUG - 2018-06-20 03:14:44 --> Total execution time: 0.0255
INFO - 2018-06-20 03:19:22 --> Config Class Initialized
INFO - 2018-06-20 03:19:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:22 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:22 --> URI Class Initialized
INFO - 2018-06-20 03:19:22 --> Router Class Initialized
INFO - 2018-06-20 03:19:22 --> Output Class Initialized
INFO - 2018-06-20 03:19:22 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:22 --> CSRF cookie sent
INFO - 2018-06-20 03:19:22 --> Input Class Initialized
INFO - 2018-06-20 03:19:22 --> Language Class Initialized
INFO - 2018-06-20 03:19:22 --> Loader Class Initialized
INFO - 2018-06-20 03:19:22 --> Helper loaded: url_helper
INFO - 2018-06-20 03:19:22 --> Helper loaded: form_helper
INFO - 2018-06-20 03:19:22 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:19:22 --> User Agent Class Initialized
INFO - 2018-06-20 03:19:22 --> Controller Class Initialized
INFO - 2018-06-20 03:19:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:19:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:19:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:19:22 --> Final output sent to browser
DEBUG - 2018-06-20 03:19:22 --> Total execution time: 0.0488
INFO - 2018-06-20 03:19:28 --> Config Class Initialized
INFO - 2018-06-20 03:19:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:28 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:28 --> URI Class Initialized
INFO - 2018-06-20 03:19:28 --> Router Class Initialized
INFO - 2018-06-20 03:19:28 --> Output Class Initialized
INFO - 2018-06-20 03:19:28 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:28 --> CSRF cookie sent
INFO - 2018-06-20 03:19:28 --> Input Class Initialized
INFO - 2018-06-20 03:19:28 --> Language Class Initialized
INFO - 2018-06-20 03:19:28 --> Loader Class Initialized
INFO - 2018-06-20 03:19:28 --> Helper loaded: url_helper
INFO - 2018-06-20 03:19:28 --> Helper loaded: form_helper
INFO - 2018-06-20 03:19:28 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:19:28 --> User Agent Class Initialized
INFO - 2018-06-20 03:19:28 --> Controller Class Initialized
INFO - 2018-06-20 03:19:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:19:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:19:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:19:28 --> Final output sent to browser
DEBUG - 2018-06-20 03:19:28 --> Total execution time: 0.0642
INFO - 2018-06-20 03:35:06 --> Config Class Initialized
INFO - 2018-06-20 03:35:06 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:35:06 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:35:06 --> Utf8 Class Initialized
INFO - 2018-06-20 03:35:06 --> URI Class Initialized
INFO - 2018-06-20 03:35:06 --> Router Class Initialized
INFO - 2018-06-20 03:35:06 --> Output Class Initialized
INFO - 2018-06-20 03:35:06 --> Security Class Initialized
DEBUG - 2018-06-20 03:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:35:06 --> CSRF cookie sent
INFO - 2018-06-20 03:35:06 --> Input Class Initialized
INFO - 2018-06-20 03:35:06 --> Language Class Initialized
INFO - 2018-06-20 03:35:06 --> Loader Class Initialized
INFO - 2018-06-20 03:35:06 --> Helper loaded: url_helper
INFO - 2018-06-20 03:35:06 --> Helper loaded: form_helper
INFO - 2018-06-20 03:35:06 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:35:06 --> User Agent Class Initialized
INFO - 2018-06-20 03:35:06 --> Controller Class Initialized
INFO - 2018-06-20 03:35:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:35:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 03:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:35:06 --> Final output sent to browser
DEBUG - 2018-06-20 03:35:06 --> Total execution time: 0.0447
INFO - 2018-06-20 03:36:32 --> Config Class Initialized
INFO - 2018-06-20 03:36:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:32 --> URI Class Initialized
DEBUG - 2018-06-20 03:36:32 --> No URI present. Default controller set.
INFO - 2018-06-20 03:36:32 --> Router Class Initialized
INFO - 2018-06-20 03:36:32 --> Output Class Initialized
INFO - 2018-06-20 03:36:32 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:32 --> CSRF cookie sent
INFO - 2018-06-20 03:36:32 --> Input Class Initialized
INFO - 2018-06-20 03:36:32 --> Language Class Initialized
INFO - 2018-06-20 03:36:33 --> Loader Class Initialized
INFO - 2018-06-20 03:36:33 --> Helper loaded: url_helper
INFO - 2018-06-20 03:36:33 --> Helper loaded: form_helper
INFO - 2018-06-20 03:36:33 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:36:33 --> User Agent Class Initialized
INFO - 2018-06-20 03:36:33 --> Controller Class Initialized
INFO - 2018-06-20 03:36:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:36:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:36:33 --> Pixel_Model class loaded
INFO - 2018-06-20 03:36:33 --> Database Driver Class Initialized
INFO - 2018-06-20 03:36:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:36:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:36:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:36:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:36:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:36:33 --> Final output sent to browser
DEBUG - 2018-06-20 03:36:33 --> Total execution time: 0.0620
INFO - 2018-06-20 03:36:35 --> Config Class Initialized
INFO - 2018-06-20 03:36:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:35 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:35 --> URI Class Initialized
DEBUG - 2018-06-20 03:36:35 --> No URI present. Default controller set.
INFO - 2018-06-20 03:36:35 --> Router Class Initialized
INFO - 2018-06-20 03:36:35 --> Output Class Initialized
INFO - 2018-06-20 03:36:35 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:35 --> CSRF cookie sent
INFO - 2018-06-20 03:36:35 --> Input Class Initialized
INFO - 2018-06-20 03:36:35 --> Language Class Initialized
INFO - 2018-06-20 03:36:35 --> Loader Class Initialized
INFO - 2018-06-20 03:36:35 --> Helper loaded: url_helper
INFO - 2018-06-20 03:36:35 --> Helper loaded: form_helper
INFO - 2018-06-20 03:36:35 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:36:35 --> User Agent Class Initialized
INFO - 2018-06-20 03:36:35 --> Controller Class Initialized
INFO - 2018-06-20 03:36:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:36:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:36:35 --> Pixel_Model class loaded
INFO - 2018-06-20 03:36:35 --> Database Driver Class Initialized
INFO - 2018-06-20 03:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:36:36 --> Final output sent to browser
DEBUG - 2018-06-20 03:36:36 --> Total execution time: 0.0405
INFO - 2018-06-20 03:36:46 --> Config Class Initialized
INFO - 2018-06-20 03:36:46 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:46 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:46 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:46 --> URI Class Initialized
INFO - 2018-06-20 03:36:46 --> Router Class Initialized
INFO - 2018-06-20 03:36:46 --> Output Class Initialized
INFO - 2018-06-20 03:36:46 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:46 --> CSRF cookie sent
INFO - 2018-06-20 03:36:46 --> Input Class Initialized
INFO - 2018-06-20 03:36:46 --> Language Class Initialized
ERROR - 2018-06-20 03:36:46 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2018-06-20 03:36:50 --> Config Class Initialized
INFO - 2018-06-20 03:36:50 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:50 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:50 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:50 --> URI Class Initialized
DEBUG - 2018-06-20 03:36:50 --> No URI present. Default controller set.
INFO - 2018-06-20 03:36:50 --> Router Class Initialized
INFO - 2018-06-20 03:36:50 --> Output Class Initialized
INFO - 2018-06-20 03:36:50 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:50 --> CSRF cookie sent
INFO - 2018-06-20 03:36:50 --> Input Class Initialized
INFO - 2018-06-20 03:36:50 --> Language Class Initialized
INFO - 2018-06-20 03:36:50 --> Loader Class Initialized
INFO - 2018-06-20 03:36:50 --> Helper loaded: url_helper
INFO - 2018-06-20 03:36:50 --> Helper loaded: form_helper
INFO - 2018-06-20 03:36:50 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:36:50 --> User Agent Class Initialized
INFO - 2018-06-20 03:36:50 --> Controller Class Initialized
INFO - 2018-06-20 03:36:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:36:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:36:50 --> Pixel_Model class loaded
INFO - 2018-06-20 03:36:50 --> Database Driver Class Initialized
INFO - 2018-06-20 03:36:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:36:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:36:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:36:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:36:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:36:50 --> Final output sent to browser
DEBUG - 2018-06-20 03:36:50 --> Total execution time: 0.0535
INFO - 2018-06-20 03:36:53 --> Config Class Initialized
INFO - 2018-06-20 03:36:53 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:53 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:53 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:53 --> URI Class Initialized
DEBUG - 2018-06-20 03:36:53 --> No URI present. Default controller set.
INFO - 2018-06-20 03:36:53 --> Router Class Initialized
INFO - 2018-06-20 03:36:53 --> Output Class Initialized
INFO - 2018-06-20 03:36:53 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:53 --> CSRF cookie sent
INFO - 2018-06-20 03:36:53 --> Input Class Initialized
INFO - 2018-06-20 03:36:53 --> Language Class Initialized
INFO - 2018-06-20 03:36:53 --> Loader Class Initialized
INFO - 2018-06-20 03:36:53 --> Helper loaded: url_helper
INFO - 2018-06-20 03:36:53 --> Helper loaded: form_helper
INFO - 2018-06-20 03:36:53 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:36:53 --> User Agent Class Initialized
INFO - 2018-06-20 03:36:53 --> Controller Class Initialized
INFO - 2018-06-20 03:36:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:36:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:36:53 --> Pixel_Model class loaded
INFO - 2018-06-20 03:36:53 --> Database Driver Class Initialized
INFO - 2018-06-20 03:36:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:36:53 --> Final output sent to browser
DEBUG - 2018-06-20 03:36:53 --> Total execution time: 0.0964
INFO - 2018-06-20 03:36:56 --> Config Class Initialized
INFO - 2018-06-20 03:36:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:56 --> URI Class Initialized
DEBUG - 2018-06-20 03:36:56 --> No URI present. Default controller set.
INFO - 2018-06-20 03:36:56 --> Router Class Initialized
INFO - 2018-06-20 03:36:56 --> Output Class Initialized
INFO - 2018-06-20 03:36:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:56 --> CSRF cookie sent
INFO - 2018-06-20 03:36:56 --> Input Class Initialized
INFO - 2018-06-20 03:36:56 --> Language Class Initialized
INFO - 2018-06-20 03:36:56 --> Loader Class Initialized
INFO - 2018-06-20 03:36:56 --> Helper loaded: url_helper
INFO - 2018-06-20 03:36:56 --> Helper loaded: form_helper
INFO - 2018-06-20 03:36:56 --> Helper loaded: language_helper
DEBUG - 2018-06-20 03:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:36:56 --> User Agent Class Initialized
INFO - 2018-06-20 03:36:56 --> Controller Class Initialized
INFO - 2018-06-20 03:36:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 03:36:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 03:36:56 --> Pixel_Model class loaded
INFO - 2018-06-20 03:36:56 --> Database Driver Class Initialized
INFO - 2018-06-20 03:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 03:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 03:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 03:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 03:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 03:36:56 --> Final output sent to browser
DEBUG - 2018-06-20 03:36:56 --> Total execution time: 0.0487
INFO - 2018-06-20 03:36:59 --> Config Class Initialized
INFO - 2018-06-20 03:36:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:36:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:36:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:36:59 --> URI Class Initialized
INFO - 2018-06-20 03:36:59 --> Router Class Initialized
INFO - 2018-06-20 03:36:59 --> Output Class Initialized
INFO - 2018-06-20 03:36:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:36:59 --> CSRF cookie sent
INFO - 2018-06-20 03:36:59 --> Input Class Initialized
INFO - 2018-06-20 03:36:59 --> Language Class Initialized
ERROR - 2018-06-20 03:36:59 --> 404 Page Not Found: User/register
INFO - 2018-06-20 06:12:36 --> Config Class Initialized
INFO - 2018-06-20 06:12:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 06:12:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 06:12:36 --> Utf8 Class Initialized
INFO - 2018-06-20 06:12:36 --> URI Class Initialized
DEBUG - 2018-06-20 06:12:36 --> No URI present. Default controller set.
INFO - 2018-06-20 06:12:36 --> Router Class Initialized
INFO - 2018-06-20 06:12:36 --> Output Class Initialized
INFO - 2018-06-20 06:12:36 --> Security Class Initialized
DEBUG - 2018-06-20 06:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 06:12:36 --> CSRF cookie sent
INFO - 2018-06-20 06:12:36 --> Input Class Initialized
INFO - 2018-06-20 06:12:36 --> Language Class Initialized
INFO - 2018-06-20 06:12:36 --> Loader Class Initialized
INFO - 2018-06-20 06:12:36 --> Helper loaded: url_helper
INFO - 2018-06-20 06:12:36 --> Helper loaded: form_helper
INFO - 2018-06-20 06:12:36 --> Helper loaded: language_helper
DEBUG - 2018-06-20 06:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 06:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 06:12:36 --> User Agent Class Initialized
INFO - 2018-06-20 06:12:36 --> Controller Class Initialized
INFO - 2018-06-20 06:12:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 06:12:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 06:12:36 --> Pixel_Model class loaded
INFO - 2018-06-20 06:12:36 --> Database Driver Class Initialized
INFO - 2018-06-20 06:12:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 06:12:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 06:12:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 06:12:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 06:12:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 06:12:36 --> Final output sent to browser
DEBUG - 2018-06-20 06:12:36 --> Total execution time: 0.0530
INFO - 2018-06-20 10:39:29 --> Config Class Initialized
INFO - 2018-06-20 10:39:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 10:39:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 10:39:29 --> Utf8 Class Initialized
INFO - 2018-06-20 10:39:29 --> URI Class Initialized
DEBUG - 2018-06-20 10:39:29 --> No URI present. Default controller set.
INFO - 2018-06-20 10:39:29 --> Router Class Initialized
INFO - 2018-06-20 10:39:29 --> Output Class Initialized
INFO - 2018-06-20 10:39:29 --> Security Class Initialized
DEBUG - 2018-06-20 10:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 10:39:29 --> CSRF cookie sent
INFO - 2018-06-20 10:39:29 --> Input Class Initialized
INFO - 2018-06-20 10:39:29 --> Language Class Initialized
INFO - 2018-06-20 10:39:29 --> Loader Class Initialized
INFO - 2018-06-20 10:39:29 --> Helper loaded: url_helper
INFO - 2018-06-20 10:39:29 --> Helper loaded: form_helper
INFO - 2018-06-20 10:39:29 --> Helper loaded: language_helper
DEBUG - 2018-06-20 10:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 10:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 10:39:29 --> User Agent Class Initialized
INFO - 2018-06-20 10:39:29 --> Controller Class Initialized
INFO - 2018-06-20 10:39:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 10:39:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 10:39:29 --> Pixel_Model class loaded
INFO - 2018-06-20 10:39:29 --> Database Driver Class Initialized
INFO - 2018-06-20 10:39:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 10:39:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 10:39:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 10:39:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 10:39:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 10:39:29 --> Final output sent to browser
DEBUG - 2018-06-20 10:39:29 --> Total execution time: 0.0680
INFO - 2018-06-20 10:39:35 --> Config Class Initialized
INFO - 2018-06-20 10:39:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 10:39:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 10:39:35 --> Utf8 Class Initialized
INFO - 2018-06-20 10:39:35 --> URI Class Initialized
INFO - 2018-06-20 10:39:35 --> Router Class Initialized
INFO - 2018-06-20 10:39:35 --> Output Class Initialized
INFO - 2018-06-20 10:39:35 --> Security Class Initialized
DEBUG - 2018-06-20 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 10:39:35 --> CSRF cookie sent
INFO - 2018-06-20 10:39:35 --> Input Class Initialized
INFO - 2018-06-20 10:39:35 --> Language Class Initialized
ERROR - 2018-06-20 10:39:35 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-06-20 10:39:35 --> Config Class Initialized
INFO - 2018-06-20 10:39:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 10:39:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 10:39:35 --> Utf8 Class Initialized
INFO - 2018-06-20 10:39:35 --> URI Class Initialized
INFO - 2018-06-20 10:39:35 --> Router Class Initialized
INFO - 2018-06-20 10:39:35 --> Output Class Initialized
INFO - 2018-06-20 10:39:35 --> Security Class Initialized
DEBUG - 2018-06-20 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 10:39:35 --> CSRF cookie sent
INFO - 2018-06-20 10:39:35 --> Input Class Initialized
INFO - 2018-06-20 10:39:35 --> Language Class Initialized
ERROR - 2018-06-20 10:39:35 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-06-20 10:39:36 --> Config Class Initialized
INFO - 2018-06-20 10:39:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 10:39:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 10:39:36 --> Utf8 Class Initialized
INFO - 2018-06-20 10:39:36 --> URI Class Initialized
INFO - 2018-06-20 10:39:36 --> Router Class Initialized
INFO - 2018-06-20 10:39:36 --> Output Class Initialized
INFO - 2018-06-20 10:39:36 --> Security Class Initialized
DEBUG - 2018-06-20 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 10:39:36 --> CSRF cookie sent
INFO - 2018-06-20 10:39:36 --> Input Class Initialized
INFO - 2018-06-20 10:39:36 --> Language Class Initialized
ERROR - 2018-06-20 10:39:36 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-06-20 10:39:36 --> Config Class Initialized
INFO - 2018-06-20 10:39:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 10:39:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 10:39:36 --> Utf8 Class Initialized
INFO - 2018-06-20 10:39:36 --> URI Class Initialized
INFO - 2018-06-20 10:39:36 --> Router Class Initialized
INFO - 2018-06-20 10:39:36 --> Output Class Initialized
INFO - 2018-06-20 10:39:36 --> Security Class Initialized
DEBUG - 2018-06-20 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 10:39:36 --> CSRF cookie sent
INFO - 2018-06-20 10:39:36 --> Input Class Initialized
INFO - 2018-06-20 10:39:36 --> Language Class Initialized
ERROR - 2018-06-20 10:39:36 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-06-20 13:20:20 --> Config Class Initialized
INFO - 2018-06-20 13:20:20 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:20:20 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:20:20 --> Utf8 Class Initialized
INFO - 2018-06-20 13:20:20 --> URI Class Initialized
INFO - 2018-06-20 13:20:20 --> Router Class Initialized
INFO - 2018-06-20 13:20:20 --> Output Class Initialized
INFO - 2018-06-20 13:20:20 --> Security Class Initialized
DEBUG - 2018-06-20 13:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:20:20 --> CSRF cookie sent
INFO - 2018-06-20 13:20:20 --> Input Class Initialized
INFO - 2018-06-20 13:20:20 --> Language Class Initialized
INFO - 2018-06-20 13:20:20 --> Loader Class Initialized
INFO - 2018-06-20 13:20:20 --> Helper loaded: url_helper
INFO - 2018-06-20 13:20:20 --> Helper loaded: form_helper
INFO - 2018-06-20 13:20:20 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:20:20 --> User Agent Class Initialized
INFO - 2018-06-20 13:20:20 --> Controller Class Initialized
INFO - 2018-06-20 13:20:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:20:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:20:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:20:20 --> Final output sent to browser
DEBUG - 2018-06-20 13:20:20 --> Total execution time: 0.0381
INFO - 2018-06-20 13:20:24 --> Config Class Initialized
INFO - 2018-06-20 13:20:24 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:20:24 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:20:24 --> Utf8 Class Initialized
INFO - 2018-06-20 13:20:24 --> URI Class Initialized
INFO - 2018-06-20 13:20:24 --> Router Class Initialized
INFO - 2018-06-20 13:20:24 --> Output Class Initialized
INFO - 2018-06-20 13:20:24 --> Security Class Initialized
DEBUG - 2018-06-20 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:20:24 --> CSRF cookie sent
INFO - 2018-06-20 13:20:24 --> Input Class Initialized
INFO - 2018-06-20 13:20:24 --> Language Class Initialized
INFO - 2018-06-20 13:20:24 --> Loader Class Initialized
INFO - 2018-06-20 13:20:24 --> Helper loaded: url_helper
INFO - 2018-06-20 13:20:24 --> Helper loaded: form_helper
INFO - 2018-06-20 13:20:24 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:20:24 --> User Agent Class Initialized
INFO - 2018-06-20 13:20:24 --> Controller Class Initialized
INFO - 2018-06-20 13:20:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:20:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:20:24 --> Final output sent to browser
DEBUG - 2018-06-20 13:20:24 --> Total execution time: 0.0557
INFO - 2018-06-20 13:21:33 --> Config Class Initialized
INFO - 2018-06-20 13:21:33 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:21:33 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:21:33 --> Utf8 Class Initialized
INFO - 2018-06-20 13:21:33 --> URI Class Initialized
INFO - 2018-06-20 13:21:33 --> Router Class Initialized
INFO - 2018-06-20 13:21:33 --> Output Class Initialized
INFO - 2018-06-20 13:21:33 --> Security Class Initialized
DEBUG - 2018-06-20 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:21:33 --> CSRF cookie sent
INFO - 2018-06-20 13:21:33 --> Input Class Initialized
INFO - 2018-06-20 13:21:33 --> Language Class Initialized
INFO - 2018-06-20 13:21:33 --> Loader Class Initialized
INFO - 2018-06-20 13:21:33 --> Helper loaded: url_helper
INFO - 2018-06-20 13:21:33 --> Helper loaded: form_helper
INFO - 2018-06-20 13:21:33 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:21:33 --> User Agent Class Initialized
INFO - 2018-06-20 13:21:33 --> Controller Class Initialized
INFO - 2018-06-20 13:21:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:21:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:21:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:21:33 --> Final output sent to browser
DEBUG - 2018-06-20 13:21:33 --> Total execution time: 0.0914
INFO - 2018-06-20 13:21:40 --> Config Class Initialized
INFO - 2018-06-20 13:21:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:21:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:21:40 --> Utf8 Class Initialized
INFO - 2018-06-20 13:21:40 --> URI Class Initialized
INFO - 2018-06-20 13:21:40 --> Router Class Initialized
INFO - 2018-06-20 13:21:40 --> Output Class Initialized
INFO - 2018-06-20 13:21:40 --> Security Class Initialized
DEBUG - 2018-06-20 13:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:21:40 --> CSRF cookie sent
INFO - 2018-06-20 13:21:40 --> Input Class Initialized
INFO - 2018-06-20 13:21:40 --> Language Class Initialized
INFO - 2018-06-20 13:21:40 --> Loader Class Initialized
INFO - 2018-06-20 13:21:40 --> Helper loaded: url_helper
INFO - 2018-06-20 13:21:40 --> Helper loaded: form_helper
INFO - 2018-06-20 13:21:40 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:21:40 --> User Agent Class Initialized
INFO - 2018-06-20 13:21:40 --> Controller Class Initialized
INFO - 2018-06-20 13:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:21:40 --> Final output sent to browser
DEBUG - 2018-06-20 13:21:40 --> Total execution time: 0.0654
INFO - 2018-06-20 13:21:40 --> Config Class Initialized
INFO - 2018-06-20 13:21:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:21:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:21:40 --> Utf8 Class Initialized
INFO - 2018-06-20 13:21:40 --> URI Class Initialized
INFO - 2018-06-20 13:21:40 --> Router Class Initialized
INFO - 2018-06-20 13:21:40 --> Output Class Initialized
INFO - 2018-06-20 13:21:40 --> Security Class Initialized
DEBUG - 2018-06-20 13:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:21:40 --> CSRF cookie sent
INFO - 2018-06-20 13:21:40 --> Input Class Initialized
INFO - 2018-06-20 13:21:40 --> Language Class Initialized
INFO - 2018-06-20 13:21:40 --> Loader Class Initialized
INFO - 2018-06-20 13:21:40 --> Helper loaded: url_helper
INFO - 2018-06-20 13:21:40 --> Helper loaded: form_helper
INFO - 2018-06-20 13:21:40 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:21:40 --> User Agent Class Initialized
INFO - 2018-06-20 13:21:40 --> Controller Class Initialized
INFO - 2018-06-20 13:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:21:40 --> Final output sent to browser
DEBUG - 2018-06-20 13:21:40 --> Total execution time: 0.0361
INFO - 2018-06-20 13:21:41 --> Config Class Initialized
INFO - 2018-06-20 13:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:21:41 --> Utf8 Class Initialized
INFO - 2018-06-20 13:21:41 --> URI Class Initialized
INFO - 2018-06-20 13:21:41 --> Router Class Initialized
INFO - 2018-06-20 13:21:41 --> Output Class Initialized
INFO - 2018-06-20 13:21:41 --> Security Class Initialized
DEBUG - 2018-06-20 13:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:21:41 --> CSRF cookie sent
INFO - 2018-06-20 13:21:41 --> Input Class Initialized
INFO - 2018-06-20 13:21:41 --> Language Class Initialized
INFO - 2018-06-20 13:21:41 --> Loader Class Initialized
INFO - 2018-06-20 13:21:41 --> Helper loaded: url_helper
INFO - 2018-06-20 13:21:41 --> Helper loaded: form_helper
INFO - 2018-06-20 13:21:41 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:21:41 --> User Agent Class Initialized
INFO - 2018-06-20 13:21:41 --> Controller Class Initialized
INFO - 2018-06-20 13:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:21:41 --> Final output sent to browser
DEBUG - 2018-06-20 13:21:41 --> Total execution time: 0.0497
INFO - 2018-06-20 13:21:41 --> Config Class Initialized
INFO - 2018-06-20 13:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:21:41 --> Utf8 Class Initialized
INFO - 2018-06-20 13:21:41 --> URI Class Initialized
INFO - 2018-06-20 13:21:41 --> Router Class Initialized
INFO - 2018-06-20 13:21:41 --> Output Class Initialized
INFO - 2018-06-20 13:21:41 --> Security Class Initialized
DEBUG - 2018-06-20 13:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:21:41 --> CSRF cookie sent
INFO - 2018-06-20 13:21:41 --> Input Class Initialized
INFO - 2018-06-20 13:21:41 --> Language Class Initialized
INFO - 2018-06-20 13:21:41 --> Loader Class Initialized
INFO - 2018-06-20 13:21:41 --> Helper loaded: url_helper
INFO - 2018-06-20 13:21:41 --> Helper loaded: form_helper
INFO - 2018-06-20 13:21:41 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:21:41 --> User Agent Class Initialized
INFO - 2018-06-20 13:21:41 --> Controller Class Initialized
INFO - 2018-06-20 13:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:21:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:21:41 --> Final output sent to browser
DEBUG - 2018-06-20 13:21:41 --> Total execution time: 0.0427
INFO - 2018-06-20 13:45:16 --> Config Class Initialized
INFO - 2018-06-20 13:45:16 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:45:16 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:45:16 --> Utf8 Class Initialized
INFO - 2018-06-20 13:45:16 --> URI Class Initialized
INFO - 2018-06-20 13:45:16 --> Router Class Initialized
INFO - 2018-06-20 13:45:16 --> Output Class Initialized
INFO - 2018-06-20 13:45:16 --> Security Class Initialized
DEBUG - 2018-06-20 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:45:16 --> CSRF cookie sent
INFO - 2018-06-20 13:45:16 --> Input Class Initialized
INFO - 2018-06-20 13:45:16 --> Language Class Initialized
INFO - 2018-06-20 13:45:16 --> Loader Class Initialized
INFO - 2018-06-20 13:45:16 --> Helper loaded: url_helper
INFO - 2018-06-20 13:45:16 --> Helper loaded: form_helper
INFO - 2018-06-20 13:45:16 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:45:16 --> User Agent Class Initialized
INFO - 2018-06-20 13:45:16 --> Controller Class Initialized
INFO - 2018-06-20 13:45:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:45:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:45:16 --> Final output sent to browser
DEBUG - 2018-06-20 13:45:16 --> Total execution time: 0.0440
INFO - 2018-06-20 13:45:26 --> Config Class Initialized
INFO - 2018-06-20 13:45:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 13:45:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 13:45:26 --> Utf8 Class Initialized
INFO - 2018-06-20 13:45:26 --> URI Class Initialized
INFO - 2018-06-20 13:45:26 --> Router Class Initialized
INFO - 2018-06-20 13:45:26 --> Output Class Initialized
INFO - 2018-06-20 13:45:26 --> Security Class Initialized
DEBUG - 2018-06-20 13:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 13:45:26 --> CSRF cookie sent
INFO - 2018-06-20 13:45:26 --> Input Class Initialized
INFO - 2018-06-20 13:45:26 --> Language Class Initialized
INFO - 2018-06-20 13:45:26 --> Loader Class Initialized
INFO - 2018-06-20 13:45:26 --> Helper loaded: url_helper
INFO - 2018-06-20 13:45:26 --> Helper loaded: form_helper
INFO - 2018-06-20 13:45:26 --> Helper loaded: language_helper
DEBUG - 2018-06-20 13:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 13:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 13:45:26 --> User Agent Class Initialized
INFO - 2018-06-20 13:45:26 --> Controller Class Initialized
INFO - 2018-06-20 13:45:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 13:45:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 13:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 13:45:26 --> Final output sent to browser
DEBUG - 2018-06-20 13:45:26 --> Total execution time: 0.0400
INFO - 2018-06-20 14:38:10 --> Config Class Initialized
INFO - 2018-06-20 14:38:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 14:38:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 14:38:10 --> Utf8 Class Initialized
INFO - 2018-06-20 14:38:10 --> URI Class Initialized
DEBUG - 2018-06-20 14:38:10 --> No URI present. Default controller set.
INFO - 2018-06-20 14:38:10 --> Router Class Initialized
INFO - 2018-06-20 14:38:10 --> Output Class Initialized
INFO - 2018-06-20 14:38:10 --> Security Class Initialized
DEBUG - 2018-06-20 14:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 14:38:10 --> CSRF cookie sent
INFO - 2018-06-20 14:38:10 --> Input Class Initialized
INFO - 2018-06-20 14:38:10 --> Language Class Initialized
INFO - 2018-06-20 14:38:10 --> Loader Class Initialized
INFO - 2018-06-20 14:38:10 --> Helper loaded: url_helper
INFO - 2018-06-20 14:38:10 --> Helper loaded: form_helper
INFO - 2018-06-20 14:38:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 14:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 14:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 14:38:10 --> User Agent Class Initialized
INFO - 2018-06-20 14:38:10 --> Controller Class Initialized
INFO - 2018-06-20 14:38:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 14:38:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 14:38:10 --> Pixel_Model class loaded
INFO - 2018-06-20 14:38:10 --> Database Driver Class Initialized
INFO - 2018-06-20 14:38:10 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 14:38:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 14:38:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 14:38:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 14:38:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 14:38:10 --> Final output sent to browser
DEBUG - 2018-06-20 14:38:10 --> Total execution time: 0.0826
INFO - 2018-06-20 15:11:43 --> Config Class Initialized
INFO - 2018-06-20 15:11:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:11:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:11:43 --> Utf8 Class Initialized
INFO - 2018-06-20 15:11:43 --> URI Class Initialized
DEBUG - 2018-06-20 15:11:43 --> No URI present. Default controller set.
INFO - 2018-06-20 15:11:43 --> Router Class Initialized
INFO - 2018-06-20 15:11:43 --> Output Class Initialized
INFO - 2018-06-20 15:11:43 --> Security Class Initialized
DEBUG - 2018-06-20 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:11:43 --> CSRF cookie sent
INFO - 2018-06-20 15:11:43 --> Input Class Initialized
INFO - 2018-06-20 15:11:43 --> Language Class Initialized
INFO - 2018-06-20 15:11:43 --> Loader Class Initialized
INFO - 2018-06-20 15:11:43 --> Helper loaded: url_helper
INFO - 2018-06-20 15:11:43 --> Helper loaded: form_helper
INFO - 2018-06-20 15:11:43 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:11:43 --> User Agent Class Initialized
INFO - 2018-06-20 15:11:43 --> Controller Class Initialized
INFO - 2018-06-20 15:11:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:11:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:11:43 --> Pixel_Model class loaded
INFO - 2018-06-20 15:11:43 --> Database Driver Class Initialized
INFO - 2018-06-20 15:11:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 15:11:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:11:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:11:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 15:11:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:11:43 --> Final output sent to browser
DEBUG - 2018-06-20 15:11:43 --> Total execution time: 0.0553
INFO - 2018-06-20 15:12:00 --> Config Class Initialized
INFO - 2018-06-20 15:12:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:12:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:12:00 --> Utf8 Class Initialized
INFO - 2018-06-20 15:12:00 --> URI Class Initialized
INFO - 2018-06-20 15:12:00 --> Router Class Initialized
INFO - 2018-06-20 15:12:00 --> Output Class Initialized
INFO - 2018-06-20 15:12:00 --> Security Class Initialized
DEBUG - 2018-06-20 15:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:12:00 --> CSRF cookie sent
INFO - 2018-06-20 15:12:00 --> Input Class Initialized
INFO - 2018-06-20 15:12:00 --> Language Class Initialized
INFO - 2018-06-20 15:12:00 --> Loader Class Initialized
INFO - 2018-06-20 15:12:00 --> Helper loaded: url_helper
INFO - 2018-06-20 15:12:00 --> Helper loaded: form_helper
INFO - 2018-06-20 15:12:00 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:12:00 --> User Agent Class Initialized
INFO - 2018-06-20 15:12:00 --> Controller Class Initialized
INFO - 2018-06-20 15:12:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:12:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 15:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:12:00 --> Final output sent to browser
DEBUG - 2018-06-20 15:12:00 --> Total execution time: 0.0913
INFO - 2018-06-20 15:12:31 --> Config Class Initialized
INFO - 2018-06-20 15:12:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:12:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:12:31 --> Utf8 Class Initialized
INFO - 2018-06-20 15:12:31 --> URI Class Initialized
INFO - 2018-06-20 15:12:31 --> Router Class Initialized
INFO - 2018-06-20 15:12:31 --> Output Class Initialized
INFO - 2018-06-20 15:12:31 --> Security Class Initialized
DEBUG - 2018-06-20 15:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:12:31 --> CSRF cookie sent
INFO - 2018-06-20 15:12:31 --> Input Class Initialized
INFO - 2018-06-20 15:12:31 --> Language Class Initialized
INFO - 2018-06-20 15:12:31 --> Loader Class Initialized
INFO - 2018-06-20 15:12:31 --> Helper loaded: url_helper
INFO - 2018-06-20 15:12:31 --> Helper loaded: form_helper
INFO - 2018-06-20 15:12:31 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:12:31 --> User Agent Class Initialized
INFO - 2018-06-20 15:12:31 --> Controller Class Initialized
INFO - 2018-06-20 15:12:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:12:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 15:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:12:31 --> Final output sent to browser
DEBUG - 2018-06-20 15:12:31 --> Total execution time: 0.0617
INFO - 2018-06-20 15:13:59 --> Config Class Initialized
INFO - 2018-06-20 15:13:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:13:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:13:59 --> Utf8 Class Initialized
INFO - 2018-06-20 15:13:59 --> URI Class Initialized
INFO - 2018-06-20 15:13:59 --> Router Class Initialized
INFO - 2018-06-20 15:13:59 --> Output Class Initialized
INFO - 2018-06-20 15:13:59 --> Security Class Initialized
DEBUG - 2018-06-20 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:13:59 --> CSRF cookie sent
INFO - 2018-06-20 15:13:59 --> Input Class Initialized
INFO - 2018-06-20 15:13:59 --> Language Class Initialized
INFO - 2018-06-20 15:13:59 --> Loader Class Initialized
INFO - 2018-06-20 15:13:59 --> Helper loaded: url_helper
INFO - 2018-06-20 15:13:59 --> Helper loaded: form_helper
INFO - 2018-06-20 15:13:59 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:13:59 --> User Agent Class Initialized
INFO - 2018-06-20 15:13:59 --> Controller Class Initialized
INFO - 2018-06-20 15:13:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:13:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:13:59 --> Final output sent to browser
DEBUG - 2018-06-20 15:13:59 --> Total execution time: 0.0385
INFO - 2018-06-20 15:15:21 --> Config Class Initialized
INFO - 2018-06-20 15:15:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:15:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:15:21 --> Utf8 Class Initialized
INFO - 2018-06-20 15:15:21 --> URI Class Initialized
INFO - 2018-06-20 15:15:21 --> Router Class Initialized
INFO - 2018-06-20 15:15:21 --> Output Class Initialized
INFO - 2018-06-20 15:15:21 --> Security Class Initialized
DEBUG - 2018-06-20 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:15:21 --> CSRF cookie sent
INFO - 2018-06-20 15:15:21 --> Input Class Initialized
INFO - 2018-06-20 15:15:21 --> Language Class Initialized
INFO - 2018-06-20 15:15:21 --> Loader Class Initialized
INFO - 2018-06-20 15:15:21 --> Helper loaded: url_helper
INFO - 2018-06-20 15:15:21 --> Helper loaded: form_helper
INFO - 2018-06-20 15:15:21 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:15:21 --> User Agent Class Initialized
INFO - 2018-06-20 15:15:21 --> Controller Class Initialized
INFO - 2018-06-20 15:15:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:15:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 15:15:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:15:21 --> Final output sent to browser
DEBUG - 2018-06-20 15:15:21 --> Total execution time: 0.0603
INFO - 2018-06-20 15:15:24 --> Config Class Initialized
INFO - 2018-06-20 15:15:24 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:15:24 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:15:24 --> Utf8 Class Initialized
INFO - 2018-06-20 15:15:24 --> URI Class Initialized
INFO - 2018-06-20 15:15:24 --> Router Class Initialized
INFO - 2018-06-20 15:15:24 --> Output Class Initialized
INFO - 2018-06-20 15:15:24 --> Security Class Initialized
DEBUG - 2018-06-20 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:15:24 --> CSRF cookie sent
INFO - 2018-06-20 15:15:24 --> Input Class Initialized
INFO - 2018-06-20 15:15:24 --> Language Class Initialized
INFO - 2018-06-20 15:15:24 --> Loader Class Initialized
INFO - 2018-06-20 15:15:24 --> Helper loaded: url_helper
INFO - 2018-06-20 15:15:24 --> Helper loaded: form_helper
INFO - 2018-06-20 15:15:24 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:15:24 --> User Agent Class Initialized
INFO - 2018-06-20 15:15:24 --> Controller Class Initialized
INFO - 2018-06-20 15:15:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:15:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 15:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:15:24 --> Final output sent to browser
DEBUG - 2018-06-20 15:15:24 --> Total execution time: 0.0475
INFO - 2018-06-20 15:15:27 --> Config Class Initialized
INFO - 2018-06-20 15:15:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:15:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:15:27 --> Utf8 Class Initialized
INFO - 2018-06-20 15:15:27 --> URI Class Initialized
INFO - 2018-06-20 15:15:27 --> Router Class Initialized
INFO - 2018-06-20 15:15:27 --> Output Class Initialized
INFO - 2018-06-20 15:15:27 --> Security Class Initialized
DEBUG - 2018-06-20 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:15:27 --> CSRF cookie sent
INFO - 2018-06-20 15:15:27 --> Input Class Initialized
INFO - 2018-06-20 15:15:27 --> Language Class Initialized
INFO - 2018-06-20 15:15:27 --> Loader Class Initialized
INFO - 2018-06-20 15:15:27 --> Helper loaded: url_helper
INFO - 2018-06-20 15:15:27 --> Helper loaded: form_helper
INFO - 2018-06-20 15:15:27 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:15:27 --> User Agent Class Initialized
INFO - 2018-06-20 15:15:27 --> Controller Class Initialized
INFO - 2018-06-20 15:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-20 15:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:15:27 --> Final output sent to browser
DEBUG - 2018-06-20 15:15:27 --> Total execution time: 0.0482
INFO - 2018-06-20 15:15:28 --> Config Class Initialized
INFO - 2018-06-20 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:15:28 --> Utf8 Class Initialized
INFO - 2018-06-20 15:15:28 --> URI Class Initialized
INFO - 2018-06-20 15:15:28 --> Router Class Initialized
INFO - 2018-06-20 15:15:28 --> Output Class Initialized
INFO - 2018-06-20 15:15:28 --> Security Class Initialized
DEBUG - 2018-06-20 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:15:28 --> CSRF cookie sent
INFO - 2018-06-20 15:15:28 --> Input Class Initialized
INFO - 2018-06-20 15:15:28 --> Language Class Initialized
INFO - 2018-06-20 15:15:28 --> Loader Class Initialized
INFO - 2018-06-20 15:15:28 --> Helper loaded: url_helper
INFO - 2018-06-20 15:15:28 --> Helper loaded: form_helper
INFO - 2018-06-20 15:15:28 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:15:28 --> User Agent Class Initialized
INFO - 2018-06-20 15:15:28 --> Controller Class Initialized
INFO - 2018-06-20 15:15:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:15:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:15:28 --> Final output sent to browser
DEBUG - 2018-06-20 15:15:28 --> Total execution time: 0.0718
INFO - 2018-06-20 15:15:30 --> Config Class Initialized
INFO - 2018-06-20 15:15:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 15:15:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 15:15:30 --> Utf8 Class Initialized
INFO - 2018-06-20 15:15:30 --> URI Class Initialized
DEBUG - 2018-06-20 15:15:30 --> No URI present. Default controller set.
INFO - 2018-06-20 15:15:30 --> Router Class Initialized
INFO - 2018-06-20 15:15:30 --> Output Class Initialized
INFO - 2018-06-20 15:15:30 --> Security Class Initialized
DEBUG - 2018-06-20 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 15:15:30 --> CSRF cookie sent
INFO - 2018-06-20 15:15:30 --> Input Class Initialized
INFO - 2018-06-20 15:15:30 --> Language Class Initialized
INFO - 2018-06-20 15:15:30 --> Loader Class Initialized
INFO - 2018-06-20 15:15:30 --> Helper loaded: url_helper
INFO - 2018-06-20 15:15:30 --> Helper loaded: form_helper
INFO - 2018-06-20 15:15:30 --> Helper loaded: language_helper
DEBUG - 2018-06-20 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 15:15:30 --> User Agent Class Initialized
INFO - 2018-06-20 15:15:30 --> Controller Class Initialized
INFO - 2018-06-20 15:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 15:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 15:15:30 --> Pixel_Model class loaded
INFO - 2018-06-20 15:15:30 --> Database Driver Class Initialized
INFO - 2018-06-20 15:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 15:15:30 --> Final output sent to browser
DEBUG - 2018-06-20 15:15:30 --> Total execution time: 0.0592
INFO - 2018-06-20 16:46:03 --> Config Class Initialized
INFO - 2018-06-20 16:46:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 16:46:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 16:46:03 --> Utf8 Class Initialized
INFO - 2018-06-20 16:46:03 --> URI Class Initialized
DEBUG - 2018-06-20 16:46:03 --> No URI present. Default controller set.
INFO - 2018-06-20 16:46:03 --> Router Class Initialized
INFO - 2018-06-20 16:46:03 --> Output Class Initialized
INFO - 2018-06-20 16:46:03 --> Security Class Initialized
DEBUG - 2018-06-20 16:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 16:46:03 --> CSRF cookie sent
INFO - 2018-06-20 16:46:03 --> Input Class Initialized
INFO - 2018-06-20 16:46:03 --> Language Class Initialized
INFO - 2018-06-20 16:46:03 --> Loader Class Initialized
INFO - 2018-06-20 16:46:03 --> Helper loaded: url_helper
INFO - 2018-06-20 16:46:03 --> Helper loaded: form_helper
INFO - 2018-06-20 16:46:03 --> Helper loaded: language_helper
DEBUG - 2018-06-20 16:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 16:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 16:46:03 --> User Agent Class Initialized
INFO - 2018-06-20 16:46:03 --> Controller Class Initialized
INFO - 2018-06-20 16:46:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 16:46:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 16:46:03 --> Pixel_Model class loaded
INFO - 2018-06-20 16:46:03 --> Database Driver Class Initialized
INFO - 2018-06-20 16:46:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 16:46:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 16:46:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 16:46:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 16:46:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 16:46:03 --> Final output sent to browser
DEBUG - 2018-06-20 16:46:03 --> Total execution time: 0.0482
INFO - 2018-06-20 17:03:59 --> Config Class Initialized
INFO - 2018-06-20 17:03:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:03:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:03:59 --> Utf8 Class Initialized
INFO - 2018-06-20 17:03:59 --> URI Class Initialized
DEBUG - 2018-06-20 17:03:59 --> No URI present. Default controller set.
INFO - 2018-06-20 17:03:59 --> Router Class Initialized
INFO - 2018-06-20 17:03:59 --> Output Class Initialized
INFO - 2018-06-20 17:03:59 --> Security Class Initialized
DEBUG - 2018-06-20 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:03:59 --> CSRF cookie sent
INFO - 2018-06-20 17:03:59 --> Input Class Initialized
INFO - 2018-06-20 17:03:59 --> Language Class Initialized
INFO - 2018-06-20 17:03:59 --> Loader Class Initialized
INFO - 2018-06-20 17:03:59 --> Helper loaded: url_helper
INFO - 2018-06-20 17:03:59 --> Helper loaded: form_helper
INFO - 2018-06-20 17:03:59 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:03:59 --> User Agent Class Initialized
INFO - 2018-06-20 17:03:59 --> Controller Class Initialized
INFO - 2018-06-20 17:03:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:03:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:03:59 --> Pixel_Model class loaded
INFO - 2018-06-20 17:03:59 --> Database Driver Class Initialized
INFO - 2018-06-20 17:03:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 17:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:03:59 --> Final output sent to browser
DEBUG - 2018-06-20 17:03:59 --> Total execution time: 0.0574
INFO - 2018-06-20 17:04:00 --> Config Class Initialized
INFO - 2018-06-20 17:04:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:00 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:00 --> URI Class Initialized
DEBUG - 2018-06-20 17:04:00 --> No URI present. Default controller set.
INFO - 2018-06-20 17:04:00 --> Router Class Initialized
INFO - 2018-06-20 17:04:00 --> Output Class Initialized
INFO - 2018-06-20 17:04:00 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:00 --> CSRF cookie sent
INFO - 2018-06-20 17:04:00 --> Input Class Initialized
INFO - 2018-06-20 17:04:00 --> Language Class Initialized
INFO - 2018-06-20 17:04:00 --> Loader Class Initialized
INFO - 2018-06-20 17:04:00 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:00 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:00 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:00 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:00 --> Controller Class Initialized
INFO - 2018-06-20 17:04:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:00 --> Pixel_Model class loaded
INFO - 2018-06-20 17:04:00 --> Database Driver Class Initialized
INFO - 2018-06-20 17:04:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:00 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:00 --> Total execution time: 0.0717
INFO - 2018-06-20 17:04:00 --> Config Class Initialized
INFO - 2018-06-20 17:04:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:00 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:00 --> URI Class Initialized
DEBUG - 2018-06-20 17:04:00 --> No URI present. Default controller set.
INFO - 2018-06-20 17:04:00 --> Router Class Initialized
INFO - 2018-06-20 17:04:00 --> Output Class Initialized
INFO - 2018-06-20 17:04:00 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:00 --> CSRF cookie sent
INFO - 2018-06-20 17:04:00 --> Input Class Initialized
INFO - 2018-06-20 17:04:00 --> Language Class Initialized
INFO - 2018-06-20 17:04:00 --> Loader Class Initialized
INFO - 2018-06-20 17:04:00 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:00 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:00 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:00 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:00 --> Controller Class Initialized
INFO - 2018-06-20 17:04:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:00 --> Pixel_Model class loaded
INFO - 2018-06-20 17:04:00 --> Database Driver Class Initialized
INFO - 2018-06-20 17:04:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 17:04:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:00 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:00 --> Total execution time: 0.0555
INFO - 2018-06-20 17:04:01 --> Config Class Initialized
INFO - 2018-06-20 17:04:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:01 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:01 --> URI Class Initialized
INFO - 2018-06-20 17:04:01 --> Router Class Initialized
INFO - 2018-06-20 17:04:01 --> Output Class Initialized
INFO - 2018-06-20 17:04:01 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:01 --> CSRF cookie sent
INFO - 2018-06-20 17:04:01 --> Input Class Initialized
INFO - 2018-06-20 17:04:01 --> Language Class Initialized
ERROR - 2018-06-20 17:04:01 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-20 17:04:08 --> Config Class Initialized
INFO - 2018-06-20 17:04:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:08 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:08 --> URI Class Initialized
DEBUG - 2018-06-20 17:04:08 --> No URI present. Default controller set.
INFO - 2018-06-20 17:04:08 --> Router Class Initialized
INFO - 2018-06-20 17:04:08 --> Output Class Initialized
INFO - 2018-06-20 17:04:08 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:08 --> CSRF cookie sent
INFO - 2018-06-20 17:04:08 --> Input Class Initialized
INFO - 2018-06-20 17:04:08 --> Language Class Initialized
INFO - 2018-06-20 17:04:08 --> Loader Class Initialized
INFO - 2018-06-20 17:04:08 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:08 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:08 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:08 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:08 --> Controller Class Initialized
INFO - 2018-06-20 17:04:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:08 --> Pixel_Model class loaded
INFO - 2018-06-20 17:04:08 --> Database Driver Class Initialized
INFO - 2018-06-20 17:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 17:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:08 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:08 --> Total execution time: 0.0660
INFO - 2018-06-20 17:04:08 --> Config Class Initialized
INFO - 2018-06-20 17:04:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:08 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:08 --> URI Class Initialized
INFO - 2018-06-20 17:04:08 --> Router Class Initialized
INFO - 2018-06-20 17:04:08 --> Output Class Initialized
INFO - 2018-06-20 17:04:08 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:08 --> CSRF cookie sent
INFO - 2018-06-20 17:04:08 --> Input Class Initialized
INFO - 2018-06-20 17:04:08 --> Language Class Initialized
ERROR - 2018-06-20 17:04:08 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-20 17:04:09 --> Config Class Initialized
INFO - 2018-06-20 17:04:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:09 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:09 --> URI Class Initialized
INFO - 2018-06-20 17:04:09 --> Router Class Initialized
INFO - 2018-06-20 17:04:09 --> Output Class Initialized
INFO - 2018-06-20 17:04:09 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:09 --> CSRF cookie sent
INFO - 2018-06-20 17:04:09 --> Input Class Initialized
INFO - 2018-06-20 17:04:09 --> Language Class Initialized
ERROR - 2018-06-20 17:04:09 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-20 17:04:09 --> Config Class Initialized
INFO - 2018-06-20 17:04:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:09 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:09 --> URI Class Initialized
INFO - 2018-06-20 17:04:09 --> Router Class Initialized
INFO - 2018-06-20 17:04:09 --> Output Class Initialized
INFO - 2018-06-20 17:04:09 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:09 --> CSRF cookie sent
INFO - 2018-06-20 17:04:09 --> Input Class Initialized
INFO - 2018-06-20 17:04:09 --> Language Class Initialized
INFO - 2018-06-20 17:04:09 --> Loader Class Initialized
INFO - 2018-06-20 17:04:09 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:09 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:09 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:09 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:09 --> Controller Class Initialized
INFO - 2018-06-20 17:04:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:09 --> Pixel_Model class loaded
INFO - 2018-06-20 17:04:09 --> Database Driver Class Initialized
INFO - 2018-06-20 17:04:09 --> Model "QuestionsModel" initialized
ERROR - 2018-06-20 17:04:09 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-20 17:04:09 --> Config Class Initialized
INFO - 2018-06-20 17:04:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:09 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:09 --> URI Class Initialized
INFO - 2018-06-20 17:04:09 --> Router Class Initialized
INFO - 2018-06-20 17:04:09 --> Output Class Initialized
INFO - 2018-06-20 17:04:09 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:09 --> CSRF cookie sent
INFO - 2018-06-20 17:04:09 --> Input Class Initialized
INFO - 2018-06-20 17:04:09 --> Language Class Initialized
INFO - 2018-06-20 17:04:09 --> Loader Class Initialized
INFO - 2018-06-20 17:04:09 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:09 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:09 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:09 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:09 --> Controller Class Initialized
INFO - 2018-06-20 17:04:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-20 17:04:09 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-20 17:04:09 --> Could not find the language line "req_email"
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-20 17:04:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:09 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:09 --> Total execution time: 0.0393
INFO - 2018-06-20 17:04:10 --> Config Class Initialized
INFO - 2018-06-20 17:04:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:10 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:10 --> URI Class Initialized
INFO - 2018-06-20 17:04:10 --> Router Class Initialized
INFO - 2018-06-20 17:04:10 --> Output Class Initialized
INFO - 2018-06-20 17:04:10 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:10 --> CSRF cookie sent
INFO - 2018-06-20 17:04:10 --> Input Class Initialized
INFO - 2018-06-20 17:04:10 --> Language Class Initialized
INFO - 2018-06-20 17:04:10 --> Loader Class Initialized
INFO - 2018-06-20 17:04:10 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:10 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:10 --> Controller Class Initialized
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:10 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:10 --> Total execution time: 0.0371
INFO - 2018-06-20 17:04:10 --> Config Class Initialized
INFO - 2018-06-20 17:04:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:10 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:10 --> URI Class Initialized
INFO - 2018-06-20 17:04:10 --> Router Class Initialized
INFO - 2018-06-20 17:04:10 --> Output Class Initialized
INFO - 2018-06-20 17:04:10 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:10 --> CSRF cookie sent
INFO - 2018-06-20 17:04:10 --> Input Class Initialized
INFO - 2018-06-20 17:04:10 --> Language Class Initialized
INFO - 2018-06-20 17:04:10 --> Loader Class Initialized
INFO - 2018-06-20 17:04:10 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:10 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:10 --> Controller Class Initialized
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:10 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:10 --> Total execution time: 0.0544
INFO - 2018-06-20 17:04:10 --> Config Class Initialized
INFO - 2018-06-20 17:04:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:10 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:10 --> URI Class Initialized
INFO - 2018-06-20 17:04:10 --> Router Class Initialized
INFO - 2018-06-20 17:04:10 --> Output Class Initialized
INFO - 2018-06-20 17:04:10 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:10 --> CSRF cookie sent
INFO - 2018-06-20 17:04:10 --> Input Class Initialized
INFO - 2018-06-20 17:04:10 --> Language Class Initialized
INFO - 2018-06-20 17:04:10 --> Loader Class Initialized
INFO - 2018-06-20 17:04:10 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:10 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:10 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:10 --> Controller Class Initialized
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-20 17:04:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:10 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:10 --> Total execution time: 0.0413
INFO - 2018-06-20 17:04:11 --> Config Class Initialized
INFO - 2018-06-20 17:04:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:11 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:11 --> URI Class Initialized
INFO - 2018-06-20 17:04:11 --> Router Class Initialized
INFO - 2018-06-20 17:04:11 --> Output Class Initialized
INFO - 2018-06-20 17:04:11 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:11 --> CSRF cookie sent
INFO - 2018-06-20 17:04:11 --> Input Class Initialized
INFO - 2018-06-20 17:04:11 --> Language Class Initialized
INFO - 2018-06-20 17:04:11 --> Loader Class Initialized
INFO - 2018-06-20 17:04:11 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:11 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:11 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:11 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:11 --> Controller Class Initialized
INFO - 2018-06-20 17:04:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:11 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:11 --> Total execution time: 0.0338
INFO - 2018-06-20 17:04:11 --> Config Class Initialized
INFO - 2018-06-20 17:04:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:11 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:11 --> URI Class Initialized
INFO - 2018-06-20 17:04:11 --> Router Class Initialized
INFO - 2018-06-20 17:04:11 --> Output Class Initialized
INFO - 2018-06-20 17:04:11 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:11 --> CSRF cookie sent
INFO - 2018-06-20 17:04:11 --> Input Class Initialized
INFO - 2018-06-20 17:04:11 --> Language Class Initialized
INFO - 2018-06-20 17:04:11 --> Loader Class Initialized
INFO - 2018-06-20 17:04:11 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:11 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:11 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:11 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:11 --> Controller Class Initialized
INFO - 2018-06-20 17:04:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-20 17:04:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-20 17:04:11 --> Could not find the language line "req_email"
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-20 17:04:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:11 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:11 --> Total execution time: 0.0327
INFO - 2018-06-20 17:04:12 --> Config Class Initialized
INFO - 2018-06-20 17:04:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:04:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:04:12 --> Utf8 Class Initialized
INFO - 2018-06-20 17:04:12 --> URI Class Initialized
INFO - 2018-06-20 17:04:12 --> Router Class Initialized
INFO - 2018-06-20 17:04:12 --> Output Class Initialized
INFO - 2018-06-20 17:04:12 --> Security Class Initialized
DEBUG - 2018-06-20 17:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:04:12 --> CSRF cookie sent
INFO - 2018-06-20 17:04:12 --> Input Class Initialized
INFO - 2018-06-20 17:04:12 --> Language Class Initialized
INFO - 2018-06-20 17:04:12 --> Loader Class Initialized
INFO - 2018-06-20 17:04:12 --> Helper loaded: url_helper
INFO - 2018-06-20 17:04:12 --> Helper loaded: form_helper
INFO - 2018-06-20 17:04:12 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:04:12 --> User Agent Class Initialized
INFO - 2018-06-20 17:04:12 --> Controller Class Initialized
INFO - 2018-06-20 17:04:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:04:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-20 17:04:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:04:12 --> Final output sent to browser
DEBUG - 2018-06-20 17:04:12 --> Total execution time: 0.0339
INFO - 2018-06-20 17:36:12 --> Config Class Initialized
INFO - 2018-06-20 17:36:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:36:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:36:12 --> Utf8 Class Initialized
INFO - 2018-06-20 17:36:12 --> URI Class Initialized
DEBUG - 2018-06-20 17:36:12 --> No URI present. Default controller set.
INFO - 2018-06-20 17:36:12 --> Router Class Initialized
INFO - 2018-06-20 17:36:12 --> Output Class Initialized
INFO - 2018-06-20 17:36:12 --> Security Class Initialized
DEBUG - 2018-06-20 17:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:36:12 --> CSRF cookie sent
INFO - 2018-06-20 17:36:12 --> Input Class Initialized
INFO - 2018-06-20 17:36:12 --> Language Class Initialized
INFO - 2018-06-20 17:36:12 --> Loader Class Initialized
INFO - 2018-06-20 17:36:12 --> Helper loaded: url_helper
INFO - 2018-06-20 17:36:12 --> Helper loaded: form_helper
INFO - 2018-06-20 17:36:12 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:36:12 --> User Agent Class Initialized
INFO - 2018-06-20 17:36:12 --> Controller Class Initialized
INFO - 2018-06-20 17:36:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:36:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:36:12 --> Pixel_Model class loaded
INFO - 2018-06-20 17:36:12 --> Database Driver Class Initialized
INFO - 2018-06-20 17:36:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:36:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:36:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:36:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 17:36:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:36:12 --> Final output sent to browser
DEBUG - 2018-06-20 17:36:12 --> Total execution time: 0.0599
INFO - 2018-06-20 17:36:23 --> Config Class Initialized
INFO - 2018-06-20 17:36:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:36:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:36:23 --> Utf8 Class Initialized
INFO - 2018-06-20 17:36:23 --> URI Class Initialized
INFO - 2018-06-20 17:36:23 --> Router Class Initialized
INFO - 2018-06-20 17:36:23 --> Output Class Initialized
INFO - 2018-06-20 17:36:23 --> Security Class Initialized
DEBUG - 2018-06-20 17:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:36:23 --> CSRF cookie sent
INFO - 2018-06-20 17:36:23 --> Input Class Initialized
INFO - 2018-06-20 17:36:23 --> Language Class Initialized
INFO - 2018-06-20 17:36:23 --> Loader Class Initialized
INFO - 2018-06-20 17:36:23 --> Helper loaded: url_helper
INFO - 2018-06-20 17:36:23 --> Helper loaded: form_helper
INFO - 2018-06-20 17:36:23 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:36:23 --> User Agent Class Initialized
INFO - 2018-06-20 17:36:23 --> Controller Class Initialized
INFO - 2018-06-20 17:36:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:36:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:36:23 --> Pixel_Model class loaded
INFO - 2018-06-20 17:36:23 --> Database Driver Class Initialized
INFO - 2018-06-20 17:36:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 17:36:23 --> Config Class Initialized
INFO - 2018-06-20 17:36:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:36:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:36:23 --> Utf8 Class Initialized
INFO - 2018-06-20 17:36:23 --> URI Class Initialized
INFO - 2018-06-20 17:36:23 --> Router Class Initialized
INFO - 2018-06-20 17:36:23 --> Output Class Initialized
INFO - 2018-06-20 17:36:23 --> Security Class Initialized
DEBUG - 2018-06-20 17:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:36:23 --> CSRF cookie sent
INFO - 2018-06-20 17:36:23 --> Input Class Initialized
INFO - 2018-06-20 17:36:23 --> Language Class Initialized
INFO - 2018-06-20 17:36:23 --> Loader Class Initialized
INFO - 2018-06-20 17:36:23 --> Helper loaded: url_helper
INFO - 2018-06-20 17:36:23 --> Helper loaded: form_helper
INFO - 2018-06-20 17:36:23 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:36:23 --> User Agent Class Initialized
INFO - 2018-06-20 17:36:23 --> Controller Class Initialized
INFO - 2018-06-20 17:36:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:36:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-20 17:36:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-20 17:36:23 --> Could not find the language line "req_email"
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-20 17:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:36:23 --> Final output sent to browser
DEBUG - 2018-06-20 17:36:23 --> Total execution time: 0.0494
INFO - 2018-06-20 17:37:31 --> Config Class Initialized
INFO - 2018-06-20 17:37:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:37:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:37:31 --> Utf8 Class Initialized
INFO - 2018-06-20 17:37:31 --> URI Class Initialized
INFO - 2018-06-20 17:37:31 --> Router Class Initialized
INFO - 2018-06-20 17:37:31 --> Output Class Initialized
INFO - 2018-06-20 17:37:31 --> Security Class Initialized
DEBUG - 2018-06-20 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:37:31 --> CSRF cookie sent
INFO - 2018-06-20 17:37:31 --> Input Class Initialized
INFO - 2018-06-20 17:37:31 --> Language Class Initialized
INFO - 2018-06-20 17:37:31 --> Loader Class Initialized
INFO - 2018-06-20 17:37:31 --> Helper loaded: url_helper
INFO - 2018-06-20 17:37:31 --> Helper loaded: form_helper
INFO - 2018-06-20 17:37:31 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:37:31 --> User Agent Class Initialized
INFO - 2018-06-20 17:37:31 --> Controller Class Initialized
INFO - 2018-06-20 17:37:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:37:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-20 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:37:31 --> Final output sent to browser
DEBUG - 2018-06-20 17:37:31 --> Total execution time: 0.0685
INFO - 2018-06-20 17:37:45 --> Config Class Initialized
INFO - 2018-06-20 17:37:45 --> Hooks Class Initialized
DEBUG - 2018-06-20 17:37:45 --> UTF-8 Support Enabled
INFO - 2018-06-20 17:37:45 --> Utf8 Class Initialized
INFO - 2018-06-20 17:37:45 --> URI Class Initialized
INFO - 2018-06-20 17:37:45 --> Router Class Initialized
INFO - 2018-06-20 17:37:45 --> Output Class Initialized
INFO - 2018-06-20 17:37:45 --> Security Class Initialized
DEBUG - 2018-06-20 17:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 17:37:45 --> CSRF cookie sent
INFO - 2018-06-20 17:37:45 --> Input Class Initialized
INFO - 2018-06-20 17:37:45 --> Language Class Initialized
INFO - 2018-06-20 17:37:45 --> Loader Class Initialized
INFO - 2018-06-20 17:37:45 --> Helper loaded: url_helper
INFO - 2018-06-20 17:37:45 --> Helper loaded: form_helper
INFO - 2018-06-20 17:37:45 --> Helper loaded: language_helper
DEBUG - 2018-06-20 17:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 17:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 17:37:45 --> User Agent Class Initialized
INFO - 2018-06-20 17:37:45 --> Controller Class Initialized
INFO - 2018-06-20 17:37:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 17:37:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 17:37:45 --> Final output sent to browser
DEBUG - 2018-06-20 17:37:45 --> Total execution time: 0.0379
INFO - 2018-06-20 19:50:56 --> Config Class Initialized
INFO - 2018-06-20 19:50:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 19:50:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 19:50:56 --> Utf8 Class Initialized
INFO - 2018-06-20 19:50:56 --> URI Class Initialized
DEBUG - 2018-06-20 19:50:56 --> No URI present. Default controller set.
INFO - 2018-06-20 19:50:56 --> Router Class Initialized
INFO - 2018-06-20 19:50:56 --> Output Class Initialized
INFO - 2018-06-20 19:50:56 --> Security Class Initialized
DEBUG - 2018-06-20 19:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 19:50:56 --> CSRF cookie sent
INFO - 2018-06-20 19:50:56 --> Input Class Initialized
INFO - 2018-06-20 19:50:56 --> Language Class Initialized
INFO - 2018-06-20 19:50:56 --> Loader Class Initialized
INFO - 2018-06-20 19:50:56 --> Helper loaded: url_helper
INFO - 2018-06-20 19:50:56 --> Helper loaded: form_helper
INFO - 2018-06-20 19:50:56 --> Helper loaded: language_helper
DEBUG - 2018-06-20 19:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 19:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 19:50:56 --> User Agent Class Initialized
INFO - 2018-06-20 19:50:56 --> Controller Class Initialized
INFO - 2018-06-20 19:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 19:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 19:50:56 --> Pixel_Model class loaded
INFO - 2018-06-20 19:50:56 --> Database Driver Class Initialized
INFO - 2018-06-20 19:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 19:50:56 --> Final output sent to browser
DEBUG - 2018-06-20 19:50:56 --> Total execution time: 0.0514
INFO - 2018-06-20 21:38:21 --> Config Class Initialized
INFO - 2018-06-20 21:38:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:38:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:38:21 --> Utf8 Class Initialized
INFO - 2018-06-20 21:38:21 --> URI Class Initialized
INFO - 2018-06-20 21:38:21 --> Router Class Initialized
INFO - 2018-06-20 21:38:21 --> Output Class Initialized
INFO - 2018-06-20 21:38:21 --> Security Class Initialized
DEBUG - 2018-06-20 21:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:38:21 --> CSRF cookie sent
INFO - 2018-06-20 21:38:21 --> Input Class Initialized
INFO - 2018-06-20 21:38:21 --> Language Class Initialized
INFO - 2018-06-20 21:38:21 --> Loader Class Initialized
INFO - 2018-06-20 21:38:21 --> Helper loaded: url_helper
INFO - 2018-06-20 21:38:21 --> Helper loaded: form_helper
INFO - 2018-06-20 21:38:21 --> Helper loaded: language_helper
DEBUG - 2018-06-20 21:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:38:22 --> User Agent Class Initialized
INFO - 2018-06-20 21:38:22 --> Controller Class Initialized
INFO - 2018-06-20 21:38:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 21:38:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-20 21:38:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 21:38:22 --> Final output sent to browser
DEBUG - 2018-06-20 21:38:22 --> Total execution time: 0.0610
INFO - 2018-06-20 21:59:22 --> Config Class Initialized
INFO - 2018-06-20 21:59:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:59:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:59:22 --> Utf8 Class Initialized
INFO - 2018-06-20 21:59:22 --> URI Class Initialized
DEBUG - 2018-06-20 21:59:22 --> No URI present. Default controller set.
INFO - 2018-06-20 21:59:22 --> Router Class Initialized
INFO - 2018-06-20 21:59:22 --> Output Class Initialized
INFO - 2018-06-20 21:59:22 --> Security Class Initialized
DEBUG - 2018-06-20 21:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:59:22 --> CSRF cookie sent
INFO - 2018-06-20 21:59:22 --> Input Class Initialized
INFO - 2018-06-20 21:59:22 --> Language Class Initialized
INFO - 2018-06-20 21:59:22 --> Loader Class Initialized
INFO - 2018-06-20 21:59:22 --> Helper loaded: url_helper
INFO - 2018-06-20 21:59:22 --> Helper loaded: form_helper
INFO - 2018-06-20 21:59:22 --> Helper loaded: language_helper
DEBUG - 2018-06-20 21:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:59:22 --> User Agent Class Initialized
INFO - 2018-06-20 21:59:22 --> Controller Class Initialized
INFO - 2018-06-20 21:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 21:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 21:59:22 --> Pixel_Model class loaded
INFO - 2018-06-20 21:59:22 --> Database Driver Class Initialized
INFO - 2018-06-20 21:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 21:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 21:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 21:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 21:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 21:59:22 --> Final output sent to browser
DEBUG - 2018-06-20 21:59:22 --> Total execution time: 0.0564
INFO - 2018-06-20 22:01:18 --> Config Class Initialized
INFO - 2018-06-20 22:01:18 --> Hooks Class Initialized
DEBUG - 2018-06-20 22:01:18 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:01:18 --> Utf8 Class Initialized
INFO - 2018-06-20 22:01:18 --> URI Class Initialized
INFO - 2018-06-20 22:01:18 --> Router Class Initialized
INFO - 2018-06-20 22:01:18 --> Output Class Initialized
INFO - 2018-06-20 22:01:18 --> Security Class Initialized
DEBUG - 2018-06-20 22:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:01:18 --> CSRF cookie sent
INFO - 2018-06-20 22:01:18 --> Input Class Initialized
INFO - 2018-06-20 22:01:18 --> Language Class Initialized
INFO - 2018-06-20 22:01:18 --> Loader Class Initialized
INFO - 2018-06-20 22:01:18 --> Helper loaded: url_helper
INFO - 2018-06-20 22:01:18 --> Helper loaded: form_helper
INFO - 2018-06-20 22:01:18 --> Helper loaded: language_helper
DEBUG - 2018-06-20 22:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 22:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 22:01:18 --> User Agent Class Initialized
INFO - 2018-06-20 22:01:18 --> Controller Class Initialized
INFO - 2018-06-20 22:01:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 22:01:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-20 22:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 22:01:18 --> Final output sent to browser
DEBUG - 2018-06-20 22:01:18 --> Total execution time: 0.0443
INFO - 2018-06-20 22:01:27 --> Config Class Initialized
INFO - 2018-06-20 22:01:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 22:01:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:01:27 --> Utf8 Class Initialized
INFO - 2018-06-20 22:01:27 --> URI Class Initialized
DEBUG - 2018-06-20 22:01:27 --> No URI present. Default controller set.
INFO - 2018-06-20 22:01:27 --> Router Class Initialized
INFO - 2018-06-20 22:01:27 --> Output Class Initialized
INFO - 2018-06-20 22:01:27 --> Security Class Initialized
DEBUG - 2018-06-20 22:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:01:27 --> CSRF cookie sent
INFO - 2018-06-20 22:01:27 --> Input Class Initialized
INFO - 2018-06-20 22:01:27 --> Language Class Initialized
INFO - 2018-06-20 22:01:27 --> Loader Class Initialized
INFO - 2018-06-20 22:01:27 --> Helper loaded: url_helper
INFO - 2018-06-20 22:01:27 --> Helper loaded: form_helper
INFO - 2018-06-20 22:01:27 --> Helper loaded: language_helper
DEBUG - 2018-06-20 22:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 22:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 22:01:27 --> User Agent Class Initialized
INFO - 2018-06-20 22:01:27 --> Controller Class Initialized
INFO - 2018-06-20 22:01:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-20 22:01:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-20 22:01:27 --> Pixel_Model class loaded
INFO - 2018-06-20 22:01:27 --> Database Driver Class Initialized
INFO - 2018-06-20 22:01:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-20 22:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-20 22:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-20 22:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-20 22:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-20 22:01:27 --> Final output sent to browser
DEBUG - 2018-06-20 22:01:27 --> Total execution time: 0.0616

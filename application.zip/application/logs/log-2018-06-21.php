<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-21 09:10:23 --> Config Class Initialized
INFO - 2018-06-21 09:10:23 --> Hooks Class Initialized
DEBUG - 2018-06-21 09:10:23 --> UTF-8 Support Enabled
INFO - 2018-06-21 09:10:23 --> Utf8 Class Initialized
INFO - 2018-06-21 09:10:23 --> URI Class Initialized
INFO - 2018-06-21 09:10:23 --> Router Class Initialized
INFO - 2018-06-21 09:10:23 --> Output Class Initialized
INFO - 2018-06-21 09:10:23 --> Security Class Initialized
DEBUG - 2018-06-21 09:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 09:10:23 --> CSRF cookie sent
INFO - 2018-06-21 09:10:23 --> Input Class Initialized
INFO - 2018-06-21 09:10:23 --> Language Class Initialized
ERROR - 2018-06-21 09:10:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-21 09:10:27 --> Config Class Initialized
INFO - 2018-06-21 09:10:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 09:10:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 09:10:27 --> Utf8 Class Initialized
INFO - 2018-06-21 09:10:27 --> URI Class Initialized
DEBUG - 2018-06-21 09:10:27 --> No URI present. Default controller set.
INFO - 2018-06-21 09:10:27 --> Router Class Initialized
INFO - 2018-06-21 09:10:27 --> Output Class Initialized
INFO - 2018-06-21 09:10:27 --> Security Class Initialized
DEBUG - 2018-06-21 09:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 09:10:27 --> CSRF cookie sent
INFO - 2018-06-21 09:10:27 --> Input Class Initialized
INFO - 2018-06-21 09:10:27 --> Language Class Initialized
INFO - 2018-06-21 09:10:27 --> Loader Class Initialized
INFO - 2018-06-21 09:10:27 --> Helper loaded: url_helper
INFO - 2018-06-21 09:10:27 --> Helper loaded: form_helper
INFO - 2018-06-21 09:10:27 --> Helper loaded: language_helper
DEBUG - 2018-06-21 09:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 09:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 09:10:27 --> User Agent Class Initialized
INFO - 2018-06-21 09:10:27 --> Controller Class Initialized
INFO - 2018-06-21 09:10:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 09:10:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 09:10:27 --> Pixel_Model class loaded
INFO - 2018-06-21 09:10:27 --> Database Driver Class Initialized
INFO - 2018-06-21 09:10:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 09:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 09:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 09:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 09:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 09:10:27 --> Final output sent to browser
DEBUG - 2018-06-21 09:10:27 --> Total execution time: 0.0601
INFO - 2018-06-21 12:58:59 --> Config Class Initialized
INFO - 2018-06-21 12:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-21 12:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-21 12:58:59 --> Utf8 Class Initialized
INFO - 2018-06-21 12:58:59 --> URI Class Initialized
INFO - 2018-06-21 12:58:59 --> Router Class Initialized
INFO - 2018-06-21 12:58:59 --> Output Class Initialized
INFO - 2018-06-21 12:58:59 --> Security Class Initialized
DEBUG - 2018-06-21 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 12:58:59 --> CSRF cookie sent
INFO - 2018-06-21 12:58:59 --> Input Class Initialized
INFO - 2018-06-21 12:58:59 --> Language Class Initialized
ERROR - 2018-06-21 12:58:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-21 12:58:59 --> Config Class Initialized
INFO - 2018-06-21 12:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-21 12:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-21 12:58:59 --> Utf8 Class Initialized
INFO - 2018-06-21 12:58:59 --> URI Class Initialized
DEBUG - 2018-06-21 12:58:59 --> No URI present. Default controller set.
INFO - 2018-06-21 12:58:59 --> Router Class Initialized
INFO - 2018-06-21 12:58:59 --> Output Class Initialized
INFO - 2018-06-21 12:58:59 --> Security Class Initialized
DEBUG - 2018-06-21 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 12:58:59 --> CSRF cookie sent
INFO - 2018-06-21 12:58:59 --> Input Class Initialized
INFO - 2018-06-21 12:58:59 --> Language Class Initialized
INFO - 2018-06-21 12:58:59 --> Loader Class Initialized
INFO - 2018-06-21 12:58:59 --> Helper loaded: url_helper
INFO - 2018-06-21 12:58:59 --> Helper loaded: form_helper
INFO - 2018-06-21 12:58:59 --> Helper loaded: language_helper
DEBUG - 2018-06-21 12:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 12:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 12:58:59 --> User Agent Class Initialized
INFO - 2018-06-21 12:58:59 --> Controller Class Initialized
INFO - 2018-06-21 12:58:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 12:58:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 12:58:59 --> Pixel_Model class loaded
INFO - 2018-06-21 12:58:59 --> Database Driver Class Initialized
INFO - 2018-06-21 12:58:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 12:58:59 --> Final output sent to browser
DEBUG - 2018-06-21 12:58:59 --> Total execution time: 0.0674
INFO - 2018-06-21 12:59:06 --> Config Class Initialized
INFO - 2018-06-21 12:59:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 12:59:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 12:59:06 --> Utf8 Class Initialized
INFO - 2018-06-21 12:59:06 --> URI Class Initialized
INFO - 2018-06-21 12:59:06 --> Router Class Initialized
INFO - 2018-06-21 12:59:06 --> Output Class Initialized
INFO - 2018-06-21 12:59:06 --> Security Class Initialized
DEBUG - 2018-06-21 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 12:59:06 --> CSRF cookie sent
INFO - 2018-06-21 12:59:06 --> Input Class Initialized
INFO - 2018-06-21 12:59:06 --> Language Class Initialized
ERROR - 2018-06-21 12:59:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-21 13:32:01 --> Config Class Initialized
INFO - 2018-06-21 13:32:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:32:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:32:01 --> Utf8 Class Initialized
INFO - 2018-06-21 13:32:01 --> URI Class Initialized
DEBUG - 2018-06-21 13:32:01 --> No URI present. Default controller set.
INFO - 2018-06-21 13:32:01 --> Router Class Initialized
INFO - 2018-06-21 13:32:01 --> Output Class Initialized
INFO - 2018-06-21 13:32:01 --> Security Class Initialized
DEBUG - 2018-06-21 13:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:32:01 --> CSRF cookie sent
INFO - 2018-06-21 13:32:01 --> Input Class Initialized
INFO - 2018-06-21 13:32:01 --> Language Class Initialized
INFO - 2018-06-21 13:32:01 --> Loader Class Initialized
INFO - 2018-06-21 13:32:01 --> Helper loaded: url_helper
INFO - 2018-06-21 13:32:01 --> Helper loaded: form_helper
INFO - 2018-06-21 13:32:01 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:32:01 --> User Agent Class Initialized
INFO - 2018-06-21 13:32:01 --> Controller Class Initialized
INFO - 2018-06-21 13:32:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:32:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:32:01 --> Pixel_Model class loaded
INFO - 2018-06-21 13:32:01 --> Database Driver Class Initialized
INFO - 2018-06-21 13:32:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 13:32:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:32:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:32:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 13:32:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:32:01 --> Final output sent to browser
DEBUG - 2018-06-21 13:32:01 --> Total execution time: 0.0750
INFO - 2018-06-21 13:32:53 --> Config Class Initialized
INFO - 2018-06-21 13:32:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:32:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:32:53 --> Utf8 Class Initialized
INFO - 2018-06-21 13:32:53 --> URI Class Initialized
INFO - 2018-06-21 13:32:53 --> Router Class Initialized
INFO - 2018-06-21 13:32:53 --> Output Class Initialized
INFO - 2018-06-21 13:32:53 --> Security Class Initialized
DEBUG - 2018-06-21 13:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:32:53 --> CSRF cookie sent
INFO - 2018-06-21 13:32:53 --> Input Class Initialized
INFO - 2018-06-21 13:32:53 --> Language Class Initialized
INFO - 2018-06-21 13:32:53 --> Loader Class Initialized
INFO - 2018-06-21 13:32:53 --> Helper loaded: url_helper
INFO - 2018-06-21 13:32:53 --> Helper loaded: form_helper
INFO - 2018-06-21 13:32:53 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:32:53 --> User Agent Class Initialized
INFO - 2018-06-21 13:32:53 --> Controller Class Initialized
INFO - 2018-06-21 13:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-21 13:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:32:53 --> Final output sent to browser
DEBUG - 2018-06-21 13:32:53 --> Total execution time: 0.0491
INFO - 2018-06-21 13:33:03 --> Config Class Initialized
INFO - 2018-06-21 13:33:03 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:33:03 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:33:03 --> Utf8 Class Initialized
INFO - 2018-06-21 13:33:03 --> URI Class Initialized
INFO - 2018-06-21 13:33:03 --> Router Class Initialized
INFO - 2018-06-21 13:33:03 --> Output Class Initialized
INFO - 2018-06-21 13:33:03 --> Security Class Initialized
DEBUG - 2018-06-21 13:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:33:03 --> CSRF cookie sent
INFO - 2018-06-21 13:33:03 --> Input Class Initialized
INFO - 2018-06-21 13:33:03 --> Language Class Initialized
INFO - 2018-06-21 13:33:03 --> Loader Class Initialized
INFO - 2018-06-21 13:33:03 --> Helper loaded: url_helper
INFO - 2018-06-21 13:33:03 --> Helper loaded: form_helper
INFO - 2018-06-21 13:33:03 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:33:03 --> User Agent Class Initialized
INFO - 2018-06-21 13:33:03 --> Controller Class Initialized
INFO - 2018-06-21 13:33:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:33:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 13:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:33:03 --> Final output sent to browser
DEBUG - 2018-06-21 13:33:03 --> Total execution time: 0.0533
INFO - 2018-06-21 13:33:26 --> Config Class Initialized
INFO - 2018-06-21 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:33:26 --> Utf8 Class Initialized
INFO - 2018-06-21 13:33:26 --> URI Class Initialized
DEBUG - 2018-06-21 13:33:26 --> No URI present. Default controller set.
INFO - 2018-06-21 13:33:26 --> Router Class Initialized
INFO - 2018-06-21 13:33:26 --> Output Class Initialized
INFO - 2018-06-21 13:33:26 --> Security Class Initialized
DEBUG - 2018-06-21 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:33:26 --> CSRF cookie sent
INFO - 2018-06-21 13:33:26 --> Input Class Initialized
INFO - 2018-06-21 13:33:26 --> Language Class Initialized
INFO - 2018-06-21 13:33:26 --> Loader Class Initialized
INFO - 2018-06-21 13:33:26 --> Helper loaded: url_helper
INFO - 2018-06-21 13:33:26 --> Helper loaded: form_helper
INFO - 2018-06-21 13:33:26 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:33:26 --> User Agent Class Initialized
INFO - 2018-06-21 13:33:26 --> Controller Class Initialized
INFO - 2018-06-21 13:33:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:33:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:33:26 --> Pixel_Model class loaded
INFO - 2018-06-21 13:33:26 --> Database Driver Class Initialized
INFO - 2018-06-21 13:33:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 13:33:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:33:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:33:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 13:33:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:33:26 --> Final output sent to browser
DEBUG - 2018-06-21 13:33:26 --> Total execution time: 0.0481
INFO - 2018-06-21 13:33:29 --> Config Class Initialized
INFO - 2018-06-21 13:33:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:33:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:33:29 --> Utf8 Class Initialized
INFO - 2018-06-21 13:33:29 --> URI Class Initialized
INFO - 2018-06-21 13:33:29 --> Router Class Initialized
INFO - 2018-06-21 13:33:29 --> Output Class Initialized
INFO - 2018-06-21 13:33:29 --> Security Class Initialized
DEBUG - 2018-06-21 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:33:29 --> CSRF cookie sent
INFO - 2018-06-21 13:33:29 --> Input Class Initialized
INFO - 2018-06-21 13:33:29 --> Language Class Initialized
INFO - 2018-06-21 13:33:29 --> Loader Class Initialized
INFO - 2018-06-21 13:33:29 --> Helper loaded: url_helper
INFO - 2018-06-21 13:33:29 --> Helper loaded: form_helper
INFO - 2018-06-21 13:33:29 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:33:29 --> User Agent Class Initialized
INFO - 2018-06-21 13:33:29 --> Controller Class Initialized
INFO - 2018-06-21 13:33:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:33:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 13:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:33:29 --> Final output sent to browser
DEBUG - 2018-06-21 13:33:29 --> Total execution time: 0.0259
INFO - 2018-06-21 13:47:37 --> Config Class Initialized
INFO - 2018-06-21 13:47:37 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:47:37 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:47:37 --> Utf8 Class Initialized
INFO - 2018-06-21 13:47:37 --> URI Class Initialized
INFO - 2018-06-21 13:47:37 --> Router Class Initialized
INFO - 2018-06-21 13:47:37 --> Output Class Initialized
INFO - 2018-06-21 13:47:37 --> Security Class Initialized
DEBUG - 2018-06-21 13:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:47:37 --> CSRF cookie sent
INFO - 2018-06-21 13:47:37 --> Input Class Initialized
INFO - 2018-06-21 13:47:37 --> Language Class Initialized
INFO - 2018-06-21 13:47:37 --> Loader Class Initialized
INFO - 2018-06-21 13:47:37 --> Helper loaded: url_helper
INFO - 2018-06-21 13:47:37 --> Helper loaded: form_helper
INFO - 2018-06-21 13:47:37 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:47:37 --> User Agent Class Initialized
INFO - 2018-06-21 13:47:37 --> Controller Class Initialized
INFO - 2018-06-21 13:47:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:47:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 13:47:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 13:47:37 --> Could not find the language line "req_email"
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 13:47:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:47:37 --> Final output sent to browser
DEBUG - 2018-06-21 13:47:37 --> Total execution time: 0.0321
INFO - 2018-06-21 13:47:39 --> Config Class Initialized
INFO - 2018-06-21 13:47:39 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:47:39 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:47:39 --> Utf8 Class Initialized
INFO - 2018-06-21 13:47:39 --> URI Class Initialized
INFO - 2018-06-21 13:47:39 --> Router Class Initialized
INFO - 2018-06-21 13:47:39 --> Output Class Initialized
INFO - 2018-06-21 13:47:39 --> Security Class Initialized
DEBUG - 2018-06-21 13:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:47:39 --> CSRF cookie sent
INFO - 2018-06-21 13:47:39 --> Input Class Initialized
INFO - 2018-06-21 13:47:39 --> Language Class Initialized
INFO - 2018-06-21 13:47:39 --> Loader Class Initialized
INFO - 2018-06-21 13:47:39 --> Helper loaded: url_helper
INFO - 2018-06-21 13:47:39 --> Helper loaded: form_helper
INFO - 2018-06-21 13:47:39 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:47:39 --> User Agent Class Initialized
INFO - 2018-06-21 13:47:39 --> Controller Class Initialized
INFO - 2018-06-21 13:47:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:47:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:47:39 --> Pixel_Model class loaded
INFO - 2018-06-21 13:47:39 --> Database Driver Class Initialized
INFO - 2018-06-21 13:47:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 13:47:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 13:47:39 --> Could not find the language line "req_email"
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-21 13:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:47:39 --> Final output sent to browser
DEBUG - 2018-06-21 13:47:39 --> Total execution time: 0.0543
INFO - 2018-06-21 13:48:04 --> Config Class Initialized
INFO - 2018-06-21 13:48:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:48:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:48:04 --> Utf8 Class Initialized
INFO - 2018-06-21 13:48:04 --> URI Class Initialized
INFO - 2018-06-21 13:48:04 --> Router Class Initialized
INFO - 2018-06-21 13:48:04 --> Output Class Initialized
INFO - 2018-06-21 13:48:04 --> Security Class Initialized
DEBUG - 2018-06-21 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:48:04 --> CSRF cookie sent
INFO - 2018-06-21 13:48:04 --> Input Class Initialized
INFO - 2018-06-21 13:48:04 --> Language Class Initialized
ERROR - 2018-06-21 13:48:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-21 13:48:04 --> Config Class Initialized
INFO - 2018-06-21 13:48:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:48:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:48:04 --> Utf8 Class Initialized
INFO - 2018-06-21 13:48:04 --> URI Class Initialized
INFO - 2018-06-21 13:48:04 --> Router Class Initialized
INFO - 2018-06-21 13:48:04 --> Output Class Initialized
INFO - 2018-06-21 13:48:04 --> Security Class Initialized
DEBUG - 2018-06-21 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:48:04 --> CSRF cookie sent
INFO - 2018-06-21 13:48:04 --> Input Class Initialized
INFO - 2018-06-21 13:48:04 --> Language Class Initialized
INFO - 2018-06-21 13:48:04 --> Loader Class Initialized
INFO - 2018-06-21 13:48:04 --> Helper loaded: url_helper
INFO - 2018-06-21 13:48:04 --> Helper loaded: form_helper
INFO - 2018-06-21 13:48:04 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:48:04 --> User Agent Class Initialized
INFO - 2018-06-21 13:48:04 --> Controller Class Initialized
INFO - 2018-06-21 13:48:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:48:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:48:04 --> Final output sent to browser
DEBUG - 2018-06-21 13:48:04 --> Total execution time: 0.0329
INFO - 2018-06-21 13:48:04 --> Config Class Initialized
INFO - 2018-06-21 13:48:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:48:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:48:04 --> Utf8 Class Initialized
INFO - 2018-06-21 13:48:04 --> URI Class Initialized
INFO - 2018-06-21 13:48:04 --> Router Class Initialized
INFO - 2018-06-21 13:48:04 --> Output Class Initialized
INFO - 2018-06-21 13:48:04 --> Security Class Initialized
DEBUG - 2018-06-21 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:48:04 --> CSRF cookie sent
INFO - 2018-06-21 13:48:04 --> Input Class Initialized
INFO - 2018-06-21 13:48:04 --> Language Class Initialized
INFO - 2018-06-21 13:48:04 --> Loader Class Initialized
INFO - 2018-06-21 13:48:04 --> Helper loaded: url_helper
INFO - 2018-06-21 13:48:04 --> Helper loaded: form_helper
INFO - 2018-06-21 13:48:04 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:48:04 --> User Agent Class Initialized
INFO - 2018-06-21 13:48:04 --> Controller Class Initialized
INFO - 2018-06-21 13:48:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:48:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 13:48:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:48:04 --> Final output sent to browser
DEBUG - 2018-06-21 13:48:04 --> Total execution time: 0.0310
INFO - 2018-06-21 13:49:50 --> Config Class Initialized
INFO - 2018-06-21 13:49:50 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:49:50 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:49:50 --> Utf8 Class Initialized
INFO - 2018-06-21 13:49:50 --> URI Class Initialized
INFO - 2018-06-21 13:49:50 --> Router Class Initialized
INFO - 2018-06-21 13:49:50 --> Output Class Initialized
INFO - 2018-06-21 13:49:50 --> Security Class Initialized
DEBUG - 2018-06-21 13:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:49:50 --> CSRF cookie sent
INFO - 2018-06-21 13:49:50 --> Input Class Initialized
INFO - 2018-06-21 13:49:50 --> Language Class Initialized
INFO - 2018-06-21 13:49:50 --> Loader Class Initialized
INFO - 2018-06-21 13:49:50 --> Helper loaded: url_helper
INFO - 2018-06-21 13:49:50 --> Helper loaded: form_helper
INFO - 2018-06-21 13:49:50 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:49:50 --> User Agent Class Initialized
INFO - 2018-06-21 13:49:50 --> Controller Class Initialized
INFO - 2018-06-21 13:49:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:49:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-21 13:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:49:50 --> Final output sent to browser
DEBUG - 2018-06-21 13:49:50 --> Total execution time: 0.0356
INFO - 2018-06-21 13:49:54 --> Config Class Initialized
INFO - 2018-06-21 13:49:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:49:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:49:54 --> Utf8 Class Initialized
INFO - 2018-06-21 13:49:54 --> URI Class Initialized
INFO - 2018-06-21 13:49:54 --> Router Class Initialized
INFO - 2018-06-21 13:49:54 --> Output Class Initialized
INFO - 2018-06-21 13:49:54 --> Security Class Initialized
DEBUG - 2018-06-21 13:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:49:54 --> CSRF cookie sent
INFO - 2018-06-21 13:49:54 --> Input Class Initialized
INFO - 2018-06-21 13:49:54 --> Language Class Initialized
INFO - 2018-06-21 13:49:54 --> Loader Class Initialized
INFO - 2018-06-21 13:49:54 --> Helper loaded: url_helper
INFO - 2018-06-21 13:49:54 --> Helper loaded: form_helper
INFO - 2018-06-21 13:49:54 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:49:54 --> User Agent Class Initialized
INFO - 2018-06-21 13:49:54 --> Controller Class Initialized
INFO - 2018-06-21 13:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:49:54 --> Pixel_Model class loaded
INFO - 2018-06-21 13:49:54 --> Database Driver Class Initialized
INFO - 2018-06-21 13:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 13:49:54 --> Config Class Initialized
INFO - 2018-06-21 13:49:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:49:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:49:54 --> Utf8 Class Initialized
INFO - 2018-06-21 13:49:54 --> URI Class Initialized
INFO - 2018-06-21 13:49:54 --> Router Class Initialized
INFO - 2018-06-21 13:49:54 --> Output Class Initialized
INFO - 2018-06-21 13:49:54 --> Security Class Initialized
DEBUG - 2018-06-21 13:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:49:54 --> CSRF cookie sent
INFO - 2018-06-21 13:49:54 --> Input Class Initialized
INFO - 2018-06-21 13:49:54 --> Language Class Initialized
INFO - 2018-06-21 13:49:54 --> Loader Class Initialized
INFO - 2018-06-21 13:49:54 --> Helper loaded: url_helper
INFO - 2018-06-21 13:49:54 --> Helper loaded: form_helper
INFO - 2018-06-21 13:49:54 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:49:54 --> User Agent Class Initialized
INFO - 2018-06-21 13:49:54 --> Controller Class Initialized
INFO - 2018-06-21 13:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:49:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 13:49:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 13:49:54 --> Could not find the language line "req_email"
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 13:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:49:54 --> Final output sent to browser
DEBUG - 2018-06-21 13:49:54 --> Total execution time: 0.0370
INFO - 2018-06-21 13:50:04 --> Config Class Initialized
INFO - 2018-06-21 13:50:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:50:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:50:04 --> Utf8 Class Initialized
INFO - 2018-06-21 13:50:04 --> URI Class Initialized
DEBUG - 2018-06-21 13:50:04 --> No URI present. Default controller set.
INFO - 2018-06-21 13:50:04 --> Router Class Initialized
INFO - 2018-06-21 13:50:04 --> Output Class Initialized
INFO - 2018-06-21 13:50:04 --> Security Class Initialized
DEBUG - 2018-06-21 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:50:04 --> CSRF cookie sent
INFO - 2018-06-21 13:50:04 --> Input Class Initialized
INFO - 2018-06-21 13:50:04 --> Language Class Initialized
INFO - 2018-06-21 13:50:04 --> Loader Class Initialized
INFO - 2018-06-21 13:50:04 --> Helper loaded: url_helper
INFO - 2018-06-21 13:50:04 --> Helper loaded: form_helper
INFO - 2018-06-21 13:50:04 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:50:04 --> User Agent Class Initialized
INFO - 2018-06-21 13:50:04 --> Controller Class Initialized
INFO - 2018-06-21 13:50:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:50:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:50:04 --> Pixel_Model class loaded
INFO - 2018-06-21 13:50:04 --> Database Driver Class Initialized
INFO - 2018-06-21 13:50:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 13:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 13:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:50:04 --> Final output sent to browser
DEBUG - 2018-06-21 13:50:04 --> Total execution time: 0.0823
INFO - 2018-06-21 13:50:14 --> Config Class Initialized
INFO - 2018-06-21 13:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-21 13:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-21 13:50:14 --> Utf8 Class Initialized
INFO - 2018-06-21 13:50:14 --> URI Class Initialized
INFO - 2018-06-21 13:50:14 --> Router Class Initialized
INFO - 2018-06-21 13:50:14 --> Output Class Initialized
INFO - 2018-06-21 13:50:14 --> Security Class Initialized
DEBUG - 2018-06-21 13:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 13:50:14 --> CSRF cookie sent
INFO - 2018-06-21 13:50:14 --> Input Class Initialized
INFO - 2018-06-21 13:50:14 --> Language Class Initialized
INFO - 2018-06-21 13:50:14 --> Loader Class Initialized
INFO - 2018-06-21 13:50:14 --> Helper loaded: url_helper
INFO - 2018-06-21 13:50:14 --> Helper loaded: form_helper
INFO - 2018-06-21 13:50:14 --> Helper loaded: language_helper
DEBUG - 2018-06-21 13:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 13:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 13:50:14 --> User Agent Class Initialized
INFO - 2018-06-21 13:50:14 --> Controller Class Initialized
INFO - 2018-06-21 13:50:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 13:50:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 13:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 13:50:14 --> Final output sent to browser
DEBUG - 2018-06-21 13:50:14 --> Total execution time: 0.0303
INFO - 2018-06-21 14:02:16 --> Config Class Initialized
INFO - 2018-06-21 14:02:16 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:02:16 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:02:16 --> Utf8 Class Initialized
INFO - 2018-06-21 14:02:16 --> URI Class Initialized
INFO - 2018-06-21 14:02:16 --> Router Class Initialized
INFO - 2018-06-21 14:02:16 --> Output Class Initialized
INFO - 2018-06-21 14:02:16 --> Security Class Initialized
DEBUG - 2018-06-21 14:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:02:16 --> CSRF cookie sent
INFO - 2018-06-21 14:02:16 --> Input Class Initialized
INFO - 2018-06-21 14:02:16 --> Language Class Initialized
INFO - 2018-06-21 14:02:16 --> Loader Class Initialized
INFO - 2018-06-21 14:02:16 --> Helper loaded: url_helper
INFO - 2018-06-21 14:02:16 --> Helper loaded: form_helper
INFO - 2018-06-21 14:02:16 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:02:16 --> User Agent Class Initialized
INFO - 2018-06-21 14:02:16 --> Controller Class Initialized
INFO - 2018-06-21 14:02:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:02:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 14:02:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:02:16 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 14:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:02:16 --> Final output sent to browser
DEBUG - 2018-06-21 14:02:16 --> Total execution time: 0.0799
INFO - 2018-06-21 14:02:21 --> Config Class Initialized
INFO - 2018-06-21 14:02:21 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:02:21 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:02:21 --> Utf8 Class Initialized
INFO - 2018-06-21 14:02:21 --> URI Class Initialized
INFO - 2018-06-21 14:02:21 --> Router Class Initialized
INFO - 2018-06-21 14:02:21 --> Output Class Initialized
INFO - 2018-06-21 14:02:21 --> Security Class Initialized
DEBUG - 2018-06-21 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:02:21 --> CSRF cookie sent
INFO - 2018-06-21 14:02:21 --> Input Class Initialized
INFO - 2018-06-21 14:02:21 --> Language Class Initialized
INFO - 2018-06-21 14:02:21 --> Loader Class Initialized
INFO - 2018-06-21 14:02:21 --> Helper loaded: url_helper
INFO - 2018-06-21 14:02:21 --> Helper loaded: form_helper
INFO - 2018-06-21 14:02:21 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:02:21 --> User Agent Class Initialized
INFO - 2018-06-21 14:02:21 --> Controller Class Initialized
INFO - 2018-06-21 14:02:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:02:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:02:21 --> Pixel_Model class loaded
INFO - 2018-06-21 14:02:21 --> Database Driver Class Initialized
INFO - 2018-06-21 14:02:21 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 14:02:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:02:21 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-21 14:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:02:21 --> Final output sent to browser
DEBUG - 2018-06-21 14:02:21 --> Total execution time: 0.0698
INFO - 2018-06-21 14:51:03 --> Config Class Initialized
INFO - 2018-06-21 14:51:03 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:03 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:03 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:03 --> URI Class Initialized
INFO - 2018-06-21 14:51:03 --> Router Class Initialized
INFO - 2018-06-21 14:51:03 --> Output Class Initialized
INFO - 2018-06-21 14:51:03 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:03 --> CSRF cookie sent
INFO - 2018-06-21 14:51:03 --> Input Class Initialized
INFO - 2018-06-21 14:51:03 --> Language Class Initialized
INFO - 2018-06-21 14:51:03 --> Loader Class Initialized
INFO - 2018-06-21 14:51:03 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:03 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:03 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:03 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:03 --> Controller Class Initialized
INFO - 2018-06-21 14:51:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 14:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:03 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:03 --> Total execution time: 0.0867
INFO - 2018-06-21 14:51:04 --> Config Class Initialized
INFO - 2018-06-21 14:51:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:04 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:04 --> URI Class Initialized
DEBUG - 2018-06-21 14:51:04 --> No URI present. Default controller set.
INFO - 2018-06-21 14:51:04 --> Router Class Initialized
INFO - 2018-06-21 14:51:04 --> Output Class Initialized
INFO - 2018-06-21 14:51:04 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:04 --> CSRF cookie sent
INFO - 2018-06-21 14:51:04 --> Input Class Initialized
INFO - 2018-06-21 14:51:04 --> Language Class Initialized
INFO - 2018-06-21 14:51:04 --> Loader Class Initialized
INFO - 2018-06-21 14:51:04 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:04 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:04 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:04 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:04 --> Controller Class Initialized
INFO - 2018-06-21 14:51:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:04 --> Pixel_Model class loaded
INFO - 2018-06-21 14:51:04 --> Database Driver Class Initialized
INFO - 2018-06-21 14:51:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:04 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:04 --> Total execution time: 0.0743
INFO - 2018-06-21 14:51:04 --> Config Class Initialized
INFO - 2018-06-21 14:51:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:04 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:04 --> URI Class Initialized
INFO - 2018-06-21 14:51:04 --> Router Class Initialized
INFO - 2018-06-21 14:51:04 --> Output Class Initialized
INFO - 2018-06-21 14:51:04 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:04 --> CSRF cookie sent
INFO - 2018-06-21 14:51:04 --> Input Class Initialized
INFO - 2018-06-21 14:51:04 --> Language Class Initialized
INFO - 2018-06-21 14:51:04 --> Loader Class Initialized
INFO - 2018-06-21 14:51:04 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:04 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:04 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:04 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:04 --> Controller Class Initialized
INFO - 2018-06-21 14:51:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-21 14:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:04 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:04 --> Total execution time: 0.0600
INFO - 2018-06-21 14:51:05 --> Config Class Initialized
INFO - 2018-06-21 14:51:05 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:05 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:05 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:05 --> URI Class Initialized
INFO - 2018-06-21 14:51:05 --> Router Class Initialized
INFO - 2018-06-21 14:51:05 --> Output Class Initialized
INFO - 2018-06-21 14:51:05 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:05 --> CSRF cookie sent
INFO - 2018-06-21 14:51:05 --> Input Class Initialized
INFO - 2018-06-21 14:51:05 --> Language Class Initialized
INFO - 2018-06-21 14:51:05 --> Loader Class Initialized
INFO - 2018-06-21 14:51:05 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:05 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:05 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:05 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:05 --> Controller Class Initialized
INFO - 2018-06-21 14:51:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 14:51:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:51:05 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 14:51:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:05 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:05 --> Total execution time: 0.0821
INFO - 2018-06-21 14:51:06 --> Config Class Initialized
INFO - 2018-06-21 14:51:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:06 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:06 --> URI Class Initialized
INFO - 2018-06-21 14:51:06 --> Router Class Initialized
INFO - 2018-06-21 14:51:06 --> Output Class Initialized
INFO - 2018-06-21 14:51:06 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:06 --> CSRF cookie sent
INFO - 2018-06-21 14:51:06 --> Input Class Initialized
INFO - 2018-06-21 14:51:06 --> Language Class Initialized
INFO - 2018-06-21 14:51:06 --> Loader Class Initialized
INFO - 2018-06-21 14:51:06 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:06 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:06 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:06 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:06 --> Controller Class Initialized
INFO - 2018-06-21 14:51:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-21 14:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:06 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:06 --> Total execution time: 0.0408
INFO - 2018-06-21 14:51:07 --> Config Class Initialized
INFO - 2018-06-21 14:51:07 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:07 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:07 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:07 --> URI Class Initialized
INFO - 2018-06-21 14:51:07 --> Router Class Initialized
INFO - 2018-06-21 14:51:07 --> Output Class Initialized
INFO - 2018-06-21 14:51:07 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:07 --> CSRF cookie sent
INFO - 2018-06-21 14:51:07 --> Input Class Initialized
INFO - 2018-06-21 14:51:07 --> Language Class Initialized
INFO - 2018-06-21 14:51:07 --> Loader Class Initialized
INFO - 2018-06-21 14:51:07 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:07 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:07 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:07 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:07 --> Controller Class Initialized
INFO - 2018-06-21 14:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-21 14:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:07 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:07 --> Total execution time: 0.0468
INFO - 2018-06-21 14:51:08 --> Config Class Initialized
INFO - 2018-06-21 14:51:08 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:08 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:08 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:08 --> URI Class Initialized
INFO - 2018-06-21 14:51:08 --> Router Class Initialized
INFO - 2018-06-21 14:51:08 --> Output Class Initialized
INFO - 2018-06-21 14:51:08 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:08 --> CSRF cookie sent
INFO - 2018-06-21 14:51:08 --> Input Class Initialized
INFO - 2018-06-21 14:51:08 --> Language Class Initialized
INFO - 2018-06-21 14:51:08 --> Loader Class Initialized
INFO - 2018-06-21 14:51:08 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:08 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:08 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:08 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:08 --> Controller Class Initialized
INFO - 2018-06-21 14:51:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:08 --> Pixel_Model class loaded
INFO - 2018-06-21 14:51:08 --> Database Driver Class Initialized
INFO - 2018-06-21 14:51:08 --> Model "QuestionsModel" initialized
ERROR - 2018-06-21 14:51:08 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-21 14:51:09 --> Config Class Initialized
INFO - 2018-06-21 14:51:09 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:09 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:09 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:09 --> URI Class Initialized
INFO - 2018-06-21 14:51:09 --> Router Class Initialized
INFO - 2018-06-21 14:51:09 --> Output Class Initialized
INFO - 2018-06-21 14:51:09 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:09 --> CSRF cookie sent
INFO - 2018-06-21 14:51:09 --> Input Class Initialized
INFO - 2018-06-21 14:51:09 --> Language Class Initialized
INFO - 2018-06-21 14:51:09 --> Loader Class Initialized
INFO - 2018-06-21 14:51:09 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:09 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:09 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:09 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:09 --> Controller Class Initialized
INFO - 2018-06-21 14:51:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 14:51:09 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:51:09 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 14:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:09 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:09 --> Total execution time: 0.0855
INFO - 2018-06-21 14:51:42 --> Config Class Initialized
INFO - 2018-06-21 14:51:42 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:51:42 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:51:42 --> Utf8 Class Initialized
INFO - 2018-06-21 14:51:42 --> URI Class Initialized
INFO - 2018-06-21 14:51:42 --> Router Class Initialized
INFO - 2018-06-21 14:51:42 --> Output Class Initialized
INFO - 2018-06-21 14:51:42 --> Security Class Initialized
DEBUG - 2018-06-21 14:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:51:42 --> CSRF cookie sent
INFO - 2018-06-21 14:51:42 --> Input Class Initialized
INFO - 2018-06-21 14:51:42 --> Language Class Initialized
INFO - 2018-06-21 14:51:42 --> Loader Class Initialized
INFO - 2018-06-21 14:51:42 --> Helper loaded: url_helper
INFO - 2018-06-21 14:51:42 --> Helper loaded: form_helper
INFO - 2018-06-21 14:51:42 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:51:42 --> User Agent Class Initialized
INFO - 2018-06-21 14:51:42 --> Controller Class Initialized
INFO - 2018-06-21 14:51:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:51:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-06-21 14:51:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:51:42 --> Final output sent to browser
DEBUG - 2018-06-21 14:51:42 --> Total execution time: 0.0591
INFO - 2018-06-21 14:52:02 --> Config Class Initialized
INFO - 2018-06-21 14:52:02 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:52:02 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:52:02 --> Utf8 Class Initialized
INFO - 2018-06-21 14:52:02 --> URI Class Initialized
INFO - 2018-06-21 14:52:02 --> Router Class Initialized
INFO - 2018-06-21 14:52:02 --> Output Class Initialized
INFO - 2018-06-21 14:52:02 --> Security Class Initialized
DEBUG - 2018-06-21 14:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:52:02 --> CSRF cookie sent
INFO - 2018-06-21 14:52:02 --> Input Class Initialized
INFO - 2018-06-21 14:52:02 --> Language Class Initialized
INFO - 2018-06-21 14:52:02 --> Loader Class Initialized
INFO - 2018-06-21 14:52:02 --> Helper loaded: url_helper
INFO - 2018-06-21 14:52:02 --> Helper loaded: form_helper
INFO - 2018-06-21 14:52:02 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:52:02 --> User Agent Class Initialized
INFO - 2018-06-21 14:52:02 --> Controller Class Initialized
INFO - 2018-06-21 14:52:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:52:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:52:02 --> Pixel_Model class loaded
INFO - 2018-06-21 14:52:02 --> Database Driver Class Initialized
INFO - 2018-06-21 14:52:02 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 14:52:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:52:02 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-21 14:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:52:02 --> Final output sent to browser
DEBUG - 2018-06-21 14:52:02 --> Total execution time: 0.0734
INFO - 2018-06-21 14:52:32 --> Config Class Initialized
INFO - 2018-06-21 14:52:32 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:52:32 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:52:32 --> Utf8 Class Initialized
INFO - 2018-06-21 14:52:32 --> URI Class Initialized
INFO - 2018-06-21 14:52:32 --> Router Class Initialized
INFO - 2018-06-21 14:52:32 --> Output Class Initialized
INFO - 2018-06-21 14:52:33 --> Security Class Initialized
DEBUG - 2018-06-21 14:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:52:33 --> CSRF cookie sent
INFO - 2018-06-21 14:52:33 --> Input Class Initialized
INFO - 2018-06-21 14:52:33 --> Language Class Initialized
INFO - 2018-06-21 14:52:33 --> Loader Class Initialized
INFO - 2018-06-21 14:52:33 --> Helper loaded: url_helper
INFO - 2018-06-21 14:52:33 --> Helper loaded: form_helper
INFO - 2018-06-21 14:52:33 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:52:33 --> User Agent Class Initialized
INFO - 2018-06-21 14:52:33 --> Controller Class Initialized
INFO - 2018-06-21 14:52:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:52:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-06-21 14:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:52:33 --> Final output sent to browser
DEBUG - 2018-06-21 14:52:33 --> Total execution time: 0.0652
INFO - 2018-06-21 14:52:49 --> Config Class Initialized
INFO - 2018-06-21 14:52:49 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:52:49 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:52:49 --> Utf8 Class Initialized
INFO - 2018-06-21 14:52:49 --> URI Class Initialized
INFO - 2018-06-21 14:52:49 --> Router Class Initialized
INFO - 2018-06-21 14:52:49 --> Output Class Initialized
INFO - 2018-06-21 14:52:49 --> Security Class Initialized
DEBUG - 2018-06-21 14:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:52:49 --> CSRF cookie sent
INFO - 2018-06-21 14:52:49 --> Input Class Initialized
INFO - 2018-06-21 14:52:49 --> Language Class Initialized
INFO - 2018-06-21 14:52:49 --> Loader Class Initialized
INFO - 2018-06-21 14:52:49 --> Helper loaded: url_helper
INFO - 2018-06-21 14:52:49 --> Helper loaded: form_helper
INFO - 2018-06-21 14:52:49 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:52:49 --> User Agent Class Initialized
INFO - 2018-06-21 14:52:49 --> Controller Class Initialized
INFO - 2018-06-21 14:52:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:52:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-06-21 14:52:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:52:49 --> Final output sent to browser
DEBUG - 2018-06-21 14:52:49 --> Total execution time: 0.0427
INFO - 2018-06-21 14:53:07 --> Config Class Initialized
INFO - 2018-06-21 14:53:07 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:53:07 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:53:07 --> Utf8 Class Initialized
INFO - 2018-06-21 14:53:07 --> URI Class Initialized
INFO - 2018-06-21 14:53:07 --> Router Class Initialized
INFO - 2018-06-21 14:53:07 --> Output Class Initialized
INFO - 2018-06-21 14:53:07 --> Security Class Initialized
DEBUG - 2018-06-21 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:53:07 --> CSRF cookie sent
INFO - 2018-06-21 14:53:07 --> Input Class Initialized
INFO - 2018-06-21 14:53:07 --> Language Class Initialized
INFO - 2018-06-21 14:53:07 --> Loader Class Initialized
INFO - 2018-06-21 14:53:07 --> Helper loaded: url_helper
INFO - 2018-06-21 14:53:07 --> Helper loaded: form_helper
INFO - 2018-06-21 14:53:07 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:53:07 --> User Agent Class Initialized
INFO - 2018-06-21 14:53:07 --> Controller Class Initialized
INFO - 2018-06-21 14:53:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:53:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-06-21 14:53:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:53:07 --> Final output sent to browser
DEBUG - 2018-06-21 14:53:07 --> Total execution time: 0.0404
INFO - 2018-06-21 14:53:24 --> Config Class Initialized
INFO - 2018-06-21 14:53:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:53:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:53:24 --> Utf8 Class Initialized
INFO - 2018-06-21 14:53:24 --> URI Class Initialized
INFO - 2018-06-21 14:53:24 --> Router Class Initialized
INFO - 2018-06-21 14:53:24 --> Output Class Initialized
INFO - 2018-06-21 14:53:24 --> Security Class Initialized
DEBUG - 2018-06-21 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:53:24 --> CSRF cookie sent
INFO - 2018-06-21 14:53:24 --> Input Class Initialized
INFO - 2018-06-21 14:53:24 --> Language Class Initialized
INFO - 2018-06-21 14:53:24 --> Loader Class Initialized
INFO - 2018-06-21 14:53:24 --> Helper loaded: url_helper
INFO - 2018-06-21 14:53:24 --> Helper loaded: form_helper
INFO - 2018-06-21 14:53:24 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:53:24 --> User Agent Class Initialized
INFO - 2018-06-21 14:53:24 --> Controller Class Initialized
INFO - 2018-06-21 14:53:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:53:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-06-21 14:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:53:24 --> Final output sent to browser
DEBUG - 2018-06-21 14:53:24 --> Total execution time: 0.0438
INFO - 2018-06-21 14:53:41 --> Config Class Initialized
INFO - 2018-06-21 14:53:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:53:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:53:41 --> Utf8 Class Initialized
INFO - 2018-06-21 14:53:41 --> URI Class Initialized
INFO - 2018-06-21 14:53:41 --> Router Class Initialized
INFO - 2018-06-21 14:53:41 --> Output Class Initialized
INFO - 2018-06-21 14:53:41 --> Security Class Initialized
DEBUG - 2018-06-21 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:53:41 --> CSRF cookie sent
INFO - 2018-06-21 14:53:41 --> Input Class Initialized
INFO - 2018-06-21 14:53:41 --> Language Class Initialized
INFO - 2018-06-21 14:53:41 --> Loader Class Initialized
INFO - 2018-06-21 14:53:41 --> Helper loaded: url_helper
INFO - 2018-06-21 14:53:41 --> Helper loaded: form_helper
INFO - 2018-06-21 14:53:41 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:53:41 --> User Agent Class Initialized
INFO - 2018-06-21 14:53:41 --> Controller Class Initialized
INFO - 2018-06-21 14:53:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:53:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-21 14:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:53:41 --> Final output sent to browser
DEBUG - 2018-06-21 14:53:41 --> Total execution time: 0.0500
INFO - 2018-06-21 14:53:58 --> Config Class Initialized
INFO - 2018-06-21 14:53:58 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:53:58 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:53:58 --> Utf8 Class Initialized
INFO - 2018-06-21 14:53:58 --> URI Class Initialized
INFO - 2018-06-21 14:53:58 --> Router Class Initialized
INFO - 2018-06-21 14:53:58 --> Output Class Initialized
INFO - 2018-06-21 14:53:58 --> Security Class Initialized
DEBUG - 2018-06-21 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:53:58 --> CSRF cookie sent
INFO - 2018-06-21 14:53:58 --> Input Class Initialized
INFO - 2018-06-21 14:53:58 --> Language Class Initialized
INFO - 2018-06-21 14:53:58 --> Loader Class Initialized
INFO - 2018-06-21 14:53:58 --> Helper loaded: url_helper
INFO - 2018-06-21 14:53:58 --> Helper loaded: form_helper
INFO - 2018-06-21 14:53:58 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:53:58 --> User Agent Class Initialized
INFO - 2018-06-21 14:53:58 --> Controller Class Initialized
INFO - 2018-06-21 14:53:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:53:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:53:58 --> Pixel_Model class loaded
INFO - 2018-06-21 14:53:58 --> Database Driver Class Initialized
INFO - 2018-06-21 14:53:58 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 14:53:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:53:58 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-06-21 14:53:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:53:58 --> Final output sent to browser
DEBUG - 2018-06-21 14:53:58 --> Total execution time: 0.0788
INFO - 2018-06-21 14:54:15 --> Config Class Initialized
INFO - 2018-06-21 14:54:15 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:54:15 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:54:15 --> Utf8 Class Initialized
INFO - 2018-06-21 14:54:15 --> URI Class Initialized
INFO - 2018-06-21 14:54:15 --> Router Class Initialized
INFO - 2018-06-21 14:54:15 --> Output Class Initialized
INFO - 2018-06-21 14:54:15 --> Security Class Initialized
DEBUG - 2018-06-21 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:54:15 --> CSRF cookie sent
INFO - 2018-06-21 14:54:15 --> Input Class Initialized
INFO - 2018-06-21 14:54:15 --> Language Class Initialized
INFO - 2018-06-21 14:54:15 --> Loader Class Initialized
INFO - 2018-06-21 14:54:15 --> Helper loaded: url_helper
INFO - 2018-06-21 14:54:15 --> Helper loaded: form_helper
INFO - 2018-06-21 14:54:15 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:54:15 --> User Agent Class Initialized
INFO - 2018-06-21 14:54:15 --> Controller Class Initialized
INFO - 2018-06-21 14:54:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:54:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-06-21 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:54:15 --> Final output sent to browser
DEBUG - 2018-06-21 14:54:15 --> Total execution time: 0.0483
INFO - 2018-06-21 14:54:32 --> Config Class Initialized
INFO - 2018-06-21 14:54:32 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:54:32 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:54:32 --> Utf8 Class Initialized
INFO - 2018-06-21 14:54:32 --> URI Class Initialized
INFO - 2018-06-21 14:54:32 --> Router Class Initialized
INFO - 2018-06-21 14:54:32 --> Output Class Initialized
INFO - 2018-06-21 14:54:32 --> Security Class Initialized
DEBUG - 2018-06-21 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:54:32 --> CSRF cookie sent
INFO - 2018-06-21 14:54:32 --> Input Class Initialized
INFO - 2018-06-21 14:54:32 --> Language Class Initialized
INFO - 2018-06-21 14:54:32 --> Loader Class Initialized
INFO - 2018-06-21 14:54:32 --> Helper loaded: url_helper
INFO - 2018-06-21 14:54:32 --> Helper loaded: form_helper
INFO - 2018-06-21 14:54:32 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:54:32 --> User Agent Class Initialized
INFO - 2018-06-21 14:54:32 --> Controller Class Initialized
INFO - 2018-06-21 14:54:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:54:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:54:32 --> Pixel_Model class loaded
INFO - 2018-06-21 14:54:32 --> Database Driver Class Initialized
INFO - 2018-06-21 14:54:32 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 14:54:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:54:32 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_lawyer.php
INFO - 2018-06-21 14:54:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:54:32 --> Final output sent to browser
DEBUG - 2018-06-21 14:54:32 --> Total execution time: 0.0570
INFO - 2018-06-21 14:54:49 --> Config Class Initialized
INFO - 2018-06-21 14:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:54:49 --> Utf8 Class Initialized
INFO - 2018-06-21 14:54:49 --> URI Class Initialized
INFO - 2018-06-21 14:54:49 --> Router Class Initialized
INFO - 2018-06-21 14:54:49 --> Output Class Initialized
INFO - 2018-06-21 14:54:49 --> Security Class Initialized
DEBUG - 2018-06-21 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:54:49 --> CSRF cookie sent
INFO - 2018-06-21 14:54:49 --> Input Class Initialized
INFO - 2018-06-21 14:54:49 --> Language Class Initialized
INFO - 2018-06-21 14:54:49 --> Loader Class Initialized
INFO - 2018-06-21 14:54:49 --> Helper loaded: url_helper
INFO - 2018-06-21 14:54:49 --> Helper loaded: form_helper
INFO - 2018-06-21 14:54:49 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:54:49 --> User Agent Class Initialized
INFO - 2018-06-21 14:54:49 --> Controller Class Initialized
INFO - 2018-06-21 14:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:54:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:54:49 --> Config Class Initialized
INFO - 2018-06-21 14:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:54:49 --> Utf8 Class Initialized
INFO - 2018-06-21 14:54:49 --> URI Class Initialized
INFO - 2018-06-21 14:54:49 --> Router Class Initialized
INFO - 2018-06-21 14:54:49 --> Output Class Initialized
INFO - 2018-06-21 14:54:49 --> Security Class Initialized
DEBUG - 2018-06-21 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:54:49 --> CSRF cookie sent
INFO - 2018-06-21 14:54:49 --> Input Class Initialized
INFO - 2018-06-21 14:54:49 --> Language Class Initialized
INFO - 2018-06-21 14:54:49 --> Loader Class Initialized
INFO - 2018-06-21 14:54:49 --> Helper loaded: url_helper
INFO - 2018-06-21 14:54:49 --> Helper loaded: form_helper
INFO - 2018-06-21 14:54:49 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:54:49 --> User Agent Class Initialized
INFO - 2018-06-21 14:54:49 --> Controller Class Initialized
INFO - 2018-06-21 14:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:54:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 14:54:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:54:49 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 14:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:54:49 --> Final output sent to browser
DEBUG - 2018-06-21 14:54:49 --> Total execution time: 0.0487
INFO - 2018-06-21 14:55:06 --> Config Class Initialized
INFO - 2018-06-21 14:55:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:55:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:55:06 --> Utf8 Class Initialized
INFO - 2018-06-21 14:55:06 --> URI Class Initialized
INFO - 2018-06-21 14:55:06 --> Router Class Initialized
INFO - 2018-06-21 14:55:06 --> Output Class Initialized
INFO - 2018-06-21 14:55:06 --> Security Class Initialized
DEBUG - 2018-06-21 14:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:55:06 --> CSRF cookie sent
INFO - 2018-06-21 14:55:06 --> Input Class Initialized
INFO - 2018-06-21 14:55:06 --> Language Class Initialized
INFO - 2018-06-21 14:55:06 --> Loader Class Initialized
INFO - 2018-06-21 14:55:06 --> Helper loaded: url_helper
INFO - 2018-06-21 14:55:06 --> Helper loaded: form_helper
INFO - 2018-06-21 14:55:06 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:55:06 --> User Agent Class Initialized
INFO - 2018-06-21 14:55:06 --> Controller Class Initialized
INFO - 2018-06-21 14:55:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:55:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 14:55:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 14:55:06 --> Could not find the language line "req_email"
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-06-21 14:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:55:06 --> Final output sent to browser
DEBUG - 2018-06-21 14:55:06 --> Total execution time: 0.0772
INFO - 2018-06-21 14:55:24 --> Config Class Initialized
INFO - 2018-06-21 14:55:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:55:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:55:24 --> Utf8 Class Initialized
INFO - 2018-06-21 14:55:24 --> URI Class Initialized
INFO - 2018-06-21 14:55:24 --> Router Class Initialized
INFO - 2018-06-21 14:55:24 --> Output Class Initialized
INFO - 2018-06-21 14:55:24 --> Security Class Initialized
DEBUG - 2018-06-21 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:55:24 --> CSRF cookie sent
INFO - 2018-06-21 14:55:24 --> Input Class Initialized
INFO - 2018-06-21 14:55:24 --> Language Class Initialized
INFO - 2018-06-21 14:55:24 --> Loader Class Initialized
INFO - 2018-06-21 14:55:24 --> Helper loaded: url_helper
INFO - 2018-06-21 14:55:24 --> Helper loaded: form_helper
INFO - 2018-06-21 14:55:24 --> Helper loaded: language_helper
DEBUG - 2018-06-21 14:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 14:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 14:55:24 --> User Agent Class Initialized
INFO - 2018-06-21 14:55:24 --> Controller Class Initialized
INFO - 2018-06-21 14:55:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 14:55:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-06-21 14:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 14:55:24 --> Final output sent to browser
DEBUG - 2018-06-21 14:55:24 --> Total execution time: 0.0313
INFO - 2018-06-21 14:56:02 --> Config Class Initialized
INFO - 2018-06-21 14:56:02 --> Hooks Class Initialized
DEBUG - 2018-06-21 14:56:02 --> UTF-8 Support Enabled
INFO - 2018-06-21 14:56:02 --> Utf8 Class Initialized
INFO - 2018-06-21 14:56:02 --> URI Class Initialized
INFO - 2018-06-21 14:56:02 --> Router Class Initialized
INFO - 2018-06-21 14:56:02 --> Output Class Initialized
INFO - 2018-06-21 14:56:02 --> Security Class Initialized
DEBUG - 2018-06-21 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 14:56:02 --> CSRF cookie sent
INFO - 2018-06-21 14:56:02 --> Input Class Initialized
INFO - 2018-06-21 14:56:02 --> Language Class Initialized
ERROR - 2018-06-21 14:56:02 --> 404 Page Not Found: Assets/js
INFO - 2018-06-21 15:39:54 --> Config Class Initialized
INFO - 2018-06-21 15:39:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 15:39:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 15:39:54 --> Utf8 Class Initialized
INFO - 2018-06-21 15:39:54 --> URI Class Initialized
DEBUG - 2018-06-21 15:39:54 --> No URI present. Default controller set.
INFO - 2018-06-21 15:39:54 --> Router Class Initialized
INFO - 2018-06-21 15:39:54 --> Output Class Initialized
INFO - 2018-06-21 15:39:54 --> Security Class Initialized
DEBUG - 2018-06-21 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 15:39:54 --> CSRF cookie sent
INFO - 2018-06-21 15:39:54 --> Input Class Initialized
INFO - 2018-06-21 15:39:54 --> Language Class Initialized
INFO - 2018-06-21 15:39:54 --> Loader Class Initialized
INFO - 2018-06-21 15:39:54 --> Helper loaded: url_helper
INFO - 2018-06-21 15:39:54 --> Helper loaded: form_helper
INFO - 2018-06-21 15:39:54 --> Helper loaded: language_helper
DEBUG - 2018-06-21 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 15:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 15:39:54 --> User Agent Class Initialized
INFO - 2018-06-21 15:39:54 --> Controller Class Initialized
INFO - 2018-06-21 15:39:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 15:39:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 15:39:54 --> Pixel_Model class loaded
INFO - 2018-06-21 15:39:54 --> Database Driver Class Initialized
INFO - 2018-06-21 15:39:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 15:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 15:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 15:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 15:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 15:39:54 --> Final output sent to browser
DEBUG - 2018-06-21 15:39:54 --> Total execution time: 0.1052
INFO - 2018-06-21 16:51:03 --> Config Class Initialized
INFO - 2018-06-21 16:51:03 --> Hooks Class Initialized
DEBUG - 2018-06-21 16:51:03 --> UTF-8 Support Enabled
INFO - 2018-06-21 16:51:03 --> Utf8 Class Initialized
INFO - 2018-06-21 16:51:03 --> URI Class Initialized
DEBUG - 2018-06-21 16:51:03 --> No URI present. Default controller set.
INFO - 2018-06-21 16:51:03 --> Router Class Initialized
INFO - 2018-06-21 16:51:03 --> Output Class Initialized
INFO - 2018-06-21 16:51:03 --> Security Class Initialized
DEBUG - 2018-06-21 16:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 16:51:03 --> CSRF cookie sent
INFO - 2018-06-21 16:51:03 --> Input Class Initialized
INFO - 2018-06-21 16:51:03 --> Language Class Initialized
INFO - 2018-06-21 16:51:03 --> Loader Class Initialized
INFO - 2018-06-21 16:51:03 --> Helper loaded: url_helper
INFO - 2018-06-21 16:51:03 --> Helper loaded: form_helper
INFO - 2018-06-21 16:51:03 --> Helper loaded: language_helper
DEBUG - 2018-06-21 16:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 16:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 16:51:03 --> User Agent Class Initialized
INFO - 2018-06-21 16:51:03 --> Controller Class Initialized
INFO - 2018-06-21 16:51:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 16:51:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 16:51:03 --> Pixel_Model class loaded
INFO - 2018-06-21 16:51:03 --> Database Driver Class Initialized
INFO - 2018-06-21 16:51:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 16:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 16:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 16:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 16:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 16:51:03 --> Final output sent to browser
DEBUG - 2018-06-21 16:51:03 --> Total execution time: 0.0904
INFO - 2018-06-21 16:55:35 --> Config Class Initialized
INFO - 2018-06-21 16:55:35 --> Hooks Class Initialized
DEBUG - 2018-06-21 16:55:35 --> UTF-8 Support Enabled
INFO - 2018-06-21 16:55:35 --> Utf8 Class Initialized
INFO - 2018-06-21 16:55:35 --> URI Class Initialized
DEBUG - 2018-06-21 16:55:35 --> No URI present. Default controller set.
INFO - 2018-06-21 16:55:35 --> Router Class Initialized
INFO - 2018-06-21 16:55:35 --> Output Class Initialized
INFO - 2018-06-21 16:55:35 --> Security Class Initialized
DEBUG - 2018-06-21 16:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 16:55:35 --> CSRF cookie sent
INFO - 2018-06-21 16:55:35 --> Input Class Initialized
INFO - 2018-06-21 16:55:35 --> Language Class Initialized
INFO - 2018-06-21 16:55:35 --> Loader Class Initialized
INFO - 2018-06-21 16:55:35 --> Helper loaded: url_helper
INFO - 2018-06-21 16:55:35 --> Helper loaded: form_helper
INFO - 2018-06-21 16:55:35 --> Helper loaded: language_helper
DEBUG - 2018-06-21 16:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 16:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 16:55:35 --> User Agent Class Initialized
INFO - 2018-06-21 16:55:35 --> Controller Class Initialized
INFO - 2018-06-21 16:55:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 16:55:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 16:55:35 --> Pixel_Model class loaded
INFO - 2018-06-21 16:55:35 --> Database Driver Class Initialized
INFO - 2018-06-21 16:55:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 16:55:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 16:55:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 16:55:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 16:55:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 16:55:35 --> Final output sent to browser
DEBUG - 2018-06-21 16:55:35 --> Total execution time: 0.0795
INFO - 2018-06-21 17:09:17 --> Config Class Initialized
INFO - 2018-06-21 17:09:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:17 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:17 --> URI Class Initialized
DEBUG - 2018-06-21 17:09:17 --> No URI present. Default controller set.
INFO - 2018-06-21 17:09:17 --> Router Class Initialized
INFO - 2018-06-21 17:09:17 --> Output Class Initialized
INFO - 2018-06-21 17:09:17 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:17 --> CSRF cookie sent
INFO - 2018-06-21 17:09:17 --> Input Class Initialized
INFO - 2018-06-21 17:09:17 --> Language Class Initialized
INFO - 2018-06-21 17:09:17 --> Loader Class Initialized
INFO - 2018-06-21 17:09:17 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:17 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:17 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:17 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:17 --> Controller Class Initialized
INFO - 2018-06-21 17:09:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:17 --> Pixel_Model class loaded
INFO - 2018-06-21 17:09:17 --> Database Driver Class Initialized
INFO - 2018-06-21 17:09:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:09:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:09:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:17 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:17 --> Total execution time: 0.0660
INFO - 2018-06-21 17:09:18 --> Config Class Initialized
INFO - 2018-06-21 17:09:18 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:18 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:18 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:18 --> URI Class Initialized
DEBUG - 2018-06-21 17:09:18 --> No URI present. Default controller set.
INFO - 2018-06-21 17:09:18 --> Router Class Initialized
INFO - 2018-06-21 17:09:18 --> Output Class Initialized
INFO - 2018-06-21 17:09:18 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:18 --> CSRF cookie sent
INFO - 2018-06-21 17:09:18 --> Input Class Initialized
INFO - 2018-06-21 17:09:18 --> Language Class Initialized
INFO - 2018-06-21 17:09:18 --> Loader Class Initialized
INFO - 2018-06-21 17:09:18 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:18 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:18 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:18 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:18 --> Controller Class Initialized
INFO - 2018-06-21 17:09:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:18 --> Pixel_Model class loaded
INFO - 2018-06-21 17:09:18 --> Database Driver Class Initialized
INFO - 2018-06-21 17:09:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:09:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:09:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:18 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:18 --> Total execution time: 0.0801
INFO - 2018-06-21 17:09:19 --> Config Class Initialized
INFO - 2018-06-21 17:09:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:19 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:19 --> URI Class Initialized
DEBUG - 2018-06-21 17:09:19 --> No URI present. Default controller set.
INFO - 2018-06-21 17:09:19 --> Router Class Initialized
INFO - 2018-06-21 17:09:19 --> Output Class Initialized
INFO - 2018-06-21 17:09:19 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:19 --> CSRF cookie sent
INFO - 2018-06-21 17:09:19 --> Input Class Initialized
INFO - 2018-06-21 17:09:19 --> Language Class Initialized
INFO - 2018-06-21 17:09:19 --> Loader Class Initialized
INFO - 2018-06-21 17:09:19 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:19 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:19 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:19 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:19 --> Controller Class Initialized
INFO - 2018-06-21 17:09:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:19 --> Pixel_Model class loaded
INFO - 2018-06-21 17:09:19 --> Database Driver Class Initialized
INFO - 2018-06-21 17:09:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:09:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:09:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:19 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:19 --> Total execution time: 0.0580
INFO - 2018-06-21 17:09:19 --> Config Class Initialized
INFO - 2018-06-21 17:09:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:19 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:19 --> URI Class Initialized
INFO - 2018-06-21 17:09:19 --> Router Class Initialized
INFO - 2018-06-21 17:09:19 --> Output Class Initialized
INFO - 2018-06-21 17:09:19 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:19 --> CSRF cookie sent
INFO - 2018-06-21 17:09:19 --> Input Class Initialized
INFO - 2018-06-21 17:09:19 --> Language Class Initialized
ERROR - 2018-06-21 17:09:19 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-21 17:09:26 --> Config Class Initialized
INFO - 2018-06-21 17:09:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:26 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:26 --> URI Class Initialized
DEBUG - 2018-06-21 17:09:26 --> No URI present. Default controller set.
INFO - 2018-06-21 17:09:26 --> Router Class Initialized
INFO - 2018-06-21 17:09:26 --> Output Class Initialized
INFO - 2018-06-21 17:09:26 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:26 --> CSRF cookie sent
INFO - 2018-06-21 17:09:26 --> Input Class Initialized
INFO - 2018-06-21 17:09:26 --> Language Class Initialized
INFO - 2018-06-21 17:09:26 --> Loader Class Initialized
INFO - 2018-06-21 17:09:26 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:26 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:26 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:26 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:26 --> Controller Class Initialized
INFO - 2018-06-21 17:09:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:26 --> Pixel_Model class loaded
INFO - 2018-06-21 17:09:26 --> Database Driver Class Initialized
INFO - 2018-06-21 17:09:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:09:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:09:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:26 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:26 --> Total execution time: 0.0919
INFO - 2018-06-21 17:09:26 --> Config Class Initialized
INFO - 2018-06-21 17:09:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:26 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:26 --> URI Class Initialized
INFO - 2018-06-21 17:09:26 --> Router Class Initialized
INFO - 2018-06-21 17:09:26 --> Output Class Initialized
INFO - 2018-06-21 17:09:26 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:26 --> CSRF cookie sent
INFO - 2018-06-21 17:09:26 --> Input Class Initialized
INFO - 2018-06-21 17:09:26 --> Language Class Initialized
ERROR - 2018-06-21 17:09:26 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-21 17:09:27 --> Config Class Initialized
INFO - 2018-06-21 17:09:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:27 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:27 --> URI Class Initialized
INFO - 2018-06-21 17:09:27 --> Router Class Initialized
INFO - 2018-06-21 17:09:27 --> Output Class Initialized
INFO - 2018-06-21 17:09:27 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:27 --> CSRF cookie sent
INFO - 2018-06-21 17:09:27 --> Input Class Initialized
INFO - 2018-06-21 17:09:27 --> Language Class Initialized
ERROR - 2018-06-21 17:09:27 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-21 17:09:27 --> Config Class Initialized
INFO - 2018-06-21 17:09:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:27 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:27 --> URI Class Initialized
INFO - 2018-06-21 17:09:27 --> Router Class Initialized
INFO - 2018-06-21 17:09:27 --> Output Class Initialized
INFO - 2018-06-21 17:09:27 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:27 --> CSRF cookie sent
INFO - 2018-06-21 17:09:27 --> Input Class Initialized
INFO - 2018-06-21 17:09:27 --> Language Class Initialized
INFO - 2018-06-21 17:09:27 --> Loader Class Initialized
INFO - 2018-06-21 17:09:27 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:27 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:27 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:27 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:27 --> Controller Class Initialized
INFO - 2018-06-21 17:09:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:27 --> Pixel_Model class loaded
INFO - 2018-06-21 17:09:27 --> Database Driver Class Initialized
INFO - 2018-06-21 17:09:27 --> Model "QuestionsModel" initialized
ERROR - 2018-06-21 17:09:27 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-21 17:09:27 --> Config Class Initialized
INFO - 2018-06-21 17:09:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:27 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:27 --> URI Class Initialized
INFO - 2018-06-21 17:09:27 --> Router Class Initialized
INFO - 2018-06-21 17:09:27 --> Output Class Initialized
INFO - 2018-06-21 17:09:27 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:27 --> CSRF cookie sent
INFO - 2018-06-21 17:09:27 --> Input Class Initialized
INFO - 2018-06-21 17:09:27 --> Language Class Initialized
INFO - 2018-06-21 17:09:27 --> Loader Class Initialized
INFO - 2018-06-21 17:09:27 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:27 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:27 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:27 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:27 --> Controller Class Initialized
INFO - 2018-06-21 17:09:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 17:09:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 17:09:27 --> Could not find the language line "req_email"
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 17:09:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:27 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:27 --> Total execution time: 0.0634
INFO - 2018-06-21 17:09:28 --> Config Class Initialized
INFO - 2018-06-21 17:09:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:28 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:28 --> URI Class Initialized
INFO - 2018-06-21 17:09:28 --> Router Class Initialized
INFO - 2018-06-21 17:09:28 --> Output Class Initialized
INFO - 2018-06-21 17:09:28 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:28 --> CSRF cookie sent
INFO - 2018-06-21 17:09:28 --> Input Class Initialized
INFO - 2018-06-21 17:09:28 --> Language Class Initialized
INFO - 2018-06-21 17:09:28 --> Loader Class Initialized
INFO - 2018-06-21 17:09:28 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:28 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:28 --> Controller Class Initialized
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:28 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:28 --> Total execution time: 0.0330
INFO - 2018-06-21 17:09:28 --> Config Class Initialized
INFO - 2018-06-21 17:09:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:28 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:28 --> URI Class Initialized
INFO - 2018-06-21 17:09:28 --> Router Class Initialized
INFO - 2018-06-21 17:09:28 --> Output Class Initialized
INFO - 2018-06-21 17:09:28 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:28 --> CSRF cookie sent
INFO - 2018-06-21 17:09:28 --> Input Class Initialized
INFO - 2018-06-21 17:09:28 --> Language Class Initialized
INFO - 2018-06-21 17:09:28 --> Loader Class Initialized
INFO - 2018-06-21 17:09:28 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:28 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:28 --> Controller Class Initialized
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:28 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:28 --> Total execution time: 0.0717
INFO - 2018-06-21 17:09:28 --> Config Class Initialized
INFO - 2018-06-21 17:09:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:28 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:28 --> URI Class Initialized
INFO - 2018-06-21 17:09:28 --> Router Class Initialized
INFO - 2018-06-21 17:09:28 --> Output Class Initialized
INFO - 2018-06-21 17:09:28 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:28 --> CSRF cookie sent
INFO - 2018-06-21 17:09:28 --> Input Class Initialized
INFO - 2018-06-21 17:09:28 --> Language Class Initialized
INFO - 2018-06-21 17:09:28 --> Loader Class Initialized
INFO - 2018-06-21 17:09:28 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:28 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:28 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:28 --> Controller Class Initialized
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-21 17:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:28 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:28 --> Total execution time: 0.0299
INFO - 2018-06-21 17:09:29 --> Config Class Initialized
INFO - 2018-06-21 17:09:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:29 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:29 --> URI Class Initialized
INFO - 2018-06-21 17:09:29 --> Router Class Initialized
INFO - 2018-06-21 17:09:29 --> Output Class Initialized
INFO - 2018-06-21 17:09:29 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:29 --> CSRF cookie sent
INFO - 2018-06-21 17:09:29 --> Input Class Initialized
INFO - 2018-06-21 17:09:29 --> Language Class Initialized
INFO - 2018-06-21 17:09:29 --> Loader Class Initialized
INFO - 2018-06-21 17:09:29 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:29 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:29 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:29 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:29 --> Controller Class Initialized
INFO - 2018-06-21 17:09:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:29 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:29 --> Total execution time: 0.0441
INFO - 2018-06-21 17:09:29 --> Config Class Initialized
INFO - 2018-06-21 17:09:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:29 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:29 --> URI Class Initialized
INFO - 2018-06-21 17:09:29 --> Router Class Initialized
INFO - 2018-06-21 17:09:29 --> Output Class Initialized
INFO - 2018-06-21 17:09:29 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:29 --> CSRF cookie sent
INFO - 2018-06-21 17:09:29 --> Input Class Initialized
INFO - 2018-06-21 17:09:29 --> Language Class Initialized
INFO - 2018-06-21 17:09:29 --> Loader Class Initialized
INFO - 2018-06-21 17:09:29 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:29 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:29 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:29 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:29 --> Controller Class Initialized
INFO - 2018-06-21 17:09:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 17:09:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 17:09:29 --> Could not find the language line "req_email"
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 17:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:29 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:29 --> Total execution time: 0.0459
INFO - 2018-06-21 17:09:29 --> Config Class Initialized
INFO - 2018-06-21 17:09:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:09:29 --> Utf8 Class Initialized
INFO - 2018-06-21 17:09:30 --> URI Class Initialized
INFO - 2018-06-21 17:09:30 --> Router Class Initialized
INFO - 2018-06-21 17:09:30 --> Output Class Initialized
INFO - 2018-06-21 17:09:30 --> Security Class Initialized
DEBUG - 2018-06-21 17:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:09:30 --> CSRF cookie sent
INFO - 2018-06-21 17:09:30 --> Input Class Initialized
INFO - 2018-06-21 17:09:30 --> Language Class Initialized
INFO - 2018-06-21 17:09:30 --> Loader Class Initialized
INFO - 2018-06-21 17:09:30 --> Helper loaded: url_helper
INFO - 2018-06-21 17:09:30 --> Helper loaded: form_helper
INFO - 2018-06-21 17:09:30 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:09:30 --> User Agent Class Initialized
INFO - 2018-06-21 17:09:30 --> Controller Class Initialized
INFO - 2018-06-21 17:09:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:09:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-21 17:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:09:30 --> Final output sent to browser
DEBUG - 2018-06-21 17:09:30 --> Total execution time: 0.0445
INFO - 2018-06-21 17:51:17 --> Config Class Initialized
INFO - 2018-06-21 17:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:51:17 --> Utf8 Class Initialized
INFO - 2018-06-21 17:51:17 --> URI Class Initialized
DEBUG - 2018-06-21 17:51:17 --> No URI present. Default controller set.
INFO - 2018-06-21 17:51:17 --> Router Class Initialized
INFO - 2018-06-21 17:51:17 --> Output Class Initialized
INFO - 2018-06-21 17:51:17 --> Security Class Initialized
DEBUG - 2018-06-21 17:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:51:17 --> CSRF cookie sent
INFO - 2018-06-21 17:51:17 --> Input Class Initialized
INFO - 2018-06-21 17:51:17 --> Language Class Initialized
INFO - 2018-06-21 17:51:17 --> Loader Class Initialized
INFO - 2018-06-21 17:51:17 --> Helper loaded: url_helper
INFO - 2018-06-21 17:51:17 --> Helper loaded: form_helper
INFO - 2018-06-21 17:51:17 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:51:17 --> User Agent Class Initialized
INFO - 2018-06-21 17:51:17 --> Controller Class Initialized
INFO - 2018-06-21 17:51:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:51:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:51:17 --> Pixel_Model class loaded
INFO - 2018-06-21 17:51:17 --> Database Driver Class Initialized
INFO - 2018-06-21 17:51:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:51:17 --> Final output sent to browser
DEBUG - 2018-06-21 17:51:17 --> Total execution time: 0.0589
INFO - 2018-06-21 17:52:26 --> Config Class Initialized
INFO - 2018-06-21 17:52:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:52:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:52:26 --> Utf8 Class Initialized
INFO - 2018-06-21 17:52:26 --> URI Class Initialized
INFO - 2018-06-21 17:52:26 --> Router Class Initialized
INFO - 2018-06-21 17:52:26 --> Output Class Initialized
INFO - 2018-06-21 17:52:26 --> Security Class Initialized
DEBUG - 2018-06-21 17:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:52:26 --> CSRF cookie sent
INFO - 2018-06-21 17:52:26 --> CSRF token verified
INFO - 2018-06-21 17:52:26 --> Input Class Initialized
INFO - 2018-06-21 17:52:26 --> Language Class Initialized
INFO - 2018-06-21 17:52:26 --> Loader Class Initialized
INFO - 2018-06-21 17:52:26 --> Helper loaded: url_helper
INFO - 2018-06-21 17:52:26 --> Helper loaded: form_helper
INFO - 2018-06-21 17:52:26 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:52:26 --> User Agent Class Initialized
INFO - 2018-06-21 17:52:26 --> Controller Class Initialized
INFO - 2018-06-21 17:52:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:52:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:52:26 --> Pixel_Model class loaded
INFO - 2018-06-21 17:52:26 --> Database Driver Class Initialized
INFO - 2018-06-21 17:52:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:52:26 --> Config Class Initialized
INFO - 2018-06-21 17:52:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:52:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:52:26 --> Utf8 Class Initialized
INFO - 2018-06-21 17:52:26 --> URI Class Initialized
INFO - 2018-06-21 17:52:26 --> Router Class Initialized
INFO - 2018-06-21 17:52:26 --> Output Class Initialized
INFO - 2018-06-21 17:52:26 --> Security Class Initialized
DEBUG - 2018-06-21 17:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:52:26 --> CSRF cookie sent
INFO - 2018-06-21 17:52:26 --> Input Class Initialized
INFO - 2018-06-21 17:52:26 --> Language Class Initialized
INFO - 2018-06-21 17:52:26 --> Loader Class Initialized
INFO - 2018-06-21 17:52:26 --> Helper loaded: url_helper
INFO - 2018-06-21 17:52:26 --> Helper loaded: form_helper
INFO - 2018-06-21 17:52:26 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:52:26 --> User Agent Class Initialized
INFO - 2018-06-21 17:52:26 --> Controller Class Initialized
INFO - 2018-06-21 17:52:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:52:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 17:52:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 17:52:26 --> Could not find the language line "req_email"
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-21 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:52:26 --> Final output sent to browser
DEBUG - 2018-06-21 17:52:26 --> Total execution time: 0.0394
INFO - 2018-06-21 17:52:54 --> Config Class Initialized
INFO - 2018-06-21 17:52:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:52:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:52:54 --> Utf8 Class Initialized
INFO - 2018-06-21 17:52:54 --> URI Class Initialized
INFO - 2018-06-21 17:52:54 --> Router Class Initialized
INFO - 2018-06-21 17:52:54 --> Output Class Initialized
INFO - 2018-06-21 17:52:54 --> Security Class Initialized
DEBUG - 2018-06-21 17:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:52:54 --> CSRF cookie sent
INFO - 2018-06-21 17:52:54 --> Input Class Initialized
INFO - 2018-06-21 17:52:54 --> Language Class Initialized
INFO - 2018-06-21 17:52:54 --> Loader Class Initialized
INFO - 2018-06-21 17:52:54 --> Helper loaded: url_helper
INFO - 2018-06-21 17:52:54 --> Helper loaded: form_helper
INFO - 2018-06-21 17:52:54 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:52:54 --> User Agent Class Initialized
INFO - 2018-06-21 17:52:54 --> Controller Class Initialized
INFO - 2018-06-21 17:52:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:52:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:52:54 --> Pixel_Model class loaded
INFO - 2018-06-21 17:52:54 --> Database Driver Class Initialized
INFO - 2018-06-21 17:52:54 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-21 17:52:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-21 17:52:54 --> Could not find the language line "req_email"
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-21 17:52:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:52:54 --> Final output sent to browser
DEBUG - 2018-06-21 17:52:54 --> Total execution time: 0.0501
INFO - 2018-06-21 17:53:28 --> Config Class Initialized
INFO - 2018-06-21 17:53:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:53:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:53:28 --> Utf8 Class Initialized
INFO - 2018-06-21 17:53:28 --> URI Class Initialized
DEBUG - 2018-06-21 17:53:28 --> No URI present. Default controller set.
INFO - 2018-06-21 17:53:28 --> Router Class Initialized
INFO - 2018-06-21 17:53:28 --> Output Class Initialized
INFO - 2018-06-21 17:53:28 --> Security Class Initialized
DEBUG - 2018-06-21 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:53:28 --> CSRF cookie sent
INFO - 2018-06-21 17:53:28 --> Input Class Initialized
INFO - 2018-06-21 17:53:28 --> Language Class Initialized
INFO - 2018-06-21 17:53:28 --> Loader Class Initialized
INFO - 2018-06-21 17:53:28 --> Helper loaded: url_helper
INFO - 2018-06-21 17:53:28 --> Helper loaded: form_helper
INFO - 2018-06-21 17:53:28 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:53:28 --> User Agent Class Initialized
INFO - 2018-06-21 17:53:28 --> Controller Class Initialized
INFO - 2018-06-21 17:53:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:53:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:53:28 --> Pixel_Model class loaded
INFO - 2018-06-21 17:53:28 --> Database Driver Class Initialized
INFO - 2018-06-21 17:53:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 17:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:53:28 --> Final output sent to browser
DEBUG - 2018-06-21 17:53:28 --> Total execution time: 0.0585
INFO - 2018-06-21 17:54:30 --> Config Class Initialized
INFO - 2018-06-21 17:54:30 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:54:30 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:54:30 --> Utf8 Class Initialized
INFO - 2018-06-21 17:54:30 --> URI Class Initialized
INFO - 2018-06-21 17:54:30 --> Router Class Initialized
INFO - 2018-06-21 17:54:30 --> Output Class Initialized
INFO - 2018-06-21 17:54:30 --> Security Class Initialized
DEBUG - 2018-06-21 17:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:54:30 --> CSRF cookie sent
INFO - 2018-06-21 17:54:30 --> CSRF token verified
INFO - 2018-06-21 17:54:30 --> Input Class Initialized
INFO - 2018-06-21 17:54:30 --> Language Class Initialized
INFO - 2018-06-21 17:54:30 --> Loader Class Initialized
INFO - 2018-06-21 17:54:30 --> Helper loaded: url_helper
INFO - 2018-06-21 17:54:30 --> Helper loaded: form_helper
INFO - 2018-06-21 17:54:30 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:54:30 --> User Agent Class Initialized
INFO - 2018-06-21 17:54:30 --> Controller Class Initialized
INFO - 2018-06-21 17:54:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:54:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-21 17:54:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-21 17:54:30 --> Form Validation Class Initialized
INFO - 2018-06-21 17:54:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-21 17:54:30 --> Pixel_Model class loaded
INFO - 2018-06-21 17:54:30 --> Database Driver Class Initialized
INFO - 2018-06-21 17:54:30 --> Model "RegistrationModel" initialized
INFO - 2018-06-21 17:54:30 --> Helper loaded: string_helper
INFO - 2018-06-21 17:54:30 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-06-21 17:54:31 --> Database Driver Class Initialized
INFO - 2018-06-21 17:54:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-06-21 17:54:31 --> Email Class Initialized
INFO - 2018-06-21 17:54:31 --> Language file loaded: language/english/email_lang.php
INFO - 2018-06-21 17:54:31 --> Config Class Initialized
INFO - 2018-06-21 17:54:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:54:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:54:31 --> Utf8 Class Initialized
INFO - 2018-06-21 17:54:31 --> URI Class Initialized
INFO - 2018-06-21 17:54:31 --> Router Class Initialized
INFO - 2018-06-21 17:54:31 --> Output Class Initialized
INFO - 2018-06-21 17:54:31 --> Security Class Initialized
DEBUG - 2018-06-21 17:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:54:31 --> CSRF cookie sent
INFO - 2018-06-21 17:54:31 --> Input Class Initialized
INFO - 2018-06-21 17:54:31 --> Language Class Initialized
INFO - 2018-06-21 17:54:31 --> Loader Class Initialized
INFO - 2018-06-21 17:54:31 --> Helper loaded: url_helper
INFO - 2018-06-21 17:54:31 --> Helper loaded: form_helper
INFO - 2018-06-21 17:54:31 --> Helper loaded: language_helper
DEBUG - 2018-06-21 17:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 17:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 17:54:31 --> User Agent Class Initialized
INFO - 2018-06-21 17:54:31 --> Controller Class Initialized
INFO - 2018-06-21 17:54:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 17:54:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/thanks.php
INFO - 2018-06-21 17:54:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 17:54:31 --> Final output sent to browser
DEBUG - 2018-06-21 17:54:31 --> Total execution time: 0.0664
INFO - 2018-06-21 17:55:33 --> Config Class Initialized
INFO - 2018-06-21 17:55:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 17:55:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 17:55:33 --> Utf8 Class Initialized
INFO - 2018-06-21 17:55:33 --> URI Class Initialized
INFO - 2018-06-21 17:55:33 --> Router Class Initialized
INFO - 2018-06-21 17:55:33 --> Output Class Initialized
INFO - 2018-06-21 17:55:33 --> Security Class Initialized
DEBUG - 2018-06-21 17:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 17:55:33 --> CSRF cookie sent
INFO - 2018-06-21 17:55:33 --> Input Class Initialized
INFO - 2018-06-21 17:55:33 --> Language Class Initialized
ERROR - 2018-06-21 17:55:33 --> 404 Page Not Found: Assets/images
INFO - 2018-06-21 20:55:01 --> Config Class Initialized
INFO - 2018-06-21 20:55:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 20:55:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 20:55:01 --> Utf8 Class Initialized
INFO - 2018-06-21 20:55:01 --> URI Class Initialized
DEBUG - 2018-06-21 20:55:01 --> No URI present. Default controller set.
INFO - 2018-06-21 20:55:01 --> Router Class Initialized
INFO - 2018-06-21 20:55:01 --> Output Class Initialized
INFO - 2018-06-21 20:55:01 --> Security Class Initialized
DEBUG - 2018-06-21 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 20:55:01 --> CSRF cookie sent
INFO - 2018-06-21 20:55:01 --> Input Class Initialized
INFO - 2018-06-21 20:55:01 --> Language Class Initialized
INFO - 2018-06-21 20:55:01 --> Loader Class Initialized
INFO - 2018-06-21 20:55:01 --> Helper loaded: url_helper
INFO - 2018-06-21 20:55:01 --> Helper loaded: form_helper
INFO - 2018-06-21 20:55:01 --> Helper loaded: language_helper
DEBUG - 2018-06-21 20:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 20:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 20:55:01 --> User Agent Class Initialized
INFO - 2018-06-21 20:55:01 --> Controller Class Initialized
INFO - 2018-06-21 20:55:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-21 20:55:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-21 20:55:01 --> Pixel_Model class loaded
INFO - 2018-06-21 20:55:01 --> Database Driver Class Initialized
INFO - 2018-06-21 20:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-21 20:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-21 20:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-21 20:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-21 20:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-21 20:55:01 --> Final output sent to browser
DEBUG - 2018-06-21 20:55:01 --> Total execution time: 0.0561

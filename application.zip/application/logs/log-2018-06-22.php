<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-22 01:33:55 --> Config Class Initialized
INFO - 2018-06-22 01:33:55 --> Hooks Class Initialized
DEBUG - 2018-06-22 01:33:55 --> UTF-8 Support Enabled
INFO - 2018-06-22 01:33:55 --> Utf8 Class Initialized
INFO - 2018-06-22 01:33:55 --> URI Class Initialized
DEBUG - 2018-06-22 01:33:55 --> No URI present. Default controller set.
INFO - 2018-06-22 01:33:55 --> Router Class Initialized
INFO - 2018-06-22 01:33:55 --> Output Class Initialized
INFO - 2018-06-22 01:33:55 --> Security Class Initialized
DEBUG - 2018-06-22 01:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 01:33:55 --> CSRF cookie sent
INFO - 2018-06-22 01:33:55 --> Input Class Initialized
INFO - 2018-06-22 01:33:55 --> Language Class Initialized
INFO - 2018-06-22 01:33:55 --> Loader Class Initialized
INFO - 2018-06-22 01:33:55 --> Helper loaded: url_helper
INFO - 2018-06-22 01:33:55 --> Helper loaded: form_helper
INFO - 2018-06-22 01:33:55 --> Helper loaded: language_helper
DEBUG - 2018-06-22 01:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 01:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 01:33:55 --> User Agent Class Initialized
INFO - 2018-06-22 01:33:55 --> Controller Class Initialized
INFO - 2018-06-22 01:33:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 01:33:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 01:33:55 --> Pixel_Model class loaded
INFO - 2018-06-22 01:33:55 --> Database Driver Class Initialized
INFO - 2018-06-22 01:33:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 01:33:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 01:33:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 01:33:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 01:33:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 01:33:55 --> Final output sent to browser
DEBUG - 2018-06-22 01:33:55 --> Total execution time: 0.0427
INFO - 2018-06-22 01:34:03 --> Config Class Initialized
INFO - 2018-06-22 01:34:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 01:34:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 01:34:03 --> Utf8 Class Initialized
INFO - 2018-06-22 01:34:03 --> URI Class Initialized
INFO - 2018-06-22 01:34:03 --> Router Class Initialized
INFO - 2018-06-22 01:34:03 --> Output Class Initialized
INFO - 2018-06-22 01:34:03 --> Security Class Initialized
DEBUG - 2018-06-22 01:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 01:34:03 --> CSRF cookie sent
INFO - 2018-06-22 01:34:03 --> CSRF token verified
INFO - 2018-06-22 01:34:03 --> Input Class Initialized
INFO - 2018-06-22 01:34:03 --> Language Class Initialized
INFO - 2018-06-22 01:34:03 --> Loader Class Initialized
INFO - 2018-06-22 01:34:03 --> Helper loaded: url_helper
INFO - 2018-06-22 01:34:03 --> Helper loaded: form_helper
INFO - 2018-06-22 01:34:03 --> Helper loaded: language_helper
DEBUG - 2018-06-22 01:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 01:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 01:34:03 --> User Agent Class Initialized
INFO - 2018-06-22 01:34:03 --> Controller Class Initialized
INFO - 2018-06-22 01:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 01:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 01:34:03 --> Pixel_Model class loaded
INFO - 2018-06-22 01:34:03 --> Database Driver Class Initialized
INFO - 2018-06-22 01:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 01:34:03 --> Config Class Initialized
INFO - 2018-06-22 01:34:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 01:34:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 01:34:03 --> Utf8 Class Initialized
INFO - 2018-06-22 01:34:03 --> URI Class Initialized
INFO - 2018-06-22 01:34:03 --> Router Class Initialized
INFO - 2018-06-22 01:34:03 --> Output Class Initialized
INFO - 2018-06-22 01:34:03 --> Security Class Initialized
DEBUG - 2018-06-22 01:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 01:34:03 --> CSRF cookie sent
INFO - 2018-06-22 01:34:03 --> Input Class Initialized
INFO - 2018-06-22 01:34:03 --> Language Class Initialized
INFO - 2018-06-22 01:34:03 --> Loader Class Initialized
INFO - 2018-06-22 01:34:03 --> Helper loaded: url_helper
INFO - 2018-06-22 01:34:03 --> Helper loaded: form_helper
INFO - 2018-06-22 01:34:03 --> Helper loaded: language_helper
DEBUG - 2018-06-22 01:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 01:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 01:34:03 --> User Agent Class Initialized
INFO - 2018-06-22 01:34:03 --> Controller Class Initialized
INFO - 2018-06-22 01:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 01:34:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 01:34:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 01:34:03 --> Could not find the language line "req_email"
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 01:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 01:34:03 --> Final output sent to browser
DEBUG - 2018-06-22 01:34:03 --> Total execution time: 0.0293
INFO - 2018-06-22 01:34:21 --> Config Class Initialized
INFO - 2018-06-22 01:34:21 --> Hooks Class Initialized
DEBUG - 2018-06-22 01:34:21 --> UTF-8 Support Enabled
INFO - 2018-06-22 01:34:21 --> Utf8 Class Initialized
INFO - 2018-06-22 01:34:21 --> URI Class Initialized
INFO - 2018-06-22 01:34:21 --> Router Class Initialized
INFO - 2018-06-22 01:34:21 --> Output Class Initialized
INFO - 2018-06-22 01:34:21 --> Security Class Initialized
DEBUG - 2018-06-22 01:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 01:34:21 --> CSRF cookie sent
INFO - 2018-06-22 01:34:21 --> Input Class Initialized
INFO - 2018-06-22 01:34:21 --> Language Class Initialized
INFO - 2018-06-22 01:34:21 --> Loader Class Initialized
INFO - 2018-06-22 01:34:21 --> Helper loaded: url_helper
INFO - 2018-06-22 01:34:21 --> Helper loaded: form_helper
INFO - 2018-06-22 01:34:21 --> Helper loaded: language_helper
DEBUG - 2018-06-22 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 01:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 01:34:21 --> User Agent Class Initialized
INFO - 2018-06-22 01:34:21 --> Controller Class Initialized
INFO - 2018-06-22 01:34:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 01:34:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 01:34:21 --> Pixel_Model class loaded
INFO - 2018-06-22 01:34:21 --> Database Driver Class Initialized
INFO - 2018-06-22 01:34:21 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 01:34:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 01:34:21 --> Could not find the language line "req_email"
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-22 01:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 01:34:21 --> Final output sent to browser
DEBUG - 2018-06-22 01:34:21 --> Total execution time: 0.0674
INFO - 2018-06-22 03:24:31 --> Config Class Initialized
INFO - 2018-06-22 03:24:31 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:31 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:31 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:31 --> URI Class Initialized
INFO - 2018-06-22 03:24:31 --> Router Class Initialized
INFO - 2018-06-22 03:24:31 --> Output Class Initialized
INFO - 2018-06-22 03:24:31 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:31 --> CSRF cookie sent
INFO - 2018-06-22 03:24:31 --> Input Class Initialized
INFO - 2018-06-22 03:24:31 --> Language Class Initialized
ERROR - 2018-06-22 03:24:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-22 03:24:34 --> Config Class Initialized
INFO - 2018-06-22 03:24:34 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:34 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:34 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:34 --> URI Class Initialized
INFO - 2018-06-22 03:24:34 --> Router Class Initialized
INFO - 2018-06-22 03:24:34 --> Output Class Initialized
INFO - 2018-06-22 03:24:34 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:34 --> CSRF cookie sent
INFO - 2018-06-22 03:24:34 --> Input Class Initialized
INFO - 2018-06-22 03:24:34 --> Language Class Initialized
INFO - 2018-06-22 03:24:34 --> Loader Class Initialized
INFO - 2018-06-22 03:24:34 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:34 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:34 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:34 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:34 --> Controller Class Initialized
INFO - 2018-06-22 03:24:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-22 03:24:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:34 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:34 --> Total execution time: 0.0237
INFO - 2018-06-22 03:24:37 --> Config Class Initialized
INFO - 2018-06-22 03:24:37 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:37 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:37 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:37 --> URI Class Initialized
INFO - 2018-06-22 03:24:37 --> Router Class Initialized
INFO - 2018-06-22 03:24:37 --> Output Class Initialized
INFO - 2018-06-22 03:24:37 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:37 --> CSRF cookie sent
INFO - 2018-06-22 03:24:37 --> Input Class Initialized
INFO - 2018-06-22 03:24:37 --> Language Class Initialized
INFO - 2018-06-22 03:24:37 --> Loader Class Initialized
INFO - 2018-06-22 03:24:37 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:37 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:37 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:37 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:37 --> Controller Class Initialized
INFO - 2018-06-22 03:24:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-22 03:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:37 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:37 --> Total execution time: 0.0215
INFO - 2018-06-22 03:24:40 --> Config Class Initialized
INFO - 2018-06-22 03:24:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:40 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:40 --> URI Class Initialized
INFO - 2018-06-22 03:24:40 --> Router Class Initialized
INFO - 2018-06-22 03:24:40 --> Output Class Initialized
INFO - 2018-06-22 03:24:40 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:40 --> CSRF cookie sent
INFO - 2018-06-22 03:24:40 --> Input Class Initialized
INFO - 2018-06-22 03:24:40 --> Language Class Initialized
INFO - 2018-06-22 03:24:40 --> Loader Class Initialized
INFO - 2018-06-22 03:24:40 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:40 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:40 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:40 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:40 --> Controller Class Initialized
INFO - 2018-06-22 03:24:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 03:24:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 03:24:40 --> Could not find the language line "req_email"
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 03:24:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:40 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:40 --> Total execution time: 0.0224
INFO - 2018-06-22 03:24:43 --> Config Class Initialized
INFO - 2018-06-22 03:24:43 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:43 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:43 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:43 --> URI Class Initialized
INFO - 2018-06-22 03:24:43 --> Router Class Initialized
INFO - 2018-06-22 03:24:43 --> Output Class Initialized
INFO - 2018-06-22 03:24:43 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:43 --> CSRF cookie sent
INFO - 2018-06-22 03:24:43 --> Input Class Initialized
INFO - 2018-06-22 03:24:43 --> Language Class Initialized
INFO - 2018-06-22 03:24:43 --> Loader Class Initialized
INFO - 2018-06-22 03:24:43 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:43 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:43 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:43 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:43 --> Controller Class Initialized
INFO - 2018-06-22 03:24:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-22 03:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:43 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:43 --> Total execution time: 0.0274
INFO - 2018-06-22 03:24:47 --> Config Class Initialized
INFO - 2018-06-22 03:24:47 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:47 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:47 --> URI Class Initialized
INFO - 2018-06-22 03:24:47 --> Router Class Initialized
INFO - 2018-06-22 03:24:47 --> Output Class Initialized
INFO - 2018-06-22 03:24:47 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:47 --> CSRF cookie sent
INFO - 2018-06-22 03:24:47 --> Input Class Initialized
INFO - 2018-06-22 03:24:47 --> Language Class Initialized
INFO - 2018-06-22 03:24:47 --> Loader Class Initialized
INFO - 2018-06-22 03:24:47 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:47 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:47 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:47 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:47 --> Controller Class Initialized
INFO - 2018-06-22 03:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 03:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:47 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:47 --> Total execution time: 0.0233
INFO - 2018-06-22 03:24:49 --> Config Class Initialized
INFO - 2018-06-22 03:24:49 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:49 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:49 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:49 --> URI Class Initialized
INFO - 2018-06-22 03:24:49 --> Router Class Initialized
INFO - 2018-06-22 03:24:49 --> Output Class Initialized
INFO - 2018-06-22 03:24:49 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:49 --> CSRF cookie sent
INFO - 2018-06-22 03:24:49 --> Input Class Initialized
INFO - 2018-06-22 03:24:49 --> Language Class Initialized
INFO - 2018-06-22 03:24:49 --> Loader Class Initialized
INFO - 2018-06-22 03:24:49 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:49 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:49 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:49 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:49 --> Controller Class Initialized
INFO - 2018-06-22 03:24:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-22 03:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:49 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:49 --> Total execution time: 0.0205
INFO - 2018-06-22 03:24:52 --> Config Class Initialized
INFO - 2018-06-22 03:24:52 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:52 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:52 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:52 --> URI Class Initialized
INFO - 2018-06-22 03:24:52 --> Router Class Initialized
INFO - 2018-06-22 03:24:52 --> Output Class Initialized
INFO - 2018-06-22 03:24:52 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:52 --> CSRF cookie sent
INFO - 2018-06-22 03:24:52 --> Input Class Initialized
INFO - 2018-06-22 03:24:52 --> Language Class Initialized
INFO - 2018-06-22 03:24:52 --> Loader Class Initialized
INFO - 2018-06-22 03:24:52 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:52 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:52 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:52 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:52 --> Controller Class Initialized
INFO - 2018-06-22 03:24:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 03:24:52 --> Pixel_Model class loaded
INFO - 2018-06-22 03:24:52 --> Database Driver Class Initialized
INFO - 2018-06-22 03:24:52 --> Model "QuestionsModel" initialized
ERROR - 2018-06-22 03:24:52 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-22 03:24:55 --> Config Class Initialized
INFO - 2018-06-22 03:24:55 --> Hooks Class Initialized
DEBUG - 2018-06-22 03:24:55 --> UTF-8 Support Enabled
INFO - 2018-06-22 03:24:55 --> Utf8 Class Initialized
INFO - 2018-06-22 03:24:55 --> URI Class Initialized
INFO - 2018-06-22 03:24:55 --> Router Class Initialized
INFO - 2018-06-22 03:24:55 --> Output Class Initialized
INFO - 2018-06-22 03:24:55 --> Security Class Initialized
DEBUG - 2018-06-22 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 03:24:55 --> CSRF cookie sent
INFO - 2018-06-22 03:24:55 --> Input Class Initialized
INFO - 2018-06-22 03:24:55 --> Language Class Initialized
INFO - 2018-06-22 03:24:55 --> Loader Class Initialized
INFO - 2018-06-22 03:24:55 --> Helper loaded: url_helper
INFO - 2018-06-22 03:24:55 --> Helper loaded: form_helper
INFO - 2018-06-22 03:24:55 --> Helper loaded: language_helper
DEBUG - 2018-06-22 03:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 03:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 03:24:55 --> User Agent Class Initialized
INFO - 2018-06-22 03:24:55 --> Controller Class Initialized
INFO - 2018-06-22 03:24:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 03:24:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 03:24:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 03:24:55 --> Could not find the language line "req_email"
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 03:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 03:24:55 --> Final output sent to browser
DEBUG - 2018-06-22 03:24:55 --> Total execution time: 0.0219
INFO - 2018-06-22 07:43:06 --> Config Class Initialized
INFO - 2018-06-22 07:43:06 --> Hooks Class Initialized
DEBUG - 2018-06-22 07:43:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 07:43:06 --> Utf8 Class Initialized
INFO - 2018-06-22 07:43:06 --> URI Class Initialized
DEBUG - 2018-06-22 07:43:06 --> No URI present. Default controller set.
INFO - 2018-06-22 07:43:06 --> Router Class Initialized
INFO - 2018-06-22 07:43:06 --> Output Class Initialized
INFO - 2018-06-22 07:43:06 --> Security Class Initialized
DEBUG - 2018-06-22 07:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 07:43:06 --> CSRF cookie sent
INFO - 2018-06-22 07:43:06 --> Input Class Initialized
INFO - 2018-06-22 07:43:06 --> Language Class Initialized
INFO - 2018-06-22 07:43:06 --> Loader Class Initialized
INFO - 2018-06-22 07:43:06 --> Helper loaded: url_helper
INFO - 2018-06-22 07:43:06 --> Helper loaded: form_helper
INFO - 2018-06-22 07:43:06 --> Helper loaded: language_helper
DEBUG - 2018-06-22 07:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 07:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 07:43:06 --> User Agent Class Initialized
INFO - 2018-06-22 07:43:06 --> Controller Class Initialized
INFO - 2018-06-22 07:43:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 07:43:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 07:43:06 --> Pixel_Model class loaded
INFO - 2018-06-22 07:43:06 --> Database Driver Class Initialized
INFO - 2018-06-22 07:43:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 07:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 07:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 07:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 07:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 07:43:06 --> Final output sent to browser
DEBUG - 2018-06-22 07:43:06 --> Total execution time: 0.0360
INFO - 2018-06-22 09:40:16 --> Config Class Initialized
INFO - 2018-06-22 09:40:16 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:16 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:16 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:16 --> URI Class Initialized
INFO - 2018-06-22 09:40:16 --> Router Class Initialized
INFO - 2018-06-22 09:40:16 --> Output Class Initialized
INFO - 2018-06-22 09:40:16 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:16 --> CSRF cookie sent
INFO - 2018-06-22 09:40:16 --> Input Class Initialized
INFO - 2018-06-22 09:40:16 --> Language Class Initialized
ERROR - 2018-06-22 09:40:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-22 09:40:19 --> Config Class Initialized
INFO - 2018-06-22 09:40:19 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:19 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:19 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:19 --> URI Class Initialized
DEBUG - 2018-06-22 09:40:19 --> No URI present. Default controller set.
INFO - 2018-06-22 09:40:19 --> Router Class Initialized
INFO - 2018-06-22 09:40:19 --> Output Class Initialized
INFO - 2018-06-22 09:40:19 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:19 --> CSRF cookie sent
INFO - 2018-06-22 09:40:19 --> Input Class Initialized
INFO - 2018-06-22 09:40:19 --> Language Class Initialized
INFO - 2018-06-22 09:40:19 --> Loader Class Initialized
INFO - 2018-06-22 09:40:19 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:19 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:19 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:19 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:19 --> Controller Class Initialized
INFO - 2018-06-22 09:40:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:19 --> Pixel_Model class loaded
INFO - 2018-06-22 09:40:19 --> Database Driver Class Initialized
INFO - 2018-06-22 09:40:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 09:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 09:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:19 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:19 --> Total execution time: 0.0348
INFO - 2018-06-22 09:40:23 --> Config Class Initialized
INFO - 2018-06-22 09:40:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:23 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:23 --> URI Class Initialized
INFO - 2018-06-22 09:40:23 --> Router Class Initialized
INFO - 2018-06-22 09:40:23 --> Output Class Initialized
INFO - 2018-06-22 09:40:23 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:23 --> CSRF cookie sent
INFO - 2018-06-22 09:40:23 --> Input Class Initialized
INFO - 2018-06-22 09:40:23 --> Language Class Initialized
INFO - 2018-06-22 09:40:23 --> Loader Class Initialized
INFO - 2018-06-22 09:40:23 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:23 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:23 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:23 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:23 --> Controller Class Initialized
INFO - 2018-06-22 09:40:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:23 --> Pixel_Model class loaded
INFO - 2018-06-22 09:40:23 --> Database Driver Class Initialized
INFO - 2018-06-22 09:40:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 09:40:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 09:40:23 --> Could not find the language line "req_email"
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-22 09:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:23 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:23 --> Total execution time: 0.0330
INFO - 2018-06-22 09:40:26 --> Config Class Initialized
INFO - 2018-06-22 09:40:26 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:26 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:26 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:26 --> URI Class Initialized
INFO - 2018-06-22 09:40:26 --> Router Class Initialized
INFO - 2018-06-22 09:40:26 --> Output Class Initialized
INFO - 2018-06-22 09:40:26 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:26 --> CSRF cookie sent
INFO - 2018-06-22 09:40:26 --> Input Class Initialized
INFO - 2018-06-22 09:40:26 --> Language Class Initialized
INFO - 2018-06-22 09:40:26 --> Loader Class Initialized
INFO - 2018-06-22 09:40:26 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:26 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:26 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:26 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:26 --> Controller Class Initialized
INFO - 2018-06-22 09:40:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:26 --> Pixel_Model class loaded
INFO - 2018-06-22 09:40:26 --> Database Driver Class Initialized
INFO - 2018-06-22 09:40:26 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 09:40:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 09:40:26 --> Could not find the language line "req_email"
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-06-22 09:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:26 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:26 --> Total execution time: 0.0314
INFO - 2018-06-22 09:40:29 --> Config Class Initialized
INFO - 2018-06-22 09:40:29 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:29 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:29 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:29 --> URI Class Initialized
INFO - 2018-06-22 09:40:29 --> Router Class Initialized
INFO - 2018-06-22 09:40:29 --> Output Class Initialized
INFO - 2018-06-22 09:40:29 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:29 --> CSRF cookie sent
INFO - 2018-06-22 09:40:29 --> Input Class Initialized
INFO - 2018-06-22 09:40:29 --> Language Class Initialized
INFO - 2018-06-22 09:40:29 --> Loader Class Initialized
INFO - 2018-06-22 09:40:29 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:29 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:29 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:29 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:29 --> Controller Class Initialized
INFO - 2018-06-22 09:40:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-06-22 09:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:29 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:29 --> Total execution time: 0.0204
INFO - 2018-06-22 09:40:32 --> Config Class Initialized
INFO - 2018-06-22 09:40:32 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:32 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:32 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:32 --> URI Class Initialized
INFO - 2018-06-22 09:40:32 --> Router Class Initialized
INFO - 2018-06-22 09:40:32 --> Output Class Initialized
INFO - 2018-06-22 09:40:32 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:32 --> CSRF cookie sent
INFO - 2018-06-22 09:40:32 --> Input Class Initialized
INFO - 2018-06-22 09:40:32 --> Language Class Initialized
INFO - 2018-06-22 09:40:32 --> Loader Class Initialized
INFO - 2018-06-22 09:40:32 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:32 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:32 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:32 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:32 --> Controller Class Initialized
INFO - 2018-06-22 09:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 09:40:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 09:40:32 --> Could not find the language line "req_email"
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-06-22 09:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:32 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:32 --> Total execution time: 0.0207
INFO - 2018-06-22 09:40:34 --> Config Class Initialized
INFO - 2018-06-22 09:40:34 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:34 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:34 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:34 --> URI Class Initialized
INFO - 2018-06-22 09:40:34 --> Router Class Initialized
INFO - 2018-06-22 09:40:34 --> Output Class Initialized
INFO - 2018-06-22 09:40:34 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:34 --> CSRF cookie sent
INFO - 2018-06-22 09:40:34 --> Input Class Initialized
INFO - 2018-06-22 09:40:34 --> Language Class Initialized
INFO - 2018-06-22 09:40:34 --> Loader Class Initialized
INFO - 2018-06-22 09:40:34 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:34 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:34 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:34 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:34 --> Controller Class Initialized
INFO - 2018-06-22 09:40:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:34 --> Pixel_Model class loaded
INFO - 2018-06-22 09:40:34 --> Database Driver Class Initialized
INFO - 2018-06-22 09:40:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 09:40:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 09:40:34 --> Could not find the language line "req_email"
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_lawyer.php
INFO - 2018-06-22 09:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:34 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:34 --> Total execution time: 0.0354
INFO - 2018-06-22 09:40:36 --> Config Class Initialized
INFO - 2018-06-22 09:40:36 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:36 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:36 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:36 --> URI Class Initialized
INFO - 2018-06-22 09:40:36 --> Router Class Initialized
INFO - 2018-06-22 09:40:36 --> Output Class Initialized
INFO - 2018-06-22 09:40:36 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:36 --> CSRF cookie sent
INFO - 2018-06-22 09:40:36 --> Input Class Initialized
INFO - 2018-06-22 09:40:36 --> Language Class Initialized
INFO - 2018-06-22 09:40:36 --> Loader Class Initialized
INFO - 2018-06-22 09:40:36 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:36 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:36 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:36 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:36 --> Controller Class Initialized
INFO - 2018-06-22 09:40:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-06-22 09:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:36 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:36 --> Total execution time: 0.0259
INFO - 2018-06-22 09:40:39 --> Config Class Initialized
INFO - 2018-06-22 09:40:39 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:39 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:39 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:39 --> URI Class Initialized
INFO - 2018-06-22 09:40:39 --> Router Class Initialized
INFO - 2018-06-22 09:40:39 --> Output Class Initialized
INFO - 2018-06-22 09:40:39 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:39 --> CSRF cookie sent
INFO - 2018-06-22 09:40:39 --> Input Class Initialized
INFO - 2018-06-22 09:40:39 --> Language Class Initialized
INFO - 2018-06-22 09:40:39 --> Loader Class Initialized
INFO - 2018-06-22 09:40:39 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:39 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:39 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:39 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:39 --> Controller Class Initialized
INFO - 2018-06-22 09:40:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:44 --> Config Class Initialized
INFO - 2018-06-22 09:40:44 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:44 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:44 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:44 --> URI Class Initialized
INFO - 2018-06-22 09:40:44 --> Router Class Initialized
INFO - 2018-06-22 09:40:44 --> Output Class Initialized
INFO - 2018-06-22 09:40:44 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:44 --> CSRF cookie sent
INFO - 2018-06-22 09:40:44 --> Input Class Initialized
INFO - 2018-06-22 09:40:44 --> Language Class Initialized
INFO - 2018-06-22 09:40:44 --> Loader Class Initialized
INFO - 2018-06-22 09:40:44 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:44 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:44 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:44 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:44 --> Controller Class Initialized
INFO - 2018-06-22 09:40:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-22 09:40:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:44 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:44 --> Total execution time: 0.0213
INFO - 2018-06-22 09:40:46 --> Config Class Initialized
INFO - 2018-06-22 09:40:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:46 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:46 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:46 --> URI Class Initialized
INFO - 2018-06-22 09:40:46 --> Router Class Initialized
INFO - 2018-06-22 09:40:46 --> Output Class Initialized
INFO - 2018-06-22 09:40:46 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:46 --> CSRF cookie sent
INFO - 2018-06-22 09:40:46 --> Input Class Initialized
INFO - 2018-06-22 09:40:46 --> Language Class Initialized
INFO - 2018-06-22 09:40:46 --> Loader Class Initialized
INFO - 2018-06-22 09:40:46 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:46 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:46 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:46 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:46 --> Controller Class Initialized
INFO - 2018-06-22 09:40:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-06-22 09:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:46 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:46 --> Total execution time: 0.0227
INFO - 2018-06-22 09:40:48 --> Config Class Initialized
INFO - 2018-06-22 09:40:48 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:48 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:48 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:48 --> URI Class Initialized
INFO - 2018-06-22 09:40:48 --> Router Class Initialized
INFO - 2018-06-22 09:40:48 --> Output Class Initialized
INFO - 2018-06-22 09:40:48 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:48 --> CSRF cookie sent
INFO - 2018-06-22 09:40:48 --> Input Class Initialized
INFO - 2018-06-22 09:40:48 --> Language Class Initialized
INFO - 2018-06-22 09:40:48 --> Loader Class Initialized
INFO - 2018-06-22 09:40:48 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:48 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:48 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:48 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:48 --> Controller Class Initialized
INFO - 2018-06-22 09:40:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-06-22 09:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:48 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:48 --> Total execution time: 0.0210
INFO - 2018-06-22 09:40:51 --> Config Class Initialized
INFO - 2018-06-22 09:40:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:51 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:51 --> URI Class Initialized
INFO - 2018-06-22 09:40:51 --> Router Class Initialized
INFO - 2018-06-22 09:40:51 --> Output Class Initialized
INFO - 2018-06-22 09:40:51 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:51 --> CSRF cookie sent
INFO - 2018-06-22 09:40:51 --> Input Class Initialized
INFO - 2018-06-22 09:40:51 --> Language Class Initialized
INFO - 2018-06-22 09:40:51 --> Loader Class Initialized
INFO - 2018-06-22 09:40:51 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:51 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:51 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:51 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:51 --> Controller Class Initialized
INFO - 2018-06-22 09:40:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-06-22 09:40:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:51 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:51 --> Total execution time: 0.0209
INFO - 2018-06-22 09:40:53 --> Config Class Initialized
INFO - 2018-06-22 09:40:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:53 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:53 --> URI Class Initialized
INFO - 2018-06-22 09:40:53 --> Router Class Initialized
INFO - 2018-06-22 09:40:53 --> Output Class Initialized
INFO - 2018-06-22 09:40:53 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:53 --> CSRF cookie sent
INFO - 2018-06-22 09:40:53 --> Input Class Initialized
INFO - 2018-06-22 09:40:53 --> Language Class Initialized
INFO - 2018-06-22 09:40:53 --> Loader Class Initialized
INFO - 2018-06-22 09:40:53 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:53 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:53 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:53 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:53 --> Controller Class Initialized
INFO - 2018-06-22 09:40:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-06-22 09:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:53 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:53 --> Total execution time: 0.0202
INFO - 2018-06-22 09:40:55 --> Config Class Initialized
INFO - 2018-06-22 09:40:55 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:55 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:55 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:55 --> URI Class Initialized
INFO - 2018-06-22 09:40:55 --> Router Class Initialized
INFO - 2018-06-22 09:40:55 --> Output Class Initialized
INFO - 2018-06-22 09:40:55 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:55 --> CSRF cookie sent
INFO - 2018-06-22 09:40:55 --> Input Class Initialized
INFO - 2018-06-22 09:40:55 --> Language Class Initialized
INFO - 2018-06-22 09:40:55 --> Loader Class Initialized
INFO - 2018-06-22 09:40:55 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:55 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:55 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:55 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:55 --> Controller Class Initialized
INFO - 2018-06-22 09:40:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-06-22 09:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:55 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:55 --> Total execution time: 0.0220
INFO - 2018-06-22 09:40:58 --> Config Class Initialized
INFO - 2018-06-22 09:40:58 --> Hooks Class Initialized
DEBUG - 2018-06-22 09:40:58 --> UTF-8 Support Enabled
INFO - 2018-06-22 09:40:58 --> Utf8 Class Initialized
INFO - 2018-06-22 09:40:58 --> URI Class Initialized
INFO - 2018-06-22 09:40:58 --> Router Class Initialized
INFO - 2018-06-22 09:40:58 --> Output Class Initialized
INFO - 2018-06-22 09:40:58 --> Security Class Initialized
DEBUG - 2018-06-22 09:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 09:40:58 --> CSRF cookie sent
INFO - 2018-06-22 09:40:58 --> Input Class Initialized
INFO - 2018-06-22 09:40:58 --> Language Class Initialized
INFO - 2018-06-22 09:40:58 --> Loader Class Initialized
INFO - 2018-06-22 09:40:58 --> Helper loaded: url_helper
INFO - 2018-06-22 09:40:58 --> Helper loaded: form_helper
INFO - 2018-06-22 09:40:58 --> Helper loaded: language_helper
DEBUG - 2018-06-22 09:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 09:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 09:40:58 --> User Agent Class Initialized
INFO - 2018-06-22 09:40:58 --> Controller Class Initialized
INFO - 2018-06-22 09:40:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 09:40:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 09:40:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 09:40:58 --> Could not find the language line "req_email"
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 09:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 09:40:58 --> Final output sent to browser
DEBUG - 2018-06-22 09:40:58 --> Total execution time: 0.0214
INFO - 2018-06-22 12:41:52 --> Config Class Initialized
INFO - 2018-06-22 12:41:52 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:41:52 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:41:52 --> Utf8 Class Initialized
INFO - 2018-06-22 12:41:52 --> URI Class Initialized
INFO - 2018-06-22 12:41:52 --> Router Class Initialized
INFO - 2018-06-22 12:41:52 --> Output Class Initialized
INFO - 2018-06-22 12:41:52 --> Security Class Initialized
DEBUG - 2018-06-22 12:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:41:52 --> CSRF cookie sent
INFO - 2018-06-22 12:41:52 --> Input Class Initialized
INFO - 2018-06-22 12:41:52 --> Language Class Initialized
ERROR - 2018-06-22 12:41:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-22 12:41:55 --> Config Class Initialized
INFO - 2018-06-22 12:41:55 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:41:55 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:41:55 --> Utf8 Class Initialized
INFO - 2018-06-22 12:41:55 --> URI Class Initialized
INFO - 2018-06-22 12:41:55 --> Router Class Initialized
INFO - 2018-06-22 12:41:55 --> Output Class Initialized
INFO - 2018-06-22 12:41:55 --> Security Class Initialized
DEBUG - 2018-06-22 12:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:41:55 --> CSRF cookie sent
INFO - 2018-06-22 12:41:55 --> Input Class Initialized
INFO - 2018-06-22 12:41:55 --> Language Class Initialized
INFO - 2018-06-22 12:41:55 --> Loader Class Initialized
INFO - 2018-06-22 12:41:55 --> Helper loaded: url_helper
INFO - 2018-06-22 12:41:55 --> Helper loaded: form_helper
INFO - 2018-06-22 12:41:55 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:41:55 --> User Agent Class Initialized
INFO - 2018-06-22 12:41:55 --> Controller Class Initialized
INFO - 2018-06-22 12:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:41:55 --> Pixel_Model class loaded
INFO - 2018-06-22 12:41:55 --> Database Driver Class Initialized
INFO - 2018-06-22 12:41:55 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 12:41:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 12:41:55 --> Could not find the language line "req_email"
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_lawyer.php
INFO - 2018-06-22 12:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:41:55 --> Final output sent to browser
DEBUG - 2018-06-22 12:41:55 --> Total execution time: 0.0380
INFO - 2018-06-22 12:41:59 --> Config Class Initialized
INFO - 2018-06-22 12:41:59 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:41:59 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:41:59 --> Utf8 Class Initialized
INFO - 2018-06-22 12:41:59 --> URI Class Initialized
DEBUG - 2018-06-22 12:41:59 --> No URI present. Default controller set.
INFO - 2018-06-22 12:41:59 --> Router Class Initialized
INFO - 2018-06-22 12:41:59 --> Output Class Initialized
INFO - 2018-06-22 12:41:59 --> Security Class Initialized
DEBUG - 2018-06-22 12:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:41:59 --> CSRF cookie sent
INFO - 2018-06-22 12:41:59 --> Input Class Initialized
INFO - 2018-06-22 12:41:59 --> Language Class Initialized
INFO - 2018-06-22 12:41:59 --> Loader Class Initialized
INFO - 2018-06-22 12:41:59 --> Helper loaded: url_helper
INFO - 2018-06-22 12:41:59 --> Helper loaded: form_helper
INFO - 2018-06-22 12:41:59 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:41:59 --> User Agent Class Initialized
INFO - 2018-06-22 12:41:59 --> Controller Class Initialized
INFO - 2018-06-22 12:41:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:41:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:41:59 --> Pixel_Model class loaded
INFO - 2018-06-22 12:41:59 --> Database Driver Class Initialized
INFO - 2018-06-22 12:41:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 12:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 12:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:41:59 --> Final output sent to browser
DEBUG - 2018-06-22 12:41:59 --> Total execution time: 0.0347
INFO - 2018-06-22 12:42:02 --> Config Class Initialized
INFO - 2018-06-22 12:42:02 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:02 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:02 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:02 --> URI Class Initialized
INFO - 2018-06-22 12:42:02 --> Router Class Initialized
INFO - 2018-06-22 12:42:02 --> Output Class Initialized
INFO - 2018-06-22 12:42:02 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:02 --> CSRF cookie sent
INFO - 2018-06-22 12:42:02 --> Input Class Initialized
INFO - 2018-06-22 12:42:02 --> Language Class Initialized
INFO - 2018-06-22 12:42:02 --> Loader Class Initialized
INFO - 2018-06-22 12:42:02 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:02 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:02 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:02 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:02 --> Controller Class Initialized
INFO - 2018-06-22 12:42:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:02 --> Pixel_Model class loaded
INFO - 2018-06-22 12:42:02 --> Database Driver Class Initialized
INFO - 2018-06-22 12:42:02 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 12:42:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 12:42:02 --> Could not find the language line "req_email"
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-06-22 12:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:02 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:02 --> Total execution time: 0.0376
INFO - 2018-06-22 12:42:04 --> Config Class Initialized
INFO - 2018-06-22 12:42:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:04 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:04 --> URI Class Initialized
INFO - 2018-06-22 12:42:04 --> Router Class Initialized
INFO - 2018-06-22 12:42:04 --> Output Class Initialized
INFO - 2018-06-22 12:42:04 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:04 --> CSRF cookie sent
INFO - 2018-06-22 12:42:04 --> Input Class Initialized
INFO - 2018-06-22 12:42:04 --> Language Class Initialized
INFO - 2018-06-22 12:42:04 --> Loader Class Initialized
INFO - 2018-06-22 12:42:04 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:04 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:04 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:04 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:04 --> Controller Class Initialized
INFO - 2018-06-22 12:42:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:04 --> Pixel_Model class loaded
INFO - 2018-06-22 12:42:04 --> Database Driver Class Initialized
INFO - 2018-06-22 12:42:04 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 12:42:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 12:42:04 --> Could not find the language line "req_email"
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-22 12:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:04 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:04 --> Total execution time: 0.0331
INFO - 2018-06-22 12:42:07 --> Config Class Initialized
INFO - 2018-06-22 12:42:07 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:07 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:07 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:07 --> URI Class Initialized
INFO - 2018-06-22 12:42:07 --> Router Class Initialized
INFO - 2018-06-22 12:42:07 --> Output Class Initialized
INFO - 2018-06-22 12:42:07 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:07 --> CSRF cookie sent
INFO - 2018-06-22 12:42:07 --> Input Class Initialized
INFO - 2018-06-22 12:42:07 --> Language Class Initialized
INFO - 2018-06-22 12:42:07 --> Loader Class Initialized
INFO - 2018-06-22 12:42:07 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:07 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:07 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:07 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:07 --> Controller Class Initialized
INFO - 2018-06-22 12:42:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-06-22 12:42:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:07 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:07 --> Total execution time: 0.0250
INFO - 2018-06-22 12:42:10 --> Config Class Initialized
INFO - 2018-06-22 12:42:10 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:10 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:10 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:10 --> URI Class Initialized
INFO - 2018-06-22 12:42:10 --> Router Class Initialized
INFO - 2018-06-22 12:42:10 --> Output Class Initialized
INFO - 2018-06-22 12:42:10 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:10 --> CSRF cookie sent
INFO - 2018-06-22 12:42:10 --> Input Class Initialized
INFO - 2018-06-22 12:42:10 --> Language Class Initialized
INFO - 2018-06-22 12:42:10 --> Loader Class Initialized
INFO - 2018-06-22 12:42:10 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:10 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:10 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:10 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:10 --> Controller Class Initialized
INFO - 2018-06-22 12:42:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:10 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 12:42:10 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 12:42:10 --> Could not find the language line "req_email"
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-06-22 12:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:10 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:10 --> Total execution time: 0.0207
INFO - 2018-06-22 12:42:12 --> Config Class Initialized
INFO - 2018-06-22 12:42:12 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:12 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:12 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:12 --> URI Class Initialized
INFO - 2018-06-22 12:42:12 --> Router Class Initialized
INFO - 2018-06-22 12:42:12 --> Output Class Initialized
INFO - 2018-06-22 12:42:12 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:12 --> CSRF cookie sent
INFO - 2018-06-22 12:42:12 --> Input Class Initialized
INFO - 2018-06-22 12:42:12 --> Language Class Initialized
INFO - 2018-06-22 12:42:12 --> Loader Class Initialized
INFO - 2018-06-22 12:42:12 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:12 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:12 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:12 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:12 --> Controller Class Initialized
INFO - 2018-06-22 12:42:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:17 --> Config Class Initialized
INFO - 2018-06-22 12:42:17 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:17 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:17 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:17 --> URI Class Initialized
INFO - 2018-06-22 12:42:17 --> Router Class Initialized
INFO - 2018-06-22 12:42:17 --> Output Class Initialized
INFO - 2018-06-22 12:42:17 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:17 --> CSRF cookie sent
INFO - 2018-06-22 12:42:17 --> Input Class Initialized
INFO - 2018-06-22 12:42:17 --> Language Class Initialized
INFO - 2018-06-22 12:42:17 --> Loader Class Initialized
INFO - 2018-06-22 12:42:17 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:17 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:17 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:17 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:17 --> Controller Class Initialized
INFO - 2018-06-22 12:42:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-06-22 12:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:17 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:17 --> Total execution time: 0.0209
INFO - 2018-06-22 12:42:19 --> Config Class Initialized
INFO - 2018-06-22 12:42:19 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:19 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:19 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:19 --> URI Class Initialized
INFO - 2018-06-22 12:42:19 --> Router Class Initialized
INFO - 2018-06-22 12:42:19 --> Output Class Initialized
INFO - 2018-06-22 12:42:19 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:19 --> CSRF cookie sent
INFO - 2018-06-22 12:42:19 --> Input Class Initialized
INFO - 2018-06-22 12:42:19 --> Language Class Initialized
INFO - 2018-06-22 12:42:19 --> Loader Class Initialized
INFO - 2018-06-22 12:42:19 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:19 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:19 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:19 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:19 --> Controller Class Initialized
INFO - 2018-06-22 12:42:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-06-22 12:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:19 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:19 --> Total execution time: 0.0206
INFO - 2018-06-22 12:42:22 --> Config Class Initialized
INFO - 2018-06-22 12:42:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:22 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:22 --> URI Class Initialized
INFO - 2018-06-22 12:42:22 --> Router Class Initialized
INFO - 2018-06-22 12:42:22 --> Output Class Initialized
INFO - 2018-06-22 12:42:22 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:22 --> CSRF cookie sent
INFO - 2018-06-22 12:42:22 --> Input Class Initialized
INFO - 2018-06-22 12:42:22 --> Language Class Initialized
INFO - 2018-06-22 12:42:22 --> Loader Class Initialized
INFO - 2018-06-22 12:42:22 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:22 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:22 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:22 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:22 --> Controller Class Initialized
INFO - 2018-06-22 12:42:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-22 12:42:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:22 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:22 --> Total execution time: 0.0217
INFO - 2018-06-22 12:42:24 --> Config Class Initialized
INFO - 2018-06-22 12:42:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:24 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:24 --> URI Class Initialized
INFO - 2018-06-22 12:42:24 --> Router Class Initialized
INFO - 2018-06-22 12:42:24 --> Output Class Initialized
INFO - 2018-06-22 12:42:24 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:24 --> CSRF cookie sent
INFO - 2018-06-22 12:42:24 --> Input Class Initialized
INFO - 2018-06-22 12:42:24 --> Language Class Initialized
INFO - 2018-06-22 12:42:24 --> Loader Class Initialized
INFO - 2018-06-22 12:42:24 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:24 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:24 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:24 --> Controller Class Initialized
INFO - 2018-06-22 12:42:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-06-22 12:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:24 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:24 --> Total execution time: 0.0209
INFO - 2018-06-22 12:42:26 --> Config Class Initialized
INFO - 2018-06-22 12:42:26 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:26 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:26 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:26 --> URI Class Initialized
INFO - 2018-06-22 12:42:26 --> Router Class Initialized
INFO - 2018-06-22 12:42:26 --> Output Class Initialized
INFO - 2018-06-22 12:42:26 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:26 --> CSRF cookie sent
INFO - 2018-06-22 12:42:26 --> Input Class Initialized
INFO - 2018-06-22 12:42:26 --> Language Class Initialized
INFO - 2018-06-22 12:42:26 --> Loader Class Initialized
INFO - 2018-06-22 12:42:26 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:26 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:26 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:26 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:26 --> Controller Class Initialized
INFO - 2018-06-22 12:42:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-06-22 12:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:26 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:26 --> Total execution time: 0.0213
INFO - 2018-06-22 12:42:29 --> Config Class Initialized
INFO - 2018-06-22 12:42:29 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:29 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:29 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:29 --> URI Class Initialized
INFO - 2018-06-22 12:42:29 --> Router Class Initialized
INFO - 2018-06-22 12:42:29 --> Output Class Initialized
INFO - 2018-06-22 12:42:29 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:29 --> CSRF cookie sent
INFO - 2018-06-22 12:42:29 --> Input Class Initialized
INFO - 2018-06-22 12:42:29 --> Language Class Initialized
INFO - 2018-06-22 12:42:29 --> Loader Class Initialized
INFO - 2018-06-22 12:42:29 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:29 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:29 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:29 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:29 --> Controller Class Initialized
INFO - 2018-06-22 12:42:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-06-22 12:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:29 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:29 --> Total execution time: 0.0230
INFO - 2018-06-22 12:42:31 --> Config Class Initialized
INFO - 2018-06-22 12:42:31 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:31 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:31 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:31 --> URI Class Initialized
INFO - 2018-06-22 12:42:31 --> Router Class Initialized
INFO - 2018-06-22 12:42:31 --> Output Class Initialized
INFO - 2018-06-22 12:42:31 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:31 --> CSRF cookie sent
INFO - 2018-06-22 12:42:31 --> Input Class Initialized
INFO - 2018-06-22 12:42:31 --> Language Class Initialized
INFO - 2018-06-22 12:42:31 --> Loader Class Initialized
INFO - 2018-06-22 12:42:31 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:31 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:31 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:31 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:31 --> Controller Class Initialized
INFO - 2018-06-22 12:42:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-06-22 12:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:31 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:31 --> Total execution time: 0.0206
INFO - 2018-06-22 12:42:33 --> Config Class Initialized
INFO - 2018-06-22 12:42:33 --> Hooks Class Initialized
DEBUG - 2018-06-22 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-06-22 12:42:33 --> Utf8 Class Initialized
INFO - 2018-06-22 12:42:33 --> URI Class Initialized
INFO - 2018-06-22 12:42:33 --> Router Class Initialized
INFO - 2018-06-22 12:42:33 --> Output Class Initialized
INFO - 2018-06-22 12:42:33 --> Security Class Initialized
DEBUG - 2018-06-22 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 12:42:33 --> CSRF cookie sent
INFO - 2018-06-22 12:42:33 --> Input Class Initialized
INFO - 2018-06-22 12:42:33 --> Language Class Initialized
INFO - 2018-06-22 12:42:33 --> Loader Class Initialized
INFO - 2018-06-22 12:42:33 --> Helper loaded: url_helper
INFO - 2018-06-22 12:42:33 --> Helper loaded: form_helper
INFO - 2018-06-22 12:42:33 --> Helper loaded: language_helper
DEBUG - 2018-06-22 12:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 12:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 12:42:33 --> User Agent Class Initialized
INFO - 2018-06-22 12:42:33 --> Controller Class Initialized
INFO - 2018-06-22 12:42:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 12:42:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 12:42:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 12:42:33 --> Could not find the language line "req_email"
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 12:42:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 12:42:33 --> Final output sent to browser
DEBUG - 2018-06-22 12:42:33 --> Total execution time: 0.0216
INFO - 2018-06-22 13:28:20 --> Config Class Initialized
INFO - 2018-06-22 13:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:28:20 --> Utf8 Class Initialized
INFO - 2018-06-22 13:28:20 --> URI Class Initialized
DEBUG - 2018-06-22 13:28:20 --> No URI present. Default controller set.
INFO - 2018-06-22 13:28:20 --> Router Class Initialized
INFO - 2018-06-22 13:28:20 --> Output Class Initialized
INFO - 2018-06-22 13:28:20 --> Security Class Initialized
DEBUG - 2018-06-22 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:28:20 --> CSRF cookie sent
INFO - 2018-06-22 13:28:20 --> Input Class Initialized
INFO - 2018-06-22 13:28:20 --> Language Class Initialized
INFO - 2018-06-22 13:28:20 --> Loader Class Initialized
INFO - 2018-06-22 13:28:20 --> Helper loaded: url_helper
INFO - 2018-06-22 13:28:20 --> Helper loaded: form_helper
INFO - 2018-06-22 13:28:20 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:28:20 --> User Agent Class Initialized
INFO - 2018-06-22 13:28:20 --> Controller Class Initialized
INFO - 2018-06-22 13:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:28:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:28:20 --> Pixel_Model class loaded
INFO - 2018-06-22 13:28:20 --> Database Driver Class Initialized
INFO - 2018-06-22 13:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 13:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:28:20 --> Final output sent to browser
DEBUG - 2018-06-22 13:28:20 --> Total execution time: 0.0343
INFO - 2018-06-22 13:30:35 --> Config Class Initialized
INFO - 2018-06-22 13:30:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:30:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:30:35 --> Utf8 Class Initialized
INFO - 2018-06-22 13:30:35 --> URI Class Initialized
DEBUG - 2018-06-22 13:30:35 --> No URI present. Default controller set.
INFO - 2018-06-22 13:30:35 --> Router Class Initialized
INFO - 2018-06-22 13:30:35 --> Output Class Initialized
INFO - 2018-06-22 13:30:35 --> Security Class Initialized
DEBUG - 2018-06-22 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:30:35 --> CSRF cookie sent
INFO - 2018-06-22 13:30:35 --> Input Class Initialized
INFO - 2018-06-22 13:30:35 --> Language Class Initialized
INFO - 2018-06-22 13:30:35 --> Loader Class Initialized
INFO - 2018-06-22 13:30:35 --> Helper loaded: url_helper
INFO - 2018-06-22 13:30:35 --> Helper loaded: form_helper
INFO - 2018-06-22 13:30:35 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:30:35 --> User Agent Class Initialized
INFO - 2018-06-22 13:30:35 --> Controller Class Initialized
INFO - 2018-06-22 13:30:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:30:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:30:35 --> Pixel_Model class loaded
INFO - 2018-06-22 13:30:35 --> Database Driver Class Initialized
INFO - 2018-06-22 13:30:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:30:35 --> Final output sent to browser
DEBUG - 2018-06-22 13:30:35 --> Total execution time: 0.0335
INFO - 2018-06-22 13:30:35 --> Config Class Initialized
INFO - 2018-06-22 13:30:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:30:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:30:35 --> Utf8 Class Initialized
INFO - 2018-06-22 13:30:35 --> URI Class Initialized
DEBUG - 2018-06-22 13:30:35 --> No URI present. Default controller set.
INFO - 2018-06-22 13:30:35 --> Router Class Initialized
INFO - 2018-06-22 13:30:35 --> Output Class Initialized
INFO - 2018-06-22 13:30:35 --> Security Class Initialized
DEBUG - 2018-06-22 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:30:35 --> CSRF cookie sent
INFO - 2018-06-22 13:30:35 --> Input Class Initialized
INFO - 2018-06-22 13:30:35 --> Language Class Initialized
INFO - 2018-06-22 13:30:35 --> Loader Class Initialized
INFO - 2018-06-22 13:30:35 --> Helper loaded: url_helper
INFO - 2018-06-22 13:30:35 --> Helper loaded: form_helper
INFO - 2018-06-22 13:30:35 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:30:35 --> User Agent Class Initialized
INFO - 2018-06-22 13:30:35 --> Controller Class Initialized
INFO - 2018-06-22 13:30:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:30:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:30:35 --> Pixel_Model class loaded
INFO - 2018-06-22 13:30:35 --> Database Driver Class Initialized
INFO - 2018-06-22 13:30:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:30:35 --> Final output sent to browser
DEBUG - 2018-06-22 13:30:35 --> Total execution time: 0.0326
INFO - 2018-06-22 13:30:38 --> Config Class Initialized
INFO - 2018-06-22 13:30:38 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:30:38 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:30:38 --> Utf8 Class Initialized
INFO - 2018-06-22 13:30:38 --> URI Class Initialized
INFO - 2018-06-22 13:30:38 --> Router Class Initialized
INFO - 2018-06-22 13:30:38 --> Output Class Initialized
INFO - 2018-06-22 13:30:38 --> Security Class Initialized
DEBUG - 2018-06-22 13:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:30:38 --> CSRF cookie sent
INFO - 2018-06-22 13:30:38 --> CSRF token verified
INFO - 2018-06-22 13:30:38 --> Input Class Initialized
INFO - 2018-06-22 13:30:38 --> Language Class Initialized
INFO - 2018-06-22 13:30:38 --> Loader Class Initialized
INFO - 2018-06-22 13:30:38 --> Helper loaded: url_helper
INFO - 2018-06-22 13:30:38 --> Helper loaded: form_helper
INFO - 2018-06-22 13:30:38 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:30:38 --> User Agent Class Initialized
INFO - 2018-06-22 13:30:38 --> Controller Class Initialized
INFO - 2018-06-22 13:30:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:30:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:30:38 --> Pixel_Model class loaded
INFO - 2018-06-22 13:30:38 --> Database Driver Class Initialized
INFO - 2018-06-22 13:30:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:30:38 --> Config Class Initialized
INFO - 2018-06-22 13:30:38 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:30:38 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:30:38 --> Utf8 Class Initialized
INFO - 2018-06-22 13:30:38 --> URI Class Initialized
INFO - 2018-06-22 13:30:38 --> Router Class Initialized
INFO - 2018-06-22 13:30:38 --> Output Class Initialized
INFO - 2018-06-22 13:30:38 --> Security Class Initialized
DEBUG - 2018-06-22 13:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:30:38 --> CSRF cookie sent
INFO - 2018-06-22 13:30:38 --> Input Class Initialized
INFO - 2018-06-22 13:30:38 --> Language Class Initialized
INFO - 2018-06-22 13:30:38 --> Loader Class Initialized
INFO - 2018-06-22 13:30:38 --> Helper loaded: url_helper
INFO - 2018-06-22 13:30:38 --> Helper loaded: form_helper
INFO - 2018-06-22 13:30:38 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:30:38 --> User Agent Class Initialized
INFO - 2018-06-22 13:30:38 --> Controller Class Initialized
INFO - 2018-06-22 13:30:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:30:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 13:30:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 13:30:38 --> Could not find the language line "req_email"
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 13:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:30:38 --> Final output sent to browser
DEBUG - 2018-06-22 13:30:38 --> Total execution time: 0.0202
INFO - 2018-06-22 13:51:13 --> Config Class Initialized
INFO - 2018-06-22 13:51:13 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:13 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:13 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:13 --> URI Class Initialized
DEBUG - 2018-06-22 13:51:13 --> No URI present. Default controller set.
INFO - 2018-06-22 13:51:13 --> Router Class Initialized
INFO - 2018-06-22 13:51:13 --> Output Class Initialized
INFO - 2018-06-22 13:51:13 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:13 --> CSRF cookie sent
INFO - 2018-06-22 13:51:13 --> Input Class Initialized
INFO - 2018-06-22 13:51:13 --> Language Class Initialized
INFO - 2018-06-22 13:51:13 --> Loader Class Initialized
INFO - 2018-06-22 13:51:13 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:13 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:13 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:13 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:13 --> Controller Class Initialized
INFO - 2018-06-22 13:51:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:13 --> Pixel_Model class loaded
INFO - 2018-06-22 13:51:13 --> Database Driver Class Initialized
INFO - 2018-06-22 13:51:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:51:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 13:51:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:13 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:13 --> Total execution time: 0.0418
INFO - 2018-06-22 13:51:14 --> Config Class Initialized
INFO - 2018-06-22 13:51:14 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:14 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:14 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:14 --> URI Class Initialized
DEBUG - 2018-06-22 13:51:14 --> No URI present. Default controller set.
INFO - 2018-06-22 13:51:14 --> Router Class Initialized
INFO - 2018-06-22 13:51:14 --> Output Class Initialized
INFO - 2018-06-22 13:51:14 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:14 --> CSRF cookie sent
INFO - 2018-06-22 13:51:14 --> Input Class Initialized
INFO - 2018-06-22 13:51:14 --> Language Class Initialized
INFO - 2018-06-22 13:51:14 --> Loader Class Initialized
INFO - 2018-06-22 13:51:14 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:14 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:14 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:14 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:14 --> Controller Class Initialized
INFO - 2018-06-22 13:51:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:14 --> Pixel_Model class loaded
INFO - 2018-06-22 13:51:14 --> Database Driver Class Initialized
INFO - 2018-06-22 13:51:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:51:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 13:51:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:14 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:14 --> Total execution time: 0.0324
INFO - 2018-06-22 13:51:24 --> Config Class Initialized
INFO - 2018-06-22 13:51:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:24 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:24 --> URI Class Initialized
INFO - 2018-06-22 13:51:24 --> Router Class Initialized
INFO - 2018-06-22 13:51:24 --> Output Class Initialized
INFO - 2018-06-22 13:51:24 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:24 --> CSRF cookie sent
INFO - 2018-06-22 13:51:24 --> Input Class Initialized
INFO - 2018-06-22 13:51:24 --> Language Class Initialized
INFO - 2018-06-22 13:51:24 --> Loader Class Initialized
INFO - 2018-06-22 13:51:24 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:24 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:24 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:24 --> Controller Class Initialized
INFO - 2018-06-22 13:51:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:24 --> Pixel_Model class loaded
INFO - 2018-06-22 13:51:24 --> Database Driver Class Initialized
INFO - 2018-06-22 13:51:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 13:51:24 --> Config Class Initialized
INFO - 2018-06-22 13:51:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:24 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:24 --> URI Class Initialized
INFO - 2018-06-22 13:51:24 --> Router Class Initialized
INFO - 2018-06-22 13:51:24 --> Output Class Initialized
INFO - 2018-06-22 13:51:24 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:24 --> CSRF cookie sent
INFO - 2018-06-22 13:51:24 --> Input Class Initialized
INFO - 2018-06-22 13:51:24 --> Language Class Initialized
INFO - 2018-06-22 13:51:24 --> Loader Class Initialized
INFO - 2018-06-22 13:51:24 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:24 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:24 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:24 --> Controller Class Initialized
INFO - 2018-06-22 13:51:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 13:51:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 13:51:24 --> Could not find the language line "req_email"
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 13:51:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:24 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:24 --> Total execution time: 0.0226
INFO - 2018-06-22 13:51:28 --> Config Class Initialized
INFO - 2018-06-22 13:51:28 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:28 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:28 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:28 --> URI Class Initialized
INFO - 2018-06-22 13:51:28 --> Router Class Initialized
INFO - 2018-06-22 13:51:28 --> Output Class Initialized
INFO - 2018-06-22 13:51:28 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:28 --> CSRF cookie sent
INFO - 2018-06-22 13:51:28 --> Input Class Initialized
INFO - 2018-06-22 13:51:28 --> Language Class Initialized
INFO - 2018-06-22 13:51:28 --> Loader Class Initialized
INFO - 2018-06-22 13:51:28 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:28 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:28 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:28 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:28 --> Controller Class Initialized
INFO - 2018-06-22 13:51:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-22 13:51:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:28 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:28 --> Total execution time: 0.0229
INFO - 2018-06-22 13:51:36 --> Config Class Initialized
INFO - 2018-06-22 13:51:36 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:36 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:36 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:36 --> URI Class Initialized
INFO - 2018-06-22 13:51:36 --> Router Class Initialized
INFO - 2018-06-22 13:51:36 --> Output Class Initialized
INFO - 2018-06-22 13:51:36 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:36 --> CSRF cookie sent
INFO - 2018-06-22 13:51:36 --> Input Class Initialized
INFO - 2018-06-22 13:51:36 --> Language Class Initialized
INFO - 2018-06-22 13:51:36 --> Loader Class Initialized
INFO - 2018-06-22 13:51:36 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:36 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:36 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:36 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:36 --> Controller Class Initialized
INFO - 2018-06-22 13:51:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 13:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:36 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:36 --> Total execution time: 0.0249
INFO - 2018-06-22 13:51:39 --> Config Class Initialized
INFO - 2018-06-22 13:51:39 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:39 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:39 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:39 --> URI Class Initialized
INFO - 2018-06-22 13:51:39 --> Router Class Initialized
INFO - 2018-06-22 13:51:39 --> Output Class Initialized
INFO - 2018-06-22 13:51:39 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:39 --> CSRF cookie sent
INFO - 2018-06-22 13:51:39 --> Input Class Initialized
INFO - 2018-06-22 13:51:39 --> Language Class Initialized
INFO - 2018-06-22 13:51:39 --> Loader Class Initialized
INFO - 2018-06-22 13:51:39 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:39 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:39 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:39 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:39 --> Controller Class Initialized
INFO - 2018-06-22 13:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-06-22 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:39 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:39 --> Total execution time: 0.0279
INFO - 2018-06-22 13:51:48 --> Config Class Initialized
INFO - 2018-06-22 13:51:48 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:48 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:48 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:48 --> URI Class Initialized
INFO - 2018-06-22 13:51:48 --> Router Class Initialized
INFO - 2018-06-22 13:51:48 --> Output Class Initialized
INFO - 2018-06-22 13:51:48 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:48 --> CSRF cookie sent
INFO - 2018-06-22 13:51:48 --> Input Class Initialized
INFO - 2018-06-22 13:51:48 --> Language Class Initialized
INFO - 2018-06-22 13:51:48 --> Loader Class Initialized
INFO - 2018-06-22 13:51:48 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:48 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:48 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:48 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:48 --> Controller Class Initialized
INFO - 2018-06-22 13:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:48 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:48 --> Total execution time: 0.0197
INFO - 2018-06-22 13:51:51 --> Config Class Initialized
INFO - 2018-06-22 13:51:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:51 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:51 --> URI Class Initialized
INFO - 2018-06-22 13:51:51 --> Router Class Initialized
INFO - 2018-06-22 13:51:51 --> Output Class Initialized
INFO - 2018-06-22 13:51:51 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:51 --> CSRF cookie sent
INFO - 2018-06-22 13:51:51 --> Input Class Initialized
INFO - 2018-06-22 13:51:51 --> Language Class Initialized
ERROR - 2018-06-22 13:51:51 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-22 13:51:53 --> Config Class Initialized
INFO - 2018-06-22 13:51:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:53 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:53 --> URI Class Initialized
INFO - 2018-06-22 13:51:53 --> Router Class Initialized
INFO - 2018-06-22 13:51:53 --> Output Class Initialized
INFO - 2018-06-22 13:51:53 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:53 --> CSRF cookie sent
INFO - 2018-06-22 13:51:53 --> Input Class Initialized
INFO - 2018-06-22 13:51:53 --> Language Class Initialized
INFO - 2018-06-22 13:51:53 --> Loader Class Initialized
INFO - 2018-06-22 13:51:53 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:53 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:53 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:53 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:53 --> Controller Class Initialized
INFO - 2018-06-22 13:51:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 13:51:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 13:51:53 --> Could not find the language line "req_email"
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 13:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:53 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:53 --> Total execution time: 0.0227
INFO - 2018-06-22 13:51:55 --> Config Class Initialized
INFO - 2018-06-22 13:51:55 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:55 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:55 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:55 --> URI Class Initialized
INFO - 2018-06-22 13:51:55 --> Router Class Initialized
INFO - 2018-06-22 13:51:55 --> Output Class Initialized
INFO - 2018-06-22 13:51:55 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:55 --> CSRF cookie sent
INFO - 2018-06-22 13:51:55 --> Input Class Initialized
INFO - 2018-06-22 13:51:55 --> Language Class Initialized
INFO - 2018-06-22 13:51:55 --> Loader Class Initialized
INFO - 2018-06-22 13:51:55 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:55 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:55 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:55 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:55 --> Controller Class Initialized
INFO - 2018-06-22 13:51:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 13:51:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:55 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:55 --> Total execution time: 0.0201
INFO - 2018-06-22 13:51:57 --> Config Class Initialized
INFO - 2018-06-22 13:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:51:57 --> Utf8 Class Initialized
INFO - 2018-06-22 13:51:57 --> URI Class Initialized
INFO - 2018-06-22 13:51:57 --> Router Class Initialized
INFO - 2018-06-22 13:51:57 --> Output Class Initialized
INFO - 2018-06-22 13:51:57 --> Security Class Initialized
DEBUG - 2018-06-22 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:51:57 --> CSRF cookie sent
INFO - 2018-06-22 13:51:57 --> Input Class Initialized
INFO - 2018-06-22 13:51:57 --> Language Class Initialized
INFO - 2018-06-22 13:51:57 --> Loader Class Initialized
INFO - 2018-06-22 13:51:57 --> Helper loaded: url_helper
INFO - 2018-06-22 13:51:57 --> Helper loaded: form_helper
INFO - 2018-06-22 13:51:57 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:51:57 --> User Agent Class Initialized
INFO - 2018-06-22 13:51:57 --> Controller Class Initialized
INFO - 2018-06-22 13:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-22 13:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:51:57 --> Final output sent to browser
DEBUG - 2018-06-22 13:51:57 --> Total execution time: 0.0197
INFO - 2018-06-22 13:52:02 --> Config Class Initialized
INFO - 2018-06-22 13:52:02 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:52:02 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:52:02 --> Utf8 Class Initialized
INFO - 2018-06-22 13:52:02 --> URI Class Initialized
INFO - 2018-06-22 13:52:02 --> Router Class Initialized
INFO - 2018-06-22 13:52:02 --> Output Class Initialized
INFO - 2018-06-22 13:52:02 --> Security Class Initialized
DEBUG - 2018-06-22 13:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:52:02 --> CSRF cookie sent
INFO - 2018-06-22 13:52:02 --> Input Class Initialized
INFO - 2018-06-22 13:52:02 --> Language Class Initialized
INFO - 2018-06-22 13:52:02 --> Loader Class Initialized
INFO - 2018-06-22 13:52:02 --> Helper loaded: url_helper
INFO - 2018-06-22 13:52:02 --> Helper loaded: form_helper
INFO - 2018-06-22 13:52:02 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:52:02 --> User Agent Class Initialized
INFO - 2018-06-22 13:52:02 --> Controller Class Initialized
INFO - 2018-06-22 13:52:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:52:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-22 13:52:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:52:02 --> Final output sent to browser
DEBUG - 2018-06-22 13:52:02 --> Total execution time: 0.0208
INFO - 2018-06-22 13:52:17 --> Config Class Initialized
INFO - 2018-06-22 13:52:17 --> Hooks Class Initialized
DEBUG - 2018-06-22 13:52:17 --> UTF-8 Support Enabled
INFO - 2018-06-22 13:52:17 --> Utf8 Class Initialized
INFO - 2018-06-22 13:52:17 --> URI Class Initialized
INFO - 2018-06-22 13:52:17 --> Router Class Initialized
INFO - 2018-06-22 13:52:17 --> Output Class Initialized
INFO - 2018-06-22 13:52:17 --> Security Class Initialized
DEBUG - 2018-06-22 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 13:52:17 --> CSRF cookie sent
INFO - 2018-06-22 13:52:17 --> Input Class Initialized
INFO - 2018-06-22 13:52:17 --> Language Class Initialized
INFO - 2018-06-22 13:52:17 --> Loader Class Initialized
INFO - 2018-06-22 13:52:17 --> Helper loaded: url_helper
INFO - 2018-06-22 13:52:17 --> Helper loaded: form_helper
INFO - 2018-06-22 13:52:17 --> Helper loaded: language_helper
DEBUG - 2018-06-22 13:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 13:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 13:52:17 --> User Agent Class Initialized
INFO - 2018-06-22 13:52:17 --> Controller Class Initialized
INFO - 2018-06-22 13:52:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 13:52:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-22 13:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 13:52:17 --> Final output sent to browser
DEBUG - 2018-06-22 13:52:17 --> Total execution time: 0.0221
INFO - 2018-06-22 16:56:03 --> Config Class Initialized
INFO - 2018-06-22 16:56:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 16:56:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 16:56:03 --> Utf8 Class Initialized
INFO - 2018-06-22 16:56:03 --> URI Class Initialized
DEBUG - 2018-06-22 16:56:03 --> No URI present. Default controller set.
INFO - 2018-06-22 16:56:03 --> Router Class Initialized
INFO - 2018-06-22 16:56:03 --> Output Class Initialized
INFO - 2018-06-22 16:56:03 --> Security Class Initialized
DEBUG - 2018-06-22 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 16:56:03 --> CSRF cookie sent
INFO - 2018-06-22 16:56:03 --> Input Class Initialized
INFO - 2018-06-22 16:56:03 --> Language Class Initialized
INFO - 2018-06-22 16:56:03 --> Loader Class Initialized
INFO - 2018-06-22 16:56:03 --> Helper loaded: url_helper
INFO - 2018-06-22 16:56:03 --> Helper loaded: form_helper
INFO - 2018-06-22 16:56:03 --> Helper loaded: language_helper
DEBUG - 2018-06-22 16:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 16:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 16:56:03 --> User Agent Class Initialized
INFO - 2018-06-22 16:56:03 --> Controller Class Initialized
INFO - 2018-06-22 16:56:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 16:56:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 16:56:03 --> Pixel_Model class loaded
INFO - 2018-06-22 16:56:03 --> Database Driver Class Initialized
INFO - 2018-06-22 16:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 16:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 16:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 16:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 16:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 16:56:03 --> Final output sent to browser
DEBUG - 2018-06-22 16:56:03 --> Total execution time: 0.0320
INFO - 2018-06-22 17:12:12 --> Config Class Initialized
INFO - 2018-06-22 17:12:12 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:12 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:12 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:12 --> URI Class Initialized
DEBUG - 2018-06-22 17:12:12 --> No URI present. Default controller set.
INFO - 2018-06-22 17:12:12 --> Router Class Initialized
INFO - 2018-06-22 17:12:12 --> Output Class Initialized
INFO - 2018-06-22 17:12:12 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:12 --> CSRF cookie sent
INFO - 2018-06-22 17:12:12 --> Input Class Initialized
INFO - 2018-06-22 17:12:12 --> Language Class Initialized
INFO - 2018-06-22 17:12:12 --> Loader Class Initialized
INFO - 2018-06-22 17:12:12 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:12 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:12 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:12 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:12 --> Controller Class Initialized
INFO - 2018-06-22 17:12:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:12 --> Pixel_Model class loaded
INFO - 2018-06-22 17:12:12 --> Database Driver Class Initialized
INFO - 2018-06-22 17:12:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:13 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:13 --> Total execution time: 0.0325
INFO - 2018-06-22 17:12:13 --> Config Class Initialized
INFO - 2018-06-22 17:12:13 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:13 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:13 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:13 --> URI Class Initialized
DEBUG - 2018-06-22 17:12:13 --> No URI present. Default controller set.
INFO - 2018-06-22 17:12:13 --> Router Class Initialized
INFO - 2018-06-22 17:12:13 --> Output Class Initialized
INFO - 2018-06-22 17:12:13 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:13 --> CSRF cookie sent
INFO - 2018-06-22 17:12:13 --> Input Class Initialized
INFO - 2018-06-22 17:12:13 --> Language Class Initialized
INFO - 2018-06-22 17:12:13 --> Loader Class Initialized
INFO - 2018-06-22 17:12:13 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:13 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:13 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:13 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:13 --> Controller Class Initialized
INFO - 2018-06-22 17:12:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:13 --> Pixel_Model class loaded
INFO - 2018-06-22 17:12:13 --> Database Driver Class Initialized
INFO - 2018-06-22 17:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 17:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:13 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:13 --> Total execution time: 0.0356
INFO - 2018-06-22 17:12:14 --> Config Class Initialized
INFO - 2018-06-22 17:12:14 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:14 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:14 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:14 --> URI Class Initialized
DEBUG - 2018-06-22 17:12:14 --> No URI present. Default controller set.
INFO - 2018-06-22 17:12:14 --> Router Class Initialized
INFO - 2018-06-22 17:12:14 --> Output Class Initialized
INFO - 2018-06-22 17:12:14 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:14 --> CSRF cookie sent
INFO - 2018-06-22 17:12:14 --> Input Class Initialized
INFO - 2018-06-22 17:12:14 --> Language Class Initialized
INFO - 2018-06-22 17:12:14 --> Loader Class Initialized
INFO - 2018-06-22 17:12:14 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:14 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:14 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:14 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:14 --> Controller Class Initialized
INFO - 2018-06-22 17:12:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:14 --> Pixel_Model class loaded
INFO - 2018-06-22 17:12:14 --> Database Driver Class Initialized
INFO - 2018-06-22 17:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:14 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:14 --> Total execution time: 0.0324
INFO - 2018-06-22 17:12:15 --> Config Class Initialized
INFO - 2018-06-22 17:12:15 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:15 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:15 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:15 --> URI Class Initialized
INFO - 2018-06-22 17:12:15 --> Router Class Initialized
INFO - 2018-06-22 17:12:15 --> Output Class Initialized
INFO - 2018-06-22 17:12:15 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:15 --> CSRF cookie sent
INFO - 2018-06-22 17:12:15 --> Input Class Initialized
INFO - 2018-06-22 17:12:15 --> Language Class Initialized
ERROR - 2018-06-22 17:12:15 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-22 17:12:21 --> Config Class Initialized
INFO - 2018-06-22 17:12:21 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:21 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:21 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:21 --> URI Class Initialized
DEBUG - 2018-06-22 17:12:21 --> No URI present. Default controller set.
INFO - 2018-06-22 17:12:21 --> Router Class Initialized
INFO - 2018-06-22 17:12:21 --> Output Class Initialized
INFO - 2018-06-22 17:12:21 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:21 --> CSRF cookie sent
INFO - 2018-06-22 17:12:21 --> Input Class Initialized
INFO - 2018-06-22 17:12:21 --> Language Class Initialized
INFO - 2018-06-22 17:12:21 --> Loader Class Initialized
INFO - 2018-06-22 17:12:21 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:21 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:21 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:21 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:21 --> Controller Class Initialized
INFO - 2018-06-22 17:12:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:21 --> Pixel_Model class loaded
INFO - 2018-06-22 17:12:21 --> Database Driver Class Initialized
INFO - 2018-06-22 17:12:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 17:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 17:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:21 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:21 --> Total execution time: 0.0361
INFO - 2018-06-22 17:12:22 --> Config Class Initialized
INFO - 2018-06-22 17:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:22 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:22 --> URI Class Initialized
INFO - 2018-06-22 17:12:22 --> Router Class Initialized
INFO - 2018-06-22 17:12:22 --> Output Class Initialized
INFO - 2018-06-22 17:12:22 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:22 --> CSRF cookie sent
INFO - 2018-06-22 17:12:22 --> Input Class Initialized
INFO - 2018-06-22 17:12:22 --> Language Class Initialized
ERROR - 2018-06-22 17:12:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-22 17:12:22 --> Config Class Initialized
INFO - 2018-06-22 17:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:22 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:22 --> URI Class Initialized
INFO - 2018-06-22 17:12:22 --> Router Class Initialized
INFO - 2018-06-22 17:12:22 --> Output Class Initialized
INFO - 2018-06-22 17:12:22 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:22 --> CSRF cookie sent
INFO - 2018-06-22 17:12:22 --> Input Class Initialized
INFO - 2018-06-22 17:12:22 --> Language Class Initialized
ERROR - 2018-06-22 17:12:22 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-22 17:12:22 --> Config Class Initialized
INFO - 2018-06-22 17:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:22 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:22 --> URI Class Initialized
INFO - 2018-06-22 17:12:22 --> Router Class Initialized
INFO - 2018-06-22 17:12:22 --> Output Class Initialized
INFO - 2018-06-22 17:12:22 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:22 --> CSRF cookie sent
INFO - 2018-06-22 17:12:22 --> Input Class Initialized
INFO - 2018-06-22 17:12:22 --> Language Class Initialized
INFO - 2018-06-22 17:12:22 --> Loader Class Initialized
INFO - 2018-06-22 17:12:22 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:22 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:22 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:22 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:22 --> Controller Class Initialized
INFO - 2018-06-22 17:12:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:22 --> Pixel_Model class loaded
INFO - 2018-06-22 17:12:22 --> Database Driver Class Initialized
INFO - 2018-06-22 17:12:22 --> Model "QuestionsModel" initialized
ERROR - 2018-06-22 17:12:22 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-22 17:12:22 --> Config Class Initialized
INFO - 2018-06-22 17:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:22 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:22 --> URI Class Initialized
INFO - 2018-06-22 17:12:22 --> Router Class Initialized
INFO - 2018-06-22 17:12:22 --> Output Class Initialized
INFO - 2018-06-22 17:12:22 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:22 --> CSRF cookie sent
INFO - 2018-06-22 17:12:22 --> Input Class Initialized
INFO - 2018-06-22 17:12:22 --> Language Class Initialized
INFO - 2018-06-22 17:12:22 --> Loader Class Initialized
INFO - 2018-06-22 17:12:22 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:22 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:22 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:22 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:22 --> Controller Class Initialized
INFO - 2018-06-22 17:12:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 17:12:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 17:12:22 --> Could not find the language line "req_email"
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 17:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:22 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:22 --> Total execution time: 0.0218
INFO - 2018-06-22 17:12:23 --> Config Class Initialized
INFO - 2018-06-22 17:12:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:23 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:23 --> URI Class Initialized
INFO - 2018-06-22 17:12:23 --> Router Class Initialized
INFO - 2018-06-22 17:12:23 --> Output Class Initialized
INFO - 2018-06-22 17:12:23 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:23 --> CSRF cookie sent
INFO - 2018-06-22 17:12:23 --> Input Class Initialized
INFO - 2018-06-22 17:12:23 --> Language Class Initialized
INFO - 2018-06-22 17:12:23 --> Loader Class Initialized
INFO - 2018-06-22 17:12:23 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:23 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:23 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:23 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:23 --> Controller Class Initialized
INFO - 2018-06-22 17:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:23 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:23 --> Total execution time: 0.0417
INFO - 2018-06-22 17:12:23 --> Config Class Initialized
INFO - 2018-06-22 17:12:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:23 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:23 --> URI Class Initialized
INFO - 2018-06-22 17:12:23 --> Router Class Initialized
INFO - 2018-06-22 17:12:23 --> Output Class Initialized
INFO - 2018-06-22 17:12:23 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:23 --> CSRF cookie sent
INFO - 2018-06-22 17:12:23 --> Input Class Initialized
INFO - 2018-06-22 17:12:23 --> Language Class Initialized
INFO - 2018-06-22 17:12:23 --> Loader Class Initialized
INFO - 2018-06-22 17:12:23 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:23 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:23 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:23 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:23 --> Controller Class Initialized
INFO - 2018-06-22 17:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 17:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:23 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:23 --> Total execution time: 0.0305
INFO - 2018-06-22 17:12:24 --> Config Class Initialized
INFO - 2018-06-22 17:12:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:24 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:24 --> URI Class Initialized
INFO - 2018-06-22 17:12:24 --> Router Class Initialized
INFO - 2018-06-22 17:12:24 --> Output Class Initialized
INFO - 2018-06-22 17:12:24 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:24 --> CSRF cookie sent
INFO - 2018-06-22 17:12:24 --> Input Class Initialized
INFO - 2018-06-22 17:12:24 --> Language Class Initialized
INFO - 2018-06-22 17:12:24 --> Loader Class Initialized
INFO - 2018-06-22 17:12:24 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:24 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:24 --> Controller Class Initialized
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:24 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:24 --> Total execution time: 0.0215
INFO - 2018-06-22 17:12:24 --> Config Class Initialized
INFO - 2018-06-22 17:12:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:24 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:24 --> URI Class Initialized
INFO - 2018-06-22 17:12:24 --> Router Class Initialized
INFO - 2018-06-22 17:12:24 --> Output Class Initialized
INFO - 2018-06-22 17:12:24 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:24 --> CSRF cookie sent
INFO - 2018-06-22 17:12:24 --> Input Class Initialized
INFO - 2018-06-22 17:12:24 --> Language Class Initialized
INFO - 2018-06-22 17:12:24 --> Loader Class Initialized
INFO - 2018-06-22 17:12:24 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:24 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:24 --> Controller Class Initialized
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:24 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:24 --> Total execution time: 0.0226
INFO - 2018-06-22 17:12:24 --> Config Class Initialized
INFO - 2018-06-22 17:12:24 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:24 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:24 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:24 --> URI Class Initialized
INFO - 2018-06-22 17:12:24 --> Router Class Initialized
INFO - 2018-06-22 17:12:24 --> Output Class Initialized
INFO - 2018-06-22 17:12:24 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:24 --> CSRF cookie sent
INFO - 2018-06-22 17:12:24 --> Input Class Initialized
INFO - 2018-06-22 17:12:24 --> Language Class Initialized
INFO - 2018-06-22 17:12:24 --> Loader Class Initialized
INFO - 2018-06-22 17:12:24 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:24 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:24 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:24 --> Controller Class Initialized
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 17:12:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 17:12:24 --> Could not find the language line "req_email"
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 17:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:24 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:24 --> Total execution time: 0.0221
INFO - 2018-06-22 17:12:25 --> Config Class Initialized
INFO - 2018-06-22 17:12:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 17:12:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 17:12:25 --> Utf8 Class Initialized
INFO - 2018-06-22 17:12:25 --> URI Class Initialized
INFO - 2018-06-22 17:12:25 --> Router Class Initialized
INFO - 2018-06-22 17:12:25 --> Output Class Initialized
INFO - 2018-06-22 17:12:25 --> Security Class Initialized
DEBUG - 2018-06-22 17:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 17:12:25 --> CSRF cookie sent
INFO - 2018-06-22 17:12:25 --> Input Class Initialized
INFO - 2018-06-22 17:12:25 --> Language Class Initialized
INFO - 2018-06-22 17:12:25 --> Loader Class Initialized
INFO - 2018-06-22 17:12:25 --> Helper loaded: url_helper
INFO - 2018-06-22 17:12:25 --> Helper loaded: form_helper
INFO - 2018-06-22 17:12:25 --> Helper loaded: language_helper
DEBUG - 2018-06-22 17:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 17:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 17:12:25 --> User Agent Class Initialized
INFO - 2018-06-22 17:12:25 --> Controller Class Initialized
INFO - 2018-06-22 17:12:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 17:12:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-22 17:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 17:12:25 --> Final output sent to browser
DEBUG - 2018-06-22 17:12:25 --> Total execution time: 0.0304
INFO - 2018-06-22 19:05:56 --> Config Class Initialized
INFO - 2018-06-22 19:05:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:05:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:05:56 --> Utf8 Class Initialized
INFO - 2018-06-22 19:05:56 --> URI Class Initialized
DEBUG - 2018-06-22 19:05:56 --> No URI present. Default controller set.
INFO - 2018-06-22 19:05:56 --> Router Class Initialized
INFO - 2018-06-22 19:05:56 --> Output Class Initialized
INFO - 2018-06-22 19:05:56 --> Security Class Initialized
DEBUG - 2018-06-22 19:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:05:56 --> CSRF cookie sent
INFO - 2018-06-22 19:05:56 --> Input Class Initialized
INFO - 2018-06-22 19:05:56 --> Language Class Initialized
INFO - 2018-06-22 19:05:56 --> Loader Class Initialized
INFO - 2018-06-22 19:05:56 --> Helper loaded: url_helper
INFO - 2018-06-22 19:05:56 --> Helper loaded: form_helper
INFO - 2018-06-22 19:05:56 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:05:56 --> User Agent Class Initialized
INFO - 2018-06-22 19:05:56 --> Controller Class Initialized
INFO - 2018-06-22 19:05:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:05:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:05:56 --> Pixel_Model class loaded
INFO - 2018-06-22 19:05:56 --> Database Driver Class Initialized
INFO - 2018-06-22 19:05:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 19:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 19:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:05:56 --> Final output sent to browser
DEBUG - 2018-06-22 19:05:56 --> Total execution time: 0.0359
INFO - 2018-06-22 19:06:28 --> Config Class Initialized
INFO - 2018-06-22 19:06:28 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:28 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:28 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:28 --> URI Class Initialized
DEBUG - 2018-06-22 19:06:28 --> No URI present. Default controller set.
INFO - 2018-06-22 19:06:28 --> Router Class Initialized
INFO - 2018-06-22 19:06:28 --> Output Class Initialized
INFO - 2018-06-22 19:06:28 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:28 --> CSRF cookie sent
INFO - 2018-06-22 19:06:28 --> Input Class Initialized
INFO - 2018-06-22 19:06:28 --> Language Class Initialized
INFO - 2018-06-22 19:06:28 --> Loader Class Initialized
INFO - 2018-06-22 19:06:28 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:28 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:28 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:28 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:28 --> Controller Class Initialized
INFO - 2018-06-22 19:06:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:06:28 --> Pixel_Model class loaded
INFO - 2018-06-22 19:06:28 --> Database Driver Class Initialized
INFO - 2018-06-22 19:06:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 19:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 19:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:28 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:28 --> Total execution time: 0.0378
INFO - 2018-06-22 19:06:40 --> Config Class Initialized
INFO - 2018-06-22 19:06:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:40 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:40 --> URI Class Initialized
INFO - 2018-06-22 19:06:40 --> Router Class Initialized
INFO - 2018-06-22 19:06:40 --> Output Class Initialized
INFO - 2018-06-22 19:06:40 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:40 --> CSRF cookie sent
INFO - 2018-06-22 19:06:40 --> Input Class Initialized
INFO - 2018-06-22 19:06:40 --> Language Class Initialized
INFO - 2018-06-22 19:06:40 --> Loader Class Initialized
INFO - 2018-06-22 19:06:40 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:40 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:40 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:40 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:40 --> Controller Class Initialized
INFO - 2018-06-22 19:06:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-22 19:06:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 19:06:40 --> Could not find the language line "req_email"
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-22 19:06:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:40 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:40 --> Total execution time: 0.0276
INFO - 2018-06-22 19:06:42 --> Config Class Initialized
INFO - 2018-06-22 19:06:42 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:42 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:42 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:42 --> URI Class Initialized
INFO - 2018-06-22 19:06:42 --> Router Class Initialized
INFO - 2018-06-22 19:06:42 --> Output Class Initialized
INFO - 2018-06-22 19:06:42 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:42 --> CSRF cookie sent
INFO - 2018-06-22 19:06:42 --> Input Class Initialized
INFO - 2018-06-22 19:06:42 --> Language Class Initialized
INFO - 2018-06-22 19:06:42 --> Loader Class Initialized
INFO - 2018-06-22 19:06:42 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:42 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:42 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:42 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:42 --> Controller Class Initialized
INFO - 2018-06-22 19:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:06:42 --> Pixel_Model class loaded
INFO - 2018-06-22 19:06:42 --> Database Driver Class Initialized
INFO - 2018-06-22 19:06:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-22 19:06:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-22 19:06:42 --> Could not find the language line "req_email"
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-22 19:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:42 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:42 --> Total execution time: 0.0396
INFO - 2018-06-22 19:06:49 --> Config Class Initialized
INFO - 2018-06-22 19:06:49 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:49 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:49 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:49 --> URI Class Initialized
INFO - 2018-06-22 19:06:49 --> Router Class Initialized
INFO - 2018-06-22 19:06:49 --> Output Class Initialized
INFO - 2018-06-22 19:06:49 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:49 --> CSRF cookie sent
INFO - 2018-06-22 19:06:49 --> Input Class Initialized
INFO - 2018-06-22 19:06:49 --> Language Class Initialized
INFO - 2018-06-22 19:06:49 --> Loader Class Initialized
INFO - 2018-06-22 19:06:49 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:49 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:49 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:49 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:49 --> Controller Class Initialized
INFO - 2018-06-22 19:06:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 19:06:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:49 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:49 --> Total execution time: 0.0219
INFO - 2018-06-22 19:06:51 --> Config Class Initialized
INFO - 2018-06-22 19:06:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:51 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:51 --> URI Class Initialized
INFO - 2018-06-22 19:06:51 --> Router Class Initialized
INFO - 2018-06-22 19:06:51 --> Output Class Initialized
INFO - 2018-06-22 19:06:51 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:51 --> CSRF cookie sent
INFO - 2018-06-22 19:06:51 --> Input Class Initialized
INFO - 2018-06-22 19:06:51 --> Language Class Initialized
ERROR - 2018-06-22 19:06:51 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-22 19:06:56 --> Config Class Initialized
INFO - 2018-06-22 19:06:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:56 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:56 --> URI Class Initialized
INFO - 2018-06-22 19:06:56 --> Router Class Initialized
INFO - 2018-06-22 19:06:56 --> Output Class Initialized
INFO - 2018-06-22 19:06:56 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:56 --> CSRF cookie sent
INFO - 2018-06-22 19:06:56 --> Input Class Initialized
INFO - 2018-06-22 19:06:56 --> Language Class Initialized
INFO - 2018-06-22 19:06:56 --> Loader Class Initialized
INFO - 2018-06-22 19:06:56 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:56 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:56 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:56 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:56 --> Controller Class Initialized
INFO - 2018-06-22 19:06:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-22 19:06:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:56 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:56 --> Total execution time: 0.0252
INFO - 2018-06-22 19:06:59 --> Config Class Initialized
INFO - 2018-06-22 19:06:59 --> Hooks Class Initialized
DEBUG - 2018-06-22 19:06:59 --> UTF-8 Support Enabled
INFO - 2018-06-22 19:06:59 --> Utf8 Class Initialized
INFO - 2018-06-22 19:06:59 --> URI Class Initialized
INFO - 2018-06-22 19:06:59 --> Router Class Initialized
INFO - 2018-06-22 19:06:59 --> Output Class Initialized
INFO - 2018-06-22 19:06:59 --> Security Class Initialized
DEBUG - 2018-06-22 19:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 19:06:59 --> CSRF cookie sent
INFO - 2018-06-22 19:06:59 --> Input Class Initialized
INFO - 2018-06-22 19:06:59 --> Language Class Initialized
INFO - 2018-06-22 19:06:59 --> Loader Class Initialized
INFO - 2018-06-22 19:06:59 --> Helper loaded: url_helper
INFO - 2018-06-22 19:06:59 --> Helper loaded: form_helper
INFO - 2018-06-22 19:06:59 --> Helper loaded: language_helper
DEBUG - 2018-06-22 19:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 19:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 19:06:59 --> User Agent Class Initialized
INFO - 2018-06-22 19:06:59 --> Controller Class Initialized
INFO - 2018-06-22 19:06:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 19:06:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 19:06:59 --> Pixel_Model class loaded
INFO - 2018-06-22 19:06:59 --> Database Driver Class Initialized
INFO - 2018-06-22 19:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-22 19:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 19:06:59 --> Final output sent to browser
DEBUG - 2018-06-22 19:06:59 --> Total execution time: 0.0341
INFO - 2018-06-22 21:45:33 --> Config Class Initialized
INFO - 2018-06-22 21:45:33 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:45:33 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:45:33 --> Utf8 Class Initialized
INFO - 2018-06-22 21:45:33 --> URI Class Initialized
DEBUG - 2018-06-22 21:45:33 --> No URI present. Default controller set.
INFO - 2018-06-22 21:45:33 --> Router Class Initialized
INFO - 2018-06-22 21:45:33 --> Output Class Initialized
INFO - 2018-06-22 21:45:33 --> Security Class Initialized
DEBUG - 2018-06-22 21:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:45:33 --> CSRF cookie sent
INFO - 2018-06-22 21:45:33 --> Input Class Initialized
INFO - 2018-06-22 21:45:33 --> Language Class Initialized
INFO - 2018-06-22 21:45:33 --> Loader Class Initialized
INFO - 2018-06-22 21:45:33 --> Helper loaded: url_helper
INFO - 2018-06-22 21:45:33 --> Helper loaded: form_helper
INFO - 2018-06-22 21:45:33 --> Helper loaded: language_helper
DEBUG - 2018-06-22 21:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:45:33 --> User Agent Class Initialized
INFO - 2018-06-22 21:45:33 --> Controller Class Initialized
INFO - 2018-06-22 21:45:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 21:45:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 21:45:33 --> Pixel_Model class loaded
INFO - 2018-06-22 21:45:33 --> Database Driver Class Initialized
INFO - 2018-06-22 21:45:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 21:45:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 21:45:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 21:45:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 21:45:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 21:45:33 --> Final output sent to browser
DEBUG - 2018-06-22 21:45:33 --> Total execution time: 0.0327
INFO - 2018-06-22 22:23:42 --> Config Class Initialized
INFO - 2018-06-22 22:23:42 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:23:42 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:23:42 --> Utf8 Class Initialized
INFO - 2018-06-22 22:23:42 --> URI Class Initialized
DEBUG - 2018-06-22 22:23:42 --> No URI present. Default controller set.
INFO - 2018-06-22 22:23:42 --> Router Class Initialized
INFO - 2018-06-22 22:23:42 --> Output Class Initialized
INFO - 2018-06-22 22:23:42 --> Security Class Initialized
DEBUG - 2018-06-22 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:23:42 --> CSRF cookie sent
INFO - 2018-06-22 22:23:42 --> Input Class Initialized
INFO - 2018-06-22 22:23:42 --> Language Class Initialized
INFO - 2018-06-22 22:23:42 --> Loader Class Initialized
INFO - 2018-06-22 22:23:42 --> Helper loaded: url_helper
INFO - 2018-06-22 22:23:42 --> Helper loaded: form_helper
INFO - 2018-06-22 22:23:42 --> Helper loaded: language_helper
DEBUG - 2018-06-22 22:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:23:42 --> User Agent Class Initialized
INFO - 2018-06-22 22:23:42 --> Controller Class Initialized
INFO - 2018-06-22 22:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-22 22:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-22 22:23:42 --> Pixel_Model class loaded
INFO - 2018-06-22 22:23:42 --> Database Driver Class Initialized
INFO - 2018-06-22 22:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-22 22:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-22 22:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-22 22:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-22 22:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-22 22:23:42 --> Final output sent to browser
DEBUG - 2018-06-22 22:23:42 --> Total execution time: 0.0321

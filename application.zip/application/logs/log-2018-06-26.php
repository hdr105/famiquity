<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-26 00:02:25 --> Config Class Initialized
INFO - 2018-06-26 00:02:25 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:02:25 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:02:25 --> Utf8 Class Initialized
INFO - 2018-06-26 00:02:25 --> URI Class Initialized
INFO - 2018-06-26 00:02:25 --> Router Class Initialized
INFO - 2018-06-26 00:02:25 --> Output Class Initialized
INFO - 2018-06-26 00:02:25 --> Security Class Initialized
DEBUG - 2018-06-26 00:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:02:25 --> CSRF cookie sent
INFO - 2018-06-26 00:02:25 --> Input Class Initialized
INFO - 2018-06-26 00:02:25 --> Language Class Initialized
INFO - 2018-06-26 00:02:25 --> Loader Class Initialized
INFO - 2018-06-26 00:02:25 --> Helper loaded: url_helper
INFO - 2018-06-26 00:02:25 --> Helper loaded: form_helper
INFO - 2018-06-26 00:02:25 --> Helper loaded: language_helper
DEBUG - 2018-06-26 00:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:02:25 --> User Agent Class Initialized
INFO - 2018-06-26 00:02:25 --> Controller Class Initialized
INFO - 2018-06-26 00:02:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 00:02:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-26 00:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 00:02:25 --> Final output sent to browser
DEBUG - 2018-06-26 00:02:25 --> Total execution time: 0.0225
INFO - 2018-06-26 01:14:39 --> Config Class Initialized
INFO - 2018-06-26 01:14:39 --> Hooks Class Initialized
DEBUG - 2018-06-26 01:14:39 --> UTF-8 Support Enabled
INFO - 2018-06-26 01:14:39 --> Utf8 Class Initialized
INFO - 2018-06-26 01:14:39 --> URI Class Initialized
DEBUG - 2018-06-26 01:14:39 --> No URI present. Default controller set.
INFO - 2018-06-26 01:14:39 --> Router Class Initialized
INFO - 2018-06-26 01:14:39 --> Output Class Initialized
INFO - 2018-06-26 01:14:39 --> Security Class Initialized
DEBUG - 2018-06-26 01:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 01:14:39 --> CSRF cookie sent
INFO - 2018-06-26 01:14:39 --> Input Class Initialized
INFO - 2018-06-26 01:14:39 --> Language Class Initialized
INFO - 2018-06-26 01:14:39 --> Loader Class Initialized
INFO - 2018-06-26 01:14:39 --> Helper loaded: url_helper
INFO - 2018-06-26 01:14:39 --> Helper loaded: form_helper
INFO - 2018-06-26 01:14:39 --> Helper loaded: language_helper
DEBUG - 2018-06-26 01:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 01:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 01:14:39 --> User Agent Class Initialized
INFO - 2018-06-26 01:14:39 --> Controller Class Initialized
INFO - 2018-06-26 01:14:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 01:14:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 01:14:39 --> Pixel_Model class loaded
INFO - 2018-06-26 01:14:39 --> Database Driver Class Initialized
INFO - 2018-06-26 01:14:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 01:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 01:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 01:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 01:14:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 01:14:39 --> Final output sent to browser
DEBUG - 2018-06-26 01:14:39 --> Total execution time: 0.0315
INFO - 2018-06-26 01:21:09 --> Config Class Initialized
INFO - 2018-06-26 01:21:09 --> Hooks Class Initialized
DEBUG - 2018-06-26 01:21:09 --> UTF-8 Support Enabled
INFO - 2018-06-26 01:21:09 --> Utf8 Class Initialized
INFO - 2018-06-26 01:21:09 --> URI Class Initialized
DEBUG - 2018-06-26 01:21:09 --> No URI present. Default controller set.
INFO - 2018-06-26 01:21:09 --> Router Class Initialized
INFO - 2018-06-26 01:21:09 --> Output Class Initialized
INFO - 2018-06-26 01:21:09 --> Security Class Initialized
DEBUG - 2018-06-26 01:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 01:21:09 --> CSRF cookie sent
INFO - 2018-06-26 01:21:09 --> Input Class Initialized
INFO - 2018-06-26 01:21:09 --> Language Class Initialized
INFO - 2018-06-26 01:21:09 --> Loader Class Initialized
INFO - 2018-06-26 01:21:09 --> Helper loaded: url_helper
INFO - 2018-06-26 01:21:09 --> Helper loaded: form_helper
INFO - 2018-06-26 01:21:09 --> Helper loaded: language_helper
DEBUG - 2018-06-26 01:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 01:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 01:21:09 --> User Agent Class Initialized
INFO - 2018-06-26 01:21:09 --> Controller Class Initialized
INFO - 2018-06-26 01:21:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 01:21:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 01:21:09 --> Pixel_Model class loaded
INFO - 2018-06-26 01:21:09 --> Database Driver Class Initialized
INFO - 2018-06-26 01:21:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 01:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 01:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 01:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 01:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 01:21:09 --> Final output sent to browser
DEBUG - 2018-06-26 01:21:09 --> Total execution time: 0.0329
INFO - 2018-06-26 01:45:59 --> Config Class Initialized
INFO - 2018-06-26 01:45:59 --> Hooks Class Initialized
DEBUG - 2018-06-26 01:45:59 --> UTF-8 Support Enabled
INFO - 2018-06-26 01:45:59 --> Utf8 Class Initialized
INFO - 2018-06-26 01:45:59 --> URI Class Initialized
INFO - 2018-06-26 01:45:59 --> Router Class Initialized
INFO - 2018-06-26 01:45:59 --> Output Class Initialized
INFO - 2018-06-26 01:45:59 --> Security Class Initialized
DEBUG - 2018-06-26 01:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 01:45:59 --> CSRF cookie sent
INFO - 2018-06-26 01:45:59 --> Input Class Initialized
INFO - 2018-06-26 01:45:59 --> Language Class Initialized
INFO - 2018-06-26 01:45:59 --> Loader Class Initialized
INFO - 2018-06-26 01:45:59 --> Helper loaded: url_helper
INFO - 2018-06-26 01:45:59 --> Helper loaded: form_helper
INFO - 2018-06-26 01:45:59 --> Helper loaded: language_helper
DEBUG - 2018-06-26 01:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 01:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 01:45:59 --> User Agent Class Initialized
INFO - 2018-06-26 01:45:59 --> Controller Class Initialized
INFO - 2018-06-26 01:45:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 01:45:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-06-26 01:45:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 01:45:59 --> Final output sent to browser
DEBUG - 2018-06-26 01:45:59 --> Total execution time: 0.0208
INFO - 2018-06-26 02:19:37 --> Config Class Initialized
INFO - 2018-06-26 02:19:37 --> Hooks Class Initialized
DEBUG - 2018-06-26 02:19:37 --> UTF-8 Support Enabled
INFO - 2018-06-26 02:19:37 --> Utf8 Class Initialized
INFO - 2018-06-26 02:19:37 --> URI Class Initialized
INFO - 2018-06-26 02:19:37 --> Router Class Initialized
INFO - 2018-06-26 02:19:37 --> Output Class Initialized
INFO - 2018-06-26 02:19:37 --> Security Class Initialized
DEBUG - 2018-06-26 02:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 02:19:37 --> CSRF cookie sent
INFO - 2018-06-26 02:19:37 --> Input Class Initialized
INFO - 2018-06-26 02:19:37 --> Language Class Initialized
ERROR - 2018-06-26 02:19:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 02:19:41 --> Config Class Initialized
INFO - 2018-06-26 02:19:41 --> Hooks Class Initialized
DEBUG - 2018-06-26 02:19:41 --> UTF-8 Support Enabled
INFO - 2018-06-26 02:19:41 --> Utf8 Class Initialized
INFO - 2018-06-26 02:19:41 --> URI Class Initialized
INFO - 2018-06-26 02:19:41 --> Router Class Initialized
INFO - 2018-06-26 02:19:41 --> Output Class Initialized
INFO - 2018-06-26 02:19:41 --> Security Class Initialized
DEBUG - 2018-06-26 02:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 02:19:41 --> CSRF cookie sent
INFO - 2018-06-26 02:19:41 --> Input Class Initialized
INFO - 2018-06-26 02:19:41 --> Language Class Initialized
INFO - 2018-06-26 02:19:41 --> Loader Class Initialized
INFO - 2018-06-26 02:19:41 --> Helper loaded: url_helper
INFO - 2018-06-26 02:19:41 --> Helper loaded: form_helper
INFO - 2018-06-26 02:19:41 --> Helper loaded: language_helper
DEBUG - 2018-06-26 02:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 02:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 02:19:41 --> User Agent Class Initialized
INFO - 2018-06-26 02:19:41 --> Controller Class Initialized
INFO - 2018-06-26 02:19:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 02:19:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-26 02:19:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 02:19:41 --> Final output sent to browser
DEBUG - 2018-06-26 02:19:41 --> Total execution time: 0.0266
INFO - 2018-06-26 05:15:58 --> Config Class Initialized
INFO - 2018-06-26 05:15:58 --> Hooks Class Initialized
DEBUG - 2018-06-26 05:15:58 --> UTF-8 Support Enabled
INFO - 2018-06-26 05:15:58 --> Utf8 Class Initialized
INFO - 2018-06-26 05:15:58 --> URI Class Initialized
INFO - 2018-06-26 05:15:58 --> Router Class Initialized
INFO - 2018-06-26 05:15:58 --> Output Class Initialized
INFO - 2018-06-26 05:15:58 --> Security Class Initialized
DEBUG - 2018-06-26 05:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 05:15:58 --> CSRF cookie sent
INFO - 2018-06-26 05:15:58 --> Input Class Initialized
INFO - 2018-06-26 05:15:58 --> Language Class Initialized
ERROR - 2018-06-26 05:15:58 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 05:16:01 --> Config Class Initialized
INFO - 2018-06-26 05:16:01 --> Hooks Class Initialized
DEBUG - 2018-06-26 05:16:01 --> UTF-8 Support Enabled
INFO - 2018-06-26 05:16:01 --> Utf8 Class Initialized
INFO - 2018-06-26 05:16:01 --> URI Class Initialized
DEBUG - 2018-06-26 05:16:01 --> No URI present. Default controller set.
INFO - 2018-06-26 05:16:01 --> Router Class Initialized
INFO - 2018-06-26 05:16:01 --> Output Class Initialized
INFO - 2018-06-26 05:16:01 --> Security Class Initialized
DEBUG - 2018-06-26 05:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 05:16:01 --> CSRF cookie sent
INFO - 2018-06-26 05:16:01 --> Input Class Initialized
INFO - 2018-06-26 05:16:01 --> Language Class Initialized
INFO - 2018-06-26 05:16:01 --> Loader Class Initialized
INFO - 2018-06-26 05:16:01 --> Helper loaded: url_helper
INFO - 2018-06-26 05:16:01 --> Helper loaded: form_helper
INFO - 2018-06-26 05:16:01 --> Helper loaded: language_helper
DEBUG - 2018-06-26 05:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 05:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 05:16:01 --> User Agent Class Initialized
INFO - 2018-06-26 05:16:01 --> Controller Class Initialized
INFO - 2018-06-26 05:16:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 05:16:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 05:16:01 --> Pixel_Model class loaded
INFO - 2018-06-26 05:16:01 --> Database Driver Class Initialized
INFO - 2018-06-26 05:16:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 05:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 05:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 05:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 05:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 05:16:01 --> Final output sent to browser
DEBUG - 2018-06-26 05:16:01 --> Total execution time: 0.0301
INFO - 2018-06-26 05:16:41 --> Config Class Initialized
INFO - 2018-06-26 05:16:41 --> Hooks Class Initialized
DEBUG - 2018-06-26 05:16:41 --> UTF-8 Support Enabled
INFO - 2018-06-26 05:16:41 --> Utf8 Class Initialized
INFO - 2018-06-26 05:16:41 --> URI Class Initialized
INFO - 2018-06-26 05:16:41 --> Router Class Initialized
INFO - 2018-06-26 05:16:41 --> Output Class Initialized
INFO - 2018-06-26 05:16:41 --> Security Class Initialized
DEBUG - 2018-06-26 05:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 05:16:41 --> CSRF cookie sent
INFO - 2018-06-26 05:16:41 --> Input Class Initialized
INFO - 2018-06-26 05:16:41 --> Language Class Initialized
INFO - 2018-06-26 05:16:41 --> Loader Class Initialized
INFO - 2018-06-26 05:16:41 --> Helper loaded: url_helper
INFO - 2018-06-26 05:16:41 --> Helper loaded: form_helper
INFO - 2018-06-26 05:16:41 --> Helper loaded: language_helper
DEBUG - 2018-06-26 05:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 05:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 05:16:41 --> User Agent Class Initialized
INFO - 2018-06-26 05:16:41 --> Controller Class Initialized
INFO - 2018-06-26 05:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 05:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-26 05:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 05:16:41 --> Final output sent to browser
DEBUG - 2018-06-26 05:16:41 --> Total execution time: 0.0229
INFO - 2018-06-26 05:37:23 --> Config Class Initialized
INFO - 2018-06-26 05:37:23 --> Hooks Class Initialized
DEBUG - 2018-06-26 05:37:23 --> UTF-8 Support Enabled
INFO - 2018-06-26 05:37:23 --> Utf8 Class Initialized
INFO - 2018-06-26 05:37:23 --> URI Class Initialized
INFO - 2018-06-26 05:37:23 --> Router Class Initialized
INFO - 2018-06-26 05:37:23 --> Output Class Initialized
INFO - 2018-06-26 05:37:23 --> Security Class Initialized
DEBUG - 2018-06-26 05:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 05:37:23 --> CSRF cookie sent
INFO - 2018-06-26 05:37:23 --> Input Class Initialized
INFO - 2018-06-26 05:37:23 --> Language Class Initialized
ERROR - 2018-06-26 05:37:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 05:39:37 --> Config Class Initialized
INFO - 2018-06-26 05:39:37 --> Hooks Class Initialized
DEBUG - 2018-06-26 05:39:37 --> UTF-8 Support Enabled
INFO - 2018-06-26 05:39:37 --> Utf8 Class Initialized
INFO - 2018-06-26 05:39:37 --> URI Class Initialized
INFO - 2018-06-26 05:39:37 --> Router Class Initialized
INFO - 2018-06-26 05:39:37 --> Output Class Initialized
INFO - 2018-06-26 05:39:37 --> Security Class Initialized
DEBUG - 2018-06-26 05:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 05:39:37 --> CSRF cookie sent
INFO - 2018-06-26 05:39:37 --> Input Class Initialized
INFO - 2018-06-26 05:39:37 --> Language Class Initialized
INFO - 2018-06-26 05:39:37 --> Loader Class Initialized
INFO - 2018-06-26 05:39:37 --> Helper loaded: url_helper
INFO - 2018-06-26 05:39:37 --> Helper loaded: form_helper
INFO - 2018-06-26 05:39:37 --> Helper loaded: language_helper
DEBUG - 2018-06-26 05:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 05:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 05:39:37 --> User Agent Class Initialized
INFO - 2018-06-26 05:39:37 --> Controller Class Initialized
INFO - 2018-06-26 05:39:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 05:39:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-26 05:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 05:39:37 --> Final output sent to browser
DEBUG - 2018-06-26 05:39:37 --> Total execution time: 0.0238
INFO - 2018-06-26 09:27:36 --> Config Class Initialized
INFO - 2018-06-26 09:27:36 --> Hooks Class Initialized
DEBUG - 2018-06-26 09:27:36 --> UTF-8 Support Enabled
INFO - 2018-06-26 09:27:36 --> Utf8 Class Initialized
INFO - 2018-06-26 09:27:36 --> URI Class Initialized
INFO - 2018-06-26 09:27:36 --> Router Class Initialized
INFO - 2018-06-26 09:27:36 --> Output Class Initialized
INFO - 2018-06-26 09:27:36 --> Security Class Initialized
DEBUG - 2018-06-26 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 09:27:36 --> CSRF cookie sent
INFO - 2018-06-26 09:27:36 --> Input Class Initialized
INFO - 2018-06-26 09:27:36 --> Language Class Initialized
ERROR - 2018-06-26 09:27:36 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 09:27:40 --> Config Class Initialized
INFO - 2018-06-26 09:27:40 --> Hooks Class Initialized
DEBUG - 2018-06-26 09:27:40 --> UTF-8 Support Enabled
INFO - 2018-06-26 09:27:40 --> Utf8 Class Initialized
INFO - 2018-06-26 09:27:40 --> URI Class Initialized
INFO - 2018-06-26 09:27:40 --> Router Class Initialized
INFO - 2018-06-26 09:27:40 --> Output Class Initialized
INFO - 2018-06-26 09:27:40 --> Security Class Initialized
DEBUG - 2018-06-26 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 09:27:40 --> CSRF cookie sent
INFO - 2018-06-26 09:27:40 --> Input Class Initialized
INFO - 2018-06-26 09:27:40 --> Language Class Initialized
INFO - 2018-06-26 09:27:40 --> Loader Class Initialized
INFO - 2018-06-26 09:27:40 --> Helper loaded: url_helper
INFO - 2018-06-26 09:27:40 --> Helper loaded: form_helper
INFO - 2018-06-26 09:27:40 --> Helper loaded: language_helper
DEBUG - 2018-06-26 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 09:27:40 --> User Agent Class Initialized
INFO - 2018-06-26 09:27:40 --> Controller Class Initialized
INFO - 2018-06-26 09:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 09:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-26 09:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 09:27:40 --> Final output sent to browser
DEBUG - 2018-06-26 09:27:40 --> Total execution time: 0.0221
INFO - 2018-06-26 10:16:30 --> Config Class Initialized
INFO - 2018-06-26 10:16:30 --> Hooks Class Initialized
DEBUG - 2018-06-26 10:16:30 --> UTF-8 Support Enabled
INFO - 2018-06-26 10:16:30 --> Utf8 Class Initialized
INFO - 2018-06-26 10:16:30 --> URI Class Initialized
INFO - 2018-06-26 10:16:30 --> Router Class Initialized
INFO - 2018-06-26 10:16:30 --> Output Class Initialized
INFO - 2018-06-26 10:16:30 --> Security Class Initialized
DEBUG - 2018-06-26 10:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 10:16:30 --> CSRF cookie sent
INFO - 2018-06-26 10:16:30 --> Input Class Initialized
INFO - 2018-06-26 10:16:30 --> Language Class Initialized
INFO - 2018-06-26 10:16:30 --> Loader Class Initialized
INFO - 2018-06-26 10:16:30 --> Helper loaded: url_helper
INFO - 2018-06-26 10:16:30 --> Helper loaded: form_helper
INFO - 2018-06-26 10:16:30 --> Helper loaded: language_helper
DEBUG - 2018-06-26 10:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 10:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 10:16:30 --> User Agent Class Initialized
INFO - 2018-06-26 10:16:30 --> Controller Class Initialized
INFO - 2018-06-26 10:16:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 10:16:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-26 10:16:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 10:16:30 --> Could not find the language line "req_email"
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-26 10:16:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 10:16:30 --> Final output sent to browser
DEBUG - 2018-06-26 10:16:30 --> Total execution time: 0.0336
INFO - 2018-06-26 10:33:29 --> Config Class Initialized
INFO - 2018-06-26 10:33:29 --> Hooks Class Initialized
DEBUG - 2018-06-26 10:33:29 --> UTF-8 Support Enabled
INFO - 2018-06-26 10:33:29 --> Utf8 Class Initialized
INFO - 2018-06-26 10:33:29 --> URI Class Initialized
INFO - 2018-06-26 10:33:29 --> Router Class Initialized
INFO - 2018-06-26 10:33:29 --> Output Class Initialized
INFO - 2018-06-26 10:33:29 --> Security Class Initialized
DEBUG - 2018-06-26 10:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 10:33:29 --> CSRF cookie sent
INFO - 2018-06-26 10:33:29 --> Input Class Initialized
INFO - 2018-06-26 10:33:29 --> Language Class Initialized
INFO - 2018-06-26 10:33:29 --> Loader Class Initialized
INFO - 2018-06-26 10:33:29 --> Helper loaded: url_helper
INFO - 2018-06-26 10:33:29 --> Helper loaded: form_helper
INFO - 2018-06-26 10:33:29 --> Helper loaded: language_helper
DEBUG - 2018-06-26 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 10:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 10:33:29 --> User Agent Class Initialized
INFO - 2018-06-26 10:33:29 --> Controller Class Initialized
INFO - 2018-06-26 10:33:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 10:33:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-26 10:33:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 10:33:29 --> Could not find the language line "req_email"
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-26 10:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 10:33:29 --> Final output sent to browser
DEBUG - 2018-06-26 10:33:29 --> Total execution time: 0.0241
INFO - 2018-06-26 11:37:41 --> Config Class Initialized
INFO - 2018-06-26 11:37:41 --> Hooks Class Initialized
DEBUG - 2018-06-26 11:37:41 --> UTF-8 Support Enabled
INFO - 2018-06-26 11:37:41 --> Utf8 Class Initialized
INFO - 2018-06-26 11:37:41 --> URI Class Initialized
DEBUG - 2018-06-26 11:37:41 --> No URI present. Default controller set.
INFO - 2018-06-26 11:37:41 --> Router Class Initialized
INFO - 2018-06-26 11:37:41 --> Output Class Initialized
INFO - 2018-06-26 11:37:41 --> Security Class Initialized
DEBUG - 2018-06-26 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 11:37:41 --> CSRF cookie sent
INFO - 2018-06-26 11:37:41 --> Input Class Initialized
INFO - 2018-06-26 11:37:41 --> Language Class Initialized
INFO - 2018-06-26 11:37:41 --> Loader Class Initialized
INFO - 2018-06-26 11:37:41 --> Helper loaded: url_helper
INFO - 2018-06-26 11:37:41 --> Helper loaded: form_helper
INFO - 2018-06-26 11:37:41 --> Helper loaded: language_helper
DEBUG - 2018-06-26 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 11:37:41 --> User Agent Class Initialized
INFO - 2018-06-26 11:37:41 --> Controller Class Initialized
INFO - 2018-06-26 11:37:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 11:37:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 11:37:41 --> Pixel_Model class loaded
INFO - 2018-06-26 11:37:41 --> Database Driver Class Initialized
INFO - 2018-06-26 11:37:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 11:37:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 11:37:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 11:37:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 11:37:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 11:37:41 --> Final output sent to browser
DEBUG - 2018-06-26 11:37:41 --> Total execution time: 0.0329
INFO - 2018-06-26 13:19:57 --> Config Class Initialized
INFO - 2018-06-26 13:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-26 13:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-26 13:19:57 --> Utf8 Class Initialized
INFO - 2018-06-26 13:19:57 --> URI Class Initialized
INFO - 2018-06-26 13:19:57 --> Router Class Initialized
INFO - 2018-06-26 13:19:57 --> Output Class Initialized
INFO - 2018-06-26 13:19:57 --> Security Class Initialized
DEBUG - 2018-06-26 13:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 13:19:57 --> CSRF cookie sent
INFO - 2018-06-26 13:19:57 --> Input Class Initialized
INFO - 2018-06-26 13:19:57 --> Language Class Initialized
ERROR - 2018-06-26 13:19:57 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 13:20:00 --> Config Class Initialized
INFO - 2018-06-26 13:20:00 --> Hooks Class Initialized
DEBUG - 2018-06-26 13:20:00 --> UTF-8 Support Enabled
INFO - 2018-06-26 13:20:00 --> Utf8 Class Initialized
INFO - 2018-06-26 13:20:00 --> URI Class Initialized
INFO - 2018-06-26 13:20:00 --> Router Class Initialized
INFO - 2018-06-26 13:20:00 --> Output Class Initialized
INFO - 2018-06-26 13:20:00 --> Security Class Initialized
DEBUG - 2018-06-26 13:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 13:20:00 --> CSRF cookie sent
INFO - 2018-06-26 13:20:00 --> Input Class Initialized
INFO - 2018-06-26 13:20:00 --> Language Class Initialized
INFO - 2018-06-26 13:20:00 --> Loader Class Initialized
INFO - 2018-06-26 13:20:00 --> Helper loaded: url_helper
INFO - 2018-06-26 13:20:00 --> Helper loaded: form_helper
INFO - 2018-06-26 13:20:00 --> Helper loaded: language_helper
DEBUG - 2018-06-26 13:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 13:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 13:20:00 --> User Agent Class Initialized
INFO - 2018-06-26 13:20:00 --> Controller Class Initialized
INFO - 2018-06-26 13:20:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 13:20:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-26 13:20:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 13:20:00 --> Final output sent to browser
DEBUG - 2018-06-26 13:20:00 --> Total execution time: 0.0225
INFO - 2018-06-26 13:51:34 --> Config Class Initialized
INFO - 2018-06-26 13:51:34 --> Hooks Class Initialized
DEBUG - 2018-06-26 13:51:34 --> UTF-8 Support Enabled
INFO - 2018-06-26 13:51:34 --> Utf8 Class Initialized
INFO - 2018-06-26 13:51:34 --> URI Class Initialized
DEBUG - 2018-06-26 13:51:34 --> No URI present. Default controller set.
INFO - 2018-06-26 13:51:34 --> Router Class Initialized
INFO - 2018-06-26 13:51:34 --> Output Class Initialized
INFO - 2018-06-26 13:51:34 --> Security Class Initialized
DEBUG - 2018-06-26 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 13:51:34 --> CSRF cookie sent
INFO - 2018-06-26 13:51:34 --> Input Class Initialized
INFO - 2018-06-26 13:51:34 --> Language Class Initialized
INFO - 2018-06-26 13:51:34 --> Loader Class Initialized
INFO - 2018-06-26 13:51:34 --> Helper loaded: url_helper
INFO - 2018-06-26 13:51:34 --> Helper loaded: form_helper
INFO - 2018-06-26 13:51:34 --> Helper loaded: language_helper
DEBUG - 2018-06-26 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 13:51:34 --> User Agent Class Initialized
INFO - 2018-06-26 13:51:34 --> Controller Class Initialized
INFO - 2018-06-26 13:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 13:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 13:51:34 --> Pixel_Model class loaded
INFO - 2018-06-26 13:51:34 --> Database Driver Class Initialized
INFO - 2018-06-26 13:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 13:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 13:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 13:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 13:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 13:51:34 --> Final output sent to browser
DEBUG - 2018-06-26 13:51:34 --> Total execution time: 0.0307
INFO - 2018-06-26 13:51:37 --> Config Class Initialized
INFO - 2018-06-26 13:51:37 --> Hooks Class Initialized
DEBUG - 2018-06-26 13:51:37 --> UTF-8 Support Enabled
INFO - 2018-06-26 13:51:37 --> Utf8 Class Initialized
INFO - 2018-06-26 13:51:37 --> URI Class Initialized
INFO - 2018-06-26 13:51:37 --> Router Class Initialized
INFO - 2018-06-26 13:51:37 --> Output Class Initialized
INFO - 2018-06-26 13:51:37 --> Security Class Initialized
DEBUG - 2018-06-26 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 13:51:37 --> CSRF cookie sent
INFO - 2018-06-26 13:51:37 --> Input Class Initialized
INFO - 2018-06-26 13:51:37 --> Language Class Initialized
INFO - 2018-06-26 13:51:37 --> Loader Class Initialized
INFO - 2018-06-26 13:51:37 --> Helper loaded: url_helper
INFO - 2018-06-26 13:51:37 --> Helper loaded: form_helper
INFO - 2018-06-26 13:51:37 --> Helper loaded: language_helper
DEBUG - 2018-06-26 13:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 13:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 13:51:37 --> User Agent Class Initialized
INFO - 2018-06-26 13:51:37 --> Controller Class Initialized
INFO - 2018-06-26 13:51:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 13:51:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-26 13:51:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 13:51:37 --> Could not find the language line "req_email"
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-26 13:51:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 13:51:37 --> Final output sent to browser
DEBUG - 2018-06-26 13:51:37 --> Total execution time: 0.0222
INFO - 2018-06-26 13:51:39 --> Config Class Initialized
INFO - 2018-06-26 13:51:39 --> Hooks Class Initialized
DEBUG - 2018-06-26 13:51:39 --> UTF-8 Support Enabled
INFO - 2018-06-26 13:51:39 --> Utf8 Class Initialized
INFO - 2018-06-26 13:51:39 --> URI Class Initialized
INFO - 2018-06-26 13:51:39 --> Router Class Initialized
INFO - 2018-06-26 13:51:39 --> Output Class Initialized
INFO - 2018-06-26 13:51:39 --> Security Class Initialized
DEBUG - 2018-06-26 13:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 13:51:39 --> CSRF cookie sent
INFO - 2018-06-26 13:51:39 --> Input Class Initialized
INFO - 2018-06-26 13:51:39 --> Language Class Initialized
INFO - 2018-06-26 13:51:39 --> Loader Class Initialized
INFO - 2018-06-26 13:51:39 --> Helper loaded: url_helper
INFO - 2018-06-26 13:51:39 --> Helper loaded: form_helper
INFO - 2018-06-26 13:51:39 --> Helper loaded: language_helper
DEBUG - 2018-06-26 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 13:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 13:51:39 --> User Agent Class Initialized
INFO - 2018-06-26 13:51:39 --> Controller Class Initialized
INFO - 2018-06-26 13:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 13:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 13:51:39 --> Pixel_Model class loaded
INFO - 2018-06-26 13:51:39 --> Database Driver Class Initialized
INFO - 2018-06-26 13:51:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-26 13:51:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 13:51:39 --> Could not find the language line "req_email"
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-26 13:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 13:51:39 --> Final output sent to browser
DEBUG - 2018-06-26 13:51:39 --> Total execution time: 0.0317
INFO - 2018-06-26 16:18:34 --> Config Class Initialized
INFO - 2018-06-26 16:18:34 --> Hooks Class Initialized
DEBUG - 2018-06-26 16:18:34 --> UTF-8 Support Enabled
INFO - 2018-06-26 16:18:34 --> Utf8 Class Initialized
INFO - 2018-06-26 16:18:34 --> URI Class Initialized
INFO - 2018-06-26 16:18:34 --> Router Class Initialized
INFO - 2018-06-26 16:18:34 --> Output Class Initialized
INFO - 2018-06-26 16:18:34 --> Security Class Initialized
DEBUG - 2018-06-26 16:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 16:18:34 --> CSRF cookie sent
INFO - 2018-06-26 16:18:34 --> Input Class Initialized
INFO - 2018-06-26 16:18:34 --> Language Class Initialized
ERROR - 2018-06-26 16:18:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 17:16:05 --> Config Class Initialized
INFO - 2018-06-26 17:16:05 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:16:05 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:16:05 --> Utf8 Class Initialized
INFO - 2018-06-26 17:16:05 --> URI Class Initialized
DEBUG - 2018-06-26 17:16:05 --> No URI present. Default controller set.
INFO - 2018-06-26 17:16:05 --> Router Class Initialized
INFO - 2018-06-26 17:16:05 --> Output Class Initialized
INFO - 2018-06-26 17:16:05 --> Security Class Initialized
DEBUG - 2018-06-26 17:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:16:05 --> CSRF cookie sent
INFO - 2018-06-26 17:16:05 --> Input Class Initialized
INFO - 2018-06-26 17:16:05 --> Language Class Initialized
INFO - 2018-06-26 17:16:05 --> Loader Class Initialized
INFO - 2018-06-26 17:16:05 --> Helper loaded: url_helper
INFO - 2018-06-26 17:16:05 --> Helper loaded: form_helper
INFO - 2018-06-26 17:16:05 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:16:05 --> User Agent Class Initialized
INFO - 2018-06-26 17:16:05 --> Controller Class Initialized
INFO - 2018-06-26 17:16:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:16:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:16:05 --> Pixel_Model class loaded
INFO - 2018-06-26 17:16:05 --> Database Driver Class Initialized
INFO - 2018-06-26 17:16:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:16:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:16:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:16:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 17:16:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:16:05 --> Final output sent to browser
DEBUG - 2018-06-26 17:16:05 --> Total execution time: 0.0367
INFO - 2018-06-26 17:18:08 --> Config Class Initialized
INFO - 2018-06-26 17:18:08 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:18:08 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:18:08 --> Utf8 Class Initialized
INFO - 2018-06-26 17:18:08 --> URI Class Initialized
INFO - 2018-06-26 17:18:08 --> Router Class Initialized
INFO - 2018-06-26 17:18:08 --> Output Class Initialized
INFO - 2018-06-26 17:18:08 --> Security Class Initialized
DEBUG - 2018-06-26 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:18:08 --> CSRF cookie sent
INFO - 2018-06-26 17:18:08 --> Input Class Initialized
INFO - 2018-06-26 17:18:08 --> Language Class Initialized
ERROR - 2018-06-26 17:18:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 17:36:07 --> Config Class Initialized
INFO - 2018-06-26 17:36:07 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:07 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:07 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:07 --> URI Class Initialized
DEBUG - 2018-06-26 17:36:07 --> No URI present. Default controller set.
INFO - 2018-06-26 17:36:07 --> Router Class Initialized
INFO - 2018-06-26 17:36:07 --> Output Class Initialized
INFO - 2018-06-26 17:36:07 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:07 --> CSRF cookie sent
INFO - 2018-06-26 17:36:07 --> Input Class Initialized
INFO - 2018-06-26 17:36:07 --> Language Class Initialized
INFO - 2018-06-26 17:36:07 --> Loader Class Initialized
INFO - 2018-06-26 17:36:07 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:07 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:07 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:07 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:07 --> Controller Class Initialized
INFO - 2018-06-26 17:36:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:07 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:07 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 17:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:07 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:07 --> Total execution time: 0.0336
INFO - 2018-06-26 17:36:08 --> Config Class Initialized
INFO - 2018-06-26 17:36:08 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:08 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:08 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:08 --> URI Class Initialized
DEBUG - 2018-06-26 17:36:08 --> No URI present. Default controller set.
INFO - 2018-06-26 17:36:08 --> Router Class Initialized
INFO - 2018-06-26 17:36:08 --> Output Class Initialized
INFO - 2018-06-26 17:36:08 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:08 --> CSRF cookie sent
INFO - 2018-06-26 17:36:08 --> Input Class Initialized
INFO - 2018-06-26 17:36:08 --> Language Class Initialized
INFO - 2018-06-26 17:36:08 --> Loader Class Initialized
INFO - 2018-06-26 17:36:08 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:08 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:08 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:08 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:08 --> Controller Class Initialized
INFO - 2018-06-26 17:36:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:08 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:08 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 17:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:08 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:08 --> Total execution time: 0.0359
INFO - 2018-06-26 17:36:09 --> Config Class Initialized
INFO - 2018-06-26 17:36:09 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:09 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:09 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:09 --> URI Class Initialized
DEBUG - 2018-06-26 17:36:09 --> No URI present. Default controller set.
INFO - 2018-06-26 17:36:09 --> Router Class Initialized
INFO - 2018-06-26 17:36:09 --> Output Class Initialized
INFO - 2018-06-26 17:36:09 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:09 --> CSRF cookie sent
INFO - 2018-06-26 17:36:09 --> Input Class Initialized
INFO - 2018-06-26 17:36:09 --> Language Class Initialized
INFO - 2018-06-26 17:36:09 --> Loader Class Initialized
INFO - 2018-06-26 17:36:09 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:09 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:09 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:09 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:09 --> Controller Class Initialized
INFO - 2018-06-26 17:36:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:09 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:09 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:36:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 17:36:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:09 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:09 --> Total execution time: 0.0361
INFO - 2018-06-26 17:36:09 --> Config Class Initialized
INFO - 2018-06-26 17:36:09 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:09 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:09 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:09 --> URI Class Initialized
INFO - 2018-06-26 17:36:09 --> Router Class Initialized
INFO - 2018-06-26 17:36:09 --> Output Class Initialized
INFO - 2018-06-26 17:36:09 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:09 --> CSRF cookie sent
INFO - 2018-06-26 17:36:09 --> Input Class Initialized
INFO - 2018-06-26 17:36:09 --> Language Class Initialized
ERROR - 2018-06-26 17:36:09 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-26 17:36:16 --> Config Class Initialized
INFO - 2018-06-26 17:36:16 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:16 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:16 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:16 --> URI Class Initialized
DEBUG - 2018-06-26 17:36:16 --> No URI present. Default controller set.
INFO - 2018-06-26 17:36:16 --> Router Class Initialized
INFO - 2018-06-26 17:36:16 --> Output Class Initialized
INFO - 2018-06-26 17:36:16 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:16 --> CSRF cookie sent
INFO - 2018-06-26 17:36:16 --> Input Class Initialized
INFO - 2018-06-26 17:36:16 --> Language Class Initialized
INFO - 2018-06-26 17:36:16 --> Loader Class Initialized
INFO - 2018-06-26 17:36:16 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:16 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:16 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:16 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:16 --> Controller Class Initialized
INFO - 2018-06-26 17:36:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:16 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:16 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-26 17:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:16 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:16 --> Total execution time: 0.0355
INFO - 2018-06-26 17:36:17 --> Config Class Initialized
INFO - 2018-06-26 17:36:17 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:17 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:17 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:17 --> URI Class Initialized
INFO - 2018-06-26 17:36:17 --> Router Class Initialized
INFO - 2018-06-26 17:36:17 --> Output Class Initialized
INFO - 2018-06-26 17:36:17 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:17 --> CSRF cookie sent
INFO - 2018-06-26 17:36:17 --> Input Class Initialized
INFO - 2018-06-26 17:36:17 --> Language Class Initialized
ERROR - 2018-06-26 17:36:17 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-26 17:36:17 --> Config Class Initialized
INFO - 2018-06-26 17:36:17 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:17 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:17 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:17 --> URI Class Initialized
INFO - 2018-06-26 17:36:17 --> Router Class Initialized
INFO - 2018-06-26 17:36:17 --> Output Class Initialized
INFO - 2018-06-26 17:36:17 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:17 --> CSRF cookie sent
INFO - 2018-06-26 17:36:17 --> Input Class Initialized
INFO - 2018-06-26 17:36:17 --> Language Class Initialized
ERROR - 2018-06-26 17:36:17 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-26 17:36:18 --> Config Class Initialized
INFO - 2018-06-26 17:36:18 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:18 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:18 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:18 --> URI Class Initialized
INFO - 2018-06-26 17:36:18 --> Router Class Initialized
INFO - 2018-06-26 17:36:18 --> Output Class Initialized
INFO - 2018-06-26 17:36:18 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:18 --> CSRF cookie sent
INFO - 2018-06-26 17:36:18 --> Input Class Initialized
INFO - 2018-06-26 17:36:18 --> Language Class Initialized
INFO - 2018-06-26 17:36:18 --> Loader Class Initialized
INFO - 2018-06-26 17:36:18 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:18 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:18 --> Controller Class Initialized
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:18 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:18 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:18 --> Model "QuestionsModel" initialized
ERROR - 2018-06-26 17:36:18 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-26 17:36:18 --> Config Class Initialized
INFO - 2018-06-26 17:36:18 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:18 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:18 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:18 --> URI Class Initialized
INFO - 2018-06-26 17:36:18 --> Router Class Initialized
INFO - 2018-06-26 17:36:18 --> Output Class Initialized
INFO - 2018-06-26 17:36:18 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:18 --> CSRF cookie sent
INFO - 2018-06-26 17:36:18 --> Input Class Initialized
INFO - 2018-06-26 17:36:18 --> Language Class Initialized
INFO - 2018-06-26 17:36:18 --> Loader Class Initialized
INFO - 2018-06-26 17:36:18 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:18 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:18 --> Controller Class Initialized
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-26 17:36:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 17:36:18 --> Could not find the language line "req_email"
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:18 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:18 --> Total execution time: 0.0233
INFO - 2018-06-26 17:36:18 --> Config Class Initialized
INFO - 2018-06-26 17:36:18 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:18 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:18 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:18 --> URI Class Initialized
INFO - 2018-06-26 17:36:18 --> Router Class Initialized
INFO - 2018-06-26 17:36:18 --> Output Class Initialized
INFO - 2018-06-26 17:36:18 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:18 --> CSRF cookie sent
INFO - 2018-06-26 17:36:18 --> Input Class Initialized
INFO - 2018-06-26 17:36:18 --> Language Class Initialized
INFO - 2018-06-26 17:36:18 --> Loader Class Initialized
INFO - 2018-06-26 17:36:18 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:18 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:18 --> Controller Class Initialized
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:18 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:18 --> Total execution time: 0.0212
INFO - 2018-06-26 17:36:18 --> Config Class Initialized
INFO - 2018-06-26 17:36:18 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:18 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:18 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:18 --> URI Class Initialized
INFO - 2018-06-26 17:36:18 --> Router Class Initialized
INFO - 2018-06-26 17:36:18 --> Output Class Initialized
INFO - 2018-06-26 17:36:18 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:18 --> CSRF cookie sent
INFO - 2018-06-26 17:36:18 --> Input Class Initialized
INFO - 2018-06-26 17:36:18 --> Language Class Initialized
INFO - 2018-06-26 17:36:18 --> Loader Class Initialized
INFO - 2018-06-26 17:36:18 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:18 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:18 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:18 --> Controller Class Initialized
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-26 17:36:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:18 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:18 --> Total execution time: 0.0235
INFO - 2018-06-26 17:36:19 --> Config Class Initialized
INFO - 2018-06-26 17:36:19 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:19 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:19 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:19 --> URI Class Initialized
INFO - 2018-06-26 17:36:19 --> Router Class Initialized
INFO - 2018-06-26 17:36:19 --> Output Class Initialized
INFO - 2018-06-26 17:36:19 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:19 --> CSRF cookie sent
INFO - 2018-06-26 17:36:19 --> Input Class Initialized
INFO - 2018-06-26 17:36:19 --> Language Class Initialized
INFO - 2018-06-26 17:36:19 --> Loader Class Initialized
INFO - 2018-06-26 17:36:19 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:19 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:19 --> Controller Class Initialized
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:19 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:19 --> Total execution time: 0.0229
INFO - 2018-06-26 17:36:19 --> Config Class Initialized
INFO - 2018-06-26 17:36:19 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:19 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:19 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:19 --> URI Class Initialized
INFO - 2018-06-26 17:36:19 --> Router Class Initialized
INFO - 2018-06-26 17:36:19 --> Output Class Initialized
INFO - 2018-06-26 17:36:19 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:19 --> CSRF cookie sent
INFO - 2018-06-26 17:36:19 --> Input Class Initialized
INFO - 2018-06-26 17:36:19 --> Language Class Initialized
INFO - 2018-06-26 17:36:19 --> Loader Class Initialized
INFO - 2018-06-26 17:36:19 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:19 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:19 --> Controller Class Initialized
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:19 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:19 --> Total execution time: 0.0203
INFO - 2018-06-26 17:36:19 --> Config Class Initialized
INFO - 2018-06-26 17:36:19 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:19 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:19 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:19 --> URI Class Initialized
INFO - 2018-06-26 17:36:19 --> Router Class Initialized
INFO - 2018-06-26 17:36:19 --> Output Class Initialized
INFO - 2018-06-26 17:36:19 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:19 --> CSRF cookie sent
INFO - 2018-06-26 17:36:19 --> Input Class Initialized
INFO - 2018-06-26 17:36:19 --> Language Class Initialized
INFO - 2018-06-26 17:36:19 --> Loader Class Initialized
INFO - 2018-06-26 17:36:19 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:19 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:19 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:19 --> Controller Class Initialized
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-26 17:36:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-26 17:36:19 --> Could not find the language line "req_email"
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-26 17:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:19 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:19 --> Total execution time: 0.0210
INFO - 2018-06-26 17:36:20 --> Config Class Initialized
INFO - 2018-06-26 17:36:20 --> Hooks Class Initialized
DEBUG - 2018-06-26 17:36:20 --> UTF-8 Support Enabled
INFO - 2018-06-26 17:36:20 --> Utf8 Class Initialized
INFO - 2018-06-26 17:36:20 --> URI Class Initialized
INFO - 2018-06-26 17:36:20 --> Router Class Initialized
INFO - 2018-06-26 17:36:20 --> Output Class Initialized
INFO - 2018-06-26 17:36:20 --> Security Class Initialized
DEBUG - 2018-06-26 17:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 17:36:20 --> CSRF cookie sent
INFO - 2018-06-26 17:36:20 --> Input Class Initialized
INFO - 2018-06-26 17:36:20 --> Language Class Initialized
INFO - 2018-06-26 17:36:20 --> Loader Class Initialized
INFO - 2018-06-26 17:36:20 --> Helper loaded: url_helper
INFO - 2018-06-26 17:36:20 --> Helper loaded: form_helper
INFO - 2018-06-26 17:36:20 --> Helper loaded: language_helper
DEBUG - 2018-06-26 17:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 17:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 17:36:20 --> User Agent Class Initialized
INFO - 2018-06-26 17:36:20 --> Controller Class Initialized
INFO - 2018-06-26 17:36:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 17:36:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 17:36:20 --> Pixel_Model class loaded
INFO - 2018-06-26 17:36:20 --> Database Driver Class Initialized
INFO - 2018-06-26 17:36:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-26 17:36:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 17:36:20 --> Final output sent to browser
DEBUG - 2018-06-26 17:36:20 --> Total execution time: 0.0352
INFO - 2018-06-26 22:31:18 --> Config Class Initialized
INFO - 2018-06-26 22:31:18 --> Hooks Class Initialized
DEBUG - 2018-06-26 22:31:18 --> UTF-8 Support Enabled
INFO - 2018-06-26 22:31:18 --> Utf8 Class Initialized
INFO - 2018-06-26 22:31:18 --> URI Class Initialized
INFO - 2018-06-26 22:31:18 --> Router Class Initialized
INFO - 2018-06-26 22:31:18 --> Output Class Initialized
INFO - 2018-06-26 22:31:18 --> Security Class Initialized
DEBUG - 2018-06-26 22:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 22:31:18 --> CSRF cookie sent
INFO - 2018-06-26 22:31:18 --> Input Class Initialized
INFO - 2018-06-26 22:31:18 --> Language Class Initialized
ERROR - 2018-06-26 22:31:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-26 22:31:21 --> Config Class Initialized
INFO - 2018-06-26 22:31:21 --> Hooks Class Initialized
DEBUG - 2018-06-26 22:31:21 --> UTF-8 Support Enabled
INFO - 2018-06-26 22:31:21 --> Utf8 Class Initialized
INFO - 2018-06-26 22:31:21 --> URI Class Initialized
INFO - 2018-06-26 22:31:21 --> Router Class Initialized
INFO - 2018-06-26 22:31:21 --> Output Class Initialized
INFO - 2018-06-26 22:31:21 --> Security Class Initialized
DEBUG - 2018-06-26 22:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 22:31:21 --> CSRF cookie sent
INFO - 2018-06-26 22:31:21 --> Input Class Initialized
INFO - 2018-06-26 22:31:21 --> Language Class Initialized
INFO - 2018-06-26 22:31:21 --> Loader Class Initialized
INFO - 2018-06-26 22:31:21 --> Helper loaded: url_helper
INFO - 2018-06-26 22:31:21 --> Helper loaded: form_helper
INFO - 2018-06-26 22:31:21 --> Helper loaded: language_helper
DEBUG - 2018-06-26 22:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 22:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 22:31:21 --> User Agent Class Initialized
INFO - 2018-06-26 22:31:21 --> Controller Class Initialized
INFO - 2018-06-26 22:31:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 22:31:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-26 22:31:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 22:31:21 --> Final output sent to browser
DEBUG - 2018-06-26 22:31:21 --> Total execution time: 0.0227
INFO - 2018-06-26 22:58:53 --> Config Class Initialized
INFO - 2018-06-26 22:58:53 --> Hooks Class Initialized
DEBUG - 2018-06-26 22:58:53 --> UTF-8 Support Enabled
INFO - 2018-06-26 22:58:53 --> Utf8 Class Initialized
INFO - 2018-06-26 22:58:53 --> URI Class Initialized
INFO - 2018-06-26 22:58:53 --> Router Class Initialized
INFO - 2018-06-26 22:58:53 --> Output Class Initialized
INFO - 2018-06-26 22:58:53 --> Security Class Initialized
DEBUG - 2018-06-26 22:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 22:58:53 --> CSRF cookie sent
INFO - 2018-06-26 22:58:53 --> Input Class Initialized
INFO - 2018-06-26 22:58:53 --> Language Class Initialized
INFO - 2018-06-26 22:58:53 --> Loader Class Initialized
INFO - 2018-06-26 22:58:53 --> Helper loaded: url_helper
INFO - 2018-06-26 22:58:53 --> Helper loaded: form_helper
INFO - 2018-06-26 22:58:53 --> Helper loaded: language_helper
DEBUG - 2018-06-26 22:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 22:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 22:58:53 --> User Agent Class Initialized
INFO - 2018-06-26 22:58:53 --> Controller Class Initialized
INFO - 2018-06-26 22:58:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-26 22:58:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-26 22:58:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-26 22:58:53 --> Final output sent to browser
DEBUG - 2018-06-26 22:58:53 --> Total execution time: 0.0231

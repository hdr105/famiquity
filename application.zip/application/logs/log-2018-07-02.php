<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-02 00:16:40 --> Config Class Initialized
INFO - 2018-07-02 00:16:40 --> Hooks Class Initialized
DEBUG - 2018-07-02 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-07-02 00:16:40 --> Utf8 Class Initialized
INFO - 2018-07-02 00:16:40 --> URI Class Initialized
INFO - 2018-07-02 00:16:40 --> Router Class Initialized
INFO - 2018-07-02 00:16:40 --> Output Class Initialized
INFO - 2018-07-02 00:16:40 --> Security Class Initialized
DEBUG - 2018-07-02 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 00:16:40 --> CSRF cookie sent
INFO - 2018-07-02 00:16:40 --> Input Class Initialized
INFO - 2018-07-02 00:16:40 --> Language Class Initialized
INFO - 2018-07-02 00:16:40 --> Loader Class Initialized
INFO - 2018-07-02 00:16:40 --> Helper loaded: url_helper
INFO - 2018-07-02 00:16:41 --> Helper loaded: form_helper
INFO - 2018-07-02 00:16:41 --> Helper loaded: language_helper
DEBUG - 2018-07-02 00:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 00:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 00:16:41 --> User Agent Class Initialized
INFO - 2018-07-02 00:16:41 --> Controller Class Initialized
INFO - 2018-07-02 00:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 00:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-02 00:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 00:16:41 --> Final output sent to browser
DEBUG - 2018-07-02 00:16:41 --> Total execution time: 0.0249
INFO - 2018-07-02 03:16:40 --> Config Class Initialized
INFO - 2018-07-02 03:16:40 --> Hooks Class Initialized
DEBUG - 2018-07-02 03:16:40 --> UTF-8 Support Enabled
INFO - 2018-07-02 03:16:40 --> Utf8 Class Initialized
INFO - 2018-07-02 03:16:40 --> URI Class Initialized
DEBUG - 2018-07-02 03:16:40 --> No URI present. Default controller set.
INFO - 2018-07-02 03:16:40 --> Router Class Initialized
INFO - 2018-07-02 03:16:40 --> Output Class Initialized
INFO - 2018-07-02 03:16:40 --> Security Class Initialized
DEBUG - 2018-07-02 03:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 03:16:40 --> CSRF cookie sent
INFO - 2018-07-02 03:16:40 --> Input Class Initialized
INFO - 2018-07-02 03:16:40 --> Language Class Initialized
INFO - 2018-07-02 03:16:40 --> Loader Class Initialized
INFO - 2018-07-02 03:16:40 --> Helper loaded: url_helper
INFO - 2018-07-02 03:16:40 --> Helper loaded: form_helper
INFO - 2018-07-02 03:16:40 --> Helper loaded: language_helper
DEBUG - 2018-07-02 03:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 03:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 03:16:40 --> User Agent Class Initialized
INFO - 2018-07-02 03:16:40 --> Controller Class Initialized
INFO - 2018-07-02 03:16:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 03:16:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 03:16:40 --> Pixel_Model class loaded
INFO - 2018-07-02 03:16:40 --> Database Driver Class Initialized
INFO - 2018-07-02 03:16:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 03:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 03:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 03:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 03:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 03:16:40 --> Final output sent to browser
DEBUG - 2018-07-02 03:16:40 --> Total execution time: 0.0440
INFO - 2018-07-02 09:21:40 --> Config Class Initialized
INFO - 2018-07-02 09:21:40 --> Hooks Class Initialized
DEBUG - 2018-07-02 09:21:40 --> UTF-8 Support Enabled
INFO - 2018-07-02 09:21:40 --> Utf8 Class Initialized
INFO - 2018-07-02 09:21:40 --> URI Class Initialized
INFO - 2018-07-02 09:21:40 --> Router Class Initialized
INFO - 2018-07-02 09:21:40 --> Output Class Initialized
INFO - 2018-07-02 09:21:40 --> Security Class Initialized
DEBUG - 2018-07-02 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 09:21:40 --> CSRF cookie sent
INFO - 2018-07-02 09:21:40 --> Input Class Initialized
INFO - 2018-07-02 09:21:40 --> Language Class Initialized
ERROR - 2018-07-02 09:21:40 --> 404 Page Not Found: Admin/index
INFO - 2018-07-02 09:49:08 --> Config Class Initialized
INFO - 2018-07-02 09:49:08 --> Hooks Class Initialized
DEBUG - 2018-07-02 09:49:08 --> UTF-8 Support Enabled
INFO - 2018-07-02 09:49:08 --> Utf8 Class Initialized
INFO - 2018-07-02 09:49:08 --> URI Class Initialized
DEBUG - 2018-07-02 09:49:08 --> No URI present. Default controller set.
INFO - 2018-07-02 09:49:08 --> Router Class Initialized
INFO - 2018-07-02 09:49:08 --> Output Class Initialized
INFO - 2018-07-02 09:49:08 --> Security Class Initialized
DEBUG - 2018-07-02 09:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 09:49:08 --> CSRF cookie sent
INFO - 2018-07-02 09:49:08 --> Input Class Initialized
INFO - 2018-07-02 09:49:08 --> Language Class Initialized
INFO - 2018-07-02 09:49:08 --> Loader Class Initialized
INFO - 2018-07-02 09:49:08 --> Helper loaded: url_helper
INFO - 2018-07-02 09:49:08 --> Helper loaded: form_helper
INFO - 2018-07-02 09:49:08 --> Helper loaded: language_helper
DEBUG - 2018-07-02 09:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 09:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 09:49:08 --> User Agent Class Initialized
INFO - 2018-07-02 09:49:08 --> Controller Class Initialized
INFO - 2018-07-02 09:49:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 09:49:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 09:49:08 --> Pixel_Model class loaded
INFO - 2018-07-02 09:49:08 --> Database Driver Class Initialized
INFO - 2018-07-02 09:49:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 09:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 09:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 09:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 09:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 09:49:08 --> Final output sent to browser
DEBUG - 2018-07-02 09:49:08 --> Total execution time: 0.0337
INFO - 2018-07-02 16:59:51 --> Config Class Initialized
INFO - 2018-07-02 16:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-02 16:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-02 16:59:51 --> Utf8 Class Initialized
INFO - 2018-07-02 16:59:51 --> URI Class Initialized
INFO - 2018-07-02 16:59:51 --> Router Class Initialized
INFO - 2018-07-02 16:59:51 --> Output Class Initialized
INFO - 2018-07-02 16:59:51 --> Security Class Initialized
DEBUG - 2018-07-02 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 16:59:51 --> CSRF cookie sent
INFO - 2018-07-02 16:59:51 --> Input Class Initialized
INFO - 2018-07-02 16:59:51 --> Language Class Initialized
ERROR - 2018-07-02 16:59:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-02 17:30:27 --> Config Class Initialized
INFO - 2018-07-02 17:30:27 --> Hooks Class Initialized
DEBUG - 2018-07-02 17:30:27 --> UTF-8 Support Enabled
INFO - 2018-07-02 17:30:27 --> Utf8 Class Initialized
INFO - 2018-07-02 17:30:27 --> URI Class Initialized
INFO - 2018-07-02 17:30:27 --> Router Class Initialized
INFO - 2018-07-02 17:30:27 --> Output Class Initialized
INFO - 2018-07-02 17:30:27 --> Security Class Initialized
DEBUG - 2018-07-02 17:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 17:30:27 --> CSRF cookie sent
INFO - 2018-07-02 17:30:27 --> Input Class Initialized
INFO - 2018-07-02 17:30:27 --> Language Class Initialized
ERROR - 2018-07-02 17:30:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-02 17:41:11 --> Config Class Initialized
INFO - 2018-07-02 17:41:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 17:41:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 17:41:11 --> Utf8 Class Initialized
INFO - 2018-07-02 17:41:11 --> URI Class Initialized
DEBUG - 2018-07-02 17:41:11 --> No URI present. Default controller set.
INFO - 2018-07-02 17:41:11 --> Router Class Initialized
INFO - 2018-07-02 17:41:11 --> Output Class Initialized
INFO - 2018-07-02 17:41:11 --> Security Class Initialized
DEBUG - 2018-07-02 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 17:41:11 --> CSRF cookie sent
INFO - 2018-07-02 17:41:11 --> Input Class Initialized
INFO - 2018-07-02 17:41:11 --> Language Class Initialized
INFO - 2018-07-02 17:41:11 --> Loader Class Initialized
INFO - 2018-07-02 17:41:11 --> Helper loaded: url_helper
INFO - 2018-07-02 17:41:11 --> Helper loaded: form_helper
INFO - 2018-07-02 17:41:11 --> Helper loaded: language_helper
DEBUG - 2018-07-02 17:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 17:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 17:41:11 --> User Agent Class Initialized
INFO - 2018-07-02 17:41:11 --> Controller Class Initialized
INFO - 2018-07-02 17:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 17:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 17:41:11 --> Pixel_Model class loaded
INFO - 2018-07-02 17:41:11 --> Database Driver Class Initialized
INFO - 2018-07-02 17:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 17:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 17:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 17:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 17:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 17:41:11 --> Final output sent to browser
DEBUG - 2018-07-02 17:41:11 --> Total execution time: 0.0323
INFO - 2018-07-02 17:48:01 --> Config Class Initialized
INFO - 2018-07-02 17:48:01 --> Hooks Class Initialized
DEBUG - 2018-07-02 17:48:01 --> UTF-8 Support Enabled
INFO - 2018-07-02 17:48:01 --> Utf8 Class Initialized
INFO - 2018-07-02 17:48:01 --> URI Class Initialized
DEBUG - 2018-07-02 17:48:01 --> No URI present. Default controller set.
INFO - 2018-07-02 17:48:01 --> Router Class Initialized
INFO - 2018-07-02 17:48:01 --> Output Class Initialized
INFO - 2018-07-02 17:48:01 --> Security Class Initialized
DEBUG - 2018-07-02 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 17:48:01 --> CSRF cookie sent
INFO - 2018-07-02 17:48:01 --> Input Class Initialized
INFO - 2018-07-02 17:48:01 --> Language Class Initialized
INFO - 2018-07-02 17:48:01 --> Loader Class Initialized
INFO - 2018-07-02 17:48:01 --> Helper loaded: url_helper
INFO - 2018-07-02 17:48:01 --> Helper loaded: form_helper
INFO - 2018-07-02 17:48:01 --> Helper loaded: language_helper
DEBUG - 2018-07-02 17:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 17:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 17:48:01 --> User Agent Class Initialized
INFO - 2018-07-02 17:48:01 --> Controller Class Initialized
INFO - 2018-07-02 17:48:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 17:48:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 17:48:01 --> Pixel_Model class loaded
INFO - 2018-07-02 17:48:01 --> Database Driver Class Initialized
INFO - 2018-07-02 17:48:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 17:48:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 17:48:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 17:48:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 17:48:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 17:48:01 --> Final output sent to browser
DEBUG - 2018-07-02 17:48:01 --> Total execution time: 0.0373
INFO - 2018-07-02 18:00:39 --> Config Class Initialized
INFO - 2018-07-02 18:00:39 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:39 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:39 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:39 --> URI Class Initialized
DEBUG - 2018-07-02 18:00:39 --> No URI present. Default controller set.
INFO - 2018-07-02 18:00:39 --> Router Class Initialized
INFO - 2018-07-02 18:00:39 --> Output Class Initialized
INFO - 2018-07-02 18:00:39 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:39 --> CSRF cookie sent
INFO - 2018-07-02 18:00:39 --> Input Class Initialized
INFO - 2018-07-02 18:00:39 --> Language Class Initialized
INFO - 2018-07-02 18:00:39 --> Loader Class Initialized
INFO - 2018-07-02 18:00:39 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:39 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:39 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:39 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:39 --> Controller Class Initialized
INFO - 2018-07-02 18:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:39 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:39 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 18:00:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:39 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:39 --> Total execution time: 0.0300
INFO - 2018-07-02 18:00:40 --> Config Class Initialized
INFO - 2018-07-02 18:00:40 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:40 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:40 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:40 --> URI Class Initialized
DEBUG - 2018-07-02 18:00:40 --> No URI present. Default controller set.
INFO - 2018-07-02 18:00:40 --> Router Class Initialized
INFO - 2018-07-02 18:00:40 --> Output Class Initialized
INFO - 2018-07-02 18:00:40 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:40 --> CSRF cookie sent
INFO - 2018-07-02 18:00:40 --> Input Class Initialized
INFO - 2018-07-02 18:00:40 --> Language Class Initialized
INFO - 2018-07-02 18:00:40 --> Loader Class Initialized
INFO - 2018-07-02 18:00:40 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:40 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:40 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:40 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:40 --> Controller Class Initialized
INFO - 2018-07-02 18:00:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:40 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:40 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:40 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:40 --> Total execution time: 0.0332
INFO - 2018-07-02 18:00:40 --> Config Class Initialized
INFO - 2018-07-02 18:00:40 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:40 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:40 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:40 --> URI Class Initialized
DEBUG - 2018-07-02 18:00:40 --> No URI present. Default controller set.
INFO - 2018-07-02 18:00:40 --> Router Class Initialized
INFO - 2018-07-02 18:00:40 --> Output Class Initialized
INFO - 2018-07-02 18:00:40 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:40 --> CSRF cookie sent
INFO - 2018-07-02 18:00:40 --> Input Class Initialized
INFO - 2018-07-02 18:00:40 --> Language Class Initialized
INFO - 2018-07-02 18:00:40 --> Loader Class Initialized
INFO - 2018-07-02 18:00:40 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:40 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:40 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:40 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:40 --> Controller Class Initialized
INFO - 2018-07-02 18:00:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:40 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:40 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 18:00:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:40 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:40 --> Total execution time: 0.0453
INFO - 2018-07-02 18:00:41 --> Config Class Initialized
INFO - 2018-07-02 18:00:41 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:41 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:41 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:41 --> URI Class Initialized
INFO - 2018-07-02 18:00:41 --> Router Class Initialized
INFO - 2018-07-02 18:00:41 --> Output Class Initialized
INFO - 2018-07-02 18:00:41 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:41 --> CSRF cookie sent
INFO - 2018-07-02 18:00:41 --> Input Class Initialized
INFO - 2018-07-02 18:00:41 --> Language Class Initialized
ERROR - 2018-07-02 18:00:41 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-02 18:00:47 --> Config Class Initialized
INFO - 2018-07-02 18:00:47 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:47 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:47 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:47 --> URI Class Initialized
DEBUG - 2018-07-02 18:00:47 --> No URI present. Default controller set.
INFO - 2018-07-02 18:00:47 --> Router Class Initialized
INFO - 2018-07-02 18:00:47 --> Output Class Initialized
INFO - 2018-07-02 18:00:47 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:47 --> CSRF cookie sent
INFO - 2018-07-02 18:00:47 --> Input Class Initialized
INFO - 2018-07-02 18:00:47 --> Language Class Initialized
INFO - 2018-07-02 18:00:47 --> Loader Class Initialized
INFO - 2018-07-02 18:00:47 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:47 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:47 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:47 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:47 --> Controller Class Initialized
INFO - 2018-07-02 18:00:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:47 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:47 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 18:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:47 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:47 --> Total execution time: 0.0479
INFO - 2018-07-02 18:00:47 --> Config Class Initialized
INFO - 2018-07-02 18:00:47 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:47 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:47 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:47 --> URI Class Initialized
INFO - 2018-07-02 18:00:47 --> Router Class Initialized
INFO - 2018-07-02 18:00:47 --> Output Class Initialized
INFO - 2018-07-02 18:00:47 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:47 --> CSRF cookie sent
INFO - 2018-07-02 18:00:47 --> Input Class Initialized
INFO - 2018-07-02 18:00:47 --> Language Class Initialized
ERROR - 2018-07-02 18:00:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-02 18:00:48 --> Config Class Initialized
INFO - 2018-07-02 18:00:48 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:48 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:48 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:48 --> URI Class Initialized
INFO - 2018-07-02 18:00:48 --> Router Class Initialized
INFO - 2018-07-02 18:00:48 --> Output Class Initialized
INFO - 2018-07-02 18:00:48 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:48 --> CSRF cookie sent
INFO - 2018-07-02 18:00:48 --> Input Class Initialized
INFO - 2018-07-02 18:00:48 --> Language Class Initialized
ERROR - 2018-07-02 18:00:48 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-02 18:00:48 --> Config Class Initialized
INFO - 2018-07-02 18:00:48 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:48 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:48 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:48 --> URI Class Initialized
INFO - 2018-07-02 18:00:48 --> Router Class Initialized
INFO - 2018-07-02 18:00:48 --> Output Class Initialized
INFO - 2018-07-02 18:00:48 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:48 --> CSRF cookie sent
INFO - 2018-07-02 18:00:48 --> Input Class Initialized
INFO - 2018-07-02 18:00:48 --> Language Class Initialized
INFO - 2018-07-02 18:00:48 --> Loader Class Initialized
INFO - 2018-07-02 18:00:48 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:48 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:48 --> Controller Class Initialized
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:48 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:48 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:48 --> Config Class Initialized
INFO - 2018-07-02 18:00:48 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:48 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:48 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:48 --> URI Class Initialized
INFO - 2018-07-02 18:00:48 --> Router Class Initialized
INFO - 2018-07-02 18:00:48 --> Output Class Initialized
INFO - 2018-07-02 18:00:48 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:48 --> CSRF cookie sent
INFO - 2018-07-02 18:00:48 --> Input Class Initialized
INFO - 2018-07-02 18:00:48 --> Language Class Initialized
INFO - 2018-07-02 18:00:48 --> Loader Class Initialized
INFO - 2018-07-02 18:00:48 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:48 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:48 --> Controller Class Initialized
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-02 18:00:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-02 18:00:48 --> Could not find the language line "req_email"
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:48 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:48 --> Total execution time: 0.0237
INFO - 2018-07-02 18:00:48 --> Config Class Initialized
INFO - 2018-07-02 18:00:48 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:48 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:48 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:48 --> URI Class Initialized
INFO - 2018-07-02 18:00:48 --> Router Class Initialized
INFO - 2018-07-02 18:00:48 --> Output Class Initialized
INFO - 2018-07-02 18:00:48 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:48 --> CSRF cookie sent
INFO - 2018-07-02 18:00:48 --> Input Class Initialized
INFO - 2018-07-02 18:00:48 --> Language Class Initialized
INFO - 2018-07-02 18:00:48 --> Loader Class Initialized
INFO - 2018-07-02 18:00:48 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:48 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:48 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:48 --> Controller Class Initialized
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-02 18:00:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:48 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:48 --> Total execution time: 0.0241
INFO - 2018-07-02 18:00:49 --> Config Class Initialized
INFO - 2018-07-02 18:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:49 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:49 --> URI Class Initialized
INFO - 2018-07-02 18:00:49 --> Router Class Initialized
INFO - 2018-07-02 18:00:49 --> Output Class Initialized
INFO - 2018-07-02 18:00:49 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:49 --> CSRF cookie sent
INFO - 2018-07-02 18:00:49 --> Input Class Initialized
INFO - 2018-07-02 18:00:49 --> Language Class Initialized
INFO - 2018-07-02 18:00:49 --> Loader Class Initialized
INFO - 2018-07-02 18:00:49 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:49 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:49 --> Controller Class Initialized
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:49 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:49 --> Total execution time: 0.0339
INFO - 2018-07-02 18:00:49 --> Config Class Initialized
INFO - 2018-07-02 18:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:49 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:49 --> URI Class Initialized
INFO - 2018-07-02 18:00:49 --> Router Class Initialized
INFO - 2018-07-02 18:00:49 --> Output Class Initialized
INFO - 2018-07-02 18:00:49 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:49 --> CSRF cookie sent
INFO - 2018-07-02 18:00:49 --> Input Class Initialized
INFO - 2018-07-02 18:00:49 --> Language Class Initialized
INFO - 2018-07-02 18:00:49 --> Loader Class Initialized
INFO - 2018-07-02 18:00:49 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:49 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:49 --> Controller Class Initialized
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:49 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:49 --> Total execution time: 0.0207
INFO - 2018-07-02 18:00:49 --> Config Class Initialized
INFO - 2018-07-02 18:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:49 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:49 --> URI Class Initialized
INFO - 2018-07-02 18:00:49 --> Router Class Initialized
INFO - 2018-07-02 18:00:49 --> Output Class Initialized
INFO - 2018-07-02 18:00:49 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:49 --> CSRF cookie sent
INFO - 2018-07-02 18:00:49 --> Input Class Initialized
INFO - 2018-07-02 18:00:49 --> Language Class Initialized
INFO - 2018-07-02 18:00:49 --> Loader Class Initialized
INFO - 2018-07-02 18:00:49 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:49 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:49 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:49 --> Controller Class Initialized
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-02 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:49 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:49 --> Total execution time: 0.0207
INFO - 2018-07-02 18:00:50 --> Config Class Initialized
INFO - 2018-07-02 18:00:50 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:50 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:50 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:50 --> URI Class Initialized
INFO - 2018-07-02 18:00:50 --> Router Class Initialized
INFO - 2018-07-02 18:00:50 --> Output Class Initialized
INFO - 2018-07-02 18:00:50 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:50 --> CSRF cookie sent
INFO - 2018-07-02 18:00:50 --> Input Class Initialized
INFO - 2018-07-02 18:00:50 --> Language Class Initialized
INFO - 2018-07-02 18:00:50 --> Loader Class Initialized
INFO - 2018-07-02 18:00:50 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:50 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:50 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:50 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:50 --> Controller Class Initialized
INFO - 2018-07-02 18:00:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-02 18:00:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-02 18:00:50 --> Could not find the language line "req_email"
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:50 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:50 --> Total execution time: 0.0233
INFO - 2018-07-02 18:00:50 --> Config Class Initialized
INFO - 2018-07-02 18:00:50 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:00:50 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:00:50 --> Utf8 Class Initialized
INFO - 2018-07-02 18:00:50 --> URI Class Initialized
INFO - 2018-07-02 18:00:50 --> Router Class Initialized
INFO - 2018-07-02 18:00:50 --> Output Class Initialized
INFO - 2018-07-02 18:00:50 --> Security Class Initialized
DEBUG - 2018-07-02 18:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:00:50 --> CSRF cookie sent
INFO - 2018-07-02 18:00:50 --> Input Class Initialized
INFO - 2018-07-02 18:00:50 --> Language Class Initialized
INFO - 2018-07-02 18:00:50 --> Loader Class Initialized
INFO - 2018-07-02 18:00:50 --> Helper loaded: url_helper
INFO - 2018-07-02 18:00:50 --> Helper loaded: form_helper
INFO - 2018-07-02 18:00:50 --> Helper loaded: language_helper
DEBUG - 2018-07-02 18:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 18:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 18:00:50 --> User Agent Class Initialized
INFO - 2018-07-02 18:00:50 --> Controller Class Initialized
INFO - 2018-07-02 18:00:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 18:00:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 18:00:50 --> Pixel_Model class loaded
INFO - 2018-07-02 18:00:50 --> Database Driver Class Initialized
INFO - 2018-07-02 18:00:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-02 18:00:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 18:00:50 --> Final output sent to browser
DEBUG - 2018-07-02 18:00:50 --> Total execution time: 0.0379
INFO - 2018-07-02 18:03:31 --> Config Class Initialized
INFO - 2018-07-02 18:03:31 --> Hooks Class Initialized
DEBUG - 2018-07-02 18:03:31 --> UTF-8 Support Enabled
INFO - 2018-07-02 18:03:31 --> Utf8 Class Initialized
INFO - 2018-07-02 18:03:31 --> URI Class Initialized
INFO - 2018-07-02 18:03:31 --> Router Class Initialized
INFO - 2018-07-02 18:03:31 --> Output Class Initialized
INFO - 2018-07-02 18:03:31 --> Security Class Initialized
DEBUG - 2018-07-02 18:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 18:03:31 --> CSRF cookie sent
INFO - 2018-07-02 18:03:31 --> Input Class Initialized
INFO - 2018-07-02 18:03:31 --> Language Class Initialized
ERROR - 2018-07-02 18:03:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-02 19:02:32 --> Config Class Initialized
INFO - 2018-07-02 19:02:32 --> Hooks Class Initialized
DEBUG - 2018-07-02 19:02:32 --> UTF-8 Support Enabled
INFO - 2018-07-02 19:02:32 --> Utf8 Class Initialized
INFO - 2018-07-02 19:02:32 --> URI Class Initialized
DEBUG - 2018-07-02 19:02:32 --> No URI present. Default controller set.
INFO - 2018-07-02 19:02:32 --> Router Class Initialized
INFO - 2018-07-02 19:02:32 --> Output Class Initialized
INFO - 2018-07-02 19:02:32 --> Security Class Initialized
DEBUG - 2018-07-02 19:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 19:02:32 --> CSRF cookie sent
INFO - 2018-07-02 19:02:32 --> Input Class Initialized
INFO - 2018-07-02 19:02:32 --> Language Class Initialized
INFO - 2018-07-02 19:02:32 --> Loader Class Initialized
INFO - 2018-07-02 19:02:32 --> Helper loaded: url_helper
INFO - 2018-07-02 19:02:32 --> Helper loaded: form_helper
INFO - 2018-07-02 19:02:32 --> Helper loaded: language_helper
DEBUG - 2018-07-02 19:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 19:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 19:02:32 --> User Agent Class Initialized
INFO - 2018-07-02 19:02:32 --> Controller Class Initialized
INFO - 2018-07-02 19:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 19:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 19:02:32 --> Pixel_Model class loaded
INFO - 2018-07-02 19:02:32 --> Database Driver Class Initialized
INFO - 2018-07-02 19:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 19:02:32 --> Final output sent to browser
DEBUG - 2018-07-02 19:02:32 --> Total execution time: 0.0360
INFO - 2018-07-02 19:07:56 --> Config Class Initialized
INFO - 2018-07-02 19:07:56 --> Hooks Class Initialized
DEBUG - 2018-07-02 19:07:56 --> UTF-8 Support Enabled
INFO - 2018-07-02 19:07:56 --> Utf8 Class Initialized
INFO - 2018-07-02 19:07:56 --> URI Class Initialized
DEBUG - 2018-07-02 19:07:56 --> No URI present. Default controller set.
INFO - 2018-07-02 19:07:56 --> Router Class Initialized
INFO - 2018-07-02 19:07:56 --> Output Class Initialized
INFO - 2018-07-02 19:07:56 --> Security Class Initialized
DEBUG - 2018-07-02 19:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 19:07:56 --> CSRF cookie sent
INFO - 2018-07-02 19:07:56 --> Input Class Initialized
INFO - 2018-07-02 19:07:56 --> Language Class Initialized
INFO - 2018-07-02 19:07:56 --> Loader Class Initialized
INFO - 2018-07-02 19:07:56 --> Helper loaded: url_helper
INFO - 2018-07-02 19:07:56 --> Helper loaded: form_helper
INFO - 2018-07-02 19:07:56 --> Helper loaded: language_helper
DEBUG - 2018-07-02 19:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 19:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 19:07:56 --> User Agent Class Initialized
INFO - 2018-07-02 19:07:56 --> Controller Class Initialized
INFO - 2018-07-02 19:07:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 19:07:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 19:07:56 --> Pixel_Model class loaded
INFO - 2018-07-02 19:07:56 --> Database Driver Class Initialized
INFO - 2018-07-02 19:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 19:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 19:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 19:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 19:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 19:07:56 --> Final output sent to browser
DEBUG - 2018-07-02 19:07:56 --> Total execution time: 0.0353
INFO - 2018-07-02 22:00:18 --> Config Class Initialized
INFO - 2018-07-02 22:00:18 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:00:18 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:00:18 --> Utf8 Class Initialized
INFO - 2018-07-02 22:00:18 --> URI Class Initialized
DEBUG - 2018-07-02 22:00:18 --> No URI present. Default controller set.
INFO - 2018-07-02 22:00:18 --> Router Class Initialized
INFO - 2018-07-02 22:00:18 --> Output Class Initialized
INFO - 2018-07-02 22:00:18 --> Security Class Initialized
DEBUG - 2018-07-02 22:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:00:18 --> CSRF cookie sent
INFO - 2018-07-02 22:00:18 --> Input Class Initialized
INFO - 2018-07-02 22:00:18 --> Language Class Initialized
INFO - 2018-07-02 22:00:18 --> Loader Class Initialized
INFO - 2018-07-02 22:00:18 --> Helper loaded: url_helper
INFO - 2018-07-02 22:00:18 --> Helper loaded: form_helper
INFO - 2018-07-02 22:00:18 --> Helper loaded: language_helper
DEBUG - 2018-07-02 22:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:00:18 --> User Agent Class Initialized
INFO - 2018-07-02 22:00:18 --> Controller Class Initialized
INFO - 2018-07-02 22:00:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 22:00:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 22:00:18 --> Pixel_Model class loaded
INFO - 2018-07-02 22:00:18 --> Database Driver Class Initialized
INFO - 2018-07-02 22:00:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-02 22:00:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 22:00:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 22:00:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-02 22:00:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 22:00:18 --> Final output sent to browser
DEBUG - 2018-07-02 22:00:18 --> Total execution time: 0.0332
INFO - 2018-07-02 22:13:38 --> Config Class Initialized
INFO - 2018-07-02 22:13:38 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:13:38 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:13:38 --> Utf8 Class Initialized
INFO - 2018-07-02 22:13:38 --> URI Class Initialized
INFO - 2018-07-02 22:13:38 --> Router Class Initialized
INFO - 2018-07-02 22:13:38 --> Output Class Initialized
INFO - 2018-07-02 22:13:38 --> Security Class Initialized
DEBUG - 2018-07-02 22:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:13:38 --> CSRF cookie sent
INFO - 2018-07-02 22:13:38 --> Input Class Initialized
INFO - 2018-07-02 22:13:38 --> Language Class Initialized
ERROR - 2018-07-02 22:13:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-02 22:13:41 --> Config Class Initialized
INFO - 2018-07-02 22:13:41 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:13:41 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:13:41 --> Utf8 Class Initialized
INFO - 2018-07-02 22:13:41 --> URI Class Initialized
INFO - 2018-07-02 22:13:41 --> Router Class Initialized
INFO - 2018-07-02 22:13:41 --> Output Class Initialized
INFO - 2018-07-02 22:13:41 --> Security Class Initialized
DEBUG - 2018-07-02 22:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:13:41 --> CSRF cookie sent
INFO - 2018-07-02 22:13:41 --> Input Class Initialized
INFO - 2018-07-02 22:13:41 --> Language Class Initialized
INFO - 2018-07-02 22:13:41 --> Loader Class Initialized
INFO - 2018-07-02 22:13:41 --> Helper loaded: url_helper
INFO - 2018-07-02 22:13:41 --> Helper loaded: form_helper
INFO - 2018-07-02 22:13:41 --> Helper loaded: language_helper
DEBUG - 2018-07-02 22:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:13:41 --> User Agent Class Initialized
INFO - 2018-07-02 22:13:41 --> Controller Class Initialized
INFO - 2018-07-02 22:13:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-02 22:13:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-02 22:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-02 22:13:41 --> Final output sent to browser
DEBUG - 2018-07-02 22:13:41 --> Total execution time: 0.0233

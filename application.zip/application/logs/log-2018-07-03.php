<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-03 01:50:44 --> Config Class Initialized
INFO - 2018-07-03 01:50:44 --> Hooks Class Initialized
DEBUG - 2018-07-03 01:50:44 --> UTF-8 Support Enabled
INFO - 2018-07-03 01:50:44 --> Utf8 Class Initialized
INFO - 2018-07-03 01:50:44 --> URI Class Initialized
DEBUG - 2018-07-03 01:50:44 --> No URI present. Default controller set.
INFO - 2018-07-03 01:50:44 --> Router Class Initialized
INFO - 2018-07-03 01:50:44 --> Output Class Initialized
INFO - 2018-07-03 01:50:44 --> Security Class Initialized
DEBUG - 2018-07-03 01:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 01:50:44 --> CSRF cookie sent
INFO - 2018-07-03 01:50:44 --> Input Class Initialized
INFO - 2018-07-03 01:50:44 --> Language Class Initialized
INFO - 2018-07-03 01:50:44 --> Loader Class Initialized
INFO - 2018-07-03 01:50:44 --> Helper loaded: url_helper
INFO - 2018-07-03 01:50:44 --> Helper loaded: form_helper
INFO - 2018-07-03 01:50:44 --> Helper loaded: language_helper
DEBUG - 2018-07-03 01:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 01:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 01:50:44 --> User Agent Class Initialized
INFO - 2018-07-03 01:50:44 --> Controller Class Initialized
INFO - 2018-07-03 01:50:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 01:50:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 01:50:44 --> Pixel_Model class loaded
INFO - 2018-07-03 01:50:44 --> Database Driver Class Initialized
INFO - 2018-07-03 01:50:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 01:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 01:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 01:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 01:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 01:50:44 --> Final output sent to browser
DEBUG - 2018-07-03 01:50:44 --> Total execution time: 0.0420
INFO - 2018-07-03 02:22:31 --> Config Class Initialized
INFO - 2018-07-03 02:22:31 --> Hooks Class Initialized
DEBUG - 2018-07-03 02:22:31 --> UTF-8 Support Enabled
INFO - 2018-07-03 02:22:31 --> Utf8 Class Initialized
INFO - 2018-07-03 02:22:31 --> URI Class Initialized
INFO - 2018-07-03 02:22:31 --> Router Class Initialized
INFO - 2018-07-03 02:22:31 --> Output Class Initialized
INFO - 2018-07-03 02:22:31 --> Security Class Initialized
DEBUG - 2018-07-03 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 02:22:31 --> CSRF cookie sent
INFO - 2018-07-03 02:22:31 --> Input Class Initialized
INFO - 2018-07-03 02:22:31 --> Language Class Initialized
ERROR - 2018-07-03 02:22:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 02:22:34 --> Config Class Initialized
INFO - 2018-07-03 02:22:34 --> Hooks Class Initialized
DEBUG - 2018-07-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2018-07-03 02:22:34 --> Utf8 Class Initialized
INFO - 2018-07-03 02:22:34 --> URI Class Initialized
DEBUG - 2018-07-03 02:22:34 --> No URI present. Default controller set.
INFO - 2018-07-03 02:22:34 --> Router Class Initialized
INFO - 2018-07-03 02:22:34 --> Output Class Initialized
INFO - 2018-07-03 02:22:34 --> Security Class Initialized
DEBUG - 2018-07-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 02:22:34 --> CSRF cookie sent
INFO - 2018-07-03 02:22:34 --> Input Class Initialized
INFO - 2018-07-03 02:22:34 --> Language Class Initialized
INFO - 2018-07-03 02:22:34 --> Loader Class Initialized
INFO - 2018-07-03 02:22:34 --> Helper loaded: url_helper
INFO - 2018-07-03 02:22:34 --> Helper loaded: form_helper
INFO - 2018-07-03 02:22:34 --> Helper loaded: language_helper
DEBUG - 2018-07-03 02:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 02:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 02:22:34 --> User Agent Class Initialized
INFO - 2018-07-03 02:22:34 --> Controller Class Initialized
INFO - 2018-07-03 02:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 02:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 02:22:34 --> Pixel_Model class loaded
INFO - 2018-07-03 02:22:34 --> Database Driver Class Initialized
INFO - 2018-07-03 02:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 02:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 02:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 02:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 02:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 02:22:34 --> Final output sent to browser
DEBUG - 2018-07-03 02:22:34 --> Total execution time: 0.0436
INFO - 2018-07-03 04:01:01 --> Config Class Initialized
INFO - 2018-07-03 04:01:01 --> Hooks Class Initialized
DEBUG - 2018-07-03 04:01:01 --> UTF-8 Support Enabled
INFO - 2018-07-03 04:01:01 --> Utf8 Class Initialized
INFO - 2018-07-03 04:01:01 --> URI Class Initialized
INFO - 2018-07-03 04:01:01 --> Router Class Initialized
INFO - 2018-07-03 04:01:01 --> Output Class Initialized
INFO - 2018-07-03 04:01:01 --> Security Class Initialized
DEBUG - 2018-07-03 04:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 04:01:01 --> CSRF cookie sent
INFO - 2018-07-03 04:01:01 --> Input Class Initialized
INFO - 2018-07-03 04:01:01 --> Language Class Initialized
INFO - 2018-07-03 04:01:01 --> Loader Class Initialized
INFO - 2018-07-03 04:01:01 --> Helper loaded: url_helper
INFO - 2018-07-03 04:01:01 --> Helper loaded: form_helper
INFO - 2018-07-03 04:01:01 --> Helper loaded: language_helper
DEBUG - 2018-07-03 04:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 04:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 04:01:01 --> User Agent Class Initialized
INFO - 2018-07-03 04:01:01 --> Controller Class Initialized
INFO - 2018-07-03 04:01:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 04:01:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-03 04:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 04:01:01 --> Final output sent to browser
DEBUG - 2018-07-03 04:01:01 --> Total execution time: 0.0264
INFO - 2018-07-03 05:46:21 --> Config Class Initialized
INFO - 2018-07-03 05:46:21 --> Hooks Class Initialized
DEBUG - 2018-07-03 05:46:21 --> UTF-8 Support Enabled
INFO - 2018-07-03 05:46:21 --> Utf8 Class Initialized
INFO - 2018-07-03 05:46:21 --> URI Class Initialized
INFO - 2018-07-03 05:46:21 --> Router Class Initialized
INFO - 2018-07-03 05:46:21 --> Output Class Initialized
INFO - 2018-07-03 05:46:21 --> Security Class Initialized
DEBUG - 2018-07-03 05:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 05:46:21 --> CSRF cookie sent
INFO - 2018-07-03 05:46:21 --> Input Class Initialized
INFO - 2018-07-03 05:46:21 --> Language Class Initialized
ERROR - 2018-07-03 05:46:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 09:50:39 --> Config Class Initialized
INFO - 2018-07-03 09:50:39 --> Hooks Class Initialized
DEBUG - 2018-07-03 09:50:39 --> UTF-8 Support Enabled
INFO - 2018-07-03 09:50:39 --> Utf8 Class Initialized
INFO - 2018-07-03 09:50:39 --> URI Class Initialized
DEBUG - 2018-07-03 09:50:39 --> No URI present. Default controller set.
INFO - 2018-07-03 09:50:39 --> Router Class Initialized
INFO - 2018-07-03 09:50:39 --> Output Class Initialized
INFO - 2018-07-03 09:50:39 --> Security Class Initialized
DEBUG - 2018-07-03 09:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 09:50:39 --> CSRF cookie sent
INFO - 2018-07-03 09:50:39 --> Input Class Initialized
INFO - 2018-07-03 09:50:39 --> Language Class Initialized
INFO - 2018-07-03 09:50:39 --> Loader Class Initialized
INFO - 2018-07-03 09:50:39 --> Helper loaded: url_helper
INFO - 2018-07-03 09:50:39 --> Helper loaded: form_helper
INFO - 2018-07-03 09:50:39 --> Helper loaded: language_helper
DEBUG - 2018-07-03 09:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 09:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 09:50:39 --> User Agent Class Initialized
INFO - 2018-07-03 09:50:39 --> Controller Class Initialized
INFO - 2018-07-03 09:50:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 09:50:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 09:50:39 --> Pixel_Model class loaded
INFO - 2018-07-03 09:50:39 --> Database Driver Class Initialized
INFO - 2018-07-03 09:50:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 09:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 09:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 09:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 09:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 09:50:39 --> Final output sent to browser
DEBUG - 2018-07-03 09:50:39 --> Total execution time: 0.0336
INFO - 2018-07-03 11:15:07 --> Config Class Initialized
INFO - 2018-07-03 11:15:07 --> Hooks Class Initialized
DEBUG - 2018-07-03 11:15:07 --> UTF-8 Support Enabled
INFO - 2018-07-03 11:15:07 --> Utf8 Class Initialized
INFO - 2018-07-03 11:15:07 --> URI Class Initialized
DEBUG - 2018-07-03 11:15:07 --> No URI present. Default controller set.
INFO - 2018-07-03 11:15:07 --> Router Class Initialized
INFO - 2018-07-03 11:15:07 --> Output Class Initialized
INFO - 2018-07-03 11:15:07 --> Security Class Initialized
DEBUG - 2018-07-03 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 11:15:07 --> CSRF cookie sent
INFO - 2018-07-03 11:15:07 --> Input Class Initialized
INFO - 2018-07-03 11:15:07 --> Language Class Initialized
INFO - 2018-07-03 11:15:07 --> Loader Class Initialized
INFO - 2018-07-03 11:15:07 --> Helper loaded: url_helper
INFO - 2018-07-03 11:15:07 --> Helper loaded: form_helper
INFO - 2018-07-03 11:15:07 --> Helper loaded: language_helper
DEBUG - 2018-07-03 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 11:15:07 --> User Agent Class Initialized
INFO - 2018-07-03 11:15:07 --> Controller Class Initialized
INFO - 2018-07-03 11:15:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 11:15:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 11:15:07 --> Pixel_Model class loaded
INFO - 2018-07-03 11:15:07 --> Database Driver Class Initialized
INFO - 2018-07-03 11:15:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 11:15:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 11:15:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 11:15:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 11:15:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 11:15:07 --> Final output sent to browser
DEBUG - 2018-07-03 11:15:07 --> Total execution time: 0.0330
INFO - 2018-07-03 11:15:09 --> Config Class Initialized
INFO - 2018-07-03 11:15:09 --> Hooks Class Initialized
DEBUG - 2018-07-03 11:15:09 --> UTF-8 Support Enabled
INFO - 2018-07-03 11:15:09 --> Utf8 Class Initialized
INFO - 2018-07-03 11:15:09 --> URI Class Initialized
DEBUG - 2018-07-03 11:15:09 --> No URI present. Default controller set.
INFO - 2018-07-03 11:15:09 --> Router Class Initialized
INFO - 2018-07-03 11:15:09 --> Output Class Initialized
INFO - 2018-07-03 11:15:09 --> Security Class Initialized
DEBUG - 2018-07-03 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 11:15:09 --> CSRF cookie sent
INFO - 2018-07-03 11:15:09 --> Input Class Initialized
INFO - 2018-07-03 11:15:09 --> Language Class Initialized
INFO - 2018-07-03 11:15:09 --> Loader Class Initialized
INFO - 2018-07-03 11:15:09 --> Helper loaded: url_helper
INFO - 2018-07-03 11:15:09 --> Helper loaded: form_helper
INFO - 2018-07-03 11:15:09 --> Helper loaded: language_helper
DEBUG - 2018-07-03 11:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 11:15:09 --> User Agent Class Initialized
INFO - 2018-07-03 11:15:09 --> Controller Class Initialized
INFO - 2018-07-03 11:15:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 11:15:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 11:15:09 --> Pixel_Model class loaded
INFO - 2018-07-03 11:15:09 --> Database Driver Class Initialized
INFO - 2018-07-03 11:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 11:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 11:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 11:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 11:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 11:15:09 --> Final output sent to browser
DEBUG - 2018-07-03 11:15:09 --> Total execution time: 0.0327
INFO - 2018-07-03 11:39:33 --> Config Class Initialized
INFO - 2018-07-03 11:39:33 --> Hooks Class Initialized
DEBUG - 2018-07-03 11:39:33 --> UTF-8 Support Enabled
INFO - 2018-07-03 11:39:33 --> Utf8 Class Initialized
INFO - 2018-07-03 11:39:33 --> URI Class Initialized
INFO - 2018-07-03 11:39:33 --> Router Class Initialized
INFO - 2018-07-03 11:39:33 --> Output Class Initialized
INFO - 2018-07-03 11:39:33 --> Security Class Initialized
DEBUG - 2018-07-03 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 11:39:33 --> CSRF cookie sent
INFO - 2018-07-03 11:39:33 --> Input Class Initialized
INFO - 2018-07-03 11:39:33 --> Language Class Initialized
ERROR - 2018-07-03 11:39:33 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 11:39:33 --> Config Class Initialized
INFO - 2018-07-03 11:39:33 --> Hooks Class Initialized
DEBUG - 2018-07-03 11:39:33 --> UTF-8 Support Enabled
INFO - 2018-07-03 11:39:33 --> Utf8 Class Initialized
INFO - 2018-07-03 11:39:33 --> URI Class Initialized
DEBUG - 2018-07-03 11:39:33 --> No URI present. Default controller set.
INFO - 2018-07-03 11:39:33 --> Router Class Initialized
INFO - 2018-07-03 11:39:33 --> Output Class Initialized
INFO - 2018-07-03 11:39:33 --> Security Class Initialized
DEBUG - 2018-07-03 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 11:39:33 --> CSRF cookie sent
INFO - 2018-07-03 11:39:33 --> Input Class Initialized
INFO - 2018-07-03 11:39:33 --> Language Class Initialized
INFO - 2018-07-03 11:39:33 --> Loader Class Initialized
INFO - 2018-07-03 11:39:33 --> Helper loaded: url_helper
INFO - 2018-07-03 11:39:33 --> Helper loaded: form_helper
INFO - 2018-07-03 11:39:33 --> Helper loaded: language_helper
DEBUG - 2018-07-03 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 11:39:33 --> User Agent Class Initialized
INFO - 2018-07-03 11:39:33 --> Controller Class Initialized
INFO - 2018-07-03 11:39:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 11:39:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 11:39:33 --> Pixel_Model class loaded
INFO - 2018-07-03 11:39:33 --> Database Driver Class Initialized
INFO - 2018-07-03 11:39:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 11:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 11:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 11:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 11:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 11:39:33 --> Final output sent to browser
DEBUG - 2018-07-03 11:39:33 --> Total execution time: 0.0362
INFO - 2018-07-03 14:52:12 --> Config Class Initialized
INFO - 2018-07-03 14:52:12 --> Hooks Class Initialized
DEBUG - 2018-07-03 14:52:12 --> UTF-8 Support Enabled
INFO - 2018-07-03 14:52:12 --> Utf8 Class Initialized
INFO - 2018-07-03 14:52:12 --> URI Class Initialized
DEBUG - 2018-07-03 14:52:12 --> No URI present. Default controller set.
INFO - 2018-07-03 14:52:12 --> Router Class Initialized
INFO - 2018-07-03 14:52:12 --> Output Class Initialized
INFO - 2018-07-03 14:52:12 --> Security Class Initialized
DEBUG - 2018-07-03 14:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 14:52:12 --> CSRF cookie sent
INFO - 2018-07-03 14:52:12 --> Input Class Initialized
INFO - 2018-07-03 14:52:12 --> Language Class Initialized
INFO - 2018-07-03 14:52:12 --> Loader Class Initialized
INFO - 2018-07-03 14:52:12 --> Helper loaded: url_helper
INFO - 2018-07-03 14:52:12 --> Helper loaded: form_helper
INFO - 2018-07-03 14:52:12 --> Helper loaded: language_helper
DEBUG - 2018-07-03 14:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 14:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 14:52:12 --> User Agent Class Initialized
INFO - 2018-07-03 14:52:12 --> Controller Class Initialized
INFO - 2018-07-03 14:52:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 14:52:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 14:52:12 --> Pixel_Model class loaded
INFO - 2018-07-03 14:52:12 --> Database Driver Class Initialized
INFO - 2018-07-03 14:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 14:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 14:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 14:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 14:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 14:52:12 --> Final output sent to browser
DEBUG - 2018-07-03 14:52:12 --> Total execution time: 0.0357
INFO - 2018-07-03 15:40:40 --> Config Class Initialized
INFO - 2018-07-03 15:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-03 15:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-03 15:40:40 --> Utf8 Class Initialized
INFO - 2018-07-03 15:40:40 --> URI Class Initialized
DEBUG - 2018-07-03 15:40:40 --> No URI present. Default controller set.
INFO - 2018-07-03 15:40:40 --> Router Class Initialized
INFO - 2018-07-03 15:40:40 --> Output Class Initialized
INFO - 2018-07-03 15:40:40 --> Security Class Initialized
DEBUG - 2018-07-03 15:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 15:40:40 --> CSRF cookie sent
INFO - 2018-07-03 15:40:40 --> Input Class Initialized
INFO - 2018-07-03 15:40:40 --> Language Class Initialized
INFO - 2018-07-03 15:40:40 --> Loader Class Initialized
INFO - 2018-07-03 15:40:40 --> Helper loaded: url_helper
INFO - 2018-07-03 15:40:40 --> Helper loaded: form_helper
INFO - 2018-07-03 15:40:40 --> Helper loaded: language_helper
DEBUG - 2018-07-03 15:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 15:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 15:40:40 --> User Agent Class Initialized
INFO - 2018-07-03 15:40:40 --> Controller Class Initialized
INFO - 2018-07-03 15:40:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 15:40:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 15:40:40 --> Pixel_Model class loaded
INFO - 2018-07-03 15:40:40 --> Database Driver Class Initialized
INFO - 2018-07-03 15:40:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 15:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 15:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 15:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 15:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 15:40:40 --> Final output sent to browser
DEBUG - 2018-07-03 15:40:40 --> Total execution time: 0.0484
INFO - 2018-07-03 16:13:42 --> Config Class Initialized
INFO - 2018-07-03 16:13:42 --> Hooks Class Initialized
DEBUG - 2018-07-03 16:13:42 --> UTF-8 Support Enabled
INFO - 2018-07-03 16:13:42 --> Utf8 Class Initialized
INFO - 2018-07-03 16:13:42 --> URI Class Initialized
INFO - 2018-07-03 16:13:42 --> Router Class Initialized
INFO - 2018-07-03 16:13:42 --> Output Class Initialized
INFO - 2018-07-03 16:13:42 --> Security Class Initialized
DEBUG - 2018-07-03 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 16:13:42 --> CSRF cookie sent
INFO - 2018-07-03 16:13:42 --> Input Class Initialized
INFO - 2018-07-03 16:13:42 --> Language Class Initialized
ERROR - 2018-07-03 16:13:42 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 17:01:13 --> Config Class Initialized
INFO - 2018-07-03 17:01:13 --> Hooks Class Initialized
DEBUG - 2018-07-03 17:01:13 --> UTF-8 Support Enabled
INFO - 2018-07-03 17:01:13 --> Utf8 Class Initialized
INFO - 2018-07-03 17:01:13 --> URI Class Initialized
INFO - 2018-07-03 17:01:13 --> Router Class Initialized
INFO - 2018-07-03 17:01:13 --> Output Class Initialized
INFO - 2018-07-03 17:01:13 --> Security Class Initialized
DEBUG - 2018-07-03 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 17:01:13 --> CSRF cookie sent
INFO - 2018-07-03 17:01:13 --> Input Class Initialized
INFO - 2018-07-03 17:01:13 --> Language Class Initialized
ERROR - 2018-07-03 17:01:13 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 17:30:27 --> Config Class Initialized
INFO - 2018-07-03 17:30:27 --> Hooks Class Initialized
DEBUG - 2018-07-03 17:30:27 --> UTF-8 Support Enabled
INFO - 2018-07-03 17:30:27 --> Utf8 Class Initialized
INFO - 2018-07-03 17:30:27 --> URI Class Initialized
INFO - 2018-07-03 17:30:27 --> Router Class Initialized
INFO - 2018-07-03 17:30:27 --> Output Class Initialized
INFO - 2018-07-03 17:30:27 --> Security Class Initialized
DEBUG - 2018-07-03 17:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 17:30:27 --> CSRF cookie sent
INFO - 2018-07-03 17:30:27 --> Input Class Initialized
INFO - 2018-07-03 17:30:27 --> Language Class Initialized
ERROR - 2018-07-03 17:30:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-03 17:45:13 --> Config Class Initialized
INFO - 2018-07-03 17:45:13 --> Hooks Class Initialized
DEBUG - 2018-07-03 17:45:13 --> UTF-8 Support Enabled
INFO - 2018-07-03 17:45:13 --> Utf8 Class Initialized
INFO - 2018-07-03 17:45:13 --> URI Class Initialized
DEBUG - 2018-07-03 17:45:13 --> No URI present. Default controller set.
INFO - 2018-07-03 17:45:13 --> Router Class Initialized
INFO - 2018-07-03 17:45:13 --> Output Class Initialized
INFO - 2018-07-03 17:45:13 --> Security Class Initialized
DEBUG - 2018-07-03 17:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 17:45:13 --> CSRF cookie sent
INFO - 2018-07-03 17:45:13 --> Input Class Initialized
INFO - 2018-07-03 17:45:13 --> Language Class Initialized
INFO - 2018-07-03 17:45:13 --> Loader Class Initialized
INFO - 2018-07-03 17:45:13 --> Helper loaded: url_helper
INFO - 2018-07-03 17:45:13 --> Helper loaded: form_helper
INFO - 2018-07-03 17:45:13 --> Helper loaded: language_helper
DEBUG - 2018-07-03 17:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 17:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 17:45:13 --> User Agent Class Initialized
INFO - 2018-07-03 17:45:13 --> Controller Class Initialized
INFO - 2018-07-03 17:45:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 17:45:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 17:45:13 --> Pixel_Model class loaded
INFO - 2018-07-03 17:45:13 --> Database Driver Class Initialized
INFO - 2018-07-03 17:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 17:45:13 --> Final output sent to browser
DEBUG - 2018-07-03 17:45:13 --> Total execution time: 0.0479
INFO - 2018-07-03 17:48:00 --> Config Class Initialized
INFO - 2018-07-03 17:48:00 --> Hooks Class Initialized
DEBUG - 2018-07-03 17:48:00 --> UTF-8 Support Enabled
INFO - 2018-07-03 17:48:00 --> Utf8 Class Initialized
INFO - 2018-07-03 17:48:00 --> URI Class Initialized
DEBUG - 2018-07-03 17:48:00 --> No URI present. Default controller set.
INFO - 2018-07-03 17:48:00 --> Router Class Initialized
INFO - 2018-07-03 17:48:00 --> Output Class Initialized
INFO - 2018-07-03 17:48:00 --> Security Class Initialized
DEBUG - 2018-07-03 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 17:48:00 --> CSRF cookie sent
INFO - 2018-07-03 17:48:00 --> Input Class Initialized
INFO - 2018-07-03 17:48:00 --> Language Class Initialized
INFO - 2018-07-03 17:48:00 --> Loader Class Initialized
INFO - 2018-07-03 17:48:00 --> Helper loaded: url_helper
INFO - 2018-07-03 17:48:00 --> Helper loaded: form_helper
INFO - 2018-07-03 17:48:00 --> Helper loaded: language_helper
DEBUG - 2018-07-03 17:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 17:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 17:48:00 --> User Agent Class Initialized
INFO - 2018-07-03 17:48:00 --> Controller Class Initialized
INFO - 2018-07-03 17:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 17:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 17:48:00 --> Pixel_Model class loaded
INFO - 2018-07-03 17:48:00 --> Database Driver Class Initialized
INFO - 2018-07-03 17:48:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 17:48:00 --> Final output sent to browser
DEBUG - 2018-07-03 17:48:00 --> Total execution time: 0.0341
INFO - 2018-07-03 17:48:00 --> Config Class Initialized
INFO - 2018-07-03 17:48:00 --> Hooks Class Initialized
DEBUG - 2018-07-03 17:48:00 --> UTF-8 Support Enabled
INFO - 2018-07-03 17:48:00 --> Utf8 Class Initialized
INFO - 2018-07-03 17:48:00 --> URI Class Initialized
DEBUG - 2018-07-03 17:48:00 --> No URI present. Default controller set.
INFO - 2018-07-03 17:48:00 --> Router Class Initialized
INFO - 2018-07-03 17:48:00 --> Output Class Initialized
INFO - 2018-07-03 17:48:00 --> Security Class Initialized
DEBUG - 2018-07-03 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 17:48:00 --> CSRF cookie sent
INFO - 2018-07-03 17:48:00 --> Input Class Initialized
INFO - 2018-07-03 17:48:00 --> Language Class Initialized
INFO - 2018-07-03 17:48:00 --> Loader Class Initialized
INFO - 2018-07-03 17:48:00 --> Helper loaded: url_helper
INFO - 2018-07-03 17:48:00 --> Helper loaded: form_helper
INFO - 2018-07-03 17:48:00 --> Helper loaded: language_helper
DEBUG - 2018-07-03 17:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 17:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 17:48:00 --> User Agent Class Initialized
INFO - 2018-07-03 17:48:00 --> Controller Class Initialized
INFO - 2018-07-03 17:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 17:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 17:48:00 --> Pixel_Model class loaded
INFO - 2018-07-03 17:48:00 --> Database Driver Class Initialized
INFO - 2018-07-03 17:48:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 17:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 17:48:00 --> Final output sent to browser
DEBUG - 2018-07-03 17:48:00 --> Total execution time: 0.0343
INFO - 2018-07-03 18:06:02 --> Config Class Initialized
INFO - 2018-07-03 18:06:02 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:02 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:02 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:02 --> URI Class Initialized
DEBUG - 2018-07-03 18:06:02 --> No URI present. Default controller set.
INFO - 2018-07-03 18:06:02 --> Router Class Initialized
INFO - 2018-07-03 18:06:02 --> Output Class Initialized
INFO - 2018-07-03 18:06:02 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:02 --> CSRF cookie sent
INFO - 2018-07-03 18:06:02 --> Input Class Initialized
INFO - 2018-07-03 18:06:02 --> Language Class Initialized
INFO - 2018-07-03 18:06:02 --> Loader Class Initialized
INFO - 2018-07-03 18:06:02 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:02 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:02 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:02 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:02 --> Controller Class Initialized
INFO - 2018-07-03 18:06:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:02 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:02 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 18:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:02 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:02 --> Total execution time: 0.0322
INFO - 2018-07-03 18:06:03 --> Config Class Initialized
INFO - 2018-07-03 18:06:03 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:03 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:03 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:03 --> URI Class Initialized
DEBUG - 2018-07-03 18:06:03 --> No URI present. Default controller set.
INFO - 2018-07-03 18:06:03 --> Router Class Initialized
INFO - 2018-07-03 18:06:03 --> Output Class Initialized
INFO - 2018-07-03 18:06:03 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:03 --> CSRF cookie sent
INFO - 2018-07-03 18:06:03 --> Input Class Initialized
INFO - 2018-07-03 18:06:03 --> Language Class Initialized
INFO - 2018-07-03 18:06:03 --> Loader Class Initialized
INFO - 2018-07-03 18:06:03 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:03 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:03 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:03 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:03 --> Controller Class Initialized
INFO - 2018-07-03 18:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:03 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:03 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:03 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:03 --> Total execution time: 0.0298
INFO - 2018-07-03 18:06:03 --> Config Class Initialized
INFO - 2018-07-03 18:06:03 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:03 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:03 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:03 --> URI Class Initialized
DEBUG - 2018-07-03 18:06:03 --> No URI present. Default controller set.
INFO - 2018-07-03 18:06:03 --> Router Class Initialized
INFO - 2018-07-03 18:06:03 --> Output Class Initialized
INFO - 2018-07-03 18:06:03 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:03 --> CSRF cookie sent
INFO - 2018-07-03 18:06:03 --> Input Class Initialized
INFO - 2018-07-03 18:06:03 --> Language Class Initialized
INFO - 2018-07-03 18:06:03 --> Loader Class Initialized
INFO - 2018-07-03 18:06:03 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:03 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:03 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:03 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:03 --> Controller Class Initialized
INFO - 2018-07-03 18:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:03 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:03 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 18:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:03 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:03 --> Total execution time: 0.0350
INFO - 2018-07-03 18:06:04 --> Config Class Initialized
INFO - 2018-07-03 18:06:04 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:04 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:04 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:04 --> URI Class Initialized
INFO - 2018-07-03 18:06:04 --> Router Class Initialized
INFO - 2018-07-03 18:06:04 --> Output Class Initialized
INFO - 2018-07-03 18:06:04 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:04 --> CSRF cookie sent
INFO - 2018-07-03 18:06:04 --> Input Class Initialized
INFO - 2018-07-03 18:06:04 --> Language Class Initialized
ERROR - 2018-07-03 18:06:04 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-03 18:06:10 --> Config Class Initialized
INFO - 2018-07-03 18:06:10 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:10 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:10 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:10 --> URI Class Initialized
DEBUG - 2018-07-03 18:06:10 --> No URI present. Default controller set.
INFO - 2018-07-03 18:06:10 --> Router Class Initialized
INFO - 2018-07-03 18:06:10 --> Output Class Initialized
INFO - 2018-07-03 18:06:10 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:10 --> CSRF cookie sent
INFO - 2018-07-03 18:06:10 --> Input Class Initialized
INFO - 2018-07-03 18:06:10 --> Language Class Initialized
INFO - 2018-07-03 18:06:10 --> Loader Class Initialized
INFO - 2018-07-03 18:06:10 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:10 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:10 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:10 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:10 --> Controller Class Initialized
INFO - 2018-07-03 18:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:10 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:10 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 18:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:10 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:10 --> Total execution time: 0.0341
INFO - 2018-07-03 18:06:10 --> Config Class Initialized
INFO - 2018-07-03 18:06:10 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:10 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:10 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:10 --> URI Class Initialized
INFO - 2018-07-03 18:06:10 --> Router Class Initialized
INFO - 2018-07-03 18:06:10 --> Output Class Initialized
INFO - 2018-07-03 18:06:10 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:10 --> CSRF cookie sent
INFO - 2018-07-03 18:06:10 --> Input Class Initialized
INFO - 2018-07-03 18:06:10 --> Language Class Initialized
ERROR - 2018-07-03 18:06:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-03 18:06:11 --> Config Class Initialized
INFO - 2018-07-03 18:06:11 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:11 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:11 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:11 --> URI Class Initialized
INFO - 2018-07-03 18:06:11 --> Router Class Initialized
INFO - 2018-07-03 18:06:11 --> Output Class Initialized
INFO - 2018-07-03 18:06:11 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:11 --> CSRF cookie sent
INFO - 2018-07-03 18:06:11 --> Input Class Initialized
INFO - 2018-07-03 18:06:11 --> Language Class Initialized
ERROR - 2018-07-03 18:06:11 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-03 18:06:11 --> Config Class Initialized
INFO - 2018-07-03 18:06:11 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:11 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:11 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:11 --> URI Class Initialized
INFO - 2018-07-03 18:06:11 --> Router Class Initialized
INFO - 2018-07-03 18:06:11 --> Output Class Initialized
INFO - 2018-07-03 18:06:11 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:11 --> CSRF cookie sent
INFO - 2018-07-03 18:06:11 --> Input Class Initialized
INFO - 2018-07-03 18:06:11 --> Language Class Initialized
INFO - 2018-07-03 18:06:11 --> Loader Class Initialized
INFO - 2018-07-03 18:06:11 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:11 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:11 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:11 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:11 --> Controller Class Initialized
INFO - 2018-07-03 18:06:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:11 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:11 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:11 --> Config Class Initialized
INFO - 2018-07-03 18:06:11 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:11 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:11 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:11 --> URI Class Initialized
INFO - 2018-07-03 18:06:11 --> Router Class Initialized
INFO - 2018-07-03 18:06:11 --> Output Class Initialized
INFO - 2018-07-03 18:06:11 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:11 --> CSRF cookie sent
INFO - 2018-07-03 18:06:11 --> Input Class Initialized
INFO - 2018-07-03 18:06:11 --> Language Class Initialized
INFO - 2018-07-03 18:06:11 --> Loader Class Initialized
INFO - 2018-07-03 18:06:11 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:11 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:11 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:11 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:11 --> Controller Class Initialized
INFO - 2018-07-03 18:06:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-03 18:06:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-03 18:06:11 --> Could not find the language line "req_email"
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-03 18:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:11 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:11 --> Total execution time: 0.0256
INFO - 2018-07-03 18:06:12 --> Config Class Initialized
INFO - 2018-07-03 18:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:12 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:12 --> URI Class Initialized
INFO - 2018-07-03 18:06:12 --> Router Class Initialized
INFO - 2018-07-03 18:06:12 --> Output Class Initialized
INFO - 2018-07-03 18:06:12 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:12 --> CSRF cookie sent
INFO - 2018-07-03 18:06:12 --> Input Class Initialized
INFO - 2018-07-03 18:06:12 --> Language Class Initialized
INFO - 2018-07-03 18:06:12 --> Loader Class Initialized
INFO - 2018-07-03 18:06:12 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:12 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:12 --> Controller Class Initialized
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:12 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:12 --> Total execution time: 0.0216
INFO - 2018-07-03 18:06:12 --> Config Class Initialized
INFO - 2018-07-03 18:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:12 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:12 --> URI Class Initialized
INFO - 2018-07-03 18:06:12 --> Router Class Initialized
INFO - 2018-07-03 18:06:12 --> Output Class Initialized
INFO - 2018-07-03 18:06:12 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:12 --> CSRF cookie sent
INFO - 2018-07-03 18:06:12 --> Input Class Initialized
INFO - 2018-07-03 18:06:12 --> Language Class Initialized
INFO - 2018-07-03 18:06:12 --> Loader Class Initialized
INFO - 2018-07-03 18:06:12 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:12 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:12 --> Controller Class Initialized
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:12 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:12 --> Total execution time: 0.0229
INFO - 2018-07-03 18:06:12 --> Config Class Initialized
INFO - 2018-07-03 18:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:12 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:12 --> URI Class Initialized
INFO - 2018-07-03 18:06:12 --> Router Class Initialized
INFO - 2018-07-03 18:06:12 --> Output Class Initialized
INFO - 2018-07-03 18:06:12 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:12 --> CSRF cookie sent
INFO - 2018-07-03 18:06:12 --> Input Class Initialized
INFO - 2018-07-03 18:06:12 --> Language Class Initialized
INFO - 2018-07-03 18:06:12 --> Loader Class Initialized
INFO - 2018-07-03 18:06:12 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:12 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:12 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:12 --> Controller Class Initialized
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-03 18:06:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:12 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:12 --> Total execution time: 0.0214
INFO - 2018-07-03 18:06:12 --> Config Class Initialized
INFO - 2018-07-03 18:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:12 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:12 --> URI Class Initialized
INFO - 2018-07-03 18:06:12 --> Router Class Initialized
INFO - 2018-07-03 18:06:12 --> Output Class Initialized
INFO - 2018-07-03 18:06:12 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:12 --> CSRF cookie sent
INFO - 2018-07-03 18:06:12 --> Input Class Initialized
INFO - 2018-07-03 18:06:12 --> Language Class Initialized
INFO - 2018-07-03 18:06:13 --> Loader Class Initialized
INFO - 2018-07-03 18:06:13 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:13 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:13 --> Controller Class Initialized
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:13 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:13 --> Total execution time: 0.0219
INFO - 2018-07-03 18:06:13 --> Config Class Initialized
INFO - 2018-07-03 18:06:13 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:13 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:13 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:13 --> URI Class Initialized
INFO - 2018-07-03 18:06:13 --> Router Class Initialized
INFO - 2018-07-03 18:06:13 --> Output Class Initialized
INFO - 2018-07-03 18:06:13 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:13 --> CSRF cookie sent
INFO - 2018-07-03 18:06:13 --> Input Class Initialized
INFO - 2018-07-03 18:06:13 --> Language Class Initialized
INFO - 2018-07-03 18:06:13 --> Loader Class Initialized
INFO - 2018-07-03 18:06:13 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:13 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:13 --> Controller Class Initialized
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-03 18:06:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-03 18:06:13 --> Could not find the language line "req_email"
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:13 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:13 --> Total execution time: 0.0172
INFO - 2018-07-03 18:06:13 --> Config Class Initialized
INFO - 2018-07-03 18:06:13 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:06:13 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:06:13 --> Utf8 Class Initialized
INFO - 2018-07-03 18:06:13 --> URI Class Initialized
INFO - 2018-07-03 18:06:13 --> Router Class Initialized
INFO - 2018-07-03 18:06:13 --> Output Class Initialized
INFO - 2018-07-03 18:06:13 --> Security Class Initialized
DEBUG - 2018-07-03 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:06:13 --> CSRF cookie sent
INFO - 2018-07-03 18:06:13 --> Input Class Initialized
INFO - 2018-07-03 18:06:13 --> Language Class Initialized
INFO - 2018-07-03 18:06:13 --> Loader Class Initialized
INFO - 2018-07-03 18:06:13 --> Helper loaded: url_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: form_helper
INFO - 2018-07-03 18:06:13 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:06:13 --> User Agent Class Initialized
INFO - 2018-07-03 18:06:13 --> Controller Class Initialized
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:06:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:06:13 --> Pixel_Model class loaded
INFO - 2018-07-03 18:06:13 --> Database Driver Class Initialized
INFO - 2018-07-03 18:06:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-03 18:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:06:13 --> Final output sent to browser
DEBUG - 2018-07-03 18:06:13 --> Total execution time: 0.0331
INFO - 2018-07-03 18:40:40 --> Config Class Initialized
INFO - 2018-07-03 18:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-03 18:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-03 18:40:40 --> Utf8 Class Initialized
INFO - 2018-07-03 18:40:40 --> URI Class Initialized
DEBUG - 2018-07-03 18:40:40 --> No URI present. Default controller set.
INFO - 2018-07-03 18:40:40 --> Router Class Initialized
INFO - 2018-07-03 18:40:40 --> Output Class Initialized
INFO - 2018-07-03 18:40:40 --> Security Class Initialized
DEBUG - 2018-07-03 18:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-03 18:40:40 --> CSRF cookie sent
INFO - 2018-07-03 18:40:40 --> Input Class Initialized
INFO - 2018-07-03 18:40:40 --> Language Class Initialized
INFO - 2018-07-03 18:40:40 --> Loader Class Initialized
INFO - 2018-07-03 18:40:40 --> Helper loaded: url_helper
INFO - 2018-07-03 18:40:40 --> Helper loaded: form_helper
INFO - 2018-07-03 18:40:40 --> Helper loaded: language_helper
DEBUG - 2018-07-03 18:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-03 18:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-03 18:40:40 --> User Agent Class Initialized
INFO - 2018-07-03 18:40:40 --> Controller Class Initialized
INFO - 2018-07-03 18:40:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-03 18:40:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-03 18:40:40 --> Pixel_Model class loaded
INFO - 2018-07-03 18:40:40 --> Database Driver Class Initialized
INFO - 2018-07-03 18:40:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-03 18:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-03 18:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-03 18:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-03 18:40:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-03 18:40:40 --> Final output sent to browser
DEBUG - 2018-07-03 18:40:40 --> Total execution time: 0.0332

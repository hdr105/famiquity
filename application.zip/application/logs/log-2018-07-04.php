<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-04 00:16:39 --> Config Class Initialized
INFO - 2018-07-04 00:16:39 --> Hooks Class Initialized
DEBUG - 2018-07-04 00:16:39 --> UTF-8 Support Enabled
INFO - 2018-07-04 00:16:39 --> Utf8 Class Initialized
INFO - 2018-07-04 00:16:39 --> URI Class Initialized
INFO - 2018-07-04 00:16:39 --> Router Class Initialized
INFO - 2018-07-04 00:16:39 --> Output Class Initialized
INFO - 2018-07-04 00:16:39 --> Security Class Initialized
DEBUG - 2018-07-04 00:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 00:16:39 --> CSRF cookie sent
INFO - 2018-07-04 00:16:39 --> Input Class Initialized
INFO - 2018-07-04 00:16:39 --> Language Class Initialized
ERROR - 2018-07-04 00:16:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 00:16:42 --> Config Class Initialized
INFO - 2018-07-04 00:16:42 --> Hooks Class Initialized
DEBUG - 2018-07-04 00:16:42 --> UTF-8 Support Enabled
INFO - 2018-07-04 00:16:42 --> Utf8 Class Initialized
INFO - 2018-07-04 00:16:42 --> URI Class Initialized
DEBUG - 2018-07-04 00:16:42 --> No URI present. Default controller set.
INFO - 2018-07-04 00:16:42 --> Router Class Initialized
INFO - 2018-07-04 00:16:42 --> Output Class Initialized
INFO - 2018-07-04 00:16:42 --> Security Class Initialized
DEBUG - 2018-07-04 00:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 00:16:42 --> CSRF cookie sent
INFO - 2018-07-04 00:16:42 --> Input Class Initialized
INFO - 2018-07-04 00:16:42 --> Language Class Initialized
INFO - 2018-07-04 00:16:42 --> Loader Class Initialized
INFO - 2018-07-04 00:16:42 --> Helper loaded: url_helper
INFO - 2018-07-04 00:16:42 --> Helper loaded: form_helper
INFO - 2018-07-04 00:16:42 --> Helper loaded: language_helper
DEBUG - 2018-07-04 00:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 00:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 00:16:42 --> User Agent Class Initialized
INFO - 2018-07-04 00:16:42 --> Controller Class Initialized
INFO - 2018-07-04 00:16:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 00:16:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 00:16:42 --> Pixel_Model class loaded
INFO - 2018-07-04 00:16:42 --> Database Driver Class Initialized
INFO - 2018-07-04 00:16:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 00:16:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 00:16:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 00:16:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 00:16:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 00:16:42 --> Final output sent to browser
DEBUG - 2018-07-04 00:16:42 --> Total execution time: 0.0363
INFO - 2018-07-04 00:33:33 --> Config Class Initialized
INFO - 2018-07-04 00:33:33 --> Hooks Class Initialized
DEBUG - 2018-07-04 00:33:33 --> UTF-8 Support Enabled
INFO - 2018-07-04 00:33:33 --> Utf8 Class Initialized
INFO - 2018-07-04 00:33:33 --> URI Class Initialized
INFO - 2018-07-04 00:33:33 --> Router Class Initialized
INFO - 2018-07-04 00:33:33 --> Output Class Initialized
INFO - 2018-07-04 00:33:33 --> Security Class Initialized
DEBUG - 2018-07-04 00:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 00:33:33 --> CSRF cookie sent
INFO - 2018-07-04 00:33:33 --> Input Class Initialized
INFO - 2018-07-04 00:33:33 --> Language Class Initialized
INFO - 2018-07-04 00:33:33 --> Loader Class Initialized
INFO - 2018-07-04 00:33:33 --> Helper loaded: url_helper
INFO - 2018-07-04 00:33:33 --> Helper loaded: form_helper
INFO - 2018-07-04 00:33:33 --> Helper loaded: language_helper
DEBUG - 2018-07-04 00:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 00:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 00:33:33 --> User Agent Class Initialized
INFO - 2018-07-04 00:33:33 --> Controller Class Initialized
INFO - 2018-07-04 00:33:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 00:33:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-04 00:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 00:33:33 --> Final output sent to browser
DEBUG - 2018-07-04 00:33:33 --> Total execution time: 0.0335
INFO - 2018-07-04 01:06:09 --> Config Class Initialized
INFO - 2018-07-04 01:06:09 --> Hooks Class Initialized
DEBUG - 2018-07-04 01:06:09 --> UTF-8 Support Enabled
INFO - 2018-07-04 01:06:09 --> Utf8 Class Initialized
INFO - 2018-07-04 01:06:09 --> URI Class Initialized
DEBUG - 2018-07-04 01:06:09 --> No URI present. Default controller set.
INFO - 2018-07-04 01:06:09 --> Router Class Initialized
INFO - 2018-07-04 01:06:09 --> Output Class Initialized
INFO - 2018-07-04 01:06:09 --> Security Class Initialized
DEBUG - 2018-07-04 01:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 01:06:09 --> CSRF cookie sent
INFO - 2018-07-04 01:06:09 --> Input Class Initialized
INFO - 2018-07-04 01:06:09 --> Language Class Initialized
INFO - 2018-07-04 01:06:09 --> Loader Class Initialized
INFO - 2018-07-04 01:06:09 --> Helper loaded: url_helper
INFO - 2018-07-04 01:06:09 --> Helper loaded: form_helper
INFO - 2018-07-04 01:06:09 --> Helper loaded: language_helper
DEBUG - 2018-07-04 01:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 01:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 01:06:09 --> User Agent Class Initialized
INFO - 2018-07-04 01:06:09 --> Controller Class Initialized
INFO - 2018-07-04 01:06:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 01:06:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 01:06:09 --> Pixel_Model class loaded
INFO - 2018-07-04 01:06:09 --> Database Driver Class Initialized
INFO - 2018-07-04 01:06:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 01:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 01:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 01:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 01:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 01:06:09 --> Final output sent to browser
DEBUG - 2018-07-04 01:06:09 --> Total execution time: 0.0325
INFO - 2018-07-04 01:21:54 --> Config Class Initialized
INFO - 2018-07-04 01:21:54 --> Hooks Class Initialized
DEBUG - 2018-07-04 01:21:54 --> UTF-8 Support Enabled
INFO - 2018-07-04 01:21:54 --> Utf8 Class Initialized
INFO - 2018-07-04 01:21:54 --> URI Class Initialized
INFO - 2018-07-04 01:21:54 --> Router Class Initialized
INFO - 2018-07-04 01:21:54 --> Output Class Initialized
INFO - 2018-07-04 01:21:54 --> Security Class Initialized
DEBUG - 2018-07-04 01:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 01:21:54 --> CSRF cookie sent
INFO - 2018-07-04 01:21:54 --> Input Class Initialized
INFO - 2018-07-04 01:21:54 --> Language Class Initialized
INFO - 2018-07-04 01:21:54 --> Loader Class Initialized
INFO - 2018-07-04 01:21:54 --> Helper loaded: url_helper
INFO - 2018-07-04 01:21:54 --> Helper loaded: form_helper
INFO - 2018-07-04 01:21:54 --> Helper loaded: language_helper
DEBUG - 2018-07-04 01:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 01:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 01:21:54 --> User Agent Class Initialized
INFO - 2018-07-04 01:21:54 --> Controller Class Initialized
INFO - 2018-07-04 01:21:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 01:21:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 01:21:54 --> Pixel_Model class loaded
INFO - 2018-07-04 01:21:54 --> Database Driver Class Initialized
INFO - 2018-07-04 01:21:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 01:21:56 --> Config Class Initialized
INFO - 2018-07-04 01:21:56 --> Hooks Class Initialized
DEBUG - 2018-07-04 01:21:56 --> UTF-8 Support Enabled
INFO - 2018-07-04 01:21:56 --> Utf8 Class Initialized
INFO - 2018-07-04 01:21:56 --> URI Class Initialized
INFO - 2018-07-04 01:21:56 --> Router Class Initialized
INFO - 2018-07-04 01:21:56 --> Output Class Initialized
INFO - 2018-07-04 01:21:56 --> Security Class Initialized
DEBUG - 2018-07-04 01:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 01:21:56 --> CSRF cookie sent
INFO - 2018-07-04 01:21:56 --> Input Class Initialized
INFO - 2018-07-04 01:21:56 --> Language Class Initialized
INFO - 2018-07-04 01:21:56 --> Loader Class Initialized
INFO - 2018-07-04 01:21:56 --> Helper loaded: url_helper
INFO - 2018-07-04 01:21:56 --> Helper loaded: form_helper
INFO - 2018-07-04 01:21:56 --> Helper loaded: language_helper
DEBUG - 2018-07-04 01:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 01:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 01:21:56 --> User Agent Class Initialized
INFO - 2018-07-04 01:21:56 --> Controller Class Initialized
INFO - 2018-07-04 01:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 01:21:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 01:21:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 01:21:56 --> Could not find the language line "req_email"
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 01:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 01:21:56 --> Final output sent to browser
DEBUG - 2018-07-04 01:21:56 --> Total execution time: 0.0321
INFO - 2018-07-04 01:55:13 --> Config Class Initialized
INFO - 2018-07-04 01:55:13 --> Hooks Class Initialized
DEBUG - 2018-07-04 01:55:13 --> UTF-8 Support Enabled
INFO - 2018-07-04 01:55:13 --> Utf8 Class Initialized
INFO - 2018-07-04 01:55:13 --> URI Class Initialized
INFO - 2018-07-04 01:55:13 --> Router Class Initialized
INFO - 2018-07-04 01:55:13 --> Output Class Initialized
INFO - 2018-07-04 01:55:13 --> Security Class Initialized
DEBUG - 2018-07-04 01:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 01:55:13 --> CSRF cookie sent
INFO - 2018-07-04 01:55:13 --> Input Class Initialized
INFO - 2018-07-04 01:55:13 --> Language Class Initialized
INFO - 2018-07-04 01:55:13 --> Loader Class Initialized
INFO - 2018-07-04 01:55:13 --> Helper loaded: url_helper
INFO - 2018-07-04 01:55:13 --> Helper loaded: form_helper
INFO - 2018-07-04 01:55:13 --> Helper loaded: language_helper
DEBUG - 2018-07-04 01:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 01:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 01:55:13 --> User Agent Class Initialized
INFO - 2018-07-04 01:55:13 --> Controller Class Initialized
INFO - 2018-07-04 01:55:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 01:55:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 01:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 01:55:13 --> Final output sent to browser
DEBUG - 2018-07-04 01:55:13 --> Total execution time: 0.0212
INFO - 2018-07-04 02:16:45 --> Config Class Initialized
INFO - 2018-07-04 02:16:45 --> Hooks Class Initialized
DEBUG - 2018-07-04 02:16:45 --> UTF-8 Support Enabled
INFO - 2018-07-04 02:16:45 --> Utf8 Class Initialized
INFO - 2018-07-04 02:16:45 --> URI Class Initialized
INFO - 2018-07-04 02:16:45 --> Router Class Initialized
INFO - 2018-07-04 02:16:45 --> Output Class Initialized
INFO - 2018-07-04 02:16:45 --> Security Class Initialized
DEBUG - 2018-07-04 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 02:16:45 --> CSRF cookie sent
INFO - 2018-07-04 02:16:45 --> Input Class Initialized
INFO - 2018-07-04 02:16:45 --> Language Class Initialized
INFO - 2018-07-04 02:16:45 --> Loader Class Initialized
INFO - 2018-07-04 02:16:45 --> Helper loaded: url_helper
INFO - 2018-07-04 02:16:45 --> Helper loaded: form_helper
INFO - 2018-07-04 02:16:45 --> Helper loaded: language_helper
DEBUG - 2018-07-04 02:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 02:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 02:16:45 --> User Agent Class Initialized
INFO - 2018-07-04 02:16:45 --> Controller Class Initialized
INFO - 2018-07-04 02:16:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 02:16:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 02:16:45 --> Pixel_Model class loaded
INFO - 2018-07-04 02:16:45 --> Database Driver Class Initialized
INFO - 2018-07-04 02:16:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-04 02:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 02:16:45 --> Final output sent to browser
DEBUG - 2018-07-04 02:16:45 --> Total execution time: 0.0360
INFO - 2018-07-04 02:28:33 --> Config Class Initialized
INFO - 2018-07-04 02:28:33 --> Hooks Class Initialized
DEBUG - 2018-07-04 02:28:33 --> UTF-8 Support Enabled
INFO - 2018-07-04 02:28:33 --> Utf8 Class Initialized
INFO - 2018-07-04 02:28:33 --> URI Class Initialized
INFO - 2018-07-04 02:28:33 --> Router Class Initialized
INFO - 2018-07-04 02:28:33 --> Output Class Initialized
INFO - 2018-07-04 02:28:33 --> Security Class Initialized
DEBUG - 2018-07-04 02:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 02:28:33 --> CSRF cookie sent
INFO - 2018-07-04 02:28:33 --> Input Class Initialized
INFO - 2018-07-04 02:28:33 --> Language Class Initialized
INFO - 2018-07-04 02:28:33 --> Loader Class Initialized
INFO - 2018-07-04 02:28:33 --> Helper loaded: url_helper
INFO - 2018-07-04 02:28:33 --> Helper loaded: form_helper
INFO - 2018-07-04 02:28:33 --> Helper loaded: language_helper
DEBUG - 2018-07-04 02:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 02:28:33 --> User Agent Class Initialized
INFO - 2018-07-04 02:28:33 --> Controller Class Initialized
INFO - 2018-07-04 02:28:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 02:28:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 02:28:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 02:28:33 --> Final output sent to browser
DEBUG - 2018-07-04 02:28:33 --> Total execution time: 0.0209
INFO - 2018-07-04 03:01:55 --> Config Class Initialized
INFO - 2018-07-04 03:01:55 --> Hooks Class Initialized
DEBUG - 2018-07-04 03:01:55 --> UTF-8 Support Enabled
INFO - 2018-07-04 03:01:55 --> Utf8 Class Initialized
INFO - 2018-07-04 03:01:55 --> URI Class Initialized
DEBUG - 2018-07-04 03:01:55 --> No URI present. Default controller set.
INFO - 2018-07-04 03:01:55 --> Router Class Initialized
INFO - 2018-07-04 03:01:55 --> Output Class Initialized
INFO - 2018-07-04 03:01:55 --> Security Class Initialized
DEBUG - 2018-07-04 03:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 03:01:55 --> CSRF cookie sent
INFO - 2018-07-04 03:01:55 --> Input Class Initialized
INFO - 2018-07-04 03:01:55 --> Language Class Initialized
INFO - 2018-07-04 03:01:55 --> Loader Class Initialized
INFO - 2018-07-04 03:01:55 --> Helper loaded: url_helper
INFO - 2018-07-04 03:01:55 --> Helper loaded: form_helper
INFO - 2018-07-04 03:01:55 --> Helper loaded: language_helper
DEBUG - 2018-07-04 03:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 03:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 03:01:55 --> User Agent Class Initialized
INFO - 2018-07-04 03:01:55 --> Controller Class Initialized
INFO - 2018-07-04 03:01:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 03:01:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 03:01:55 --> Pixel_Model class loaded
INFO - 2018-07-04 03:01:55 --> Database Driver Class Initialized
INFO - 2018-07-04 03:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 03:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 03:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 03:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 03:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 03:01:55 --> Final output sent to browser
DEBUG - 2018-07-04 03:01:55 --> Total execution time: 0.0323
INFO - 2018-07-04 03:35:13 --> Config Class Initialized
INFO - 2018-07-04 03:35:13 --> Hooks Class Initialized
DEBUG - 2018-07-04 03:35:13 --> UTF-8 Support Enabled
INFO - 2018-07-04 03:35:13 --> Utf8 Class Initialized
INFO - 2018-07-04 03:35:13 --> URI Class Initialized
INFO - 2018-07-04 03:35:13 --> Router Class Initialized
INFO - 2018-07-04 03:35:13 --> Output Class Initialized
INFO - 2018-07-04 03:35:13 --> Security Class Initialized
DEBUG - 2018-07-04 03:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 03:35:13 --> CSRF cookie sent
INFO - 2018-07-04 03:35:13 --> Input Class Initialized
INFO - 2018-07-04 03:35:13 --> Language Class Initialized
INFO - 2018-07-04 03:35:13 --> Loader Class Initialized
INFO - 2018-07-04 03:35:13 --> Helper loaded: url_helper
INFO - 2018-07-04 03:35:13 --> Helper loaded: form_helper
INFO - 2018-07-04 03:35:13 --> Helper loaded: language_helper
DEBUG - 2018-07-04 03:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 03:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 03:35:13 --> User Agent Class Initialized
INFO - 2018-07-04 03:35:13 --> Controller Class Initialized
INFO - 2018-07-04 03:35:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 03:35:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 03:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 03:35:13 --> Final output sent to browser
DEBUG - 2018-07-04 03:35:13 --> Total execution time: 0.0210
INFO - 2018-07-04 04:08:33 --> Config Class Initialized
INFO - 2018-07-04 04:08:33 --> Hooks Class Initialized
DEBUG - 2018-07-04 04:08:33 --> UTF-8 Support Enabled
INFO - 2018-07-04 04:08:33 --> Utf8 Class Initialized
INFO - 2018-07-04 04:08:33 --> URI Class Initialized
INFO - 2018-07-04 04:08:33 --> Router Class Initialized
INFO - 2018-07-04 04:08:33 --> Output Class Initialized
INFO - 2018-07-04 04:08:33 --> Security Class Initialized
DEBUG - 2018-07-04 04:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 04:08:33 --> CSRF cookie sent
INFO - 2018-07-04 04:08:33 --> Input Class Initialized
INFO - 2018-07-04 04:08:33 --> Language Class Initialized
INFO - 2018-07-04 04:08:33 --> Loader Class Initialized
INFO - 2018-07-04 04:08:33 --> Helper loaded: url_helper
INFO - 2018-07-04 04:08:33 --> Helper loaded: form_helper
INFO - 2018-07-04 04:08:33 --> Helper loaded: language_helper
DEBUG - 2018-07-04 04:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 04:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 04:08:33 --> User Agent Class Initialized
INFO - 2018-07-04 04:08:33 --> Controller Class Initialized
INFO - 2018-07-04 04:08:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 04:08:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 04:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 04:08:33 --> Final output sent to browser
DEBUG - 2018-07-04 04:08:33 --> Total execution time: 0.0249
INFO - 2018-07-04 04:41:55 --> Config Class Initialized
INFO - 2018-07-04 04:41:55 --> Hooks Class Initialized
DEBUG - 2018-07-04 04:41:55 --> UTF-8 Support Enabled
INFO - 2018-07-04 04:41:55 --> Utf8 Class Initialized
INFO - 2018-07-04 04:41:55 --> URI Class Initialized
INFO - 2018-07-04 04:41:55 --> Router Class Initialized
INFO - 2018-07-04 04:41:55 --> Output Class Initialized
INFO - 2018-07-04 04:41:55 --> Security Class Initialized
DEBUG - 2018-07-04 04:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 04:41:55 --> CSRF cookie sent
INFO - 2018-07-04 04:41:55 --> Input Class Initialized
INFO - 2018-07-04 04:41:55 --> Language Class Initialized
INFO - 2018-07-04 04:41:55 --> Loader Class Initialized
INFO - 2018-07-04 04:41:55 --> Helper loaded: url_helper
INFO - 2018-07-04 04:41:55 --> Helper loaded: form_helper
INFO - 2018-07-04 04:41:55 --> Helper loaded: language_helper
DEBUG - 2018-07-04 04:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 04:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 04:41:55 --> User Agent Class Initialized
INFO - 2018-07-04 04:41:55 --> Controller Class Initialized
INFO - 2018-07-04 04:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 04:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 04:41:55 --> Pixel_Model class loaded
INFO - 2018-07-04 04:41:55 --> Database Driver Class Initialized
INFO - 2018-07-04 04:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 04:41:56 --> Config Class Initialized
INFO - 2018-07-04 04:41:56 --> Hooks Class Initialized
DEBUG - 2018-07-04 04:41:56 --> UTF-8 Support Enabled
INFO - 2018-07-04 04:41:56 --> Utf8 Class Initialized
INFO - 2018-07-04 04:41:56 --> URI Class Initialized
INFO - 2018-07-04 04:41:56 --> Router Class Initialized
INFO - 2018-07-04 04:41:56 --> Output Class Initialized
INFO - 2018-07-04 04:41:56 --> Security Class Initialized
DEBUG - 2018-07-04 04:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 04:41:56 --> CSRF cookie sent
INFO - 2018-07-04 04:41:56 --> Input Class Initialized
INFO - 2018-07-04 04:41:56 --> Language Class Initialized
INFO - 2018-07-04 04:41:56 --> Loader Class Initialized
INFO - 2018-07-04 04:41:56 --> Helper loaded: url_helper
INFO - 2018-07-04 04:41:56 --> Helper loaded: form_helper
INFO - 2018-07-04 04:41:56 --> Helper loaded: language_helper
DEBUG - 2018-07-04 04:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 04:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 04:41:56 --> User Agent Class Initialized
INFO - 2018-07-04 04:41:56 --> Controller Class Initialized
INFO - 2018-07-04 04:41:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 04:41:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 04:41:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 04:41:56 --> Could not find the language line "req_email"
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 04:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 04:41:56 --> Final output sent to browser
DEBUG - 2018-07-04 04:41:56 --> Total execution time: 0.0372
INFO - 2018-07-04 07:50:56 --> Config Class Initialized
INFO - 2018-07-04 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-04 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-04 07:50:56 --> Utf8 Class Initialized
INFO - 2018-07-04 07:50:56 --> URI Class Initialized
DEBUG - 2018-07-04 07:50:56 --> No URI present. Default controller set.
INFO - 2018-07-04 07:50:56 --> Router Class Initialized
INFO - 2018-07-04 07:50:56 --> Output Class Initialized
INFO - 2018-07-04 07:50:56 --> Security Class Initialized
DEBUG - 2018-07-04 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 07:50:56 --> CSRF cookie sent
INFO - 2018-07-04 07:50:56 --> Input Class Initialized
INFO - 2018-07-04 07:50:56 --> Language Class Initialized
INFO - 2018-07-04 07:50:56 --> Loader Class Initialized
INFO - 2018-07-04 07:50:56 --> Helper loaded: url_helper
INFO - 2018-07-04 07:50:56 --> Helper loaded: form_helper
INFO - 2018-07-04 07:50:56 --> Helper loaded: language_helper
DEBUG - 2018-07-04 07:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 07:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 07:50:56 --> User Agent Class Initialized
INFO - 2018-07-04 07:50:56 --> Controller Class Initialized
INFO - 2018-07-04 07:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 07:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 07:50:56 --> Pixel_Model class loaded
INFO - 2018-07-04 07:50:56 --> Database Driver Class Initialized
INFO - 2018-07-04 07:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 07:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 07:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 07:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 07:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 07:50:56 --> Final output sent to browser
DEBUG - 2018-07-04 07:50:56 --> Total execution time: 0.0341
INFO - 2018-07-04 10:08:43 --> Config Class Initialized
INFO - 2018-07-04 10:08:43 --> Hooks Class Initialized
DEBUG - 2018-07-04 10:08:43 --> UTF-8 Support Enabled
INFO - 2018-07-04 10:08:43 --> Utf8 Class Initialized
INFO - 2018-07-04 10:08:43 --> URI Class Initialized
INFO - 2018-07-04 10:08:43 --> Router Class Initialized
INFO - 2018-07-04 10:08:43 --> Output Class Initialized
INFO - 2018-07-04 10:08:43 --> Security Class Initialized
DEBUG - 2018-07-04 10:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 10:08:43 --> CSRF cookie sent
INFO - 2018-07-04 10:08:43 --> Input Class Initialized
INFO - 2018-07-04 10:08:43 --> Language Class Initialized
INFO - 2018-07-04 10:08:43 --> Loader Class Initialized
INFO - 2018-07-04 10:08:43 --> Helper loaded: url_helper
INFO - 2018-07-04 10:08:43 --> Helper loaded: form_helper
INFO - 2018-07-04 10:08:43 --> Helper loaded: language_helper
DEBUG - 2018-07-04 10:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 10:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 10:08:43 --> User Agent Class Initialized
INFO - 2018-07-04 10:08:43 --> Controller Class Initialized
INFO - 2018-07-04 10:08:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 10:08:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 10:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 10:08:43 --> Final output sent to browser
DEBUG - 2018-07-04 10:08:43 --> Total execution time: 0.0259
INFO - 2018-07-04 10:37:21 --> Config Class Initialized
INFO - 2018-07-04 10:37:21 --> Hooks Class Initialized
DEBUG - 2018-07-04 10:37:21 --> UTF-8 Support Enabled
INFO - 2018-07-04 10:37:21 --> Utf8 Class Initialized
INFO - 2018-07-04 10:37:21 --> URI Class Initialized
DEBUG - 2018-07-04 10:37:21 --> No URI present. Default controller set.
INFO - 2018-07-04 10:37:21 --> Router Class Initialized
INFO - 2018-07-04 10:37:21 --> Output Class Initialized
INFO - 2018-07-04 10:37:21 --> Security Class Initialized
DEBUG - 2018-07-04 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 10:37:21 --> CSRF cookie sent
INFO - 2018-07-04 10:37:21 --> Input Class Initialized
INFO - 2018-07-04 10:37:21 --> Language Class Initialized
INFO - 2018-07-04 10:37:21 --> Loader Class Initialized
INFO - 2018-07-04 10:37:21 --> Helper loaded: url_helper
INFO - 2018-07-04 10:37:21 --> Helper loaded: form_helper
INFO - 2018-07-04 10:37:21 --> Helper loaded: language_helper
DEBUG - 2018-07-04 10:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 10:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 10:37:21 --> User Agent Class Initialized
INFO - 2018-07-04 10:37:21 --> Controller Class Initialized
INFO - 2018-07-04 10:37:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 10:37:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 10:37:21 --> Pixel_Model class loaded
INFO - 2018-07-04 10:37:21 --> Database Driver Class Initialized
INFO - 2018-07-04 10:37:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 10:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 10:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 10:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 10:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 10:37:21 --> Final output sent to browser
DEBUG - 2018-07-04 10:37:21 --> Total execution time: 0.0344
INFO - 2018-07-04 10:39:22 --> Config Class Initialized
INFO - 2018-07-04 10:39:22 --> Hooks Class Initialized
DEBUG - 2018-07-04 10:39:22 --> UTF-8 Support Enabled
INFO - 2018-07-04 10:39:22 --> Utf8 Class Initialized
INFO - 2018-07-04 10:39:22 --> URI Class Initialized
INFO - 2018-07-04 10:39:22 --> Router Class Initialized
INFO - 2018-07-04 10:39:22 --> Output Class Initialized
INFO - 2018-07-04 10:39:22 --> Security Class Initialized
DEBUG - 2018-07-04 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 10:39:22 --> CSRF cookie sent
INFO - 2018-07-04 10:39:22 --> Input Class Initialized
INFO - 2018-07-04 10:39:22 --> Language Class Initialized
INFO - 2018-07-04 10:39:22 --> Loader Class Initialized
INFO - 2018-07-04 10:39:22 --> Helper loaded: url_helper
INFO - 2018-07-04 10:39:22 --> Helper loaded: form_helper
INFO - 2018-07-04 10:39:22 --> Helper loaded: language_helper
DEBUG - 2018-07-04 10:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 10:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 10:39:22 --> User Agent Class Initialized
INFO - 2018-07-04 10:39:22 --> Controller Class Initialized
INFO - 2018-07-04 10:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 10:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 10:39:22 --> Pixel_Model class loaded
INFO - 2018-07-04 10:39:22 --> Database Driver Class Initialized
INFO - 2018-07-04 10:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 10:39:23 --> Config Class Initialized
INFO - 2018-07-04 10:39:23 --> Hooks Class Initialized
DEBUG - 2018-07-04 10:39:23 --> UTF-8 Support Enabled
INFO - 2018-07-04 10:39:23 --> Utf8 Class Initialized
INFO - 2018-07-04 10:39:23 --> URI Class Initialized
INFO - 2018-07-04 10:39:23 --> Router Class Initialized
INFO - 2018-07-04 10:39:23 --> Output Class Initialized
INFO - 2018-07-04 10:39:23 --> Security Class Initialized
DEBUG - 2018-07-04 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 10:39:23 --> CSRF cookie sent
INFO - 2018-07-04 10:39:23 --> Input Class Initialized
INFO - 2018-07-04 10:39:23 --> Language Class Initialized
INFO - 2018-07-04 10:39:23 --> Loader Class Initialized
INFO - 2018-07-04 10:39:23 --> Helper loaded: url_helper
INFO - 2018-07-04 10:39:23 --> Helper loaded: form_helper
INFO - 2018-07-04 10:39:23 --> Helper loaded: language_helper
DEBUG - 2018-07-04 10:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 10:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 10:39:23 --> User Agent Class Initialized
INFO - 2018-07-04 10:39:23 --> Controller Class Initialized
INFO - 2018-07-04 10:39:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 10:39:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 10:39:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 10:39:23 --> Could not find the language line "req_email"
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 10:39:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 10:39:23 --> Final output sent to browser
DEBUG - 2018-07-04 10:39:23 --> Total execution time: 0.0223
INFO - 2018-07-04 11:12:39 --> Config Class Initialized
INFO - 2018-07-04 11:12:39 --> Hooks Class Initialized
DEBUG - 2018-07-04 11:12:39 --> UTF-8 Support Enabled
INFO - 2018-07-04 11:12:39 --> Utf8 Class Initialized
INFO - 2018-07-04 11:12:39 --> URI Class Initialized
DEBUG - 2018-07-04 11:12:39 --> No URI present. Default controller set.
INFO - 2018-07-04 11:12:39 --> Router Class Initialized
INFO - 2018-07-04 11:12:39 --> Output Class Initialized
INFO - 2018-07-04 11:12:39 --> Security Class Initialized
DEBUG - 2018-07-04 11:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 11:12:39 --> CSRF cookie sent
INFO - 2018-07-04 11:12:39 --> Input Class Initialized
INFO - 2018-07-04 11:12:39 --> Language Class Initialized
INFO - 2018-07-04 11:12:39 --> Loader Class Initialized
INFO - 2018-07-04 11:12:39 --> Helper loaded: url_helper
INFO - 2018-07-04 11:12:39 --> Helper loaded: form_helper
INFO - 2018-07-04 11:12:39 --> Helper loaded: language_helper
DEBUG - 2018-07-04 11:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 11:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 11:12:39 --> User Agent Class Initialized
INFO - 2018-07-04 11:12:39 --> Controller Class Initialized
INFO - 2018-07-04 11:12:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 11:12:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 11:12:39 --> Pixel_Model class loaded
INFO - 2018-07-04 11:12:39 --> Database Driver Class Initialized
INFO - 2018-07-04 11:12:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 11:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 11:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 11:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 11:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 11:12:39 --> Final output sent to browser
DEBUG - 2018-07-04 11:12:39 --> Total execution time: 0.0326
INFO - 2018-07-04 11:12:41 --> Config Class Initialized
INFO - 2018-07-04 11:12:41 --> Hooks Class Initialized
DEBUG - 2018-07-04 11:12:41 --> UTF-8 Support Enabled
INFO - 2018-07-04 11:12:41 --> Utf8 Class Initialized
INFO - 2018-07-04 11:12:41 --> URI Class Initialized
INFO - 2018-07-04 11:12:41 --> Router Class Initialized
INFO - 2018-07-04 11:12:41 --> Output Class Initialized
INFO - 2018-07-04 11:12:41 --> Security Class Initialized
DEBUG - 2018-07-04 11:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 11:12:41 --> CSRF cookie sent
INFO - 2018-07-04 11:12:41 --> Input Class Initialized
INFO - 2018-07-04 11:12:41 --> Language Class Initialized
INFO - 2018-07-04 11:12:41 --> Loader Class Initialized
INFO - 2018-07-04 11:12:41 --> Helper loaded: url_helper
INFO - 2018-07-04 11:12:41 --> Helper loaded: form_helper
INFO - 2018-07-04 11:12:41 --> Helper loaded: language_helper
DEBUG - 2018-07-04 11:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 11:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 11:12:41 --> User Agent Class Initialized
INFO - 2018-07-04 11:12:41 --> Controller Class Initialized
INFO - 2018-07-04 11:12:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 11:12:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 11:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 11:12:41 --> Final output sent to browser
DEBUG - 2018-07-04 11:12:41 --> Total execution time: 0.0227
INFO - 2018-07-04 11:46:01 --> Config Class Initialized
INFO - 2018-07-04 11:46:01 --> Hooks Class Initialized
DEBUG - 2018-07-04 11:46:01 --> UTF-8 Support Enabled
INFO - 2018-07-04 11:46:01 --> Utf8 Class Initialized
INFO - 2018-07-04 11:46:01 --> URI Class Initialized
DEBUG - 2018-07-04 11:46:01 --> No URI present. Default controller set.
INFO - 2018-07-04 11:46:01 --> Router Class Initialized
INFO - 2018-07-04 11:46:01 --> Output Class Initialized
INFO - 2018-07-04 11:46:01 --> Security Class Initialized
DEBUG - 2018-07-04 11:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 11:46:01 --> CSRF cookie sent
INFO - 2018-07-04 11:46:01 --> Input Class Initialized
INFO - 2018-07-04 11:46:01 --> Language Class Initialized
INFO - 2018-07-04 11:46:01 --> Loader Class Initialized
INFO - 2018-07-04 11:46:01 --> Helper loaded: url_helper
INFO - 2018-07-04 11:46:01 --> Helper loaded: form_helper
INFO - 2018-07-04 11:46:01 --> Helper loaded: language_helper
DEBUG - 2018-07-04 11:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 11:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 11:46:01 --> User Agent Class Initialized
INFO - 2018-07-04 11:46:01 --> Controller Class Initialized
INFO - 2018-07-04 11:46:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 11:46:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 11:46:01 --> Pixel_Model class loaded
INFO - 2018-07-04 11:46:01 --> Database Driver Class Initialized
INFO - 2018-07-04 11:46:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 11:46:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 11:46:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 11:46:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 11:46:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 11:46:01 --> Final output sent to browser
DEBUG - 2018-07-04 11:46:01 --> Total execution time: 0.0389
INFO - 2018-07-04 12:19:21 --> Config Class Initialized
INFO - 2018-07-04 12:19:21 --> Hooks Class Initialized
DEBUG - 2018-07-04 12:19:21 --> UTF-8 Support Enabled
INFO - 2018-07-04 12:19:21 --> Utf8 Class Initialized
INFO - 2018-07-04 12:19:21 --> URI Class Initialized
INFO - 2018-07-04 12:19:21 --> Router Class Initialized
INFO - 2018-07-04 12:19:21 --> Output Class Initialized
INFO - 2018-07-04 12:19:21 --> Security Class Initialized
DEBUG - 2018-07-04 12:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 12:19:21 --> CSRF cookie sent
INFO - 2018-07-04 12:19:21 --> Input Class Initialized
INFO - 2018-07-04 12:19:21 --> Language Class Initialized
INFO - 2018-07-04 12:19:21 --> Loader Class Initialized
INFO - 2018-07-04 12:19:21 --> Helper loaded: url_helper
INFO - 2018-07-04 12:19:21 --> Helper loaded: form_helper
INFO - 2018-07-04 12:19:21 --> Helper loaded: language_helper
DEBUG - 2018-07-04 12:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 12:19:21 --> User Agent Class Initialized
INFO - 2018-07-04 12:19:21 --> Controller Class Initialized
INFO - 2018-07-04 12:19:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 12:19:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 12:19:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 12:19:21 --> Final output sent to browser
DEBUG - 2018-07-04 12:19:21 --> Total execution time: 0.0217
INFO - 2018-07-04 12:52:41 --> Config Class Initialized
INFO - 2018-07-04 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-07-04 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-07-04 12:52:41 --> Utf8 Class Initialized
INFO - 2018-07-04 12:52:41 --> URI Class Initialized
INFO - 2018-07-04 12:52:41 --> Router Class Initialized
INFO - 2018-07-04 12:52:41 --> Output Class Initialized
INFO - 2018-07-04 12:52:41 --> Security Class Initialized
DEBUG - 2018-07-04 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 12:52:41 --> CSRF cookie sent
INFO - 2018-07-04 12:52:41 --> Input Class Initialized
INFO - 2018-07-04 12:52:41 --> Language Class Initialized
INFO - 2018-07-04 12:52:41 --> Loader Class Initialized
INFO - 2018-07-04 12:52:41 --> Helper loaded: url_helper
INFO - 2018-07-04 12:52:41 --> Helper loaded: form_helper
INFO - 2018-07-04 12:52:41 --> Helper loaded: language_helper
DEBUG - 2018-07-04 12:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 12:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 12:52:41 --> User Agent Class Initialized
INFO - 2018-07-04 12:52:41 --> Controller Class Initialized
INFO - 2018-07-04 12:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 12:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 12:52:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 12:52:41 --> Final output sent to browser
DEBUG - 2018-07-04 12:52:41 --> Total execution time: 0.0193
INFO - 2018-07-04 13:22:17 --> Config Class Initialized
INFO - 2018-07-04 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-07-04 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-07-04 13:22:17 --> Utf8 Class Initialized
INFO - 2018-07-04 13:22:17 --> URI Class Initialized
INFO - 2018-07-04 13:22:17 --> Router Class Initialized
INFO - 2018-07-04 13:22:17 --> Output Class Initialized
INFO - 2018-07-04 13:22:17 --> Security Class Initialized
DEBUG - 2018-07-04 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 13:22:17 --> CSRF cookie sent
INFO - 2018-07-04 13:22:17 --> Input Class Initialized
INFO - 2018-07-04 13:22:17 --> Language Class Initialized
ERROR - 2018-07-04 13:22:17 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 13:22:20 --> Config Class Initialized
INFO - 2018-07-04 13:22:20 --> Hooks Class Initialized
DEBUG - 2018-07-04 13:22:20 --> UTF-8 Support Enabled
INFO - 2018-07-04 13:22:20 --> Utf8 Class Initialized
INFO - 2018-07-04 13:22:20 --> URI Class Initialized
INFO - 2018-07-04 13:22:20 --> Router Class Initialized
INFO - 2018-07-04 13:22:20 --> Output Class Initialized
INFO - 2018-07-04 13:22:20 --> Security Class Initialized
DEBUG - 2018-07-04 13:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 13:22:20 --> CSRF cookie sent
INFO - 2018-07-04 13:22:20 --> Input Class Initialized
INFO - 2018-07-04 13:22:20 --> Language Class Initialized
INFO - 2018-07-04 13:22:20 --> Loader Class Initialized
INFO - 2018-07-04 13:22:20 --> Helper loaded: url_helper
INFO - 2018-07-04 13:22:20 --> Helper loaded: form_helper
INFO - 2018-07-04 13:22:20 --> Helper loaded: language_helper
DEBUG - 2018-07-04 13:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 13:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 13:22:20 --> User Agent Class Initialized
INFO - 2018-07-04 13:22:20 --> Controller Class Initialized
INFO - 2018-07-04 13:22:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 13:22:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 13:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 13:22:20 --> Final output sent to browser
DEBUG - 2018-07-04 13:22:20 --> Total execution time: 0.0234
INFO - 2018-07-04 13:29:12 --> Config Class Initialized
INFO - 2018-07-04 13:29:12 --> Hooks Class Initialized
DEBUG - 2018-07-04 13:29:12 --> UTF-8 Support Enabled
INFO - 2018-07-04 13:29:12 --> Utf8 Class Initialized
INFO - 2018-07-04 13:29:12 --> URI Class Initialized
INFO - 2018-07-04 13:29:12 --> Router Class Initialized
INFO - 2018-07-04 13:29:12 --> Output Class Initialized
INFO - 2018-07-04 13:29:12 --> Security Class Initialized
DEBUG - 2018-07-04 13:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 13:29:12 --> CSRF cookie sent
INFO - 2018-07-04 13:29:12 --> Input Class Initialized
INFO - 2018-07-04 13:29:12 --> Language Class Initialized
INFO - 2018-07-04 13:29:12 --> Loader Class Initialized
INFO - 2018-07-04 13:29:12 --> Helper loaded: url_helper
INFO - 2018-07-04 13:29:12 --> Helper loaded: form_helper
INFO - 2018-07-04 13:29:12 --> Helper loaded: language_helper
DEBUG - 2018-07-04 13:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 13:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 13:29:12 --> User Agent Class Initialized
INFO - 2018-07-04 13:29:12 --> Controller Class Initialized
INFO - 2018-07-04 13:29:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 13:29:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 13:29:12 --> Pixel_Model class loaded
INFO - 2018-07-04 13:29:12 --> Database Driver Class Initialized
INFO - 2018-07-04 13:29:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 13:29:15 --> Config Class Initialized
INFO - 2018-07-04 13:29:15 --> Hooks Class Initialized
DEBUG - 2018-07-04 13:29:15 --> UTF-8 Support Enabled
INFO - 2018-07-04 13:29:15 --> Utf8 Class Initialized
INFO - 2018-07-04 13:29:15 --> URI Class Initialized
INFO - 2018-07-04 13:29:15 --> Router Class Initialized
INFO - 2018-07-04 13:29:15 --> Output Class Initialized
INFO - 2018-07-04 13:29:15 --> Security Class Initialized
DEBUG - 2018-07-04 13:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 13:29:15 --> CSRF cookie sent
INFO - 2018-07-04 13:29:15 --> Input Class Initialized
INFO - 2018-07-04 13:29:15 --> Language Class Initialized
INFO - 2018-07-04 13:29:15 --> Loader Class Initialized
INFO - 2018-07-04 13:29:15 --> Helper loaded: url_helper
INFO - 2018-07-04 13:29:15 --> Helper loaded: form_helper
INFO - 2018-07-04 13:29:15 --> Helper loaded: language_helper
DEBUG - 2018-07-04 13:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 13:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 13:29:15 --> User Agent Class Initialized
INFO - 2018-07-04 13:29:15 --> Controller Class Initialized
INFO - 2018-07-04 13:29:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 13:29:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 13:29:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 13:29:15 --> Could not find the language line "req_email"
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 13:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 13:29:15 --> Final output sent to browser
DEBUG - 2018-07-04 13:29:15 --> Total execution time: 0.0217
INFO - 2018-07-04 14:05:41 --> Config Class Initialized
INFO - 2018-07-04 14:05:41 --> Hooks Class Initialized
DEBUG - 2018-07-04 14:05:41 --> UTF-8 Support Enabled
INFO - 2018-07-04 14:05:41 --> Utf8 Class Initialized
INFO - 2018-07-04 14:05:41 --> URI Class Initialized
DEBUG - 2018-07-04 14:05:41 --> No URI present. Default controller set.
INFO - 2018-07-04 14:05:41 --> Router Class Initialized
INFO - 2018-07-04 14:05:41 --> Output Class Initialized
INFO - 2018-07-04 14:05:41 --> Security Class Initialized
DEBUG - 2018-07-04 14:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 14:05:41 --> CSRF cookie sent
INFO - 2018-07-04 14:05:41 --> Input Class Initialized
INFO - 2018-07-04 14:05:41 --> Language Class Initialized
INFO - 2018-07-04 14:05:41 --> Loader Class Initialized
INFO - 2018-07-04 14:05:41 --> Helper loaded: url_helper
INFO - 2018-07-04 14:05:41 --> Helper loaded: form_helper
INFO - 2018-07-04 14:05:41 --> Helper loaded: language_helper
DEBUG - 2018-07-04 14:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 14:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 14:05:41 --> User Agent Class Initialized
INFO - 2018-07-04 14:05:41 --> Controller Class Initialized
INFO - 2018-07-04 14:05:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 14:05:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 14:05:41 --> Pixel_Model class loaded
INFO - 2018-07-04 14:05:41 --> Database Driver Class Initialized
INFO - 2018-07-04 14:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 14:05:41 --> Final output sent to browser
DEBUG - 2018-07-04 14:05:41 --> Total execution time: 0.0334
INFO - 2018-07-04 14:42:12 --> Config Class Initialized
INFO - 2018-07-04 14:42:12 --> Hooks Class Initialized
DEBUG - 2018-07-04 14:42:12 --> UTF-8 Support Enabled
INFO - 2018-07-04 14:42:12 --> Utf8 Class Initialized
INFO - 2018-07-04 14:42:12 --> URI Class Initialized
INFO - 2018-07-04 14:42:12 --> Router Class Initialized
INFO - 2018-07-04 14:42:12 --> Output Class Initialized
INFO - 2018-07-04 14:42:12 --> Security Class Initialized
DEBUG - 2018-07-04 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 14:42:12 --> CSRF cookie sent
INFO - 2018-07-04 14:42:12 --> Input Class Initialized
INFO - 2018-07-04 14:42:12 --> Language Class Initialized
INFO - 2018-07-04 14:42:12 --> Loader Class Initialized
INFO - 2018-07-04 14:42:12 --> Helper loaded: url_helper
INFO - 2018-07-04 14:42:12 --> Helper loaded: form_helper
INFO - 2018-07-04 14:42:12 --> Helper loaded: language_helper
DEBUG - 2018-07-04 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 14:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 14:42:12 --> User Agent Class Initialized
INFO - 2018-07-04 14:42:12 --> Controller Class Initialized
INFO - 2018-07-04 14:42:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 14:42:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 14:42:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 14:42:12 --> Could not find the language line "req_email"
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 14:42:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 14:42:12 --> Final output sent to browser
DEBUG - 2018-07-04 14:42:12 --> Total execution time: 0.0257
INFO - 2018-07-04 15:25:53 --> Config Class Initialized
INFO - 2018-07-04 15:25:53 --> Hooks Class Initialized
DEBUG - 2018-07-04 15:25:53 --> UTF-8 Support Enabled
INFO - 2018-07-04 15:25:53 --> Utf8 Class Initialized
INFO - 2018-07-04 15:25:53 --> URI Class Initialized
INFO - 2018-07-04 15:25:53 --> Router Class Initialized
INFO - 2018-07-04 15:25:53 --> Output Class Initialized
INFO - 2018-07-04 15:25:53 --> Security Class Initialized
DEBUG - 2018-07-04 15:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 15:25:53 --> CSRF cookie sent
INFO - 2018-07-04 15:25:53 --> Input Class Initialized
INFO - 2018-07-04 15:25:53 --> Language Class Initialized
INFO - 2018-07-04 15:25:53 --> Loader Class Initialized
INFO - 2018-07-04 15:25:53 --> Helper loaded: url_helper
INFO - 2018-07-04 15:25:53 --> Helper loaded: form_helper
INFO - 2018-07-04 15:25:53 --> Helper loaded: language_helper
DEBUG - 2018-07-04 15:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 15:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 15:25:53 --> User Agent Class Initialized
INFO - 2018-07-04 15:25:53 --> Controller Class Initialized
INFO - 2018-07-04 15:25:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 15:25:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 15:25:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 15:25:53 --> Could not find the language line "req_email"
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 15:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 15:25:53 --> Final output sent to browser
DEBUG - 2018-07-04 15:25:53 --> Total execution time: 0.0204
INFO - 2018-07-04 16:59:23 --> Config Class Initialized
INFO - 2018-07-04 16:59:23 --> Hooks Class Initialized
DEBUG - 2018-07-04 16:59:23 --> UTF-8 Support Enabled
INFO - 2018-07-04 16:59:23 --> Utf8 Class Initialized
INFO - 2018-07-04 16:59:23 --> URI Class Initialized
INFO - 2018-07-04 16:59:23 --> Router Class Initialized
INFO - 2018-07-04 16:59:23 --> Output Class Initialized
INFO - 2018-07-04 16:59:23 --> Security Class Initialized
DEBUG - 2018-07-04 16:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 16:59:23 --> CSRF cookie sent
INFO - 2018-07-04 16:59:23 --> Input Class Initialized
INFO - 2018-07-04 16:59:23 --> Language Class Initialized
ERROR - 2018-07-04 16:59:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 17:16:58 --> Config Class Initialized
INFO - 2018-07-04 17:16:58 --> Hooks Class Initialized
DEBUG - 2018-07-04 17:16:58 --> UTF-8 Support Enabled
INFO - 2018-07-04 17:16:58 --> Utf8 Class Initialized
INFO - 2018-07-04 17:16:58 --> URI Class Initialized
INFO - 2018-07-04 17:16:58 --> Router Class Initialized
INFO - 2018-07-04 17:16:58 --> Output Class Initialized
INFO - 2018-07-04 17:16:58 --> Security Class Initialized
DEBUG - 2018-07-04 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 17:16:58 --> CSRF cookie sent
INFO - 2018-07-04 17:16:58 --> Input Class Initialized
INFO - 2018-07-04 17:16:58 --> Language Class Initialized
INFO - 2018-07-04 17:16:58 --> Loader Class Initialized
INFO - 2018-07-04 17:16:58 --> Helper loaded: url_helper
INFO - 2018-07-04 17:16:58 --> Helper loaded: form_helper
INFO - 2018-07-04 17:16:58 --> Helper loaded: language_helper
DEBUG - 2018-07-04 17:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 17:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 17:16:58 --> User Agent Class Initialized
INFO - 2018-07-04 17:16:58 --> Controller Class Initialized
INFO - 2018-07-04 17:16:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 17:16:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 17:16:58 --> Pixel_Model class loaded
INFO - 2018-07-04 17:16:58 --> Database Driver Class Initialized
INFO - 2018-07-04 17:16:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 17:29:18 --> Config Class Initialized
INFO - 2018-07-04 17:29:18 --> Hooks Class Initialized
DEBUG - 2018-07-04 17:29:18 --> UTF-8 Support Enabled
INFO - 2018-07-04 17:29:18 --> Utf8 Class Initialized
INFO - 2018-07-04 17:29:18 --> URI Class Initialized
INFO - 2018-07-04 17:29:18 --> Router Class Initialized
INFO - 2018-07-04 17:29:18 --> Output Class Initialized
INFO - 2018-07-04 17:29:18 --> Security Class Initialized
DEBUG - 2018-07-04 17:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 17:29:18 --> CSRF cookie sent
INFO - 2018-07-04 17:29:18 --> Input Class Initialized
INFO - 2018-07-04 17:29:18 --> Language Class Initialized
ERROR - 2018-07-04 17:29:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 17:49:48 --> Config Class Initialized
INFO - 2018-07-04 17:49:48 --> Hooks Class Initialized
DEBUG - 2018-07-04 17:49:48 --> UTF-8 Support Enabled
INFO - 2018-07-04 17:49:48 --> Utf8 Class Initialized
INFO - 2018-07-04 17:49:48 --> URI Class Initialized
DEBUG - 2018-07-04 17:49:48 --> No URI present. Default controller set.
INFO - 2018-07-04 17:49:48 --> Router Class Initialized
INFO - 2018-07-04 17:49:48 --> Output Class Initialized
INFO - 2018-07-04 17:49:48 --> Security Class Initialized
DEBUG - 2018-07-04 17:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 17:49:48 --> CSRF cookie sent
INFO - 2018-07-04 17:49:48 --> Input Class Initialized
INFO - 2018-07-04 17:49:48 --> Language Class Initialized
INFO - 2018-07-04 17:49:48 --> Loader Class Initialized
INFO - 2018-07-04 17:49:48 --> Helper loaded: url_helper
INFO - 2018-07-04 17:49:48 --> Helper loaded: form_helper
INFO - 2018-07-04 17:49:48 --> Helper loaded: language_helper
DEBUG - 2018-07-04 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 17:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 17:49:48 --> User Agent Class Initialized
INFO - 2018-07-04 17:49:48 --> Controller Class Initialized
INFO - 2018-07-04 17:49:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 17:49:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 17:49:48 --> Pixel_Model class loaded
INFO - 2018-07-04 17:49:48 --> Database Driver Class Initialized
INFO - 2018-07-04 17:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 17:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 17:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 17:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 17:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 17:49:48 --> Final output sent to browser
DEBUG - 2018-07-04 17:49:48 --> Total execution time: 0.0705
INFO - 2018-07-04 18:04:42 --> Config Class Initialized
INFO - 2018-07-04 18:04:42 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:04:42 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:04:42 --> Utf8 Class Initialized
INFO - 2018-07-04 18:04:42 --> URI Class Initialized
INFO - 2018-07-04 18:04:42 --> Router Class Initialized
INFO - 2018-07-04 18:04:42 --> Output Class Initialized
INFO - 2018-07-04 18:04:42 --> Security Class Initialized
DEBUG - 2018-07-04 18:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:04:42 --> CSRF cookie sent
INFO - 2018-07-04 18:04:42 --> Input Class Initialized
INFO - 2018-07-04 18:04:42 --> Language Class Initialized
ERROR - 2018-07-04 18:04:42 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 18:04:43 --> Config Class Initialized
INFO - 2018-07-04 18:04:43 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:04:43 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:04:43 --> Utf8 Class Initialized
INFO - 2018-07-04 18:04:43 --> URI Class Initialized
DEBUG - 2018-07-04 18:04:43 --> No URI present. Default controller set.
INFO - 2018-07-04 18:04:43 --> Router Class Initialized
INFO - 2018-07-04 18:04:43 --> Output Class Initialized
INFO - 2018-07-04 18:04:43 --> Security Class Initialized
DEBUG - 2018-07-04 18:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:04:43 --> CSRF cookie sent
INFO - 2018-07-04 18:04:43 --> Input Class Initialized
INFO - 2018-07-04 18:04:43 --> Language Class Initialized
INFO - 2018-07-04 18:04:43 --> Loader Class Initialized
INFO - 2018-07-04 18:04:43 --> Helper loaded: url_helper
INFO - 2018-07-04 18:04:43 --> Helper loaded: form_helper
INFO - 2018-07-04 18:04:43 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:04:43 --> User Agent Class Initialized
INFO - 2018-07-04 18:04:43 --> Controller Class Initialized
INFO - 2018-07-04 18:04:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:04:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:04:43 --> Pixel_Model class loaded
INFO - 2018-07-04 18:04:43 --> Database Driver Class Initialized
INFO - 2018-07-04 18:04:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:04:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:04:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:04:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 18:04:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:04:43 --> Final output sent to browser
DEBUG - 2018-07-04 18:04:43 --> Total execution time: 0.0506
INFO - 2018-07-04 18:13:27 --> Config Class Initialized
INFO - 2018-07-04 18:13:27 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:27 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:27 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:27 --> URI Class Initialized
DEBUG - 2018-07-04 18:13:27 --> No URI present. Default controller set.
INFO - 2018-07-04 18:13:27 --> Router Class Initialized
INFO - 2018-07-04 18:13:27 --> Output Class Initialized
INFO - 2018-07-04 18:13:27 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:27 --> CSRF cookie sent
INFO - 2018-07-04 18:13:27 --> Input Class Initialized
INFO - 2018-07-04 18:13:27 --> Language Class Initialized
INFO - 2018-07-04 18:13:27 --> Loader Class Initialized
INFO - 2018-07-04 18:13:27 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:27 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:27 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:27 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:27 --> Controller Class Initialized
INFO - 2018-07-04 18:13:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:27 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:27 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 18:13:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:27 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:27 --> Total execution time: 0.0310
INFO - 2018-07-04 18:13:28 --> Config Class Initialized
INFO - 2018-07-04 18:13:28 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:28 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:28 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:28 --> URI Class Initialized
DEBUG - 2018-07-04 18:13:28 --> No URI present. Default controller set.
INFO - 2018-07-04 18:13:28 --> Router Class Initialized
INFO - 2018-07-04 18:13:28 --> Output Class Initialized
INFO - 2018-07-04 18:13:28 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:28 --> CSRF cookie sent
INFO - 2018-07-04 18:13:28 --> Input Class Initialized
INFO - 2018-07-04 18:13:28 --> Language Class Initialized
INFO - 2018-07-04 18:13:28 --> Loader Class Initialized
INFO - 2018-07-04 18:13:28 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:28 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:28 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:28 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:28 --> Controller Class Initialized
INFO - 2018-07-04 18:13:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:28 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:28 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 18:13:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:28 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:28 --> Total execution time: 0.0387
INFO - 2018-07-04 18:13:29 --> Config Class Initialized
INFO - 2018-07-04 18:13:29 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:29 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:29 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:29 --> URI Class Initialized
DEBUG - 2018-07-04 18:13:29 --> No URI present. Default controller set.
INFO - 2018-07-04 18:13:29 --> Router Class Initialized
INFO - 2018-07-04 18:13:29 --> Output Class Initialized
INFO - 2018-07-04 18:13:29 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:29 --> CSRF cookie sent
INFO - 2018-07-04 18:13:29 --> Input Class Initialized
INFO - 2018-07-04 18:13:29 --> Language Class Initialized
INFO - 2018-07-04 18:13:29 --> Loader Class Initialized
INFO - 2018-07-04 18:13:29 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:29 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:29 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:29 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:29 --> Controller Class Initialized
INFO - 2018-07-04 18:13:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:29 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:29 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 18:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:29 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:29 --> Total execution time: 0.0356
INFO - 2018-07-04 18:13:29 --> Config Class Initialized
INFO - 2018-07-04 18:13:29 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:29 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:29 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:29 --> URI Class Initialized
INFO - 2018-07-04 18:13:29 --> Router Class Initialized
INFO - 2018-07-04 18:13:29 --> Output Class Initialized
INFO - 2018-07-04 18:13:29 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:29 --> CSRF cookie sent
INFO - 2018-07-04 18:13:29 --> Input Class Initialized
INFO - 2018-07-04 18:13:29 --> Language Class Initialized
ERROR - 2018-07-04 18:13:29 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-04 18:13:35 --> Config Class Initialized
INFO - 2018-07-04 18:13:35 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:35 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:35 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:35 --> URI Class Initialized
DEBUG - 2018-07-04 18:13:35 --> No URI present. Default controller set.
INFO - 2018-07-04 18:13:35 --> Router Class Initialized
INFO - 2018-07-04 18:13:36 --> Output Class Initialized
INFO - 2018-07-04 18:13:36 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:36 --> CSRF cookie sent
INFO - 2018-07-04 18:13:36 --> Input Class Initialized
INFO - 2018-07-04 18:13:36 --> Language Class Initialized
INFO - 2018-07-04 18:13:36 --> Loader Class Initialized
INFO - 2018-07-04 18:13:36 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:36 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:36 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:36 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:36 --> Controller Class Initialized
INFO - 2018-07-04 18:13:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:36 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:36 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 18:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:36 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:36 --> Total execution time: 0.0347
INFO - 2018-07-04 18:13:36 --> Config Class Initialized
INFO - 2018-07-04 18:13:36 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:36 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:36 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:36 --> URI Class Initialized
INFO - 2018-07-04 18:13:36 --> Router Class Initialized
INFO - 2018-07-04 18:13:36 --> Output Class Initialized
INFO - 2018-07-04 18:13:36 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:36 --> CSRF cookie sent
INFO - 2018-07-04 18:13:36 --> Input Class Initialized
INFO - 2018-07-04 18:13:36 --> Language Class Initialized
ERROR - 2018-07-04 18:13:36 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-04 18:13:36 --> Config Class Initialized
INFO - 2018-07-04 18:13:36 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:36 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:36 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:36 --> URI Class Initialized
INFO - 2018-07-04 18:13:36 --> Router Class Initialized
INFO - 2018-07-04 18:13:36 --> Output Class Initialized
INFO - 2018-07-04 18:13:36 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:36 --> CSRF cookie sent
INFO - 2018-07-04 18:13:36 --> Input Class Initialized
INFO - 2018-07-04 18:13:36 --> Language Class Initialized
ERROR - 2018-07-04 18:13:36 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-04 18:13:37 --> Config Class Initialized
INFO - 2018-07-04 18:13:37 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:37 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:37 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:37 --> URI Class Initialized
INFO - 2018-07-04 18:13:37 --> Router Class Initialized
INFO - 2018-07-04 18:13:37 --> Output Class Initialized
INFO - 2018-07-04 18:13:37 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:37 --> CSRF cookie sent
INFO - 2018-07-04 18:13:37 --> Input Class Initialized
INFO - 2018-07-04 18:13:37 --> Language Class Initialized
INFO - 2018-07-04 18:13:37 --> Loader Class Initialized
INFO - 2018-07-04 18:13:37 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:37 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:37 --> Controller Class Initialized
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:37 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:37 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:37 --> Config Class Initialized
INFO - 2018-07-04 18:13:37 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:37 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:37 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:37 --> URI Class Initialized
INFO - 2018-07-04 18:13:37 --> Router Class Initialized
INFO - 2018-07-04 18:13:37 --> Output Class Initialized
INFO - 2018-07-04 18:13:37 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:37 --> CSRF cookie sent
INFO - 2018-07-04 18:13:37 --> Input Class Initialized
INFO - 2018-07-04 18:13:37 --> Language Class Initialized
INFO - 2018-07-04 18:13:37 --> Loader Class Initialized
INFO - 2018-07-04 18:13:37 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:37 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:37 --> Controller Class Initialized
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 18:13:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 18:13:37 --> Could not find the language line "req_email"
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:37 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:37 --> Total execution time: 0.0208
INFO - 2018-07-04 18:13:37 --> Config Class Initialized
INFO - 2018-07-04 18:13:37 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:37 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:37 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:37 --> URI Class Initialized
INFO - 2018-07-04 18:13:37 --> Router Class Initialized
INFO - 2018-07-04 18:13:37 --> Output Class Initialized
INFO - 2018-07-04 18:13:37 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:37 --> CSRF cookie sent
INFO - 2018-07-04 18:13:37 --> Input Class Initialized
INFO - 2018-07-04 18:13:37 --> Language Class Initialized
INFO - 2018-07-04 18:13:37 --> Loader Class Initialized
INFO - 2018-07-04 18:13:37 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:37 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:37 --> Controller Class Initialized
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:37 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:37 --> Total execution time: 0.0222
INFO - 2018-07-04 18:13:37 --> Config Class Initialized
INFO - 2018-07-04 18:13:37 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:37 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:37 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:37 --> URI Class Initialized
INFO - 2018-07-04 18:13:37 --> Router Class Initialized
INFO - 2018-07-04 18:13:37 --> Output Class Initialized
INFO - 2018-07-04 18:13:37 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:37 --> CSRF cookie sent
INFO - 2018-07-04 18:13:37 --> Input Class Initialized
INFO - 2018-07-04 18:13:37 --> Language Class Initialized
INFO - 2018-07-04 18:13:37 --> Loader Class Initialized
INFO - 2018-07-04 18:13:37 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:37 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:37 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:37 --> Controller Class Initialized
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-04 18:13:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:37 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:37 --> Total execution time: 0.0274
INFO - 2018-07-04 18:13:38 --> Config Class Initialized
INFO - 2018-07-04 18:13:38 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:38 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:38 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:38 --> URI Class Initialized
INFO - 2018-07-04 18:13:38 --> Router Class Initialized
INFO - 2018-07-04 18:13:38 --> Output Class Initialized
INFO - 2018-07-04 18:13:38 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:38 --> CSRF cookie sent
INFO - 2018-07-04 18:13:38 --> Input Class Initialized
INFO - 2018-07-04 18:13:38 --> Language Class Initialized
INFO - 2018-07-04 18:13:38 --> Loader Class Initialized
INFO - 2018-07-04 18:13:38 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:38 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:38 --> Controller Class Initialized
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:38 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:38 --> Total execution time: 0.0218
INFO - 2018-07-04 18:13:38 --> Config Class Initialized
INFO - 2018-07-04 18:13:38 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:38 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:38 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:38 --> URI Class Initialized
INFO - 2018-07-04 18:13:38 --> Router Class Initialized
INFO - 2018-07-04 18:13:38 --> Output Class Initialized
INFO - 2018-07-04 18:13:38 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:38 --> CSRF cookie sent
INFO - 2018-07-04 18:13:38 --> Input Class Initialized
INFO - 2018-07-04 18:13:38 --> Language Class Initialized
INFO - 2018-07-04 18:13:38 --> Loader Class Initialized
INFO - 2018-07-04 18:13:38 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:38 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:38 --> Controller Class Initialized
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:38 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:38 --> Total execution time: 0.0224
INFO - 2018-07-04 18:13:38 --> Config Class Initialized
INFO - 2018-07-04 18:13:38 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:38 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:38 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:38 --> URI Class Initialized
INFO - 2018-07-04 18:13:38 --> Router Class Initialized
INFO - 2018-07-04 18:13:38 --> Output Class Initialized
INFO - 2018-07-04 18:13:38 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:38 --> CSRF cookie sent
INFO - 2018-07-04 18:13:38 --> Input Class Initialized
INFO - 2018-07-04 18:13:38 --> Language Class Initialized
INFO - 2018-07-04 18:13:38 --> Loader Class Initialized
INFO - 2018-07-04 18:13:38 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:38 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:38 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:38 --> Controller Class Initialized
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-04 18:13:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-04 18:13:38 --> Could not find the language line "req_email"
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-04 18:13:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:38 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:38 --> Total execution time: 0.0257
INFO - 2018-07-04 18:13:39 --> Config Class Initialized
INFO - 2018-07-04 18:13:39 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:13:39 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:13:39 --> Utf8 Class Initialized
INFO - 2018-07-04 18:13:39 --> URI Class Initialized
INFO - 2018-07-04 18:13:39 --> Router Class Initialized
INFO - 2018-07-04 18:13:39 --> Output Class Initialized
INFO - 2018-07-04 18:13:39 --> Security Class Initialized
DEBUG - 2018-07-04 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:13:39 --> CSRF cookie sent
INFO - 2018-07-04 18:13:39 --> Input Class Initialized
INFO - 2018-07-04 18:13:39 --> Language Class Initialized
INFO - 2018-07-04 18:13:39 --> Loader Class Initialized
INFO - 2018-07-04 18:13:39 --> Helper loaded: url_helper
INFO - 2018-07-04 18:13:39 --> Helper loaded: form_helper
INFO - 2018-07-04 18:13:39 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:13:39 --> User Agent Class Initialized
INFO - 2018-07-04 18:13:39 --> Controller Class Initialized
INFO - 2018-07-04 18:13:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:13:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:13:39 --> Pixel_Model class loaded
INFO - 2018-07-04 18:13:39 --> Database Driver Class Initialized
INFO - 2018-07-04 18:13:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-04 18:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:13:39 --> Final output sent to browser
DEBUG - 2018-07-04 18:13:39 --> Total execution time: 0.0350
INFO - 2018-07-04 18:29:05 --> Config Class Initialized
INFO - 2018-07-04 18:29:05 --> Hooks Class Initialized
DEBUG - 2018-07-04 18:29:05 --> UTF-8 Support Enabled
INFO - 2018-07-04 18:29:05 --> Utf8 Class Initialized
INFO - 2018-07-04 18:29:05 --> URI Class Initialized
INFO - 2018-07-04 18:29:05 --> Router Class Initialized
INFO - 2018-07-04 18:29:05 --> Output Class Initialized
INFO - 2018-07-04 18:29:05 --> Security Class Initialized
DEBUG - 2018-07-04 18:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 18:29:05 --> CSRF cookie sent
INFO - 2018-07-04 18:29:05 --> Input Class Initialized
INFO - 2018-07-04 18:29:05 --> Language Class Initialized
INFO - 2018-07-04 18:29:05 --> Loader Class Initialized
INFO - 2018-07-04 18:29:05 --> Helper loaded: url_helper
INFO - 2018-07-04 18:29:05 --> Helper loaded: form_helper
INFO - 2018-07-04 18:29:05 --> Helper loaded: language_helper
DEBUG - 2018-07-04 18:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 18:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 18:29:05 --> User Agent Class Initialized
INFO - 2018-07-04 18:29:05 --> Controller Class Initialized
INFO - 2018-07-04 18:29:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 18:29:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-04 18:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 18:29:05 --> Final output sent to browser
DEBUG - 2018-07-04 18:29:05 --> Total execution time: 0.0226
INFO - 2018-07-04 19:05:08 --> Config Class Initialized
INFO - 2018-07-04 19:05:08 --> Hooks Class Initialized
DEBUG - 2018-07-04 19:05:08 --> UTF-8 Support Enabled
INFO - 2018-07-04 19:05:08 --> Utf8 Class Initialized
INFO - 2018-07-04 19:05:08 --> URI Class Initialized
DEBUG - 2018-07-04 19:05:08 --> No URI present. Default controller set.
INFO - 2018-07-04 19:05:08 --> Router Class Initialized
INFO - 2018-07-04 19:05:08 --> Output Class Initialized
INFO - 2018-07-04 19:05:08 --> Security Class Initialized
DEBUG - 2018-07-04 19:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 19:05:08 --> CSRF cookie sent
INFO - 2018-07-04 19:05:08 --> Input Class Initialized
INFO - 2018-07-04 19:05:08 --> Language Class Initialized
INFO - 2018-07-04 19:05:08 --> Loader Class Initialized
INFO - 2018-07-04 19:05:08 --> Helper loaded: url_helper
INFO - 2018-07-04 19:05:08 --> Helper loaded: form_helper
INFO - 2018-07-04 19:05:08 --> Helper loaded: language_helper
DEBUG - 2018-07-04 19:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 19:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 19:05:08 --> User Agent Class Initialized
INFO - 2018-07-04 19:05:08 --> Controller Class Initialized
INFO - 2018-07-04 19:05:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 19:05:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 19:05:08 --> Pixel_Model class loaded
INFO - 2018-07-04 19:05:08 --> Database Driver Class Initialized
INFO - 2018-07-04 19:05:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 19:05:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 19:05:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 19:05:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 19:05:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 19:05:08 --> Final output sent to browser
DEBUG - 2018-07-04 19:05:08 --> Total execution time: 0.0332
INFO - 2018-07-04 19:27:54 --> Config Class Initialized
INFO - 2018-07-04 19:27:54 --> Hooks Class Initialized
DEBUG - 2018-07-04 19:27:54 --> UTF-8 Support Enabled
INFO - 2018-07-04 19:27:54 --> Utf8 Class Initialized
INFO - 2018-07-04 19:27:54 --> URI Class Initialized
DEBUG - 2018-07-04 19:27:54 --> No URI present. Default controller set.
INFO - 2018-07-04 19:27:54 --> Router Class Initialized
INFO - 2018-07-04 19:27:54 --> Output Class Initialized
INFO - 2018-07-04 19:27:54 --> Security Class Initialized
DEBUG - 2018-07-04 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 19:27:54 --> CSRF cookie sent
INFO - 2018-07-04 19:27:54 --> Input Class Initialized
INFO - 2018-07-04 19:27:54 --> Language Class Initialized
INFO - 2018-07-04 19:27:54 --> Loader Class Initialized
INFO - 2018-07-04 19:27:54 --> Helper loaded: url_helper
INFO - 2018-07-04 19:27:54 --> Helper loaded: form_helper
INFO - 2018-07-04 19:27:54 --> Helper loaded: language_helper
DEBUG - 2018-07-04 19:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 19:27:54 --> User Agent Class Initialized
INFO - 2018-07-04 19:27:54 --> Controller Class Initialized
INFO - 2018-07-04 19:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 19:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 19:27:54 --> Pixel_Model class loaded
INFO - 2018-07-04 19:27:54 --> Database Driver Class Initialized
INFO - 2018-07-04 19:27:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 19:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 19:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 19:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 19:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 19:27:54 --> Final output sent to browser
DEBUG - 2018-07-04 19:27:54 --> Total execution time: 0.0325
INFO - 2018-07-04 20:47:29 --> Config Class Initialized
INFO - 2018-07-04 20:47:29 --> Hooks Class Initialized
DEBUG - 2018-07-04 20:47:29 --> UTF-8 Support Enabled
INFO - 2018-07-04 20:47:29 --> Utf8 Class Initialized
INFO - 2018-07-04 20:47:29 --> URI Class Initialized
INFO - 2018-07-04 20:47:29 --> Router Class Initialized
INFO - 2018-07-04 20:47:29 --> Output Class Initialized
INFO - 2018-07-04 20:47:29 --> Security Class Initialized
DEBUG - 2018-07-04 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 20:47:29 --> CSRF cookie sent
INFO - 2018-07-04 20:47:29 --> Input Class Initialized
INFO - 2018-07-04 20:47:29 --> Language Class Initialized
ERROR - 2018-07-04 20:47:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 20:47:29 --> Config Class Initialized
INFO - 2018-07-04 20:47:29 --> Hooks Class Initialized
DEBUG - 2018-07-04 20:47:29 --> UTF-8 Support Enabled
INFO - 2018-07-04 20:47:29 --> Utf8 Class Initialized
INFO - 2018-07-04 20:47:29 --> URI Class Initialized
DEBUG - 2018-07-04 20:47:29 --> No URI present. Default controller set.
INFO - 2018-07-04 20:47:29 --> Router Class Initialized
INFO - 2018-07-04 20:47:29 --> Output Class Initialized
INFO - 2018-07-04 20:47:29 --> Security Class Initialized
DEBUG - 2018-07-04 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 20:47:29 --> CSRF cookie sent
INFO - 2018-07-04 20:47:29 --> Input Class Initialized
INFO - 2018-07-04 20:47:29 --> Language Class Initialized
INFO - 2018-07-04 20:47:29 --> Loader Class Initialized
INFO - 2018-07-04 20:47:29 --> Helper loaded: url_helper
INFO - 2018-07-04 20:47:29 --> Helper loaded: form_helper
INFO - 2018-07-04 20:47:29 --> Helper loaded: language_helper
DEBUG - 2018-07-04 20:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 20:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 20:47:29 --> User Agent Class Initialized
INFO - 2018-07-04 20:47:29 --> Controller Class Initialized
INFO - 2018-07-04 20:47:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 20:47:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 20:47:29 --> Pixel_Model class loaded
INFO - 2018-07-04 20:47:29 --> Database Driver Class Initialized
INFO - 2018-07-04 20:47:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-04 20:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 20:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 20:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-04 20:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 20:47:29 --> Final output sent to browser
DEBUG - 2018-07-04 20:47:29 --> Total execution time: 0.0321
INFO - 2018-07-04 21:04:08 --> Config Class Initialized
INFO - 2018-07-04 21:04:08 --> Hooks Class Initialized
DEBUG - 2018-07-04 21:04:08 --> UTF-8 Support Enabled
INFO - 2018-07-04 21:04:08 --> Utf8 Class Initialized
INFO - 2018-07-04 21:04:08 --> URI Class Initialized
INFO - 2018-07-04 21:04:08 --> Router Class Initialized
INFO - 2018-07-04 21:04:08 --> Output Class Initialized
INFO - 2018-07-04 21:04:08 --> Security Class Initialized
DEBUG - 2018-07-04 21:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 21:04:08 --> CSRF cookie sent
INFO - 2018-07-04 21:04:08 --> Input Class Initialized
INFO - 2018-07-04 21:04:08 --> Language Class Initialized
ERROR - 2018-07-04 21:04:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 21:57:16 --> Config Class Initialized
INFO - 2018-07-04 21:57:16 --> Hooks Class Initialized
DEBUG - 2018-07-04 21:57:16 --> UTF-8 Support Enabled
INFO - 2018-07-04 21:57:16 --> Utf8 Class Initialized
INFO - 2018-07-04 21:57:16 --> URI Class Initialized
INFO - 2018-07-04 21:57:16 --> Router Class Initialized
INFO - 2018-07-04 21:57:16 --> Output Class Initialized
INFO - 2018-07-04 21:57:16 --> Security Class Initialized
DEBUG - 2018-07-04 21:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 21:57:16 --> CSRF cookie sent
INFO - 2018-07-04 21:57:16 --> Input Class Initialized
INFO - 2018-07-04 21:57:16 --> Language Class Initialized
ERROR - 2018-07-04 21:57:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-04 21:57:20 --> Config Class Initialized
INFO - 2018-07-04 21:57:20 --> Hooks Class Initialized
DEBUG - 2018-07-04 21:57:20 --> UTF-8 Support Enabled
INFO - 2018-07-04 21:57:20 --> Utf8 Class Initialized
INFO - 2018-07-04 21:57:20 --> URI Class Initialized
INFO - 2018-07-04 21:57:20 --> Router Class Initialized
INFO - 2018-07-04 21:57:20 --> Output Class Initialized
INFO - 2018-07-04 21:57:20 --> Security Class Initialized
DEBUG - 2018-07-04 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-04 21:57:20 --> CSRF cookie sent
INFO - 2018-07-04 21:57:20 --> Input Class Initialized
INFO - 2018-07-04 21:57:20 --> Language Class Initialized
INFO - 2018-07-04 21:57:20 --> Loader Class Initialized
INFO - 2018-07-04 21:57:20 --> Helper loaded: url_helper
INFO - 2018-07-04 21:57:20 --> Helper loaded: form_helper
INFO - 2018-07-04 21:57:20 --> Helper loaded: language_helper
DEBUG - 2018-07-04 21:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-04 21:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-04 21:57:20 --> User Agent Class Initialized
INFO - 2018-07-04 21:57:20 --> Controller Class Initialized
INFO - 2018-07-04 21:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-04 21:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-04 21:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-04 21:57:20 --> Final output sent to browser
DEBUG - 2018-07-04 21:57:20 --> Total execution time: 0.0257

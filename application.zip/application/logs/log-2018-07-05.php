<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-05 01:50:26 --> Config Class Initialized
INFO - 2018-07-05 01:50:26 --> Hooks Class Initialized
DEBUG - 2018-07-05 01:50:26 --> UTF-8 Support Enabled
INFO - 2018-07-05 01:50:26 --> Utf8 Class Initialized
INFO - 2018-07-05 01:50:26 --> URI Class Initialized
DEBUG - 2018-07-05 01:50:26 --> No URI present. Default controller set.
INFO - 2018-07-05 01:50:26 --> Router Class Initialized
INFO - 2018-07-05 01:50:26 --> Output Class Initialized
INFO - 2018-07-05 01:50:26 --> Security Class Initialized
DEBUG - 2018-07-05 01:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 01:50:26 --> CSRF cookie sent
INFO - 2018-07-05 01:50:26 --> Input Class Initialized
INFO - 2018-07-05 01:50:26 --> Language Class Initialized
INFO - 2018-07-05 01:50:26 --> Loader Class Initialized
INFO - 2018-07-05 01:50:26 --> Helper loaded: url_helper
INFO - 2018-07-05 01:50:26 --> Helper loaded: form_helper
INFO - 2018-07-05 01:50:26 --> Helper loaded: language_helper
DEBUG - 2018-07-05 01:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 01:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 01:50:26 --> User Agent Class Initialized
INFO - 2018-07-05 01:50:26 --> Controller Class Initialized
INFO - 2018-07-05 01:50:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 01:50:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 01:50:26 --> Pixel_Model class loaded
INFO - 2018-07-05 01:50:26 --> Database Driver Class Initialized
INFO - 2018-07-05 01:50:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 01:50:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 01:50:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 01:50:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 01:50:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 01:50:26 --> Final output sent to browser
DEBUG - 2018-07-05 01:50:26 --> Total execution time: 0.0315
INFO - 2018-07-05 03:53:58 --> Config Class Initialized
INFO - 2018-07-05 03:53:58 --> Hooks Class Initialized
DEBUG - 2018-07-05 03:53:58 --> UTF-8 Support Enabled
INFO - 2018-07-05 03:53:58 --> Utf8 Class Initialized
INFO - 2018-07-05 03:53:58 --> URI Class Initialized
INFO - 2018-07-05 03:53:58 --> Router Class Initialized
INFO - 2018-07-05 03:53:58 --> Output Class Initialized
INFO - 2018-07-05 03:53:58 --> Security Class Initialized
DEBUG - 2018-07-05 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 03:53:58 --> CSRF cookie sent
INFO - 2018-07-05 03:53:58 --> Input Class Initialized
INFO - 2018-07-05 03:53:58 --> Language Class Initialized
ERROR - 2018-07-05 03:53:58 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-05 03:54:01 --> Config Class Initialized
INFO - 2018-07-05 03:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-05 03:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-05 03:54:01 --> Utf8 Class Initialized
INFO - 2018-07-05 03:54:01 --> URI Class Initialized
DEBUG - 2018-07-05 03:54:01 --> No URI present. Default controller set.
INFO - 2018-07-05 03:54:01 --> Router Class Initialized
INFO - 2018-07-05 03:54:01 --> Output Class Initialized
INFO - 2018-07-05 03:54:01 --> Security Class Initialized
DEBUG - 2018-07-05 03:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 03:54:01 --> CSRF cookie sent
INFO - 2018-07-05 03:54:01 --> Input Class Initialized
INFO - 2018-07-05 03:54:01 --> Language Class Initialized
INFO - 2018-07-05 03:54:01 --> Loader Class Initialized
INFO - 2018-07-05 03:54:01 --> Helper loaded: url_helper
INFO - 2018-07-05 03:54:01 --> Helper loaded: form_helper
INFO - 2018-07-05 03:54:01 --> Helper loaded: language_helper
DEBUG - 2018-07-05 03:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 03:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 03:54:01 --> User Agent Class Initialized
INFO - 2018-07-05 03:54:01 --> Controller Class Initialized
INFO - 2018-07-05 03:54:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 03:54:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 03:54:01 --> Pixel_Model class loaded
INFO - 2018-07-05 03:54:01 --> Database Driver Class Initialized
INFO - 2018-07-05 03:54:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 03:54:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 03:54:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 03:54:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 03:54:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 03:54:01 --> Final output sent to browser
DEBUG - 2018-07-05 03:54:01 --> Total execution time: 0.0320
INFO - 2018-07-05 05:23:47 --> Config Class Initialized
INFO - 2018-07-05 05:23:47 --> Hooks Class Initialized
DEBUG - 2018-07-05 05:23:47 --> UTF-8 Support Enabled
INFO - 2018-07-05 05:23:47 --> Utf8 Class Initialized
INFO - 2018-07-05 05:23:47 --> URI Class Initialized
INFO - 2018-07-05 05:23:47 --> Router Class Initialized
INFO - 2018-07-05 05:23:47 --> Output Class Initialized
INFO - 2018-07-05 05:23:47 --> Security Class Initialized
DEBUG - 2018-07-05 05:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 05:23:47 --> CSRF cookie sent
INFO - 2018-07-05 05:23:47 --> Input Class Initialized
INFO - 2018-07-05 05:23:47 --> Language Class Initialized
INFO - 2018-07-05 05:23:47 --> Loader Class Initialized
INFO - 2018-07-05 05:23:47 --> Helper loaded: url_helper
INFO - 2018-07-05 05:23:47 --> Helper loaded: form_helper
INFO - 2018-07-05 05:23:47 --> Helper loaded: language_helper
DEBUG - 2018-07-05 05:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 05:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 05:23:47 --> User Agent Class Initialized
INFO - 2018-07-05 05:23:47 --> Controller Class Initialized
INFO - 2018-07-05 05:23:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 05:23:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-05 05:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 05:23:47 --> Final output sent to browser
DEBUG - 2018-07-05 05:23:47 --> Total execution time: 0.0227
INFO - 2018-07-05 06:17:08 --> Config Class Initialized
INFO - 2018-07-05 06:17:08 --> Hooks Class Initialized
DEBUG - 2018-07-05 06:17:08 --> UTF-8 Support Enabled
INFO - 2018-07-05 06:17:08 --> Utf8 Class Initialized
INFO - 2018-07-05 06:17:08 --> URI Class Initialized
INFO - 2018-07-05 06:17:08 --> Router Class Initialized
INFO - 2018-07-05 06:17:08 --> Output Class Initialized
INFO - 2018-07-05 06:17:08 --> Security Class Initialized
DEBUG - 2018-07-05 06:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 06:17:08 --> CSRF cookie sent
INFO - 2018-07-05 06:17:08 --> Input Class Initialized
INFO - 2018-07-05 06:17:08 --> Language Class Initialized
INFO - 2018-07-05 06:17:08 --> Loader Class Initialized
INFO - 2018-07-05 06:17:08 --> Helper loaded: url_helper
INFO - 2018-07-05 06:17:08 --> Helper loaded: form_helper
INFO - 2018-07-05 06:17:08 --> Helper loaded: language_helper
DEBUG - 2018-07-05 06:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 06:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 06:17:08 --> User Agent Class Initialized
INFO - 2018-07-05 06:17:08 --> Controller Class Initialized
INFO - 2018-07-05 06:17:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 06:17:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-05 06:17:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 06:17:08 --> Final output sent to browser
DEBUG - 2018-07-05 06:17:08 --> Total execution time: 0.0217
INFO - 2018-07-05 07:43:34 --> Config Class Initialized
INFO - 2018-07-05 07:43:34 --> Hooks Class Initialized
DEBUG - 2018-07-05 07:43:34 --> UTF-8 Support Enabled
INFO - 2018-07-05 07:43:34 --> Utf8 Class Initialized
INFO - 2018-07-05 07:43:34 --> URI Class Initialized
INFO - 2018-07-05 07:43:34 --> Router Class Initialized
INFO - 2018-07-05 07:43:34 --> Output Class Initialized
INFO - 2018-07-05 07:43:34 --> Security Class Initialized
DEBUG - 2018-07-05 07:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 07:43:34 --> CSRF cookie sent
INFO - 2018-07-05 07:43:34 --> Input Class Initialized
INFO - 2018-07-05 07:43:34 --> Language Class Initialized
ERROR - 2018-07-05 07:43:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-05 07:43:37 --> Config Class Initialized
INFO - 2018-07-05 07:43:37 --> Hooks Class Initialized
DEBUG - 2018-07-05 07:43:37 --> UTF-8 Support Enabled
INFO - 2018-07-05 07:43:37 --> Utf8 Class Initialized
INFO - 2018-07-05 07:43:37 --> URI Class Initialized
INFO - 2018-07-05 07:43:37 --> Router Class Initialized
INFO - 2018-07-05 07:43:37 --> Output Class Initialized
INFO - 2018-07-05 07:43:37 --> Security Class Initialized
DEBUG - 2018-07-05 07:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 07:43:37 --> CSRF cookie sent
INFO - 2018-07-05 07:43:37 --> Input Class Initialized
INFO - 2018-07-05 07:43:37 --> Language Class Initialized
INFO - 2018-07-05 07:43:37 --> Loader Class Initialized
INFO - 2018-07-05 07:43:37 --> Helper loaded: url_helper
INFO - 2018-07-05 07:43:37 --> Helper loaded: form_helper
INFO - 2018-07-05 07:43:37 --> Helper loaded: language_helper
DEBUG - 2018-07-05 07:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 07:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 07:43:37 --> User Agent Class Initialized
INFO - 2018-07-05 07:43:37 --> Controller Class Initialized
INFO - 2018-07-05 07:43:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 07:43:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-07-05 07:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 07:43:37 --> Final output sent to browser
DEBUG - 2018-07-05 07:43:37 --> Total execution time: 0.0282
INFO - 2018-07-05 09:50:04 --> Config Class Initialized
INFO - 2018-07-05 09:50:04 --> Hooks Class Initialized
DEBUG - 2018-07-05 09:50:04 --> UTF-8 Support Enabled
INFO - 2018-07-05 09:50:04 --> Utf8 Class Initialized
INFO - 2018-07-05 09:50:04 --> URI Class Initialized
DEBUG - 2018-07-05 09:50:04 --> No URI present. Default controller set.
INFO - 2018-07-05 09:50:04 --> Router Class Initialized
INFO - 2018-07-05 09:50:04 --> Output Class Initialized
INFO - 2018-07-05 09:50:04 --> Security Class Initialized
DEBUG - 2018-07-05 09:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 09:50:04 --> CSRF cookie sent
INFO - 2018-07-05 09:50:04 --> Input Class Initialized
INFO - 2018-07-05 09:50:04 --> Language Class Initialized
INFO - 2018-07-05 09:50:04 --> Loader Class Initialized
INFO - 2018-07-05 09:50:04 --> Helper loaded: url_helper
INFO - 2018-07-05 09:50:04 --> Helper loaded: form_helper
INFO - 2018-07-05 09:50:04 --> Helper loaded: language_helper
DEBUG - 2018-07-05 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 09:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 09:50:04 --> User Agent Class Initialized
INFO - 2018-07-05 09:50:04 --> Controller Class Initialized
INFO - 2018-07-05 09:50:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 09:50:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 09:50:04 --> Pixel_Model class loaded
INFO - 2018-07-05 09:50:04 --> Database Driver Class Initialized
INFO - 2018-07-05 09:50:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 09:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 09:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 09:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 09:50:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 09:50:04 --> Final output sent to browser
DEBUG - 2018-07-05 09:50:04 --> Total execution time: 0.0609
INFO - 2018-07-05 12:00:59 --> Config Class Initialized
INFO - 2018-07-05 12:00:59 --> Hooks Class Initialized
DEBUG - 2018-07-05 12:00:59 --> UTF-8 Support Enabled
INFO - 2018-07-05 12:00:59 --> Utf8 Class Initialized
INFO - 2018-07-05 12:00:59 --> URI Class Initialized
DEBUG - 2018-07-05 12:00:59 --> No URI present. Default controller set.
INFO - 2018-07-05 12:00:59 --> Router Class Initialized
INFO - 2018-07-05 12:00:59 --> Output Class Initialized
INFO - 2018-07-05 12:00:59 --> Security Class Initialized
DEBUG - 2018-07-05 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 12:00:59 --> CSRF cookie sent
INFO - 2018-07-05 12:00:59 --> Input Class Initialized
INFO - 2018-07-05 12:00:59 --> Language Class Initialized
INFO - 2018-07-05 12:00:59 --> Loader Class Initialized
INFO - 2018-07-05 12:00:59 --> Helper loaded: url_helper
INFO - 2018-07-05 12:00:59 --> Helper loaded: form_helper
INFO - 2018-07-05 12:00:59 --> Helper loaded: language_helper
DEBUG - 2018-07-05 12:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 12:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 12:00:59 --> User Agent Class Initialized
INFO - 2018-07-05 12:00:59 --> Controller Class Initialized
INFO - 2018-07-05 12:00:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 12:00:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 12:00:59 --> Pixel_Model class loaded
INFO - 2018-07-05 12:00:59 --> Database Driver Class Initialized
INFO - 2018-07-05 12:00:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 12:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 12:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 12:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 12:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 12:00:59 --> Final output sent to browser
DEBUG - 2018-07-05 12:00:59 --> Total execution time: 0.0370
INFO - 2018-07-05 13:22:42 --> Config Class Initialized
INFO - 2018-07-05 13:22:42 --> Hooks Class Initialized
DEBUG - 2018-07-05 13:22:42 --> UTF-8 Support Enabled
INFO - 2018-07-05 13:22:42 --> Utf8 Class Initialized
INFO - 2018-07-05 13:22:42 --> URI Class Initialized
INFO - 2018-07-05 13:22:42 --> Router Class Initialized
INFO - 2018-07-05 13:22:42 --> Output Class Initialized
INFO - 2018-07-05 13:22:42 --> Security Class Initialized
DEBUG - 2018-07-05 13:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 13:22:42 --> CSRF cookie sent
INFO - 2018-07-05 13:22:42 --> Input Class Initialized
INFO - 2018-07-05 13:22:42 --> Language Class Initialized
INFO - 2018-07-05 13:22:42 --> Loader Class Initialized
INFO - 2018-07-05 13:22:42 --> Helper loaded: url_helper
INFO - 2018-07-05 13:22:42 --> Helper loaded: form_helper
INFO - 2018-07-05 13:22:42 --> Helper loaded: language_helper
DEBUG - 2018-07-05 13:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 13:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 13:22:42 --> User Agent Class Initialized
INFO - 2018-07-05 13:22:42 --> Controller Class Initialized
INFO - 2018-07-05 13:22:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 13:22:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 13:22:42 --> Pixel_Model class loaded
INFO - 2018-07-05 13:22:42 --> Database Driver Class Initialized
INFO - 2018-07-05 13:22:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 13:22:44 --> Config Class Initialized
INFO - 2018-07-05 13:22:44 --> Hooks Class Initialized
DEBUG - 2018-07-05 13:22:44 --> UTF-8 Support Enabled
INFO - 2018-07-05 13:22:44 --> Utf8 Class Initialized
INFO - 2018-07-05 13:22:44 --> URI Class Initialized
INFO - 2018-07-05 13:22:44 --> Router Class Initialized
INFO - 2018-07-05 13:22:44 --> Output Class Initialized
INFO - 2018-07-05 13:22:44 --> Security Class Initialized
DEBUG - 2018-07-05 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 13:22:44 --> CSRF cookie sent
INFO - 2018-07-05 13:22:44 --> Input Class Initialized
INFO - 2018-07-05 13:22:44 --> Language Class Initialized
INFO - 2018-07-05 13:22:44 --> Loader Class Initialized
INFO - 2018-07-05 13:22:44 --> Helper loaded: url_helper
INFO - 2018-07-05 13:22:44 --> Helper loaded: form_helper
INFO - 2018-07-05 13:22:44 --> Helper loaded: language_helper
DEBUG - 2018-07-05 13:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 13:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 13:22:44 --> User Agent Class Initialized
INFO - 2018-07-05 13:22:44 --> Controller Class Initialized
INFO - 2018-07-05 13:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 13:22:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-05 13:22:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-05 13:22:44 --> Could not find the language line "req_email"
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-05 13:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 13:22:44 --> Final output sent to browser
DEBUG - 2018-07-05 13:22:44 --> Total execution time: 0.0222
INFO - 2018-07-05 14:42:26 --> Config Class Initialized
INFO - 2018-07-05 14:42:26 --> Hooks Class Initialized
DEBUG - 2018-07-05 14:42:26 --> UTF-8 Support Enabled
INFO - 2018-07-05 14:42:26 --> Utf8 Class Initialized
INFO - 2018-07-05 14:42:26 --> URI Class Initialized
DEBUG - 2018-07-05 14:42:26 --> No URI present. Default controller set.
INFO - 2018-07-05 14:42:26 --> Router Class Initialized
INFO - 2018-07-05 14:42:26 --> Output Class Initialized
INFO - 2018-07-05 14:42:26 --> Security Class Initialized
DEBUG - 2018-07-05 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 14:42:26 --> CSRF cookie sent
INFO - 2018-07-05 14:42:26 --> Input Class Initialized
INFO - 2018-07-05 14:42:26 --> Language Class Initialized
INFO - 2018-07-05 14:42:26 --> Loader Class Initialized
INFO - 2018-07-05 14:42:26 --> Helper loaded: url_helper
INFO - 2018-07-05 14:42:26 --> Helper loaded: form_helper
INFO - 2018-07-05 14:42:26 --> Helper loaded: language_helper
DEBUG - 2018-07-05 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 14:42:26 --> User Agent Class Initialized
INFO - 2018-07-05 14:42:26 --> Controller Class Initialized
INFO - 2018-07-05 14:42:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 14:42:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 14:42:26 --> Pixel_Model class loaded
INFO - 2018-07-05 14:42:26 --> Database Driver Class Initialized
INFO - 2018-07-05 14:42:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 14:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 14:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 14:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 14:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 14:42:26 --> Final output sent to browser
DEBUG - 2018-07-05 14:42:26 --> Total execution time: 0.0339
INFO - 2018-07-05 16:50:18 --> Config Class Initialized
INFO - 2018-07-05 16:50:18 --> Hooks Class Initialized
DEBUG - 2018-07-05 16:50:18 --> UTF-8 Support Enabled
INFO - 2018-07-05 16:50:18 --> Utf8 Class Initialized
INFO - 2018-07-05 16:50:18 --> URI Class Initialized
INFO - 2018-07-05 16:50:18 --> Router Class Initialized
INFO - 2018-07-05 16:50:18 --> Output Class Initialized
INFO - 2018-07-05 16:50:18 --> Security Class Initialized
DEBUG - 2018-07-05 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 16:50:18 --> CSRF cookie sent
INFO - 2018-07-05 16:50:18 --> Input Class Initialized
INFO - 2018-07-05 16:50:18 --> Language Class Initialized
ERROR - 2018-07-05 16:50:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-05 17:18:37 --> Config Class Initialized
INFO - 2018-07-05 17:18:37 --> Hooks Class Initialized
DEBUG - 2018-07-05 17:18:37 --> UTF-8 Support Enabled
INFO - 2018-07-05 17:18:37 --> Utf8 Class Initialized
INFO - 2018-07-05 17:18:37 --> URI Class Initialized
INFO - 2018-07-05 17:18:37 --> Router Class Initialized
INFO - 2018-07-05 17:18:37 --> Output Class Initialized
INFO - 2018-07-05 17:18:37 --> Security Class Initialized
DEBUG - 2018-07-05 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 17:18:37 --> CSRF cookie sent
INFO - 2018-07-05 17:18:37 --> Input Class Initialized
INFO - 2018-07-05 17:18:37 --> Language Class Initialized
ERROR - 2018-07-05 17:18:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-05 17:54:47 --> Config Class Initialized
INFO - 2018-07-05 17:54:47 --> Hooks Class Initialized
DEBUG - 2018-07-05 17:54:47 --> UTF-8 Support Enabled
INFO - 2018-07-05 17:54:47 --> Utf8 Class Initialized
INFO - 2018-07-05 17:54:47 --> URI Class Initialized
DEBUG - 2018-07-05 17:54:47 --> No URI present. Default controller set.
INFO - 2018-07-05 17:54:47 --> Router Class Initialized
INFO - 2018-07-05 17:54:47 --> Output Class Initialized
INFO - 2018-07-05 17:54:47 --> Security Class Initialized
DEBUG - 2018-07-05 17:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 17:54:47 --> CSRF cookie sent
INFO - 2018-07-05 17:54:47 --> Input Class Initialized
INFO - 2018-07-05 17:54:47 --> Language Class Initialized
INFO - 2018-07-05 17:54:47 --> Loader Class Initialized
INFO - 2018-07-05 17:54:47 --> Helper loaded: url_helper
INFO - 2018-07-05 17:54:47 --> Helper loaded: form_helper
INFO - 2018-07-05 17:54:47 --> Helper loaded: language_helper
DEBUG - 2018-07-05 17:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 17:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 17:54:47 --> User Agent Class Initialized
INFO - 2018-07-05 17:54:47 --> Controller Class Initialized
INFO - 2018-07-05 17:54:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 17:54:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 17:54:47 --> Pixel_Model class loaded
INFO - 2018-07-05 17:54:47 --> Database Driver Class Initialized
INFO - 2018-07-05 17:54:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 17:54:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 17:54:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 17:54:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 17:54:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 17:54:47 --> Final output sent to browser
DEBUG - 2018-07-05 17:54:47 --> Total execution time: 0.0302
INFO - 2018-07-05 18:07:10 --> Config Class Initialized
INFO - 2018-07-05 18:07:10 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:07:10 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:07:10 --> Utf8 Class Initialized
INFO - 2018-07-05 18:07:10 --> URI Class Initialized
DEBUG - 2018-07-05 18:07:10 --> No URI present. Default controller set.
INFO - 2018-07-05 18:07:10 --> Router Class Initialized
INFO - 2018-07-05 18:07:10 --> Output Class Initialized
INFO - 2018-07-05 18:07:10 --> Security Class Initialized
DEBUG - 2018-07-05 18:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:07:10 --> CSRF cookie sent
INFO - 2018-07-05 18:07:10 --> Input Class Initialized
INFO - 2018-07-05 18:07:10 --> Language Class Initialized
INFO - 2018-07-05 18:07:10 --> Loader Class Initialized
INFO - 2018-07-05 18:07:10 --> Helper loaded: url_helper
INFO - 2018-07-05 18:07:10 --> Helper loaded: form_helper
INFO - 2018-07-05 18:07:10 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:07:10 --> User Agent Class Initialized
INFO - 2018-07-05 18:07:10 --> Controller Class Initialized
INFO - 2018-07-05 18:07:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:07:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:07:10 --> Pixel_Model class loaded
INFO - 2018-07-05 18:07:10 --> Database Driver Class Initialized
INFO - 2018-07-05 18:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:07:10 --> Final output sent to browser
DEBUG - 2018-07-05 18:07:10 --> Total execution time: 0.0343
INFO - 2018-07-05 18:15:34 --> Config Class Initialized
INFO - 2018-07-05 18:15:34 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:34 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:34 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:34 --> URI Class Initialized
DEBUG - 2018-07-05 18:15:34 --> No URI present. Default controller set.
INFO - 2018-07-05 18:15:34 --> Router Class Initialized
INFO - 2018-07-05 18:15:34 --> Output Class Initialized
INFO - 2018-07-05 18:15:34 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:34 --> CSRF cookie sent
INFO - 2018-07-05 18:15:34 --> Input Class Initialized
INFO - 2018-07-05 18:15:34 --> Language Class Initialized
INFO - 2018-07-05 18:15:34 --> Loader Class Initialized
INFO - 2018-07-05 18:15:34 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:34 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:34 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:34 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:34 --> Controller Class Initialized
INFO - 2018-07-05 18:15:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:34 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:34 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:15:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:34 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:34 --> Total execution time: 0.0446
INFO - 2018-07-05 18:15:35 --> Config Class Initialized
INFO - 2018-07-05 18:15:35 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:35 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:35 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:35 --> URI Class Initialized
DEBUG - 2018-07-05 18:15:35 --> No URI present. Default controller set.
INFO - 2018-07-05 18:15:35 --> Router Class Initialized
INFO - 2018-07-05 18:15:35 --> Output Class Initialized
INFO - 2018-07-05 18:15:35 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:35 --> CSRF cookie sent
INFO - 2018-07-05 18:15:35 --> Input Class Initialized
INFO - 2018-07-05 18:15:35 --> Language Class Initialized
INFO - 2018-07-05 18:15:35 --> Loader Class Initialized
INFO - 2018-07-05 18:15:35 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:35 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:35 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:35 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:35 --> Controller Class Initialized
INFO - 2018-07-05 18:15:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:35 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:35 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:15:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:35 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:35 --> Total execution time: 0.0372
INFO - 2018-07-05 18:15:36 --> Config Class Initialized
INFO - 2018-07-05 18:15:36 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:36 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:36 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:36 --> URI Class Initialized
DEBUG - 2018-07-05 18:15:36 --> No URI present. Default controller set.
INFO - 2018-07-05 18:15:36 --> Router Class Initialized
INFO - 2018-07-05 18:15:36 --> Output Class Initialized
INFO - 2018-07-05 18:15:36 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:36 --> CSRF cookie sent
INFO - 2018-07-05 18:15:36 --> Input Class Initialized
INFO - 2018-07-05 18:15:36 --> Language Class Initialized
INFO - 2018-07-05 18:15:36 --> Loader Class Initialized
INFO - 2018-07-05 18:15:36 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:36 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:36 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:36 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:36 --> Controller Class Initialized
INFO - 2018-07-05 18:15:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:36 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:36 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:36 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:36 --> Total execution time: 0.0481
INFO - 2018-07-05 18:15:37 --> Config Class Initialized
INFO - 2018-07-05 18:15:37 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:37 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:37 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:37 --> URI Class Initialized
INFO - 2018-07-05 18:15:37 --> Router Class Initialized
INFO - 2018-07-05 18:15:37 --> Output Class Initialized
INFO - 2018-07-05 18:15:37 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:37 --> CSRF cookie sent
INFO - 2018-07-05 18:15:37 --> Input Class Initialized
INFO - 2018-07-05 18:15:37 --> Language Class Initialized
ERROR - 2018-07-05 18:15:37 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-05 18:15:43 --> Config Class Initialized
INFO - 2018-07-05 18:15:43 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:43 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:43 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:43 --> URI Class Initialized
DEBUG - 2018-07-05 18:15:43 --> No URI present. Default controller set.
INFO - 2018-07-05 18:15:43 --> Router Class Initialized
INFO - 2018-07-05 18:15:43 --> Output Class Initialized
INFO - 2018-07-05 18:15:43 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:43 --> CSRF cookie sent
INFO - 2018-07-05 18:15:43 --> Input Class Initialized
INFO - 2018-07-05 18:15:43 --> Language Class Initialized
INFO - 2018-07-05 18:15:43 --> Loader Class Initialized
INFO - 2018-07-05 18:15:43 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:43 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:43 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:43 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:43 --> Controller Class Initialized
INFO - 2018-07-05 18:15:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:43 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:43 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:43 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:43 --> Total execution time: 0.0324
INFO - 2018-07-05 18:15:44 --> Config Class Initialized
INFO - 2018-07-05 18:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:44 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:44 --> URI Class Initialized
INFO - 2018-07-05 18:15:44 --> Router Class Initialized
INFO - 2018-07-05 18:15:44 --> Output Class Initialized
INFO - 2018-07-05 18:15:44 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:44 --> CSRF cookie sent
INFO - 2018-07-05 18:15:44 --> Input Class Initialized
INFO - 2018-07-05 18:15:44 --> Language Class Initialized
ERROR - 2018-07-05 18:15:44 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-05 18:15:44 --> Config Class Initialized
INFO - 2018-07-05 18:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:44 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:44 --> URI Class Initialized
INFO - 2018-07-05 18:15:44 --> Router Class Initialized
INFO - 2018-07-05 18:15:44 --> Output Class Initialized
INFO - 2018-07-05 18:15:44 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:44 --> CSRF cookie sent
INFO - 2018-07-05 18:15:44 --> Input Class Initialized
INFO - 2018-07-05 18:15:44 --> Language Class Initialized
ERROR - 2018-07-05 18:15:44 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-05 18:15:44 --> Config Class Initialized
INFO - 2018-07-05 18:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:44 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:44 --> URI Class Initialized
INFO - 2018-07-05 18:15:44 --> Router Class Initialized
INFO - 2018-07-05 18:15:44 --> Output Class Initialized
INFO - 2018-07-05 18:15:44 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:44 --> CSRF cookie sent
INFO - 2018-07-05 18:15:44 --> Input Class Initialized
INFO - 2018-07-05 18:15:44 --> Language Class Initialized
INFO - 2018-07-05 18:15:44 --> Loader Class Initialized
INFO - 2018-07-05 18:15:44 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:44 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:44 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:44 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:44 --> Controller Class Initialized
INFO - 2018-07-05 18:15:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:44 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:44 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:44 --> Config Class Initialized
INFO - 2018-07-05 18:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:44 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:44 --> URI Class Initialized
INFO - 2018-07-05 18:15:44 --> Router Class Initialized
INFO - 2018-07-05 18:15:44 --> Output Class Initialized
INFO - 2018-07-05 18:15:44 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:44 --> CSRF cookie sent
INFO - 2018-07-05 18:15:44 --> Input Class Initialized
INFO - 2018-07-05 18:15:44 --> Language Class Initialized
INFO - 2018-07-05 18:15:44 --> Loader Class Initialized
INFO - 2018-07-05 18:15:44 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:44 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:44 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:45 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:45 --> Controller Class Initialized
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-05 18:15:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-05 18:15:45 --> Could not find the language line "req_email"
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:45 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:45 --> Total execution time: 0.0255
INFO - 2018-07-05 18:15:45 --> Config Class Initialized
INFO - 2018-07-05 18:15:45 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:45 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:45 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:45 --> URI Class Initialized
INFO - 2018-07-05 18:15:45 --> Router Class Initialized
INFO - 2018-07-05 18:15:45 --> Output Class Initialized
INFO - 2018-07-05 18:15:45 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:45 --> CSRF cookie sent
INFO - 2018-07-05 18:15:45 --> Input Class Initialized
INFO - 2018-07-05 18:15:45 --> Language Class Initialized
INFO - 2018-07-05 18:15:45 --> Loader Class Initialized
INFO - 2018-07-05 18:15:45 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:45 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:45 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:45 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:45 --> Controller Class Initialized
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:45 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:45 --> Total execution time: 0.0208
INFO - 2018-07-05 18:15:45 --> Config Class Initialized
INFO - 2018-07-05 18:15:45 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:45 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:45 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:45 --> URI Class Initialized
INFO - 2018-07-05 18:15:45 --> Router Class Initialized
INFO - 2018-07-05 18:15:45 --> Output Class Initialized
INFO - 2018-07-05 18:15:45 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:45 --> CSRF cookie sent
INFO - 2018-07-05 18:15:45 --> Input Class Initialized
INFO - 2018-07-05 18:15:45 --> Language Class Initialized
INFO - 2018-07-05 18:15:45 --> Loader Class Initialized
INFO - 2018-07-05 18:15:45 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:45 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:45 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:45 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:45 --> Controller Class Initialized
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-05 18:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:45 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:45 --> Total execution time: 0.0244
INFO - 2018-07-05 18:15:46 --> Config Class Initialized
INFO - 2018-07-05 18:15:46 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:46 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:46 --> URI Class Initialized
INFO - 2018-07-05 18:15:46 --> Router Class Initialized
INFO - 2018-07-05 18:15:46 --> Output Class Initialized
INFO - 2018-07-05 18:15:46 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:46 --> CSRF cookie sent
INFO - 2018-07-05 18:15:46 --> Input Class Initialized
INFO - 2018-07-05 18:15:46 --> Language Class Initialized
INFO - 2018-07-05 18:15:46 --> Loader Class Initialized
INFO - 2018-07-05 18:15:46 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:46 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:46 --> Controller Class Initialized
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:46 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:46 --> Total execution time: 0.0264
INFO - 2018-07-05 18:15:46 --> Config Class Initialized
INFO - 2018-07-05 18:15:46 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:46 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:46 --> URI Class Initialized
INFO - 2018-07-05 18:15:46 --> Router Class Initialized
INFO - 2018-07-05 18:15:46 --> Output Class Initialized
INFO - 2018-07-05 18:15:46 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:46 --> CSRF cookie sent
INFO - 2018-07-05 18:15:46 --> Input Class Initialized
INFO - 2018-07-05 18:15:46 --> Language Class Initialized
INFO - 2018-07-05 18:15:46 --> Loader Class Initialized
INFO - 2018-07-05 18:15:46 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:46 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:46 --> Controller Class Initialized
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:46 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:46 --> Total execution time: 0.0210
INFO - 2018-07-05 18:15:46 --> Config Class Initialized
INFO - 2018-07-05 18:15:46 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:46 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:46 --> URI Class Initialized
INFO - 2018-07-05 18:15:46 --> Router Class Initialized
INFO - 2018-07-05 18:15:46 --> Output Class Initialized
INFO - 2018-07-05 18:15:46 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:46 --> CSRF cookie sent
INFO - 2018-07-05 18:15:46 --> Input Class Initialized
INFO - 2018-07-05 18:15:46 --> Language Class Initialized
INFO - 2018-07-05 18:15:46 --> Loader Class Initialized
INFO - 2018-07-05 18:15:46 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:46 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:46 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:46 --> Controller Class Initialized
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-05 18:15:46 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-05 18:15:46 --> Could not find the language line "req_email"
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-05 18:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:46 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:46 --> Total execution time: 0.0249
INFO - 2018-07-05 18:15:47 --> Config Class Initialized
INFO - 2018-07-05 18:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:15:47 --> Utf8 Class Initialized
INFO - 2018-07-05 18:15:47 --> URI Class Initialized
INFO - 2018-07-05 18:15:47 --> Router Class Initialized
INFO - 2018-07-05 18:15:47 --> Output Class Initialized
INFO - 2018-07-05 18:15:47 --> Security Class Initialized
DEBUG - 2018-07-05 18:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:15:47 --> CSRF cookie sent
INFO - 2018-07-05 18:15:47 --> Input Class Initialized
INFO - 2018-07-05 18:15:47 --> Language Class Initialized
INFO - 2018-07-05 18:15:47 --> Loader Class Initialized
INFO - 2018-07-05 18:15:47 --> Helper loaded: url_helper
INFO - 2018-07-05 18:15:47 --> Helper loaded: form_helper
INFO - 2018-07-05 18:15:47 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:15:47 --> User Agent Class Initialized
INFO - 2018-07-05 18:15:47 --> Controller Class Initialized
INFO - 2018-07-05 18:15:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:15:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:15:47 --> Pixel_Model class loaded
INFO - 2018-07-05 18:15:47 --> Database Driver Class Initialized
INFO - 2018-07-05 18:15:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-05 18:15:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:15:47 --> Final output sent to browser
DEBUG - 2018-07-05 18:15:47 --> Total execution time: 0.0310
INFO - 2018-07-05 18:55:46 --> Config Class Initialized
INFO - 2018-07-05 18:55:46 --> Hooks Class Initialized
DEBUG - 2018-07-05 18:55:46 --> UTF-8 Support Enabled
INFO - 2018-07-05 18:55:46 --> Utf8 Class Initialized
INFO - 2018-07-05 18:55:46 --> URI Class Initialized
DEBUG - 2018-07-05 18:55:46 --> No URI present. Default controller set.
INFO - 2018-07-05 18:55:46 --> Router Class Initialized
INFO - 2018-07-05 18:55:46 --> Output Class Initialized
INFO - 2018-07-05 18:55:46 --> Security Class Initialized
DEBUG - 2018-07-05 18:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 18:55:46 --> CSRF cookie sent
INFO - 2018-07-05 18:55:46 --> Input Class Initialized
INFO - 2018-07-05 18:55:46 --> Language Class Initialized
INFO - 2018-07-05 18:55:46 --> Loader Class Initialized
INFO - 2018-07-05 18:55:46 --> Helper loaded: url_helper
INFO - 2018-07-05 18:55:46 --> Helper loaded: form_helper
INFO - 2018-07-05 18:55:46 --> Helper loaded: language_helper
DEBUG - 2018-07-05 18:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 18:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 18:55:46 --> User Agent Class Initialized
INFO - 2018-07-05 18:55:46 --> Controller Class Initialized
INFO - 2018-07-05 18:55:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 18:55:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 18:55:46 --> Pixel_Model class loaded
INFO - 2018-07-05 18:55:46 --> Database Driver Class Initialized
INFO - 2018-07-05 18:55:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 18:55:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 18:55:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 18:55:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 18:55:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 18:55:46 --> Final output sent to browser
DEBUG - 2018-07-05 18:55:46 --> Total execution time: 0.0364
INFO - 2018-07-05 22:07:11 --> Config Class Initialized
INFO - 2018-07-05 22:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-05 22:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-05 22:07:11 --> Utf8 Class Initialized
INFO - 2018-07-05 22:07:11 --> URI Class Initialized
DEBUG - 2018-07-05 22:07:11 --> No URI present. Default controller set.
INFO - 2018-07-05 22:07:11 --> Router Class Initialized
INFO - 2018-07-05 22:07:11 --> Output Class Initialized
INFO - 2018-07-05 22:07:11 --> Security Class Initialized
DEBUG - 2018-07-05 22:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 22:07:11 --> CSRF cookie sent
INFO - 2018-07-05 22:07:11 --> Input Class Initialized
INFO - 2018-07-05 22:07:11 --> Language Class Initialized
INFO - 2018-07-05 22:07:11 --> Loader Class Initialized
INFO - 2018-07-05 22:07:11 --> Helper loaded: url_helper
INFO - 2018-07-05 22:07:11 --> Helper loaded: form_helper
INFO - 2018-07-05 22:07:11 --> Helper loaded: language_helper
DEBUG - 2018-07-05 22:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 22:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 22:07:11 --> User Agent Class Initialized
INFO - 2018-07-05 22:07:11 --> Controller Class Initialized
INFO - 2018-07-05 22:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 22:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 22:07:11 --> Pixel_Model class loaded
INFO - 2018-07-05 22:07:11 --> Database Driver Class Initialized
INFO - 2018-07-05 22:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 22:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 22:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 22:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 22:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 22:07:11 --> Final output sent to browser
DEBUG - 2018-07-05 22:07:11 --> Total execution time: 0.0338
INFO - 2018-07-05 23:04:52 --> Config Class Initialized
INFO - 2018-07-05 23:04:52 --> Hooks Class Initialized
DEBUG - 2018-07-05 23:04:52 --> UTF-8 Support Enabled
INFO - 2018-07-05 23:04:52 --> Utf8 Class Initialized
INFO - 2018-07-05 23:04:52 --> URI Class Initialized
INFO - 2018-07-05 23:04:52 --> Router Class Initialized
INFO - 2018-07-05 23:04:52 --> Output Class Initialized
INFO - 2018-07-05 23:04:52 --> Security Class Initialized
DEBUG - 2018-07-05 23:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 23:04:52 --> CSRF cookie sent
INFO - 2018-07-05 23:04:52 --> Input Class Initialized
INFO - 2018-07-05 23:04:52 --> Language Class Initialized
ERROR - 2018-07-05 23:04:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-05 23:04:55 --> Config Class Initialized
INFO - 2018-07-05 23:04:55 --> Hooks Class Initialized
DEBUG - 2018-07-05 23:04:55 --> UTF-8 Support Enabled
INFO - 2018-07-05 23:04:55 --> Utf8 Class Initialized
INFO - 2018-07-05 23:04:55 --> URI Class Initialized
DEBUG - 2018-07-05 23:04:55 --> No URI present. Default controller set.
INFO - 2018-07-05 23:04:55 --> Router Class Initialized
INFO - 2018-07-05 23:04:55 --> Output Class Initialized
INFO - 2018-07-05 23:04:55 --> Security Class Initialized
DEBUG - 2018-07-05 23:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 23:04:55 --> CSRF cookie sent
INFO - 2018-07-05 23:04:55 --> Input Class Initialized
INFO - 2018-07-05 23:04:55 --> Language Class Initialized
INFO - 2018-07-05 23:04:55 --> Loader Class Initialized
INFO - 2018-07-05 23:04:55 --> Helper loaded: url_helper
INFO - 2018-07-05 23:04:55 --> Helper loaded: form_helper
INFO - 2018-07-05 23:04:55 --> Helper loaded: language_helper
DEBUG - 2018-07-05 23:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 23:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 23:04:55 --> User Agent Class Initialized
INFO - 2018-07-05 23:04:55 --> Controller Class Initialized
INFO - 2018-07-05 23:04:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 23:04:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 23:04:55 --> Pixel_Model class loaded
INFO - 2018-07-05 23:04:55 --> Database Driver Class Initialized
INFO - 2018-07-05 23:04:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-05 23:04:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 23:04:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 23:04:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-05 23:04:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 23:04:55 --> Final output sent to browser
DEBUG - 2018-07-05 23:04:55 --> Total execution time: 0.0341
INFO - 2018-07-05 23:52:11 --> Config Class Initialized
INFO - 2018-07-05 23:52:11 --> Hooks Class Initialized
DEBUG - 2018-07-05 23:52:11 --> UTF-8 Support Enabled
INFO - 2018-07-05 23:52:11 --> Utf8 Class Initialized
INFO - 2018-07-05 23:52:11 --> URI Class Initialized
INFO - 2018-07-05 23:52:11 --> Router Class Initialized
INFO - 2018-07-05 23:52:11 --> Output Class Initialized
INFO - 2018-07-05 23:52:11 --> Security Class Initialized
DEBUG - 2018-07-05 23:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 23:52:11 --> CSRF cookie sent
INFO - 2018-07-05 23:52:11 --> Input Class Initialized
INFO - 2018-07-05 23:52:11 --> Language Class Initialized
INFO - 2018-07-05 23:52:11 --> Loader Class Initialized
INFO - 2018-07-05 23:52:11 --> Helper loaded: url_helper
INFO - 2018-07-05 23:52:11 --> Helper loaded: form_helper
INFO - 2018-07-05 23:52:11 --> Helper loaded: language_helper
DEBUG - 2018-07-05 23:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 23:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 23:52:11 --> User Agent Class Initialized
INFO - 2018-07-05 23:52:11 --> Controller Class Initialized
INFO - 2018-07-05 23:52:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 23:52:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-07-05 23:52:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 23:52:11 --> Final output sent to browser
DEBUG - 2018-07-05 23:52:11 --> Total execution time: 0.0332
INFO - 2018-07-05 23:57:47 --> Config Class Initialized
INFO - 2018-07-05 23:57:47 --> Hooks Class Initialized
DEBUG - 2018-07-05 23:57:47 --> UTF-8 Support Enabled
INFO - 2018-07-05 23:57:47 --> Utf8 Class Initialized
INFO - 2018-07-05 23:57:47 --> URI Class Initialized
INFO - 2018-07-05 23:57:47 --> Router Class Initialized
INFO - 2018-07-05 23:57:47 --> Output Class Initialized
INFO - 2018-07-05 23:57:47 --> Security Class Initialized
DEBUG - 2018-07-05 23:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-05 23:57:47 --> CSRF cookie sent
INFO - 2018-07-05 23:57:47 --> Input Class Initialized
INFO - 2018-07-05 23:57:47 --> Language Class Initialized
INFO - 2018-07-05 23:57:47 --> Loader Class Initialized
INFO - 2018-07-05 23:57:47 --> Helper loaded: url_helper
INFO - 2018-07-05 23:57:47 --> Helper loaded: form_helper
INFO - 2018-07-05 23:57:47 --> Helper loaded: language_helper
DEBUG - 2018-07-05 23:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-05 23:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-05 23:57:47 --> User Agent Class Initialized
INFO - 2018-07-05 23:57:47 --> Controller Class Initialized
INFO - 2018-07-05 23:57:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-05 23:57:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-05 23:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-05 23:57:47 --> Final output sent to browser
DEBUG - 2018-07-05 23:57:47 --> Total execution time: 0.0264

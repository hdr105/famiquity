<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-08 01:54:40 --> Config Class Initialized
INFO - 2018-07-08 01:54:40 --> Hooks Class Initialized
DEBUG - 2018-07-08 01:54:40 --> UTF-8 Support Enabled
INFO - 2018-07-08 01:54:40 --> Utf8 Class Initialized
INFO - 2018-07-08 01:54:40 --> URI Class Initialized
DEBUG - 2018-07-08 01:54:40 --> No URI present. Default controller set.
INFO - 2018-07-08 01:54:40 --> Router Class Initialized
INFO - 2018-07-08 01:54:40 --> Output Class Initialized
INFO - 2018-07-08 01:54:40 --> Security Class Initialized
DEBUG - 2018-07-08 01:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 01:54:40 --> CSRF cookie sent
INFO - 2018-07-08 01:54:40 --> Input Class Initialized
INFO - 2018-07-08 01:54:40 --> Language Class Initialized
INFO - 2018-07-08 01:54:40 --> Loader Class Initialized
INFO - 2018-07-08 01:54:40 --> Helper loaded: url_helper
INFO - 2018-07-08 01:54:40 --> Helper loaded: form_helper
INFO - 2018-07-08 01:54:40 --> Helper loaded: language_helper
DEBUG - 2018-07-08 01:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 01:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 01:54:40 --> User Agent Class Initialized
INFO - 2018-07-08 01:54:40 --> Controller Class Initialized
INFO - 2018-07-08 01:54:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 01:54:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 01:54:40 --> Pixel_Model class loaded
INFO - 2018-07-08 01:54:40 --> Database Driver Class Initialized
INFO - 2018-07-08 01:54:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 01:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 01:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 01:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 01:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 01:54:40 --> Final output sent to browser
DEBUG - 2018-07-08 01:54:40 --> Total execution time: 0.0335
INFO - 2018-07-08 07:31:35 --> Config Class Initialized
INFO - 2018-07-08 07:31:35 --> Hooks Class Initialized
DEBUG - 2018-07-08 07:31:35 --> UTF-8 Support Enabled
INFO - 2018-07-08 07:31:35 --> Utf8 Class Initialized
INFO - 2018-07-08 07:31:35 --> URI Class Initialized
INFO - 2018-07-08 07:31:35 --> Router Class Initialized
INFO - 2018-07-08 07:31:35 --> Output Class Initialized
INFO - 2018-07-08 07:31:35 --> Security Class Initialized
DEBUG - 2018-07-08 07:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 07:31:35 --> CSRF cookie sent
INFO - 2018-07-08 07:31:35 --> Input Class Initialized
INFO - 2018-07-08 07:31:35 --> Language Class Initialized
ERROR - 2018-07-08 07:31:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-08 07:31:47 --> Config Class Initialized
INFO - 2018-07-08 07:31:47 --> Hooks Class Initialized
DEBUG - 2018-07-08 07:31:47 --> UTF-8 Support Enabled
INFO - 2018-07-08 07:31:47 --> Utf8 Class Initialized
INFO - 2018-07-08 07:31:47 --> URI Class Initialized
INFO - 2018-07-08 07:31:47 --> Router Class Initialized
INFO - 2018-07-08 07:31:47 --> Output Class Initialized
INFO - 2018-07-08 07:31:47 --> Security Class Initialized
DEBUG - 2018-07-08 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 07:31:47 --> CSRF cookie sent
INFO - 2018-07-08 07:31:47 --> Input Class Initialized
INFO - 2018-07-08 07:31:47 --> Language Class Initialized
INFO - 2018-07-08 07:31:47 --> Loader Class Initialized
INFO - 2018-07-08 07:31:47 --> Helper loaded: url_helper
INFO - 2018-07-08 07:31:47 --> Helper loaded: form_helper
INFO - 2018-07-08 07:31:47 --> Helper loaded: language_helper
DEBUG - 2018-07-08 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 07:31:47 --> User Agent Class Initialized
INFO - 2018-07-08 07:31:47 --> Controller Class Initialized
INFO - 2018-07-08 07:31:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 07:31:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-08 07:31:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-08 07:31:47 --> Could not find the language line "req_email"
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-08 07:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 07:31:47 --> Final output sent to browser
DEBUG - 2018-07-08 07:31:47 --> Total execution time: 0.0237
INFO - 2018-07-08 07:31:51 --> Config Class Initialized
INFO - 2018-07-08 07:31:51 --> Hooks Class Initialized
DEBUG - 2018-07-08 07:31:51 --> UTF-8 Support Enabled
INFO - 2018-07-08 07:31:51 --> Utf8 Class Initialized
INFO - 2018-07-08 07:31:51 --> URI Class Initialized
DEBUG - 2018-07-08 07:31:51 --> No URI present. Default controller set.
INFO - 2018-07-08 07:31:51 --> Router Class Initialized
INFO - 2018-07-08 07:31:51 --> Output Class Initialized
INFO - 2018-07-08 07:31:51 --> Security Class Initialized
DEBUG - 2018-07-08 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 07:31:51 --> CSRF cookie sent
INFO - 2018-07-08 07:31:51 --> Input Class Initialized
INFO - 2018-07-08 07:31:51 --> Language Class Initialized
INFO - 2018-07-08 07:31:51 --> Loader Class Initialized
INFO - 2018-07-08 07:31:51 --> Helper loaded: url_helper
INFO - 2018-07-08 07:31:51 --> Helper loaded: form_helper
INFO - 2018-07-08 07:31:51 --> Helper loaded: language_helper
DEBUG - 2018-07-08 07:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 07:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 07:31:51 --> User Agent Class Initialized
INFO - 2018-07-08 07:31:51 --> Controller Class Initialized
INFO - 2018-07-08 07:31:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 07:31:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 07:31:51 --> Pixel_Model class loaded
INFO - 2018-07-08 07:31:51 --> Database Driver Class Initialized
INFO - 2018-07-08 07:31:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 07:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 07:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 07:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 07:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 07:31:51 --> Final output sent to browser
DEBUG - 2018-07-08 07:31:51 --> Total execution time: 0.0339
INFO - 2018-07-08 09:53:23 --> Config Class Initialized
INFO - 2018-07-08 09:53:23 --> Hooks Class Initialized
DEBUG - 2018-07-08 09:53:23 --> UTF-8 Support Enabled
INFO - 2018-07-08 09:53:23 --> Utf8 Class Initialized
INFO - 2018-07-08 09:53:23 --> URI Class Initialized
DEBUG - 2018-07-08 09:53:23 --> No URI present. Default controller set.
INFO - 2018-07-08 09:53:23 --> Router Class Initialized
INFO - 2018-07-08 09:53:23 --> Output Class Initialized
INFO - 2018-07-08 09:53:23 --> Security Class Initialized
DEBUG - 2018-07-08 09:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 09:53:23 --> CSRF cookie sent
INFO - 2018-07-08 09:53:23 --> Input Class Initialized
INFO - 2018-07-08 09:53:23 --> Language Class Initialized
INFO - 2018-07-08 09:53:23 --> Loader Class Initialized
INFO - 2018-07-08 09:53:23 --> Helper loaded: url_helper
INFO - 2018-07-08 09:53:23 --> Helper loaded: form_helper
INFO - 2018-07-08 09:53:23 --> Helper loaded: language_helper
DEBUG - 2018-07-08 09:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 09:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 09:53:23 --> User Agent Class Initialized
INFO - 2018-07-08 09:53:23 --> Controller Class Initialized
INFO - 2018-07-08 09:53:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 09:53:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 09:53:23 --> Pixel_Model class loaded
INFO - 2018-07-08 09:53:23 --> Database Driver Class Initialized
INFO - 2018-07-08 09:53:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 09:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 09:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 09:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 09:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 09:53:23 --> Final output sent to browser
DEBUG - 2018-07-08 09:53:23 --> Total execution time: 0.0349
INFO - 2018-07-08 11:27:29 --> Config Class Initialized
INFO - 2018-07-08 11:27:29 --> Hooks Class Initialized
DEBUG - 2018-07-08 11:27:29 --> UTF-8 Support Enabled
INFO - 2018-07-08 11:27:29 --> Utf8 Class Initialized
INFO - 2018-07-08 11:27:29 --> URI Class Initialized
INFO - 2018-07-08 11:27:29 --> Router Class Initialized
INFO - 2018-07-08 11:27:29 --> Output Class Initialized
INFO - 2018-07-08 11:27:29 --> Security Class Initialized
DEBUG - 2018-07-08 11:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 11:27:29 --> CSRF cookie sent
INFO - 2018-07-08 11:27:29 --> Input Class Initialized
INFO - 2018-07-08 11:27:29 --> Language Class Initialized
ERROR - 2018-07-08 11:27:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-08 13:00:14 --> Config Class Initialized
INFO - 2018-07-08 13:00:14 --> Hooks Class Initialized
DEBUG - 2018-07-08 13:00:14 --> UTF-8 Support Enabled
INFO - 2018-07-08 13:00:14 --> Utf8 Class Initialized
INFO - 2018-07-08 13:00:14 --> URI Class Initialized
INFO - 2018-07-08 13:00:14 --> Router Class Initialized
INFO - 2018-07-08 13:00:14 --> Output Class Initialized
INFO - 2018-07-08 13:00:14 --> Security Class Initialized
DEBUG - 2018-07-08 13:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 13:00:14 --> CSRF cookie sent
INFO - 2018-07-08 13:00:14 --> Input Class Initialized
INFO - 2018-07-08 13:00:14 --> Language Class Initialized
ERROR - 2018-07-08 13:00:14 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-08 13:00:17 --> Config Class Initialized
INFO - 2018-07-08 13:00:17 --> Hooks Class Initialized
DEBUG - 2018-07-08 13:00:17 --> UTF-8 Support Enabled
INFO - 2018-07-08 13:00:17 --> Utf8 Class Initialized
INFO - 2018-07-08 13:00:17 --> URI Class Initialized
INFO - 2018-07-08 13:00:17 --> Router Class Initialized
INFO - 2018-07-08 13:00:17 --> Output Class Initialized
INFO - 2018-07-08 13:00:17 --> Security Class Initialized
DEBUG - 2018-07-08 13:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 13:00:17 --> CSRF cookie sent
INFO - 2018-07-08 13:00:17 --> Input Class Initialized
INFO - 2018-07-08 13:00:17 --> Language Class Initialized
INFO - 2018-07-08 13:00:17 --> Loader Class Initialized
INFO - 2018-07-08 13:00:17 --> Helper loaded: url_helper
INFO - 2018-07-08 13:00:17 --> Helper loaded: form_helper
INFO - 2018-07-08 13:00:17 --> Helper loaded: language_helper
DEBUG - 2018-07-08 13:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 13:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 13:00:17 --> User Agent Class Initialized
INFO - 2018-07-08 13:00:17 --> Controller Class Initialized
INFO - 2018-07-08 13:00:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 13:00:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-08 13:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 13:00:17 --> Final output sent to browser
DEBUG - 2018-07-08 13:00:17 --> Total execution time: 0.0284
INFO - 2018-07-08 16:01:30 --> Config Class Initialized
INFO - 2018-07-08 16:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-08 16:01:30 --> UTF-8 Support Enabled
INFO - 2018-07-08 16:01:30 --> Utf8 Class Initialized
INFO - 2018-07-08 16:01:30 --> URI Class Initialized
DEBUG - 2018-07-08 16:01:30 --> No URI present. Default controller set.
INFO - 2018-07-08 16:01:30 --> Router Class Initialized
INFO - 2018-07-08 16:01:30 --> Output Class Initialized
INFO - 2018-07-08 16:01:30 --> Security Class Initialized
DEBUG - 2018-07-08 16:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 16:01:30 --> CSRF cookie sent
INFO - 2018-07-08 16:01:30 --> Input Class Initialized
INFO - 2018-07-08 16:01:30 --> Language Class Initialized
INFO - 2018-07-08 16:01:30 --> Loader Class Initialized
INFO - 2018-07-08 16:01:30 --> Helper loaded: url_helper
INFO - 2018-07-08 16:01:30 --> Helper loaded: form_helper
INFO - 2018-07-08 16:01:30 --> Helper loaded: language_helper
DEBUG - 2018-07-08 16:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 16:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 16:01:30 --> User Agent Class Initialized
INFO - 2018-07-08 16:01:30 --> Controller Class Initialized
INFO - 2018-07-08 16:01:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 16:01:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 16:01:30 --> Pixel_Model class loaded
INFO - 2018-07-08 16:01:30 --> Database Driver Class Initialized
INFO - 2018-07-08 16:01:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 16:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 16:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 16:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 16:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 16:01:30 --> Final output sent to browser
DEBUG - 2018-07-08 16:01:30 --> Total execution time: 0.0342
INFO - 2018-07-08 16:02:17 --> Config Class Initialized
INFO - 2018-07-08 16:02:17 --> Hooks Class Initialized
DEBUG - 2018-07-08 16:02:17 --> UTF-8 Support Enabled
INFO - 2018-07-08 16:02:17 --> Utf8 Class Initialized
INFO - 2018-07-08 16:02:17 --> URI Class Initialized
INFO - 2018-07-08 16:02:17 --> Router Class Initialized
INFO - 2018-07-08 16:02:17 --> Output Class Initialized
INFO - 2018-07-08 16:02:17 --> Security Class Initialized
DEBUG - 2018-07-08 16:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 16:02:17 --> CSRF cookie sent
INFO - 2018-07-08 16:02:17 --> CSRF token verified
INFO - 2018-07-08 16:02:17 --> Input Class Initialized
INFO - 2018-07-08 16:02:17 --> Language Class Initialized
INFO - 2018-07-08 16:02:17 --> Loader Class Initialized
INFO - 2018-07-08 16:02:17 --> Helper loaded: url_helper
INFO - 2018-07-08 16:02:17 --> Helper loaded: form_helper
INFO - 2018-07-08 16:02:17 --> Helper loaded: language_helper
DEBUG - 2018-07-08 16:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 16:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 16:02:17 --> User Agent Class Initialized
INFO - 2018-07-08 16:02:17 --> Controller Class Initialized
INFO - 2018-07-08 16:02:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 16:02:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 16:02:17 --> Pixel_Model class loaded
INFO - 2018-07-08 16:02:17 --> Database Driver Class Initialized
INFO - 2018-07-08 16:02:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 16:02:17 --> Config Class Initialized
INFO - 2018-07-08 16:02:17 --> Hooks Class Initialized
DEBUG - 2018-07-08 16:02:17 --> UTF-8 Support Enabled
INFO - 2018-07-08 16:02:17 --> Utf8 Class Initialized
INFO - 2018-07-08 16:02:17 --> URI Class Initialized
INFO - 2018-07-08 16:02:17 --> Router Class Initialized
INFO - 2018-07-08 16:02:17 --> Output Class Initialized
INFO - 2018-07-08 16:02:17 --> Security Class Initialized
DEBUG - 2018-07-08 16:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 16:02:17 --> CSRF cookie sent
INFO - 2018-07-08 16:02:17 --> Input Class Initialized
INFO - 2018-07-08 16:02:17 --> Language Class Initialized
INFO - 2018-07-08 16:02:17 --> Loader Class Initialized
INFO - 2018-07-08 16:02:17 --> Helper loaded: url_helper
INFO - 2018-07-08 16:02:17 --> Helper loaded: form_helper
INFO - 2018-07-08 16:02:17 --> Helper loaded: language_helper
DEBUG - 2018-07-08 16:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 16:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 16:02:17 --> User Agent Class Initialized
INFO - 2018-07-08 16:02:17 --> Controller Class Initialized
INFO - 2018-07-08 16:02:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 16:02:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-08 16:02:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-08 16:02:17 --> Could not find the language line "req_email"
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-08 16:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 16:02:17 --> Final output sent to browser
DEBUG - 2018-07-08 16:02:17 --> Total execution time: 0.0215
INFO - 2018-07-08 16:02:23 --> Config Class Initialized
INFO - 2018-07-08 16:02:23 --> Hooks Class Initialized
DEBUG - 2018-07-08 16:02:23 --> UTF-8 Support Enabled
INFO - 2018-07-08 16:02:23 --> Utf8 Class Initialized
INFO - 2018-07-08 16:02:23 --> URI Class Initialized
DEBUG - 2018-07-08 16:02:23 --> No URI present. Default controller set.
INFO - 2018-07-08 16:02:23 --> Router Class Initialized
INFO - 2018-07-08 16:02:23 --> Output Class Initialized
INFO - 2018-07-08 16:02:23 --> Security Class Initialized
DEBUG - 2018-07-08 16:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 16:02:23 --> CSRF cookie sent
INFO - 2018-07-08 16:02:23 --> Input Class Initialized
INFO - 2018-07-08 16:02:23 --> Language Class Initialized
INFO - 2018-07-08 16:02:23 --> Loader Class Initialized
INFO - 2018-07-08 16:02:23 --> Helper loaded: url_helper
INFO - 2018-07-08 16:02:23 --> Helper loaded: form_helper
INFO - 2018-07-08 16:02:23 --> Helper loaded: language_helper
DEBUG - 2018-07-08 16:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 16:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 16:02:23 --> User Agent Class Initialized
INFO - 2018-07-08 16:02:23 --> Controller Class Initialized
INFO - 2018-07-08 16:02:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 16:02:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 16:02:23 --> Pixel_Model class loaded
INFO - 2018-07-08 16:02:23 --> Database Driver Class Initialized
INFO - 2018-07-08 16:02:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 16:02:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 16:02:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 16:02:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 16:02:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 16:02:23 --> Final output sent to browser
DEBUG - 2018-07-08 16:02:23 --> Total execution time: 0.0345
INFO - 2018-07-08 16:02:24 --> Config Class Initialized
INFO - 2018-07-08 16:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-08 16:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-08 16:02:24 --> Utf8 Class Initialized
INFO - 2018-07-08 16:02:24 --> URI Class Initialized
INFO - 2018-07-08 16:02:24 --> Router Class Initialized
INFO - 2018-07-08 16:02:24 --> Output Class Initialized
INFO - 2018-07-08 16:02:24 --> Security Class Initialized
DEBUG - 2018-07-08 16:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 16:02:24 --> CSRF cookie sent
INFO - 2018-07-08 16:02:24 --> Input Class Initialized
INFO - 2018-07-08 16:02:24 --> Language Class Initialized
INFO - 2018-07-08 16:02:24 --> Loader Class Initialized
INFO - 2018-07-08 16:02:24 --> Helper loaded: url_helper
INFO - 2018-07-08 16:02:24 --> Helper loaded: form_helper
INFO - 2018-07-08 16:02:24 --> Helper loaded: language_helper
DEBUG - 2018-07-08 16:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 16:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 16:02:24 --> User Agent Class Initialized
INFO - 2018-07-08 16:02:24 --> Controller Class Initialized
INFO - 2018-07-08 16:02:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 16:02:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 16:02:24 --> Pixel_Model class loaded
INFO - 2018-07-08 16:02:24 --> Database Driver Class Initialized
INFO - 2018-07-08 16:02:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-08 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 16:02:24 --> Final output sent to browser
DEBUG - 2018-07-08 16:02:24 --> Total execution time: 0.0311
INFO - 2018-07-08 17:30:18 --> Config Class Initialized
INFO - 2018-07-08 17:30:18 --> Hooks Class Initialized
DEBUG - 2018-07-08 17:30:18 --> UTF-8 Support Enabled
INFO - 2018-07-08 17:30:18 --> Utf8 Class Initialized
INFO - 2018-07-08 17:30:18 --> URI Class Initialized
INFO - 2018-07-08 17:30:18 --> Router Class Initialized
INFO - 2018-07-08 17:30:18 --> Output Class Initialized
INFO - 2018-07-08 17:30:18 --> Security Class Initialized
DEBUG - 2018-07-08 17:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 17:30:18 --> CSRF cookie sent
INFO - 2018-07-08 17:30:18 --> Input Class Initialized
INFO - 2018-07-08 17:30:18 --> Language Class Initialized
ERROR - 2018-07-08 17:30:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-08 17:51:19 --> Config Class Initialized
INFO - 2018-07-08 17:51:19 --> Hooks Class Initialized
DEBUG - 2018-07-08 17:51:19 --> UTF-8 Support Enabled
INFO - 2018-07-08 17:51:19 --> Utf8 Class Initialized
INFO - 2018-07-08 17:51:19 --> URI Class Initialized
DEBUG - 2018-07-08 17:51:19 --> No URI present. Default controller set.
INFO - 2018-07-08 17:51:19 --> Router Class Initialized
INFO - 2018-07-08 17:51:19 --> Output Class Initialized
INFO - 2018-07-08 17:51:19 --> Security Class Initialized
DEBUG - 2018-07-08 17:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 17:51:19 --> CSRF cookie sent
INFO - 2018-07-08 17:51:19 --> Input Class Initialized
INFO - 2018-07-08 17:51:19 --> Language Class Initialized
INFO - 2018-07-08 17:51:19 --> Loader Class Initialized
INFO - 2018-07-08 17:51:19 --> Helper loaded: url_helper
INFO - 2018-07-08 17:51:19 --> Helper loaded: form_helper
INFO - 2018-07-08 17:51:19 --> Helper loaded: language_helper
DEBUG - 2018-07-08 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 17:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 17:51:19 --> User Agent Class Initialized
INFO - 2018-07-08 17:51:19 --> Controller Class Initialized
INFO - 2018-07-08 17:51:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 17:51:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 17:51:20 --> Pixel_Model class loaded
INFO - 2018-07-08 17:51:20 --> Database Driver Class Initialized
INFO - 2018-07-08 17:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 17:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 17:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 17:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 17:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 17:51:20 --> Final output sent to browser
DEBUG - 2018-07-08 17:51:20 --> Total execution time: 0.0349
INFO - 2018-07-08 18:09:48 --> Config Class Initialized
INFO - 2018-07-08 18:09:48 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:09:48 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:09:48 --> Utf8 Class Initialized
INFO - 2018-07-08 18:09:48 --> URI Class Initialized
DEBUG - 2018-07-08 18:09:48 --> No URI present. Default controller set.
INFO - 2018-07-08 18:09:48 --> Router Class Initialized
INFO - 2018-07-08 18:09:48 --> Output Class Initialized
INFO - 2018-07-08 18:09:48 --> Security Class Initialized
DEBUG - 2018-07-08 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:09:48 --> CSRF cookie sent
INFO - 2018-07-08 18:09:48 --> Input Class Initialized
INFO - 2018-07-08 18:09:48 --> Language Class Initialized
INFO - 2018-07-08 18:09:48 --> Loader Class Initialized
INFO - 2018-07-08 18:09:48 --> Helper loaded: url_helper
INFO - 2018-07-08 18:09:48 --> Helper loaded: form_helper
INFO - 2018-07-08 18:09:48 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:09:48 --> User Agent Class Initialized
INFO - 2018-07-08 18:09:48 --> Controller Class Initialized
INFO - 2018-07-08 18:09:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:09:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:09:48 --> Pixel_Model class loaded
INFO - 2018-07-08 18:09:48 --> Database Driver Class Initialized
INFO - 2018-07-08 18:09:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 18:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:09:48 --> Final output sent to browser
DEBUG - 2018-07-08 18:09:48 --> Total execution time: 0.0380
INFO - 2018-07-08 18:25:10 --> Config Class Initialized
INFO - 2018-07-08 18:25:10 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:10 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:10 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:10 --> URI Class Initialized
DEBUG - 2018-07-08 18:25:10 --> No URI present. Default controller set.
INFO - 2018-07-08 18:25:10 --> Router Class Initialized
INFO - 2018-07-08 18:25:10 --> Output Class Initialized
INFO - 2018-07-08 18:25:10 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:10 --> CSRF cookie sent
INFO - 2018-07-08 18:25:10 --> Input Class Initialized
INFO - 2018-07-08 18:25:10 --> Language Class Initialized
INFO - 2018-07-08 18:25:10 --> Loader Class Initialized
INFO - 2018-07-08 18:25:10 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:10 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:10 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:10 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:10 --> Controller Class Initialized
INFO - 2018-07-08 18:25:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:10 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:10 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 18:25:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:10 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:10 --> Total execution time: 0.0520
INFO - 2018-07-08 18:25:11 --> Config Class Initialized
INFO - 2018-07-08 18:25:11 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:11 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:11 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:11 --> URI Class Initialized
DEBUG - 2018-07-08 18:25:11 --> No URI present. Default controller set.
INFO - 2018-07-08 18:25:11 --> Router Class Initialized
INFO - 2018-07-08 18:25:11 --> Output Class Initialized
INFO - 2018-07-08 18:25:11 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:11 --> CSRF cookie sent
INFO - 2018-07-08 18:25:11 --> Input Class Initialized
INFO - 2018-07-08 18:25:11 --> Language Class Initialized
INFO - 2018-07-08 18:25:11 --> Loader Class Initialized
INFO - 2018-07-08 18:25:11 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:11 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:11 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:11 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:11 --> Controller Class Initialized
INFO - 2018-07-08 18:25:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:11 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:11 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:11 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:11 --> Total execution time: 0.0325
INFO - 2018-07-08 18:25:11 --> Config Class Initialized
INFO - 2018-07-08 18:25:11 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:11 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:11 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:11 --> URI Class Initialized
DEBUG - 2018-07-08 18:25:11 --> No URI present. Default controller set.
INFO - 2018-07-08 18:25:11 --> Router Class Initialized
INFO - 2018-07-08 18:25:11 --> Output Class Initialized
INFO - 2018-07-08 18:25:11 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:11 --> CSRF cookie sent
INFO - 2018-07-08 18:25:11 --> Input Class Initialized
INFO - 2018-07-08 18:25:11 --> Language Class Initialized
INFO - 2018-07-08 18:25:11 --> Loader Class Initialized
INFO - 2018-07-08 18:25:11 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:11 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:11 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:11 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:11 --> Controller Class Initialized
INFO - 2018-07-08 18:25:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:11 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:11 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 18:25:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:11 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:11 --> Total execution time: 0.0339
INFO - 2018-07-08 18:25:12 --> Config Class Initialized
INFO - 2018-07-08 18:25:12 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:12 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:12 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:12 --> URI Class Initialized
INFO - 2018-07-08 18:25:12 --> Router Class Initialized
INFO - 2018-07-08 18:25:12 --> Output Class Initialized
INFO - 2018-07-08 18:25:12 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:12 --> CSRF cookie sent
INFO - 2018-07-08 18:25:12 --> Input Class Initialized
INFO - 2018-07-08 18:25:12 --> Language Class Initialized
ERROR - 2018-07-08 18:25:12 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-08 18:25:19 --> Config Class Initialized
INFO - 2018-07-08 18:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:19 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:19 --> URI Class Initialized
DEBUG - 2018-07-08 18:25:19 --> No URI present. Default controller set.
INFO - 2018-07-08 18:25:19 --> Router Class Initialized
INFO - 2018-07-08 18:25:19 --> Output Class Initialized
INFO - 2018-07-08 18:25:19 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:19 --> CSRF cookie sent
INFO - 2018-07-08 18:25:19 --> Input Class Initialized
INFO - 2018-07-08 18:25:19 --> Language Class Initialized
INFO - 2018-07-08 18:25:19 --> Loader Class Initialized
INFO - 2018-07-08 18:25:19 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:19 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:19 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:19 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:19 --> Controller Class Initialized
INFO - 2018-07-08 18:25:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:19 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:19 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-08 18:25:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:19 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:19 --> Total execution time: 0.0338
INFO - 2018-07-08 18:25:19 --> Config Class Initialized
INFO - 2018-07-08 18:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:19 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:19 --> URI Class Initialized
INFO - 2018-07-08 18:25:19 --> Router Class Initialized
INFO - 2018-07-08 18:25:19 --> Output Class Initialized
INFO - 2018-07-08 18:25:19 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:19 --> CSRF cookie sent
INFO - 2018-07-08 18:25:19 --> Input Class Initialized
INFO - 2018-07-08 18:25:19 --> Language Class Initialized
ERROR - 2018-07-08 18:25:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-08 18:25:19 --> Config Class Initialized
INFO - 2018-07-08 18:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:19 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:19 --> URI Class Initialized
INFO - 2018-07-08 18:25:19 --> Router Class Initialized
INFO - 2018-07-08 18:25:19 --> Output Class Initialized
INFO - 2018-07-08 18:25:19 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:19 --> CSRF cookie sent
INFO - 2018-07-08 18:25:19 --> Input Class Initialized
INFO - 2018-07-08 18:25:19 --> Language Class Initialized
ERROR - 2018-07-08 18:25:19 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-08 18:25:20 --> Config Class Initialized
INFO - 2018-07-08 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:20 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:20 --> URI Class Initialized
INFO - 2018-07-08 18:25:20 --> Router Class Initialized
INFO - 2018-07-08 18:25:20 --> Output Class Initialized
INFO - 2018-07-08 18:25:20 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:20 --> CSRF cookie sent
INFO - 2018-07-08 18:25:20 --> Input Class Initialized
INFO - 2018-07-08 18:25:20 --> Language Class Initialized
INFO - 2018-07-08 18:25:20 --> Loader Class Initialized
INFO - 2018-07-08 18:25:20 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:20 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:20 --> Controller Class Initialized
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:20 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:20 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:20 --> Config Class Initialized
INFO - 2018-07-08 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:20 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:20 --> URI Class Initialized
INFO - 2018-07-08 18:25:20 --> Router Class Initialized
INFO - 2018-07-08 18:25:20 --> Output Class Initialized
INFO - 2018-07-08 18:25:20 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:20 --> CSRF cookie sent
INFO - 2018-07-08 18:25:20 --> Input Class Initialized
INFO - 2018-07-08 18:25:20 --> Language Class Initialized
INFO - 2018-07-08 18:25:20 --> Loader Class Initialized
INFO - 2018-07-08 18:25:20 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:20 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:20 --> Controller Class Initialized
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-08 18:25:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-08 18:25:20 --> Could not find the language line "req_email"
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:20 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:20 --> Total execution time: 0.0277
INFO - 2018-07-08 18:25:20 --> Config Class Initialized
INFO - 2018-07-08 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:20 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:20 --> URI Class Initialized
INFO - 2018-07-08 18:25:20 --> Router Class Initialized
INFO - 2018-07-08 18:25:20 --> Output Class Initialized
INFO - 2018-07-08 18:25:20 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:20 --> CSRF cookie sent
INFO - 2018-07-08 18:25:20 --> Input Class Initialized
INFO - 2018-07-08 18:25:20 --> Language Class Initialized
INFO - 2018-07-08 18:25:20 --> Loader Class Initialized
INFO - 2018-07-08 18:25:20 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:20 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:20 --> Controller Class Initialized
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:20 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:20 --> Total execution time: 0.0212
INFO - 2018-07-08 18:25:20 --> Config Class Initialized
INFO - 2018-07-08 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:20 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:20 --> URI Class Initialized
INFO - 2018-07-08 18:25:20 --> Router Class Initialized
INFO - 2018-07-08 18:25:20 --> Output Class Initialized
INFO - 2018-07-08 18:25:20 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:20 --> CSRF cookie sent
INFO - 2018-07-08 18:25:20 --> Input Class Initialized
INFO - 2018-07-08 18:25:20 --> Language Class Initialized
INFO - 2018-07-08 18:25:20 --> Loader Class Initialized
INFO - 2018-07-08 18:25:20 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:20 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:20 --> Controller Class Initialized
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-08 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:20 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:20 --> Total execution time: 0.0298
INFO - 2018-07-08 18:25:21 --> Config Class Initialized
INFO - 2018-07-08 18:25:21 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:21 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:21 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:21 --> URI Class Initialized
INFO - 2018-07-08 18:25:21 --> Router Class Initialized
INFO - 2018-07-08 18:25:21 --> Output Class Initialized
INFO - 2018-07-08 18:25:21 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:21 --> CSRF cookie sent
INFO - 2018-07-08 18:25:21 --> Input Class Initialized
INFO - 2018-07-08 18:25:21 --> Language Class Initialized
INFO - 2018-07-08 18:25:21 --> Loader Class Initialized
INFO - 2018-07-08 18:25:21 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:21 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:21 --> Controller Class Initialized
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:21 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:21 --> Total execution time: 0.0218
INFO - 2018-07-08 18:25:21 --> Config Class Initialized
INFO - 2018-07-08 18:25:21 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:21 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:21 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:21 --> URI Class Initialized
INFO - 2018-07-08 18:25:21 --> Router Class Initialized
INFO - 2018-07-08 18:25:21 --> Output Class Initialized
INFO - 2018-07-08 18:25:21 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:21 --> CSRF cookie sent
INFO - 2018-07-08 18:25:21 --> Input Class Initialized
INFO - 2018-07-08 18:25:21 --> Language Class Initialized
INFO - 2018-07-08 18:25:21 --> Loader Class Initialized
INFO - 2018-07-08 18:25:21 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:21 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:21 --> Controller Class Initialized
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:21 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:21 --> Total execution time: 0.0230
INFO - 2018-07-08 18:25:21 --> Config Class Initialized
INFO - 2018-07-08 18:25:21 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:21 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:21 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:21 --> URI Class Initialized
INFO - 2018-07-08 18:25:21 --> Router Class Initialized
INFO - 2018-07-08 18:25:21 --> Output Class Initialized
INFO - 2018-07-08 18:25:21 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:21 --> CSRF cookie sent
INFO - 2018-07-08 18:25:21 --> Input Class Initialized
INFO - 2018-07-08 18:25:21 --> Language Class Initialized
INFO - 2018-07-08 18:25:21 --> Loader Class Initialized
INFO - 2018-07-08 18:25:21 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:21 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:21 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:21 --> Controller Class Initialized
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-08 18:25:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-08 18:25:21 --> Could not find the language line "req_email"
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-08 18:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:21 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:21 --> Total execution time: 0.0256
INFO - 2018-07-08 18:25:22 --> Config Class Initialized
INFO - 2018-07-08 18:25:22 --> Hooks Class Initialized
DEBUG - 2018-07-08 18:25:22 --> UTF-8 Support Enabled
INFO - 2018-07-08 18:25:22 --> Utf8 Class Initialized
INFO - 2018-07-08 18:25:22 --> URI Class Initialized
INFO - 2018-07-08 18:25:22 --> Router Class Initialized
INFO - 2018-07-08 18:25:22 --> Output Class Initialized
INFO - 2018-07-08 18:25:22 --> Security Class Initialized
DEBUG - 2018-07-08 18:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 18:25:22 --> CSRF cookie sent
INFO - 2018-07-08 18:25:22 --> Input Class Initialized
INFO - 2018-07-08 18:25:22 --> Language Class Initialized
INFO - 2018-07-08 18:25:22 --> Loader Class Initialized
INFO - 2018-07-08 18:25:22 --> Helper loaded: url_helper
INFO - 2018-07-08 18:25:22 --> Helper loaded: form_helper
INFO - 2018-07-08 18:25:22 --> Helper loaded: language_helper
DEBUG - 2018-07-08 18:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 18:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 18:25:22 --> User Agent Class Initialized
INFO - 2018-07-08 18:25:22 --> Controller Class Initialized
INFO - 2018-07-08 18:25:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 18:25:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 18:25:22 --> Pixel_Model class loaded
INFO - 2018-07-08 18:25:22 --> Database Driver Class Initialized
INFO - 2018-07-08 18:25:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-08 18:25:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 18:25:22 --> Final output sent to browser
DEBUG - 2018-07-08 18:25:22 --> Total execution time: 0.0372
INFO - 2018-07-08 19:01:14 --> Config Class Initialized
INFO - 2018-07-08 19:01:14 --> Hooks Class Initialized
DEBUG - 2018-07-08 19:01:14 --> UTF-8 Support Enabled
INFO - 2018-07-08 19:01:14 --> Utf8 Class Initialized
INFO - 2018-07-08 19:01:14 --> URI Class Initialized
INFO - 2018-07-08 19:01:14 --> Router Class Initialized
INFO - 2018-07-08 19:01:14 --> Output Class Initialized
INFO - 2018-07-08 19:01:14 --> Security Class Initialized
DEBUG - 2018-07-08 19:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 19:01:14 --> CSRF cookie sent
INFO - 2018-07-08 19:01:14 --> Input Class Initialized
INFO - 2018-07-08 19:01:14 --> Language Class Initialized
INFO - 2018-07-08 19:01:14 --> Loader Class Initialized
INFO - 2018-07-08 19:01:14 --> Helper loaded: url_helper
INFO - 2018-07-08 19:01:14 --> Helper loaded: form_helper
INFO - 2018-07-08 19:01:14 --> Helper loaded: language_helper
DEBUG - 2018-07-08 19:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 19:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 19:01:14 --> User Agent Class Initialized
INFO - 2018-07-08 19:01:14 --> Controller Class Initialized
INFO - 2018-07-08 19:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 19:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-08 19:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 19:01:14 --> Final output sent to browser
DEBUG - 2018-07-08 19:01:14 --> Total execution time: 0.0215
INFO - 2018-07-08 19:34:34 --> Config Class Initialized
INFO - 2018-07-08 19:34:34 --> Hooks Class Initialized
DEBUG - 2018-07-08 19:34:34 --> UTF-8 Support Enabled
INFO - 2018-07-08 19:34:34 --> Utf8 Class Initialized
INFO - 2018-07-08 19:34:34 --> URI Class Initialized
INFO - 2018-07-08 19:34:34 --> Router Class Initialized
INFO - 2018-07-08 19:34:34 --> Output Class Initialized
INFO - 2018-07-08 19:34:34 --> Security Class Initialized
DEBUG - 2018-07-08 19:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 19:34:34 --> CSRF cookie sent
INFO - 2018-07-08 19:34:34 --> Input Class Initialized
INFO - 2018-07-08 19:34:34 --> Language Class Initialized
INFO - 2018-07-08 19:34:34 --> Loader Class Initialized
INFO - 2018-07-08 19:34:34 --> Helper loaded: url_helper
INFO - 2018-07-08 19:34:34 --> Helper loaded: form_helper
INFO - 2018-07-08 19:34:34 --> Helper loaded: language_helper
DEBUG - 2018-07-08 19:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 19:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 19:34:34 --> User Agent Class Initialized
INFO - 2018-07-08 19:34:34 --> Controller Class Initialized
INFO - 2018-07-08 19:34:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 19:34:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-08 19:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 19:34:34 --> Final output sent to browser
DEBUG - 2018-07-08 19:34:34 --> Total execution time: 0.0255
INFO - 2018-07-08 21:05:26 --> Config Class Initialized
INFO - 2018-07-08 21:05:26 --> Hooks Class Initialized
DEBUG - 2018-07-08 21:05:26 --> UTF-8 Support Enabled
INFO - 2018-07-08 21:05:26 --> Utf8 Class Initialized
INFO - 2018-07-08 21:05:26 --> URI Class Initialized
INFO - 2018-07-08 21:05:26 --> Router Class Initialized
INFO - 2018-07-08 21:05:26 --> Output Class Initialized
INFO - 2018-07-08 21:05:26 --> Security Class Initialized
DEBUG - 2018-07-08 21:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 21:05:26 --> CSRF cookie sent
INFO - 2018-07-08 21:05:26 --> Input Class Initialized
INFO - 2018-07-08 21:05:26 --> Language Class Initialized
ERROR - 2018-07-08 21:05:26 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-08 21:05:29 --> Config Class Initialized
INFO - 2018-07-08 21:05:29 --> Hooks Class Initialized
DEBUG - 2018-07-08 21:05:29 --> UTF-8 Support Enabled
INFO - 2018-07-08 21:05:29 --> Utf8 Class Initialized
INFO - 2018-07-08 21:05:29 --> URI Class Initialized
INFO - 2018-07-08 21:05:29 --> Router Class Initialized
INFO - 2018-07-08 21:05:29 --> Output Class Initialized
INFO - 2018-07-08 21:05:29 --> Security Class Initialized
DEBUG - 2018-07-08 21:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-08 21:05:29 --> CSRF cookie sent
INFO - 2018-07-08 21:05:29 --> Input Class Initialized
INFO - 2018-07-08 21:05:29 --> Language Class Initialized
INFO - 2018-07-08 21:05:29 --> Loader Class Initialized
INFO - 2018-07-08 21:05:29 --> Helper loaded: url_helper
INFO - 2018-07-08 21:05:29 --> Helper loaded: form_helper
INFO - 2018-07-08 21:05:29 --> Helper loaded: language_helper
DEBUG - 2018-07-08 21:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-08 21:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-08 21:05:29 --> User Agent Class Initialized
INFO - 2018-07-08 21:05:29 --> Controller Class Initialized
INFO - 2018-07-08 21:05:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-08 21:05:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-08 21:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-08 21:05:29 --> Final output sent to browser
DEBUG - 2018-07-08 21:05:29 --> Total execution time: 0.0241

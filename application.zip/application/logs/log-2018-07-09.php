<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-09 01:52:04 --> Config Class Initialized
INFO - 2018-07-09 01:52:04 --> Hooks Class Initialized
DEBUG - 2018-07-09 01:52:04 --> UTF-8 Support Enabled
INFO - 2018-07-09 01:52:04 --> Utf8 Class Initialized
INFO - 2018-07-09 01:52:04 --> URI Class Initialized
DEBUG - 2018-07-09 01:52:04 --> No URI present. Default controller set.
INFO - 2018-07-09 01:52:04 --> Router Class Initialized
INFO - 2018-07-09 01:52:04 --> Output Class Initialized
INFO - 2018-07-09 01:52:04 --> Security Class Initialized
DEBUG - 2018-07-09 01:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 01:52:04 --> CSRF cookie sent
INFO - 2018-07-09 01:52:04 --> Input Class Initialized
INFO - 2018-07-09 01:52:04 --> Language Class Initialized
INFO - 2018-07-09 01:52:04 --> Loader Class Initialized
INFO - 2018-07-09 01:52:04 --> Helper loaded: url_helper
INFO - 2018-07-09 01:52:04 --> Helper loaded: form_helper
INFO - 2018-07-09 01:52:04 --> Helper loaded: language_helper
DEBUG - 2018-07-09 01:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 01:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 01:52:04 --> User Agent Class Initialized
INFO - 2018-07-09 01:52:04 --> Controller Class Initialized
INFO - 2018-07-09 01:52:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 01:52:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 01:52:04 --> Pixel_Model class loaded
INFO - 2018-07-09 01:52:04 --> Database Driver Class Initialized
INFO - 2018-07-09 01:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 01:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 01:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 01:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 01:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 01:52:04 --> Final output sent to browser
DEBUG - 2018-07-09 01:52:04 --> Total execution time: 0.0330
INFO - 2018-07-09 08:11:54 --> Config Class Initialized
INFO - 2018-07-09 08:11:54 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:11:54 --> UTF-8 Support Enabled
INFO - 2018-07-09 08:11:54 --> Utf8 Class Initialized
INFO - 2018-07-09 08:11:54 --> URI Class Initialized
INFO - 2018-07-09 08:11:54 --> Router Class Initialized
INFO - 2018-07-09 08:11:54 --> Output Class Initialized
INFO - 2018-07-09 08:11:54 --> Security Class Initialized
DEBUG - 2018-07-09 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 08:11:54 --> CSRF cookie sent
INFO - 2018-07-09 08:11:54 --> Input Class Initialized
INFO - 2018-07-09 08:11:54 --> Language Class Initialized
ERROR - 2018-07-09 08:11:54 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-09 08:11:56 --> Config Class Initialized
INFO - 2018-07-09 08:11:56 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:11:56 --> UTF-8 Support Enabled
INFO - 2018-07-09 08:11:56 --> Utf8 Class Initialized
INFO - 2018-07-09 08:11:56 --> URI Class Initialized
INFO - 2018-07-09 08:11:56 --> Router Class Initialized
INFO - 2018-07-09 08:11:56 --> Output Class Initialized
INFO - 2018-07-09 08:11:56 --> Security Class Initialized
DEBUG - 2018-07-09 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 08:11:56 --> CSRF cookie sent
INFO - 2018-07-09 08:11:56 --> Input Class Initialized
INFO - 2018-07-09 08:11:56 --> Language Class Initialized
INFO - 2018-07-09 08:11:56 --> Loader Class Initialized
INFO - 2018-07-09 08:11:57 --> Helper loaded: url_helper
INFO - 2018-07-09 08:11:57 --> Helper loaded: form_helper
INFO - 2018-07-09 08:11:57 --> Helper loaded: language_helper
DEBUG - 2018-07-09 08:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 08:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 08:11:57 --> User Agent Class Initialized
INFO - 2018-07-09 08:11:57 --> Controller Class Initialized
INFO - 2018-07-09 08:11:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 08:11:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 08:11:57 --> Pixel_Model class loaded
INFO - 2018-07-09 08:11:57 --> Database Driver Class Initialized
INFO - 2018-07-09 08:11:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-09 08:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 08:11:57 --> Final output sent to browser
DEBUG - 2018-07-09 08:11:57 --> Total execution time: 0.0364
INFO - 2018-07-09 08:59:20 --> Config Class Initialized
INFO - 2018-07-09 08:59:20 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:59:20 --> UTF-8 Support Enabled
INFO - 2018-07-09 08:59:20 --> Utf8 Class Initialized
INFO - 2018-07-09 08:59:20 --> URI Class Initialized
DEBUG - 2018-07-09 08:59:20 --> No URI present. Default controller set.
INFO - 2018-07-09 08:59:20 --> Router Class Initialized
INFO - 2018-07-09 08:59:20 --> Output Class Initialized
INFO - 2018-07-09 08:59:20 --> Security Class Initialized
DEBUG - 2018-07-09 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 08:59:20 --> CSRF cookie sent
INFO - 2018-07-09 08:59:20 --> Input Class Initialized
INFO - 2018-07-09 08:59:20 --> Language Class Initialized
INFO - 2018-07-09 08:59:20 --> Loader Class Initialized
INFO - 2018-07-09 08:59:20 --> Helper loaded: url_helper
INFO - 2018-07-09 08:59:20 --> Helper loaded: form_helper
INFO - 2018-07-09 08:59:20 --> Helper loaded: language_helper
DEBUG - 2018-07-09 08:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 08:59:20 --> User Agent Class Initialized
INFO - 2018-07-09 08:59:20 --> Controller Class Initialized
INFO - 2018-07-09 08:59:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 08:59:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 08:59:20 --> Pixel_Model class loaded
INFO - 2018-07-09 08:59:20 --> Database Driver Class Initialized
INFO - 2018-07-09 08:59:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 08:59:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 08:59:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 08:59:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 08:59:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 08:59:20 --> Final output sent to browser
DEBUG - 2018-07-09 08:59:20 --> Total execution time: 0.0319
INFO - 2018-07-09 09:50:17 --> Config Class Initialized
INFO - 2018-07-09 09:50:17 --> Hooks Class Initialized
DEBUG - 2018-07-09 09:50:17 --> UTF-8 Support Enabled
INFO - 2018-07-09 09:50:17 --> Utf8 Class Initialized
INFO - 2018-07-09 09:50:17 --> URI Class Initialized
DEBUG - 2018-07-09 09:50:17 --> No URI present. Default controller set.
INFO - 2018-07-09 09:50:17 --> Router Class Initialized
INFO - 2018-07-09 09:50:17 --> Output Class Initialized
INFO - 2018-07-09 09:50:17 --> Security Class Initialized
DEBUG - 2018-07-09 09:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 09:50:17 --> CSRF cookie sent
INFO - 2018-07-09 09:50:17 --> Input Class Initialized
INFO - 2018-07-09 09:50:17 --> Language Class Initialized
INFO - 2018-07-09 09:50:17 --> Loader Class Initialized
INFO - 2018-07-09 09:50:17 --> Helper loaded: url_helper
INFO - 2018-07-09 09:50:17 --> Helper loaded: form_helper
INFO - 2018-07-09 09:50:17 --> Helper loaded: language_helper
DEBUG - 2018-07-09 09:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 09:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 09:50:17 --> User Agent Class Initialized
INFO - 2018-07-09 09:50:17 --> Controller Class Initialized
INFO - 2018-07-09 09:50:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 09:50:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 09:50:17 --> Pixel_Model class loaded
INFO - 2018-07-09 09:50:17 --> Database Driver Class Initialized
INFO - 2018-07-09 09:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 09:50:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 09:50:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 09:50:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 09:50:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 09:50:17 --> Final output sent to browser
DEBUG - 2018-07-09 09:50:17 --> Total execution time: 0.0313
INFO - 2018-07-09 14:53:26 --> Config Class Initialized
INFO - 2018-07-09 14:53:26 --> Hooks Class Initialized
DEBUG - 2018-07-09 14:53:26 --> UTF-8 Support Enabled
INFO - 2018-07-09 14:53:26 --> Utf8 Class Initialized
INFO - 2018-07-09 14:53:26 --> URI Class Initialized
INFO - 2018-07-09 14:53:26 --> Router Class Initialized
INFO - 2018-07-09 14:53:26 --> Output Class Initialized
INFO - 2018-07-09 14:53:26 --> Security Class Initialized
DEBUG - 2018-07-09 14:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 14:53:26 --> CSRF cookie sent
INFO - 2018-07-09 14:53:26 --> Input Class Initialized
INFO - 2018-07-09 14:53:26 --> Language Class Initialized
INFO - 2018-07-09 14:53:26 --> Loader Class Initialized
INFO - 2018-07-09 14:53:26 --> Helper loaded: url_helper
INFO - 2018-07-09 14:53:26 --> Helper loaded: form_helper
INFO - 2018-07-09 14:53:26 --> Helper loaded: language_helper
DEBUG - 2018-07-09 14:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 14:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 14:53:26 --> User Agent Class Initialized
INFO - 2018-07-09 14:53:26 --> Controller Class Initialized
INFO - 2018-07-09 14:53:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 14:53:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-09 14:53:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 14:53:26 --> Final output sent to browser
DEBUG - 2018-07-09 14:53:26 --> Total execution time: 0.0203
INFO - 2018-07-09 15:28:27 --> Config Class Initialized
INFO - 2018-07-09 15:28:27 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:27 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:27 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:27 --> URI Class Initialized
DEBUG - 2018-07-09 15:28:27 --> No URI present. Default controller set.
INFO - 2018-07-09 15:28:27 --> Router Class Initialized
INFO - 2018-07-09 15:28:27 --> Output Class Initialized
INFO - 2018-07-09 15:28:27 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:27 --> CSRF cookie sent
INFO - 2018-07-09 15:28:27 --> Input Class Initialized
INFO - 2018-07-09 15:28:27 --> Language Class Initialized
INFO - 2018-07-09 15:28:27 --> Loader Class Initialized
INFO - 2018-07-09 15:28:27 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:27 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:27 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:27 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:27 --> Controller Class Initialized
INFO - 2018-07-09 15:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:27 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:27 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 15:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:27 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:27 --> Total execution time: 0.0361
INFO - 2018-07-09 15:28:28 --> Config Class Initialized
INFO - 2018-07-09 15:28:28 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:28 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:28 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:28 --> URI Class Initialized
DEBUG - 2018-07-09 15:28:28 --> No URI present. Default controller set.
INFO - 2018-07-09 15:28:28 --> Router Class Initialized
INFO - 2018-07-09 15:28:28 --> Output Class Initialized
INFO - 2018-07-09 15:28:28 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:28 --> CSRF cookie sent
INFO - 2018-07-09 15:28:28 --> Input Class Initialized
INFO - 2018-07-09 15:28:28 --> Language Class Initialized
INFO - 2018-07-09 15:28:28 --> Loader Class Initialized
INFO - 2018-07-09 15:28:28 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:28 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:28 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:28 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:28 --> Controller Class Initialized
INFO - 2018-07-09 15:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:28 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:28 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 15:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:28 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:28 --> Total execution time: 0.0318
INFO - 2018-07-09 15:28:29 --> Config Class Initialized
INFO - 2018-07-09 15:28:29 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:29 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:29 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:29 --> URI Class Initialized
DEBUG - 2018-07-09 15:28:29 --> No URI present. Default controller set.
INFO - 2018-07-09 15:28:29 --> Router Class Initialized
INFO - 2018-07-09 15:28:29 --> Output Class Initialized
INFO - 2018-07-09 15:28:29 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:29 --> CSRF cookie sent
INFO - 2018-07-09 15:28:29 --> Input Class Initialized
INFO - 2018-07-09 15:28:29 --> Language Class Initialized
INFO - 2018-07-09 15:28:29 --> Loader Class Initialized
INFO - 2018-07-09 15:28:29 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:29 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:29 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:29 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:29 --> Controller Class Initialized
INFO - 2018-07-09 15:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:29 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:29 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 15:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:29 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:29 --> Total execution time: 0.0348
INFO - 2018-07-09 15:28:30 --> Config Class Initialized
INFO - 2018-07-09 15:28:30 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:30 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:30 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:30 --> URI Class Initialized
INFO - 2018-07-09 15:28:30 --> Router Class Initialized
INFO - 2018-07-09 15:28:30 --> Output Class Initialized
INFO - 2018-07-09 15:28:30 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:30 --> CSRF cookie sent
INFO - 2018-07-09 15:28:30 --> Input Class Initialized
INFO - 2018-07-09 15:28:30 --> Language Class Initialized
ERROR - 2018-07-09 15:28:30 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-09 15:28:38 --> Config Class Initialized
INFO - 2018-07-09 15:28:38 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:38 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:38 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:38 --> URI Class Initialized
DEBUG - 2018-07-09 15:28:38 --> No URI present. Default controller set.
INFO - 2018-07-09 15:28:38 --> Router Class Initialized
INFO - 2018-07-09 15:28:38 --> Output Class Initialized
INFO - 2018-07-09 15:28:38 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:38 --> CSRF cookie sent
INFO - 2018-07-09 15:28:38 --> Input Class Initialized
INFO - 2018-07-09 15:28:38 --> Language Class Initialized
INFO - 2018-07-09 15:28:38 --> Loader Class Initialized
INFO - 2018-07-09 15:28:38 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:38 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:38 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:38 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:38 --> Controller Class Initialized
INFO - 2018-07-09 15:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:38 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:38 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 15:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:38 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:38 --> Total execution time: 0.0384
INFO - 2018-07-09 15:28:38 --> Config Class Initialized
INFO - 2018-07-09 15:28:38 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:38 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:38 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:38 --> URI Class Initialized
INFO - 2018-07-09 15:28:38 --> Router Class Initialized
INFO - 2018-07-09 15:28:38 --> Output Class Initialized
INFO - 2018-07-09 15:28:38 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:38 --> CSRF cookie sent
INFO - 2018-07-09 15:28:38 --> Input Class Initialized
INFO - 2018-07-09 15:28:38 --> Language Class Initialized
ERROR - 2018-07-09 15:28:38 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-09 15:28:39 --> Config Class Initialized
INFO - 2018-07-09 15:28:39 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:39 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:39 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:39 --> URI Class Initialized
INFO - 2018-07-09 15:28:39 --> Router Class Initialized
INFO - 2018-07-09 15:28:39 --> Output Class Initialized
INFO - 2018-07-09 15:28:39 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:39 --> CSRF cookie sent
INFO - 2018-07-09 15:28:39 --> Input Class Initialized
INFO - 2018-07-09 15:28:39 --> Language Class Initialized
ERROR - 2018-07-09 15:28:39 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-09 15:28:39 --> Config Class Initialized
INFO - 2018-07-09 15:28:39 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:39 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:39 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:39 --> URI Class Initialized
INFO - 2018-07-09 15:28:39 --> Router Class Initialized
INFO - 2018-07-09 15:28:39 --> Output Class Initialized
INFO - 2018-07-09 15:28:39 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:39 --> CSRF cookie sent
INFO - 2018-07-09 15:28:39 --> Input Class Initialized
INFO - 2018-07-09 15:28:39 --> Language Class Initialized
INFO - 2018-07-09 15:28:39 --> Loader Class Initialized
INFO - 2018-07-09 15:28:39 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:39 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:39 --> Controller Class Initialized
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:39 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:39 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:39 --> Config Class Initialized
INFO - 2018-07-09 15:28:39 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:39 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:39 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:39 --> URI Class Initialized
INFO - 2018-07-09 15:28:39 --> Router Class Initialized
INFO - 2018-07-09 15:28:39 --> Output Class Initialized
INFO - 2018-07-09 15:28:39 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:39 --> CSRF cookie sent
INFO - 2018-07-09 15:28:39 --> Input Class Initialized
INFO - 2018-07-09 15:28:39 --> Language Class Initialized
INFO - 2018-07-09 15:28:39 --> Loader Class Initialized
INFO - 2018-07-09 15:28:39 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:39 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:39 --> Controller Class Initialized
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-09 15:28:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-09 15:28:39 --> Could not find the language line "req_email"
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:39 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:39 --> Total execution time: 0.0255
INFO - 2018-07-09 15:28:39 --> Config Class Initialized
INFO - 2018-07-09 15:28:39 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:39 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:39 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:39 --> URI Class Initialized
INFO - 2018-07-09 15:28:39 --> Router Class Initialized
INFO - 2018-07-09 15:28:39 --> Output Class Initialized
INFO - 2018-07-09 15:28:39 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:39 --> CSRF cookie sent
INFO - 2018-07-09 15:28:39 --> Input Class Initialized
INFO - 2018-07-09 15:28:39 --> Language Class Initialized
INFO - 2018-07-09 15:28:39 --> Loader Class Initialized
INFO - 2018-07-09 15:28:39 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:39 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:39 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:39 --> Controller Class Initialized
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-09 15:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:39 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:39 --> Total execution time: 0.0211
INFO - 2018-07-09 15:28:40 --> Config Class Initialized
INFO - 2018-07-09 15:28:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:40 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:40 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:40 --> URI Class Initialized
INFO - 2018-07-09 15:28:40 --> Router Class Initialized
INFO - 2018-07-09 15:28:40 --> Output Class Initialized
INFO - 2018-07-09 15:28:40 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:40 --> CSRF cookie sent
INFO - 2018-07-09 15:28:40 --> Input Class Initialized
INFO - 2018-07-09 15:28:40 --> Language Class Initialized
INFO - 2018-07-09 15:28:40 --> Loader Class Initialized
INFO - 2018-07-09 15:28:40 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:40 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:40 --> Controller Class Initialized
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:40 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:40 --> Total execution time: 0.0253
INFO - 2018-07-09 15:28:40 --> Config Class Initialized
INFO - 2018-07-09 15:28:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:40 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:40 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:40 --> URI Class Initialized
INFO - 2018-07-09 15:28:40 --> Router Class Initialized
INFO - 2018-07-09 15:28:40 --> Output Class Initialized
INFO - 2018-07-09 15:28:40 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:40 --> CSRF cookie sent
INFO - 2018-07-09 15:28:40 --> Input Class Initialized
INFO - 2018-07-09 15:28:40 --> Language Class Initialized
INFO - 2018-07-09 15:28:40 --> Loader Class Initialized
INFO - 2018-07-09 15:28:40 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:40 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:40 --> Controller Class Initialized
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:40 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:40 --> Total execution time: 0.0227
INFO - 2018-07-09 15:28:40 --> Config Class Initialized
INFO - 2018-07-09 15:28:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:40 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:40 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:40 --> URI Class Initialized
INFO - 2018-07-09 15:28:40 --> Router Class Initialized
INFO - 2018-07-09 15:28:40 --> Output Class Initialized
INFO - 2018-07-09 15:28:40 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:40 --> CSRF cookie sent
INFO - 2018-07-09 15:28:40 --> Input Class Initialized
INFO - 2018-07-09 15:28:40 --> Language Class Initialized
INFO - 2018-07-09 15:28:40 --> Loader Class Initialized
INFO - 2018-07-09 15:28:40 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:40 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:40 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:40 --> Controller Class Initialized
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-09 15:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:40 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:40 --> Total execution time: 0.0254
INFO - 2018-07-09 15:28:41 --> Config Class Initialized
INFO - 2018-07-09 15:28:41 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:41 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:41 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:41 --> URI Class Initialized
INFO - 2018-07-09 15:28:41 --> Router Class Initialized
INFO - 2018-07-09 15:28:41 --> Output Class Initialized
INFO - 2018-07-09 15:28:41 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:41 --> CSRF cookie sent
INFO - 2018-07-09 15:28:41 --> Input Class Initialized
INFO - 2018-07-09 15:28:41 --> Language Class Initialized
INFO - 2018-07-09 15:28:41 --> Loader Class Initialized
INFO - 2018-07-09 15:28:41 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:41 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:41 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:41 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:41 --> Controller Class Initialized
INFO - 2018-07-09 15:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:41 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-09 15:28:41 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-09 15:28:41 --> Could not find the language line "req_email"
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:41 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:41 --> Total execution time: 0.0231
INFO - 2018-07-09 15:28:41 --> Config Class Initialized
INFO - 2018-07-09 15:28:41 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:28:41 --> UTF-8 Support Enabled
INFO - 2018-07-09 15:28:41 --> Utf8 Class Initialized
INFO - 2018-07-09 15:28:41 --> URI Class Initialized
INFO - 2018-07-09 15:28:41 --> Router Class Initialized
INFO - 2018-07-09 15:28:41 --> Output Class Initialized
INFO - 2018-07-09 15:28:41 --> Security Class Initialized
DEBUG - 2018-07-09 15:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 15:28:41 --> CSRF cookie sent
INFO - 2018-07-09 15:28:41 --> Input Class Initialized
INFO - 2018-07-09 15:28:41 --> Language Class Initialized
INFO - 2018-07-09 15:28:41 --> Loader Class Initialized
INFO - 2018-07-09 15:28:41 --> Helper loaded: url_helper
INFO - 2018-07-09 15:28:41 --> Helper loaded: form_helper
INFO - 2018-07-09 15:28:41 --> Helper loaded: language_helper
DEBUG - 2018-07-09 15:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 15:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 15:28:41 --> User Agent Class Initialized
INFO - 2018-07-09 15:28:41 --> Controller Class Initialized
INFO - 2018-07-09 15:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 15:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 15:28:41 --> Pixel_Model class loaded
INFO - 2018-07-09 15:28:41 --> Database Driver Class Initialized
INFO - 2018-07-09 15:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-09 15:28:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 15:28:41 --> Final output sent to browser
DEBUG - 2018-07-09 15:28:41 --> Total execution time: 0.0325
INFO - 2018-07-09 16:20:11 --> Config Class Initialized
INFO - 2018-07-09 16:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-09 16:20:11 --> Utf8 Class Initialized
INFO - 2018-07-09 16:20:11 --> URI Class Initialized
DEBUG - 2018-07-09 16:20:11 --> No URI present. Default controller set.
INFO - 2018-07-09 16:20:11 --> Router Class Initialized
INFO - 2018-07-09 16:20:11 --> Output Class Initialized
INFO - 2018-07-09 16:20:11 --> Security Class Initialized
DEBUG - 2018-07-09 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 16:20:11 --> CSRF cookie sent
INFO - 2018-07-09 16:20:11 --> Input Class Initialized
INFO - 2018-07-09 16:20:11 --> Language Class Initialized
INFO - 2018-07-09 16:20:11 --> Loader Class Initialized
INFO - 2018-07-09 16:20:11 --> Helper loaded: url_helper
INFO - 2018-07-09 16:20:11 --> Helper loaded: form_helper
INFO - 2018-07-09 16:20:11 --> Helper loaded: language_helper
DEBUG - 2018-07-09 16:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 16:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 16:20:11 --> User Agent Class Initialized
INFO - 2018-07-09 16:20:11 --> Controller Class Initialized
INFO - 2018-07-09 16:20:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 16:20:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 16:20:11 --> Pixel_Model class loaded
INFO - 2018-07-09 16:20:11 --> Database Driver Class Initialized
INFO - 2018-07-09 16:20:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 16:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 16:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 16:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 16:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 16:20:11 --> Final output sent to browser
DEBUG - 2018-07-09 16:20:11 --> Total execution time: 0.0351
INFO - 2018-07-09 16:20:11 --> Config Class Initialized
INFO - 2018-07-09 16:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-09 16:20:11 --> Utf8 Class Initialized
INFO - 2018-07-09 16:20:11 --> URI Class Initialized
INFO - 2018-07-09 16:20:11 --> Router Class Initialized
INFO - 2018-07-09 16:20:11 --> Output Class Initialized
INFO - 2018-07-09 16:20:11 --> Security Class Initialized
DEBUG - 2018-07-09 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 16:20:11 --> CSRF cookie sent
INFO - 2018-07-09 16:20:11 --> Input Class Initialized
INFO - 2018-07-09 16:20:11 --> Language Class Initialized
ERROR - 2018-07-09 16:20:11 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-09 16:20:11 --> Config Class Initialized
INFO - 2018-07-09 16:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-09 16:20:11 --> Utf8 Class Initialized
INFO - 2018-07-09 16:20:11 --> URI Class Initialized
INFO - 2018-07-09 16:20:11 --> Router Class Initialized
INFO - 2018-07-09 16:20:11 --> Output Class Initialized
INFO - 2018-07-09 16:20:11 --> Security Class Initialized
DEBUG - 2018-07-09 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 16:20:11 --> CSRF cookie sent
INFO - 2018-07-09 16:20:11 --> Input Class Initialized
INFO - 2018-07-09 16:20:11 --> Language Class Initialized
ERROR - 2018-07-09 16:20:11 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-09 16:20:11 --> Config Class Initialized
INFO - 2018-07-09 16:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-09 16:20:11 --> Utf8 Class Initialized
INFO - 2018-07-09 16:20:11 --> URI Class Initialized
INFO - 2018-07-09 16:20:11 --> Router Class Initialized
INFO - 2018-07-09 16:20:11 --> Output Class Initialized
INFO - 2018-07-09 16:20:11 --> Security Class Initialized
DEBUG - 2018-07-09 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 16:20:11 --> CSRF cookie sent
INFO - 2018-07-09 16:20:11 --> Input Class Initialized
INFO - 2018-07-09 16:20:11 --> Language Class Initialized
ERROR - 2018-07-09 16:20:11 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-09 16:20:13 --> Config Class Initialized
INFO - 2018-07-09 16:20:13 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:20:13 --> UTF-8 Support Enabled
INFO - 2018-07-09 16:20:13 --> Utf8 Class Initialized
INFO - 2018-07-09 16:20:13 --> URI Class Initialized
INFO - 2018-07-09 16:20:13 --> Router Class Initialized
INFO - 2018-07-09 16:20:13 --> Output Class Initialized
INFO - 2018-07-09 16:20:13 --> Security Class Initialized
DEBUG - 2018-07-09 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 16:20:13 --> CSRF cookie sent
INFO - 2018-07-09 16:20:13 --> Input Class Initialized
INFO - 2018-07-09 16:20:13 --> Language Class Initialized
ERROR - 2018-07-09 16:20:13 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-09 17:28:48 --> Config Class Initialized
INFO - 2018-07-09 17:28:48 --> Hooks Class Initialized
DEBUG - 2018-07-09 17:28:48 --> UTF-8 Support Enabled
INFO - 2018-07-09 17:28:48 --> Utf8 Class Initialized
INFO - 2018-07-09 17:28:48 --> URI Class Initialized
INFO - 2018-07-09 17:28:48 --> Router Class Initialized
INFO - 2018-07-09 17:28:48 --> Output Class Initialized
INFO - 2018-07-09 17:28:48 --> Security Class Initialized
DEBUG - 2018-07-09 17:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 17:28:48 --> CSRF cookie sent
INFO - 2018-07-09 17:28:48 --> Input Class Initialized
INFO - 2018-07-09 17:28:48 --> Language Class Initialized
ERROR - 2018-07-09 17:28:48 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-09 18:15:19 --> Config Class Initialized
INFO - 2018-07-09 18:15:19 --> Hooks Class Initialized
DEBUG - 2018-07-09 18:15:19 --> UTF-8 Support Enabled
INFO - 2018-07-09 18:15:19 --> Utf8 Class Initialized
INFO - 2018-07-09 18:15:19 --> URI Class Initialized
DEBUG - 2018-07-09 18:15:19 --> No URI present. Default controller set.
INFO - 2018-07-09 18:15:19 --> Router Class Initialized
INFO - 2018-07-09 18:15:19 --> Output Class Initialized
INFO - 2018-07-09 18:15:19 --> Security Class Initialized
DEBUG - 2018-07-09 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 18:15:19 --> CSRF cookie sent
INFO - 2018-07-09 18:15:19 --> Input Class Initialized
INFO - 2018-07-09 18:15:19 --> Language Class Initialized
INFO - 2018-07-09 18:15:19 --> Loader Class Initialized
INFO - 2018-07-09 18:15:19 --> Helper loaded: url_helper
INFO - 2018-07-09 18:15:19 --> Helper loaded: form_helper
INFO - 2018-07-09 18:15:19 --> Helper loaded: language_helper
DEBUG - 2018-07-09 18:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 18:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 18:15:19 --> User Agent Class Initialized
INFO - 2018-07-09 18:15:19 --> Controller Class Initialized
INFO - 2018-07-09 18:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 18:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 18:15:19 --> Pixel_Model class loaded
INFO - 2018-07-09 18:15:19 --> Database Driver Class Initialized
INFO - 2018-07-09 18:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 18:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 18:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 18:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 18:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 18:15:19 --> Final output sent to browser
DEBUG - 2018-07-09 18:15:19 --> Total execution time: 0.0344
INFO - 2018-07-09 18:18:09 --> Config Class Initialized
INFO - 2018-07-09 18:18:09 --> Hooks Class Initialized
DEBUG - 2018-07-09 18:18:09 --> UTF-8 Support Enabled
INFO - 2018-07-09 18:18:09 --> Utf8 Class Initialized
INFO - 2018-07-09 18:18:09 --> URI Class Initialized
INFO - 2018-07-09 18:18:09 --> Router Class Initialized
INFO - 2018-07-09 18:18:09 --> Output Class Initialized
INFO - 2018-07-09 18:18:09 --> Security Class Initialized
DEBUG - 2018-07-09 18:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 18:18:09 --> CSRF cookie sent
INFO - 2018-07-09 18:18:09 --> Input Class Initialized
INFO - 2018-07-09 18:18:09 --> Language Class Initialized
ERROR - 2018-07-09 18:18:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-09 19:58:24 --> Config Class Initialized
INFO - 2018-07-09 19:58:24 --> Hooks Class Initialized
DEBUG - 2018-07-09 19:58:24 --> UTF-8 Support Enabled
INFO - 2018-07-09 19:58:24 --> Utf8 Class Initialized
INFO - 2018-07-09 19:58:24 --> URI Class Initialized
DEBUG - 2018-07-09 19:58:24 --> No URI present. Default controller set.
INFO - 2018-07-09 19:58:24 --> Router Class Initialized
INFO - 2018-07-09 19:58:24 --> Output Class Initialized
INFO - 2018-07-09 19:58:24 --> Security Class Initialized
DEBUG - 2018-07-09 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 19:58:24 --> CSRF cookie sent
INFO - 2018-07-09 19:58:24 --> Input Class Initialized
INFO - 2018-07-09 19:58:24 --> Language Class Initialized
INFO - 2018-07-09 19:58:24 --> Loader Class Initialized
INFO - 2018-07-09 19:58:24 --> Helper loaded: url_helper
INFO - 2018-07-09 19:58:24 --> Helper loaded: form_helper
INFO - 2018-07-09 19:58:24 --> Helper loaded: language_helper
DEBUG - 2018-07-09 19:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 19:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 19:58:24 --> User Agent Class Initialized
INFO - 2018-07-09 19:58:24 --> Controller Class Initialized
INFO - 2018-07-09 19:58:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 19:58:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 19:58:24 --> Pixel_Model class loaded
INFO - 2018-07-09 19:58:24 --> Database Driver Class Initialized
INFO - 2018-07-09 19:58:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 19:58:24 --> Final output sent to browser
DEBUG - 2018-07-09 19:58:24 --> Total execution time: 0.0325
INFO - 2018-07-09 23:03:31 --> Config Class Initialized
INFO - 2018-07-09 23:03:31 --> Hooks Class Initialized
DEBUG - 2018-07-09 23:03:31 --> UTF-8 Support Enabled
INFO - 2018-07-09 23:03:31 --> Utf8 Class Initialized
INFO - 2018-07-09 23:03:31 --> URI Class Initialized
DEBUG - 2018-07-09 23:03:31 --> No URI present. Default controller set.
INFO - 2018-07-09 23:03:31 --> Router Class Initialized
INFO - 2018-07-09 23:03:31 --> Output Class Initialized
INFO - 2018-07-09 23:03:31 --> Security Class Initialized
DEBUG - 2018-07-09 23:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-09 23:03:31 --> CSRF cookie sent
INFO - 2018-07-09 23:03:31 --> Input Class Initialized
INFO - 2018-07-09 23:03:31 --> Language Class Initialized
INFO - 2018-07-09 23:03:31 --> Loader Class Initialized
INFO - 2018-07-09 23:03:31 --> Helper loaded: url_helper
INFO - 2018-07-09 23:03:31 --> Helper loaded: form_helper
INFO - 2018-07-09 23:03:31 --> Helper loaded: language_helper
DEBUG - 2018-07-09 23:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-09 23:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-09 23:03:31 --> User Agent Class Initialized
INFO - 2018-07-09 23:03:31 --> Controller Class Initialized
INFO - 2018-07-09 23:03:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-09 23:03:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-09 23:03:31 --> Pixel_Model class loaded
INFO - 2018-07-09 23:03:31 --> Database Driver Class Initialized
INFO - 2018-07-09 23:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-09 23:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-09 23:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-09 23:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-09 23:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-09 23:03:31 --> Final output sent to browser
DEBUG - 2018-07-09 23:03:31 --> Total execution time: 0.0372

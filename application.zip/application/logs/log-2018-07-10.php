<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-10 00:24:59 --> Config Class Initialized
INFO - 2018-07-10 00:24:59 --> Hooks Class Initialized
DEBUG - 2018-07-10 00:24:59 --> UTF-8 Support Enabled
INFO - 2018-07-10 00:24:59 --> Utf8 Class Initialized
INFO - 2018-07-10 00:24:59 --> URI Class Initialized
INFO - 2018-07-10 00:24:59 --> Router Class Initialized
INFO - 2018-07-10 00:24:59 --> Output Class Initialized
INFO - 2018-07-10 00:24:59 --> Security Class Initialized
DEBUG - 2018-07-10 00:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 00:24:59 --> CSRF cookie sent
INFO - 2018-07-10 00:24:59 --> Input Class Initialized
INFO - 2018-07-10 00:24:59 --> Language Class Initialized
ERROR - 2018-07-10 00:24:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 00:57:53 --> Config Class Initialized
INFO - 2018-07-10 00:57:53 --> Hooks Class Initialized
DEBUG - 2018-07-10 00:57:53 --> UTF-8 Support Enabled
INFO - 2018-07-10 00:57:53 --> Utf8 Class Initialized
INFO - 2018-07-10 00:57:53 --> URI Class Initialized
DEBUG - 2018-07-10 00:57:53 --> No URI present. Default controller set.
INFO - 2018-07-10 00:57:53 --> Router Class Initialized
INFO - 2018-07-10 00:57:53 --> Output Class Initialized
INFO - 2018-07-10 00:57:53 --> Security Class Initialized
DEBUG - 2018-07-10 00:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 00:57:53 --> CSRF cookie sent
INFO - 2018-07-10 00:57:53 --> Input Class Initialized
INFO - 2018-07-10 00:57:53 --> Language Class Initialized
INFO - 2018-07-10 00:57:53 --> Loader Class Initialized
INFO - 2018-07-10 00:57:53 --> Helper loaded: url_helper
INFO - 2018-07-10 00:57:53 --> Helper loaded: form_helper
INFO - 2018-07-10 00:57:53 --> Helper loaded: language_helper
DEBUG - 2018-07-10 00:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 00:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 00:57:53 --> User Agent Class Initialized
INFO - 2018-07-10 00:57:53 --> Controller Class Initialized
INFO - 2018-07-10 00:57:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 00:57:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 00:57:53 --> Pixel_Model class loaded
INFO - 2018-07-10 00:57:53 --> Database Driver Class Initialized
INFO - 2018-07-10 00:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 00:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 00:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 00:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 00:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 00:57:53 --> Final output sent to browser
DEBUG - 2018-07-10 00:57:53 --> Total execution time: 0.0345
INFO - 2018-07-10 02:35:36 --> Config Class Initialized
INFO - 2018-07-10 02:35:36 --> Hooks Class Initialized
DEBUG - 2018-07-10 02:35:36 --> UTF-8 Support Enabled
INFO - 2018-07-10 02:35:36 --> Utf8 Class Initialized
INFO - 2018-07-10 02:35:36 --> URI Class Initialized
DEBUG - 2018-07-10 02:35:36 --> No URI present. Default controller set.
INFO - 2018-07-10 02:35:36 --> Router Class Initialized
INFO - 2018-07-10 02:35:36 --> Output Class Initialized
INFO - 2018-07-10 02:35:36 --> Security Class Initialized
DEBUG - 2018-07-10 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 02:35:36 --> CSRF cookie sent
INFO - 2018-07-10 02:35:36 --> Input Class Initialized
INFO - 2018-07-10 02:35:36 --> Language Class Initialized
INFO - 2018-07-10 02:35:36 --> Loader Class Initialized
INFO - 2018-07-10 02:35:36 --> Helper loaded: url_helper
INFO - 2018-07-10 02:35:36 --> Helper loaded: form_helper
INFO - 2018-07-10 02:35:36 --> Helper loaded: language_helper
DEBUG - 2018-07-10 02:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 02:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 02:35:36 --> User Agent Class Initialized
INFO - 2018-07-10 02:35:36 --> Controller Class Initialized
INFO - 2018-07-10 02:35:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 02:35:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 02:35:36 --> Pixel_Model class loaded
INFO - 2018-07-10 02:35:36 --> Database Driver Class Initialized
INFO - 2018-07-10 02:35:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 02:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 02:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 02:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 02:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 02:35:36 --> Final output sent to browser
DEBUG - 2018-07-10 02:35:36 --> Total execution time: 0.0503
INFO - 2018-07-10 02:45:30 --> Config Class Initialized
INFO - 2018-07-10 02:45:30 --> Hooks Class Initialized
DEBUG - 2018-07-10 02:45:30 --> UTF-8 Support Enabled
INFO - 2018-07-10 02:45:30 --> Utf8 Class Initialized
INFO - 2018-07-10 02:45:30 --> URI Class Initialized
DEBUG - 2018-07-10 02:45:30 --> No URI present. Default controller set.
INFO - 2018-07-10 02:45:30 --> Router Class Initialized
INFO - 2018-07-10 02:45:30 --> Output Class Initialized
INFO - 2018-07-10 02:45:30 --> Security Class Initialized
DEBUG - 2018-07-10 02:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 02:45:30 --> CSRF cookie sent
INFO - 2018-07-10 02:45:30 --> Input Class Initialized
INFO - 2018-07-10 02:45:30 --> Language Class Initialized
INFO - 2018-07-10 02:45:30 --> Loader Class Initialized
INFO - 2018-07-10 02:45:30 --> Helper loaded: url_helper
INFO - 2018-07-10 02:45:30 --> Helper loaded: form_helper
INFO - 2018-07-10 02:45:30 --> Helper loaded: language_helper
DEBUG - 2018-07-10 02:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 02:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 02:45:30 --> User Agent Class Initialized
INFO - 2018-07-10 02:45:30 --> Controller Class Initialized
INFO - 2018-07-10 02:45:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 02:45:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 02:45:30 --> Pixel_Model class loaded
INFO - 2018-07-10 02:45:30 --> Database Driver Class Initialized
INFO - 2018-07-10 02:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 02:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 02:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 02:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 02:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 02:45:30 --> Final output sent to browser
DEBUG - 2018-07-10 02:45:30 --> Total execution time: 0.0367
INFO - 2018-07-10 04:58:49 --> Config Class Initialized
INFO - 2018-07-10 04:58:49 --> Hooks Class Initialized
DEBUG - 2018-07-10 04:58:49 --> UTF-8 Support Enabled
INFO - 2018-07-10 04:58:49 --> Utf8 Class Initialized
INFO - 2018-07-10 04:58:49 --> URI Class Initialized
DEBUG - 2018-07-10 04:58:49 --> No URI present. Default controller set.
INFO - 2018-07-10 04:58:49 --> Router Class Initialized
INFO - 2018-07-10 04:58:49 --> Output Class Initialized
INFO - 2018-07-10 04:58:49 --> Security Class Initialized
DEBUG - 2018-07-10 04:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 04:58:49 --> CSRF cookie sent
INFO - 2018-07-10 04:58:49 --> Input Class Initialized
INFO - 2018-07-10 04:58:49 --> Language Class Initialized
INFO - 2018-07-10 04:58:49 --> Loader Class Initialized
INFO - 2018-07-10 04:58:49 --> Helper loaded: url_helper
INFO - 2018-07-10 04:58:49 --> Helper loaded: form_helper
INFO - 2018-07-10 04:58:49 --> Helper loaded: language_helper
DEBUG - 2018-07-10 04:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 04:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 04:58:49 --> User Agent Class Initialized
INFO - 2018-07-10 04:58:49 --> Controller Class Initialized
INFO - 2018-07-10 04:58:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 04:58:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 04:58:49 --> Pixel_Model class loaded
INFO - 2018-07-10 04:58:49 --> Database Driver Class Initialized
INFO - 2018-07-10 04:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 04:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 04:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 04:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 04:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 04:58:49 --> Final output sent to browser
DEBUG - 2018-07-10 04:58:49 --> Total execution time: 0.0378
INFO - 2018-07-10 06:44:40 --> Config Class Initialized
INFO - 2018-07-10 06:44:40 --> Hooks Class Initialized
DEBUG - 2018-07-10 06:44:40 --> UTF-8 Support Enabled
INFO - 2018-07-10 06:44:40 --> Utf8 Class Initialized
INFO - 2018-07-10 06:44:40 --> URI Class Initialized
INFO - 2018-07-10 06:44:40 --> Router Class Initialized
INFO - 2018-07-10 06:44:40 --> Output Class Initialized
INFO - 2018-07-10 06:44:40 --> Security Class Initialized
DEBUG - 2018-07-10 06:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 06:44:40 --> CSRF cookie sent
INFO - 2018-07-10 06:44:40 --> Input Class Initialized
INFO - 2018-07-10 06:44:40 --> Language Class Initialized
ERROR - 2018-07-10 06:44:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 06:44:42 --> Config Class Initialized
INFO - 2018-07-10 06:44:42 --> Hooks Class Initialized
DEBUG - 2018-07-10 06:44:42 --> UTF-8 Support Enabled
INFO - 2018-07-10 06:44:42 --> Utf8 Class Initialized
INFO - 2018-07-10 06:44:42 --> URI Class Initialized
DEBUG - 2018-07-10 06:44:42 --> No URI present. Default controller set.
INFO - 2018-07-10 06:44:42 --> Router Class Initialized
INFO - 2018-07-10 06:44:42 --> Output Class Initialized
INFO - 2018-07-10 06:44:42 --> Security Class Initialized
DEBUG - 2018-07-10 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 06:44:42 --> CSRF cookie sent
INFO - 2018-07-10 06:44:42 --> Input Class Initialized
INFO - 2018-07-10 06:44:42 --> Language Class Initialized
INFO - 2018-07-10 06:44:42 --> Loader Class Initialized
INFO - 2018-07-10 06:44:42 --> Helper loaded: url_helper
INFO - 2018-07-10 06:44:42 --> Helper loaded: form_helper
INFO - 2018-07-10 06:44:42 --> Helper loaded: language_helper
DEBUG - 2018-07-10 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 06:44:42 --> User Agent Class Initialized
INFO - 2018-07-10 06:44:42 --> Controller Class Initialized
INFO - 2018-07-10 06:44:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 06:44:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 06:44:42 --> Pixel_Model class loaded
INFO - 2018-07-10 06:44:42 --> Database Driver Class Initialized
INFO - 2018-07-10 06:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 06:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 06:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 06:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 06:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 06:44:42 --> Final output sent to browser
DEBUG - 2018-07-10 06:44:42 --> Total execution time: 0.0332
INFO - 2018-07-10 08:06:47 --> Config Class Initialized
INFO - 2018-07-10 08:06:47 --> Hooks Class Initialized
DEBUG - 2018-07-10 08:06:47 --> UTF-8 Support Enabled
INFO - 2018-07-10 08:06:47 --> Utf8 Class Initialized
INFO - 2018-07-10 08:06:47 --> URI Class Initialized
DEBUG - 2018-07-10 08:06:47 --> No URI present. Default controller set.
INFO - 2018-07-10 08:06:47 --> Router Class Initialized
INFO - 2018-07-10 08:06:47 --> Output Class Initialized
INFO - 2018-07-10 08:06:47 --> Security Class Initialized
DEBUG - 2018-07-10 08:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 08:06:47 --> CSRF cookie sent
INFO - 2018-07-10 08:06:47 --> Input Class Initialized
INFO - 2018-07-10 08:06:47 --> Language Class Initialized
INFO - 2018-07-10 08:06:47 --> Loader Class Initialized
INFO - 2018-07-10 08:06:47 --> Helper loaded: url_helper
INFO - 2018-07-10 08:06:47 --> Helper loaded: form_helper
INFO - 2018-07-10 08:06:47 --> Helper loaded: language_helper
DEBUG - 2018-07-10 08:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 08:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 08:06:47 --> User Agent Class Initialized
INFO - 2018-07-10 08:06:47 --> Controller Class Initialized
INFO - 2018-07-10 08:06:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 08:06:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 08:06:47 --> Pixel_Model class loaded
INFO - 2018-07-10 08:06:47 --> Database Driver Class Initialized
INFO - 2018-07-10 08:06:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 08:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 08:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 08:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 08:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 08:06:47 --> Final output sent to browser
DEBUG - 2018-07-10 08:06:47 --> Total execution time: 0.0464
INFO - 2018-07-10 08:58:21 --> Config Class Initialized
INFO - 2018-07-10 08:58:21 --> Hooks Class Initialized
DEBUG - 2018-07-10 08:58:21 --> UTF-8 Support Enabled
INFO - 2018-07-10 08:58:21 --> Utf8 Class Initialized
INFO - 2018-07-10 08:58:21 --> URI Class Initialized
INFO - 2018-07-10 08:58:21 --> Router Class Initialized
INFO - 2018-07-10 08:58:21 --> Output Class Initialized
INFO - 2018-07-10 08:58:21 --> Security Class Initialized
DEBUG - 2018-07-10 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 08:58:21 --> CSRF cookie sent
INFO - 2018-07-10 08:58:21 --> Input Class Initialized
INFO - 2018-07-10 08:58:21 --> Language Class Initialized
ERROR - 2018-07-10 08:58:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 08:58:24 --> Config Class Initialized
INFO - 2018-07-10 08:58:24 --> Hooks Class Initialized
DEBUG - 2018-07-10 08:58:24 --> UTF-8 Support Enabled
INFO - 2018-07-10 08:58:24 --> Utf8 Class Initialized
INFO - 2018-07-10 08:58:24 --> URI Class Initialized
INFO - 2018-07-10 08:58:24 --> Router Class Initialized
INFO - 2018-07-10 08:58:24 --> Output Class Initialized
INFO - 2018-07-10 08:58:24 --> Security Class Initialized
DEBUG - 2018-07-10 08:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 08:58:24 --> CSRF cookie sent
INFO - 2018-07-10 08:58:24 --> Input Class Initialized
INFO - 2018-07-10 08:58:24 --> Language Class Initialized
INFO - 2018-07-10 08:58:24 --> Loader Class Initialized
INFO - 2018-07-10 08:58:24 --> Helper loaded: url_helper
INFO - 2018-07-10 08:58:24 --> Helper loaded: form_helper
INFO - 2018-07-10 08:58:24 --> Helper loaded: language_helper
DEBUG - 2018-07-10 08:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 08:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 08:58:24 --> User Agent Class Initialized
INFO - 2018-07-10 08:58:24 --> Controller Class Initialized
INFO - 2018-07-10 08:58:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 08:58:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-10 08:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 08:58:24 --> Final output sent to browser
DEBUG - 2018-07-10 08:58:24 --> Total execution time: 0.0232
INFO - 2018-07-10 10:00:44 --> Config Class Initialized
INFO - 2018-07-10 10:00:44 --> Hooks Class Initialized
DEBUG - 2018-07-10 10:00:44 --> UTF-8 Support Enabled
INFO - 2018-07-10 10:00:44 --> Utf8 Class Initialized
INFO - 2018-07-10 10:00:44 --> URI Class Initialized
DEBUG - 2018-07-10 10:00:44 --> No URI present. Default controller set.
INFO - 2018-07-10 10:00:44 --> Router Class Initialized
INFO - 2018-07-10 10:00:44 --> Output Class Initialized
INFO - 2018-07-10 10:00:44 --> Security Class Initialized
DEBUG - 2018-07-10 10:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 10:00:44 --> CSRF cookie sent
INFO - 2018-07-10 10:00:44 --> Input Class Initialized
INFO - 2018-07-10 10:00:44 --> Language Class Initialized
INFO - 2018-07-10 10:00:44 --> Loader Class Initialized
INFO - 2018-07-10 10:00:44 --> Helper loaded: url_helper
INFO - 2018-07-10 10:00:44 --> Helper loaded: form_helper
INFO - 2018-07-10 10:00:44 --> Helper loaded: language_helper
DEBUG - 2018-07-10 10:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 10:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 10:00:44 --> User Agent Class Initialized
INFO - 2018-07-10 10:00:44 --> Controller Class Initialized
INFO - 2018-07-10 10:00:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 10:00:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 10:00:44 --> Pixel_Model class loaded
INFO - 2018-07-10 10:00:44 --> Database Driver Class Initialized
INFO - 2018-07-10 10:00:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 10:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 10:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 10:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 10:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 10:00:44 --> Final output sent to browser
DEBUG - 2018-07-10 10:00:44 --> Total execution time: 0.0338
INFO - 2018-07-10 11:19:42 --> Config Class Initialized
INFO - 2018-07-10 11:19:42 --> Hooks Class Initialized
DEBUG - 2018-07-10 11:19:42 --> UTF-8 Support Enabled
INFO - 2018-07-10 11:19:42 --> Utf8 Class Initialized
INFO - 2018-07-10 11:19:42 --> URI Class Initialized
DEBUG - 2018-07-10 11:19:42 --> No URI present. Default controller set.
INFO - 2018-07-10 11:19:42 --> Router Class Initialized
INFO - 2018-07-10 11:19:42 --> Output Class Initialized
INFO - 2018-07-10 11:19:42 --> Security Class Initialized
DEBUG - 2018-07-10 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 11:19:42 --> CSRF cookie sent
INFO - 2018-07-10 11:19:42 --> Input Class Initialized
INFO - 2018-07-10 11:19:42 --> Language Class Initialized
INFO - 2018-07-10 11:19:42 --> Loader Class Initialized
INFO - 2018-07-10 11:19:42 --> Helper loaded: url_helper
INFO - 2018-07-10 11:19:42 --> Helper loaded: form_helper
INFO - 2018-07-10 11:19:42 --> Helper loaded: language_helper
DEBUG - 2018-07-10 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 11:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 11:19:42 --> User Agent Class Initialized
INFO - 2018-07-10 11:19:42 --> Controller Class Initialized
INFO - 2018-07-10 11:19:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 11:19:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 11:19:42 --> Pixel_Model class loaded
INFO - 2018-07-10 11:19:42 --> Database Driver Class Initialized
INFO - 2018-07-10 11:19:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 11:19:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 11:19:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 11:19:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 11:19:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 11:19:42 --> Final output sent to browser
DEBUG - 2018-07-10 11:19:42 --> Total execution time: 0.0335
INFO - 2018-07-10 14:52:02 --> Config Class Initialized
INFO - 2018-07-10 14:52:02 --> Hooks Class Initialized
DEBUG - 2018-07-10 14:52:02 --> UTF-8 Support Enabled
INFO - 2018-07-10 14:52:02 --> Utf8 Class Initialized
INFO - 2018-07-10 14:52:02 --> URI Class Initialized
INFO - 2018-07-10 14:52:02 --> Router Class Initialized
INFO - 2018-07-10 14:52:02 --> Output Class Initialized
INFO - 2018-07-10 14:52:02 --> Security Class Initialized
DEBUG - 2018-07-10 14:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 14:52:02 --> CSRF cookie sent
INFO - 2018-07-10 14:52:02 --> Input Class Initialized
INFO - 2018-07-10 14:52:02 --> Language Class Initialized
ERROR - 2018-07-10 14:52:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 14:52:05 --> Config Class Initialized
INFO - 2018-07-10 14:52:05 --> Hooks Class Initialized
DEBUG - 2018-07-10 14:52:05 --> UTF-8 Support Enabled
INFO - 2018-07-10 14:52:05 --> Utf8 Class Initialized
INFO - 2018-07-10 14:52:05 --> URI Class Initialized
DEBUG - 2018-07-10 14:52:05 --> No URI present. Default controller set.
INFO - 2018-07-10 14:52:05 --> Router Class Initialized
INFO - 2018-07-10 14:52:05 --> Output Class Initialized
INFO - 2018-07-10 14:52:05 --> Security Class Initialized
DEBUG - 2018-07-10 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 14:52:05 --> CSRF cookie sent
INFO - 2018-07-10 14:52:05 --> Input Class Initialized
INFO - 2018-07-10 14:52:05 --> Language Class Initialized
INFO - 2018-07-10 14:52:05 --> Loader Class Initialized
INFO - 2018-07-10 14:52:05 --> Helper loaded: url_helper
INFO - 2018-07-10 14:52:05 --> Helper loaded: form_helper
INFO - 2018-07-10 14:52:05 --> Helper loaded: language_helper
DEBUG - 2018-07-10 14:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 14:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 14:52:05 --> User Agent Class Initialized
INFO - 2018-07-10 14:52:05 --> Controller Class Initialized
INFO - 2018-07-10 14:52:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 14:52:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 14:52:05 --> Pixel_Model class loaded
INFO - 2018-07-10 14:52:05 --> Database Driver Class Initialized
INFO - 2018-07-10 14:52:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 14:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 14:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 14:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 14:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 14:52:05 --> Final output sent to browser
DEBUG - 2018-07-10 14:52:05 --> Total execution time: 0.0341
INFO - 2018-07-10 15:56:44 --> Config Class Initialized
INFO - 2018-07-10 15:56:44 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:44 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:44 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:44 --> URI Class Initialized
DEBUG - 2018-07-10 15:56:44 --> No URI present. Default controller set.
INFO - 2018-07-10 15:56:44 --> Router Class Initialized
INFO - 2018-07-10 15:56:44 --> Output Class Initialized
INFO - 2018-07-10 15:56:44 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:44 --> CSRF cookie sent
INFO - 2018-07-10 15:56:44 --> Input Class Initialized
INFO - 2018-07-10 15:56:44 --> Language Class Initialized
INFO - 2018-07-10 15:56:44 --> Loader Class Initialized
INFO - 2018-07-10 15:56:44 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:44 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:44 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:44 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:44 --> Controller Class Initialized
INFO - 2018-07-10 15:56:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:44 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:44 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 15:56:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:44 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:44 --> Total execution time: 0.0427
INFO - 2018-07-10 15:56:45 --> Config Class Initialized
INFO - 2018-07-10 15:56:45 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:45 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:45 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:45 --> URI Class Initialized
DEBUG - 2018-07-10 15:56:45 --> No URI present. Default controller set.
INFO - 2018-07-10 15:56:45 --> Router Class Initialized
INFO - 2018-07-10 15:56:45 --> Output Class Initialized
INFO - 2018-07-10 15:56:45 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:45 --> CSRF cookie sent
INFO - 2018-07-10 15:56:45 --> Input Class Initialized
INFO - 2018-07-10 15:56:45 --> Language Class Initialized
INFO - 2018-07-10 15:56:45 --> Loader Class Initialized
INFO - 2018-07-10 15:56:45 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:45 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:45 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:45 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:45 --> Controller Class Initialized
INFO - 2018-07-10 15:56:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:45 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:45 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 15:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:45 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:45 --> Total execution time: 0.0299
INFO - 2018-07-10 15:56:46 --> Config Class Initialized
INFO - 2018-07-10 15:56:46 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:46 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:46 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:46 --> URI Class Initialized
DEBUG - 2018-07-10 15:56:46 --> No URI present. Default controller set.
INFO - 2018-07-10 15:56:46 --> Router Class Initialized
INFO - 2018-07-10 15:56:46 --> Output Class Initialized
INFO - 2018-07-10 15:56:46 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:46 --> CSRF cookie sent
INFO - 2018-07-10 15:56:46 --> Input Class Initialized
INFO - 2018-07-10 15:56:46 --> Language Class Initialized
INFO - 2018-07-10 15:56:46 --> Loader Class Initialized
INFO - 2018-07-10 15:56:46 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:46 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:46 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:46 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:46 --> Controller Class Initialized
INFO - 2018-07-10 15:56:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:46 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:46 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 15:56:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:46 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:46 --> Total execution time: 0.0386
INFO - 2018-07-10 15:56:46 --> Config Class Initialized
INFO - 2018-07-10 15:56:46 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:46 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:46 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:46 --> URI Class Initialized
INFO - 2018-07-10 15:56:46 --> Router Class Initialized
INFO - 2018-07-10 15:56:46 --> Output Class Initialized
INFO - 2018-07-10 15:56:46 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:46 --> CSRF cookie sent
INFO - 2018-07-10 15:56:46 --> Input Class Initialized
INFO - 2018-07-10 15:56:46 --> Language Class Initialized
ERROR - 2018-07-10 15:56:46 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-10 15:56:54 --> Config Class Initialized
INFO - 2018-07-10 15:56:54 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:54 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:54 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:54 --> URI Class Initialized
DEBUG - 2018-07-10 15:56:54 --> No URI present. Default controller set.
INFO - 2018-07-10 15:56:54 --> Router Class Initialized
INFO - 2018-07-10 15:56:54 --> Output Class Initialized
INFO - 2018-07-10 15:56:54 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:54 --> CSRF cookie sent
INFO - 2018-07-10 15:56:54 --> Input Class Initialized
INFO - 2018-07-10 15:56:54 --> Language Class Initialized
INFO - 2018-07-10 15:56:54 --> Loader Class Initialized
INFO - 2018-07-10 15:56:54 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:54 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:54 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:54 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:54 --> Controller Class Initialized
INFO - 2018-07-10 15:56:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:54 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:54 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 15:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:54 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:54 --> Total execution time: 0.0306
INFO - 2018-07-10 15:56:54 --> Config Class Initialized
INFO - 2018-07-10 15:56:54 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:54 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:54 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:54 --> URI Class Initialized
INFO - 2018-07-10 15:56:54 --> Router Class Initialized
INFO - 2018-07-10 15:56:54 --> Output Class Initialized
INFO - 2018-07-10 15:56:54 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:54 --> CSRF cookie sent
INFO - 2018-07-10 15:56:54 --> Input Class Initialized
INFO - 2018-07-10 15:56:54 --> Language Class Initialized
ERROR - 2018-07-10 15:56:54 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-10 15:56:55 --> Config Class Initialized
INFO - 2018-07-10 15:56:55 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:55 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:55 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:55 --> URI Class Initialized
INFO - 2018-07-10 15:56:55 --> Router Class Initialized
INFO - 2018-07-10 15:56:55 --> Output Class Initialized
INFO - 2018-07-10 15:56:55 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:55 --> CSRF cookie sent
INFO - 2018-07-10 15:56:55 --> Input Class Initialized
INFO - 2018-07-10 15:56:55 --> Language Class Initialized
ERROR - 2018-07-10 15:56:55 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-10 15:56:55 --> Config Class Initialized
INFO - 2018-07-10 15:56:55 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:55 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:55 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:55 --> URI Class Initialized
INFO - 2018-07-10 15:56:55 --> Router Class Initialized
INFO - 2018-07-10 15:56:55 --> Output Class Initialized
INFO - 2018-07-10 15:56:55 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:55 --> CSRF cookie sent
INFO - 2018-07-10 15:56:55 --> Input Class Initialized
INFO - 2018-07-10 15:56:55 --> Language Class Initialized
INFO - 2018-07-10 15:56:55 --> Loader Class Initialized
INFO - 2018-07-10 15:56:55 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:55 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:55 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:55 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:55 --> Controller Class Initialized
INFO - 2018-07-10 15:56:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:55 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:55 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:55 --> Config Class Initialized
INFO - 2018-07-10 15:56:55 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:55 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:55 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:55 --> URI Class Initialized
INFO - 2018-07-10 15:56:55 --> Router Class Initialized
INFO - 2018-07-10 15:56:55 --> Output Class Initialized
INFO - 2018-07-10 15:56:55 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:55 --> CSRF cookie sent
INFO - 2018-07-10 15:56:55 --> Input Class Initialized
INFO - 2018-07-10 15:56:55 --> Language Class Initialized
INFO - 2018-07-10 15:56:55 --> Loader Class Initialized
INFO - 2018-07-10 15:56:55 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:55 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:55 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:55 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:55 --> Controller Class Initialized
INFO - 2018-07-10 15:56:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-10 15:56:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-10 15:56:55 --> Could not find the language line "req_email"
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-10 15:56:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:55 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:55 --> Total execution time: 0.0235
INFO - 2018-07-10 15:56:56 --> Config Class Initialized
INFO - 2018-07-10 15:56:56 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:56 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:56 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:56 --> URI Class Initialized
INFO - 2018-07-10 15:56:56 --> Router Class Initialized
INFO - 2018-07-10 15:56:56 --> Output Class Initialized
INFO - 2018-07-10 15:56:56 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:56 --> CSRF cookie sent
INFO - 2018-07-10 15:56:56 --> Input Class Initialized
INFO - 2018-07-10 15:56:56 --> Language Class Initialized
INFO - 2018-07-10 15:56:56 --> Loader Class Initialized
INFO - 2018-07-10 15:56:56 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:56 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:56 --> Controller Class Initialized
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:56 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:56 --> Total execution time: 0.0234
INFO - 2018-07-10 15:56:56 --> Config Class Initialized
INFO - 2018-07-10 15:56:56 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:56 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:56 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:56 --> URI Class Initialized
INFO - 2018-07-10 15:56:56 --> Router Class Initialized
INFO - 2018-07-10 15:56:56 --> Output Class Initialized
INFO - 2018-07-10 15:56:56 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:56 --> CSRF cookie sent
INFO - 2018-07-10 15:56:56 --> Input Class Initialized
INFO - 2018-07-10 15:56:56 --> Language Class Initialized
INFO - 2018-07-10 15:56:56 --> Loader Class Initialized
INFO - 2018-07-10 15:56:56 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:56 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:56 --> Controller Class Initialized
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:56 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:56 --> Total execution time: 0.0229
INFO - 2018-07-10 15:56:56 --> Config Class Initialized
INFO - 2018-07-10 15:56:56 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:56 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:56 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:56 --> URI Class Initialized
INFO - 2018-07-10 15:56:56 --> Router Class Initialized
INFO - 2018-07-10 15:56:56 --> Output Class Initialized
INFO - 2018-07-10 15:56:56 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:56 --> CSRF cookie sent
INFO - 2018-07-10 15:56:56 --> Input Class Initialized
INFO - 2018-07-10 15:56:56 --> Language Class Initialized
INFO - 2018-07-10 15:56:56 --> Loader Class Initialized
INFO - 2018-07-10 15:56:56 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:56 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:56 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:56 --> Controller Class Initialized
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-10 15:56:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:56 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:56 --> Total execution time: 0.0212
INFO - 2018-07-10 15:56:57 --> Config Class Initialized
INFO - 2018-07-10 15:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:57 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:57 --> URI Class Initialized
INFO - 2018-07-10 15:56:57 --> Router Class Initialized
INFO - 2018-07-10 15:56:57 --> Output Class Initialized
INFO - 2018-07-10 15:56:57 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:57 --> CSRF cookie sent
INFO - 2018-07-10 15:56:57 --> Input Class Initialized
INFO - 2018-07-10 15:56:57 --> Language Class Initialized
INFO - 2018-07-10 15:56:57 --> Loader Class Initialized
INFO - 2018-07-10 15:56:57 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:57 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:57 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:57 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:57 --> Controller Class Initialized
INFO - 2018-07-10 15:56:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:57 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:57 --> Total execution time: 0.0220
INFO - 2018-07-10 15:56:57 --> Config Class Initialized
INFO - 2018-07-10 15:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:57 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:57 --> URI Class Initialized
INFO - 2018-07-10 15:56:57 --> Router Class Initialized
INFO - 2018-07-10 15:56:57 --> Output Class Initialized
INFO - 2018-07-10 15:56:57 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:57 --> CSRF cookie sent
INFO - 2018-07-10 15:56:57 --> Input Class Initialized
INFO - 2018-07-10 15:56:57 --> Language Class Initialized
INFO - 2018-07-10 15:56:57 --> Loader Class Initialized
INFO - 2018-07-10 15:56:57 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:57 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:57 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:57 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:57 --> Controller Class Initialized
INFO - 2018-07-10 15:56:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-10 15:56:57 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-10 15:56:57 --> Could not find the language line "req_email"
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-10 15:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:57 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:57 --> Total execution time: 0.0241
INFO - 2018-07-10 15:56:58 --> Config Class Initialized
INFO - 2018-07-10 15:56:58 --> Hooks Class Initialized
DEBUG - 2018-07-10 15:56:58 --> UTF-8 Support Enabled
INFO - 2018-07-10 15:56:58 --> Utf8 Class Initialized
INFO - 2018-07-10 15:56:58 --> URI Class Initialized
INFO - 2018-07-10 15:56:58 --> Router Class Initialized
INFO - 2018-07-10 15:56:58 --> Output Class Initialized
INFO - 2018-07-10 15:56:58 --> Security Class Initialized
DEBUG - 2018-07-10 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 15:56:58 --> CSRF cookie sent
INFO - 2018-07-10 15:56:58 --> Input Class Initialized
INFO - 2018-07-10 15:56:58 --> Language Class Initialized
INFO - 2018-07-10 15:56:58 --> Loader Class Initialized
INFO - 2018-07-10 15:56:58 --> Helper loaded: url_helper
INFO - 2018-07-10 15:56:58 --> Helper loaded: form_helper
INFO - 2018-07-10 15:56:58 --> Helper loaded: language_helper
DEBUG - 2018-07-10 15:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 15:56:58 --> User Agent Class Initialized
INFO - 2018-07-10 15:56:58 --> Controller Class Initialized
INFO - 2018-07-10 15:56:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 15:56:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 15:56:58 --> Pixel_Model class loaded
INFO - 2018-07-10 15:56:58 --> Database Driver Class Initialized
INFO - 2018-07-10 15:56:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-10 15:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 15:56:58 --> Final output sent to browser
DEBUG - 2018-07-10 15:56:58 --> Total execution time: 0.0487
INFO - 2018-07-10 17:22:17 --> Config Class Initialized
INFO - 2018-07-10 17:22:17 --> Hooks Class Initialized
DEBUG - 2018-07-10 17:22:17 --> UTF-8 Support Enabled
INFO - 2018-07-10 17:22:17 --> Utf8 Class Initialized
INFO - 2018-07-10 17:22:17 --> URI Class Initialized
INFO - 2018-07-10 17:22:17 --> Router Class Initialized
INFO - 2018-07-10 17:22:17 --> Output Class Initialized
INFO - 2018-07-10 17:22:17 --> Security Class Initialized
DEBUG - 2018-07-10 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 17:22:17 --> CSRF cookie sent
INFO - 2018-07-10 17:22:17 --> Input Class Initialized
INFO - 2018-07-10 17:22:17 --> Language Class Initialized
ERROR - 2018-07-10 17:22:17 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 17:50:29 --> Config Class Initialized
INFO - 2018-07-10 17:50:29 --> Hooks Class Initialized
DEBUG - 2018-07-10 17:50:29 --> UTF-8 Support Enabled
INFO - 2018-07-10 17:50:29 --> Utf8 Class Initialized
INFO - 2018-07-10 17:50:29 --> URI Class Initialized
DEBUG - 2018-07-10 17:50:29 --> No URI present. Default controller set.
INFO - 2018-07-10 17:50:29 --> Router Class Initialized
INFO - 2018-07-10 17:50:29 --> Output Class Initialized
INFO - 2018-07-10 17:50:29 --> Security Class Initialized
DEBUG - 2018-07-10 17:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 17:50:29 --> CSRF cookie sent
INFO - 2018-07-10 17:50:29 --> Input Class Initialized
INFO - 2018-07-10 17:50:29 --> Language Class Initialized
INFO - 2018-07-10 17:50:29 --> Loader Class Initialized
INFO - 2018-07-10 17:50:29 --> Helper loaded: url_helper
INFO - 2018-07-10 17:50:29 --> Helper loaded: form_helper
INFO - 2018-07-10 17:50:29 --> Helper loaded: language_helper
DEBUG - 2018-07-10 17:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 17:50:29 --> User Agent Class Initialized
INFO - 2018-07-10 17:50:29 --> Controller Class Initialized
INFO - 2018-07-10 17:50:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 17:50:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 17:50:29 --> Pixel_Model class loaded
INFO - 2018-07-10 17:50:29 --> Database Driver Class Initialized
INFO - 2018-07-10 17:50:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 17:50:29 --> Final output sent to browser
DEBUG - 2018-07-10 17:50:29 --> Total execution time: 0.0344
INFO - 2018-07-10 18:19:48 --> Config Class Initialized
INFO - 2018-07-10 18:19:48 --> Hooks Class Initialized
DEBUG - 2018-07-10 18:19:48 --> UTF-8 Support Enabled
INFO - 2018-07-10 18:19:48 --> Utf8 Class Initialized
INFO - 2018-07-10 18:19:48 --> URI Class Initialized
DEBUG - 2018-07-10 18:19:48 --> No URI present. Default controller set.
INFO - 2018-07-10 18:19:48 --> Router Class Initialized
INFO - 2018-07-10 18:19:48 --> Output Class Initialized
INFO - 2018-07-10 18:19:48 --> Security Class Initialized
DEBUG - 2018-07-10 18:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 18:19:48 --> CSRF cookie sent
INFO - 2018-07-10 18:19:48 --> Input Class Initialized
INFO - 2018-07-10 18:19:48 --> Language Class Initialized
INFO - 2018-07-10 18:19:48 --> Loader Class Initialized
INFO - 2018-07-10 18:19:48 --> Helper loaded: url_helper
INFO - 2018-07-10 18:19:48 --> Helper loaded: form_helper
INFO - 2018-07-10 18:19:48 --> Helper loaded: language_helper
DEBUG - 2018-07-10 18:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 18:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 18:19:48 --> User Agent Class Initialized
INFO - 2018-07-10 18:19:48 --> Controller Class Initialized
INFO - 2018-07-10 18:19:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 18:19:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 18:19:48 --> Pixel_Model class loaded
INFO - 2018-07-10 18:19:48 --> Database Driver Class Initialized
INFO - 2018-07-10 18:19:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 18:19:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 18:19:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 18:19:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 18:19:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 18:19:48 --> Final output sent to browser
DEBUG - 2018-07-10 18:19:48 --> Total execution time: 0.0379
INFO - 2018-07-10 20:47:31 --> Config Class Initialized
INFO - 2018-07-10 20:47:31 --> Hooks Class Initialized
DEBUG - 2018-07-10 20:47:31 --> UTF-8 Support Enabled
INFO - 2018-07-10 20:47:31 --> Utf8 Class Initialized
INFO - 2018-07-10 20:47:31 --> URI Class Initialized
INFO - 2018-07-10 20:47:31 --> Router Class Initialized
INFO - 2018-07-10 20:47:31 --> Output Class Initialized
INFO - 2018-07-10 20:47:31 --> Security Class Initialized
DEBUG - 2018-07-10 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 20:47:31 --> CSRF cookie sent
INFO - 2018-07-10 20:47:31 --> Input Class Initialized
INFO - 2018-07-10 20:47:31 --> Language Class Initialized
ERROR - 2018-07-10 20:47:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 20:47:31 --> Config Class Initialized
INFO - 2018-07-10 20:47:31 --> Hooks Class Initialized
DEBUG - 2018-07-10 20:47:31 --> UTF-8 Support Enabled
INFO - 2018-07-10 20:47:31 --> Utf8 Class Initialized
INFO - 2018-07-10 20:47:31 --> URI Class Initialized
DEBUG - 2018-07-10 20:47:31 --> No URI present. Default controller set.
INFO - 2018-07-10 20:47:31 --> Router Class Initialized
INFO - 2018-07-10 20:47:31 --> Output Class Initialized
INFO - 2018-07-10 20:47:31 --> Security Class Initialized
DEBUG - 2018-07-10 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 20:47:31 --> CSRF cookie sent
INFO - 2018-07-10 20:47:31 --> Input Class Initialized
INFO - 2018-07-10 20:47:31 --> Language Class Initialized
INFO - 2018-07-10 20:47:31 --> Loader Class Initialized
INFO - 2018-07-10 20:47:31 --> Helper loaded: url_helper
INFO - 2018-07-10 20:47:31 --> Helper loaded: form_helper
INFO - 2018-07-10 20:47:31 --> Helper loaded: language_helper
DEBUG - 2018-07-10 20:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 20:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 20:47:31 --> User Agent Class Initialized
INFO - 2018-07-10 20:47:31 --> Controller Class Initialized
INFO - 2018-07-10 20:47:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 20:47:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 20:47:31 --> Pixel_Model class loaded
INFO - 2018-07-10 20:47:31 --> Database Driver Class Initialized
INFO - 2018-07-10 20:47:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 20:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 20:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 20:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 20:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 20:47:31 --> Final output sent to browser
DEBUG - 2018-07-10 20:47:31 --> Total execution time: 0.0341
INFO - 2018-07-10 20:47:39 --> Config Class Initialized
INFO - 2018-07-10 20:47:39 --> Hooks Class Initialized
DEBUG - 2018-07-10 20:47:39 --> UTF-8 Support Enabled
INFO - 2018-07-10 20:47:39 --> Utf8 Class Initialized
INFO - 2018-07-10 20:47:39 --> URI Class Initialized
INFO - 2018-07-10 20:47:39 --> Router Class Initialized
INFO - 2018-07-10 20:47:39 --> Output Class Initialized
INFO - 2018-07-10 20:47:39 --> Security Class Initialized
DEBUG - 2018-07-10 20:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 20:47:39 --> CSRF cookie sent
INFO - 2018-07-10 20:47:39 --> Input Class Initialized
INFO - 2018-07-10 20:47:39 --> Language Class Initialized
ERROR - 2018-07-10 20:47:39 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 21:18:41 --> Config Class Initialized
INFO - 2018-07-10 21:18:41 --> Hooks Class Initialized
DEBUG - 2018-07-10 21:18:41 --> UTF-8 Support Enabled
INFO - 2018-07-10 21:18:41 --> Utf8 Class Initialized
INFO - 2018-07-10 21:18:41 --> URI Class Initialized
INFO - 2018-07-10 21:18:41 --> Router Class Initialized
INFO - 2018-07-10 21:18:41 --> Output Class Initialized
INFO - 2018-07-10 21:18:41 --> Security Class Initialized
DEBUG - 2018-07-10 21:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 21:18:41 --> CSRF cookie sent
INFO - 2018-07-10 21:18:41 --> Input Class Initialized
INFO - 2018-07-10 21:18:41 --> Language Class Initialized
ERROR - 2018-07-10 21:18:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-10 21:18:44 --> Config Class Initialized
INFO - 2018-07-10 21:18:44 --> Hooks Class Initialized
DEBUG - 2018-07-10 21:18:44 --> UTF-8 Support Enabled
INFO - 2018-07-10 21:18:44 --> Utf8 Class Initialized
INFO - 2018-07-10 21:18:44 --> URI Class Initialized
INFO - 2018-07-10 21:18:44 --> Router Class Initialized
INFO - 2018-07-10 21:18:44 --> Output Class Initialized
INFO - 2018-07-10 21:18:44 --> Security Class Initialized
DEBUG - 2018-07-10 21:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 21:18:44 --> CSRF cookie sent
INFO - 2018-07-10 21:18:44 --> Input Class Initialized
INFO - 2018-07-10 21:18:44 --> Language Class Initialized
INFO - 2018-07-10 21:18:44 --> Loader Class Initialized
INFO - 2018-07-10 21:18:44 --> Helper loaded: url_helper
INFO - 2018-07-10 21:18:44 --> Helper loaded: form_helper
INFO - 2018-07-10 21:18:44 --> Helper loaded: language_helper
DEBUG - 2018-07-10 21:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 21:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 21:18:44 --> User Agent Class Initialized
INFO - 2018-07-10 21:18:44 --> Controller Class Initialized
INFO - 2018-07-10 21:18:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 21:18:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-10 21:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 21:18:44 --> Final output sent to browser
DEBUG - 2018-07-10 21:18:44 --> Total execution time: 0.0255
INFO - 2018-07-10 21:40:00 --> Config Class Initialized
INFO - 2018-07-10 21:40:00 --> Hooks Class Initialized
DEBUG - 2018-07-10 21:40:00 --> UTF-8 Support Enabled
INFO - 2018-07-10 21:40:00 --> Utf8 Class Initialized
INFO - 2018-07-10 21:40:00 --> URI Class Initialized
INFO - 2018-07-10 21:40:00 --> Router Class Initialized
INFO - 2018-07-10 21:40:00 --> Output Class Initialized
INFO - 2018-07-10 21:40:00 --> Security Class Initialized
DEBUG - 2018-07-10 21:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 21:40:00 --> CSRF cookie sent
INFO - 2018-07-10 21:40:00 --> Input Class Initialized
INFO - 2018-07-10 21:40:00 --> Language Class Initialized
INFO - 2018-07-10 21:40:00 --> Loader Class Initialized
INFO - 2018-07-10 21:40:00 --> Helper loaded: url_helper
INFO - 2018-07-10 21:40:00 --> Helper loaded: form_helper
INFO - 2018-07-10 21:40:00 --> Helper loaded: language_helper
DEBUG - 2018-07-10 21:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 21:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 21:40:00 --> User Agent Class Initialized
INFO - 2018-07-10 21:40:00 --> Controller Class Initialized
INFO - 2018-07-10 21:40:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 21:40:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 21:40:00 --> Pixel_Model class loaded
INFO - 2018-07-10 21:40:00 --> Database Driver Class Initialized
INFO - 2018-07-10 21:40:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-10 21:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 21:40:00 --> Final output sent to browser
DEBUG - 2018-07-10 21:40:00 --> Total execution time: 0.0436
INFO - 2018-07-10 23:51:07 --> Config Class Initialized
INFO - 2018-07-10 23:51:07 --> Hooks Class Initialized
DEBUG - 2018-07-10 23:51:07 --> UTF-8 Support Enabled
INFO - 2018-07-10 23:51:07 --> Utf8 Class Initialized
INFO - 2018-07-10 23:51:07 --> URI Class Initialized
DEBUG - 2018-07-10 23:51:07 --> No URI present. Default controller set.
INFO - 2018-07-10 23:51:07 --> Router Class Initialized
INFO - 2018-07-10 23:51:07 --> Output Class Initialized
INFO - 2018-07-10 23:51:07 --> Security Class Initialized
DEBUG - 2018-07-10 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-10 23:51:07 --> CSRF cookie sent
INFO - 2018-07-10 23:51:07 --> Input Class Initialized
INFO - 2018-07-10 23:51:07 --> Language Class Initialized
INFO - 2018-07-10 23:51:07 --> Loader Class Initialized
INFO - 2018-07-10 23:51:07 --> Helper loaded: url_helper
INFO - 2018-07-10 23:51:07 --> Helper loaded: form_helper
INFO - 2018-07-10 23:51:07 --> Helper loaded: language_helper
DEBUG - 2018-07-10 23:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-10 23:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-10 23:51:07 --> User Agent Class Initialized
INFO - 2018-07-10 23:51:07 --> Controller Class Initialized
INFO - 2018-07-10 23:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-10 23:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-10 23:51:07 --> Pixel_Model class loaded
INFO - 2018-07-10 23:51:07 --> Database Driver Class Initialized
INFO - 2018-07-10 23:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-10 23:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-10 23:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-10 23:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-10 23:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-10 23:51:07 --> Final output sent to browser
DEBUG - 2018-07-10 23:51:07 --> Total execution time: 0.0361

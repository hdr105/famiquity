<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-11 00:13:06 --> Config Class Initialized
INFO - 2018-07-11 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-07-11 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-07-11 00:13:06 --> Utf8 Class Initialized
INFO - 2018-07-11 00:13:06 --> URI Class Initialized
INFO - 2018-07-11 00:13:06 --> Router Class Initialized
INFO - 2018-07-11 00:13:06 --> Output Class Initialized
INFO - 2018-07-11 00:13:06 --> Security Class Initialized
DEBUG - 2018-07-11 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 00:13:06 --> CSRF cookie sent
INFO - 2018-07-11 00:13:06 --> Input Class Initialized
INFO - 2018-07-11 00:13:06 --> Language Class Initialized
ERROR - 2018-07-11 00:13:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 00:13:10 --> Config Class Initialized
INFO - 2018-07-11 00:13:10 --> Hooks Class Initialized
DEBUG - 2018-07-11 00:13:10 --> UTF-8 Support Enabled
INFO - 2018-07-11 00:13:10 --> Utf8 Class Initialized
INFO - 2018-07-11 00:13:10 --> URI Class Initialized
INFO - 2018-07-11 00:13:10 --> Router Class Initialized
INFO - 2018-07-11 00:13:10 --> Output Class Initialized
INFO - 2018-07-11 00:13:10 --> Security Class Initialized
DEBUG - 2018-07-11 00:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 00:13:10 --> CSRF cookie sent
INFO - 2018-07-11 00:13:10 --> Input Class Initialized
INFO - 2018-07-11 00:13:10 --> Language Class Initialized
INFO - 2018-07-11 00:13:10 --> Loader Class Initialized
INFO - 2018-07-11 00:13:10 --> Helper loaded: url_helper
INFO - 2018-07-11 00:13:10 --> Helper loaded: form_helper
INFO - 2018-07-11 00:13:10 --> Helper loaded: language_helper
DEBUG - 2018-07-11 00:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 00:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 00:13:10 --> User Agent Class Initialized
INFO - 2018-07-11 00:13:10 --> Controller Class Initialized
INFO - 2018-07-11 00:13:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 00:13:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-11 00:13:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 00:13:10 --> Final output sent to browser
DEBUG - 2018-07-11 00:13:10 --> Total execution time: 0.0221
INFO - 2018-07-11 02:21:07 --> Config Class Initialized
INFO - 2018-07-11 02:21:07 --> Hooks Class Initialized
DEBUG - 2018-07-11 02:21:07 --> UTF-8 Support Enabled
INFO - 2018-07-11 02:21:07 --> Utf8 Class Initialized
INFO - 2018-07-11 02:21:07 --> URI Class Initialized
DEBUG - 2018-07-11 02:21:07 --> No URI present. Default controller set.
INFO - 2018-07-11 02:21:07 --> Router Class Initialized
INFO - 2018-07-11 02:21:07 --> Output Class Initialized
INFO - 2018-07-11 02:21:07 --> Security Class Initialized
DEBUG - 2018-07-11 02:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 02:21:07 --> CSRF cookie sent
INFO - 2018-07-11 02:21:07 --> Input Class Initialized
INFO - 2018-07-11 02:21:07 --> Language Class Initialized
INFO - 2018-07-11 02:21:07 --> Loader Class Initialized
INFO - 2018-07-11 02:21:07 --> Helper loaded: url_helper
INFO - 2018-07-11 02:21:07 --> Helper loaded: form_helper
INFO - 2018-07-11 02:21:07 --> Helper loaded: language_helper
DEBUG - 2018-07-11 02:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 02:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 02:21:07 --> User Agent Class Initialized
INFO - 2018-07-11 02:21:07 --> Controller Class Initialized
INFO - 2018-07-11 02:21:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 02:21:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 02:21:07 --> Pixel_Model class loaded
INFO - 2018-07-11 02:21:07 --> Database Driver Class Initialized
INFO - 2018-07-11 02:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 02:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 02:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 02:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 02:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 02:21:07 --> Final output sent to browser
DEBUG - 2018-07-11 02:21:07 --> Total execution time: 0.0351
INFO - 2018-07-11 06:33:06 --> Config Class Initialized
INFO - 2018-07-11 06:33:06 --> Hooks Class Initialized
DEBUG - 2018-07-11 06:33:06 --> UTF-8 Support Enabled
INFO - 2018-07-11 06:33:06 --> Utf8 Class Initialized
INFO - 2018-07-11 06:33:06 --> URI Class Initialized
INFO - 2018-07-11 06:33:06 --> Router Class Initialized
INFO - 2018-07-11 06:33:06 --> Output Class Initialized
INFO - 2018-07-11 06:33:06 --> Security Class Initialized
DEBUG - 2018-07-11 06:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 06:33:06 --> CSRF cookie sent
INFO - 2018-07-11 06:33:06 --> Input Class Initialized
INFO - 2018-07-11 06:33:06 --> Language Class Initialized
ERROR - 2018-07-11 06:33:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 06:33:09 --> Config Class Initialized
INFO - 2018-07-11 06:33:09 --> Hooks Class Initialized
DEBUG - 2018-07-11 06:33:09 --> UTF-8 Support Enabled
INFO - 2018-07-11 06:33:09 --> Utf8 Class Initialized
INFO - 2018-07-11 06:33:09 --> URI Class Initialized
INFO - 2018-07-11 06:33:09 --> Router Class Initialized
INFO - 2018-07-11 06:33:09 --> Output Class Initialized
INFO - 2018-07-11 06:33:09 --> Security Class Initialized
DEBUG - 2018-07-11 06:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 06:33:09 --> CSRF cookie sent
INFO - 2018-07-11 06:33:09 --> Input Class Initialized
INFO - 2018-07-11 06:33:09 --> Language Class Initialized
INFO - 2018-07-11 06:33:09 --> Loader Class Initialized
INFO - 2018-07-11 06:33:09 --> Helper loaded: url_helper
INFO - 2018-07-11 06:33:09 --> Helper loaded: form_helper
INFO - 2018-07-11 06:33:09 --> Helper loaded: language_helper
DEBUG - 2018-07-11 06:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 06:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 06:33:09 --> User Agent Class Initialized
INFO - 2018-07-11 06:33:09 --> Controller Class Initialized
INFO - 2018-07-11 06:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 06:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-11 06:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 06:33:09 --> Final output sent to browser
DEBUG - 2018-07-11 06:33:09 --> Total execution time: 0.0222
INFO - 2018-07-11 08:22:44 --> Config Class Initialized
INFO - 2018-07-11 08:22:44 --> Hooks Class Initialized
DEBUG - 2018-07-11 08:22:44 --> UTF-8 Support Enabled
INFO - 2018-07-11 08:22:44 --> Utf8 Class Initialized
INFO - 2018-07-11 08:22:44 --> URI Class Initialized
DEBUG - 2018-07-11 08:22:44 --> No URI present. Default controller set.
INFO - 2018-07-11 08:22:44 --> Router Class Initialized
INFO - 2018-07-11 08:22:44 --> Output Class Initialized
INFO - 2018-07-11 08:22:44 --> Security Class Initialized
DEBUG - 2018-07-11 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 08:22:44 --> CSRF cookie sent
INFO - 2018-07-11 08:22:44 --> Input Class Initialized
INFO - 2018-07-11 08:22:44 --> Language Class Initialized
INFO - 2018-07-11 08:22:44 --> Loader Class Initialized
INFO - 2018-07-11 08:22:44 --> Helper loaded: url_helper
INFO - 2018-07-11 08:22:44 --> Helper loaded: form_helper
INFO - 2018-07-11 08:22:44 --> Helper loaded: language_helper
DEBUG - 2018-07-11 08:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 08:22:44 --> User Agent Class Initialized
INFO - 2018-07-11 08:22:44 --> Controller Class Initialized
INFO - 2018-07-11 08:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 08:22:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 08:22:44 --> Pixel_Model class loaded
INFO - 2018-07-11 08:22:44 --> Database Driver Class Initialized
INFO - 2018-07-11 08:22:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 08:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 08:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 08:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 08:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 08:22:44 --> Final output sent to browser
DEBUG - 2018-07-11 08:22:44 --> Total execution time: 0.0342
INFO - 2018-07-11 10:05:44 --> Config Class Initialized
INFO - 2018-07-11 10:05:44 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:05:44 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:05:44 --> Utf8 Class Initialized
INFO - 2018-07-11 10:05:44 --> URI Class Initialized
DEBUG - 2018-07-11 10:05:44 --> No URI present. Default controller set.
INFO - 2018-07-11 10:05:44 --> Router Class Initialized
INFO - 2018-07-11 10:05:44 --> Output Class Initialized
INFO - 2018-07-11 10:05:44 --> Security Class Initialized
DEBUG - 2018-07-11 10:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:05:44 --> CSRF cookie sent
INFO - 2018-07-11 10:05:44 --> Input Class Initialized
INFO - 2018-07-11 10:05:44 --> Language Class Initialized
INFO - 2018-07-11 10:05:44 --> Loader Class Initialized
INFO - 2018-07-11 10:05:44 --> Helper loaded: url_helper
INFO - 2018-07-11 10:05:44 --> Helper loaded: form_helper
INFO - 2018-07-11 10:05:44 --> Helper loaded: language_helper
DEBUG - 2018-07-11 10:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 10:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 10:05:44 --> User Agent Class Initialized
INFO - 2018-07-11 10:05:44 --> Controller Class Initialized
INFO - 2018-07-11 10:05:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 10:05:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 10:05:44 --> Pixel_Model class loaded
INFO - 2018-07-11 10:05:44 --> Database Driver Class Initialized
INFO - 2018-07-11 10:05:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 10:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 10:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 10:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 10:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 10:05:44 --> Final output sent to browser
DEBUG - 2018-07-11 10:05:44 --> Total execution time: 0.0342
INFO - 2018-07-11 10:15:08 --> Config Class Initialized
INFO - 2018-07-11 10:15:08 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:08 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:08 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:08 --> URI Class Initialized
DEBUG - 2018-07-11 10:15:08 --> No URI present. Default controller set.
INFO - 2018-07-11 10:15:08 --> Router Class Initialized
INFO - 2018-07-11 10:15:08 --> Output Class Initialized
INFO - 2018-07-11 10:15:08 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:08 --> CSRF cookie sent
INFO - 2018-07-11 10:15:08 --> Input Class Initialized
INFO - 2018-07-11 10:15:08 --> Language Class Initialized
INFO - 2018-07-11 10:15:08 --> Loader Class Initialized
INFO - 2018-07-11 10:15:08 --> Helper loaded: url_helper
INFO - 2018-07-11 10:15:08 --> Helper loaded: form_helper
INFO - 2018-07-11 10:15:08 --> Helper loaded: language_helper
DEBUG - 2018-07-11 10:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 10:15:08 --> User Agent Class Initialized
INFO - 2018-07-11 10:15:08 --> Controller Class Initialized
INFO - 2018-07-11 10:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 10:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 10:15:08 --> Pixel_Model class loaded
INFO - 2018-07-11 10:15:08 --> Database Driver Class Initialized
INFO - 2018-07-11 10:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 10:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 10:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 10:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 10:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 10:15:08 --> Final output sent to browser
DEBUG - 2018-07-11 10:15:08 --> Total execution time: 0.0321
INFO - 2018-07-11 10:15:15 --> Config Class Initialized
INFO - 2018-07-11 10:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:15 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:15 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:15 --> URI Class Initialized
INFO - 2018-07-11 10:15:15 --> Router Class Initialized
INFO - 2018-07-11 10:15:15 --> Output Class Initialized
INFO - 2018-07-11 10:15:15 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:15 --> CSRF cookie sent
INFO - 2018-07-11 10:15:15 --> Input Class Initialized
INFO - 2018-07-11 10:15:15 --> Language Class Initialized
ERROR - 2018-07-11 10:15:15 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-11 10:15:15 --> Config Class Initialized
INFO - 2018-07-11 10:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:15 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:15 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:15 --> URI Class Initialized
INFO - 2018-07-11 10:15:15 --> Router Class Initialized
INFO - 2018-07-11 10:15:15 --> Output Class Initialized
INFO - 2018-07-11 10:15:15 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:15 --> CSRF cookie sent
INFO - 2018-07-11 10:15:15 --> Input Class Initialized
INFO - 2018-07-11 10:15:15 --> Language Class Initialized
ERROR - 2018-07-11 10:15:15 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-11 10:15:15 --> Config Class Initialized
INFO - 2018-07-11 10:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:15 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:15 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:15 --> URI Class Initialized
INFO - 2018-07-11 10:15:15 --> Router Class Initialized
INFO - 2018-07-11 10:15:15 --> Output Class Initialized
INFO - 2018-07-11 10:15:15 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:15 --> CSRF cookie sent
INFO - 2018-07-11 10:15:15 --> Input Class Initialized
INFO - 2018-07-11 10:15:15 --> Language Class Initialized
ERROR - 2018-07-11 10:15:15 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-11 10:15:15 --> Config Class Initialized
INFO - 2018-07-11 10:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:15 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:15 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:15 --> URI Class Initialized
INFO - 2018-07-11 10:15:15 --> Router Class Initialized
INFO - 2018-07-11 10:15:15 --> Output Class Initialized
INFO - 2018-07-11 10:15:15 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:15 --> CSRF cookie sent
INFO - 2018-07-11 10:15:15 --> Input Class Initialized
INFO - 2018-07-11 10:15:15 --> Language Class Initialized
ERROR - 2018-07-11 10:15:15 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-11 10:15:23 --> Config Class Initialized
INFO - 2018-07-11 10:15:23 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:23 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:23 --> URI Class Initialized
INFO - 2018-07-11 10:15:23 --> Router Class Initialized
INFO - 2018-07-11 10:15:23 --> Output Class Initialized
INFO - 2018-07-11 10:15:23 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:23 --> CSRF cookie sent
INFO - 2018-07-11 10:15:23 --> CSRF token verified
INFO - 2018-07-11 10:15:23 --> Input Class Initialized
INFO - 2018-07-11 10:15:23 --> Language Class Initialized
INFO - 2018-07-11 10:15:23 --> Loader Class Initialized
INFO - 2018-07-11 10:15:23 --> Helper loaded: url_helper
INFO - 2018-07-11 10:15:23 --> Helper loaded: form_helper
INFO - 2018-07-11 10:15:23 --> Helper loaded: language_helper
DEBUG - 2018-07-11 10:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 10:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 10:15:23 --> User Agent Class Initialized
INFO - 2018-07-11 10:15:23 --> Controller Class Initialized
INFO - 2018-07-11 10:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 10:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 10:15:23 --> Pixel_Model class loaded
INFO - 2018-07-11 10:15:23 --> Database Driver Class Initialized
INFO - 2018-07-11 10:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 10:15:23 --> Config Class Initialized
INFO - 2018-07-11 10:15:23 --> Hooks Class Initialized
DEBUG - 2018-07-11 10:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-11 10:15:23 --> Utf8 Class Initialized
INFO - 2018-07-11 10:15:23 --> URI Class Initialized
INFO - 2018-07-11 10:15:23 --> Router Class Initialized
INFO - 2018-07-11 10:15:23 --> Output Class Initialized
INFO - 2018-07-11 10:15:23 --> Security Class Initialized
DEBUG - 2018-07-11 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 10:15:23 --> CSRF cookie sent
INFO - 2018-07-11 10:15:23 --> Input Class Initialized
INFO - 2018-07-11 10:15:23 --> Language Class Initialized
INFO - 2018-07-11 10:15:23 --> Loader Class Initialized
INFO - 2018-07-11 10:15:23 --> Helper loaded: url_helper
INFO - 2018-07-11 10:15:23 --> Helper loaded: form_helper
INFO - 2018-07-11 10:15:23 --> Helper loaded: language_helper
DEBUG - 2018-07-11 10:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 10:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 10:15:23 --> User Agent Class Initialized
INFO - 2018-07-11 10:15:23 --> Controller Class Initialized
INFO - 2018-07-11 10:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 10:15:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-11 10:15:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 10:15:23 --> Could not find the language line "req_email"
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-11 10:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 10:15:23 --> Final output sent to browser
DEBUG - 2018-07-11 10:15:23 --> Total execution time: 0.0226
INFO - 2018-07-11 11:12:03 --> Config Class Initialized
INFO - 2018-07-11 11:12:03 --> Hooks Class Initialized
DEBUG - 2018-07-11 11:12:03 --> UTF-8 Support Enabled
INFO - 2018-07-11 11:12:03 --> Utf8 Class Initialized
INFO - 2018-07-11 11:12:03 --> URI Class Initialized
INFO - 2018-07-11 11:12:03 --> Router Class Initialized
INFO - 2018-07-11 11:12:03 --> Output Class Initialized
INFO - 2018-07-11 11:12:03 --> Security Class Initialized
DEBUG - 2018-07-11 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 11:12:03 --> CSRF cookie sent
INFO - 2018-07-11 11:12:03 --> Input Class Initialized
INFO - 2018-07-11 11:12:03 --> Language Class Initialized
ERROR - 2018-07-11 11:12:03 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 11:12:06 --> Config Class Initialized
INFO - 2018-07-11 11:12:06 --> Hooks Class Initialized
DEBUG - 2018-07-11 11:12:06 --> UTF-8 Support Enabled
INFO - 2018-07-11 11:12:06 --> Utf8 Class Initialized
INFO - 2018-07-11 11:12:06 --> URI Class Initialized
INFO - 2018-07-11 11:12:06 --> Router Class Initialized
INFO - 2018-07-11 11:12:06 --> Output Class Initialized
INFO - 2018-07-11 11:12:06 --> Security Class Initialized
DEBUG - 2018-07-11 11:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 11:12:06 --> CSRF cookie sent
INFO - 2018-07-11 11:12:06 --> Input Class Initialized
INFO - 2018-07-11 11:12:06 --> Language Class Initialized
INFO - 2018-07-11 11:12:06 --> Loader Class Initialized
INFO - 2018-07-11 11:12:06 --> Helper loaded: url_helper
INFO - 2018-07-11 11:12:06 --> Helper loaded: form_helper
INFO - 2018-07-11 11:12:06 --> Helper loaded: language_helper
DEBUG - 2018-07-11 11:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 11:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 11:12:06 --> User Agent Class Initialized
INFO - 2018-07-11 11:12:06 --> Controller Class Initialized
INFO - 2018-07-11 11:12:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 11:12:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-11 11:12:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 11:12:06 --> Final output sent to browser
DEBUG - 2018-07-11 11:12:06 --> Total execution time: 0.0240
INFO - 2018-07-11 13:25:28 --> Config Class Initialized
INFO - 2018-07-11 13:25:28 --> Hooks Class Initialized
DEBUG - 2018-07-11 13:25:28 --> UTF-8 Support Enabled
INFO - 2018-07-11 13:25:28 --> Utf8 Class Initialized
INFO - 2018-07-11 13:25:28 --> URI Class Initialized
DEBUG - 2018-07-11 13:25:28 --> No URI present. Default controller set.
INFO - 2018-07-11 13:25:28 --> Router Class Initialized
INFO - 2018-07-11 13:25:28 --> Output Class Initialized
INFO - 2018-07-11 13:25:28 --> Security Class Initialized
DEBUG - 2018-07-11 13:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 13:25:28 --> CSRF cookie sent
INFO - 2018-07-11 13:25:28 --> Input Class Initialized
INFO - 2018-07-11 13:25:28 --> Language Class Initialized
INFO - 2018-07-11 13:25:28 --> Loader Class Initialized
INFO - 2018-07-11 13:25:28 --> Helper loaded: url_helper
INFO - 2018-07-11 13:25:28 --> Helper loaded: form_helper
INFO - 2018-07-11 13:25:28 --> Helper loaded: language_helper
DEBUG - 2018-07-11 13:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 13:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 13:25:28 --> User Agent Class Initialized
INFO - 2018-07-11 13:25:28 --> Controller Class Initialized
INFO - 2018-07-11 13:25:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 13:25:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 13:25:28 --> Pixel_Model class loaded
INFO - 2018-07-11 13:25:28 --> Database Driver Class Initialized
INFO - 2018-07-11 13:25:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 13:25:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 13:25:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 13:25:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 13:25:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 13:25:28 --> Final output sent to browser
DEBUG - 2018-07-11 13:25:28 --> Total execution time: 0.0393
INFO - 2018-07-11 14:24:37 --> Config Class Initialized
INFO - 2018-07-11 14:24:37 --> Hooks Class Initialized
DEBUG - 2018-07-11 14:24:37 --> UTF-8 Support Enabled
INFO - 2018-07-11 14:24:37 --> Utf8 Class Initialized
INFO - 2018-07-11 14:24:37 --> URI Class Initialized
INFO - 2018-07-11 14:24:37 --> Router Class Initialized
INFO - 2018-07-11 14:24:37 --> Output Class Initialized
INFO - 2018-07-11 14:24:37 --> Security Class Initialized
DEBUG - 2018-07-11 14:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 14:24:37 --> CSRF cookie sent
INFO - 2018-07-11 14:24:37 --> Input Class Initialized
INFO - 2018-07-11 14:24:37 --> Language Class Initialized
ERROR - 2018-07-11 14:24:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 14:24:37 --> Config Class Initialized
INFO - 2018-07-11 14:24:37 --> Hooks Class Initialized
DEBUG - 2018-07-11 14:24:37 --> UTF-8 Support Enabled
INFO - 2018-07-11 14:24:37 --> Utf8 Class Initialized
INFO - 2018-07-11 14:24:37 --> URI Class Initialized
INFO - 2018-07-11 14:24:37 --> Router Class Initialized
INFO - 2018-07-11 14:24:37 --> Output Class Initialized
INFO - 2018-07-11 14:24:37 --> Security Class Initialized
DEBUG - 2018-07-11 14:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 14:24:37 --> CSRF cookie sent
INFO - 2018-07-11 14:24:37 --> Input Class Initialized
INFO - 2018-07-11 14:24:37 --> Language Class Initialized
INFO - 2018-07-11 14:24:38 --> Loader Class Initialized
INFO - 2018-07-11 14:24:38 --> Helper loaded: url_helper
INFO - 2018-07-11 14:24:38 --> Helper loaded: form_helper
INFO - 2018-07-11 14:24:38 --> Helper loaded: language_helper
DEBUG - 2018-07-11 14:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 14:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 14:24:38 --> User Agent Class Initialized
INFO - 2018-07-11 14:24:38 --> Controller Class Initialized
INFO - 2018-07-11 14:24:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 14:24:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-11 14:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 14:24:38 --> Final output sent to browser
DEBUG - 2018-07-11 14:24:38 --> Total execution time: 0.0281
INFO - 2018-07-11 15:38:10 --> Config Class Initialized
INFO - 2018-07-11 15:38:10 --> Hooks Class Initialized
DEBUG - 2018-07-11 15:38:10 --> UTF-8 Support Enabled
INFO - 2018-07-11 15:38:10 --> Utf8 Class Initialized
INFO - 2018-07-11 15:38:10 --> URI Class Initialized
INFO - 2018-07-11 15:38:10 --> Router Class Initialized
INFO - 2018-07-11 15:38:10 --> Output Class Initialized
INFO - 2018-07-11 15:38:10 --> Security Class Initialized
DEBUG - 2018-07-11 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 15:38:10 --> CSRF cookie sent
INFO - 2018-07-11 15:38:10 --> Input Class Initialized
INFO - 2018-07-11 15:38:10 --> Language Class Initialized
ERROR - 2018-07-11 15:38:10 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 15:38:13 --> Config Class Initialized
INFO - 2018-07-11 15:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-11 15:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-11 15:38:13 --> Utf8 Class Initialized
INFO - 2018-07-11 15:38:13 --> URI Class Initialized
INFO - 2018-07-11 15:38:13 --> Router Class Initialized
INFO - 2018-07-11 15:38:13 --> Output Class Initialized
INFO - 2018-07-11 15:38:13 --> Security Class Initialized
DEBUG - 2018-07-11 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 15:38:13 --> CSRF cookie sent
INFO - 2018-07-11 15:38:13 --> Input Class Initialized
INFO - 2018-07-11 15:38:13 --> Language Class Initialized
INFO - 2018-07-11 15:38:13 --> Loader Class Initialized
INFO - 2018-07-11 15:38:13 --> Helper loaded: url_helper
INFO - 2018-07-11 15:38:13 --> Helper loaded: form_helper
INFO - 2018-07-11 15:38:13 --> Helper loaded: language_helper
DEBUG - 2018-07-11 15:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 15:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 15:38:13 --> User Agent Class Initialized
INFO - 2018-07-11 15:38:13 --> Controller Class Initialized
INFO - 2018-07-11 15:38:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 15:38:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-11 15:38:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 15:38:13 --> Could not find the language line "req_email"
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-11 15:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 15:38:13 --> Final output sent to browser
DEBUG - 2018-07-11 15:38:13 --> Total execution time: 0.0303
INFO - 2018-07-11 16:02:36 --> Config Class Initialized
INFO - 2018-07-11 16:02:36 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:36 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:36 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:36 --> URI Class Initialized
DEBUG - 2018-07-11 16:02:36 --> No URI present. Default controller set.
INFO - 2018-07-11 16:02:36 --> Router Class Initialized
INFO - 2018-07-11 16:02:36 --> Output Class Initialized
INFO - 2018-07-11 16:02:36 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:36 --> CSRF cookie sent
INFO - 2018-07-11 16:02:36 --> Input Class Initialized
INFO - 2018-07-11 16:02:36 --> Language Class Initialized
INFO - 2018-07-11 16:02:36 --> Loader Class Initialized
INFO - 2018-07-11 16:02:36 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:36 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:36 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:36 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:36 --> Controller Class Initialized
INFO - 2018-07-11 16:02:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:36 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:36 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:36 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:36 --> Total execution time: 0.0366
INFO - 2018-07-11 16:02:37 --> Config Class Initialized
INFO - 2018-07-11 16:02:37 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:37 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:37 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:37 --> URI Class Initialized
DEBUG - 2018-07-11 16:02:37 --> No URI present. Default controller set.
INFO - 2018-07-11 16:02:37 --> Router Class Initialized
INFO - 2018-07-11 16:02:37 --> Output Class Initialized
INFO - 2018-07-11 16:02:37 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:37 --> CSRF cookie sent
INFO - 2018-07-11 16:02:37 --> Input Class Initialized
INFO - 2018-07-11 16:02:37 --> Language Class Initialized
INFO - 2018-07-11 16:02:37 --> Loader Class Initialized
INFO - 2018-07-11 16:02:37 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:37 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:37 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:37 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:37 --> Controller Class Initialized
INFO - 2018-07-11 16:02:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:37 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:37 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:37 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:37 --> Total execution time: 0.0289
INFO - 2018-07-11 16:02:37 --> Config Class Initialized
INFO - 2018-07-11 16:02:37 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:37 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:37 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:37 --> URI Class Initialized
DEBUG - 2018-07-11 16:02:37 --> No URI present. Default controller set.
INFO - 2018-07-11 16:02:37 --> Router Class Initialized
INFO - 2018-07-11 16:02:37 --> Output Class Initialized
INFO - 2018-07-11 16:02:37 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:37 --> CSRF cookie sent
INFO - 2018-07-11 16:02:37 --> Input Class Initialized
INFO - 2018-07-11 16:02:37 --> Language Class Initialized
INFO - 2018-07-11 16:02:37 --> Loader Class Initialized
INFO - 2018-07-11 16:02:37 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:37 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:37 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:37 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:37 --> Controller Class Initialized
INFO - 2018-07-11 16:02:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:37 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:37 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:02:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:37 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:37 --> Total execution time: 0.0365
INFO - 2018-07-11 16:02:38 --> Config Class Initialized
INFO - 2018-07-11 16:02:38 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:38 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:38 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:38 --> URI Class Initialized
INFO - 2018-07-11 16:02:38 --> Router Class Initialized
INFO - 2018-07-11 16:02:38 --> Output Class Initialized
INFO - 2018-07-11 16:02:38 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:38 --> CSRF cookie sent
INFO - 2018-07-11 16:02:38 --> Input Class Initialized
INFO - 2018-07-11 16:02:38 --> Language Class Initialized
ERROR - 2018-07-11 16:02:38 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-11 16:02:47 --> Config Class Initialized
INFO - 2018-07-11 16:02:47 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:47 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:47 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:47 --> URI Class Initialized
DEBUG - 2018-07-11 16:02:47 --> No URI present. Default controller set.
INFO - 2018-07-11 16:02:47 --> Router Class Initialized
INFO - 2018-07-11 16:02:47 --> Output Class Initialized
INFO - 2018-07-11 16:02:47 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:47 --> CSRF cookie sent
INFO - 2018-07-11 16:02:47 --> Input Class Initialized
INFO - 2018-07-11 16:02:47 --> Language Class Initialized
INFO - 2018-07-11 16:02:47 --> Loader Class Initialized
INFO - 2018-07-11 16:02:47 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:47 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:47 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:47 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:47 --> Controller Class Initialized
INFO - 2018-07-11 16:02:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:47 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:47 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:02:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:47 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:47 --> Total execution time: 0.0325
INFO - 2018-07-11 16:02:47 --> Config Class Initialized
INFO - 2018-07-11 16:02:47 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:47 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:47 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:47 --> URI Class Initialized
INFO - 2018-07-11 16:02:47 --> Router Class Initialized
INFO - 2018-07-11 16:02:47 --> Output Class Initialized
INFO - 2018-07-11 16:02:47 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:47 --> CSRF cookie sent
INFO - 2018-07-11 16:02:47 --> Input Class Initialized
INFO - 2018-07-11 16:02:47 --> Language Class Initialized
ERROR - 2018-07-11 16:02:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-11 16:02:47 --> Config Class Initialized
INFO - 2018-07-11 16:02:47 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:47 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:47 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:47 --> URI Class Initialized
INFO - 2018-07-11 16:02:48 --> Router Class Initialized
INFO - 2018-07-11 16:02:48 --> Output Class Initialized
INFO - 2018-07-11 16:02:48 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:48 --> CSRF cookie sent
INFO - 2018-07-11 16:02:48 --> Input Class Initialized
INFO - 2018-07-11 16:02:48 --> Language Class Initialized
ERROR - 2018-07-11 16:02:48 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-11 16:02:48 --> Config Class Initialized
INFO - 2018-07-11 16:02:48 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:48 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:48 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:48 --> URI Class Initialized
INFO - 2018-07-11 16:02:48 --> Router Class Initialized
INFO - 2018-07-11 16:02:48 --> Output Class Initialized
INFO - 2018-07-11 16:02:48 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:48 --> CSRF cookie sent
INFO - 2018-07-11 16:02:48 --> Input Class Initialized
INFO - 2018-07-11 16:02:48 --> Language Class Initialized
INFO - 2018-07-11 16:02:48 --> Loader Class Initialized
INFO - 2018-07-11 16:02:48 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:48 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:48 --> Controller Class Initialized
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:48 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:48 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:48 --> Config Class Initialized
INFO - 2018-07-11 16:02:48 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:48 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:48 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:48 --> URI Class Initialized
INFO - 2018-07-11 16:02:48 --> Router Class Initialized
INFO - 2018-07-11 16:02:48 --> Output Class Initialized
INFO - 2018-07-11 16:02:48 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:48 --> CSRF cookie sent
INFO - 2018-07-11 16:02:48 --> Input Class Initialized
INFO - 2018-07-11 16:02:48 --> Language Class Initialized
INFO - 2018-07-11 16:02:48 --> Loader Class Initialized
INFO - 2018-07-11 16:02:48 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:48 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:48 --> Controller Class Initialized
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-11 16:02:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 16:02:48 --> Could not find the language line "req_email"
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:48 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:48 --> Total execution time: 0.0332
INFO - 2018-07-11 16:02:48 --> Config Class Initialized
INFO - 2018-07-11 16:02:48 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:48 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:48 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:48 --> URI Class Initialized
INFO - 2018-07-11 16:02:48 --> Router Class Initialized
INFO - 2018-07-11 16:02:48 --> Output Class Initialized
INFO - 2018-07-11 16:02:48 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:48 --> CSRF cookie sent
INFO - 2018-07-11 16:02:48 --> Input Class Initialized
INFO - 2018-07-11 16:02:48 --> Language Class Initialized
INFO - 2018-07-11 16:02:48 --> Loader Class Initialized
INFO - 2018-07-11 16:02:48 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:48 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:48 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:48 --> Controller Class Initialized
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-11 16:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:48 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:48 --> Total execution time: 0.0246
INFO - 2018-07-11 16:02:49 --> Config Class Initialized
INFO - 2018-07-11 16:02:49 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:49 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:49 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:49 --> URI Class Initialized
INFO - 2018-07-11 16:02:49 --> Router Class Initialized
INFO - 2018-07-11 16:02:49 --> Output Class Initialized
INFO - 2018-07-11 16:02:49 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:49 --> CSRF cookie sent
INFO - 2018-07-11 16:02:49 --> Input Class Initialized
INFO - 2018-07-11 16:02:49 --> Language Class Initialized
INFO - 2018-07-11 16:02:49 --> Loader Class Initialized
INFO - 2018-07-11 16:02:49 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:49 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:49 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:49 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:49 --> Controller Class Initialized
INFO - 2018-07-11 16:02:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:49 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:49 --> Total execution time: 0.0220
INFO - 2018-07-11 16:02:49 --> Config Class Initialized
INFO - 2018-07-11 16:02:49 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:49 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:49 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:49 --> URI Class Initialized
INFO - 2018-07-11 16:02:49 --> Router Class Initialized
INFO - 2018-07-11 16:02:49 --> Output Class Initialized
INFO - 2018-07-11 16:02:49 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:49 --> CSRF cookie sent
INFO - 2018-07-11 16:02:49 --> Input Class Initialized
INFO - 2018-07-11 16:02:49 --> Language Class Initialized
INFO - 2018-07-11 16:02:49 --> Loader Class Initialized
INFO - 2018-07-11 16:02:49 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:49 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:49 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:49 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:49 --> Controller Class Initialized
INFO - 2018-07-11 16:02:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-11 16:02:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:49 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:49 --> Total execution time: 0.0216
INFO - 2018-07-11 16:02:50 --> Config Class Initialized
INFO - 2018-07-11 16:02:50 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:50 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:50 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:50 --> URI Class Initialized
INFO - 2018-07-11 16:02:50 --> Router Class Initialized
INFO - 2018-07-11 16:02:50 --> Output Class Initialized
INFO - 2018-07-11 16:02:50 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:50 --> CSRF cookie sent
INFO - 2018-07-11 16:02:50 --> Input Class Initialized
INFO - 2018-07-11 16:02:50 --> Language Class Initialized
INFO - 2018-07-11 16:02:50 --> Loader Class Initialized
INFO - 2018-07-11 16:02:50 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:50 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:50 --> Controller Class Initialized
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:50 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:50 --> Total execution time: 0.0258
INFO - 2018-07-11 16:02:50 --> Config Class Initialized
INFO - 2018-07-11 16:02:50 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:50 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:50 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:50 --> URI Class Initialized
INFO - 2018-07-11 16:02:50 --> Router Class Initialized
INFO - 2018-07-11 16:02:50 --> Output Class Initialized
INFO - 2018-07-11 16:02:50 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:50 --> CSRF cookie sent
INFO - 2018-07-11 16:02:50 --> Input Class Initialized
INFO - 2018-07-11 16:02:50 --> Language Class Initialized
INFO - 2018-07-11 16:02:50 --> Loader Class Initialized
INFO - 2018-07-11 16:02:50 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:50 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:50 --> Controller Class Initialized
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-11 16:02:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 16:02:50 --> Could not find the language line "req_email"
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:50 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:50 --> Total execution time: 0.0240
INFO - 2018-07-11 16:02:50 --> Config Class Initialized
INFO - 2018-07-11 16:02:50 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:02:50 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:02:50 --> Utf8 Class Initialized
INFO - 2018-07-11 16:02:50 --> URI Class Initialized
INFO - 2018-07-11 16:02:50 --> Router Class Initialized
INFO - 2018-07-11 16:02:50 --> Output Class Initialized
INFO - 2018-07-11 16:02:50 --> Security Class Initialized
DEBUG - 2018-07-11 16:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:02:50 --> CSRF cookie sent
INFO - 2018-07-11 16:02:50 --> Input Class Initialized
INFO - 2018-07-11 16:02:50 --> Language Class Initialized
INFO - 2018-07-11 16:02:50 --> Loader Class Initialized
INFO - 2018-07-11 16:02:50 --> Helper loaded: url_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: form_helper
INFO - 2018-07-11 16:02:50 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:02:50 --> User Agent Class Initialized
INFO - 2018-07-11 16:02:50 --> Controller Class Initialized
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:02:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:02:50 --> Pixel_Model class loaded
INFO - 2018-07-11 16:02:50 --> Database Driver Class Initialized
INFO - 2018-07-11 16:02:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-11 16:02:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:02:50 --> Final output sent to browser
DEBUG - 2018-07-11 16:02:50 --> Total execution time: 0.0333
INFO - 2018-07-11 16:07:08 --> Config Class Initialized
INFO - 2018-07-11 16:07:08 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:07:08 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:07:08 --> Utf8 Class Initialized
INFO - 2018-07-11 16:07:08 --> URI Class Initialized
DEBUG - 2018-07-11 16:07:08 --> No URI present. Default controller set.
INFO - 2018-07-11 16:07:08 --> Router Class Initialized
INFO - 2018-07-11 16:07:08 --> Output Class Initialized
INFO - 2018-07-11 16:07:08 --> Security Class Initialized
DEBUG - 2018-07-11 16:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:07:08 --> CSRF cookie sent
INFO - 2018-07-11 16:07:08 --> Input Class Initialized
INFO - 2018-07-11 16:07:08 --> Language Class Initialized
INFO - 2018-07-11 16:07:08 --> Loader Class Initialized
INFO - 2018-07-11 16:07:08 --> Helper loaded: url_helper
INFO - 2018-07-11 16:07:08 --> Helper loaded: form_helper
INFO - 2018-07-11 16:07:08 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:07:08 --> User Agent Class Initialized
INFO - 2018-07-11 16:07:08 --> Controller Class Initialized
INFO - 2018-07-11 16:07:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:07:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:07:08 --> Pixel_Model class loaded
INFO - 2018-07-11 16:07:08 --> Database Driver Class Initialized
INFO - 2018-07-11 16:07:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:07:08 --> Final output sent to browser
DEBUG - 2018-07-11 16:07:08 --> Total execution time: 0.0341
INFO - 2018-07-11 16:15:03 --> Config Class Initialized
INFO - 2018-07-11 16:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:15:03 --> Utf8 Class Initialized
INFO - 2018-07-11 16:15:03 --> URI Class Initialized
DEBUG - 2018-07-11 16:15:03 --> No URI present. Default controller set.
INFO - 2018-07-11 16:15:03 --> Router Class Initialized
INFO - 2018-07-11 16:15:03 --> Output Class Initialized
INFO - 2018-07-11 16:15:03 --> Security Class Initialized
DEBUG - 2018-07-11 16:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:15:03 --> CSRF cookie sent
INFO - 2018-07-11 16:15:03 --> Input Class Initialized
INFO - 2018-07-11 16:15:03 --> Language Class Initialized
INFO - 2018-07-11 16:15:03 --> Loader Class Initialized
INFO - 2018-07-11 16:15:03 --> Helper loaded: url_helper
INFO - 2018-07-11 16:15:03 --> Helper loaded: form_helper
INFO - 2018-07-11 16:15:03 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:15:03 --> User Agent Class Initialized
INFO - 2018-07-11 16:15:03 --> Controller Class Initialized
INFO - 2018-07-11 16:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:15:03 --> Pixel_Model class loaded
INFO - 2018-07-11 16:15:03 --> Database Driver Class Initialized
INFO - 2018-07-11 16:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:15:03 --> Final output sent to browser
DEBUG - 2018-07-11 16:15:03 --> Total execution time: 0.0459
INFO - 2018-07-11 16:15:05 --> Config Class Initialized
INFO - 2018-07-11 16:15:05 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:15:05 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:15:05 --> Utf8 Class Initialized
INFO - 2018-07-11 16:15:05 --> URI Class Initialized
INFO - 2018-07-11 16:15:05 --> Router Class Initialized
INFO - 2018-07-11 16:15:05 --> Output Class Initialized
INFO - 2018-07-11 16:15:05 --> Security Class Initialized
DEBUG - 2018-07-11 16:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:15:05 --> CSRF cookie sent
INFO - 2018-07-11 16:15:05 --> Input Class Initialized
INFO - 2018-07-11 16:15:05 --> Language Class Initialized
ERROR - 2018-07-11 16:15:05 --> 404 Page Not Found: Assets/css
INFO - 2018-07-11 16:15:12 --> Config Class Initialized
INFO - 2018-07-11 16:15:12 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:15:12 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:15:12 --> Utf8 Class Initialized
INFO - 2018-07-11 16:15:12 --> URI Class Initialized
DEBUG - 2018-07-11 16:15:12 --> No URI present. Default controller set.
INFO - 2018-07-11 16:15:12 --> Router Class Initialized
INFO - 2018-07-11 16:15:12 --> Output Class Initialized
INFO - 2018-07-11 16:15:12 --> Security Class Initialized
DEBUG - 2018-07-11 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:15:12 --> CSRF cookie sent
INFO - 2018-07-11 16:15:12 --> Input Class Initialized
INFO - 2018-07-11 16:15:12 --> Language Class Initialized
INFO - 2018-07-11 16:15:12 --> Loader Class Initialized
INFO - 2018-07-11 16:15:12 --> Helper loaded: url_helper
INFO - 2018-07-11 16:15:12 --> Helper loaded: form_helper
INFO - 2018-07-11 16:15:12 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:15:12 --> User Agent Class Initialized
INFO - 2018-07-11 16:15:12 --> Controller Class Initialized
INFO - 2018-07-11 16:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:15:12 --> Pixel_Model class loaded
INFO - 2018-07-11 16:15:12 --> Database Driver Class Initialized
INFO - 2018-07-11 16:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 16:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 16:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:15:12 --> Final output sent to browser
DEBUG - 2018-07-11 16:15:12 --> Total execution time: 0.0305
INFO - 2018-07-11 16:15:22 --> Config Class Initialized
INFO - 2018-07-11 16:15:22 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:15:22 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:15:22 --> Utf8 Class Initialized
INFO - 2018-07-11 16:15:22 --> URI Class Initialized
INFO - 2018-07-11 16:15:22 --> Router Class Initialized
INFO - 2018-07-11 16:15:22 --> Output Class Initialized
INFO - 2018-07-11 16:15:22 --> Security Class Initialized
DEBUG - 2018-07-11 16:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:15:22 --> CSRF cookie sent
INFO - 2018-07-11 16:15:22 --> Input Class Initialized
INFO - 2018-07-11 16:15:22 --> Language Class Initialized
INFO - 2018-07-11 16:15:22 --> Loader Class Initialized
INFO - 2018-07-11 16:15:22 --> Helper loaded: url_helper
INFO - 2018-07-11 16:15:22 --> Helper loaded: form_helper
INFO - 2018-07-11 16:15:22 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:15:22 --> User Agent Class Initialized
INFO - 2018-07-11 16:15:22 --> Controller Class Initialized
INFO - 2018-07-11 16:15:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:15:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-11 16:15:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 16:15:22 --> Could not find the language line "req_email"
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-11 16:15:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:15:22 --> Final output sent to browser
DEBUG - 2018-07-11 16:15:22 --> Total execution time: 0.0258
INFO - 2018-07-11 16:15:27 --> Config Class Initialized
INFO - 2018-07-11 16:15:27 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:15:27 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:15:27 --> Utf8 Class Initialized
INFO - 2018-07-11 16:15:27 --> URI Class Initialized
INFO - 2018-07-11 16:15:27 --> Router Class Initialized
INFO - 2018-07-11 16:15:27 --> Output Class Initialized
INFO - 2018-07-11 16:15:27 --> Security Class Initialized
DEBUG - 2018-07-11 16:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:15:27 --> CSRF cookie sent
INFO - 2018-07-11 16:15:27 --> Input Class Initialized
INFO - 2018-07-11 16:15:27 --> Language Class Initialized
INFO - 2018-07-11 16:15:27 --> Loader Class Initialized
INFO - 2018-07-11 16:15:27 --> Helper loaded: url_helper
INFO - 2018-07-11 16:15:27 --> Helper loaded: form_helper
INFO - 2018-07-11 16:15:27 --> Helper loaded: language_helper
DEBUG - 2018-07-11 16:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 16:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 16:15:27 --> User Agent Class Initialized
INFO - 2018-07-11 16:15:27 --> Controller Class Initialized
INFO - 2018-07-11 16:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 16:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 16:15:27 --> Pixel_Model class loaded
INFO - 2018-07-11 16:15:27 --> Database Driver Class Initialized
INFO - 2018-07-11 16:15:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-11 16:15:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-11 16:15:27 --> Could not find the language line "req_email"
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-11 16:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 16:15:27 --> Final output sent to browser
DEBUG - 2018-07-11 16:15:27 --> Total execution time: 0.0373
INFO - 2018-07-11 16:57:03 --> Config Class Initialized
INFO - 2018-07-11 16:57:03 --> Hooks Class Initialized
DEBUG - 2018-07-11 16:57:03 --> UTF-8 Support Enabled
INFO - 2018-07-11 16:57:03 --> Utf8 Class Initialized
INFO - 2018-07-11 16:57:03 --> URI Class Initialized
INFO - 2018-07-11 16:57:03 --> Router Class Initialized
INFO - 2018-07-11 16:57:03 --> Output Class Initialized
INFO - 2018-07-11 16:57:03 --> Security Class Initialized
DEBUG - 2018-07-11 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 16:57:03 --> CSRF cookie sent
INFO - 2018-07-11 16:57:03 --> Input Class Initialized
INFO - 2018-07-11 16:57:03 --> Language Class Initialized
ERROR - 2018-07-11 16:57:03 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 17:24:59 --> Config Class Initialized
INFO - 2018-07-11 17:24:59 --> Hooks Class Initialized
DEBUG - 2018-07-11 17:24:59 --> UTF-8 Support Enabled
INFO - 2018-07-11 17:24:59 --> Utf8 Class Initialized
INFO - 2018-07-11 17:24:59 --> URI Class Initialized
INFO - 2018-07-11 17:24:59 --> Router Class Initialized
INFO - 2018-07-11 17:24:59 --> Output Class Initialized
INFO - 2018-07-11 17:24:59 --> Security Class Initialized
DEBUG - 2018-07-11 17:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 17:24:59 --> CSRF cookie sent
INFO - 2018-07-11 17:24:59 --> Input Class Initialized
INFO - 2018-07-11 17:24:59 --> Language Class Initialized
ERROR - 2018-07-11 17:24:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 18:24:48 --> Config Class Initialized
INFO - 2018-07-11 18:24:48 --> Hooks Class Initialized
DEBUG - 2018-07-11 18:24:48 --> UTF-8 Support Enabled
INFO - 2018-07-11 18:24:48 --> Utf8 Class Initialized
INFO - 2018-07-11 18:24:48 --> URI Class Initialized
DEBUG - 2018-07-11 18:24:48 --> No URI present. Default controller set.
INFO - 2018-07-11 18:24:48 --> Router Class Initialized
INFO - 2018-07-11 18:24:48 --> Output Class Initialized
INFO - 2018-07-11 18:24:48 --> Security Class Initialized
DEBUG - 2018-07-11 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 18:24:48 --> CSRF cookie sent
INFO - 2018-07-11 18:24:48 --> Input Class Initialized
INFO - 2018-07-11 18:24:48 --> Language Class Initialized
INFO - 2018-07-11 18:24:48 --> Loader Class Initialized
INFO - 2018-07-11 18:24:48 --> Helper loaded: url_helper
INFO - 2018-07-11 18:24:48 --> Helper loaded: form_helper
INFO - 2018-07-11 18:24:48 --> Helper loaded: language_helper
DEBUG - 2018-07-11 18:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 18:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 18:24:48 --> User Agent Class Initialized
INFO - 2018-07-11 18:24:48 --> Controller Class Initialized
INFO - 2018-07-11 18:24:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 18:24:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 18:24:48 --> Pixel_Model class loaded
INFO - 2018-07-11 18:24:48 --> Database Driver Class Initialized
INFO - 2018-07-11 18:24:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 18:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 18:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 18:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 18:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 18:24:48 --> Final output sent to browser
DEBUG - 2018-07-11 18:24:48 --> Total execution time: 0.0412
INFO - 2018-07-11 18:46:12 --> Config Class Initialized
INFO - 2018-07-11 18:46:12 --> Hooks Class Initialized
DEBUG - 2018-07-11 18:46:12 --> UTF-8 Support Enabled
INFO - 2018-07-11 18:46:12 --> Utf8 Class Initialized
INFO - 2018-07-11 18:46:12 --> URI Class Initialized
INFO - 2018-07-11 18:46:12 --> Router Class Initialized
INFO - 2018-07-11 18:46:12 --> Output Class Initialized
INFO - 2018-07-11 18:46:12 --> Security Class Initialized
DEBUG - 2018-07-11 18:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 18:46:12 --> CSRF cookie sent
INFO - 2018-07-11 18:46:12 --> Input Class Initialized
INFO - 2018-07-11 18:46:12 --> Language Class Initialized
ERROR - 2018-07-11 18:46:12 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-11 18:46:16 --> Config Class Initialized
INFO - 2018-07-11 18:46:16 --> Hooks Class Initialized
DEBUG - 2018-07-11 18:46:16 --> UTF-8 Support Enabled
INFO - 2018-07-11 18:46:16 --> Utf8 Class Initialized
INFO - 2018-07-11 18:46:16 --> URI Class Initialized
DEBUG - 2018-07-11 18:46:16 --> No URI present. Default controller set.
INFO - 2018-07-11 18:46:16 --> Router Class Initialized
INFO - 2018-07-11 18:46:16 --> Output Class Initialized
INFO - 2018-07-11 18:46:16 --> Security Class Initialized
DEBUG - 2018-07-11 18:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 18:46:16 --> CSRF cookie sent
INFO - 2018-07-11 18:46:16 --> Input Class Initialized
INFO - 2018-07-11 18:46:16 --> Language Class Initialized
INFO - 2018-07-11 18:46:16 --> Loader Class Initialized
INFO - 2018-07-11 18:46:16 --> Helper loaded: url_helper
INFO - 2018-07-11 18:46:16 --> Helper loaded: form_helper
INFO - 2018-07-11 18:46:16 --> Helper loaded: language_helper
DEBUG - 2018-07-11 18:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 18:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 18:46:16 --> User Agent Class Initialized
INFO - 2018-07-11 18:46:16 --> Controller Class Initialized
INFO - 2018-07-11 18:46:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 18:46:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 18:46:16 --> Pixel_Model class loaded
INFO - 2018-07-11 18:46:16 --> Database Driver Class Initialized
INFO - 2018-07-11 18:46:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 18:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 18:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 18:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 18:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 18:46:16 --> Final output sent to browser
DEBUG - 2018-07-11 18:46:16 --> Total execution time: 0.0342
INFO - 2018-07-11 20:43:28 --> Config Class Initialized
INFO - 2018-07-11 20:43:28 --> Hooks Class Initialized
DEBUG - 2018-07-11 20:43:28 --> UTF-8 Support Enabled
INFO - 2018-07-11 20:43:28 --> Utf8 Class Initialized
INFO - 2018-07-11 20:43:28 --> URI Class Initialized
DEBUG - 2018-07-11 20:43:28 --> No URI present. Default controller set.
INFO - 2018-07-11 20:43:28 --> Router Class Initialized
INFO - 2018-07-11 20:43:28 --> Output Class Initialized
INFO - 2018-07-11 20:43:28 --> Security Class Initialized
DEBUG - 2018-07-11 20:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 20:43:28 --> CSRF cookie sent
INFO - 2018-07-11 20:43:28 --> Input Class Initialized
INFO - 2018-07-11 20:43:28 --> Language Class Initialized
INFO - 2018-07-11 20:43:28 --> Loader Class Initialized
INFO - 2018-07-11 20:43:28 --> Helper loaded: url_helper
INFO - 2018-07-11 20:43:28 --> Helper loaded: form_helper
INFO - 2018-07-11 20:43:28 --> Helper loaded: language_helper
DEBUG - 2018-07-11 20:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 20:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 20:43:28 --> User Agent Class Initialized
INFO - 2018-07-11 20:43:28 --> Controller Class Initialized
INFO - 2018-07-11 20:43:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 20:43:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 20:43:28 --> Pixel_Model class loaded
INFO - 2018-07-11 20:43:28 --> Database Driver Class Initialized
INFO - 2018-07-11 20:43:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 20:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 20:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 20:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 20:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 20:43:28 --> Final output sent to browser
DEBUG - 2018-07-11 20:43:28 --> Total execution time: 0.0408
INFO - 2018-07-11 21:01:51 --> Config Class Initialized
INFO - 2018-07-11 21:01:51 --> Hooks Class Initialized
DEBUG - 2018-07-11 21:01:51 --> UTF-8 Support Enabled
INFO - 2018-07-11 21:01:51 --> Utf8 Class Initialized
INFO - 2018-07-11 21:01:51 --> URI Class Initialized
DEBUG - 2018-07-11 21:01:51 --> No URI present. Default controller set.
INFO - 2018-07-11 21:01:51 --> Router Class Initialized
INFO - 2018-07-11 21:01:51 --> Output Class Initialized
INFO - 2018-07-11 21:01:51 --> Security Class Initialized
DEBUG - 2018-07-11 21:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-11 21:01:51 --> CSRF cookie sent
INFO - 2018-07-11 21:01:51 --> Input Class Initialized
INFO - 2018-07-11 21:01:51 --> Language Class Initialized
INFO - 2018-07-11 21:01:51 --> Loader Class Initialized
INFO - 2018-07-11 21:01:51 --> Helper loaded: url_helper
INFO - 2018-07-11 21:01:51 --> Helper loaded: form_helper
INFO - 2018-07-11 21:01:51 --> Helper loaded: language_helper
DEBUG - 2018-07-11 21:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-11 21:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-11 21:01:51 --> User Agent Class Initialized
INFO - 2018-07-11 21:01:51 --> Controller Class Initialized
INFO - 2018-07-11 21:01:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-11 21:01:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-11 21:01:51 --> Pixel_Model class loaded
INFO - 2018-07-11 21:01:51 --> Database Driver Class Initialized
INFO - 2018-07-11 21:01:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-11 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-11 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-11 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-11 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-11 21:01:51 --> Final output sent to browser
DEBUG - 2018-07-11 21:01:51 --> Total execution time: 0.0413

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-13 01:48:34 --> Config Class Initialized
INFO - 2018-07-13 01:48:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 01:48:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 01:48:34 --> Utf8 Class Initialized
INFO - 2018-07-13 01:48:34 --> URI Class Initialized
DEBUG - 2018-07-13 01:48:34 --> No URI present. Default controller set.
INFO - 2018-07-13 01:48:34 --> Router Class Initialized
INFO - 2018-07-13 01:48:34 --> Output Class Initialized
INFO - 2018-07-13 01:48:34 --> Security Class Initialized
DEBUG - 2018-07-13 01:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 01:48:34 --> CSRF cookie sent
INFO - 2018-07-13 01:48:34 --> Input Class Initialized
INFO - 2018-07-13 01:48:34 --> Language Class Initialized
INFO - 2018-07-13 01:48:34 --> Loader Class Initialized
INFO - 2018-07-13 01:48:34 --> Helper loaded: url_helper
INFO - 2018-07-13 01:48:34 --> Helper loaded: form_helper
INFO - 2018-07-13 01:48:34 --> Helper loaded: language_helper
DEBUG - 2018-07-13 01:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 01:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 01:48:34 --> User Agent Class Initialized
INFO - 2018-07-13 01:48:34 --> Controller Class Initialized
INFO - 2018-07-13 01:48:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 01:48:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 01:48:34 --> Pixel_Model class loaded
INFO - 2018-07-13 01:48:34 --> Database Driver Class Initialized
INFO - 2018-07-13 01:48:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 01:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 01:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 01:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 01:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 01:48:34 --> Final output sent to browser
DEBUG - 2018-07-13 01:48:34 --> Total execution time: 0.0364
INFO - 2018-07-13 01:50:59 --> Config Class Initialized
INFO - 2018-07-13 01:50:59 --> Hooks Class Initialized
DEBUG - 2018-07-13 01:50:59 --> UTF-8 Support Enabled
INFO - 2018-07-13 01:50:59 --> Utf8 Class Initialized
INFO - 2018-07-13 01:50:59 --> URI Class Initialized
DEBUG - 2018-07-13 01:50:59 --> No URI present. Default controller set.
INFO - 2018-07-13 01:50:59 --> Router Class Initialized
INFO - 2018-07-13 01:50:59 --> Output Class Initialized
INFO - 2018-07-13 01:50:59 --> Security Class Initialized
DEBUG - 2018-07-13 01:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 01:50:59 --> CSRF cookie sent
INFO - 2018-07-13 01:50:59 --> Input Class Initialized
INFO - 2018-07-13 01:50:59 --> Language Class Initialized
INFO - 2018-07-13 01:50:59 --> Loader Class Initialized
INFO - 2018-07-13 01:50:59 --> Helper loaded: url_helper
INFO - 2018-07-13 01:50:59 --> Helper loaded: form_helper
INFO - 2018-07-13 01:50:59 --> Helper loaded: language_helper
DEBUG - 2018-07-13 01:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 01:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 01:50:59 --> User Agent Class Initialized
INFO - 2018-07-13 01:50:59 --> Controller Class Initialized
INFO - 2018-07-13 01:50:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 01:50:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 01:50:59 --> Pixel_Model class loaded
INFO - 2018-07-13 01:50:59 --> Database Driver Class Initialized
INFO - 2018-07-13 01:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 01:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 01:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 01:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 01:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 01:50:59 --> Final output sent to browser
DEBUG - 2018-07-13 01:50:59 --> Total execution time: 0.0316
INFO - 2018-07-13 02:28:13 --> Config Class Initialized
INFO - 2018-07-13 02:28:13 --> Hooks Class Initialized
DEBUG - 2018-07-13 02:28:13 --> UTF-8 Support Enabled
INFO - 2018-07-13 02:28:13 --> Utf8 Class Initialized
INFO - 2018-07-13 02:28:13 --> URI Class Initialized
DEBUG - 2018-07-13 02:28:13 --> No URI present. Default controller set.
INFO - 2018-07-13 02:28:13 --> Router Class Initialized
INFO - 2018-07-13 02:28:13 --> Output Class Initialized
INFO - 2018-07-13 02:28:13 --> Security Class Initialized
DEBUG - 2018-07-13 02:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 02:28:13 --> CSRF cookie sent
INFO - 2018-07-13 02:28:13 --> Input Class Initialized
INFO - 2018-07-13 02:28:13 --> Language Class Initialized
INFO - 2018-07-13 02:28:13 --> Loader Class Initialized
INFO - 2018-07-13 02:28:13 --> Helper loaded: url_helper
INFO - 2018-07-13 02:28:13 --> Helper loaded: form_helper
INFO - 2018-07-13 02:28:13 --> Helper loaded: language_helper
DEBUG - 2018-07-13 02:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 02:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 02:28:13 --> User Agent Class Initialized
INFO - 2018-07-13 02:28:13 --> Controller Class Initialized
INFO - 2018-07-13 02:28:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 02:28:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 02:28:13 --> Pixel_Model class loaded
INFO - 2018-07-13 02:28:13 --> Database Driver Class Initialized
INFO - 2018-07-13 02:28:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 02:28:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 02:28:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 02:28:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 02:28:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 02:28:13 --> Final output sent to browser
DEBUG - 2018-07-13 02:28:13 --> Total execution time: 0.0456
INFO - 2018-07-13 02:28:20 --> Config Class Initialized
INFO - 2018-07-13 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-13 02:28:20 --> URI Class Initialized
INFO - 2018-07-13 02:28:20 --> Router Class Initialized
INFO - 2018-07-13 02:28:20 --> Output Class Initialized
INFO - 2018-07-13 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-13 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 02:28:20 --> CSRF cookie sent
INFO - 2018-07-13 02:28:20 --> CSRF token verified
INFO - 2018-07-13 02:28:20 --> Input Class Initialized
INFO - 2018-07-13 02:28:20 --> Language Class Initialized
INFO - 2018-07-13 02:28:20 --> Loader Class Initialized
INFO - 2018-07-13 02:28:20 --> Helper loaded: url_helper
INFO - 2018-07-13 02:28:20 --> Helper loaded: form_helper
INFO - 2018-07-13 02:28:20 --> Helper loaded: language_helper
DEBUG - 2018-07-13 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 02:28:20 --> User Agent Class Initialized
INFO - 2018-07-13 02:28:20 --> Controller Class Initialized
INFO - 2018-07-13 02:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 02:28:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 02:28:20 --> Pixel_Model class loaded
INFO - 2018-07-13 02:28:20 --> Database Driver Class Initialized
INFO - 2018-07-13 02:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 02:28:20 --> Config Class Initialized
INFO - 2018-07-13 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-13 02:28:20 --> URI Class Initialized
INFO - 2018-07-13 02:28:20 --> Router Class Initialized
INFO - 2018-07-13 02:28:20 --> Output Class Initialized
INFO - 2018-07-13 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-13 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 02:28:20 --> CSRF cookie sent
INFO - 2018-07-13 02:28:20 --> Input Class Initialized
INFO - 2018-07-13 02:28:20 --> Language Class Initialized
INFO - 2018-07-13 02:28:20 --> Loader Class Initialized
INFO - 2018-07-13 02:28:20 --> Helper loaded: url_helper
INFO - 2018-07-13 02:28:20 --> Helper loaded: form_helper
INFO - 2018-07-13 02:28:20 --> Helper loaded: language_helper
DEBUG - 2018-07-13 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 02:28:20 --> User Agent Class Initialized
INFO - 2018-07-13 02:28:20 --> Controller Class Initialized
INFO - 2018-07-13 02:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 02:28:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-13 02:28:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-13 02:28:20 --> Could not find the language line "req_email"
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-13 02:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 02:28:20 --> Final output sent to browser
DEBUG - 2018-07-13 02:28:20 --> Total execution time: 0.0228
INFO - 2018-07-13 04:11:01 --> Config Class Initialized
INFO - 2018-07-13 04:11:01 --> Hooks Class Initialized
DEBUG - 2018-07-13 04:11:01 --> UTF-8 Support Enabled
INFO - 2018-07-13 04:11:01 --> Utf8 Class Initialized
INFO - 2018-07-13 04:11:01 --> URI Class Initialized
INFO - 2018-07-13 04:11:01 --> Router Class Initialized
INFO - 2018-07-13 04:11:01 --> Output Class Initialized
INFO - 2018-07-13 04:11:01 --> Security Class Initialized
DEBUG - 2018-07-13 04:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 04:11:01 --> CSRF cookie sent
INFO - 2018-07-13 04:11:01 --> Input Class Initialized
INFO - 2018-07-13 04:11:01 --> Language Class Initialized
ERROR - 2018-07-13 04:11:01 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 04:11:04 --> Config Class Initialized
INFO - 2018-07-13 04:11:04 --> Hooks Class Initialized
DEBUG - 2018-07-13 04:11:04 --> UTF-8 Support Enabled
INFO - 2018-07-13 04:11:04 --> Utf8 Class Initialized
INFO - 2018-07-13 04:11:04 --> URI Class Initialized
DEBUG - 2018-07-13 04:11:04 --> No URI present. Default controller set.
INFO - 2018-07-13 04:11:04 --> Router Class Initialized
INFO - 2018-07-13 04:11:04 --> Output Class Initialized
INFO - 2018-07-13 04:11:04 --> Security Class Initialized
DEBUG - 2018-07-13 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 04:11:04 --> CSRF cookie sent
INFO - 2018-07-13 04:11:04 --> Input Class Initialized
INFO - 2018-07-13 04:11:04 --> Language Class Initialized
INFO - 2018-07-13 04:11:04 --> Loader Class Initialized
INFO - 2018-07-13 04:11:04 --> Helper loaded: url_helper
INFO - 2018-07-13 04:11:04 --> Helper loaded: form_helper
INFO - 2018-07-13 04:11:04 --> Helper loaded: language_helper
DEBUG - 2018-07-13 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 04:11:04 --> User Agent Class Initialized
INFO - 2018-07-13 04:11:04 --> Controller Class Initialized
INFO - 2018-07-13 04:11:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 04:11:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 04:11:04 --> Pixel_Model class loaded
INFO - 2018-07-13 04:11:04 --> Database Driver Class Initialized
INFO - 2018-07-13 04:11:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 04:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 04:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 04:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 04:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 04:11:04 --> Final output sent to browser
DEBUG - 2018-07-13 04:11:04 --> Total execution time: 0.0377
INFO - 2018-07-13 06:47:51 --> Config Class Initialized
INFO - 2018-07-13 06:47:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:47:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:47:51 --> Utf8 Class Initialized
INFO - 2018-07-13 06:47:51 --> URI Class Initialized
INFO - 2018-07-13 06:47:51 --> Router Class Initialized
INFO - 2018-07-13 06:47:51 --> Output Class Initialized
INFO - 2018-07-13 06:47:51 --> Security Class Initialized
DEBUG - 2018-07-13 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:47:51 --> CSRF cookie sent
INFO - 2018-07-13 06:47:51 --> Input Class Initialized
INFO - 2018-07-13 06:47:51 --> Language Class Initialized
ERROR - 2018-07-13 06:47:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 06:47:53 --> Config Class Initialized
INFO - 2018-07-13 06:47:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:47:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:47:53 --> Utf8 Class Initialized
INFO - 2018-07-13 06:47:53 --> URI Class Initialized
DEBUG - 2018-07-13 06:47:53 --> No URI present. Default controller set.
INFO - 2018-07-13 06:47:53 --> Router Class Initialized
INFO - 2018-07-13 06:47:53 --> Output Class Initialized
INFO - 2018-07-13 06:47:53 --> Security Class Initialized
DEBUG - 2018-07-13 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:47:53 --> CSRF cookie sent
INFO - 2018-07-13 06:47:53 --> Input Class Initialized
INFO - 2018-07-13 06:47:53 --> Language Class Initialized
INFO - 2018-07-13 06:47:53 --> Loader Class Initialized
INFO - 2018-07-13 06:47:53 --> Helper loaded: url_helper
INFO - 2018-07-13 06:47:53 --> Helper loaded: form_helper
INFO - 2018-07-13 06:47:53 --> Helper loaded: language_helper
DEBUG - 2018-07-13 06:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:47:53 --> User Agent Class Initialized
INFO - 2018-07-13 06:47:53 --> Controller Class Initialized
INFO - 2018-07-13 06:47:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 06:47:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 06:47:53 --> Pixel_Model class loaded
INFO - 2018-07-13 06:47:53 --> Database Driver Class Initialized
INFO - 2018-07-13 06:47:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 06:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 06:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 06:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 06:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 06:47:53 --> Final output sent to browser
DEBUG - 2018-07-13 06:47:53 --> Total execution time: 0.0325
INFO - 2018-07-13 09:52:18 --> Config Class Initialized
INFO - 2018-07-13 09:52:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:52:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:52:18 --> Utf8 Class Initialized
INFO - 2018-07-13 09:52:18 --> URI Class Initialized
DEBUG - 2018-07-13 09:52:18 --> No URI present. Default controller set.
INFO - 2018-07-13 09:52:18 --> Router Class Initialized
INFO - 2018-07-13 09:52:18 --> Output Class Initialized
INFO - 2018-07-13 09:52:18 --> Security Class Initialized
DEBUG - 2018-07-13 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:52:18 --> CSRF cookie sent
INFO - 2018-07-13 09:52:18 --> Input Class Initialized
INFO - 2018-07-13 09:52:18 --> Language Class Initialized
INFO - 2018-07-13 09:52:18 --> Loader Class Initialized
INFO - 2018-07-13 09:52:18 --> Helper loaded: url_helper
INFO - 2018-07-13 09:52:18 --> Helper loaded: form_helper
INFO - 2018-07-13 09:52:18 --> Helper loaded: language_helper
DEBUG - 2018-07-13 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:52:18 --> User Agent Class Initialized
INFO - 2018-07-13 09:52:18 --> Controller Class Initialized
INFO - 2018-07-13 09:52:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 09:52:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 09:52:18 --> Pixel_Model class loaded
INFO - 2018-07-13 09:52:18 --> Database Driver Class Initialized
INFO - 2018-07-13 09:52:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 09:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 09:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 09:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 09:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 09:52:18 --> Final output sent to browser
DEBUG - 2018-07-13 09:52:18 --> Total execution time: 0.0359
INFO - 2018-07-13 10:15:07 --> Config Class Initialized
INFO - 2018-07-13 10:15:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 10:15:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 10:15:07 --> Utf8 Class Initialized
INFO - 2018-07-13 10:15:07 --> URI Class Initialized
INFO - 2018-07-13 10:15:07 --> Router Class Initialized
INFO - 2018-07-13 10:15:07 --> Output Class Initialized
INFO - 2018-07-13 10:15:07 --> Security Class Initialized
DEBUG - 2018-07-13 10:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 10:15:07 --> CSRF cookie sent
INFO - 2018-07-13 10:15:07 --> Input Class Initialized
INFO - 2018-07-13 10:15:07 --> Language Class Initialized
ERROR - 2018-07-13 10:15:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 10:15:11 --> Config Class Initialized
INFO - 2018-07-13 10:15:11 --> Hooks Class Initialized
DEBUG - 2018-07-13 10:15:11 --> UTF-8 Support Enabled
INFO - 2018-07-13 10:15:11 --> Utf8 Class Initialized
INFO - 2018-07-13 10:15:11 --> URI Class Initialized
INFO - 2018-07-13 10:15:11 --> Router Class Initialized
INFO - 2018-07-13 10:15:11 --> Output Class Initialized
INFO - 2018-07-13 10:15:11 --> Security Class Initialized
DEBUG - 2018-07-13 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 10:15:11 --> CSRF cookie sent
INFO - 2018-07-13 10:15:11 --> Input Class Initialized
INFO - 2018-07-13 10:15:11 --> Language Class Initialized
ERROR - 2018-07-13 10:15:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 10:15:17 --> Config Class Initialized
INFO - 2018-07-13 10:15:17 --> Hooks Class Initialized
DEBUG - 2018-07-13 10:15:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 10:15:17 --> Utf8 Class Initialized
INFO - 2018-07-13 10:15:17 --> URI Class Initialized
DEBUG - 2018-07-13 10:15:17 --> No URI present. Default controller set.
INFO - 2018-07-13 10:15:17 --> Router Class Initialized
INFO - 2018-07-13 10:15:17 --> Output Class Initialized
INFO - 2018-07-13 10:15:17 --> Security Class Initialized
DEBUG - 2018-07-13 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 10:15:17 --> CSRF cookie sent
INFO - 2018-07-13 10:15:17 --> Input Class Initialized
INFO - 2018-07-13 10:15:17 --> Language Class Initialized
INFO - 2018-07-13 10:15:17 --> Loader Class Initialized
INFO - 2018-07-13 10:15:17 --> Helper loaded: url_helper
INFO - 2018-07-13 10:15:17 --> Helper loaded: form_helper
INFO - 2018-07-13 10:15:17 --> Helper loaded: language_helper
DEBUG - 2018-07-13 10:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 10:15:17 --> User Agent Class Initialized
INFO - 2018-07-13 10:15:17 --> Controller Class Initialized
INFO - 2018-07-13 10:15:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 10:15:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 10:15:17 --> Pixel_Model class loaded
INFO - 2018-07-13 10:15:17 --> Database Driver Class Initialized
INFO - 2018-07-13 10:15:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 10:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 10:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 10:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 10:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 10:15:17 --> Final output sent to browser
DEBUG - 2018-07-13 10:15:17 --> Total execution time: 0.0345
INFO - 2018-07-13 14:43:52 --> Config Class Initialized
INFO - 2018-07-13 14:43:52 --> Hooks Class Initialized
DEBUG - 2018-07-13 14:43:52 --> UTF-8 Support Enabled
INFO - 2018-07-13 14:43:52 --> Utf8 Class Initialized
INFO - 2018-07-13 14:43:52 --> URI Class Initialized
INFO - 2018-07-13 14:43:52 --> Router Class Initialized
INFO - 2018-07-13 14:43:52 --> Output Class Initialized
INFO - 2018-07-13 14:43:52 --> Security Class Initialized
DEBUG - 2018-07-13 14:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 14:43:52 --> CSRF cookie sent
INFO - 2018-07-13 14:43:52 --> Input Class Initialized
INFO - 2018-07-13 14:43:52 --> Language Class Initialized
ERROR - 2018-07-13 14:43:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 14:43:55 --> Config Class Initialized
INFO - 2018-07-13 14:43:55 --> Hooks Class Initialized
DEBUG - 2018-07-13 14:43:55 --> UTF-8 Support Enabled
INFO - 2018-07-13 14:43:55 --> Utf8 Class Initialized
INFO - 2018-07-13 14:43:55 --> URI Class Initialized
INFO - 2018-07-13 14:43:55 --> Router Class Initialized
INFO - 2018-07-13 14:43:55 --> Output Class Initialized
INFO - 2018-07-13 14:43:55 --> Security Class Initialized
DEBUG - 2018-07-13 14:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 14:43:55 --> CSRF cookie sent
INFO - 2018-07-13 14:43:55 --> Input Class Initialized
INFO - 2018-07-13 14:43:55 --> Language Class Initialized
INFO - 2018-07-13 14:43:55 --> Loader Class Initialized
INFO - 2018-07-13 14:43:55 --> Helper loaded: url_helper
INFO - 2018-07-13 14:43:55 --> Helper loaded: form_helper
INFO - 2018-07-13 14:43:55 --> Helper loaded: language_helper
DEBUG - 2018-07-13 14:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 14:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 14:43:55 --> User Agent Class Initialized
INFO - 2018-07-13 14:43:55 --> Controller Class Initialized
INFO - 2018-07-13 14:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 14:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-13 14:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 14:43:55 --> Final output sent to browser
DEBUG - 2018-07-13 14:43:55 --> Total execution time: 0.0220
INFO - 2018-07-13 16:29:25 --> Config Class Initialized
INFO - 2018-07-13 16:29:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:25 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:25 --> URI Class Initialized
DEBUG - 2018-07-13 16:29:25 --> No URI present. Default controller set.
INFO - 2018-07-13 16:29:25 --> Router Class Initialized
INFO - 2018-07-13 16:29:25 --> Output Class Initialized
INFO - 2018-07-13 16:29:25 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:25 --> CSRF cookie sent
INFO - 2018-07-13 16:29:25 --> Input Class Initialized
INFO - 2018-07-13 16:29:25 --> Language Class Initialized
INFO - 2018-07-13 16:29:25 --> Loader Class Initialized
INFO - 2018-07-13 16:29:25 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:25 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:25 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:25 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:25 --> Controller Class Initialized
INFO - 2018-07-13 16:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:25 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:25 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:25 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:25 --> Total execution time: 0.0343
INFO - 2018-07-13 16:29:25 --> Config Class Initialized
INFO - 2018-07-13 16:29:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:25 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:25 --> URI Class Initialized
DEBUG - 2018-07-13 16:29:25 --> No URI present. Default controller set.
INFO - 2018-07-13 16:29:25 --> Router Class Initialized
INFO - 2018-07-13 16:29:25 --> Output Class Initialized
INFO - 2018-07-13 16:29:25 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:25 --> CSRF cookie sent
INFO - 2018-07-13 16:29:25 --> Input Class Initialized
INFO - 2018-07-13 16:29:25 --> Language Class Initialized
INFO - 2018-07-13 16:29:25 --> Loader Class Initialized
INFO - 2018-07-13 16:29:25 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:25 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:25 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:25 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:25 --> Controller Class Initialized
INFO - 2018-07-13 16:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:25 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:25 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 16:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:25 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:25 --> Total execution time: 0.0311
INFO - 2018-07-13 16:29:26 --> Config Class Initialized
INFO - 2018-07-13 16:29:26 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:26 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:26 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:26 --> URI Class Initialized
DEBUG - 2018-07-13 16:29:26 --> No URI present. Default controller set.
INFO - 2018-07-13 16:29:26 --> Router Class Initialized
INFO - 2018-07-13 16:29:26 --> Output Class Initialized
INFO - 2018-07-13 16:29:26 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:26 --> CSRF cookie sent
INFO - 2018-07-13 16:29:26 --> Input Class Initialized
INFO - 2018-07-13 16:29:26 --> Language Class Initialized
INFO - 2018-07-13 16:29:26 --> Loader Class Initialized
INFO - 2018-07-13 16:29:26 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:26 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:26 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:26 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:26 --> Controller Class Initialized
INFO - 2018-07-13 16:29:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:26 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:26 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 16:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:26 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:26 --> Total execution time: 0.0284
INFO - 2018-07-13 16:29:27 --> Config Class Initialized
INFO - 2018-07-13 16:29:27 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:27 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:27 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:27 --> URI Class Initialized
INFO - 2018-07-13 16:29:27 --> Router Class Initialized
INFO - 2018-07-13 16:29:27 --> Output Class Initialized
INFO - 2018-07-13 16:29:27 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:27 --> CSRF cookie sent
INFO - 2018-07-13 16:29:27 --> Input Class Initialized
INFO - 2018-07-13 16:29:27 --> Language Class Initialized
ERROR - 2018-07-13 16:29:27 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-13 16:29:34 --> Config Class Initialized
INFO - 2018-07-13 16:29:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:34 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:34 --> URI Class Initialized
DEBUG - 2018-07-13 16:29:34 --> No URI present. Default controller set.
INFO - 2018-07-13 16:29:34 --> Router Class Initialized
INFO - 2018-07-13 16:29:34 --> Output Class Initialized
INFO - 2018-07-13 16:29:34 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:34 --> CSRF cookie sent
INFO - 2018-07-13 16:29:34 --> Input Class Initialized
INFO - 2018-07-13 16:29:34 --> Language Class Initialized
INFO - 2018-07-13 16:29:34 --> Loader Class Initialized
INFO - 2018-07-13 16:29:34 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:34 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:34 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:34 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:34 --> Controller Class Initialized
INFO - 2018-07-13 16:29:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:34 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:34 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 16:29:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:34 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:34 --> Total execution time: 0.0348
INFO - 2018-07-13 16:29:34 --> Config Class Initialized
INFO - 2018-07-13 16:29:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:34 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:34 --> URI Class Initialized
INFO - 2018-07-13 16:29:34 --> Router Class Initialized
INFO - 2018-07-13 16:29:34 --> Output Class Initialized
INFO - 2018-07-13 16:29:34 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:34 --> CSRF cookie sent
INFO - 2018-07-13 16:29:34 --> Input Class Initialized
INFO - 2018-07-13 16:29:34 --> Language Class Initialized
ERROR - 2018-07-13 16:29:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-13 16:29:35 --> Config Class Initialized
INFO - 2018-07-13 16:29:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:35 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:35 --> URI Class Initialized
INFO - 2018-07-13 16:29:35 --> Router Class Initialized
INFO - 2018-07-13 16:29:35 --> Output Class Initialized
INFO - 2018-07-13 16:29:35 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:35 --> CSRF cookie sent
INFO - 2018-07-13 16:29:35 --> Input Class Initialized
INFO - 2018-07-13 16:29:35 --> Language Class Initialized
ERROR - 2018-07-13 16:29:35 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-13 16:29:35 --> Config Class Initialized
INFO - 2018-07-13 16:29:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:35 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:35 --> URI Class Initialized
INFO - 2018-07-13 16:29:35 --> Router Class Initialized
INFO - 2018-07-13 16:29:35 --> Output Class Initialized
INFO - 2018-07-13 16:29:35 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:35 --> CSRF cookie sent
INFO - 2018-07-13 16:29:35 --> Input Class Initialized
INFO - 2018-07-13 16:29:35 --> Language Class Initialized
INFO - 2018-07-13 16:29:35 --> Loader Class Initialized
INFO - 2018-07-13 16:29:35 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:35 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:35 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:35 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:35 --> Controller Class Initialized
INFO - 2018-07-13 16:29:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:35 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:35 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:35 --> Config Class Initialized
INFO - 2018-07-13 16:29:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:35 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:35 --> URI Class Initialized
INFO - 2018-07-13 16:29:35 --> Router Class Initialized
INFO - 2018-07-13 16:29:35 --> Output Class Initialized
INFO - 2018-07-13 16:29:35 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:35 --> CSRF cookie sent
INFO - 2018-07-13 16:29:35 --> Input Class Initialized
INFO - 2018-07-13 16:29:35 --> Language Class Initialized
INFO - 2018-07-13 16:29:35 --> Loader Class Initialized
INFO - 2018-07-13 16:29:35 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:35 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:35 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:35 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:35 --> Controller Class Initialized
INFO - 2018-07-13 16:29:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-13 16:29:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-13 16:29:35 --> Could not find the language line "req_email"
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-13 16:29:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:35 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:35 --> Total execution time: 0.0235
INFO - 2018-07-13 16:29:36 --> Config Class Initialized
INFO - 2018-07-13 16:29:36 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:36 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:36 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:36 --> URI Class Initialized
INFO - 2018-07-13 16:29:36 --> Router Class Initialized
INFO - 2018-07-13 16:29:36 --> Output Class Initialized
INFO - 2018-07-13 16:29:36 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:36 --> CSRF cookie sent
INFO - 2018-07-13 16:29:36 --> Input Class Initialized
INFO - 2018-07-13 16:29:36 --> Language Class Initialized
INFO - 2018-07-13 16:29:36 --> Loader Class Initialized
INFO - 2018-07-13 16:29:36 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:36 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:36 --> Controller Class Initialized
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:36 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:36 --> Total execution time: 0.0205
INFO - 2018-07-13 16:29:36 --> Config Class Initialized
INFO - 2018-07-13 16:29:36 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:36 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:36 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:36 --> URI Class Initialized
INFO - 2018-07-13 16:29:36 --> Router Class Initialized
INFO - 2018-07-13 16:29:36 --> Output Class Initialized
INFO - 2018-07-13 16:29:36 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:36 --> CSRF cookie sent
INFO - 2018-07-13 16:29:36 --> Input Class Initialized
INFO - 2018-07-13 16:29:36 --> Language Class Initialized
INFO - 2018-07-13 16:29:36 --> Loader Class Initialized
INFO - 2018-07-13 16:29:36 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:36 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:36 --> Controller Class Initialized
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:36 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:36 --> Total execution time: 0.0316
INFO - 2018-07-13 16:29:36 --> Config Class Initialized
INFO - 2018-07-13 16:29:36 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:36 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:36 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:36 --> URI Class Initialized
INFO - 2018-07-13 16:29:36 --> Router Class Initialized
INFO - 2018-07-13 16:29:36 --> Output Class Initialized
INFO - 2018-07-13 16:29:36 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:36 --> CSRF cookie sent
INFO - 2018-07-13 16:29:36 --> Input Class Initialized
INFO - 2018-07-13 16:29:36 --> Language Class Initialized
INFO - 2018-07-13 16:29:36 --> Loader Class Initialized
INFO - 2018-07-13 16:29:36 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:36 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:36 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:36 --> Controller Class Initialized
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-13 16:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:36 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:36 --> Total execution time: 0.0234
INFO - 2018-07-13 16:29:37 --> Config Class Initialized
INFO - 2018-07-13 16:29:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:37 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:37 --> URI Class Initialized
INFO - 2018-07-13 16:29:37 --> Router Class Initialized
INFO - 2018-07-13 16:29:37 --> Output Class Initialized
INFO - 2018-07-13 16:29:37 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:37 --> CSRF cookie sent
INFO - 2018-07-13 16:29:37 --> Input Class Initialized
INFO - 2018-07-13 16:29:37 --> Language Class Initialized
INFO - 2018-07-13 16:29:37 --> Loader Class Initialized
INFO - 2018-07-13 16:29:37 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:37 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:37 --> Controller Class Initialized
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:37 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:37 --> Total execution time: 0.0217
INFO - 2018-07-13 16:29:37 --> Config Class Initialized
INFO - 2018-07-13 16:29:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:37 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:37 --> URI Class Initialized
INFO - 2018-07-13 16:29:37 --> Router Class Initialized
INFO - 2018-07-13 16:29:37 --> Output Class Initialized
INFO - 2018-07-13 16:29:37 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:37 --> CSRF cookie sent
INFO - 2018-07-13 16:29:37 --> Input Class Initialized
INFO - 2018-07-13 16:29:37 --> Language Class Initialized
INFO - 2018-07-13 16:29:37 --> Loader Class Initialized
INFO - 2018-07-13 16:29:37 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:37 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:37 --> Controller Class Initialized
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-13 16:29:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-13 16:29:37 --> Could not find the language line "req_email"
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:37 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:37 --> Total execution time: 0.0224
INFO - 2018-07-13 16:29:37 --> Config Class Initialized
INFO - 2018-07-13 16:29:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 16:29:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 16:29:37 --> Utf8 Class Initialized
INFO - 2018-07-13 16:29:37 --> URI Class Initialized
INFO - 2018-07-13 16:29:37 --> Router Class Initialized
INFO - 2018-07-13 16:29:37 --> Output Class Initialized
INFO - 2018-07-13 16:29:37 --> Security Class Initialized
DEBUG - 2018-07-13 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 16:29:37 --> CSRF cookie sent
INFO - 2018-07-13 16:29:37 --> Input Class Initialized
INFO - 2018-07-13 16:29:37 --> Language Class Initialized
INFO - 2018-07-13 16:29:37 --> Loader Class Initialized
INFO - 2018-07-13 16:29:37 --> Helper loaded: url_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: form_helper
INFO - 2018-07-13 16:29:37 --> Helper loaded: language_helper
DEBUG - 2018-07-13 16:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 16:29:37 --> User Agent Class Initialized
INFO - 2018-07-13 16:29:37 --> Controller Class Initialized
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 16:29:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 16:29:37 --> Pixel_Model class loaded
INFO - 2018-07-13 16:29:37 --> Database Driver Class Initialized
INFO - 2018-07-13 16:29:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-13 16:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 16:29:37 --> Final output sent to browser
DEBUG - 2018-07-13 16:29:37 --> Total execution time: 0.0369
INFO - 2018-07-13 17:02:04 --> Config Class Initialized
INFO - 2018-07-13 17:02:04 --> Hooks Class Initialized
DEBUG - 2018-07-13 17:02:04 --> UTF-8 Support Enabled
INFO - 2018-07-13 17:02:04 --> Utf8 Class Initialized
INFO - 2018-07-13 17:02:04 --> URI Class Initialized
INFO - 2018-07-13 17:02:04 --> Router Class Initialized
INFO - 2018-07-13 17:02:04 --> Output Class Initialized
INFO - 2018-07-13 17:02:04 --> Security Class Initialized
DEBUG - 2018-07-13 17:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 17:02:04 --> CSRF cookie sent
INFO - 2018-07-13 17:02:04 --> Input Class Initialized
INFO - 2018-07-13 17:02:04 --> Language Class Initialized
ERROR - 2018-07-13 17:02:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 17:33:07 --> Config Class Initialized
INFO - 2018-07-13 17:33:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 17:33:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 17:33:07 --> Utf8 Class Initialized
INFO - 2018-07-13 17:33:07 --> URI Class Initialized
INFO - 2018-07-13 17:33:07 --> Router Class Initialized
INFO - 2018-07-13 17:33:07 --> Output Class Initialized
INFO - 2018-07-13 17:33:07 --> Security Class Initialized
DEBUG - 2018-07-13 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 17:33:07 --> CSRF cookie sent
INFO - 2018-07-13 17:33:07 --> Input Class Initialized
INFO - 2018-07-13 17:33:07 --> Language Class Initialized
ERROR - 2018-07-13 17:33:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 17:45:31 --> Config Class Initialized
INFO - 2018-07-13 17:45:31 --> Hooks Class Initialized
DEBUG - 2018-07-13 17:45:31 --> UTF-8 Support Enabled
INFO - 2018-07-13 17:45:31 --> Utf8 Class Initialized
INFO - 2018-07-13 17:45:31 --> URI Class Initialized
INFO - 2018-07-13 17:45:31 --> Router Class Initialized
INFO - 2018-07-13 17:45:31 --> Output Class Initialized
INFO - 2018-07-13 17:45:31 --> Security Class Initialized
DEBUG - 2018-07-13 17:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 17:45:31 --> CSRF cookie sent
INFO - 2018-07-13 17:45:31 --> Input Class Initialized
INFO - 2018-07-13 17:45:31 --> Language Class Initialized
ERROR - 2018-07-13 17:45:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-13 17:45:35 --> Config Class Initialized
INFO - 2018-07-13 17:45:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 17:45:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 17:45:35 --> Utf8 Class Initialized
INFO - 2018-07-13 17:45:35 --> URI Class Initialized
INFO - 2018-07-13 17:45:35 --> Router Class Initialized
INFO - 2018-07-13 17:45:35 --> Output Class Initialized
INFO - 2018-07-13 17:45:35 --> Security Class Initialized
DEBUG - 2018-07-13 17:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 17:45:35 --> CSRF cookie sent
INFO - 2018-07-13 17:45:35 --> Input Class Initialized
INFO - 2018-07-13 17:45:35 --> Language Class Initialized
INFO - 2018-07-13 17:45:35 --> Loader Class Initialized
INFO - 2018-07-13 17:45:35 --> Helper loaded: url_helper
INFO - 2018-07-13 17:45:35 --> Helper loaded: form_helper
INFO - 2018-07-13 17:45:35 --> Helper loaded: language_helper
DEBUG - 2018-07-13 17:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 17:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 17:45:35 --> User Agent Class Initialized
INFO - 2018-07-13 17:45:35 --> Controller Class Initialized
INFO - 2018-07-13 17:45:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 17:45:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 17:45:35 --> Pixel_Model class loaded
INFO - 2018-07-13 17:45:35 --> Database Driver Class Initialized
INFO - 2018-07-13 17:45:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-13 17:45:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 17:45:35 --> Final output sent to browser
DEBUG - 2018-07-13 17:45:35 --> Total execution time: 0.0366
INFO - 2018-07-13 17:53:59 --> Config Class Initialized
INFO - 2018-07-13 17:53:59 --> Hooks Class Initialized
DEBUG - 2018-07-13 17:53:59 --> UTF-8 Support Enabled
INFO - 2018-07-13 17:53:59 --> Utf8 Class Initialized
INFO - 2018-07-13 17:53:59 --> URI Class Initialized
DEBUG - 2018-07-13 17:53:59 --> No URI present. Default controller set.
INFO - 2018-07-13 17:53:59 --> Router Class Initialized
INFO - 2018-07-13 17:53:59 --> Output Class Initialized
INFO - 2018-07-13 17:53:59 --> Security Class Initialized
DEBUG - 2018-07-13 17:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 17:53:59 --> CSRF cookie sent
INFO - 2018-07-13 17:53:59 --> Input Class Initialized
INFO - 2018-07-13 17:53:59 --> Language Class Initialized
INFO - 2018-07-13 17:53:59 --> Loader Class Initialized
INFO - 2018-07-13 17:53:59 --> Helper loaded: url_helper
INFO - 2018-07-13 17:53:59 --> Helper loaded: form_helper
INFO - 2018-07-13 17:53:59 --> Helper loaded: language_helper
DEBUG - 2018-07-13 17:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 17:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 17:53:59 --> User Agent Class Initialized
INFO - 2018-07-13 17:53:59 --> Controller Class Initialized
INFO - 2018-07-13 17:53:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 17:53:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 17:53:59 --> Pixel_Model class loaded
INFO - 2018-07-13 17:53:59 --> Database Driver Class Initialized
INFO - 2018-07-13 17:53:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 17:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 17:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 17:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 17:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 17:53:59 --> Final output sent to browser
DEBUG - 2018-07-13 17:53:59 --> Total execution time: 0.0354
INFO - 2018-07-13 18:34:47 --> Config Class Initialized
INFO - 2018-07-13 18:34:47 --> Hooks Class Initialized
DEBUG - 2018-07-13 18:34:47 --> UTF-8 Support Enabled
INFO - 2018-07-13 18:34:47 --> Utf8 Class Initialized
INFO - 2018-07-13 18:34:47 --> URI Class Initialized
DEBUG - 2018-07-13 18:34:47 --> No URI present. Default controller set.
INFO - 2018-07-13 18:34:47 --> Router Class Initialized
INFO - 2018-07-13 18:34:47 --> Output Class Initialized
INFO - 2018-07-13 18:34:47 --> Security Class Initialized
DEBUG - 2018-07-13 18:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 18:34:47 --> CSRF cookie sent
INFO - 2018-07-13 18:34:47 --> Input Class Initialized
INFO - 2018-07-13 18:34:47 --> Language Class Initialized
INFO - 2018-07-13 18:34:47 --> Loader Class Initialized
INFO - 2018-07-13 18:34:47 --> Helper loaded: url_helper
INFO - 2018-07-13 18:34:47 --> Helper loaded: form_helper
INFO - 2018-07-13 18:34:47 --> Helper loaded: language_helper
DEBUG - 2018-07-13 18:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 18:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 18:34:47 --> User Agent Class Initialized
INFO - 2018-07-13 18:34:47 --> Controller Class Initialized
INFO - 2018-07-13 18:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-13 18:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-13 18:34:47 --> Pixel_Model class loaded
INFO - 2018-07-13 18:34:47 --> Database Driver Class Initialized
INFO - 2018-07-13 18:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-13 18:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-13 18:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-13 18:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-13 18:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-13 18:34:47 --> Final output sent to browser
DEBUG - 2018-07-13 18:34:47 --> Total execution time: 0.0381

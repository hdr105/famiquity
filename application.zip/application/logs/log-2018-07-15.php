<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-15 01:40:43 --> Config Class Initialized
INFO - 2018-07-15 01:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 01:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 01:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 01:40:43 --> URI Class Initialized
INFO - 2018-07-15 01:40:43 --> Router Class Initialized
INFO - 2018-07-15 01:40:43 --> Output Class Initialized
INFO - 2018-07-15 01:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 01:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 01:40:43 --> CSRF cookie sent
INFO - 2018-07-15 01:40:43 --> Input Class Initialized
INFO - 2018-07-15 01:40:43 --> Language Class Initialized
ERROR - 2018-07-15 01:40:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 01:40:46 --> Config Class Initialized
INFO - 2018-07-15 01:40:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 01:40:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 01:40:46 --> Utf8 Class Initialized
INFO - 2018-07-15 01:40:46 --> URI Class Initialized
DEBUG - 2018-07-15 01:40:46 --> No URI present. Default controller set.
INFO - 2018-07-15 01:40:46 --> Router Class Initialized
INFO - 2018-07-15 01:40:46 --> Output Class Initialized
INFO - 2018-07-15 01:40:46 --> Security Class Initialized
DEBUG - 2018-07-15 01:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 01:40:46 --> CSRF cookie sent
INFO - 2018-07-15 01:40:46 --> Input Class Initialized
INFO - 2018-07-15 01:40:46 --> Language Class Initialized
INFO - 2018-07-15 01:40:46 --> Loader Class Initialized
INFO - 2018-07-15 01:40:46 --> Helper loaded: url_helper
INFO - 2018-07-15 01:40:46 --> Helper loaded: form_helper
INFO - 2018-07-15 01:40:46 --> Helper loaded: language_helper
DEBUG - 2018-07-15 01:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 01:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 01:40:46 --> User Agent Class Initialized
INFO - 2018-07-15 01:40:46 --> Controller Class Initialized
INFO - 2018-07-15 01:40:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 01:40:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 01:40:46 --> Pixel_Model class loaded
INFO - 2018-07-15 01:40:46 --> Database Driver Class Initialized
INFO - 2018-07-15 01:40:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 01:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 01:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 01:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 01:40:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 01:40:46 --> Final output sent to browser
DEBUG - 2018-07-15 01:40:46 --> Total execution time: 0.0356
INFO - 2018-07-15 01:54:33 --> Config Class Initialized
INFO - 2018-07-15 01:54:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 01:54:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 01:54:33 --> Utf8 Class Initialized
INFO - 2018-07-15 01:54:33 --> URI Class Initialized
DEBUG - 2018-07-15 01:54:33 --> No URI present. Default controller set.
INFO - 2018-07-15 01:54:33 --> Router Class Initialized
INFO - 2018-07-15 01:54:33 --> Output Class Initialized
INFO - 2018-07-15 01:54:33 --> Security Class Initialized
DEBUG - 2018-07-15 01:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 01:54:33 --> CSRF cookie sent
INFO - 2018-07-15 01:54:33 --> Input Class Initialized
INFO - 2018-07-15 01:54:33 --> Language Class Initialized
INFO - 2018-07-15 01:54:33 --> Loader Class Initialized
INFO - 2018-07-15 01:54:33 --> Helper loaded: url_helper
INFO - 2018-07-15 01:54:33 --> Helper loaded: form_helper
INFO - 2018-07-15 01:54:33 --> Helper loaded: language_helper
DEBUG - 2018-07-15 01:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 01:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 01:54:33 --> User Agent Class Initialized
INFO - 2018-07-15 01:54:33 --> Controller Class Initialized
INFO - 2018-07-15 01:54:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 01:54:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 01:54:33 --> Pixel_Model class loaded
INFO - 2018-07-15 01:54:33 --> Database Driver Class Initialized
INFO - 2018-07-15 01:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 01:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 01:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 01:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 01:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 01:54:33 --> Final output sent to browser
DEBUG - 2018-07-15 01:54:33 --> Total execution time: 0.0346
INFO - 2018-07-15 02:28:28 --> Config Class Initialized
INFO - 2018-07-15 02:28:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 02:28:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 02:28:28 --> Utf8 Class Initialized
INFO - 2018-07-15 02:28:28 --> URI Class Initialized
INFO - 2018-07-15 02:28:28 --> Router Class Initialized
INFO - 2018-07-15 02:28:28 --> Output Class Initialized
INFO - 2018-07-15 02:28:28 --> Security Class Initialized
DEBUG - 2018-07-15 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 02:28:28 --> CSRF cookie sent
INFO - 2018-07-15 02:28:28 --> Input Class Initialized
INFO - 2018-07-15 02:28:28 --> Language Class Initialized
ERROR - 2018-07-15 02:28:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 02:28:28 --> Config Class Initialized
INFO - 2018-07-15 02:28:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 02:28:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 02:28:28 --> Utf8 Class Initialized
INFO - 2018-07-15 02:28:28 --> URI Class Initialized
DEBUG - 2018-07-15 02:28:28 --> No URI present. Default controller set.
INFO - 2018-07-15 02:28:28 --> Router Class Initialized
INFO - 2018-07-15 02:28:28 --> Output Class Initialized
INFO - 2018-07-15 02:28:28 --> Security Class Initialized
DEBUG - 2018-07-15 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 02:28:28 --> CSRF cookie sent
INFO - 2018-07-15 02:28:28 --> Input Class Initialized
INFO - 2018-07-15 02:28:28 --> Language Class Initialized
INFO - 2018-07-15 02:28:28 --> Loader Class Initialized
INFO - 2018-07-15 02:28:28 --> Helper loaded: url_helper
INFO - 2018-07-15 02:28:28 --> Helper loaded: form_helper
INFO - 2018-07-15 02:28:28 --> Helper loaded: language_helper
DEBUG - 2018-07-15 02:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 02:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 02:28:28 --> User Agent Class Initialized
INFO - 2018-07-15 02:28:28 --> Controller Class Initialized
INFO - 2018-07-15 02:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 02:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 02:28:28 --> Pixel_Model class loaded
INFO - 2018-07-15 02:28:28 --> Database Driver Class Initialized
INFO - 2018-07-15 02:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 02:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 02:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 02:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 02:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 02:28:28 --> Final output sent to browser
DEBUG - 2018-07-15 02:28:28 --> Total execution time: 0.0340
INFO - 2018-07-15 05:28:27 --> Config Class Initialized
INFO - 2018-07-15 05:28:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:28:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:28:27 --> Utf8 Class Initialized
INFO - 2018-07-15 05:28:27 --> URI Class Initialized
INFO - 2018-07-15 05:28:27 --> Router Class Initialized
INFO - 2018-07-15 05:28:27 --> Output Class Initialized
INFO - 2018-07-15 05:28:27 --> Security Class Initialized
DEBUG - 2018-07-15 05:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:28:27 --> CSRF cookie sent
INFO - 2018-07-15 05:28:27 --> Input Class Initialized
INFO - 2018-07-15 05:28:27 --> Language Class Initialized
ERROR - 2018-07-15 05:28:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 05:28:27 --> Config Class Initialized
INFO - 2018-07-15 05:28:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:28:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:28:27 --> Utf8 Class Initialized
INFO - 2018-07-15 05:28:27 --> URI Class Initialized
DEBUG - 2018-07-15 05:28:27 --> No URI present. Default controller set.
INFO - 2018-07-15 05:28:27 --> Router Class Initialized
INFO - 2018-07-15 05:28:27 --> Output Class Initialized
INFO - 2018-07-15 05:28:27 --> Security Class Initialized
DEBUG - 2018-07-15 05:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:28:27 --> CSRF cookie sent
INFO - 2018-07-15 05:28:27 --> Input Class Initialized
INFO - 2018-07-15 05:28:27 --> Language Class Initialized
INFO - 2018-07-15 05:28:27 --> Loader Class Initialized
INFO - 2018-07-15 05:28:27 --> Helper loaded: url_helper
INFO - 2018-07-15 05:28:27 --> Helper loaded: form_helper
INFO - 2018-07-15 05:28:27 --> Helper loaded: language_helper
DEBUG - 2018-07-15 05:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 05:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 05:28:27 --> User Agent Class Initialized
INFO - 2018-07-15 05:28:27 --> Controller Class Initialized
INFO - 2018-07-15 05:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 05:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 05:28:27 --> Pixel_Model class loaded
INFO - 2018-07-15 05:28:27 --> Database Driver Class Initialized
INFO - 2018-07-15 05:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 05:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 05:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 05:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 05:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 05:28:27 --> Final output sent to browser
DEBUG - 2018-07-15 05:28:27 --> Total execution time: 0.0348
INFO - 2018-07-15 07:24:27 --> Config Class Initialized
INFO - 2018-07-15 07:24:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:24:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:24:27 --> Utf8 Class Initialized
INFO - 2018-07-15 07:24:27 --> URI Class Initialized
INFO - 2018-07-15 07:24:27 --> Router Class Initialized
INFO - 2018-07-15 07:24:27 --> Output Class Initialized
INFO - 2018-07-15 07:24:27 --> Security Class Initialized
DEBUG - 2018-07-15 07:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:24:27 --> CSRF cookie sent
INFO - 2018-07-15 07:24:27 --> Input Class Initialized
INFO - 2018-07-15 07:24:27 --> Language Class Initialized
ERROR - 2018-07-15 07:24:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 09:54:12 --> Config Class Initialized
INFO - 2018-07-15 09:54:12 --> Hooks Class Initialized
DEBUG - 2018-07-15 09:54:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 09:54:12 --> Utf8 Class Initialized
INFO - 2018-07-15 09:54:12 --> URI Class Initialized
DEBUG - 2018-07-15 09:54:12 --> No URI present. Default controller set.
INFO - 2018-07-15 09:54:12 --> Router Class Initialized
INFO - 2018-07-15 09:54:12 --> Output Class Initialized
INFO - 2018-07-15 09:54:12 --> Security Class Initialized
DEBUG - 2018-07-15 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 09:54:12 --> CSRF cookie sent
INFO - 2018-07-15 09:54:12 --> Input Class Initialized
INFO - 2018-07-15 09:54:12 --> Language Class Initialized
INFO - 2018-07-15 09:54:12 --> Loader Class Initialized
INFO - 2018-07-15 09:54:12 --> Helper loaded: url_helper
INFO - 2018-07-15 09:54:12 --> Helper loaded: form_helper
INFO - 2018-07-15 09:54:12 --> Helper loaded: language_helper
DEBUG - 2018-07-15 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 09:54:12 --> User Agent Class Initialized
INFO - 2018-07-15 09:54:12 --> Controller Class Initialized
INFO - 2018-07-15 09:54:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 09:54:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 09:54:12 --> Pixel_Model class loaded
INFO - 2018-07-15 09:54:12 --> Database Driver Class Initialized
INFO - 2018-07-15 09:54:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 09:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 09:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 09:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 09:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 09:54:12 --> Final output sent to browser
DEBUG - 2018-07-15 09:54:12 --> Total execution time: 0.0332
INFO - 2018-07-15 11:19:07 --> Config Class Initialized
INFO - 2018-07-15 11:19:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 11:19:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 11:19:07 --> Utf8 Class Initialized
INFO - 2018-07-15 11:19:07 --> URI Class Initialized
DEBUG - 2018-07-15 11:19:07 --> No URI present. Default controller set.
INFO - 2018-07-15 11:19:07 --> Router Class Initialized
INFO - 2018-07-15 11:19:07 --> Output Class Initialized
INFO - 2018-07-15 11:19:07 --> Security Class Initialized
DEBUG - 2018-07-15 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 11:19:07 --> CSRF cookie sent
INFO - 2018-07-15 11:19:07 --> Input Class Initialized
INFO - 2018-07-15 11:19:07 --> Language Class Initialized
INFO - 2018-07-15 11:19:07 --> Loader Class Initialized
INFO - 2018-07-15 11:19:07 --> Helper loaded: url_helper
INFO - 2018-07-15 11:19:07 --> Helper loaded: form_helper
INFO - 2018-07-15 11:19:07 --> Helper loaded: language_helper
DEBUG - 2018-07-15 11:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 11:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 11:19:07 --> User Agent Class Initialized
INFO - 2018-07-15 11:19:07 --> Controller Class Initialized
INFO - 2018-07-15 11:19:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 11:19:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 11:19:07 --> Pixel_Model class loaded
INFO - 2018-07-15 11:19:07 --> Database Driver Class Initialized
INFO - 2018-07-15 11:19:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 11:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 11:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 11:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 11:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 11:19:07 --> Final output sent to browser
DEBUG - 2018-07-15 11:19:07 --> Total execution time: 0.0358
INFO - 2018-07-15 14:08:59 --> Config Class Initialized
INFO - 2018-07-15 14:08:59 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:08:59 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:08:59 --> Utf8 Class Initialized
INFO - 2018-07-15 14:08:59 --> URI Class Initialized
DEBUG - 2018-07-15 14:08:59 --> No URI present. Default controller set.
INFO - 2018-07-15 14:08:59 --> Router Class Initialized
INFO - 2018-07-15 14:08:59 --> Output Class Initialized
INFO - 2018-07-15 14:08:59 --> Security Class Initialized
DEBUG - 2018-07-15 14:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:08:59 --> CSRF cookie sent
INFO - 2018-07-15 14:08:59 --> Input Class Initialized
INFO - 2018-07-15 14:08:59 --> Language Class Initialized
INFO - 2018-07-15 14:08:59 --> Loader Class Initialized
INFO - 2018-07-15 14:08:59 --> Helper loaded: url_helper
INFO - 2018-07-15 14:08:59 --> Helper loaded: form_helper
INFO - 2018-07-15 14:08:59 --> Helper loaded: language_helper
DEBUG - 2018-07-15 14:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:08:59 --> User Agent Class Initialized
INFO - 2018-07-15 14:08:59 --> Controller Class Initialized
INFO - 2018-07-15 14:08:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 14:08:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 14:08:59 --> Pixel_Model class loaded
INFO - 2018-07-15 14:08:59 --> Database Driver Class Initialized
INFO - 2018-07-15 14:08:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 14:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 14:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 14:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 14:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 14:08:59 --> Final output sent to browser
DEBUG - 2018-07-15 14:08:59 --> Total execution time: 0.0350
INFO - 2018-07-15 14:09:04 --> Config Class Initialized
INFO - 2018-07-15 14:09:04 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:04 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:04 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:04 --> URI Class Initialized
INFO - 2018-07-15 14:09:04 --> Router Class Initialized
INFO - 2018-07-15 14:09:04 --> Output Class Initialized
INFO - 2018-07-15 14:09:04 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:04 --> CSRF cookie sent
INFO - 2018-07-15 14:09:04 --> Input Class Initialized
INFO - 2018-07-15 14:09:04 --> Language Class Initialized
ERROR - 2018-07-15 14:09:04 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-15 14:09:05 --> Config Class Initialized
INFO - 2018-07-15 14:09:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:05 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:05 --> URI Class Initialized
INFO - 2018-07-15 14:09:05 --> Router Class Initialized
INFO - 2018-07-15 14:09:05 --> Output Class Initialized
INFO - 2018-07-15 14:09:05 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:05 --> CSRF cookie sent
INFO - 2018-07-15 14:09:05 --> Input Class Initialized
INFO - 2018-07-15 14:09:05 --> Language Class Initialized
ERROR - 2018-07-15 14:09:05 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-15 14:09:05 --> Config Class Initialized
INFO - 2018-07-15 14:09:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:05 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:05 --> URI Class Initialized
INFO - 2018-07-15 14:09:05 --> Router Class Initialized
INFO - 2018-07-15 14:09:05 --> Output Class Initialized
INFO - 2018-07-15 14:09:05 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:05 --> CSRF cookie sent
INFO - 2018-07-15 14:09:05 --> Input Class Initialized
INFO - 2018-07-15 14:09:05 --> Language Class Initialized
ERROR - 2018-07-15 14:09:05 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-15 14:09:05 --> Config Class Initialized
INFO - 2018-07-15 14:09:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:05 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:05 --> URI Class Initialized
INFO - 2018-07-15 14:09:05 --> Router Class Initialized
INFO - 2018-07-15 14:09:05 --> Output Class Initialized
INFO - 2018-07-15 14:09:05 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:05 --> CSRF cookie sent
INFO - 2018-07-15 14:09:05 --> Input Class Initialized
INFO - 2018-07-15 14:09:05 --> Language Class Initialized
ERROR - 2018-07-15 14:09:05 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-15 14:09:21 --> Config Class Initialized
INFO - 2018-07-15 14:09:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:21 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:21 --> URI Class Initialized
INFO - 2018-07-15 14:09:21 --> Router Class Initialized
INFO - 2018-07-15 14:09:21 --> Output Class Initialized
INFO - 2018-07-15 14:09:21 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:21 --> CSRF cookie sent
INFO - 2018-07-15 14:09:21 --> CSRF token verified
INFO - 2018-07-15 14:09:21 --> Input Class Initialized
INFO - 2018-07-15 14:09:21 --> Language Class Initialized
INFO - 2018-07-15 14:09:21 --> Loader Class Initialized
INFO - 2018-07-15 14:09:21 --> Helper loaded: url_helper
INFO - 2018-07-15 14:09:21 --> Helper loaded: form_helper
INFO - 2018-07-15 14:09:21 --> Helper loaded: language_helper
DEBUG - 2018-07-15 14:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:09:21 --> User Agent Class Initialized
INFO - 2018-07-15 14:09:21 --> Controller Class Initialized
INFO - 2018-07-15 14:09:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 14:09:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 14:09:21 --> Pixel_Model class loaded
INFO - 2018-07-15 14:09:21 --> Database Driver Class Initialized
INFO - 2018-07-15 14:09:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 14:09:21 --> Config Class Initialized
INFO - 2018-07-15 14:09:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:09:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:09:21 --> Utf8 Class Initialized
INFO - 2018-07-15 14:09:21 --> URI Class Initialized
INFO - 2018-07-15 14:09:21 --> Router Class Initialized
INFO - 2018-07-15 14:09:21 --> Output Class Initialized
INFO - 2018-07-15 14:09:21 --> Security Class Initialized
DEBUG - 2018-07-15 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:09:21 --> CSRF cookie sent
INFO - 2018-07-15 14:09:21 --> Input Class Initialized
INFO - 2018-07-15 14:09:21 --> Language Class Initialized
INFO - 2018-07-15 14:09:21 --> Loader Class Initialized
INFO - 2018-07-15 14:09:21 --> Helper loaded: url_helper
INFO - 2018-07-15 14:09:21 --> Helper loaded: form_helper
INFO - 2018-07-15 14:09:21 --> Helper loaded: language_helper
DEBUG - 2018-07-15 14:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:09:21 --> User Agent Class Initialized
INFO - 2018-07-15 14:09:21 --> Controller Class Initialized
INFO - 2018-07-15 14:09:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 14:09:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-15 14:09:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-15 14:09:21 --> Could not find the language line "req_email"
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-15 14:09:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 14:09:21 --> Final output sent to browser
DEBUG - 2018-07-15 14:09:21 --> Total execution time: 0.0217
INFO - 2018-07-15 16:33:58 --> Config Class Initialized
INFO - 2018-07-15 16:33:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:33:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:33:58 --> Utf8 Class Initialized
INFO - 2018-07-15 16:33:58 --> URI Class Initialized
INFO - 2018-07-15 16:33:58 --> Router Class Initialized
INFO - 2018-07-15 16:33:58 --> Output Class Initialized
INFO - 2018-07-15 16:33:58 --> Security Class Initialized
DEBUG - 2018-07-15 16:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:33:58 --> CSRF cookie sent
INFO - 2018-07-15 16:33:58 --> Input Class Initialized
INFO - 2018-07-15 16:33:58 --> Language Class Initialized
ERROR - 2018-07-15 16:33:58 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 16:33:58 --> Config Class Initialized
INFO - 2018-07-15 16:33:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:33:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:33:58 --> Utf8 Class Initialized
INFO - 2018-07-15 16:33:58 --> URI Class Initialized
DEBUG - 2018-07-15 16:33:58 --> No URI present. Default controller set.
INFO - 2018-07-15 16:33:58 --> Router Class Initialized
INFO - 2018-07-15 16:33:58 --> Output Class Initialized
INFO - 2018-07-15 16:33:58 --> Security Class Initialized
DEBUG - 2018-07-15 16:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:33:58 --> CSRF cookie sent
INFO - 2018-07-15 16:33:58 --> Input Class Initialized
INFO - 2018-07-15 16:33:58 --> Language Class Initialized
INFO - 2018-07-15 16:33:58 --> Loader Class Initialized
INFO - 2018-07-15 16:33:58 --> Helper loaded: url_helper
INFO - 2018-07-15 16:33:58 --> Helper loaded: form_helper
INFO - 2018-07-15 16:33:58 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:33:58 --> User Agent Class Initialized
INFO - 2018-07-15 16:33:58 --> Controller Class Initialized
INFO - 2018-07-15 16:33:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:33:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:33:58 --> Pixel_Model class loaded
INFO - 2018-07-15 16:33:58 --> Database Driver Class Initialized
INFO - 2018-07-15 16:33:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:33:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:33:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:33:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 16:33:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:33:58 --> Final output sent to browser
DEBUG - 2018-07-15 16:33:58 --> Total execution time: 0.0322
INFO - 2018-07-15 16:50:39 --> Config Class Initialized
INFO - 2018-07-15 16:50:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:39 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:39 --> URI Class Initialized
DEBUG - 2018-07-15 16:50:39 --> No URI present. Default controller set.
INFO - 2018-07-15 16:50:39 --> Router Class Initialized
INFO - 2018-07-15 16:50:39 --> Output Class Initialized
INFO - 2018-07-15 16:50:39 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:39 --> CSRF cookie sent
INFO - 2018-07-15 16:50:39 --> Input Class Initialized
INFO - 2018-07-15 16:50:39 --> Language Class Initialized
INFO - 2018-07-15 16:50:39 --> Loader Class Initialized
INFO - 2018-07-15 16:50:39 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:39 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:39 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:39 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:39 --> Controller Class Initialized
INFO - 2018-07-15 16:50:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:39 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:39 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 16:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:39 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:39 --> Total execution time: 0.0342
INFO - 2018-07-15 16:50:40 --> Config Class Initialized
INFO - 2018-07-15 16:50:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:40 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:40 --> URI Class Initialized
DEBUG - 2018-07-15 16:50:40 --> No URI present. Default controller set.
INFO - 2018-07-15 16:50:40 --> Router Class Initialized
INFO - 2018-07-15 16:50:40 --> Output Class Initialized
INFO - 2018-07-15 16:50:40 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:40 --> CSRF cookie sent
INFO - 2018-07-15 16:50:40 --> Input Class Initialized
INFO - 2018-07-15 16:50:40 --> Language Class Initialized
INFO - 2018-07-15 16:50:40 --> Loader Class Initialized
INFO - 2018-07-15 16:50:40 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:40 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:40 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:40 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:40 --> Controller Class Initialized
INFO - 2018-07-15 16:50:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:40 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:40 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 16:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:40 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:40 --> Total execution time: 0.0450
INFO - 2018-07-15 16:50:41 --> Config Class Initialized
INFO - 2018-07-15 16:50:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:41 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:41 --> URI Class Initialized
DEBUG - 2018-07-15 16:50:41 --> No URI present. Default controller set.
INFO - 2018-07-15 16:50:41 --> Router Class Initialized
INFO - 2018-07-15 16:50:41 --> Output Class Initialized
INFO - 2018-07-15 16:50:41 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:41 --> CSRF cookie sent
INFO - 2018-07-15 16:50:41 --> Input Class Initialized
INFO - 2018-07-15 16:50:41 --> Language Class Initialized
INFO - 2018-07-15 16:50:41 --> Loader Class Initialized
INFO - 2018-07-15 16:50:41 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:41 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:41 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:41 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:41 --> Controller Class Initialized
INFO - 2018-07-15 16:50:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:41 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:41 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 16:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:41 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:41 --> Total execution time: 0.0338
INFO - 2018-07-15 16:50:41 --> Config Class Initialized
INFO - 2018-07-15 16:50:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:41 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:41 --> URI Class Initialized
INFO - 2018-07-15 16:50:41 --> Router Class Initialized
INFO - 2018-07-15 16:50:41 --> Output Class Initialized
INFO - 2018-07-15 16:50:41 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:41 --> CSRF cookie sent
INFO - 2018-07-15 16:50:41 --> Input Class Initialized
INFO - 2018-07-15 16:50:41 --> Language Class Initialized
ERROR - 2018-07-15 16:50:41 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-15 16:50:49 --> Config Class Initialized
INFO - 2018-07-15 16:50:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:49 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:49 --> URI Class Initialized
DEBUG - 2018-07-15 16:50:49 --> No URI present. Default controller set.
INFO - 2018-07-15 16:50:49 --> Router Class Initialized
INFO - 2018-07-15 16:50:49 --> Output Class Initialized
INFO - 2018-07-15 16:50:49 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:49 --> CSRF cookie sent
INFO - 2018-07-15 16:50:49 --> Input Class Initialized
INFO - 2018-07-15 16:50:49 --> Language Class Initialized
INFO - 2018-07-15 16:50:49 --> Loader Class Initialized
INFO - 2018-07-15 16:50:49 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:49 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:49 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:49 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:49 --> Controller Class Initialized
INFO - 2018-07-15 16:50:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:49 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:49 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 16:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:49 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:49 --> Total execution time: 0.0333
INFO - 2018-07-15 16:50:50 --> Config Class Initialized
INFO - 2018-07-15 16:50:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:50 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:50 --> URI Class Initialized
INFO - 2018-07-15 16:50:50 --> Router Class Initialized
INFO - 2018-07-15 16:50:50 --> Output Class Initialized
INFO - 2018-07-15 16:50:50 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:50 --> CSRF cookie sent
INFO - 2018-07-15 16:50:50 --> Input Class Initialized
INFO - 2018-07-15 16:50:50 --> Language Class Initialized
ERROR - 2018-07-15 16:50:50 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-15 16:50:50 --> Config Class Initialized
INFO - 2018-07-15 16:50:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:50 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:50 --> URI Class Initialized
INFO - 2018-07-15 16:50:50 --> Router Class Initialized
INFO - 2018-07-15 16:50:50 --> Output Class Initialized
INFO - 2018-07-15 16:50:50 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:50 --> CSRF cookie sent
INFO - 2018-07-15 16:50:50 --> Input Class Initialized
INFO - 2018-07-15 16:50:50 --> Language Class Initialized
ERROR - 2018-07-15 16:50:50 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-15 16:50:51 --> Config Class Initialized
INFO - 2018-07-15 16:50:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:51 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:51 --> URI Class Initialized
INFO - 2018-07-15 16:50:51 --> Router Class Initialized
INFO - 2018-07-15 16:50:51 --> Output Class Initialized
INFO - 2018-07-15 16:50:51 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:51 --> CSRF cookie sent
INFO - 2018-07-15 16:50:51 --> Input Class Initialized
INFO - 2018-07-15 16:50:51 --> Language Class Initialized
INFO - 2018-07-15 16:50:51 --> Loader Class Initialized
INFO - 2018-07-15 16:50:51 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:51 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:51 --> Controller Class Initialized
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:51 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:51 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:51 --> Config Class Initialized
INFO - 2018-07-15 16:50:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:51 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:51 --> URI Class Initialized
INFO - 2018-07-15 16:50:51 --> Router Class Initialized
INFO - 2018-07-15 16:50:51 --> Output Class Initialized
INFO - 2018-07-15 16:50:51 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:51 --> CSRF cookie sent
INFO - 2018-07-15 16:50:51 --> Input Class Initialized
INFO - 2018-07-15 16:50:51 --> Language Class Initialized
INFO - 2018-07-15 16:50:51 --> Loader Class Initialized
INFO - 2018-07-15 16:50:51 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:51 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:51 --> Controller Class Initialized
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-15 16:50:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-15 16:50:51 --> Could not find the language line "req_email"
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:51 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:51 --> Total execution time: 0.0269
INFO - 2018-07-15 16:50:51 --> Config Class Initialized
INFO - 2018-07-15 16:50:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:51 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:51 --> URI Class Initialized
INFO - 2018-07-15 16:50:51 --> Router Class Initialized
INFO - 2018-07-15 16:50:51 --> Output Class Initialized
INFO - 2018-07-15 16:50:51 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:51 --> CSRF cookie sent
INFO - 2018-07-15 16:50:51 --> Input Class Initialized
INFO - 2018-07-15 16:50:51 --> Language Class Initialized
INFO - 2018-07-15 16:50:51 --> Loader Class Initialized
INFO - 2018-07-15 16:50:51 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:51 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:51 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:51 --> Controller Class Initialized
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-15 16:50:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:51 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:51 --> Total execution time: 0.0218
INFO - 2018-07-15 16:50:52 --> Config Class Initialized
INFO - 2018-07-15 16:50:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:52 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:52 --> URI Class Initialized
INFO - 2018-07-15 16:50:52 --> Router Class Initialized
INFO - 2018-07-15 16:50:52 --> Output Class Initialized
INFO - 2018-07-15 16:50:52 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:52 --> CSRF cookie sent
INFO - 2018-07-15 16:50:52 --> Input Class Initialized
INFO - 2018-07-15 16:50:52 --> Language Class Initialized
INFO - 2018-07-15 16:50:52 --> Loader Class Initialized
INFO - 2018-07-15 16:50:52 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:52 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:52 --> Controller Class Initialized
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:52 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:52 --> Total execution time: 0.0270
INFO - 2018-07-15 16:50:52 --> Config Class Initialized
INFO - 2018-07-15 16:50:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:52 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:52 --> URI Class Initialized
INFO - 2018-07-15 16:50:52 --> Router Class Initialized
INFO - 2018-07-15 16:50:52 --> Output Class Initialized
INFO - 2018-07-15 16:50:52 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:52 --> CSRF cookie sent
INFO - 2018-07-15 16:50:52 --> Input Class Initialized
INFO - 2018-07-15 16:50:52 --> Language Class Initialized
INFO - 2018-07-15 16:50:52 --> Loader Class Initialized
INFO - 2018-07-15 16:50:52 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:52 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:52 --> Controller Class Initialized
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:52 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:52 --> Total execution time: 0.0233
INFO - 2018-07-15 16:50:52 --> Config Class Initialized
INFO - 2018-07-15 16:50:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:52 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:52 --> URI Class Initialized
INFO - 2018-07-15 16:50:52 --> Router Class Initialized
INFO - 2018-07-15 16:50:52 --> Output Class Initialized
INFO - 2018-07-15 16:50:52 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:52 --> CSRF cookie sent
INFO - 2018-07-15 16:50:52 --> Input Class Initialized
INFO - 2018-07-15 16:50:52 --> Language Class Initialized
INFO - 2018-07-15 16:50:52 --> Loader Class Initialized
INFO - 2018-07-15 16:50:52 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:52 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:52 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:52 --> Controller Class Initialized
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-15 16:50:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:52 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:52 --> Total execution time: 0.0216
INFO - 2018-07-15 16:50:53 --> Config Class Initialized
INFO - 2018-07-15 16:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:53 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:53 --> URI Class Initialized
INFO - 2018-07-15 16:50:53 --> Router Class Initialized
INFO - 2018-07-15 16:50:53 --> Output Class Initialized
INFO - 2018-07-15 16:50:53 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:53 --> CSRF cookie sent
INFO - 2018-07-15 16:50:53 --> Input Class Initialized
INFO - 2018-07-15 16:50:53 --> Language Class Initialized
INFO - 2018-07-15 16:50:53 --> Loader Class Initialized
INFO - 2018-07-15 16:50:53 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:53 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:53 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:53 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:53 --> Controller Class Initialized
INFO - 2018-07-15 16:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-15 16:50:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-15 16:50:53 --> Could not find the language line "req_email"
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:53 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:53 --> Total execution time: 0.0280
INFO - 2018-07-15 16:50:53 --> Config Class Initialized
INFO - 2018-07-15 16:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:50:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:50:53 --> Utf8 Class Initialized
INFO - 2018-07-15 16:50:53 --> URI Class Initialized
INFO - 2018-07-15 16:50:53 --> Router Class Initialized
INFO - 2018-07-15 16:50:53 --> Output Class Initialized
INFO - 2018-07-15 16:50:53 --> Security Class Initialized
DEBUG - 2018-07-15 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:50:53 --> CSRF cookie sent
INFO - 2018-07-15 16:50:53 --> Input Class Initialized
INFO - 2018-07-15 16:50:53 --> Language Class Initialized
INFO - 2018-07-15 16:50:53 --> Loader Class Initialized
INFO - 2018-07-15 16:50:53 --> Helper loaded: url_helper
INFO - 2018-07-15 16:50:53 --> Helper loaded: form_helper
INFO - 2018-07-15 16:50:53 --> Helper loaded: language_helper
DEBUG - 2018-07-15 16:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 16:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 16:50:53 --> User Agent Class Initialized
INFO - 2018-07-15 16:50:53 --> Controller Class Initialized
INFO - 2018-07-15 16:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 16:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 16:50:53 --> Pixel_Model class loaded
INFO - 2018-07-15 16:50:53 --> Database Driver Class Initialized
INFO - 2018-07-15 16:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-15 16:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 16:50:53 --> Final output sent to browser
DEBUG - 2018-07-15 16:50:53 --> Total execution time: 0.0331
INFO - 2018-07-15 17:00:49 --> Config Class Initialized
INFO - 2018-07-15 17:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 17:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 17:00:49 --> Utf8 Class Initialized
INFO - 2018-07-15 17:00:49 --> URI Class Initialized
INFO - 2018-07-15 17:00:49 --> Router Class Initialized
INFO - 2018-07-15 17:00:49 --> Output Class Initialized
INFO - 2018-07-15 17:00:49 --> Security Class Initialized
DEBUG - 2018-07-15 17:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 17:00:49 --> CSRF cookie sent
INFO - 2018-07-15 17:00:49 --> Input Class Initialized
INFO - 2018-07-15 17:00:49 --> Language Class Initialized
ERROR - 2018-07-15 17:00:49 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 17:30:15 --> Config Class Initialized
INFO - 2018-07-15 17:30:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 17:30:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 17:30:15 --> Utf8 Class Initialized
INFO - 2018-07-15 17:30:15 --> URI Class Initialized
INFO - 2018-07-15 17:30:15 --> Router Class Initialized
INFO - 2018-07-15 17:30:15 --> Output Class Initialized
INFO - 2018-07-15 17:30:15 --> Security Class Initialized
DEBUG - 2018-07-15 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 17:30:15 --> CSRF cookie sent
INFO - 2018-07-15 17:30:15 --> Input Class Initialized
INFO - 2018-07-15 17:30:15 --> Language Class Initialized
ERROR - 2018-07-15 17:30:15 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 17:41:41 --> Config Class Initialized
INFO - 2018-07-15 17:41:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 17:41:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 17:41:41 --> Utf8 Class Initialized
INFO - 2018-07-15 17:41:41 --> URI Class Initialized
DEBUG - 2018-07-15 17:41:41 --> No URI present. Default controller set.
INFO - 2018-07-15 17:41:41 --> Router Class Initialized
INFO - 2018-07-15 17:41:41 --> Output Class Initialized
INFO - 2018-07-15 17:41:41 --> Security Class Initialized
DEBUG - 2018-07-15 17:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 17:41:41 --> CSRF cookie sent
INFO - 2018-07-15 17:41:41 --> Input Class Initialized
INFO - 2018-07-15 17:41:41 --> Language Class Initialized
INFO - 2018-07-15 17:41:41 --> Loader Class Initialized
INFO - 2018-07-15 17:41:41 --> Helper loaded: url_helper
INFO - 2018-07-15 17:41:41 --> Helper loaded: form_helper
INFO - 2018-07-15 17:41:41 --> Helper loaded: language_helper
DEBUG - 2018-07-15 17:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 17:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 17:41:41 --> User Agent Class Initialized
INFO - 2018-07-15 17:41:41 --> Controller Class Initialized
INFO - 2018-07-15 17:41:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 17:41:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 17:41:41 --> Pixel_Model class loaded
INFO - 2018-07-15 17:41:41 --> Database Driver Class Initialized
INFO - 2018-07-15 17:41:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 17:41:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 17:41:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 17:41:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 17:41:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 17:41:41 --> Final output sent to browser
DEBUG - 2018-07-15 17:41:41 --> Total execution time: 0.0343
INFO - 2018-07-15 18:27:23 --> Config Class Initialized
INFO - 2018-07-15 18:27:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 18:27:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 18:27:23 --> Utf8 Class Initialized
INFO - 2018-07-15 18:27:23 --> URI Class Initialized
DEBUG - 2018-07-15 18:27:23 --> No URI present. Default controller set.
INFO - 2018-07-15 18:27:23 --> Router Class Initialized
INFO - 2018-07-15 18:27:23 --> Output Class Initialized
INFO - 2018-07-15 18:27:23 --> Security Class Initialized
DEBUG - 2018-07-15 18:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 18:27:23 --> CSRF cookie sent
INFO - 2018-07-15 18:27:23 --> Input Class Initialized
INFO - 2018-07-15 18:27:23 --> Language Class Initialized
INFO - 2018-07-15 18:27:23 --> Loader Class Initialized
INFO - 2018-07-15 18:27:23 --> Helper loaded: url_helper
INFO - 2018-07-15 18:27:23 --> Helper loaded: form_helper
INFO - 2018-07-15 18:27:23 --> Helper loaded: language_helper
DEBUG - 2018-07-15 18:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 18:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 18:27:23 --> User Agent Class Initialized
INFO - 2018-07-15 18:27:23 --> Controller Class Initialized
INFO - 2018-07-15 18:27:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 18:27:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 18:27:23 --> Pixel_Model class loaded
INFO - 2018-07-15 18:27:23 --> Database Driver Class Initialized
INFO - 2018-07-15 18:27:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 18:27:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 18:27:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 18:27:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 18:27:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 18:27:23 --> Final output sent to browser
DEBUG - 2018-07-15 18:27:23 --> Total execution time: 0.0356
INFO - 2018-07-15 18:44:48 --> Config Class Initialized
INFO - 2018-07-15 18:44:48 --> Hooks Class Initialized
DEBUG - 2018-07-15 18:44:48 --> UTF-8 Support Enabled
INFO - 2018-07-15 18:44:48 --> Utf8 Class Initialized
INFO - 2018-07-15 18:44:48 --> URI Class Initialized
DEBUG - 2018-07-15 18:44:48 --> No URI present. Default controller set.
INFO - 2018-07-15 18:44:48 --> Router Class Initialized
INFO - 2018-07-15 18:44:48 --> Output Class Initialized
INFO - 2018-07-15 18:44:48 --> Security Class Initialized
DEBUG - 2018-07-15 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 18:44:48 --> CSRF cookie sent
INFO - 2018-07-15 18:44:48 --> Input Class Initialized
INFO - 2018-07-15 18:44:48 --> Language Class Initialized
INFO - 2018-07-15 18:44:48 --> Loader Class Initialized
INFO - 2018-07-15 18:44:48 --> Helper loaded: url_helper
INFO - 2018-07-15 18:44:48 --> Helper loaded: form_helper
INFO - 2018-07-15 18:44:48 --> Helper loaded: language_helper
DEBUG - 2018-07-15 18:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 18:44:48 --> User Agent Class Initialized
INFO - 2018-07-15 18:44:48 --> Controller Class Initialized
INFO - 2018-07-15 18:44:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 18:44:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 18:44:48 --> Pixel_Model class loaded
INFO - 2018-07-15 18:44:48 --> Database Driver Class Initialized
INFO - 2018-07-15 18:44:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 18:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 18:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 18:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 18:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 18:44:48 --> Final output sent to browser
DEBUG - 2018-07-15 18:44:48 --> Total execution time: 0.0349
INFO - 2018-07-15 20:07:28 --> Config Class Initialized
INFO - 2018-07-15 20:07:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:07:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:07:28 --> Utf8 Class Initialized
INFO - 2018-07-15 20:07:28 --> URI Class Initialized
DEBUG - 2018-07-15 20:07:28 --> No URI present. Default controller set.
INFO - 2018-07-15 20:07:28 --> Router Class Initialized
INFO - 2018-07-15 20:07:28 --> Output Class Initialized
INFO - 2018-07-15 20:07:28 --> Security Class Initialized
DEBUG - 2018-07-15 20:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:07:28 --> CSRF cookie sent
INFO - 2018-07-15 20:07:28 --> Input Class Initialized
INFO - 2018-07-15 20:07:28 --> Language Class Initialized
INFO - 2018-07-15 20:07:28 --> Loader Class Initialized
INFO - 2018-07-15 20:07:28 --> Helper loaded: url_helper
INFO - 2018-07-15 20:07:28 --> Helper loaded: form_helper
INFO - 2018-07-15 20:07:28 --> Helper loaded: language_helper
DEBUG - 2018-07-15 20:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 20:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 20:07:28 --> User Agent Class Initialized
INFO - 2018-07-15 20:07:28 --> Controller Class Initialized
INFO - 2018-07-15 20:07:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 20:07:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 20:07:28 --> Pixel_Model class loaded
INFO - 2018-07-15 20:07:28 --> Database Driver Class Initialized
INFO - 2018-07-15 20:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-15 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-15 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 20:07:28 --> Final output sent to browser
DEBUG - 2018-07-15 20:07:28 --> Total execution time: 0.0347
INFO - 2018-07-15 22:44:49 --> Config Class Initialized
INFO - 2018-07-15 22:44:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:44:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:44:49 --> Utf8 Class Initialized
INFO - 2018-07-15 22:44:49 --> URI Class Initialized
INFO - 2018-07-15 22:44:49 --> Router Class Initialized
INFO - 2018-07-15 22:44:49 --> Output Class Initialized
INFO - 2018-07-15 22:44:49 --> Security Class Initialized
DEBUG - 2018-07-15 22:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:44:49 --> CSRF cookie sent
INFO - 2018-07-15 22:44:49 --> Input Class Initialized
INFO - 2018-07-15 22:44:49 --> Language Class Initialized
ERROR - 2018-07-15 22:44:49 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-15 22:44:52 --> Config Class Initialized
INFO - 2018-07-15 22:44:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:44:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:44:52 --> Utf8 Class Initialized
INFO - 2018-07-15 22:44:52 --> URI Class Initialized
INFO - 2018-07-15 22:44:52 --> Router Class Initialized
INFO - 2018-07-15 22:44:52 --> Output Class Initialized
INFO - 2018-07-15 22:44:52 --> Security Class Initialized
DEBUG - 2018-07-15 22:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:44:52 --> CSRF cookie sent
INFO - 2018-07-15 22:44:52 --> Input Class Initialized
INFO - 2018-07-15 22:44:52 --> Language Class Initialized
INFO - 2018-07-15 22:44:52 --> Loader Class Initialized
INFO - 2018-07-15 22:44:52 --> Helper loaded: url_helper
INFO - 2018-07-15 22:44:52 --> Helper loaded: form_helper
INFO - 2018-07-15 22:44:52 --> Helper loaded: language_helper
DEBUG - 2018-07-15 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:44:52 --> User Agent Class Initialized
INFO - 2018-07-15 22:44:52 --> Controller Class Initialized
INFO - 2018-07-15 22:44:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-15 22:44:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-15 22:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-15 22:44:52 --> Final output sent to browser
DEBUG - 2018-07-15 22:44:52 --> Total execution time: 0.0265

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-16 01:54:37 --> Config Class Initialized
INFO - 2018-07-16 01:54:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 01:54:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 01:54:37 --> Utf8 Class Initialized
INFO - 2018-07-16 01:54:37 --> URI Class Initialized
DEBUG - 2018-07-16 01:54:37 --> No URI present. Default controller set.
INFO - 2018-07-16 01:54:37 --> Router Class Initialized
INFO - 2018-07-16 01:54:37 --> Output Class Initialized
INFO - 2018-07-16 01:54:37 --> Security Class Initialized
DEBUG - 2018-07-16 01:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 01:54:37 --> CSRF cookie sent
INFO - 2018-07-16 01:54:37 --> Input Class Initialized
INFO - 2018-07-16 01:54:37 --> Language Class Initialized
INFO - 2018-07-16 01:54:37 --> Loader Class Initialized
INFO - 2018-07-16 01:54:37 --> Helper loaded: url_helper
INFO - 2018-07-16 01:54:37 --> Helper loaded: form_helper
INFO - 2018-07-16 01:54:37 --> Helper loaded: language_helper
DEBUG - 2018-07-16 01:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 01:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 01:54:37 --> User Agent Class Initialized
INFO - 2018-07-16 01:54:37 --> Controller Class Initialized
INFO - 2018-07-16 01:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 01:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 01:54:37 --> Pixel_Model class loaded
INFO - 2018-07-16 01:54:37 --> Database Driver Class Initialized
INFO - 2018-07-16 01:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 01:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 01:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 01:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 01:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 01:54:37 --> Final output sent to browser
DEBUG - 2018-07-16 01:54:37 --> Total execution time: 0.0329
INFO - 2018-07-16 04:41:04 --> Config Class Initialized
INFO - 2018-07-16 04:41:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:41:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:41:04 --> Utf8 Class Initialized
INFO - 2018-07-16 04:41:04 --> URI Class Initialized
INFO - 2018-07-16 04:41:04 --> Router Class Initialized
INFO - 2018-07-16 04:41:04 --> Output Class Initialized
INFO - 2018-07-16 04:41:04 --> Security Class Initialized
DEBUG - 2018-07-16 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:41:04 --> CSRF cookie sent
INFO - 2018-07-16 04:41:04 --> Input Class Initialized
INFO - 2018-07-16 04:41:04 --> Language Class Initialized
ERROR - 2018-07-16 04:41:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 09:31:28 --> Config Class Initialized
INFO - 2018-07-16 09:31:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 09:31:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 09:31:28 --> Utf8 Class Initialized
INFO - 2018-07-16 09:31:28 --> URI Class Initialized
INFO - 2018-07-16 09:31:28 --> Router Class Initialized
INFO - 2018-07-16 09:31:28 --> Output Class Initialized
INFO - 2018-07-16 09:31:28 --> Security Class Initialized
DEBUG - 2018-07-16 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 09:31:28 --> CSRF cookie sent
INFO - 2018-07-16 09:31:28 --> Input Class Initialized
INFO - 2018-07-16 09:31:28 --> Language Class Initialized
ERROR - 2018-07-16 09:31:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 09:54:27 --> Config Class Initialized
INFO - 2018-07-16 09:54:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 09:54:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 09:54:27 --> Utf8 Class Initialized
INFO - 2018-07-16 09:54:27 --> URI Class Initialized
DEBUG - 2018-07-16 09:54:27 --> No URI present. Default controller set.
INFO - 2018-07-16 09:54:27 --> Router Class Initialized
INFO - 2018-07-16 09:54:27 --> Output Class Initialized
INFO - 2018-07-16 09:54:27 --> Security Class Initialized
DEBUG - 2018-07-16 09:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 09:54:27 --> CSRF cookie sent
INFO - 2018-07-16 09:54:27 --> Input Class Initialized
INFO - 2018-07-16 09:54:27 --> Language Class Initialized
INFO - 2018-07-16 09:54:27 --> Loader Class Initialized
INFO - 2018-07-16 09:54:27 --> Helper loaded: url_helper
INFO - 2018-07-16 09:54:27 --> Helper loaded: form_helper
INFO - 2018-07-16 09:54:27 --> Helper loaded: language_helper
DEBUG - 2018-07-16 09:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 09:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 09:54:27 --> User Agent Class Initialized
INFO - 2018-07-16 09:54:27 --> Controller Class Initialized
INFO - 2018-07-16 09:54:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 09:54:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 09:54:27 --> Pixel_Model class loaded
INFO - 2018-07-16 09:54:27 --> Database Driver Class Initialized
INFO - 2018-07-16 09:54:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 09:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 09:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 09:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 09:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 09:54:27 --> Final output sent to browser
DEBUG - 2018-07-16 09:54:27 --> Total execution time: 0.0322
INFO - 2018-07-16 11:07:50 --> Config Class Initialized
INFO - 2018-07-16 11:07:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 11:07:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 11:07:50 --> Utf8 Class Initialized
INFO - 2018-07-16 11:07:50 --> URI Class Initialized
DEBUG - 2018-07-16 11:07:50 --> No URI present. Default controller set.
INFO - 2018-07-16 11:07:50 --> Router Class Initialized
INFO - 2018-07-16 11:07:50 --> Output Class Initialized
INFO - 2018-07-16 11:07:50 --> Security Class Initialized
DEBUG - 2018-07-16 11:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 11:07:50 --> CSRF cookie sent
INFO - 2018-07-16 11:07:50 --> Input Class Initialized
INFO - 2018-07-16 11:07:50 --> Language Class Initialized
INFO - 2018-07-16 11:07:50 --> Loader Class Initialized
INFO - 2018-07-16 11:07:50 --> Helper loaded: url_helper
INFO - 2018-07-16 11:07:50 --> Helper loaded: form_helper
INFO - 2018-07-16 11:07:50 --> Helper loaded: language_helper
DEBUG - 2018-07-16 11:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 11:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 11:07:50 --> User Agent Class Initialized
INFO - 2018-07-16 11:07:50 --> Controller Class Initialized
INFO - 2018-07-16 11:07:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 11:07:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 11:07:50 --> Pixel_Model class loaded
INFO - 2018-07-16 11:07:50 --> Database Driver Class Initialized
INFO - 2018-07-16 11:07:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 11:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 11:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 11:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 11:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 11:07:50 --> Final output sent to browser
DEBUG - 2018-07-16 11:07:50 --> Total execution time: 0.0471
INFO - 2018-07-16 11:13:54 --> Config Class Initialized
INFO - 2018-07-16 11:13:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 11:13:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 11:13:54 --> Utf8 Class Initialized
INFO - 2018-07-16 11:13:54 --> URI Class Initialized
DEBUG - 2018-07-16 11:13:54 --> No URI present. Default controller set.
INFO - 2018-07-16 11:13:54 --> Router Class Initialized
INFO - 2018-07-16 11:13:54 --> Output Class Initialized
INFO - 2018-07-16 11:13:54 --> Security Class Initialized
DEBUG - 2018-07-16 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 11:13:54 --> CSRF cookie sent
INFO - 2018-07-16 11:13:54 --> Input Class Initialized
INFO - 2018-07-16 11:13:54 --> Language Class Initialized
INFO - 2018-07-16 11:13:54 --> Loader Class Initialized
INFO - 2018-07-16 11:13:54 --> Helper loaded: url_helper
INFO - 2018-07-16 11:13:54 --> Helper loaded: form_helper
INFO - 2018-07-16 11:13:54 --> Helper loaded: language_helper
DEBUG - 2018-07-16 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 11:13:54 --> User Agent Class Initialized
INFO - 2018-07-16 11:13:54 --> Controller Class Initialized
INFO - 2018-07-16 11:13:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 11:13:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 11:13:54 --> Pixel_Model class loaded
INFO - 2018-07-16 11:13:54 --> Database Driver Class Initialized
INFO - 2018-07-16 11:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 11:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 11:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 11:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 11:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 11:13:54 --> Final output sent to browser
DEBUG - 2018-07-16 11:13:54 --> Total execution time: 0.0315
INFO - 2018-07-16 12:36:35 --> Config Class Initialized
INFO - 2018-07-16 12:36:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 12:36:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 12:36:35 --> Utf8 Class Initialized
INFO - 2018-07-16 12:36:35 --> URI Class Initialized
INFO - 2018-07-16 12:36:35 --> Router Class Initialized
INFO - 2018-07-16 12:36:35 --> Output Class Initialized
INFO - 2018-07-16 12:36:35 --> Security Class Initialized
DEBUG - 2018-07-16 12:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 12:36:35 --> CSRF cookie sent
INFO - 2018-07-16 12:36:35 --> Input Class Initialized
INFO - 2018-07-16 12:36:35 --> Language Class Initialized
ERROR - 2018-07-16 12:36:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 12:36:38 --> Config Class Initialized
INFO - 2018-07-16 12:36:38 --> Hooks Class Initialized
DEBUG - 2018-07-16 12:36:38 --> UTF-8 Support Enabled
INFO - 2018-07-16 12:36:38 --> Utf8 Class Initialized
INFO - 2018-07-16 12:36:38 --> URI Class Initialized
INFO - 2018-07-16 12:36:38 --> Router Class Initialized
INFO - 2018-07-16 12:36:38 --> Output Class Initialized
INFO - 2018-07-16 12:36:38 --> Security Class Initialized
DEBUG - 2018-07-16 12:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 12:36:38 --> CSRF cookie sent
INFO - 2018-07-16 12:36:38 --> Input Class Initialized
INFO - 2018-07-16 12:36:38 --> Language Class Initialized
INFO - 2018-07-16 12:36:38 --> Loader Class Initialized
INFO - 2018-07-16 12:36:38 --> Helper loaded: url_helper
INFO - 2018-07-16 12:36:38 --> Helper loaded: form_helper
INFO - 2018-07-16 12:36:38 --> Helper loaded: language_helper
DEBUG - 2018-07-16 12:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 12:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 12:36:38 --> User Agent Class Initialized
INFO - 2018-07-16 12:36:38 --> Controller Class Initialized
INFO - 2018-07-16 12:36:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 12:36:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 12:36:38 --> Pixel_Model class loaded
INFO - 2018-07-16 12:36:38 --> Database Driver Class Initialized
INFO - 2018-07-16 12:36:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-16 12:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 12:36:38 --> Final output sent to browser
DEBUG - 2018-07-16 12:36:38 --> Total execution time: 0.0345
INFO - 2018-07-16 14:16:16 --> Config Class Initialized
INFO - 2018-07-16 14:16:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:16:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:16:16 --> Utf8 Class Initialized
INFO - 2018-07-16 14:16:16 --> URI Class Initialized
DEBUG - 2018-07-16 14:16:16 --> No URI present. Default controller set.
INFO - 2018-07-16 14:16:16 --> Router Class Initialized
INFO - 2018-07-16 14:16:16 --> Output Class Initialized
INFO - 2018-07-16 14:16:16 --> Security Class Initialized
DEBUG - 2018-07-16 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:16:16 --> CSRF cookie sent
INFO - 2018-07-16 14:16:16 --> Input Class Initialized
INFO - 2018-07-16 14:16:16 --> Language Class Initialized
INFO - 2018-07-16 14:16:16 --> Loader Class Initialized
INFO - 2018-07-16 14:16:16 --> Helper loaded: url_helper
INFO - 2018-07-16 14:16:16 --> Helper loaded: form_helper
INFO - 2018-07-16 14:16:16 --> Helper loaded: language_helper
DEBUG - 2018-07-16 14:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 14:16:16 --> User Agent Class Initialized
INFO - 2018-07-16 14:16:16 --> Controller Class Initialized
INFO - 2018-07-16 14:16:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 14:16:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 14:16:16 --> Pixel_Model class loaded
INFO - 2018-07-16 14:16:16 --> Database Driver Class Initialized
INFO - 2018-07-16 14:16:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 14:16:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 14:16:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 14:16:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 14:16:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 14:16:16 --> Final output sent to browser
DEBUG - 2018-07-16 14:16:16 --> Total execution time: 0.0334
INFO - 2018-07-16 16:07:13 --> Config Class Initialized
INFO - 2018-07-16 16:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:07:13 --> Utf8 Class Initialized
INFO - 2018-07-16 16:07:13 --> URI Class Initialized
INFO - 2018-07-16 16:07:13 --> Router Class Initialized
INFO - 2018-07-16 16:07:13 --> Output Class Initialized
INFO - 2018-07-16 16:07:13 --> Security Class Initialized
DEBUG - 2018-07-16 16:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:07:13 --> CSRF cookie sent
INFO - 2018-07-16 16:07:13 --> Input Class Initialized
INFO - 2018-07-16 16:07:13 --> Language Class Initialized
ERROR - 2018-07-16 16:07:13 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 16:07:16 --> Config Class Initialized
INFO - 2018-07-16 16:07:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:07:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:07:16 --> Utf8 Class Initialized
INFO - 2018-07-16 16:07:16 --> URI Class Initialized
INFO - 2018-07-16 16:07:16 --> Router Class Initialized
INFO - 2018-07-16 16:07:16 --> Output Class Initialized
INFO - 2018-07-16 16:07:16 --> Security Class Initialized
DEBUG - 2018-07-16 16:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:07:16 --> CSRF cookie sent
INFO - 2018-07-16 16:07:16 --> Input Class Initialized
INFO - 2018-07-16 16:07:16 --> Language Class Initialized
INFO - 2018-07-16 16:07:16 --> Loader Class Initialized
INFO - 2018-07-16 16:07:16 --> Helper loaded: url_helper
INFO - 2018-07-16 16:07:16 --> Helper loaded: form_helper
INFO - 2018-07-16 16:07:16 --> Helper loaded: language_helper
DEBUG - 2018-07-16 16:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 16:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 16:07:16 --> User Agent Class Initialized
INFO - 2018-07-16 16:07:16 --> Controller Class Initialized
INFO - 2018-07-16 16:07:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 16:07:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-16 16:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 16:07:16 --> Final output sent to browser
DEBUG - 2018-07-16 16:07:16 --> Total execution time: 0.0402
INFO - 2018-07-16 16:59:50 --> Config Class Initialized
INFO - 2018-07-16 16:59:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:59:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:59:50 --> Utf8 Class Initialized
INFO - 2018-07-16 16:59:50 --> URI Class Initialized
INFO - 2018-07-16 16:59:50 --> Router Class Initialized
INFO - 2018-07-16 16:59:50 --> Output Class Initialized
INFO - 2018-07-16 16:59:50 --> Security Class Initialized
DEBUG - 2018-07-16 16:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:59:50 --> CSRF cookie sent
INFO - 2018-07-16 16:59:50 --> Input Class Initialized
INFO - 2018-07-16 16:59:50 --> Language Class Initialized
ERROR - 2018-07-16 16:59:50 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 17:07:01 --> Config Class Initialized
INFO - 2018-07-16 17:07:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:01 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:01 --> URI Class Initialized
DEBUG - 2018-07-16 17:07:01 --> No URI present. Default controller set.
INFO - 2018-07-16 17:07:01 --> Router Class Initialized
INFO - 2018-07-16 17:07:01 --> Output Class Initialized
INFO - 2018-07-16 17:07:01 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:01 --> CSRF cookie sent
INFO - 2018-07-16 17:07:01 --> Input Class Initialized
INFO - 2018-07-16 17:07:01 --> Language Class Initialized
INFO - 2018-07-16 17:07:01 --> Loader Class Initialized
INFO - 2018-07-16 17:07:01 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:01 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:01 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:01 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:01 --> Controller Class Initialized
INFO - 2018-07-16 17:07:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:01 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:01 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 17:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:01 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:01 --> Total execution time: 0.0357
INFO - 2018-07-16 17:07:02 --> Config Class Initialized
INFO - 2018-07-16 17:07:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:02 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:02 --> URI Class Initialized
DEBUG - 2018-07-16 17:07:02 --> No URI present. Default controller set.
INFO - 2018-07-16 17:07:02 --> Router Class Initialized
INFO - 2018-07-16 17:07:02 --> Output Class Initialized
INFO - 2018-07-16 17:07:02 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:02 --> CSRF cookie sent
INFO - 2018-07-16 17:07:02 --> Input Class Initialized
INFO - 2018-07-16 17:07:02 --> Language Class Initialized
INFO - 2018-07-16 17:07:02 --> Loader Class Initialized
INFO - 2018-07-16 17:07:02 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:02 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:02 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:02 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:02 --> Controller Class Initialized
INFO - 2018-07-16 17:07:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:02 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:02 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:02 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:02 --> Total execution time: 0.0463
INFO - 2018-07-16 17:07:02 --> Config Class Initialized
INFO - 2018-07-16 17:07:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:02 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:02 --> URI Class Initialized
DEBUG - 2018-07-16 17:07:02 --> No URI present. Default controller set.
INFO - 2018-07-16 17:07:02 --> Router Class Initialized
INFO - 2018-07-16 17:07:02 --> Output Class Initialized
INFO - 2018-07-16 17:07:02 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:02 --> CSRF cookie sent
INFO - 2018-07-16 17:07:02 --> Input Class Initialized
INFO - 2018-07-16 17:07:02 --> Language Class Initialized
INFO - 2018-07-16 17:07:02 --> Loader Class Initialized
INFO - 2018-07-16 17:07:02 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:02 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:02 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:02 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:02 --> Controller Class Initialized
INFO - 2018-07-16 17:07:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:02 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:02 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 17:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:02 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:02 --> Total execution time: 0.0368
INFO - 2018-07-16 17:07:03 --> Config Class Initialized
INFO - 2018-07-16 17:07:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:03 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:03 --> URI Class Initialized
INFO - 2018-07-16 17:07:03 --> Router Class Initialized
INFO - 2018-07-16 17:07:03 --> Output Class Initialized
INFO - 2018-07-16 17:07:03 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:03 --> CSRF cookie sent
INFO - 2018-07-16 17:07:03 --> Input Class Initialized
INFO - 2018-07-16 17:07:03 --> Language Class Initialized
ERROR - 2018-07-16 17:07:03 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-16 17:07:10 --> Config Class Initialized
INFO - 2018-07-16 17:07:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:10 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:10 --> URI Class Initialized
DEBUG - 2018-07-16 17:07:10 --> No URI present. Default controller set.
INFO - 2018-07-16 17:07:10 --> Router Class Initialized
INFO - 2018-07-16 17:07:10 --> Output Class Initialized
INFO - 2018-07-16 17:07:10 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:10 --> CSRF cookie sent
INFO - 2018-07-16 17:07:10 --> Input Class Initialized
INFO - 2018-07-16 17:07:10 --> Language Class Initialized
INFO - 2018-07-16 17:07:10 --> Loader Class Initialized
INFO - 2018-07-16 17:07:10 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:10 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:10 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:10 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:10 --> Controller Class Initialized
INFO - 2018-07-16 17:07:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:10 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:10 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 17:07:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:10 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:10 --> Total execution time: 0.0506
INFO - 2018-07-16 17:07:10 --> Config Class Initialized
INFO - 2018-07-16 17:07:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:10 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:10 --> URI Class Initialized
INFO - 2018-07-16 17:07:10 --> Router Class Initialized
INFO - 2018-07-16 17:07:10 --> Output Class Initialized
INFO - 2018-07-16 17:07:10 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:10 --> CSRF cookie sent
INFO - 2018-07-16 17:07:10 --> Input Class Initialized
INFO - 2018-07-16 17:07:10 --> Language Class Initialized
ERROR - 2018-07-16 17:07:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-16 17:07:11 --> Config Class Initialized
INFO - 2018-07-16 17:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:11 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:11 --> URI Class Initialized
INFO - 2018-07-16 17:07:11 --> Router Class Initialized
INFO - 2018-07-16 17:07:11 --> Output Class Initialized
INFO - 2018-07-16 17:07:11 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:11 --> CSRF cookie sent
INFO - 2018-07-16 17:07:11 --> Input Class Initialized
INFO - 2018-07-16 17:07:11 --> Language Class Initialized
ERROR - 2018-07-16 17:07:11 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-16 17:07:11 --> Config Class Initialized
INFO - 2018-07-16 17:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:11 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:11 --> URI Class Initialized
INFO - 2018-07-16 17:07:11 --> Router Class Initialized
INFO - 2018-07-16 17:07:11 --> Output Class Initialized
INFO - 2018-07-16 17:07:11 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:11 --> CSRF cookie sent
INFO - 2018-07-16 17:07:11 --> Input Class Initialized
INFO - 2018-07-16 17:07:11 --> Language Class Initialized
INFO - 2018-07-16 17:07:11 --> Loader Class Initialized
INFO - 2018-07-16 17:07:11 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:11 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:11 --> Controller Class Initialized
INFO - 2018-07-16 17:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:11 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:11 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:11 --> Config Class Initialized
INFO - 2018-07-16 17:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:11 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:11 --> URI Class Initialized
INFO - 2018-07-16 17:07:11 --> Router Class Initialized
INFO - 2018-07-16 17:07:11 --> Output Class Initialized
INFO - 2018-07-16 17:07:11 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:11 --> CSRF cookie sent
INFO - 2018-07-16 17:07:11 --> Input Class Initialized
INFO - 2018-07-16 17:07:11 --> Language Class Initialized
INFO - 2018-07-16 17:07:11 --> Loader Class Initialized
INFO - 2018-07-16 17:07:11 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:11 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:11 --> Controller Class Initialized
INFO - 2018-07-16 17:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-16 17:07:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-16 17:07:11 --> Could not find the language line "req_email"
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-16 17:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:11 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:11 --> Total execution time: 0.0221
INFO - 2018-07-16 17:07:11 --> Config Class Initialized
INFO - 2018-07-16 17:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:11 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:11 --> URI Class Initialized
INFO - 2018-07-16 17:07:11 --> Router Class Initialized
INFO - 2018-07-16 17:07:11 --> Output Class Initialized
INFO - 2018-07-16 17:07:11 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:11 --> CSRF cookie sent
INFO - 2018-07-16 17:07:11 --> Input Class Initialized
INFO - 2018-07-16 17:07:11 --> Language Class Initialized
INFO - 2018-07-16 17:07:11 --> Loader Class Initialized
INFO - 2018-07-16 17:07:11 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:11 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:12 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:12 --> Controller Class Initialized
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:12 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:12 --> Total execution time: 0.0315
INFO - 2018-07-16 17:07:12 --> Config Class Initialized
INFO - 2018-07-16 17:07:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:12 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:12 --> URI Class Initialized
INFO - 2018-07-16 17:07:12 --> Router Class Initialized
INFO - 2018-07-16 17:07:12 --> Output Class Initialized
INFO - 2018-07-16 17:07:12 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:12 --> CSRF cookie sent
INFO - 2018-07-16 17:07:12 --> Input Class Initialized
INFO - 2018-07-16 17:07:12 --> Language Class Initialized
INFO - 2018-07-16 17:07:12 --> Loader Class Initialized
INFO - 2018-07-16 17:07:12 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:12 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:12 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:12 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:12 --> Controller Class Initialized
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:12 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:12 --> Total execution time: 0.0251
INFO - 2018-07-16 17:07:12 --> Config Class Initialized
INFO - 2018-07-16 17:07:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:12 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:12 --> URI Class Initialized
INFO - 2018-07-16 17:07:12 --> Router Class Initialized
INFO - 2018-07-16 17:07:12 --> Output Class Initialized
INFO - 2018-07-16 17:07:12 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:12 --> CSRF cookie sent
INFO - 2018-07-16 17:07:12 --> Input Class Initialized
INFO - 2018-07-16 17:07:12 --> Language Class Initialized
INFO - 2018-07-16 17:07:12 --> Loader Class Initialized
INFO - 2018-07-16 17:07:12 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:12 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:12 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:12 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:12 --> Controller Class Initialized
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-16 17:07:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:12 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:12 --> Total execution time: 0.0203
INFO - 2018-07-16 17:07:13 --> Config Class Initialized
INFO - 2018-07-16 17:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:13 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:13 --> URI Class Initialized
INFO - 2018-07-16 17:07:13 --> Router Class Initialized
INFO - 2018-07-16 17:07:13 --> Output Class Initialized
INFO - 2018-07-16 17:07:13 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:13 --> CSRF cookie sent
INFO - 2018-07-16 17:07:13 --> Input Class Initialized
INFO - 2018-07-16 17:07:13 --> Language Class Initialized
INFO - 2018-07-16 17:07:13 --> Loader Class Initialized
INFO - 2018-07-16 17:07:13 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:13 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:13 --> Controller Class Initialized
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:13 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:13 --> Total execution time: 0.0235
INFO - 2018-07-16 17:07:13 --> Config Class Initialized
INFO - 2018-07-16 17:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:13 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:13 --> URI Class Initialized
INFO - 2018-07-16 17:07:13 --> Router Class Initialized
INFO - 2018-07-16 17:07:13 --> Output Class Initialized
INFO - 2018-07-16 17:07:13 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:13 --> CSRF cookie sent
INFO - 2018-07-16 17:07:13 --> Input Class Initialized
INFO - 2018-07-16 17:07:13 --> Language Class Initialized
INFO - 2018-07-16 17:07:13 --> Loader Class Initialized
INFO - 2018-07-16 17:07:13 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:13 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:13 --> Controller Class Initialized
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-16 17:07:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-16 17:07:13 --> Could not find the language line "req_email"
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:13 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:13 --> Total execution time: 0.0237
INFO - 2018-07-16 17:07:13 --> Config Class Initialized
INFO - 2018-07-16 17:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:07:13 --> Utf8 Class Initialized
INFO - 2018-07-16 17:07:13 --> URI Class Initialized
INFO - 2018-07-16 17:07:13 --> Router Class Initialized
INFO - 2018-07-16 17:07:13 --> Output Class Initialized
INFO - 2018-07-16 17:07:13 --> Security Class Initialized
DEBUG - 2018-07-16 17:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:07:13 --> CSRF cookie sent
INFO - 2018-07-16 17:07:13 --> Input Class Initialized
INFO - 2018-07-16 17:07:13 --> Language Class Initialized
INFO - 2018-07-16 17:07:13 --> Loader Class Initialized
INFO - 2018-07-16 17:07:13 --> Helper loaded: url_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: form_helper
INFO - 2018-07-16 17:07:13 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:07:13 --> User Agent Class Initialized
INFO - 2018-07-16 17:07:13 --> Controller Class Initialized
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:07:13 --> Pixel_Model class loaded
INFO - 2018-07-16 17:07:13 --> Database Driver Class Initialized
INFO - 2018-07-16 17:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-16 17:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:07:13 --> Final output sent to browser
DEBUG - 2018-07-16 17:07:13 --> Total execution time: 0.0376
INFO - 2018-07-16 17:29:25 --> Config Class Initialized
INFO - 2018-07-16 17:29:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:29:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:29:25 --> Utf8 Class Initialized
INFO - 2018-07-16 17:29:25 --> URI Class Initialized
INFO - 2018-07-16 17:29:25 --> Router Class Initialized
INFO - 2018-07-16 17:29:25 --> Output Class Initialized
INFO - 2018-07-16 17:29:25 --> Security Class Initialized
DEBUG - 2018-07-16 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:29:25 --> CSRF cookie sent
INFO - 2018-07-16 17:29:25 --> Input Class Initialized
INFO - 2018-07-16 17:29:25 --> Language Class Initialized
ERROR - 2018-07-16 17:29:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 17:54:48 --> Config Class Initialized
INFO - 2018-07-16 17:54:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:54:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:54:48 --> Utf8 Class Initialized
INFO - 2018-07-16 17:54:48 --> URI Class Initialized
DEBUG - 2018-07-16 17:54:48 --> No URI present. Default controller set.
INFO - 2018-07-16 17:54:48 --> Router Class Initialized
INFO - 2018-07-16 17:54:48 --> Output Class Initialized
INFO - 2018-07-16 17:54:48 --> Security Class Initialized
DEBUG - 2018-07-16 17:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:54:48 --> CSRF cookie sent
INFO - 2018-07-16 17:54:48 --> Input Class Initialized
INFO - 2018-07-16 17:54:48 --> Language Class Initialized
INFO - 2018-07-16 17:54:48 --> Loader Class Initialized
INFO - 2018-07-16 17:54:48 --> Helper loaded: url_helper
INFO - 2018-07-16 17:54:48 --> Helper loaded: form_helper
INFO - 2018-07-16 17:54:48 --> Helper loaded: language_helper
DEBUG - 2018-07-16 17:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:54:48 --> User Agent Class Initialized
INFO - 2018-07-16 17:54:48 --> Controller Class Initialized
INFO - 2018-07-16 17:54:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 17:54:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 17:54:48 --> Pixel_Model class loaded
INFO - 2018-07-16 17:54:48 --> Database Driver Class Initialized
INFO - 2018-07-16 17:54:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 17:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 17:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 17:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 17:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 17:54:48 --> Final output sent to browser
DEBUG - 2018-07-16 17:54:48 --> Total execution time: 0.0359
INFO - 2018-07-16 18:08:53 --> Config Class Initialized
INFO - 2018-07-16 18:08:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:08:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:08:53 --> Utf8 Class Initialized
INFO - 2018-07-16 18:08:53 --> URI Class Initialized
DEBUG - 2018-07-16 18:08:53 --> No URI present. Default controller set.
INFO - 2018-07-16 18:08:53 --> Router Class Initialized
INFO - 2018-07-16 18:08:53 --> Output Class Initialized
INFO - 2018-07-16 18:08:53 --> Security Class Initialized
DEBUG - 2018-07-16 18:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:08:53 --> CSRF cookie sent
INFO - 2018-07-16 18:08:53 --> Input Class Initialized
INFO - 2018-07-16 18:08:53 --> Language Class Initialized
INFO - 2018-07-16 18:08:53 --> Loader Class Initialized
INFO - 2018-07-16 18:08:53 --> Helper loaded: url_helper
INFO - 2018-07-16 18:08:53 --> Helper loaded: form_helper
INFO - 2018-07-16 18:08:53 --> Helper loaded: language_helper
DEBUG - 2018-07-16 18:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 18:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 18:08:53 --> User Agent Class Initialized
INFO - 2018-07-16 18:08:53 --> Controller Class Initialized
INFO - 2018-07-16 18:08:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 18:08:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 18:08:53 --> Pixel_Model class loaded
INFO - 2018-07-16 18:08:53 --> Database Driver Class Initialized
INFO - 2018-07-16 18:08:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 18:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 18:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 18:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 18:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 18:08:53 --> Final output sent to browser
DEBUG - 2018-07-16 18:08:53 --> Total execution time: 0.0480
INFO - 2018-07-16 18:49:48 --> Config Class Initialized
INFO - 2018-07-16 18:49:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:49:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:49:48 --> Utf8 Class Initialized
INFO - 2018-07-16 18:49:48 --> URI Class Initialized
DEBUG - 2018-07-16 18:49:48 --> No URI present. Default controller set.
INFO - 2018-07-16 18:49:48 --> Router Class Initialized
INFO - 2018-07-16 18:49:48 --> Output Class Initialized
INFO - 2018-07-16 18:49:48 --> Security Class Initialized
DEBUG - 2018-07-16 18:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:49:48 --> CSRF cookie sent
INFO - 2018-07-16 18:49:48 --> Input Class Initialized
INFO - 2018-07-16 18:49:48 --> Language Class Initialized
INFO - 2018-07-16 18:49:48 --> Loader Class Initialized
INFO - 2018-07-16 18:49:48 --> Helper loaded: url_helper
INFO - 2018-07-16 18:49:48 --> Helper loaded: form_helper
INFO - 2018-07-16 18:49:48 --> Helper loaded: language_helper
DEBUG - 2018-07-16 18:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 18:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 18:49:48 --> User Agent Class Initialized
INFO - 2018-07-16 18:49:48 --> Controller Class Initialized
INFO - 2018-07-16 18:49:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 18:49:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 18:49:48 --> Pixel_Model class loaded
INFO - 2018-07-16 18:49:48 --> Database Driver Class Initialized
INFO - 2018-07-16 18:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-16 18:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 18:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 18:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-16 18:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 18:49:48 --> Final output sent to browser
DEBUG - 2018-07-16 18:49:48 --> Total execution time: 0.0322
INFO - 2018-07-16 22:08:20 --> Config Class Initialized
INFO - 2018-07-16 22:08:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:08:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:08:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:08:20 --> URI Class Initialized
INFO - 2018-07-16 22:08:20 --> Router Class Initialized
INFO - 2018-07-16 22:08:20 --> Output Class Initialized
INFO - 2018-07-16 22:08:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:08:20 --> CSRF cookie sent
INFO - 2018-07-16 22:08:20 --> Input Class Initialized
INFO - 2018-07-16 22:08:20 --> Language Class Initialized
ERROR - 2018-07-16 22:08:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-16 22:08:23 --> Config Class Initialized
INFO - 2018-07-16 22:08:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:08:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:08:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:08:23 --> URI Class Initialized
INFO - 2018-07-16 22:08:23 --> Router Class Initialized
INFO - 2018-07-16 22:08:23 --> Output Class Initialized
INFO - 2018-07-16 22:08:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:08:23 --> CSRF cookie sent
INFO - 2018-07-16 22:08:23 --> Input Class Initialized
INFO - 2018-07-16 22:08:23 --> Language Class Initialized
INFO - 2018-07-16 22:08:23 --> Loader Class Initialized
INFO - 2018-07-16 22:08:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:08:23 --> Helper loaded: form_helper
INFO - 2018-07-16 22:08:23 --> Helper loaded: language_helper
DEBUG - 2018-07-16 22:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:08:23 --> User Agent Class Initialized
INFO - 2018-07-16 22:08:23 --> Controller Class Initialized
INFO - 2018-07-16 22:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-16 22:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-16 22:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-16 22:08:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:08:23 --> Total execution time: 0.0218

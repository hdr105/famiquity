<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-17 01:22:37 --> Config Class Initialized
INFO - 2018-07-17 01:22:37 --> Hooks Class Initialized
DEBUG - 2018-07-17 01:22:37 --> UTF-8 Support Enabled
INFO - 2018-07-17 01:22:37 --> Utf8 Class Initialized
INFO - 2018-07-17 01:22:37 --> URI Class Initialized
DEBUG - 2018-07-17 01:22:37 --> No URI present. Default controller set.
INFO - 2018-07-17 01:22:37 --> Router Class Initialized
INFO - 2018-07-17 01:22:37 --> Output Class Initialized
INFO - 2018-07-17 01:22:37 --> Security Class Initialized
DEBUG - 2018-07-17 01:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 01:22:37 --> CSRF cookie sent
INFO - 2018-07-17 01:22:37 --> Input Class Initialized
INFO - 2018-07-17 01:22:37 --> Language Class Initialized
INFO - 2018-07-17 01:22:37 --> Loader Class Initialized
INFO - 2018-07-17 01:22:37 --> Helper loaded: url_helper
INFO - 2018-07-17 01:22:37 --> Helper loaded: form_helper
INFO - 2018-07-17 01:22:37 --> Helper loaded: language_helper
DEBUG - 2018-07-17 01:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 01:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 01:22:37 --> User Agent Class Initialized
INFO - 2018-07-17 01:22:37 --> Controller Class Initialized
INFO - 2018-07-17 01:22:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 01:22:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 01:22:37 --> Pixel_Model class loaded
INFO - 2018-07-17 01:22:37 --> Database Driver Class Initialized
INFO - 2018-07-17 01:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 01:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 01:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 01:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 01:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 01:22:37 --> Final output sent to browser
DEBUG - 2018-07-17 01:22:37 --> Total execution time: 0.0292
INFO - 2018-07-17 01:54:48 --> Config Class Initialized
INFO - 2018-07-17 01:54:48 --> Hooks Class Initialized
DEBUG - 2018-07-17 01:54:48 --> UTF-8 Support Enabled
INFO - 2018-07-17 01:54:48 --> Utf8 Class Initialized
INFO - 2018-07-17 01:54:48 --> URI Class Initialized
DEBUG - 2018-07-17 01:54:48 --> No URI present. Default controller set.
INFO - 2018-07-17 01:54:48 --> Router Class Initialized
INFO - 2018-07-17 01:54:48 --> Output Class Initialized
INFO - 2018-07-17 01:54:48 --> Security Class Initialized
DEBUG - 2018-07-17 01:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 01:54:48 --> CSRF cookie sent
INFO - 2018-07-17 01:54:48 --> Input Class Initialized
INFO - 2018-07-17 01:54:48 --> Language Class Initialized
INFO - 2018-07-17 01:54:48 --> Loader Class Initialized
INFO - 2018-07-17 01:54:48 --> Helper loaded: url_helper
INFO - 2018-07-17 01:54:48 --> Helper loaded: form_helper
INFO - 2018-07-17 01:54:48 --> Helper loaded: language_helper
DEBUG - 2018-07-17 01:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 01:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 01:54:48 --> User Agent Class Initialized
INFO - 2018-07-17 01:54:48 --> Controller Class Initialized
INFO - 2018-07-17 01:54:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 01:54:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 01:54:48 --> Pixel_Model class loaded
INFO - 2018-07-17 01:54:48 --> Database Driver Class Initialized
INFO - 2018-07-17 01:54:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 01:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 01:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 01:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 01:54:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 01:54:48 --> Final output sent to browser
DEBUG - 2018-07-17 01:54:48 --> Total execution time: 0.0334
INFO - 2018-07-17 01:58:46 --> Config Class Initialized
INFO - 2018-07-17 01:58:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 01:58:46 --> UTF-8 Support Enabled
INFO - 2018-07-17 01:58:46 --> Utf8 Class Initialized
INFO - 2018-07-17 01:58:46 --> URI Class Initialized
INFO - 2018-07-17 01:58:46 --> Router Class Initialized
INFO - 2018-07-17 01:58:46 --> Output Class Initialized
INFO - 2018-07-17 01:58:46 --> Security Class Initialized
DEBUG - 2018-07-17 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 01:58:46 --> CSRF cookie sent
INFO - 2018-07-17 01:58:46 --> Input Class Initialized
INFO - 2018-07-17 01:58:46 --> Language Class Initialized
ERROR - 2018-07-17 01:58:46 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 01:58:49 --> Config Class Initialized
INFO - 2018-07-17 01:58:49 --> Hooks Class Initialized
DEBUG - 2018-07-17 01:58:49 --> UTF-8 Support Enabled
INFO - 2018-07-17 01:58:49 --> Utf8 Class Initialized
INFO - 2018-07-17 01:58:49 --> URI Class Initialized
DEBUG - 2018-07-17 01:58:49 --> No URI present. Default controller set.
INFO - 2018-07-17 01:58:49 --> Router Class Initialized
INFO - 2018-07-17 01:58:49 --> Output Class Initialized
INFO - 2018-07-17 01:58:49 --> Security Class Initialized
DEBUG - 2018-07-17 01:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 01:58:49 --> CSRF cookie sent
INFO - 2018-07-17 01:58:49 --> Input Class Initialized
INFO - 2018-07-17 01:58:49 --> Language Class Initialized
INFO - 2018-07-17 01:58:49 --> Loader Class Initialized
INFO - 2018-07-17 01:58:49 --> Helper loaded: url_helper
INFO - 2018-07-17 01:58:49 --> Helper loaded: form_helper
INFO - 2018-07-17 01:58:49 --> Helper loaded: language_helper
DEBUG - 2018-07-17 01:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 01:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 01:58:49 --> User Agent Class Initialized
INFO - 2018-07-17 01:58:49 --> Controller Class Initialized
INFO - 2018-07-17 01:58:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 01:58:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 01:58:49 --> Pixel_Model class loaded
INFO - 2018-07-17 01:58:49 --> Database Driver Class Initialized
INFO - 2018-07-17 01:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 01:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 01:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 01:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 01:58:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 01:58:49 --> Final output sent to browser
DEBUG - 2018-07-17 01:58:49 --> Total execution time: 0.0347
INFO - 2018-07-17 02:54:57 --> Config Class Initialized
INFO - 2018-07-17 02:54:57 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:54:57 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:54:57 --> Utf8 Class Initialized
INFO - 2018-07-17 02:54:57 --> URI Class Initialized
INFO - 2018-07-17 02:54:57 --> Router Class Initialized
INFO - 2018-07-17 02:54:57 --> Output Class Initialized
INFO - 2018-07-17 02:54:57 --> Security Class Initialized
DEBUG - 2018-07-17 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:54:57 --> CSRF cookie sent
INFO - 2018-07-17 02:54:57 --> Input Class Initialized
INFO - 2018-07-17 02:54:57 --> Language Class Initialized
ERROR - 2018-07-17 02:54:57 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 02:54:57 --> Config Class Initialized
INFO - 2018-07-17 02:54:57 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:54:57 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:54:57 --> Utf8 Class Initialized
INFO - 2018-07-17 02:54:57 --> URI Class Initialized
INFO - 2018-07-17 02:54:57 --> Router Class Initialized
INFO - 2018-07-17 02:54:57 --> Output Class Initialized
INFO - 2018-07-17 02:54:57 --> Security Class Initialized
DEBUG - 2018-07-17 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:54:57 --> CSRF cookie sent
INFO - 2018-07-17 02:54:57 --> Input Class Initialized
INFO - 2018-07-17 02:54:57 --> Language Class Initialized
INFO - 2018-07-17 02:54:57 --> Loader Class Initialized
INFO - 2018-07-17 02:54:57 --> Helper loaded: url_helper
INFO - 2018-07-17 02:54:57 --> Helper loaded: form_helper
INFO - 2018-07-17 02:54:57 --> Helper loaded: language_helper
DEBUG - 2018-07-17 02:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:54:57 --> User Agent Class Initialized
INFO - 2018-07-17 02:54:57 --> Controller Class Initialized
INFO - 2018-07-17 02:54:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 02:54:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 02:54:57 --> Pixel_Model class loaded
INFO - 2018-07-17 02:54:57 --> Database Driver Class Initialized
INFO - 2018-07-17 02:54:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 02:54:58 --> Config Class Initialized
INFO - 2018-07-17 02:54:58 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:54:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:54:58 --> Utf8 Class Initialized
INFO - 2018-07-17 02:54:58 --> URI Class Initialized
INFO - 2018-07-17 02:54:58 --> Router Class Initialized
INFO - 2018-07-17 02:54:58 --> Output Class Initialized
INFO - 2018-07-17 02:54:58 --> Security Class Initialized
DEBUG - 2018-07-17 02:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:54:58 --> CSRF cookie sent
INFO - 2018-07-17 02:54:58 --> Input Class Initialized
INFO - 2018-07-17 02:54:58 --> Language Class Initialized
INFO - 2018-07-17 02:54:58 --> Loader Class Initialized
INFO - 2018-07-17 02:54:58 --> Helper loaded: url_helper
INFO - 2018-07-17 02:54:58 --> Helper loaded: form_helper
INFO - 2018-07-17 02:54:58 --> Helper loaded: language_helper
DEBUG - 2018-07-17 02:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:54:58 --> User Agent Class Initialized
INFO - 2018-07-17 02:54:58 --> Controller Class Initialized
INFO - 2018-07-17 02:54:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 02:54:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-17 02:54:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-17 02:54:58 --> Could not find the language line "req_email"
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-17 02:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 02:54:58 --> Final output sent to browser
DEBUG - 2018-07-17 02:54:58 --> Total execution time: 0.0245
INFO - 2018-07-17 06:24:03 --> Config Class Initialized
INFO - 2018-07-17 06:24:03 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:24:03 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:24:03 --> Utf8 Class Initialized
INFO - 2018-07-17 06:24:03 --> URI Class Initialized
DEBUG - 2018-07-17 06:24:03 --> No URI present. Default controller set.
INFO - 2018-07-17 06:24:03 --> Router Class Initialized
INFO - 2018-07-17 06:24:03 --> Output Class Initialized
INFO - 2018-07-17 06:24:03 --> Security Class Initialized
DEBUG - 2018-07-17 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:24:03 --> CSRF cookie sent
INFO - 2018-07-17 06:24:03 --> Input Class Initialized
INFO - 2018-07-17 06:24:03 --> Language Class Initialized
INFO - 2018-07-17 06:24:03 --> Loader Class Initialized
INFO - 2018-07-17 06:24:03 --> Helper loaded: url_helper
INFO - 2018-07-17 06:24:03 --> Helper loaded: form_helper
INFO - 2018-07-17 06:24:03 --> Helper loaded: language_helper
DEBUG - 2018-07-17 06:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 06:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 06:24:03 --> User Agent Class Initialized
INFO - 2018-07-17 06:24:03 --> Controller Class Initialized
INFO - 2018-07-17 06:24:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 06:24:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 06:24:03 --> Pixel_Model class loaded
INFO - 2018-07-17 06:24:03 --> Database Driver Class Initialized
INFO - 2018-07-17 06:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 06:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 06:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 06:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 06:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 06:24:03 --> Final output sent to browser
DEBUG - 2018-07-17 06:24:03 --> Total execution time: 0.0356
INFO - 2018-07-17 06:24:12 --> Config Class Initialized
INFO - 2018-07-17 06:24:12 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:24:12 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:24:12 --> Utf8 Class Initialized
INFO - 2018-07-17 06:24:12 --> URI Class Initialized
INFO - 2018-07-17 06:24:12 --> Router Class Initialized
INFO - 2018-07-17 06:24:12 --> Output Class Initialized
INFO - 2018-07-17 06:24:12 --> Security Class Initialized
DEBUG - 2018-07-17 06:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:24:12 --> CSRF cookie sent
INFO - 2018-07-17 06:24:12 --> CSRF token verified
INFO - 2018-07-17 06:24:12 --> Input Class Initialized
INFO - 2018-07-17 06:24:12 --> Language Class Initialized
INFO - 2018-07-17 06:24:12 --> Loader Class Initialized
INFO - 2018-07-17 06:24:12 --> Helper loaded: url_helper
INFO - 2018-07-17 06:24:12 --> Helper loaded: form_helper
INFO - 2018-07-17 06:24:12 --> Helper loaded: language_helper
DEBUG - 2018-07-17 06:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 06:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 06:24:12 --> User Agent Class Initialized
INFO - 2018-07-17 06:24:12 --> Controller Class Initialized
INFO - 2018-07-17 06:24:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 06:24:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 06:24:12 --> Pixel_Model class loaded
INFO - 2018-07-17 06:24:12 --> Database Driver Class Initialized
INFO - 2018-07-17 06:24:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 06:24:12 --> Config Class Initialized
INFO - 2018-07-17 06:24:12 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:24:12 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:24:12 --> Utf8 Class Initialized
INFO - 2018-07-17 06:24:12 --> URI Class Initialized
INFO - 2018-07-17 06:24:12 --> Router Class Initialized
INFO - 2018-07-17 06:24:12 --> Output Class Initialized
INFO - 2018-07-17 06:24:12 --> Security Class Initialized
DEBUG - 2018-07-17 06:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:24:12 --> CSRF cookie sent
INFO - 2018-07-17 06:24:12 --> Input Class Initialized
INFO - 2018-07-17 06:24:12 --> Language Class Initialized
INFO - 2018-07-17 06:24:12 --> Loader Class Initialized
INFO - 2018-07-17 06:24:12 --> Helper loaded: url_helper
INFO - 2018-07-17 06:24:12 --> Helper loaded: form_helper
INFO - 2018-07-17 06:24:12 --> Helper loaded: language_helper
DEBUG - 2018-07-17 06:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 06:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 06:24:12 --> User Agent Class Initialized
INFO - 2018-07-17 06:24:12 --> Controller Class Initialized
INFO - 2018-07-17 06:24:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 06:24:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-17 06:24:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-17 06:24:12 --> Could not find the language line "req_email"
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-17 06:24:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 06:24:12 --> Final output sent to browser
DEBUG - 2018-07-17 06:24:12 --> Total execution time: 0.0263
INFO - 2018-07-17 09:13:20 --> Config Class Initialized
INFO - 2018-07-17 09:13:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 09:13:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 09:13:20 --> Utf8 Class Initialized
INFO - 2018-07-17 09:13:20 --> URI Class Initialized
DEBUG - 2018-07-17 09:13:20 --> No URI present. Default controller set.
INFO - 2018-07-17 09:13:20 --> Router Class Initialized
INFO - 2018-07-17 09:13:20 --> Output Class Initialized
INFO - 2018-07-17 09:13:20 --> Security Class Initialized
DEBUG - 2018-07-17 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 09:13:20 --> CSRF cookie sent
INFO - 2018-07-17 09:13:20 --> Input Class Initialized
INFO - 2018-07-17 09:13:20 --> Language Class Initialized
INFO - 2018-07-17 09:13:20 --> Loader Class Initialized
INFO - 2018-07-17 09:13:20 --> Helper loaded: url_helper
INFO - 2018-07-17 09:13:20 --> Helper loaded: form_helper
INFO - 2018-07-17 09:13:20 --> Helper loaded: language_helper
DEBUG - 2018-07-17 09:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 09:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 09:13:20 --> User Agent Class Initialized
INFO - 2018-07-17 09:13:20 --> Controller Class Initialized
INFO - 2018-07-17 09:13:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 09:13:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 09:13:20 --> Pixel_Model class loaded
INFO - 2018-07-17 09:13:20 --> Database Driver Class Initialized
INFO - 2018-07-17 09:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 09:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 09:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 09:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 09:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 09:13:20 --> Final output sent to browser
DEBUG - 2018-07-17 09:13:20 --> Total execution time: 0.0388
INFO - 2018-07-17 09:57:42 --> Config Class Initialized
INFO - 2018-07-17 09:57:42 --> Hooks Class Initialized
DEBUG - 2018-07-17 09:57:42 --> UTF-8 Support Enabled
INFO - 2018-07-17 09:57:42 --> Utf8 Class Initialized
INFO - 2018-07-17 09:57:42 --> URI Class Initialized
DEBUG - 2018-07-17 09:57:42 --> No URI present. Default controller set.
INFO - 2018-07-17 09:57:42 --> Router Class Initialized
INFO - 2018-07-17 09:57:42 --> Output Class Initialized
INFO - 2018-07-17 09:57:42 --> Security Class Initialized
DEBUG - 2018-07-17 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 09:57:42 --> CSRF cookie sent
INFO - 2018-07-17 09:57:42 --> Input Class Initialized
INFO - 2018-07-17 09:57:42 --> Language Class Initialized
INFO - 2018-07-17 09:57:42 --> Loader Class Initialized
INFO - 2018-07-17 09:57:42 --> Helper loaded: url_helper
INFO - 2018-07-17 09:57:42 --> Helper loaded: form_helper
INFO - 2018-07-17 09:57:42 --> Helper loaded: language_helper
DEBUG - 2018-07-17 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 09:57:42 --> User Agent Class Initialized
INFO - 2018-07-17 09:57:42 --> Controller Class Initialized
INFO - 2018-07-17 09:57:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 09:57:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 09:57:42 --> Pixel_Model class loaded
INFO - 2018-07-17 09:57:42 --> Database Driver Class Initialized
INFO - 2018-07-17 09:57:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 09:57:42 --> Final output sent to browser
DEBUG - 2018-07-17 09:57:42 --> Total execution time: 0.0334
INFO - 2018-07-17 12:14:28 --> Config Class Initialized
INFO - 2018-07-17 12:14:28 --> Hooks Class Initialized
DEBUG - 2018-07-17 12:14:28 --> UTF-8 Support Enabled
INFO - 2018-07-17 12:14:28 --> Utf8 Class Initialized
INFO - 2018-07-17 12:14:28 --> URI Class Initialized
DEBUG - 2018-07-17 12:14:28 --> No URI present. Default controller set.
INFO - 2018-07-17 12:14:28 --> Router Class Initialized
INFO - 2018-07-17 12:14:28 --> Output Class Initialized
INFO - 2018-07-17 12:14:28 --> Security Class Initialized
DEBUG - 2018-07-17 12:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 12:14:28 --> CSRF cookie sent
INFO - 2018-07-17 12:14:28 --> Input Class Initialized
INFO - 2018-07-17 12:14:28 --> Language Class Initialized
INFO - 2018-07-17 12:14:28 --> Loader Class Initialized
INFO - 2018-07-17 12:14:28 --> Helper loaded: url_helper
INFO - 2018-07-17 12:14:28 --> Helper loaded: form_helper
INFO - 2018-07-17 12:14:28 --> Helper loaded: language_helper
DEBUG - 2018-07-17 12:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 12:14:28 --> User Agent Class Initialized
INFO - 2018-07-17 12:14:28 --> Controller Class Initialized
INFO - 2018-07-17 12:14:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 12:14:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 12:14:28 --> Pixel_Model class loaded
INFO - 2018-07-17 12:14:28 --> Database Driver Class Initialized
INFO - 2018-07-17 12:14:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 12:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 12:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 12:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 12:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 12:14:28 --> Final output sent to browser
DEBUG - 2018-07-17 12:14:28 --> Total execution time: 0.0311
INFO - 2018-07-17 16:34:28 --> Config Class Initialized
INFO - 2018-07-17 16:34:28 --> Hooks Class Initialized
DEBUG - 2018-07-17 16:34:28 --> UTF-8 Support Enabled
INFO - 2018-07-17 16:34:28 --> Utf8 Class Initialized
INFO - 2018-07-17 16:34:28 --> URI Class Initialized
INFO - 2018-07-17 16:34:28 --> Router Class Initialized
INFO - 2018-07-17 16:34:28 --> Output Class Initialized
INFO - 2018-07-17 16:34:28 --> Security Class Initialized
DEBUG - 2018-07-17 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 16:34:28 --> CSRF cookie sent
INFO - 2018-07-17 16:34:28 --> Input Class Initialized
INFO - 2018-07-17 16:34:28 --> Language Class Initialized
ERROR - 2018-07-17 16:34:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 16:34:28 --> Config Class Initialized
INFO - 2018-07-17 16:34:28 --> Hooks Class Initialized
DEBUG - 2018-07-17 16:34:28 --> UTF-8 Support Enabled
INFO - 2018-07-17 16:34:28 --> Utf8 Class Initialized
INFO - 2018-07-17 16:34:28 --> URI Class Initialized
INFO - 2018-07-17 16:34:28 --> Router Class Initialized
INFO - 2018-07-17 16:34:28 --> Output Class Initialized
INFO - 2018-07-17 16:34:28 --> Security Class Initialized
DEBUG - 2018-07-17 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 16:34:28 --> CSRF cookie sent
INFO - 2018-07-17 16:34:28 --> Input Class Initialized
INFO - 2018-07-17 16:34:28 --> Language Class Initialized
INFO - 2018-07-17 16:34:28 --> Loader Class Initialized
INFO - 2018-07-17 16:34:28 --> Helper loaded: url_helper
INFO - 2018-07-17 16:34:28 --> Helper loaded: form_helper
INFO - 2018-07-17 16:34:28 --> Helper loaded: language_helper
DEBUG - 2018-07-17 16:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 16:34:28 --> User Agent Class Initialized
INFO - 2018-07-17 16:34:28 --> Controller Class Initialized
INFO - 2018-07-17 16:34:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 16:34:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-17 16:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 16:34:28 --> Final output sent to browser
DEBUG - 2018-07-17 16:34:28 --> Total execution time: 0.0222
INFO - 2018-07-17 17:10:38 --> Config Class Initialized
INFO - 2018-07-17 17:10:38 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:10:38 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:10:38 --> Utf8 Class Initialized
INFO - 2018-07-17 17:10:38 --> URI Class Initialized
INFO - 2018-07-17 17:10:38 --> Router Class Initialized
INFO - 2018-07-17 17:10:38 --> Output Class Initialized
INFO - 2018-07-17 17:10:38 --> Security Class Initialized
DEBUG - 2018-07-17 17:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:10:38 --> CSRF cookie sent
INFO - 2018-07-17 17:10:38 --> Input Class Initialized
INFO - 2018-07-17 17:10:38 --> Language Class Initialized
ERROR - 2018-07-17 17:10:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 17:18:25 --> Config Class Initialized
INFO - 2018-07-17 17:18:25 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:18:25 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:18:25 --> Utf8 Class Initialized
INFO - 2018-07-17 17:18:25 --> URI Class Initialized
DEBUG - 2018-07-17 17:18:25 --> No URI present. Default controller set.
INFO - 2018-07-17 17:18:25 --> Router Class Initialized
INFO - 2018-07-17 17:18:25 --> Output Class Initialized
INFO - 2018-07-17 17:18:25 --> Security Class Initialized
DEBUG - 2018-07-17 17:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:18:25 --> CSRF cookie sent
INFO - 2018-07-17 17:18:25 --> Input Class Initialized
INFO - 2018-07-17 17:18:25 --> Language Class Initialized
INFO - 2018-07-17 17:18:25 --> Loader Class Initialized
INFO - 2018-07-17 17:18:25 --> Helper loaded: url_helper
INFO - 2018-07-17 17:18:25 --> Helper loaded: form_helper
INFO - 2018-07-17 17:18:25 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:18:25 --> User Agent Class Initialized
INFO - 2018-07-17 17:18:25 --> Controller Class Initialized
INFO - 2018-07-17 17:18:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:18:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:18:25 --> Pixel_Model class loaded
INFO - 2018-07-17 17:18:25 --> Database Driver Class Initialized
INFO - 2018-07-17 17:18:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:18:25 --> Final output sent to browser
DEBUG - 2018-07-17 17:18:25 --> Total execution time: 0.2549
INFO - 2018-07-17 17:24:31 --> Config Class Initialized
INFO - 2018-07-17 17:24:31 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:31 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:31 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:31 --> URI Class Initialized
DEBUG - 2018-07-17 17:24:31 --> No URI present. Default controller set.
INFO - 2018-07-17 17:24:31 --> Router Class Initialized
INFO - 2018-07-17 17:24:31 --> Output Class Initialized
INFO - 2018-07-17 17:24:31 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:31 --> CSRF cookie sent
INFO - 2018-07-17 17:24:31 --> Input Class Initialized
INFO - 2018-07-17 17:24:31 --> Language Class Initialized
INFO - 2018-07-17 17:24:31 --> Loader Class Initialized
INFO - 2018-07-17 17:24:31 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:31 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:31 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:31 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:31 --> Controller Class Initialized
INFO - 2018-07-17 17:24:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:31 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:31 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:32 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:32 --> Total execution time: 0.5245
INFO - 2018-07-17 17:24:33 --> Config Class Initialized
INFO - 2018-07-17 17:24:33 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:33 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:33 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:33 --> URI Class Initialized
DEBUG - 2018-07-17 17:24:33 --> No URI present. Default controller set.
INFO - 2018-07-17 17:24:33 --> Router Class Initialized
INFO - 2018-07-17 17:24:33 --> Output Class Initialized
INFO - 2018-07-17 17:24:33 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:33 --> CSRF cookie sent
INFO - 2018-07-17 17:24:33 --> Input Class Initialized
INFO - 2018-07-17 17:24:33 --> Language Class Initialized
INFO - 2018-07-17 17:24:33 --> Loader Class Initialized
INFO - 2018-07-17 17:24:33 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:33 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:33 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:33 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:33 --> Controller Class Initialized
INFO - 2018-07-17 17:24:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:33 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:33 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:33 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:33 --> Total execution time: 0.0337
INFO - 2018-07-17 17:24:33 --> Config Class Initialized
INFO - 2018-07-17 17:24:33 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:33 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:33 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:33 --> URI Class Initialized
DEBUG - 2018-07-17 17:24:33 --> No URI present. Default controller set.
INFO - 2018-07-17 17:24:33 --> Router Class Initialized
INFO - 2018-07-17 17:24:33 --> Output Class Initialized
INFO - 2018-07-17 17:24:33 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:33 --> CSRF cookie sent
INFO - 2018-07-17 17:24:33 --> Input Class Initialized
INFO - 2018-07-17 17:24:33 --> Language Class Initialized
INFO - 2018-07-17 17:24:33 --> Loader Class Initialized
INFO - 2018-07-17 17:24:33 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:33 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:33 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:33 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:33 --> Controller Class Initialized
INFO - 2018-07-17 17:24:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:33 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:33 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:24:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:33 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:33 --> Total execution time: 0.0353
INFO - 2018-07-17 17:24:34 --> Config Class Initialized
INFO - 2018-07-17 17:24:34 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:34 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:34 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:34 --> URI Class Initialized
INFO - 2018-07-17 17:24:34 --> Router Class Initialized
INFO - 2018-07-17 17:24:34 --> Output Class Initialized
INFO - 2018-07-17 17:24:34 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:34 --> CSRF cookie sent
INFO - 2018-07-17 17:24:34 --> Input Class Initialized
INFO - 2018-07-17 17:24:34 --> Language Class Initialized
ERROR - 2018-07-17 17:24:34 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-17 17:24:43 --> Config Class Initialized
INFO - 2018-07-17 17:24:43 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:43 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:43 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:43 --> URI Class Initialized
DEBUG - 2018-07-17 17:24:43 --> No URI present. Default controller set.
INFO - 2018-07-17 17:24:43 --> Router Class Initialized
INFO - 2018-07-17 17:24:43 --> Output Class Initialized
INFO - 2018-07-17 17:24:43 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:43 --> CSRF cookie sent
INFO - 2018-07-17 17:24:43 --> Input Class Initialized
INFO - 2018-07-17 17:24:43 --> Language Class Initialized
INFO - 2018-07-17 17:24:43 --> Loader Class Initialized
INFO - 2018-07-17 17:24:43 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:43 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:43 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:43 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:43 --> Controller Class Initialized
INFO - 2018-07-17 17:24:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:43 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:43 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:24:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:43 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:43 --> Total execution time: 0.0365
INFO - 2018-07-17 17:24:43 --> Config Class Initialized
INFO - 2018-07-17 17:24:43 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:43 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:43 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:43 --> URI Class Initialized
INFO - 2018-07-17 17:24:43 --> Router Class Initialized
INFO - 2018-07-17 17:24:43 --> Output Class Initialized
INFO - 2018-07-17 17:24:43 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:43 --> CSRF cookie sent
INFO - 2018-07-17 17:24:43 --> Input Class Initialized
INFO - 2018-07-17 17:24:43 --> Language Class Initialized
ERROR - 2018-07-17 17:24:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-17 17:24:44 --> Config Class Initialized
INFO - 2018-07-17 17:24:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:44 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:44 --> URI Class Initialized
INFO - 2018-07-17 17:24:44 --> Router Class Initialized
INFO - 2018-07-17 17:24:44 --> Output Class Initialized
INFO - 2018-07-17 17:24:44 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:44 --> CSRF cookie sent
INFO - 2018-07-17 17:24:44 --> Input Class Initialized
INFO - 2018-07-17 17:24:44 --> Language Class Initialized
ERROR - 2018-07-17 17:24:44 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-17 17:24:44 --> Config Class Initialized
INFO - 2018-07-17 17:24:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:44 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:44 --> URI Class Initialized
INFO - 2018-07-17 17:24:44 --> Router Class Initialized
INFO - 2018-07-17 17:24:44 --> Output Class Initialized
INFO - 2018-07-17 17:24:44 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:44 --> CSRF cookie sent
INFO - 2018-07-17 17:24:44 --> Input Class Initialized
INFO - 2018-07-17 17:24:44 --> Language Class Initialized
INFO - 2018-07-17 17:24:44 --> Loader Class Initialized
INFO - 2018-07-17 17:24:44 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:44 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:44 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:44 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:44 --> Controller Class Initialized
INFO - 2018-07-17 17:24:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:44 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:44 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:44 --> Config Class Initialized
INFO - 2018-07-17 17:24:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:44 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:44 --> URI Class Initialized
INFO - 2018-07-17 17:24:44 --> Router Class Initialized
INFO - 2018-07-17 17:24:44 --> Output Class Initialized
INFO - 2018-07-17 17:24:44 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:44 --> CSRF cookie sent
INFO - 2018-07-17 17:24:44 --> Input Class Initialized
INFO - 2018-07-17 17:24:44 --> Language Class Initialized
INFO - 2018-07-17 17:24:44 --> Loader Class Initialized
INFO - 2018-07-17 17:24:44 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:44 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:44 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:44 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:44 --> Controller Class Initialized
INFO - 2018-07-17 17:24:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-17 17:24:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-17 17:24:44 --> Could not find the language line "req_email"
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-17 17:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:44 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:44 --> Total execution time: 0.0859
INFO - 2018-07-17 17:24:45 --> Config Class Initialized
INFO - 2018-07-17 17:24:45 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:45 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:45 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:45 --> URI Class Initialized
INFO - 2018-07-17 17:24:45 --> Router Class Initialized
INFO - 2018-07-17 17:24:45 --> Output Class Initialized
INFO - 2018-07-17 17:24:45 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:45 --> CSRF cookie sent
INFO - 2018-07-17 17:24:45 --> Input Class Initialized
INFO - 2018-07-17 17:24:45 --> Language Class Initialized
INFO - 2018-07-17 17:24:45 --> Loader Class Initialized
INFO - 2018-07-17 17:24:45 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:45 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:45 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:45 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:45 --> Controller Class Initialized
INFO - 2018-07-17 17:24:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:45 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:45 --> Total execution time: 0.1420
INFO - 2018-07-17 17:24:45 --> Config Class Initialized
INFO - 2018-07-17 17:24:45 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:45 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:45 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:45 --> URI Class Initialized
INFO - 2018-07-17 17:24:45 --> Router Class Initialized
INFO - 2018-07-17 17:24:45 --> Output Class Initialized
INFO - 2018-07-17 17:24:45 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:45 --> CSRF cookie sent
INFO - 2018-07-17 17:24:45 --> Input Class Initialized
INFO - 2018-07-17 17:24:45 --> Language Class Initialized
INFO - 2018-07-17 17:24:45 --> Loader Class Initialized
INFO - 2018-07-17 17:24:45 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:45 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:45 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:45 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:45 --> Controller Class Initialized
INFO - 2018-07-17 17:24:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-17 17:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:45 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:45 --> Total execution time: 0.0321
INFO - 2018-07-17 17:24:46 --> Config Class Initialized
INFO - 2018-07-17 17:24:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:46 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:46 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:46 --> URI Class Initialized
INFO - 2018-07-17 17:24:46 --> Router Class Initialized
INFO - 2018-07-17 17:24:46 --> Output Class Initialized
INFO - 2018-07-17 17:24:46 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:46 --> CSRF cookie sent
INFO - 2018-07-17 17:24:46 --> Input Class Initialized
INFO - 2018-07-17 17:24:46 --> Language Class Initialized
INFO - 2018-07-17 17:24:46 --> Loader Class Initialized
INFO - 2018-07-17 17:24:46 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:46 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:46 --> Controller Class Initialized
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:46 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:46 --> Total execution time: 0.0343
INFO - 2018-07-17 17:24:46 --> Config Class Initialized
INFO - 2018-07-17 17:24:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:46 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:46 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:46 --> URI Class Initialized
INFO - 2018-07-17 17:24:46 --> Router Class Initialized
INFO - 2018-07-17 17:24:46 --> Output Class Initialized
INFO - 2018-07-17 17:24:46 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:46 --> CSRF cookie sent
INFO - 2018-07-17 17:24:46 --> Input Class Initialized
INFO - 2018-07-17 17:24:46 --> Language Class Initialized
INFO - 2018-07-17 17:24:46 --> Loader Class Initialized
INFO - 2018-07-17 17:24:46 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:46 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:46 --> Controller Class Initialized
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:46 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:46 --> Total execution time: 0.0514
INFO - 2018-07-17 17:24:46 --> Config Class Initialized
INFO - 2018-07-17 17:24:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:46 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:46 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:46 --> URI Class Initialized
INFO - 2018-07-17 17:24:46 --> Router Class Initialized
INFO - 2018-07-17 17:24:46 --> Output Class Initialized
INFO - 2018-07-17 17:24:46 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:46 --> CSRF cookie sent
INFO - 2018-07-17 17:24:46 --> Input Class Initialized
INFO - 2018-07-17 17:24:46 --> Language Class Initialized
INFO - 2018-07-17 17:24:46 --> Loader Class Initialized
INFO - 2018-07-17 17:24:46 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:46 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:46 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:46 --> Controller Class Initialized
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-17 17:24:46 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-17 17:24:46 --> Could not find the language line "req_email"
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-17 17:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:46 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:46 --> Total execution time: 0.0218
INFO - 2018-07-17 17:24:47 --> Config Class Initialized
INFO - 2018-07-17 17:24:47 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:24:47 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:24:47 --> Utf8 Class Initialized
INFO - 2018-07-17 17:24:47 --> URI Class Initialized
INFO - 2018-07-17 17:24:47 --> Router Class Initialized
INFO - 2018-07-17 17:24:47 --> Output Class Initialized
INFO - 2018-07-17 17:24:47 --> Security Class Initialized
DEBUG - 2018-07-17 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:24:47 --> CSRF cookie sent
INFO - 2018-07-17 17:24:47 --> Input Class Initialized
INFO - 2018-07-17 17:24:47 --> Language Class Initialized
INFO - 2018-07-17 17:24:47 --> Loader Class Initialized
INFO - 2018-07-17 17:24:47 --> Helper loaded: url_helper
INFO - 2018-07-17 17:24:47 --> Helper loaded: form_helper
INFO - 2018-07-17 17:24:47 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:24:47 --> User Agent Class Initialized
INFO - 2018-07-17 17:24:47 --> Controller Class Initialized
INFO - 2018-07-17 17:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:24:47 --> Pixel_Model class loaded
INFO - 2018-07-17 17:24:47 --> Database Driver Class Initialized
INFO - 2018-07-17 17:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-17 17:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:24:47 --> Final output sent to browser
DEBUG - 2018-07-17 17:24:47 --> Total execution time: 0.1572
INFO - 2018-07-17 17:44:30 --> Config Class Initialized
INFO - 2018-07-17 17:44:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:44:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:44:30 --> Utf8 Class Initialized
INFO - 2018-07-17 17:44:30 --> URI Class Initialized
INFO - 2018-07-17 17:44:30 --> Router Class Initialized
INFO - 2018-07-17 17:44:30 --> Output Class Initialized
INFO - 2018-07-17 17:44:30 --> Security Class Initialized
DEBUG - 2018-07-17 17:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:44:30 --> CSRF cookie sent
INFO - 2018-07-17 17:44:30 --> Input Class Initialized
INFO - 2018-07-17 17:44:30 --> Language Class Initialized
ERROR - 2018-07-17 17:44:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 17:52:50 --> Config Class Initialized
INFO - 2018-07-17 17:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 17:52:50 --> Utf8 Class Initialized
INFO - 2018-07-17 17:52:50 --> URI Class Initialized
DEBUG - 2018-07-17 17:52:50 --> No URI present. Default controller set.
INFO - 2018-07-17 17:52:50 --> Router Class Initialized
INFO - 2018-07-17 17:52:50 --> Output Class Initialized
INFO - 2018-07-17 17:52:50 --> Security Class Initialized
DEBUG - 2018-07-17 17:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 17:52:50 --> CSRF cookie sent
INFO - 2018-07-17 17:52:50 --> Input Class Initialized
INFO - 2018-07-17 17:52:50 --> Language Class Initialized
INFO - 2018-07-17 17:52:50 --> Loader Class Initialized
INFO - 2018-07-17 17:52:50 --> Helper loaded: url_helper
INFO - 2018-07-17 17:52:50 --> Helper loaded: form_helper
INFO - 2018-07-17 17:52:50 --> Helper loaded: language_helper
DEBUG - 2018-07-17 17:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 17:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 17:52:50 --> User Agent Class Initialized
INFO - 2018-07-17 17:52:50 --> Controller Class Initialized
INFO - 2018-07-17 17:52:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 17:52:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 17:52:50 --> Pixel_Model class loaded
INFO - 2018-07-17 17:52:50 --> Database Driver Class Initialized
INFO - 2018-07-17 17:52:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 17:52:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 17:52:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 17:52:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 17:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 17:52:51 --> Final output sent to browser
DEBUG - 2018-07-17 17:52:51 --> Total execution time: 0.2902
INFO - 2018-07-17 18:54:48 --> Config Class Initialized
INFO - 2018-07-17 18:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-17 18:54:49 --> UTF-8 Support Enabled
INFO - 2018-07-17 18:54:49 --> Utf8 Class Initialized
INFO - 2018-07-17 18:54:49 --> URI Class Initialized
DEBUG - 2018-07-17 18:54:49 --> No URI present. Default controller set.
INFO - 2018-07-17 18:54:49 --> Router Class Initialized
INFO - 2018-07-17 18:54:49 --> Output Class Initialized
INFO - 2018-07-17 18:54:49 --> Security Class Initialized
DEBUG - 2018-07-17 18:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 18:54:49 --> CSRF cookie sent
INFO - 2018-07-17 18:54:49 --> Input Class Initialized
INFO - 2018-07-17 18:54:49 --> Language Class Initialized
INFO - 2018-07-17 18:54:49 --> Loader Class Initialized
INFO - 2018-07-17 18:54:49 --> Helper loaded: url_helper
INFO - 2018-07-17 18:54:49 --> Helper loaded: form_helper
INFO - 2018-07-17 18:54:49 --> Helper loaded: language_helper
DEBUG - 2018-07-17 18:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 18:54:49 --> User Agent Class Initialized
INFO - 2018-07-17 18:54:49 --> Controller Class Initialized
INFO - 2018-07-17 18:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 18:54:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 18:54:49 --> Pixel_Model class loaded
INFO - 2018-07-17 18:54:49 --> Database Driver Class Initialized
INFO - 2018-07-17 18:54:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 18:54:49 --> Final output sent to browser
DEBUG - 2018-07-17 18:54:49 --> Total execution time: 0.3653
INFO - 2018-07-17 19:12:24 --> Config Class Initialized
INFO - 2018-07-17 19:12:24 --> Hooks Class Initialized
DEBUG - 2018-07-17 19:12:24 --> UTF-8 Support Enabled
INFO - 2018-07-17 19:12:24 --> Utf8 Class Initialized
INFO - 2018-07-17 19:12:24 --> URI Class Initialized
INFO - 2018-07-17 19:12:24 --> Router Class Initialized
INFO - 2018-07-17 19:12:24 --> Output Class Initialized
INFO - 2018-07-17 19:12:24 --> Security Class Initialized
DEBUG - 2018-07-17 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 19:12:24 --> CSRF cookie sent
INFO - 2018-07-17 19:12:24 --> Input Class Initialized
INFO - 2018-07-17 19:12:24 --> Language Class Initialized
ERROR - 2018-07-17 19:12:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 19:12:24 --> Config Class Initialized
INFO - 2018-07-17 19:12:24 --> Hooks Class Initialized
DEBUG - 2018-07-17 19:12:24 --> UTF-8 Support Enabled
INFO - 2018-07-17 19:12:24 --> Utf8 Class Initialized
INFO - 2018-07-17 19:12:24 --> URI Class Initialized
DEBUG - 2018-07-17 19:12:24 --> No URI present. Default controller set.
INFO - 2018-07-17 19:12:24 --> Router Class Initialized
INFO - 2018-07-17 19:12:24 --> Output Class Initialized
INFO - 2018-07-17 19:12:24 --> Security Class Initialized
DEBUG - 2018-07-17 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 19:12:24 --> CSRF cookie sent
INFO - 2018-07-17 19:12:24 --> Input Class Initialized
INFO - 2018-07-17 19:12:24 --> Language Class Initialized
INFO - 2018-07-17 19:12:24 --> Loader Class Initialized
INFO - 2018-07-17 19:12:24 --> Helper loaded: url_helper
INFO - 2018-07-17 19:12:24 --> Helper loaded: form_helper
INFO - 2018-07-17 19:12:24 --> Helper loaded: language_helper
DEBUG - 2018-07-17 19:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 19:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 19:12:24 --> User Agent Class Initialized
INFO - 2018-07-17 19:12:24 --> Controller Class Initialized
INFO - 2018-07-17 19:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 19:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 19:12:24 --> Pixel_Model class loaded
INFO - 2018-07-17 19:12:24 --> Database Driver Class Initialized
INFO - 2018-07-17 19:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 19:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 19:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 19:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 19:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 19:12:24 --> Final output sent to browser
DEBUG - 2018-07-17 19:12:24 --> Total execution time: 0.0445
INFO - 2018-07-17 19:42:19 --> Config Class Initialized
INFO - 2018-07-17 19:42:19 --> Hooks Class Initialized
DEBUG - 2018-07-17 19:42:19 --> UTF-8 Support Enabled
INFO - 2018-07-17 19:42:19 --> Utf8 Class Initialized
INFO - 2018-07-17 19:42:19 --> URI Class Initialized
DEBUG - 2018-07-17 19:42:19 --> No URI present. Default controller set.
INFO - 2018-07-17 19:42:19 --> Router Class Initialized
INFO - 2018-07-17 19:42:19 --> Output Class Initialized
INFO - 2018-07-17 19:42:19 --> Security Class Initialized
DEBUG - 2018-07-17 19:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 19:42:19 --> CSRF cookie sent
INFO - 2018-07-17 19:42:19 --> Input Class Initialized
INFO - 2018-07-17 19:42:19 --> Language Class Initialized
INFO - 2018-07-17 19:42:19 --> Loader Class Initialized
INFO - 2018-07-17 19:42:19 --> Helper loaded: url_helper
INFO - 2018-07-17 19:42:19 --> Helper loaded: form_helper
INFO - 2018-07-17 19:42:19 --> Helper loaded: language_helper
DEBUG - 2018-07-17 19:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 19:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 19:42:19 --> User Agent Class Initialized
INFO - 2018-07-17 19:42:19 --> Controller Class Initialized
INFO - 2018-07-17 19:42:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 19:42:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 19:42:19 --> Pixel_Model class loaded
INFO - 2018-07-17 19:42:19 --> Database Driver Class Initialized
INFO - 2018-07-17 19:42:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 19:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 19:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 19:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 19:42:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 19:42:19 --> Final output sent to browser
DEBUG - 2018-07-17 19:42:19 --> Total execution time: 0.0427
INFO - 2018-07-17 20:22:58 --> Config Class Initialized
INFO - 2018-07-17 20:22:58 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:22:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 20:22:58 --> Utf8 Class Initialized
INFO - 2018-07-17 20:22:58 --> URI Class Initialized
DEBUG - 2018-07-17 20:22:58 --> No URI present. Default controller set.
INFO - 2018-07-17 20:22:58 --> Router Class Initialized
INFO - 2018-07-17 20:22:58 --> Output Class Initialized
INFO - 2018-07-17 20:22:58 --> Security Class Initialized
DEBUG - 2018-07-17 20:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 20:22:58 --> CSRF cookie sent
INFO - 2018-07-17 20:22:58 --> Input Class Initialized
INFO - 2018-07-17 20:22:58 --> Language Class Initialized
INFO - 2018-07-17 20:22:58 --> Loader Class Initialized
INFO - 2018-07-17 20:22:58 --> Helper loaded: url_helper
INFO - 2018-07-17 20:22:58 --> Helper loaded: form_helper
INFO - 2018-07-17 20:22:58 --> Helper loaded: language_helper
DEBUG - 2018-07-17 20:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 20:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 20:22:58 --> User Agent Class Initialized
INFO - 2018-07-17 20:22:58 --> Controller Class Initialized
INFO - 2018-07-17 20:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 20:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 20:22:58 --> Pixel_Model class loaded
INFO - 2018-07-17 20:22:58 --> Database Driver Class Initialized
INFO - 2018-07-17 20:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 20:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 20:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 20:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 20:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 20:22:58 --> Final output sent to browser
DEBUG - 2018-07-17 20:22:58 --> Total execution time: 0.0422
INFO - 2018-07-17 22:14:59 --> Config Class Initialized
INFO - 2018-07-17 22:14:59 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:14:59 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:14:59 --> Utf8 Class Initialized
INFO - 2018-07-17 22:14:59 --> URI Class Initialized
DEBUG - 2018-07-17 22:14:59 --> No URI present. Default controller set.
INFO - 2018-07-17 22:14:59 --> Router Class Initialized
INFO - 2018-07-17 22:14:59 --> Output Class Initialized
INFO - 2018-07-17 22:14:59 --> Security Class Initialized
DEBUG - 2018-07-17 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:14:59 --> CSRF cookie sent
INFO - 2018-07-17 22:14:59 --> Input Class Initialized
INFO - 2018-07-17 22:14:59 --> Language Class Initialized
INFO - 2018-07-17 22:14:59 --> Loader Class Initialized
INFO - 2018-07-17 22:14:59 --> Helper loaded: url_helper
INFO - 2018-07-17 22:14:59 --> Helper loaded: form_helper
INFO - 2018-07-17 22:14:59 --> Helper loaded: language_helper
DEBUG - 2018-07-17 22:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 22:14:59 --> User Agent Class Initialized
INFO - 2018-07-17 22:14:59 --> Controller Class Initialized
INFO - 2018-07-17 22:14:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 22:14:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 22:14:59 --> Pixel_Model class loaded
INFO - 2018-07-17 22:14:59 --> Database Driver Class Initialized
INFO - 2018-07-17 22:14:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 22:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 22:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 22:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 22:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 22:14:59 --> Final output sent to browser
DEBUG - 2018-07-17 22:14:59 --> Total execution time: 0.0340
INFO - 2018-07-17 22:53:56 --> Config Class Initialized
INFO - 2018-07-17 22:53:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:53:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:53:56 --> Utf8 Class Initialized
INFO - 2018-07-17 22:53:56 --> URI Class Initialized
INFO - 2018-07-17 22:53:56 --> Router Class Initialized
INFO - 2018-07-17 22:53:56 --> Output Class Initialized
INFO - 2018-07-17 22:53:56 --> Security Class Initialized
DEBUG - 2018-07-17 22:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:53:56 --> CSRF cookie sent
INFO - 2018-07-17 22:53:56 --> Input Class Initialized
INFO - 2018-07-17 22:53:56 --> Language Class Initialized
ERROR - 2018-07-17 22:53:56 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-17 22:53:59 --> Config Class Initialized
INFO - 2018-07-17 22:53:59 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:53:59 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:53:59 --> Utf8 Class Initialized
INFO - 2018-07-17 22:53:59 --> URI Class Initialized
DEBUG - 2018-07-17 22:53:59 --> No URI present. Default controller set.
INFO - 2018-07-17 22:53:59 --> Router Class Initialized
INFO - 2018-07-17 22:53:59 --> Output Class Initialized
INFO - 2018-07-17 22:53:59 --> Security Class Initialized
DEBUG - 2018-07-17 22:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:53:59 --> CSRF cookie sent
INFO - 2018-07-17 22:53:59 --> Input Class Initialized
INFO - 2018-07-17 22:53:59 --> Language Class Initialized
INFO - 2018-07-17 22:53:59 --> Loader Class Initialized
INFO - 2018-07-17 22:53:59 --> Helper loaded: url_helper
INFO - 2018-07-17 22:53:59 --> Helper loaded: form_helper
INFO - 2018-07-17 22:53:59 --> Helper loaded: language_helper
DEBUG - 2018-07-17 22:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 22:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 22:53:59 --> User Agent Class Initialized
INFO - 2018-07-17 22:53:59 --> Controller Class Initialized
INFO - 2018-07-17 22:53:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 22:53:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 22:53:59 --> Pixel_Model class loaded
INFO - 2018-07-17 22:53:59 --> Database Driver Class Initialized
INFO - 2018-07-17 22:53:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-17 22:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 22:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 22:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-17 22:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 22:53:59 --> Final output sent to browser
DEBUG - 2018-07-17 22:53:59 --> Total execution time: 0.0373
INFO - 2018-07-17 23:58:44 --> Config Class Initialized
INFO - 2018-07-17 23:58:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 23:58:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 23:58:44 --> Utf8 Class Initialized
INFO - 2018-07-17 23:58:44 --> URI Class Initialized
INFO - 2018-07-17 23:58:44 --> Router Class Initialized
INFO - 2018-07-17 23:58:44 --> Output Class Initialized
INFO - 2018-07-17 23:58:44 --> Security Class Initialized
DEBUG - 2018-07-17 23:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 23:58:44 --> CSRF cookie sent
INFO - 2018-07-17 23:58:44 --> Input Class Initialized
INFO - 2018-07-17 23:58:44 --> Language Class Initialized
INFO - 2018-07-17 23:58:44 --> Loader Class Initialized
INFO - 2018-07-17 23:58:44 --> Helper loaded: url_helper
INFO - 2018-07-17 23:58:44 --> Helper loaded: form_helper
INFO - 2018-07-17 23:58:44 --> Helper loaded: language_helper
DEBUG - 2018-07-17 23:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 23:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 23:58:44 --> User Agent Class Initialized
INFO - 2018-07-17 23:58:44 --> Controller Class Initialized
INFO - 2018-07-17 23:58:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-17 23:58:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-17 23:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-17 23:58:44 --> Final output sent to browser
DEBUG - 2018-07-17 23:58:44 --> Total execution time: 0.0555

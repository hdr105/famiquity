<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-20 00:17:09 --> Config Class Initialized
INFO - 2018-07-20 00:17:09 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:17:09 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:17:09 --> Utf8 Class Initialized
INFO - 2018-07-20 00:17:09 --> URI Class Initialized
INFO - 2018-07-20 00:17:09 --> Router Class Initialized
INFO - 2018-07-20 00:17:09 --> Output Class Initialized
INFO - 2018-07-20 00:17:09 --> Security Class Initialized
DEBUG - 2018-07-20 00:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:17:09 --> CSRF cookie sent
INFO - 2018-07-20 00:17:09 --> Input Class Initialized
INFO - 2018-07-20 00:17:09 --> Language Class Initialized
ERROR - 2018-07-20 00:17:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 00:17:12 --> Config Class Initialized
INFO - 2018-07-20 00:17:12 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:17:12 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:17:12 --> Utf8 Class Initialized
INFO - 2018-07-20 00:17:12 --> URI Class Initialized
INFO - 2018-07-20 00:17:12 --> Router Class Initialized
INFO - 2018-07-20 00:17:12 --> Output Class Initialized
INFO - 2018-07-20 00:17:12 --> Security Class Initialized
DEBUG - 2018-07-20 00:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:17:12 --> CSRF cookie sent
INFO - 2018-07-20 00:17:12 --> Input Class Initialized
INFO - 2018-07-20 00:17:12 --> Language Class Initialized
INFO - 2018-07-20 00:17:12 --> Loader Class Initialized
INFO - 2018-07-20 00:17:12 --> Helper loaded: url_helper
INFO - 2018-07-20 00:17:12 --> Helper loaded: form_helper
INFO - 2018-07-20 00:17:12 --> Helper loaded: language_helper
DEBUG - 2018-07-20 00:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:17:12 --> User Agent Class Initialized
INFO - 2018-07-20 00:17:12 --> Controller Class Initialized
INFO - 2018-07-20 00:17:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 00:17:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-20 00:17:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 00:17:12 --> Final output sent to browser
DEBUG - 2018-07-20 00:17:12 --> Total execution time: 0.0238
INFO - 2018-07-20 00:25:17 --> Config Class Initialized
INFO - 2018-07-20 00:25:17 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:25:17 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:25:17 --> Utf8 Class Initialized
INFO - 2018-07-20 00:25:17 --> URI Class Initialized
DEBUG - 2018-07-20 00:25:17 --> No URI present. Default controller set.
INFO - 2018-07-20 00:25:17 --> Router Class Initialized
INFO - 2018-07-20 00:25:17 --> Output Class Initialized
INFO - 2018-07-20 00:25:17 --> Security Class Initialized
DEBUG - 2018-07-20 00:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:25:17 --> CSRF cookie sent
INFO - 2018-07-20 00:25:17 --> Input Class Initialized
INFO - 2018-07-20 00:25:17 --> Language Class Initialized
INFO - 2018-07-20 00:25:17 --> Loader Class Initialized
INFO - 2018-07-20 00:25:17 --> Helper loaded: url_helper
INFO - 2018-07-20 00:25:17 --> Helper loaded: form_helper
INFO - 2018-07-20 00:25:17 --> Helper loaded: language_helper
DEBUG - 2018-07-20 00:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:25:17 --> User Agent Class Initialized
INFO - 2018-07-20 00:25:17 --> Controller Class Initialized
INFO - 2018-07-20 00:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 00:25:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 00:25:17 --> Pixel_Model class loaded
INFO - 2018-07-20 00:25:17 --> Database Driver Class Initialized
INFO - 2018-07-20 00:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 00:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 00:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 00:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 00:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 00:25:17 --> Final output sent to browser
DEBUG - 2018-07-20 00:25:17 --> Total execution time: 0.0333
INFO - 2018-07-20 01:52:07 --> Config Class Initialized
INFO - 2018-07-20 01:52:07 --> Hooks Class Initialized
DEBUG - 2018-07-20 01:52:07 --> UTF-8 Support Enabled
INFO - 2018-07-20 01:52:07 --> Utf8 Class Initialized
INFO - 2018-07-20 01:52:07 --> URI Class Initialized
DEBUG - 2018-07-20 01:52:07 --> No URI present. Default controller set.
INFO - 2018-07-20 01:52:07 --> Router Class Initialized
INFO - 2018-07-20 01:52:07 --> Output Class Initialized
INFO - 2018-07-20 01:52:07 --> Security Class Initialized
DEBUG - 2018-07-20 01:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 01:52:07 --> CSRF cookie sent
INFO - 2018-07-20 01:52:07 --> Input Class Initialized
INFO - 2018-07-20 01:52:07 --> Language Class Initialized
INFO - 2018-07-20 01:52:07 --> Loader Class Initialized
INFO - 2018-07-20 01:52:07 --> Helper loaded: url_helper
INFO - 2018-07-20 01:52:07 --> Helper loaded: form_helper
INFO - 2018-07-20 01:52:07 --> Helper loaded: language_helper
DEBUG - 2018-07-20 01:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 01:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 01:52:07 --> User Agent Class Initialized
INFO - 2018-07-20 01:52:07 --> Controller Class Initialized
INFO - 2018-07-20 01:52:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 01:52:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 01:52:07 --> Pixel_Model class loaded
INFO - 2018-07-20 01:52:07 --> Database Driver Class Initialized
INFO - 2018-07-20 01:52:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 01:52:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 01:52:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 01:52:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 01:52:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 01:52:07 --> Final output sent to browser
DEBUG - 2018-07-20 01:52:07 --> Total execution time: 0.0341
INFO - 2018-07-20 03:02:18 --> Config Class Initialized
INFO - 2018-07-20 03:02:18 --> Hooks Class Initialized
DEBUG - 2018-07-20 03:02:18 --> UTF-8 Support Enabled
INFO - 2018-07-20 03:02:18 --> Utf8 Class Initialized
INFO - 2018-07-20 03:02:18 --> URI Class Initialized
INFO - 2018-07-20 03:02:18 --> Router Class Initialized
INFO - 2018-07-20 03:02:18 --> Output Class Initialized
INFO - 2018-07-20 03:02:18 --> Security Class Initialized
DEBUG - 2018-07-20 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 03:02:18 --> CSRF cookie sent
INFO - 2018-07-20 03:02:18 --> Input Class Initialized
INFO - 2018-07-20 03:02:18 --> Language Class Initialized
ERROR - 2018-07-20 03:02:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 03:07:46 --> Config Class Initialized
INFO - 2018-07-20 03:07:46 --> Hooks Class Initialized
DEBUG - 2018-07-20 03:07:46 --> UTF-8 Support Enabled
INFO - 2018-07-20 03:07:46 --> Utf8 Class Initialized
INFO - 2018-07-20 03:07:46 --> URI Class Initialized
INFO - 2018-07-20 03:07:46 --> Router Class Initialized
INFO - 2018-07-20 03:07:46 --> Output Class Initialized
INFO - 2018-07-20 03:07:46 --> Security Class Initialized
DEBUG - 2018-07-20 03:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 03:07:46 --> CSRF cookie sent
INFO - 2018-07-20 03:07:46 --> Input Class Initialized
INFO - 2018-07-20 03:07:46 --> Language Class Initialized
ERROR - 2018-07-20 03:07:46 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 03:34:30 --> Config Class Initialized
INFO - 2018-07-20 03:34:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 03:34:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 03:34:30 --> Utf8 Class Initialized
INFO - 2018-07-20 03:34:30 --> URI Class Initialized
INFO - 2018-07-20 03:34:30 --> Router Class Initialized
INFO - 2018-07-20 03:34:30 --> Output Class Initialized
INFO - 2018-07-20 03:34:30 --> Security Class Initialized
DEBUG - 2018-07-20 03:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 03:34:30 --> CSRF cookie sent
INFO - 2018-07-20 03:34:30 --> Input Class Initialized
INFO - 2018-07-20 03:34:30 --> Language Class Initialized
INFO - 2018-07-20 03:34:30 --> Loader Class Initialized
INFO - 2018-07-20 03:34:30 --> Helper loaded: url_helper
INFO - 2018-07-20 03:34:30 --> Helper loaded: form_helper
INFO - 2018-07-20 03:34:30 --> Helper loaded: language_helper
DEBUG - 2018-07-20 03:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 03:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 03:34:30 --> User Agent Class Initialized
INFO - 2018-07-20 03:34:30 --> Controller Class Initialized
INFO - 2018-07-20 03:34:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 03:34:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-20 03:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 03:34:30 --> Final output sent to browser
DEBUG - 2018-07-20 03:34:30 --> Total execution time: 0.0389
INFO - 2018-07-20 08:57:09 --> Config Class Initialized
INFO - 2018-07-20 08:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-20 08:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-20 08:57:09 --> Utf8 Class Initialized
INFO - 2018-07-20 08:57:09 --> URI Class Initialized
DEBUG - 2018-07-20 08:57:09 --> No URI present. Default controller set.
INFO - 2018-07-20 08:57:09 --> Router Class Initialized
INFO - 2018-07-20 08:57:09 --> Output Class Initialized
INFO - 2018-07-20 08:57:09 --> Security Class Initialized
DEBUG - 2018-07-20 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 08:57:09 --> CSRF cookie sent
INFO - 2018-07-20 08:57:09 --> Input Class Initialized
INFO - 2018-07-20 08:57:09 --> Language Class Initialized
INFO - 2018-07-20 08:57:09 --> Loader Class Initialized
INFO - 2018-07-20 08:57:09 --> Helper loaded: url_helper
INFO - 2018-07-20 08:57:09 --> Helper loaded: form_helper
INFO - 2018-07-20 08:57:09 --> Helper loaded: language_helper
DEBUG - 2018-07-20 08:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 08:57:09 --> User Agent Class Initialized
INFO - 2018-07-20 08:57:09 --> Controller Class Initialized
INFO - 2018-07-20 08:57:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 08:57:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 08:57:09 --> Pixel_Model class loaded
INFO - 2018-07-20 08:57:09 --> Database Driver Class Initialized
INFO - 2018-07-20 08:57:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 08:57:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 08:57:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 08:57:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 08:57:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 08:57:09 --> Final output sent to browser
DEBUG - 2018-07-20 08:57:09 --> Total execution time: 0.0482
INFO - 2018-07-20 09:58:00 --> Config Class Initialized
INFO - 2018-07-20 09:58:00 --> Hooks Class Initialized
DEBUG - 2018-07-20 09:58:00 --> UTF-8 Support Enabled
INFO - 2018-07-20 09:58:00 --> Utf8 Class Initialized
INFO - 2018-07-20 09:58:00 --> URI Class Initialized
DEBUG - 2018-07-20 09:58:00 --> No URI present. Default controller set.
INFO - 2018-07-20 09:58:00 --> Router Class Initialized
INFO - 2018-07-20 09:58:00 --> Output Class Initialized
INFO - 2018-07-20 09:58:00 --> Security Class Initialized
DEBUG - 2018-07-20 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 09:58:00 --> CSRF cookie sent
INFO - 2018-07-20 09:58:00 --> Input Class Initialized
INFO - 2018-07-20 09:58:00 --> Language Class Initialized
INFO - 2018-07-20 09:58:00 --> Loader Class Initialized
INFO - 2018-07-20 09:58:00 --> Helper loaded: url_helper
INFO - 2018-07-20 09:58:00 --> Helper loaded: form_helper
INFO - 2018-07-20 09:58:00 --> Helper loaded: language_helper
DEBUG - 2018-07-20 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 09:58:00 --> User Agent Class Initialized
INFO - 2018-07-20 09:58:00 --> Controller Class Initialized
INFO - 2018-07-20 09:58:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 09:58:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 09:58:00 --> Pixel_Model class loaded
INFO - 2018-07-20 09:58:00 --> Database Driver Class Initialized
INFO - 2018-07-20 09:58:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 09:58:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 09:58:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 09:58:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 09:58:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 09:58:00 --> Final output sent to browser
DEBUG - 2018-07-20 09:58:00 --> Total execution time: 0.0333
INFO - 2018-07-20 11:28:29 --> Config Class Initialized
INFO - 2018-07-20 11:28:29 --> Hooks Class Initialized
DEBUG - 2018-07-20 11:28:29 --> UTF-8 Support Enabled
INFO - 2018-07-20 11:28:29 --> Utf8 Class Initialized
INFO - 2018-07-20 11:28:29 --> URI Class Initialized
DEBUG - 2018-07-20 11:28:29 --> No URI present. Default controller set.
INFO - 2018-07-20 11:28:29 --> Router Class Initialized
INFO - 2018-07-20 11:28:29 --> Output Class Initialized
INFO - 2018-07-20 11:28:29 --> Security Class Initialized
DEBUG - 2018-07-20 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 11:28:29 --> CSRF cookie sent
INFO - 2018-07-20 11:28:29 --> Input Class Initialized
INFO - 2018-07-20 11:28:29 --> Language Class Initialized
INFO - 2018-07-20 11:28:29 --> Loader Class Initialized
INFO - 2018-07-20 11:28:29 --> Helper loaded: url_helper
INFO - 2018-07-20 11:28:29 --> Helper loaded: form_helper
INFO - 2018-07-20 11:28:29 --> Helper loaded: language_helper
DEBUG - 2018-07-20 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 11:28:29 --> User Agent Class Initialized
INFO - 2018-07-20 11:28:29 --> Controller Class Initialized
INFO - 2018-07-20 11:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 11:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 11:28:29 --> Pixel_Model class loaded
INFO - 2018-07-20 11:28:29 --> Database Driver Class Initialized
INFO - 2018-07-20 11:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 11:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 11:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 11:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 11:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 11:28:29 --> Final output sent to browser
DEBUG - 2018-07-20 11:28:29 --> Total execution time: 0.0351
INFO - 2018-07-20 17:17:34 --> Config Class Initialized
INFO - 2018-07-20 17:17:34 --> Hooks Class Initialized
DEBUG - 2018-07-20 17:17:34 --> UTF-8 Support Enabled
INFO - 2018-07-20 17:17:34 --> Utf8 Class Initialized
INFO - 2018-07-20 17:17:34 --> URI Class Initialized
INFO - 2018-07-20 17:17:34 --> Router Class Initialized
INFO - 2018-07-20 17:17:34 --> Output Class Initialized
INFO - 2018-07-20 17:17:34 --> Security Class Initialized
DEBUG - 2018-07-20 17:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 17:17:34 --> CSRF cookie sent
INFO - 2018-07-20 17:17:34 --> Input Class Initialized
INFO - 2018-07-20 17:17:34 --> Language Class Initialized
ERROR - 2018-07-20 17:17:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 17:53:37 --> Config Class Initialized
INFO - 2018-07-20 17:53:37 --> Hooks Class Initialized
DEBUG - 2018-07-20 17:53:37 --> UTF-8 Support Enabled
INFO - 2018-07-20 17:53:37 --> Utf8 Class Initialized
INFO - 2018-07-20 17:53:37 --> URI Class Initialized
DEBUG - 2018-07-20 17:53:37 --> No URI present. Default controller set.
INFO - 2018-07-20 17:53:37 --> Router Class Initialized
INFO - 2018-07-20 17:53:37 --> Output Class Initialized
INFO - 2018-07-20 17:53:37 --> Security Class Initialized
DEBUG - 2018-07-20 17:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 17:53:37 --> CSRF cookie sent
INFO - 2018-07-20 17:53:37 --> Input Class Initialized
INFO - 2018-07-20 17:53:37 --> Language Class Initialized
INFO - 2018-07-20 17:53:37 --> Loader Class Initialized
INFO - 2018-07-20 17:53:37 --> Helper loaded: url_helper
INFO - 2018-07-20 17:53:37 --> Helper loaded: form_helper
INFO - 2018-07-20 17:53:37 --> Helper loaded: language_helper
DEBUG - 2018-07-20 17:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 17:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 17:53:37 --> User Agent Class Initialized
INFO - 2018-07-20 17:53:37 --> Controller Class Initialized
INFO - 2018-07-20 17:53:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 17:53:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 17:53:37 --> Pixel_Model class loaded
INFO - 2018-07-20 17:53:37 --> Database Driver Class Initialized
INFO - 2018-07-20 17:53:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 17:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 17:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 17:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 17:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 17:53:37 --> Final output sent to browser
DEBUG - 2018-07-20 17:53:37 --> Total execution time: 0.0388
INFO - 2018-07-20 17:59:37 --> Config Class Initialized
INFO - 2018-07-20 17:59:37 --> Hooks Class Initialized
DEBUG - 2018-07-20 17:59:37 --> UTF-8 Support Enabled
INFO - 2018-07-20 17:59:37 --> Utf8 Class Initialized
INFO - 2018-07-20 17:59:37 --> URI Class Initialized
DEBUG - 2018-07-20 17:59:37 --> No URI present. Default controller set.
INFO - 2018-07-20 17:59:37 --> Router Class Initialized
INFO - 2018-07-20 17:59:37 --> Output Class Initialized
INFO - 2018-07-20 17:59:37 --> Security Class Initialized
DEBUG - 2018-07-20 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 17:59:37 --> CSRF cookie sent
INFO - 2018-07-20 17:59:37 --> Input Class Initialized
INFO - 2018-07-20 17:59:37 --> Language Class Initialized
INFO - 2018-07-20 17:59:37 --> Loader Class Initialized
INFO - 2018-07-20 17:59:37 --> Helper loaded: url_helper
INFO - 2018-07-20 17:59:37 --> Helper loaded: form_helper
INFO - 2018-07-20 17:59:37 --> Helper loaded: language_helper
DEBUG - 2018-07-20 17:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 17:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 17:59:37 --> User Agent Class Initialized
INFO - 2018-07-20 17:59:37 --> Controller Class Initialized
INFO - 2018-07-20 17:59:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 17:59:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 17:59:37 --> Pixel_Model class loaded
INFO - 2018-07-20 17:59:37 --> Database Driver Class Initialized
INFO - 2018-07-20 17:59:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 17:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 17:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 17:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 17:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 17:59:37 --> Final output sent to browser
DEBUG - 2018-07-20 17:59:37 --> Total execution time: 0.0400
INFO - 2018-07-20 18:00:22 --> Config Class Initialized
INFO - 2018-07-20 18:00:22 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:00:22 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:00:22 --> Utf8 Class Initialized
INFO - 2018-07-20 18:00:22 --> URI Class Initialized
INFO - 2018-07-20 18:00:22 --> Router Class Initialized
INFO - 2018-07-20 18:00:22 --> Output Class Initialized
INFO - 2018-07-20 18:00:22 --> Security Class Initialized
DEBUG - 2018-07-20 18:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:00:22 --> CSRF cookie sent
INFO - 2018-07-20 18:00:22 --> Input Class Initialized
INFO - 2018-07-20 18:00:22 --> Language Class Initialized
ERROR - 2018-07-20 18:00:22 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 18:00:25 --> Config Class Initialized
INFO - 2018-07-20 18:00:25 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:00:25 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:00:25 --> Utf8 Class Initialized
INFO - 2018-07-20 18:00:25 --> URI Class Initialized
INFO - 2018-07-20 18:00:25 --> Router Class Initialized
INFO - 2018-07-20 18:00:25 --> Output Class Initialized
INFO - 2018-07-20 18:00:25 --> Security Class Initialized
DEBUG - 2018-07-20 18:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:00:25 --> CSRF cookie sent
INFO - 2018-07-20 18:00:25 --> Input Class Initialized
INFO - 2018-07-20 18:00:25 --> Language Class Initialized
INFO - 2018-07-20 18:00:25 --> Loader Class Initialized
INFO - 2018-07-20 18:00:25 --> Helper loaded: url_helper
INFO - 2018-07-20 18:00:25 --> Helper loaded: form_helper
INFO - 2018-07-20 18:00:25 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:00:25 --> User Agent Class Initialized
INFO - 2018-07-20 18:00:25 --> Controller Class Initialized
INFO - 2018-07-20 18:00:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:00:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-20 18:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:00:25 --> Final output sent to browser
DEBUG - 2018-07-20 18:00:25 --> Total execution time: 0.0219
INFO - 2018-07-20 18:01:14 --> Config Class Initialized
INFO - 2018-07-20 18:01:14 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:14 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:14 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:14 --> URI Class Initialized
DEBUG - 2018-07-20 18:01:14 --> No URI present. Default controller set.
INFO - 2018-07-20 18:01:14 --> Router Class Initialized
INFO - 2018-07-20 18:01:14 --> Output Class Initialized
INFO - 2018-07-20 18:01:14 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:14 --> CSRF cookie sent
INFO - 2018-07-20 18:01:14 --> Input Class Initialized
INFO - 2018-07-20 18:01:14 --> Language Class Initialized
INFO - 2018-07-20 18:01:14 --> Loader Class Initialized
INFO - 2018-07-20 18:01:14 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:14 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:14 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:14 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:14 --> Controller Class Initialized
INFO - 2018-07-20 18:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:14 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:14 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:14 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:14 --> Total execution time: 0.0346
INFO - 2018-07-20 18:01:14 --> Config Class Initialized
INFO - 2018-07-20 18:01:14 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:14 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:14 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:14 --> URI Class Initialized
DEBUG - 2018-07-20 18:01:14 --> No URI present. Default controller set.
INFO - 2018-07-20 18:01:14 --> Router Class Initialized
INFO - 2018-07-20 18:01:14 --> Output Class Initialized
INFO - 2018-07-20 18:01:14 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:14 --> CSRF cookie sent
INFO - 2018-07-20 18:01:14 --> Input Class Initialized
INFO - 2018-07-20 18:01:14 --> Language Class Initialized
INFO - 2018-07-20 18:01:14 --> Loader Class Initialized
INFO - 2018-07-20 18:01:14 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:14 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:14 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:14 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:14 --> Controller Class Initialized
INFO - 2018-07-20 18:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:14 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:14 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 18:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:14 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:14 --> Total execution time: 0.0415
INFO - 2018-07-20 18:01:15 --> Config Class Initialized
INFO - 2018-07-20 18:01:15 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:15 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:15 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:15 --> URI Class Initialized
DEBUG - 2018-07-20 18:01:15 --> No URI present. Default controller set.
INFO - 2018-07-20 18:01:15 --> Router Class Initialized
INFO - 2018-07-20 18:01:15 --> Output Class Initialized
INFO - 2018-07-20 18:01:15 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:15 --> CSRF cookie sent
INFO - 2018-07-20 18:01:15 --> Input Class Initialized
INFO - 2018-07-20 18:01:15 --> Language Class Initialized
INFO - 2018-07-20 18:01:15 --> Loader Class Initialized
INFO - 2018-07-20 18:01:15 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:15 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:15 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:15 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:15 --> Controller Class Initialized
INFO - 2018-07-20 18:01:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:15 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:15 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 18:01:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:15 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:15 --> Total execution time: 0.0340
INFO - 2018-07-20 18:01:15 --> Config Class Initialized
INFO - 2018-07-20 18:01:15 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:15 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:15 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:15 --> URI Class Initialized
INFO - 2018-07-20 18:01:15 --> Router Class Initialized
INFO - 2018-07-20 18:01:15 --> Output Class Initialized
INFO - 2018-07-20 18:01:15 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:15 --> CSRF cookie sent
INFO - 2018-07-20 18:01:15 --> Input Class Initialized
INFO - 2018-07-20 18:01:15 --> Language Class Initialized
ERROR - 2018-07-20 18:01:15 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-20 18:01:22 --> Config Class Initialized
INFO - 2018-07-20 18:01:22 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:22 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:22 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:22 --> URI Class Initialized
DEBUG - 2018-07-20 18:01:22 --> No URI present. Default controller set.
INFO - 2018-07-20 18:01:22 --> Router Class Initialized
INFO - 2018-07-20 18:01:22 --> Output Class Initialized
INFO - 2018-07-20 18:01:22 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:22 --> CSRF cookie sent
INFO - 2018-07-20 18:01:22 --> Input Class Initialized
INFO - 2018-07-20 18:01:22 --> Language Class Initialized
INFO - 2018-07-20 18:01:22 --> Loader Class Initialized
INFO - 2018-07-20 18:01:22 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:22 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:22 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:22 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:22 --> Controller Class Initialized
INFO - 2018-07-20 18:01:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:22 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:22 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 18:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:22 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:22 --> Total execution time: 0.0335
INFO - 2018-07-20 18:01:22 --> Config Class Initialized
INFO - 2018-07-20 18:01:22 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:22 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:22 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:22 --> URI Class Initialized
INFO - 2018-07-20 18:01:22 --> Router Class Initialized
INFO - 2018-07-20 18:01:22 --> Output Class Initialized
INFO - 2018-07-20 18:01:22 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:22 --> CSRF cookie sent
INFO - 2018-07-20 18:01:22 --> Input Class Initialized
INFO - 2018-07-20 18:01:22 --> Language Class Initialized
ERROR - 2018-07-20 18:01:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-20 18:01:23 --> Config Class Initialized
INFO - 2018-07-20 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:23 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:23 --> URI Class Initialized
INFO - 2018-07-20 18:01:23 --> Router Class Initialized
INFO - 2018-07-20 18:01:23 --> Output Class Initialized
INFO - 2018-07-20 18:01:23 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:23 --> CSRF cookie sent
INFO - 2018-07-20 18:01:23 --> Input Class Initialized
INFO - 2018-07-20 18:01:23 --> Language Class Initialized
ERROR - 2018-07-20 18:01:23 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-20 18:01:23 --> Config Class Initialized
INFO - 2018-07-20 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:23 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:23 --> URI Class Initialized
INFO - 2018-07-20 18:01:23 --> Router Class Initialized
INFO - 2018-07-20 18:01:23 --> Output Class Initialized
INFO - 2018-07-20 18:01:23 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:23 --> CSRF cookie sent
INFO - 2018-07-20 18:01:23 --> Input Class Initialized
INFO - 2018-07-20 18:01:23 --> Language Class Initialized
INFO - 2018-07-20 18:01:23 --> Loader Class Initialized
INFO - 2018-07-20 18:01:23 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:23 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:23 --> Controller Class Initialized
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:23 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:23 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:23 --> Config Class Initialized
INFO - 2018-07-20 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:23 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:23 --> URI Class Initialized
INFO - 2018-07-20 18:01:23 --> Router Class Initialized
INFO - 2018-07-20 18:01:23 --> Output Class Initialized
INFO - 2018-07-20 18:01:23 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:23 --> CSRF cookie sent
INFO - 2018-07-20 18:01:23 --> Input Class Initialized
INFO - 2018-07-20 18:01:23 --> Language Class Initialized
INFO - 2018-07-20 18:01:23 --> Loader Class Initialized
INFO - 2018-07-20 18:01:23 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:23 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:23 --> Controller Class Initialized
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-20 18:01:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-20 18:01:23 --> Could not find the language line "req_email"
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:23 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:23 --> Total execution time: 0.0225
INFO - 2018-07-20 18:01:23 --> Config Class Initialized
INFO - 2018-07-20 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:23 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:23 --> URI Class Initialized
INFO - 2018-07-20 18:01:23 --> Router Class Initialized
INFO - 2018-07-20 18:01:23 --> Output Class Initialized
INFO - 2018-07-20 18:01:23 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:23 --> CSRF cookie sent
INFO - 2018-07-20 18:01:23 --> Input Class Initialized
INFO - 2018-07-20 18:01:23 --> Language Class Initialized
INFO - 2018-07-20 18:01:23 --> Loader Class Initialized
INFO - 2018-07-20 18:01:23 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:23 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:23 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:23 --> Controller Class Initialized
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-20 18:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:23 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:23 --> Total execution time: 0.0234
INFO - 2018-07-20 18:01:24 --> Config Class Initialized
INFO - 2018-07-20 18:01:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:24 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:24 --> URI Class Initialized
INFO - 2018-07-20 18:01:24 --> Router Class Initialized
INFO - 2018-07-20 18:01:24 --> Output Class Initialized
INFO - 2018-07-20 18:01:24 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:24 --> CSRF cookie sent
INFO - 2018-07-20 18:01:24 --> Input Class Initialized
INFO - 2018-07-20 18:01:24 --> Language Class Initialized
INFO - 2018-07-20 18:01:24 --> Loader Class Initialized
INFO - 2018-07-20 18:01:24 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:24 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:24 --> Controller Class Initialized
INFO - 2018-07-20 18:01:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:24 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:24 --> Total execution time: 0.0235
INFO - 2018-07-20 18:01:24 --> Config Class Initialized
INFO - 2018-07-20 18:01:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:24 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:24 --> URI Class Initialized
INFO - 2018-07-20 18:01:24 --> Router Class Initialized
INFO - 2018-07-20 18:01:24 --> Output Class Initialized
INFO - 2018-07-20 18:01:24 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:24 --> CSRF cookie sent
INFO - 2018-07-20 18:01:24 --> Input Class Initialized
INFO - 2018-07-20 18:01:24 --> Language Class Initialized
INFO - 2018-07-20 18:01:24 --> Loader Class Initialized
INFO - 2018-07-20 18:01:24 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:24 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:24 --> Controller Class Initialized
INFO - 2018-07-20 18:01:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-20 18:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:24 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:24 --> Total execution time: 0.0215
INFO - 2018-07-20 18:01:24 --> Config Class Initialized
INFO - 2018-07-20 18:01:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:24 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:24 --> URI Class Initialized
INFO - 2018-07-20 18:01:24 --> Router Class Initialized
INFO - 2018-07-20 18:01:24 --> Output Class Initialized
INFO - 2018-07-20 18:01:24 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:24 --> CSRF cookie sent
INFO - 2018-07-20 18:01:24 --> Input Class Initialized
INFO - 2018-07-20 18:01:24 --> Language Class Initialized
INFO - 2018-07-20 18:01:24 --> Loader Class Initialized
INFO - 2018-07-20 18:01:24 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:24 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:25 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:25 --> Controller Class Initialized
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:25 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:25 --> Total execution time: 0.0238
INFO - 2018-07-20 18:01:25 --> Config Class Initialized
INFO - 2018-07-20 18:01:25 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:25 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:25 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:25 --> URI Class Initialized
INFO - 2018-07-20 18:01:25 --> Router Class Initialized
INFO - 2018-07-20 18:01:25 --> Output Class Initialized
INFO - 2018-07-20 18:01:25 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:25 --> CSRF cookie sent
INFO - 2018-07-20 18:01:25 --> Input Class Initialized
INFO - 2018-07-20 18:01:25 --> Language Class Initialized
INFO - 2018-07-20 18:01:25 --> Loader Class Initialized
INFO - 2018-07-20 18:01:25 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:25 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:25 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:25 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:25 --> Controller Class Initialized
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-20 18:01:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-20 18:01:25 --> Could not find the language line "req_email"
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:25 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:25 --> Total execution time: 0.0211
INFO - 2018-07-20 18:01:25 --> Config Class Initialized
INFO - 2018-07-20 18:01:25 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:01:25 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:01:25 --> Utf8 Class Initialized
INFO - 2018-07-20 18:01:25 --> URI Class Initialized
INFO - 2018-07-20 18:01:25 --> Router Class Initialized
INFO - 2018-07-20 18:01:25 --> Output Class Initialized
INFO - 2018-07-20 18:01:25 --> Security Class Initialized
DEBUG - 2018-07-20 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:01:25 --> CSRF cookie sent
INFO - 2018-07-20 18:01:25 --> Input Class Initialized
INFO - 2018-07-20 18:01:25 --> Language Class Initialized
INFO - 2018-07-20 18:01:25 --> Loader Class Initialized
INFO - 2018-07-20 18:01:25 --> Helper loaded: url_helper
INFO - 2018-07-20 18:01:25 --> Helper loaded: form_helper
INFO - 2018-07-20 18:01:25 --> Helper loaded: language_helper
DEBUG - 2018-07-20 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 18:01:25 --> User Agent Class Initialized
INFO - 2018-07-20 18:01:25 --> Controller Class Initialized
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 18:01:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 18:01:25 --> Pixel_Model class loaded
INFO - 2018-07-20 18:01:25 --> Database Driver Class Initialized
INFO - 2018-07-20 18:01:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-20 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 18:01:25 --> Final output sent to browser
DEBUG - 2018-07-20 18:01:25 --> Total execution time: 0.0391
INFO - 2018-07-20 18:05:45 --> Config Class Initialized
INFO - 2018-07-20 18:05:45 --> Hooks Class Initialized
DEBUG - 2018-07-20 18:05:45 --> UTF-8 Support Enabled
INFO - 2018-07-20 18:05:45 --> Utf8 Class Initialized
INFO - 2018-07-20 18:05:45 --> URI Class Initialized
INFO - 2018-07-20 18:05:45 --> Router Class Initialized
INFO - 2018-07-20 18:05:45 --> Output Class Initialized
INFO - 2018-07-20 18:05:45 --> Security Class Initialized
DEBUG - 2018-07-20 18:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 18:05:45 --> CSRF cookie sent
INFO - 2018-07-20 18:05:45 --> Input Class Initialized
INFO - 2018-07-20 18:05:45 --> Language Class Initialized
ERROR - 2018-07-20 18:05:45 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-20 19:09:39 --> Config Class Initialized
INFO - 2018-07-20 19:09:39 --> Hooks Class Initialized
DEBUG - 2018-07-20 19:09:39 --> UTF-8 Support Enabled
INFO - 2018-07-20 19:09:39 --> Utf8 Class Initialized
INFO - 2018-07-20 19:09:39 --> URI Class Initialized
DEBUG - 2018-07-20 19:09:39 --> No URI present. Default controller set.
INFO - 2018-07-20 19:09:39 --> Router Class Initialized
INFO - 2018-07-20 19:09:39 --> Output Class Initialized
INFO - 2018-07-20 19:09:39 --> Security Class Initialized
DEBUG - 2018-07-20 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 19:09:39 --> CSRF cookie sent
INFO - 2018-07-20 19:09:39 --> Input Class Initialized
INFO - 2018-07-20 19:09:39 --> Language Class Initialized
INFO - 2018-07-20 19:09:39 --> Loader Class Initialized
INFO - 2018-07-20 19:09:39 --> Helper loaded: url_helper
INFO - 2018-07-20 19:09:39 --> Helper loaded: form_helper
INFO - 2018-07-20 19:09:39 --> Helper loaded: language_helper
DEBUG - 2018-07-20 19:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 19:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 19:09:39 --> User Agent Class Initialized
INFO - 2018-07-20 19:09:39 --> Controller Class Initialized
INFO - 2018-07-20 19:09:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 19:09:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 19:09:39 --> Pixel_Model class loaded
INFO - 2018-07-20 19:09:39 --> Database Driver Class Initialized
INFO - 2018-07-20 19:09:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 19:09:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 19:09:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 19:09:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 19:09:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 19:09:39 --> Final output sent to browser
DEBUG - 2018-07-20 19:09:39 --> Total execution time: 0.0341
INFO - 2018-07-20 22:24:48 --> Config Class Initialized
INFO - 2018-07-20 22:24:48 --> Hooks Class Initialized
DEBUG - 2018-07-20 22:24:48 --> UTF-8 Support Enabled
INFO - 2018-07-20 22:24:48 --> Utf8 Class Initialized
INFO - 2018-07-20 22:24:48 --> URI Class Initialized
DEBUG - 2018-07-20 22:24:48 --> No URI present. Default controller set.
INFO - 2018-07-20 22:24:48 --> Router Class Initialized
INFO - 2018-07-20 22:24:48 --> Output Class Initialized
INFO - 2018-07-20 22:24:48 --> Security Class Initialized
DEBUG - 2018-07-20 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 22:24:48 --> CSRF cookie sent
INFO - 2018-07-20 22:24:48 --> Input Class Initialized
INFO - 2018-07-20 22:24:48 --> Language Class Initialized
INFO - 2018-07-20 22:24:48 --> Loader Class Initialized
INFO - 2018-07-20 22:24:48 --> Helper loaded: url_helper
INFO - 2018-07-20 22:24:48 --> Helper loaded: form_helper
INFO - 2018-07-20 22:24:48 --> Helper loaded: language_helper
DEBUG - 2018-07-20 22:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 22:24:48 --> User Agent Class Initialized
INFO - 2018-07-20 22:24:48 --> Controller Class Initialized
INFO - 2018-07-20 22:24:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-20 22:24:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-20 22:24:48 --> Pixel_Model class loaded
INFO - 2018-07-20 22:24:48 --> Database Driver Class Initialized
INFO - 2018-07-20 22:24:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-20 22:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-20 22:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-20 22:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-20 22:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-20 22:24:48 --> Final output sent to browser
DEBUG - 2018-07-20 22:24:48 --> Total execution time: 0.0370

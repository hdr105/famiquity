<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-21 01:29:47 --> Config Class Initialized
INFO - 2018-07-21 01:29:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:29:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:29:47 --> Utf8 Class Initialized
INFO - 2018-07-21 01:29:47 --> URI Class Initialized
INFO - 2018-07-21 01:29:47 --> Router Class Initialized
INFO - 2018-07-21 01:29:47 --> Output Class Initialized
INFO - 2018-07-21 01:29:47 --> Security Class Initialized
DEBUG - 2018-07-21 01:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:29:47 --> CSRF cookie sent
INFO - 2018-07-21 01:29:47 --> Input Class Initialized
INFO - 2018-07-21 01:29:47 --> Language Class Initialized
ERROR - 2018-07-21 01:29:47 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-21 01:29:50 --> Config Class Initialized
INFO - 2018-07-21 01:29:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:29:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:29:50 --> Utf8 Class Initialized
INFO - 2018-07-21 01:29:50 --> URI Class Initialized
DEBUG - 2018-07-21 01:29:50 --> No URI present. Default controller set.
INFO - 2018-07-21 01:29:50 --> Router Class Initialized
INFO - 2018-07-21 01:29:50 --> Output Class Initialized
INFO - 2018-07-21 01:29:50 --> Security Class Initialized
DEBUG - 2018-07-21 01:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:29:50 --> CSRF cookie sent
INFO - 2018-07-21 01:29:50 --> Input Class Initialized
INFO - 2018-07-21 01:29:50 --> Language Class Initialized
INFO - 2018-07-21 01:29:50 --> Loader Class Initialized
INFO - 2018-07-21 01:29:50 --> Helper loaded: url_helper
INFO - 2018-07-21 01:29:50 --> Helper loaded: form_helper
INFO - 2018-07-21 01:29:50 --> Helper loaded: language_helper
DEBUG - 2018-07-21 01:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:29:50 --> User Agent Class Initialized
INFO - 2018-07-21 01:29:50 --> Controller Class Initialized
INFO - 2018-07-21 01:29:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 01:29:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 01:29:50 --> Pixel_Model class loaded
INFO - 2018-07-21 01:29:50 --> Database Driver Class Initialized
INFO - 2018-07-21 01:29:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 01:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 01:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 01:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 01:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 01:29:50 --> Final output sent to browser
DEBUG - 2018-07-21 01:29:50 --> Total execution time: 0.0337
INFO - 2018-07-21 01:53:20 --> Config Class Initialized
INFO - 2018-07-21 01:53:20 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:53:20 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:53:20 --> Utf8 Class Initialized
INFO - 2018-07-21 01:53:20 --> URI Class Initialized
DEBUG - 2018-07-21 01:53:20 --> No URI present. Default controller set.
INFO - 2018-07-21 01:53:20 --> Router Class Initialized
INFO - 2018-07-21 01:53:20 --> Output Class Initialized
INFO - 2018-07-21 01:53:20 --> Security Class Initialized
DEBUG - 2018-07-21 01:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:53:20 --> CSRF cookie sent
INFO - 2018-07-21 01:53:20 --> Input Class Initialized
INFO - 2018-07-21 01:53:20 --> Language Class Initialized
INFO - 2018-07-21 01:53:20 --> Loader Class Initialized
INFO - 2018-07-21 01:53:20 --> Helper loaded: url_helper
INFO - 2018-07-21 01:53:20 --> Helper loaded: form_helper
INFO - 2018-07-21 01:53:20 --> Helper loaded: language_helper
DEBUG - 2018-07-21 01:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:53:20 --> User Agent Class Initialized
INFO - 2018-07-21 01:53:20 --> Controller Class Initialized
INFO - 2018-07-21 01:53:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 01:53:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 01:53:20 --> Pixel_Model class loaded
INFO - 2018-07-21 01:53:20 --> Database Driver Class Initialized
INFO - 2018-07-21 01:53:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 01:53:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 01:53:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 01:53:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 01:53:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 01:53:20 --> Final output sent to browser
DEBUG - 2018-07-21 01:53:20 --> Total execution time: 0.0409
INFO - 2018-07-21 01:54:19 --> Config Class Initialized
INFO - 2018-07-21 01:54:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:54:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:54:19 --> Utf8 Class Initialized
INFO - 2018-07-21 01:54:19 --> URI Class Initialized
DEBUG - 2018-07-21 01:54:19 --> No URI present. Default controller set.
INFO - 2018-07-21 01:54:19 --> Router Class Initialized
INFO - 2018-07-21 01:54:19 --> Output Class Initialized
INFO - 2018-07-21 01:54:19 --> Security Class Initialized
DEBUG - 2018-07-21 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:54:19 --> CSRF cookie sent
INFO - 2018-07-21 01:54:19 --> Input Class Initialized
INFO - 2018-07-21 01:54:19 --> Language Class Initialized
INFO - 2018-07-21 01:54:19 --> Loader Class Initialized
INFO - 2018-07-21 01:54:19 --> Helper loaded: url_helper
INFO - 2018-07-21 01:54:19 --> Helper loaded: form_helper
INFO - 2018-07-21 01:54:19 --> Helper loaded: language_helper
DEBUG - 2018-07-21 01:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:54:19 --> User Agent Class Initialized
INFO - 2018-07-21 01:54:19 --> Controller Class Initialized
INFO - 2018-07-21 01:54:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 01:54:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 01:54:19 --> Pixel_Model class loaded
INFO - 2018-07-21 01:54:19 --> Database Driver Class Initialized
INFO - 2018-07-21 01:54:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 01:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 01:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 01:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 01:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 01:54:19 --> Final output sent to browser
DEBUG - 2018-07-21 01:54:19 --> Total execution time: 0.0316
INFO - 2018-07-21 07:17:30 --> Config Class Initialized
INFO - 2018-07-21 07:17:30 --> Hooks Class Initialized
DEBUG - 2018-07-21 07:17:30 --> UTF-8 Support Enabled
INFO - 2018-07-21 07:17:30 --> Utf8 Class Initialized
INFO - 2018-07-21 07:17:30 --> URI Class Initialized
DEBUG - 2018-07-21 07:17:30 --> No URI present. Default controller set.
INFO - 2018-07-21 07:17:30 --> Router Class Initialized
INFO - 2018-07-21 07:17:30 --> Output Class Initialized
INFO - 2018-07-21 07:17:30 --> Security Class Initialized
DEBUG - 2018-07-21 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 07:17:30 --> CSRF cookie sent
INFO - 2018-07-21 07:17:30 --> Input Class Initialized
INFO - 2018-07-21 07:17:30 --> Language Class Initialized
INFO - 2018-07-21 07:17:30 --> Loader Class Initialized
INFO - 2018-07-21 07:17:30 --> Helper loaded: url_helper
INFO - 2018-07-21 07:17:30 --> Helper loaded: form_helper
INFO - 2018-07-21 07:17:30 --> Helper loaded: language_helper
DEBUG - 2018-07-21 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 07:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 07:17:30 --> User Agent Class Initialized
INFO - 2018-07-21 07:17:30 --> Controller Class Initialized
INFO - 2018-07-21 07:17:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 07:17:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 07:17:30 --> Pixel_Model class loaded
INFO - 2018-07-21 07:17:30 --> Database Driver Class Initialized
INFO - 2018-07-21 07:17:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 07:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 07:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 07:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 07:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 07:17:30 --> Final output sent to browser
DEBUG - 2018-07-21 07:17:30 --> Total execution time: 0.0299
INFO - 2018-07-21 09:54:33 --> Config Class Initialized
INFO - 2018-07-21 09:54:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 09:54:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 09:54:33 --> Utf8 Class Initialized
INFO - 2018-07-21 09:54:33 --> URI Class Initialized
DEBUG - 2018-07-21 09:54:33 --> No URI present. Default controller set.
INFO - 2018-07-21 09:54:33 --> Router Class Initialized
INFO - 2018-07-21 09:54:33 --> Output Class Initialized
INFO - 2018-07-21 09:54:33 --> Security Class Initialized
DEBUG - 2018-07-21 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 09:54:33 --> CSRF cookie sent
INFO - 2018-07-21 09:54:33 --> Input Class Initialized
INFO - 2018-07-21 09:54:33 --> Language Class Initialized
INFO - 2018-07-21 09:54:33 --> Loader Class Initialized
INFO - 2018-07-21 09:54:33 --> Helper loaded: url_helper
INFO - 2018-07-21 09:54:33 --> Helper loaded: form_helper
INFO - 2018-07-21 09:54:33 --> Helper loaded: language_helper
DEBUG - 2018-07-21 09:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 09:54:33 --> User Agent Class Initialized
INFO - 2018-07-21 09:54:33 --> Controller Class Initialized
INFO - 2018-07-21 09:54:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 09:54:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 09:54:33 --> Pixel_Model class loaded
INFO - 2018-07-21 09:54:33 --> Database Driver Class Initialized
INFO - 2018-07-21 09:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 09:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 09:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 09:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 09:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 09:54:33 --> Final output sent to browser
DEBUG - 2018-07-21 09:54:33 --> Total execution time: 0.0342
INFO - 2018-07-21 11:11:36 --> Config Class Initialized
INFO - 2018-07-21 11:11:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 11:11:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 11:11:36 --> Utf8 Class Initialized
INFO - 2018-07-21 11:11:36 --> URI Class Initialized
DEBUG - 2018-07-21 11:11:36 --> No URI present. Default controller set.
INFO - 2018-07-21 11:11:36 --> Router Class Initialized
INFO - 2018-07-21 11:11:36 --> Output Class Initialized
INFO - 2018-07-21 11:11:36 --> Security Class Initialized
DEBUG - 2018-07-21 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 11:11:36 --> CSRF cookie sent
INFO - 2018-07-21 11:11:36 --> Input Class Initialized
INFO - 2018-07-21 11:11:36 --> Language Class Initialized
INFO - 2018-07-21 11:11:36 --> Loader Class Initialized
INFO - 2018-07-21 11:11:36 --> Helper loaded: url_helper
INFO - 2018-07-21 11:11:36 --> Helper loaded: form_helper
INFO - 2018-07-21 11:11:36 --> Helper loaded: language_helper
DEBUG - 2018-07-21 11:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 11:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 11:11:36 --> User Agent Class Initialized
INFO - 2018-07-21 11:11:36 --> Controller Class Initialized
INFO - 2018-07-21 11:11:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 11:11:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 11:11:36 --> Pixel_Model class loaded
INFO - 2018-07-21 11:11:36 --> Database Driver Class Initialized
INFO - 2018-07-21 11:11:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 11:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 11:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 11:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 11:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 11:11:36 --> Final output sent to browser
DEBUG - 2018-07-21 11:11:36 --> Total execution time: 0.0328
INFO - 2018-07-21 11:36:25 --> Config Class Initialized
INFO - 2018-07-21 11:36:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 11:36:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 11:36:25 --> Utf8 Class Initialized
INFO - 2018-07-21 11:36:25 --> URI Class Initialized
INFO - 2018-07-21 11:36:25 --> Router Class Initialized
INFO - 2018-07-21 11:36:25 --> Output Class Initialized
INFO - 2018-07-21 11:36:25 --> Security Class Initialized
DEBUG - 2018-07-21 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 11:36:25 --> CSRF cookie sent
INFO - 2018-07-21 11:36:25 --> Input Class Initialized
INFO - 2018-07-21 11:36:25 --> Language Class Initialized
ERROR - 2018-07-21 11:36:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-21 11:36:25 --> Config Class Initialized
INFO - 2018-07-21 11:36:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 11:36:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 11:36:25 --> Utf8 Class Initialized
INFO - 2018-07-21 11:36:25 --> URI Class Initialized
DEBUG - 2018-07-21 11:36:25 --> No URI present. Default controller set.
INFO - 2018-07-21 11:36:25 --> Router Class Initialized
INFO - 2018-07-21 11:36:25 --> Output Class Initialized
INFO - 2018-07-21 11:36:25 --> Security Class Initialized
DEBUG - 2018-07-21 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 11:36:25 --> CSRF cookie sent
INFO - 2018-07-21 11:36:25 --> Input Class Initialized
INFO - 2018-07-21 11:36:25 --> Language Class Initialized
INFO - 2018-07-21 11:36:25 --> Loader Class Initialized
INFO - 2018-07-21 11:36:25 --> Helper loaded: url_helper
INFO - 2018-07-21 11:36:25 --> Helper loaded: form_helper
INFO - 2018-07-21 11:36:25 --> Helper loaded: language_helper
DEBUG - 2018-07-21 11:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 11:36:25 --> User Agent Class Initialized
INFO - 2018-07-21 11:36:25 --> Controller Class Initialized
INFO - 2018-07-21 11:36:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 11:36:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 11:36:25 --> Pixel_Model class loaded
INFO - 2018-07-21 11:36:25 --> Database Driver Class Initialized
INFO - 2018-07-21 11:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 11:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 11:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 11:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 11:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 11:36:25 --> Final output sent to browser
DEBUG - 2018-07-21 11:36:25 --> Total execution time: 0.0393
INFO - 2018-07-21 12:04:01 --> Config Class Initialized
INFO - 2018-07-21 12:04:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 12:04:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 12:04:01 --> Utf8 Class Initialized
INFO - 2018-07-21 12:04:01 --> URI Class Initialized
INFO - 2018-07-21 12:04:01 --> Router Class Initialized
INFO - 2018-07-21 12:04:01 --> Output Class Initialized
INFO - 2018-07-21 12:04:01 --> Security Class Initialized
DEBUG - 2018-07-21 12:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 12:04:01 --> CSRF cookie sent
INFO - 2018-07-21 12:04:01 --> Input Class Initialized
INFO - 2018-07-21 12:04:01 --> Language Class Initialized
ERROR - 2018-07-21 12:04:01 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-21 12:04:04 --> Config Class Initialized
INFO - 2018-07-21 12:04:04 --> Hooks Class Initialized
DEBUG - 2018-07-21 12:04:04 --> UTF-8 Support Enabled
INFO - 2018-07-21 12:04:04 --> Utf8 Class Initialized
INFO - 2018-07-21 12:04:04 --> URI Class Initialized
DEBUG - 2018-07-21 12:04:04 --> No URI present. Default controller set.
INFO - 2018-07-21 12:04:04 --> Router Class Initialized
INFO - 2018-07-21 12:04:04 --> Output Class Initialized
INFO - 2018-07-21 12:04:04 --> Security Class Initialized
DEBUG - 2018-07-21 12:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 12:04:04 --> CSRF cookie sent
INFO - 2018-07-21 12:04:04 --> Input Class Initialized
INFO - 2018-07-21 12:04:04 --> Language Class Initialized
INFO - 2018-07-21 12:04:04 --> Loader Class Initialized
INFO - 2018-07-21 12:04:04 --> Helper loaded: url_helper
INFO - 2018-07-21 12:04:04 --> Helper loaded: form_helper
INFO - 2018-07-21 12:04:04 --> Helper loaded: language_helper
DEBUG - 2018-07-21 12:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 12:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 12:04:04 --> User Agent Class Initialized
INFO - 2018-07-21 12:04:04 --> Controller Class Initialized
INFO - 2018-07-21 12:04:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 12:04:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 12:04:04 --> Pixel_Model class loaded
INFO - 2018-07-21 12:04:04 --> Database Driver Class Initialized
INFO - 2018-07-21 12:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 12:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 12:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 12:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 12:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 12:04:04 --> Final output sent to browser
DEBUG - 2018-07-21 12:04:04 --> Total execution time: 0.0335
INFO - 2018-07-21 17:20:19 --> Config Class Initialized
INFO - 2018-07-21 17:20:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 17:20:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 17:20:19 --> Utf8 Class Initialized
INFO - 2018-07-21 17:20:19 --> URI Class Initialized
INFO - 2018-07-21 17:20:19 --> Router Class Initialized
INFO - 2018-07-21 17:20:19 --> Output Class Initialized
INFO - 2018-07-21 17:20:19 --> Security Class Initialized
DEBUG - 2018-07-21 17:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 17:20:19 --> CSRF cookie sent
INFO - 2018-07-21 17:20:19 --> Input Class Initialized
INFO - 2018-07-21 17:20:19 --> Language Class Initialized
ERROR - 2018-07-21 17:20:19 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-21 17:55:17 --> Config Class Initialized
INFO - 2018-07-21 17:55:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 17:55:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 17:55:17 --> Utf8 Class Initialized
INFO - 2018-07-21 17:55:17 --> URI Class Initialized
DEBUG - 2018-07-21 17:55:17 --> No URI present. Default controller set.
INFO - 2018-07-21 17:55:17 --> Router Class Initialized
INFO - 2018-07-21 17:55:17 --> Output Class Initialized
INFO - 2018-07-21 17:55:17 --> Security Class Initialized
DEBUG - 2018-07-21 17:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 17:55:17 --> CSRF cookie sent
INFO - 2018-07-21 17:55:17 --> Input Class Initialized
INFO - 2018-07-21 17:55:17 --> Language Class Initialized
INFO - 2018-07-21 17:55:17 --> Loader Class Initialized
INFO - 2018-07-21 17:55:17 --> Helper loaded: url_helper
INFO - 2018-07-21 17:55:17 --> Helper loaded: form_helper
INFO - 2018-07-21 17:55:17 --> Helper loaded: language_helper
DEBUG - 2018-07-21 17:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 17:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 17:55:17 --> User Agent Class Initialized
INFO - 2018-07-21 17:55:17 --> Controller Class Initialized
INFO - 2018-07-21 17:55:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 17:55:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 17:55:17 --> Pixel_Model class loaded
INFO - 2018-07-21 17:55:17 --> Database Driver Class Initialized
INFO - 2018-07-21 17:55:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 17:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 17:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 17:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 17:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 17:55:17 --> Final output sent to browser
DEBUG - 2018-07-21 17:55:17 --> Total execution time: 0.0337
INFO - 2018-07-21 18:09:16 --> Config Class Initialized
INFO - 2018-07-21 18:09:16 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:09:16 --> Utf8 Class Initialized
INFO - 2018-07-21 18:09:16 --> URI Class Initialized
INFO - 2018-07-21 18:09:16 --> Router Class Initialized
INFO - 2018-07-21 18:09:16 --> Output Class Initialized
INFO - 2018-07-21 18:09:16 --> Security Class Initialized
DEBUG - 2018-07-21 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:09:16 --> CSRF cookie sent
INFO - 2018-07-21 18:09:16 --> Input Class Initialized
INFO - 2018-07-21 18:09:16 --> Language Class Initialized
ERROR - 2018-07-21 18:09:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-21 18:16:50 --> Config Class Initialized
INFO - 2018-07-21 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:50 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:50 --> URI Class Initialized
DEBUG - 2018-07-21 18:16:50 --> No URI present. Default controller set.
INFO - 2018-07-21 18:16:50 --> Router Class Initialized
INFO - 2018-07-21 18:16:50 --> Output Class Initialized
INFO - 2018-07-21 18:16:50 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:50 --> CSRF cookie sent
INFO - 2018-07-21 18:16:50 --> Input Class Initialized
INFO - 2018-07-21 18:16:50 --> Language Class Initialized
INFO - 2018-07-21 18:16:50 --> Loader Class Initialized
INFO - 2018-07-21 18:16:50 --> Helper loaded: url_helper
INFO - 2018-07-21 18:16:50 --> Helper loaded: form_helper
INFO - 2018-07-21 18:16:50 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:16:50 --> User Agent Class Initialized
INFO - 2018-07-21 18:16:50 --> Controller Class Initialized
INFO - 2018-07-21 18:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:16:50 --> Pixel_Model class loaded
INFO - 2018-07-21 18:16:50 --> Database Driver Class Initialized
INFO - 2018-07-21 18:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:16:50 --> Final output sent to browser
DEBUG - 2018-07-21 18:16:50 --> Total execution time: 0.0350
INFO - 2018-07-21 18:16:51 --> Config Class Initialized
INFO - 2018-07-21 18:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:51 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:51 --> URI Class Initialized
DEBUG - 2018-07-21 18:16:51 --> No URI present. Default controller set.
INFO - 2018-07-21 18:16:51 --> Router Class Initialized
INFO - 2018-07-21 18:16:51 --> Output Class Initialized
INFO - 2018-07-21 18:16:51 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:51 --> CSRF cookie sent
INFO - 2018-07-21 18:16:51 --> Input Class Initialized
INFO - 2018-07-21 18:16:51 --> Language Class Initialized
INFO - 2018-07-21 18:16:51 --> Loader Class Initialized
INFO - 2018-07-21 18:16:51 --> Helper loaded: url_helper
INFO - 2018-07-21 18:16:51 --> Helper loaded: form_helper
INFO - 2018-07-21 18:16:51 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:16:51 --> User Agent Class Initialized
INFO - 2018-07-21 18:16:51 --> Controller Class Initialized
INFO - 2018-07-21 18:16:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:16:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:16:51 --> Pixel_Model class loaded
INFO - 2018-07-21 18:16:51 --> Database Driver Class Initialized
INFO - 2018-07-21 18:16:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:16:51 --> Final output sent to browser
DEBUG - 2018-07-21 18:16:51 --> Total execution time: 0.0273
INFO - 2018-07-21 18:16:51 --> Config Class Initialized
INFO - 2018-07-21 18:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:51 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:51 --> URI Class Initialized
DEBUG - 2018-07-21 18:16:51 --> No URI present. Default controller set.
INFO - 2018-07-21 18:16:51 --> Router Class Initialized
INFO - 2018-07-21 18:16:51 --> Output Class Initialized
INFO - 2018-07-21 18:16:51 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:51 --> CSRF cookie sent
INFO - 2018-07-21 18:16:51 --> Input Class Initialized
INFO - 2018-07-21 18:16:51 --> Language Class Initialized
INFO - 2018-07-21 18:16:51 --> Loader Class Initialized
INFO - 2018-07-21 18:16:51 --> Helper loaded: url_helper
INFO - 2018-07-21 18:16:51 --> Helper loaded: form_helper
INFO - 2018-07-21 18:16:51 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:16:51 --> User Agent Class Initialized
INFO - 2018-07-21 18:16:51 --> Controller Class Initialized
INFO - 2018-07-21 18:16:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:16:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:16:51 --> Pixel_Model class loaded
INFO - 2018-07-21 18:16:51 --> Database Driver Class Initialized
INFO - 2018-07-21 18:16:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:16:51 --> Final output sent to browser
DEBUG - 2018-07-21 18:16:51 --> Total execution time: 0.0356
INFO - 2018-07-21 18:16:52 --> Config Class Initialized
INFO - 2018-07-21 18:16:52 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:52 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:52 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:52 --> URI Class Initialized
INFO - 2018-07-21 18:16:52 --> Router Class Initialized
INFO - 2018-07-21 18:16:52 --> Output Class Initialized
INFO - 2018-07-21 18:16:52 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:52 --> CSRF cookie sent
INFO - 2018-07-21 18:16:52 --> Input Class Initialized
INFO - 2018-07-21 18:16:52 --> Language Class Initialized
ERROR - 2018-07-21 18:16:52 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-21 18:16:59 --> Config Class Initialized
INFO - 2018-07-21 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:59 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:59 --> URI Class Initialized
DEBUG - 2018-07-21 18:16:59 --> No URI present. Default controller set.
INFO - 2018-07-21 18:16:59 --> Router Class Initialized
INFO - 2018-07-21 18:16:59 --> Output Class Initialized
INFO - 2018-07-21 18:16:59 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:59 --> CSRF cookie sent
INFO - 2018-07-21 18:16:59 --> Input Class Initialized
INFO - 2018-07-21 18:16:59 --> Language Class Initialized
INFO - 2018-07-21 18:16:59 --> Loader Class Initialized
INFO - 2018-07-21 18:16:59 --> Helper loaded: url_helper
INFO - 2018-07-21 18:16:59 --> Helper loaded: form_helper
INFO - 2018-07-21 18:16:59 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:16:59 --> User Agent Class Initialized
INFO - 2018-07-21 18:16:59 --> Controller Class Initialized
INFO - 2018-07-21 18:16:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:16:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:16:59 --> Pixel_Model class loaded
INFO - 2018-07-21 18:16:59 --> Database Driver Class Initialized
INFO - 2018-07-21 18:16:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:16:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:16:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:16:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 18:16:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:16:59 --> Final output sent to browser
DEBUG - 2018-07-21 18:16:59 --> Total execution time: 0.0335
INFO - 2018-07-21 18:16:59 --> Config Class Initialized
INFO - 2018-07-21 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:59 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:59 --> URI Class Initialized
INFO - 2018-07-21 18:16:59 --> Router Class Initialized
INFO - 2018-07-21 18:16:59 --> Output Class Initialized
INFO - 2018-07-21 18:16:59 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:59 --> CSRF cookie sent
INFO - 2018-07-21 18:16:59 --> Input Class Initialized
INFO - 2018-07-21 18:16:59 --> Language Class Initialized
ERROR - 2018-07-21 18:16:59 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-21 18:16:59 --> Config Class Initialized
INFO - 2018-07-21 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:16:59 --> Utf8 Class Initialized
INFO - 2018-07-21 18:16:59 --> URI Class Initialized
INFO - 2018-07-21 18:16:59 --> Router Class Initialized
INFO - 2018-07-21 18:16:59 --> Output Class Initialized
INFO - 2018-07-21 18:16:59 --> Security Class Initialized
DEBUG - 2018-07-21 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:16:59 --> CSRF cookie sent
INFO - 2018-07-21 18:16:59 --> Input Class Initialized
INFO - 2018-07-21 18:16:59 --> Language Class Initialized
ERROR - 2018-07-21 18:16:59 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-21 18:17:00 --> Config Class Initialized
INFO - 2018-07-21 18:17:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:00 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:00 --> URI Class Initialized
INFO - 2018-07-21 18:17:00 --> Router Class Initialized
INFO - 2018-07-21 18:17:00 --> Output Class Initialized
INFO - 2018-07-21 18:17:00 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:00 --> CSRF cookie sent
INFO - 2018-07-21 18:17:00 --> Input Class Initialized
INFO - 2018-07-21 18:17:00 --> Language Class Initialized
INFO - 2018-07-21 18:17:00 --> Loader Class Initialized
INFO - 2018-07-21 18:17:00 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:00 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:00 --> Controller Class Initialized
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:00 --> Pixel_Model class loaded
INFO - 2018-07-21 18:17:00 --> Database Driver Class Initialized
INFO - 2018-07-21 18:17:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:17:00 --> Config Class Initialized
INFO - 2018-07-21 18:17:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:00 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:00 --> URI Class Initialized
INFO - 2018-07-21 18:17:00 --> Router Class Initialized
INFO - 2018-07-21 18:17:00 --> Output Class Initialized
INFO - 2018-07-21 18:17:00 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:00 --> CSRF cookie sent
INFO - 2018-07-21 18:17:00 --> Input Class Initialized
INFO - 2018-07-21 18:17:00 --> Language Class Initialized
INFO - 2018-07-21 18:17:00 --> Loader Class Initialized
INFO - 2018-07-21 18:17:00 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:00 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:00 --> Controller Class Initialized
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-21 18:17:00 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-21 18:17:00 --> Could not find the language line "req_email"
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:00 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:00 --> Total execution time: 0.0231
INFO - 2018-07-21 18:17:00 --> Config Class Initialized
INFO - 2018-07-21 18:17:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:00 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:00 --> URI Class Initialized
INFO - 2018-07-21 18:17:00 --> Router Class Initialized
INFO - 2018-07-21 18:17:00 --> Output Class Initialized
INFO - 2018-07-21 18:17:00 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:00 --> CSRF cookie sent
INFO - 2018-07-21 18:17:00 --> Input Class Initialized
INFO - 2018-07-21 18:17:00 --> Language Class Initialized
INFO - 2018-07-21 18:17:00 --> Loader Class Initialized
INFO - 2018-07-21 18:17:00 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:00 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:00 --> Controller Class Initialized
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:00 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:00 --> Total execution time: 0.0214
INFO - 2018-07-21 18:17:00 --> Config Class Initialized
INFO - 2018-07-21 18:17:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:00 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:00 --> URI Class Initialized
INFO - 2018-07-21 18:17:00 --> Router Class Initialized
INFO - 2018-07-21 18:17:00 --> Output Class Initialized
INFO - 2018-07-21 18:17:00 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:00 --> CSRF cookie sent
INFO - 2018-07-21 18:17:00 --> Input Class Initialized
INFO - 2018-07-21 18:17:00 --> Language Class Initialized
INFO - 2018-07-21 18:17:00 --> Loader Class Initialized
INFO - 2018-07-21 18:17:00 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:00 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:00 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:00 --> Controller Class Initialized
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-21 18:17:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:00 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:00 --> Total execution time: 0.0202
INFO - 2018-07-21 18:17:01 --> Config Class Initialized
INFO - 2018-07-21 18:17:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:01 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:01 --> URI Class Initialized
INFO - 2018-07-21 18:17:01 --> Router Class Initialized
INFO - 2018-07-21 18:17:01 --> Output Class Initialized
INFO - 2018-07-21 18:17:01 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:01 --> CSRF cookie sent
INFO - 2018-07-21 18:17:01 --> Input Class Initialized
INFO - 2018-07-21 18:17:01 --> Language Class Initialized
INFO - 2018-07-21 18:17:01 --> Loader Class Initialized
INFO - 2018-07-21 18:17:01 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:01 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:01 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:01 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:01 --> Controller Class Initialized
INFO - 2018-07-21 18:17:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:01 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:01 --> Total execution time: 0.0213
INFO - 2018-07-21 18:17:01 --> Config Class Initialized
INFO - 2018-07-21 18:17:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:01 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:01 --> URI Class Initialized
INFO - 2018-07-21 18:17:01 --> Router Class Initialized
INFO - 2018-07-21 18:17:01 --> Output Class Initialized
INFO - 2018-07-21 18:17:01 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:01 --> CSRF cookie sent
INFO - 2018-07-21 18:17:01 --> Input Class Initialized
INFO - 2018-07-21 18:17:01 --> Language Class Initialized
INFO - 2018-07-21 18:17:01 --> Loader Class Initialized
INFO - 2018-07-21 18:17:01 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:01 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:01 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:01 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:01 --> Controller Class Initialized
INFO - 2018-07-21 18:17:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-21 18:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:01 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:01 --> Total execution time: 0.0203
INFO - 2018-07-21 18:17:02 --> Config Class Initialized
INFO - 2018-07-21 18:17:02 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:02 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:02 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:02 --> URI Class Initialized
INFO - 2018-07-21 18:17:02 --> Router Class Initialized
INFO - 2018-07-21 18:17:02 --> Output Class Initialized
INFO - 2018-07-21 18:17:02 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:02 --> CSRF cookie sent
INFO - 2018-07-21 18:17:02 --> Input Class Initialized
INFO - 2018-07-21 18:17:02 --> Language Class Initialized
INFO - 2018-07-21 18:17:02 --> Loader Class Initialized
INFO - 2018-07-21 18:17:02 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:02 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:02 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:02 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:02 --> Controller Class Initialized
INFO - 2018-07-21 18:17:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-21 18:17:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-21 18:17:02 --> Could not find the language line "req_email"
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:02 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:02 --> Total execution time: 0.0289
INFO - 2018-07-21 18:17:02 --> Config Class Initialized
INFO - 2018-07-21 18:17:02 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:17:02 --> UTF-8 Support Enabled
INFO - 2018-07-21 18:17:02 --> Utf8 Class Initialized
INFO - 2018-07-21 18:17:02 --> URI Class Initialized
INFO - 2018-07-21 18:17:02 --> Router Class Initialized
INFO - 2018-07-21 18:17:02 --> Output Class Initialized
INFO - 2018-07-21 18:17:02 --> Security Class Initialized
DEBUG - 2018-07-21 18:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 18:17:02 --> CSRF cookie sent
INFO - 2018-07-21 18:17:02 --> Input Class Initialized
INFO - 2018-07-21 18:17:02 --> Language Class Initialized
INFO - 2018-07-21 18:17:02 --> Loader Class Initialized
INFO - 2018-07-21 18:17:02 --> Helper loaded: url_helper
INFO - 2018-07-21 18:17:02 --> Helper loaded: form_helper
INFO - 2018-07-21 18:17:02 --> Helper loaded: language_helper
DEBUG - 2018-07-21 18:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 18:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 18:17:02 --> User Agent Class Initialized
INFO - 2018-07-21 18:17:02 --> Controller Class Initialized
INFO - 2018-07-21 18:17:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 18:17:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 18:17:02 --> Pixel_Model class loaded
INFO - 2018-07-21 18:17:02 --> Database Driver Class Initialized
INFO - 2018-07-21 18:17:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-21 18:17:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 18:17:02 --> Final output sent to browser
DEBUG - 2018-07-21 18:17:02 --> Total execution time: 0.0344
INFO - 2018-07-21 19:14:38 --> Config Class Initialized
INFO - 2018-07-21 19:14:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:14:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:14:38 --> Utf8 Class Initialized
INFO - 2018-07-21 19:14:38 --> URI Class Initialized
DEBUG - 2018-07-21 19:14:38 --> No URI present. Default controller set.
INFO - 2018-07-21 19:14:38 --> Router Class Initialized
INFO - 2018-07-21 19:14:38 --> Output Class Initialized
INFO - 2018-07-21 19:14:38 --> Security Class Initialized
DEBUG - 2018-07-21 19:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:14:38 --> CSRF cookie sent
INFO - 2018-07-21 19:14:38 --> Input Class Initialized
INFO - 2018-07-21 19:14:38 --> Language Class Initialized
INFO - 2018-07-21 19:14:38 --> Loader Class Initialized
INFO - 2018-07-21 19:14:38 --> Helper loaded: url_helper
INFO - 2018-07-21 19:14:38 --> Helper loaded: form_helper
INFO - 2018-07-21 19:14:38 --> Helper loaded: language_helper
DEBUG - 2018-07-21 19:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:14:38 --> User Agent Class Initialized
INFO - 2018-07-21 19:14:38 --> Controller Class Initialized
INFO - 2018-07-21 19:14:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-21 19:14:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-21 19:14:38 --> Pixel_Model class loaded
INFO - 2018-07-21 19:14:38 --> Database Driver Class Initialized
INFO - 2018-07-21 19:14:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-21 19:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-21 19:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-21 19:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-21 19:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-21 19:14:38 --> Final output sent to browser
DEBUG - 2018-07-21 19:14:38 --> Total execution time: 0.0348

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-23 01:53:44 --> Config Class Initialized
INFO - 2018-07-23 01:53:44 --> Hooks Class Initialized
DEBUG - 2018-07-23 01:53:44 --> UTF-8 Support Enabled
INFO - 2018-07-23 01:53:44 --> Utf8 Class Initialized
INFO - 2018-07-23 01:53:44 --> URI Class Initialized
DEBUG - 2018-07-23 01:53:44 --> No URI present. Default controller set.
INFO - 2018-07-23 01:53:44 --> Router Class Initialized
INFO - 2018-07-23 01:53:44 --> Output Class Initialized
INFO - 2018-07-23 01:53:44 --> Security Class Initialized
DEBUG - 2018-07-23 01:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 01:53:44 --> CSRF cookie sent
INFO - 2018-07-23 01:53:44 --> Input Class Initialized
INFO - 2018-07-23 01:53:44 --> Language Class Initialized
INFO - 2018-07-23 01:53:44 --> Loader Class Initialized
INFO - 2018-07-23 01:53:44 --> Helper loaded: url_helper
INFO - 2018-07-23 01:53:44 --> Helper loaded: form_helper
INFO - 2018-07-23 01:53:44 --> Helper loaded: language_helper
DEBUG - 2018-07-23 01:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 01:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 01:53:44 --> User Agent Class Initialized
INFO - 2018-07-23 01:53:44 --> Controller Class Initialized
INFO - 2018-07-23 01:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 01:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 01:53:44 --> Pixel_Model class loaded
INFO - 2018-07-23 01:53:44 --> Database Driver Class Initialized
INFO - 2018-07-23 01:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 01:53:44 --> Final output sent to browser
DEBUG - 2018-07-23 01:53:44 --> Total execution time: 0.0341
INFO - 2018-07-23 08:34:03 --> Config Class Initialized
INFO - 2018-07-23 08:34:03 --> Hooks Class Initialized
DEBUG - 2018-07-23 08:34:03 --> UTF-8 Support Enabled
INFO - 2018-07-23 08:34:03 --> Utf8 Class Initialized
INFO - 2018-07-23 08:34:03 --> URI Class Initialized
DEBUG - 2018-07-23 08:34:03 --> No URI present. Default controller set.
INFO - 2018-07-23 08:34:03 --> Router Class Initialized
INFO - 2018-07-23 08:34:03 --> Output Class Initialized
INFO - 2018-07-23 08:34:03 --> Security Class Initialized
DEBUG - 2018-07-23 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 08:34:03 --> CSRF cookie sent
INFO - 2018-07-23 08:34:03 --> Input Class Initialized
INFO - 2018-07-23 08:34:03 --> Language Class Initialized
INFO - 2018-07-23 08:34:03 --> Loader Class Initialized
INFO - 2018-07-23 08:34:03 --> Helper loaded: url_helper
INFO - 2018-07-23 08:34:03 --> Helper loaded: form_helper
INFO - 2018-07-23 08:34:03 --> Helper loaded: language_helper
DEBUG - 2018-07-23 08:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 08:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 08:34:03 --> User Agent Class Initialized
INFO - 2018-07-23 08:34:03 --> Controller Class Initialized
INFO - 2018-07-23 08:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 08:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 08:34:03 --> Pixel_Model class loaded
INFO - 2018-07-23 08:34:03 --> Database Driver Class Initialized
INFO - 2018-07-23 08:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 08:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 08:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 08:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 08:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 08:34:03 --> Final output sent to browser
DEBUG - 2018-07-23 08:34:03 --> Total execution time: 0.0353
INFO - 2018-07-23 09:52:55 --> Config Class Initialized
INFO - 2018-07-23 09:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-23 09:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-23 09:52:55 --> Utf8 Class Initialized
INFO - 2018-07-23 09:52:55 --> URI Class Initialized
DEBUG - 2018-07-23 09:52:55 --> No URI present. Default controller set.
INFO - 2018-07-23 09:52:55 --> Router Class Initialized
INFO - 2018-07-23 09:52:55 --> Output Class Initialized
INFO - 2018-07-23 09:52:55 --> Security Class Initialized
DEBUG - 2018-07-23 09:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 09:52:55 --> CSRF cookie sent
INFO - 2018-07-23 09:52:55 --> Input Class Initialized
INFO - 2018-07-23 09:52:55 --> Language Class Initialized
INFO - 2018-07-23 09:52:55 --> Loader Class Initialized
INFO - 2018-07-23 09:52:55 --> Helper loaded: url_helper
INFO - 2018-07-23 09:52:55 --> Helper loaded: form_helper
INFO - 2018-07-23 09:52:55 --> Helper loaded: language_helper
DEBUG - 2018-07-23 09:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 09:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 09:52:55 --> User Agent Class Initialized
INFO - 2018-07-23 09:52:55 --> Controller Class Initialized
INFO - 2018-07-23 09:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 09:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 09:52:55 --> Pixel_Model class loaded
INFO - 2018-07-23 09:52:55 --> Database Driver Class Initialized
INFO - 2018-07-23 09:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 09:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 09:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 09:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 09:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 09:52:55 --> Final output sent to browser
DEBUG - 2018-07-23 09:52:55 --> Total execution time: 0.0475
INFO - 2018-07-23 14:48:03 --> Config Class Initialized
INFO - 2018-07-23 14:48:03 --> Hooks Class Initialized
DEBUG - 2018-07-23 14:48:03 --> UTF-8 Support Enabled
INFO - 2018-07-23 14:48:03 --> Utf8 Class Initialized
INFO - 2018-07-23 14:48:03 --> URI Class Initialized
INFO - 2018-07-23 14:48:03 --> Router Class Initialized
INFO - 2018-07-23 14:48:03 --> Output Class Initialized
INFO - 2018-07-23 14:48:03 --> Security Class Initialized
DEBUG - 2018-07-23 14:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 14:48:03 --> CSRF cookie sent
INFO - 2018-07-23 14:48:03 --> Input Class Initialized
INFO - 2018-07-23 14:48:03 --> Language Class Initialized
ERROR - 2018-07-23 14:48:03 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-23 14:48:06 --> Config Class Initialized
INFO - 2018-07-23 14:48:06 --> Hooks Class Initialized
DEBUG - 2018-07-23 14:48:06 --> UTF-8 Support Enabled
INFO - 2018-07-23 14:48:06 --> Utf8 Class Initialized
INFO - 2018-07-23 14:48:06 --> URI Class Initialized
DEBUG - 2018-07-23 14:48:06 --> No URI present. Default controller set.
INFO - 2018-07-23 14:48:06 --> Router Class Initialized
INFO - 2018-07-23 14:48:06 --> Output Class Initialized
INFO - 2018-07-23 14:48:06 --> Security Class Initialized
DEBUG - 2018-07-23 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 14:48:06 --> CSRF cookie sent
INFO - 2018-07-23 14:48:06 --> Input Class Initialized
INFO - 2018-07-23 14:48:06 --> Language Class Initialized
INFO - 2018-07-23 14:48:06 --> Loader Class Initialized
INFO - 2018-07-23 14:48:06 --> Helper loaded: url_helper
INFO - 2018-07-23 14:48:06 --> Helper loaded: form_helper
INFO - 2018-07-23 14:48:06 --> Helper loaded: language_helper
DEBUG - 2018-07-23 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 14:48:06 --> User Agent Class Initialized
INFO - 2018-07-23 14:48:06 --> Controller Class Initialized
INFO - 2018-07-23 14:48:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 14:48:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 14:48:06 --> Pixel_Model class loaded
INFO - 2018-07-23 14:48:06 --> Database Driver Class Initialized
INFO - 2018-07-23 14:48:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 14:48:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 14:48:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 14:48:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 14:48:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 14:48:06 --> Final output sent to browser
DEBUG - 2018-07-23 14:48:06 --> Total execution time: 0.0298
INFO - 2018-07-23 16:05:20 --> Config Class Initialized
INFO - 2018-07-23 16:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-23 16:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-23 16:05:20 --> Utf8 Class Initialized
INFO - 2018-07-23 16:05:20 --> URI Class Initialized
DEBUG - 2018-07-23 16:05:20 --> No URI present. Default controller set.
INFO - 2018-07-23 16:05:20 --> Router Class Initialized
INFO - 2018-07-23 16:05:20 --> Output Class Initialized
INFO - 2018-07-23 16:05:20 --> Security Class Initialized
DEBUG - 2018-07-23 16:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 16:05:20 --> CSRF cookie sent
INFO - 2018-07-23 16:05:20 --> Input Class Initialized
INFO - 2018-07-23 16:05:20 --> Language Class Initialized
INFO - 2018-07-23 16:05:20 --> Loader Class Initialized
INFO - 2018-07-23 16:05:20 --> Helper loaded: url_helper
INFO - 2018-07-23 16:05:20 --> Helper loaded: form_helper
INFO - 2018-07-23 16:05:20 --> Helper loaded: language_helper
DEBUG - 2018-07-23 16:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 16:05:20 --> User Agent Class Initialized
INFO - 2018-07-23 16:05:20 --> Controller Class Initialized
INFO - 2018-07-23 16:05:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 16:05:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 16:05:20 --> Pixel_Model class loaded
INFO - 2018-07-23 16:05:20 --> Database Driver Class Initialized
INFO - 2018-07-23 16:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 16:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 16:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 16:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 16:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 16:05:20 --> Final output sent to browser
DEBUG - 2018-07-23 16:05:20 --> Total execution time: 0.0362
INFO - 2018-07-23 17:27:40 --> Config Class Initialized
INFO - 2018-07-23 17:27:40 --> Hooks Class Initialized
DEBUG - 2018-07-23 17:27:40 --> UTF-8 Support Enabled
INFO - 2018-07-23 17:27:40 --> Utf8 Class Initialized
INFO - 2018-07-23 17:27:40 --> URI Class Initialized
INFO - 2018-07-23 17:27:40 --> Router Class Initialized
INFO - 2018-07-23 17:27:40 --> Output Class Initialized
INFO - 2018-07-23 17:27:40 --> Security Class Initialized
DEBUG - 2018-07-23 17:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 17:27:40 --> CSRF cookie sent
INFO - 2018-07-23 17:27:40 --> Input Class Initialized
INFO - 2018-07-23 17:27:40 --> Language Class Initialized
ERROR - 2018-07-23 17:27:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-23 18:01:22 --> Config Class Initialized
INFO - 2018-07-23 18:01:22 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:01:22 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:01:22 --> Utf8 Class Initialized
INFO - 2018-07-23 18:01:22 --> URI Class Initialized
INFO - 2018-07-23 18:01:22 --> Router Class Initialized
INFO - 2018-07-23 18:01:22 --> Output Class Initialized
INFO - 2018-07-23 18:01:22 --> Security Class Initialized
DEBUG - 2018-07-23 18:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:01:22 --> CSRF cookie sent
INFO - 2018-07-23 18:01:22 --> Input Class Initialized
INFO - 2018-07-23 18:01:22 --> Language Class Initialized
ERROR - 2018-07-23 18:01:22 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-23 18:01:25 --> Config Class Initialized
INFO - 2018-07-23 18:01:25 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:01:25 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:01:25 --> Utf8 Class Initialized
INFO - 2018-07-23 18:01:25 --> URI Class Initialized
INFO - 2018-07-23 18:01:25 --> Router Class Initialized
INFO - 2018-07-23 18:01:25 --> Output Class Initialized
INFO - 2018-07-23 18:01:25 --> Security Class Initialized
DEBUG - 2018-07-23 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:01:25 --> CSRF cookie sent
INFO - 2018-07-23 18:01:25 --> Input Class Initialized
INFO - 2018-07-23 18:01:25 --> Language Class Initialized
INFO - 2018-07-23 18:01:25 --> Loader Class Initialized
INFO - 2018-07-23 18:01:25 --> Helper loaded: url_helper
INFO - 2018-07-23 18:01:25 --> Helper loaded: form_helper
INFO - 2018-07-23 18:01:25 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:01:25 --> User Agent Class Initialized
INFO - 2018-07-23 18:01:25 --> Controller Class Initialized
INFO - 2018-07-23 18:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:01:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-23 18:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:01:25 --> Final output sent to browser
DEBUG - 2018-07-23 18:01:25 --> Total execution time: 0.0242
INFO - 2018-07-23 18:50:43 --> Config Class Initialized
INFO - 2018-07-23 18:50:43 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:43 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:43 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:43 --> URI Class Initialized
DEBUG - 2018-07-23 18:50:43 --> No URI present. Default controller set.
INFO - 2018-07-23 18:50:43 --> Router Class Initialized
INFO - 2018-07-23 18:50:43 --> Output Class Initialized
INFO - 2018-07-23 18:50:43 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:43 --> CSRF cookie sent
INFO - 2018-07-23 18:50:43 --> Input Class Initialized
INFO - 2018-07-23 18:50:43 --> Language Class Initialized
INFO - 2018-07-23 18:50:43 --> Loader Class Initialized
INFO - 2018-07-23 18:50:43 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:43 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:43 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:44 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:44 --> Controller Class Initialized
INFO - 2018-07-23 18:50:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:44 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:44 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 18:50:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:44 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:44 --> Total execution time: 0.0374
INFO - 2018-07-23 18:50:44 --> Config Class Initialized
INFO - 2018-07-23 18:50:44 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:44 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:44 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:44 --> URI Class Initialized
DEBUG - 2018-07-23 18:50:44 --> No URI present. Default controller set.
INFO - 2018-07-23 18:50:44 --> Router Class Initialized
INFO - 2018-07-23 18:50:44 --> Output Class Initialized
INFO - 2018-07-23 18:50:44 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:44 --> CSRF cookie sent
INFO - 2018-07-23 18:50:44 --> Input Class Initialized
INFO - 2018-07-23 18:50:44 --> Language Class Initialized
INFO - 2018-07-23 18:50:45 --> Loader Class Initialized
INFO - 2018-07-23 18:50:45 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:45 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:45 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:45 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:45 --> Controller Class Initialized
INFO - 2018-07-23 18:50:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:45 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:45 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:45 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:45 --> Total execution time: 0.0297
INFO - 2018-07-23 18:50:45 --> Config Class Initialized
INFO - 2018-07-23 18:50:45 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:45 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:45 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:45 --> URI Class Initialized
DEBUG - 2018-07-23 18:50:45 --> No URI present. Default controller set.
INFO - 2018-07-23 18:50:45 --> Router Class Initialized
INFO - 2018-07-23 18:50:45 --> Output Class Initialized
INFO - 2018-07-23 18:50:45 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:45 --> CSRF cookie sent
INFO - 2018-07-23 18:50:45 --> Input Class Initialized
INFO - 2018-07-23 18:50:45 --> Language Class Initialized
INFO - 2018-07-23 18:50:45 --> Loader Class Initialized
INFO - 2018-07-23 18:50:45 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:45 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:45 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:45 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:45 --> Controller Class Initialized
INFO - 2018-07-23 18:50:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:45 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:45 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 18:50:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:45 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:45 --> Total execution time: 0.0326
INFO - 2018-07-23 18:50:46 --> Config Class Initialized
INFO - 2018-07-23 18:50:46 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:46 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:46 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:46 --> URI Class Initialized
INFO - 2018-07-23 18:50:46 --> Router Class Initialized
INFO - 2018-07-23 18:50:46 --> Output Class Initialized
INFO - 2018-07-23 18:50:46 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:46 --> CSRF cookie sent
INFO - 2018-07-23 18:50:46 --> Input Class Initialized
INFO - 2018-07-23 18:50:46 --> Language Class Initialized
ERROR - 2018-07-23 18:50:46 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-23 18:50:53 --> Config Class Initialized
INFO - 2018-07-23 18:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:53 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:53 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:53 --> URI Class Initialized
DEBUG - 2018-07-23 18:50:53 --> No URI present. Default controller set.
INFO - 2018-07-23 18:50:53 --> Router Class Initialized
INFO - 2018-07-23 18:50:53 --> Output Class Initialized
INFO - 2018-07-23 18:50:53 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:53 --> CSRF cookie sent
INFO - 2018-07-23 18:50:53 --> Input Class Initialized
INFO - 2018-07-23 18:50:53 --> Language Class Initialized
INFO - 2018-07-23 18:50:53 --> Loader Class Initialized
INFO - 2018-07-23 18:50:53 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:53 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:53 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:53 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:53 --> Controller Class Initialized
INFO - 2018-07-23 18:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:53 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:53 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 18:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:53 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:53 --> Total execution time: 0.0339
INFO - 2018-07-23 18:50:53 --> Config Class Initialized
INFO - 2018-07-23 18:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:53 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:53 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:53 --> URI Class Initialized
INFO - 2018-07-23 18:50:53 --> Router Class Initialized
INFO - 2018-07-23 18:50:53 --> Output Class Initialized
INFO - 2018-07-23 18:50:53 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:54 --> CSRF cookie sent
INFO - 2018-07-23 18:50:54 --> Input Class Initialized
INFO - 2018-07-23 18:50:54 --> Language Class Initialized
ERROR - 2018-07-23 18:50:54 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-23 18:50:54 --> Config Class Initialized
INFO - 2018-07-23 18:50:54 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:54 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:54 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:54 --> URI Class Initialized
INFO - 2018-07-23 18:50:54 --> Router Class Initialized
INFO - 2018-07-23 18:50:54 --> Output Class Initialized
INFO - 2018-07-23 18:50:54 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:54 --> CSRF cookie sent
INFO - 2018-07-23 18:50:54 --> Input Class Initialized
INFO - 2018-07-23 18:50:54 --> Language Class Initialized
ERROR - 2018-07-23 18:50:54 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-23 18:50:54 --> Config Class Initialized
INFO - 2018-07-23 18:50:54 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:54 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:54 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:54 --> URI Class Initialized
INFO - 2018-07-23 18:50:54 --> Router Class Initialized
INFO - 2018-07-23 18:50:54 --> Output Class Initialized
INFO - 2018-07-23 18:50:54 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:54 --> CSRF cookie sent
INFO - 2018-07-23 18:50:54 --> Input Class Initialized
INFO - 2018-07-23 18:50:54 --> Language Class Initialized
INFO - 2018-07-23 18:50:54 --> Loader Class Initialized
INFO - 2018-07-23 18:50:54 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:54 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:54 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:54 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:54 --> Controller Class Initialized
INFO - 2018-07-23 18:50:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:54 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:54 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:54 --> Config Class Initialized
INFO - 2018-07-23 18:50:54 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:54 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:54 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:54 --> URI Class Initialized
INFO - 2018-07-23 18:50:54 --> Router Class Initialized
INFO - 2018-07-23 18:50:54 --> Output Class Initialized
INFO - 2018-07-23 18:50:54 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:54 --> CSRF cookie sent
INFO - 2018-07-23 18:50:54 --> Input Class Initialized
INFO - 2018-07-23 18:50:54 --> Language Class Initialized
INFO - 2018-07-23 18:50:54 --> Loader Class Initialized
INFO - 2018-07-23 18:50:54 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:54 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:54 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:54 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:54 --> Controller Class Initialized
INFO - 2018-07-23 18:50:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-23 18:50:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-23 18:50:54 --> Could not find the language line "req_email"
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-23 18:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:54 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:54 --> Total execution time: 0.0211
INFO - 2018-07-23 18:50:55 --> Config Class Initialized
INFO - 2018-07-23 18:50:55 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:55 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:55 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:55 --> URI Class Initialized
INFO - 2018-07-23 18:50:55 --> Router Class Initialized
INFO - 2018-07-23 18:50:55 --> Output Class Initialized
INFO - 2018-07-23 18:50:55 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:55 --> CSRF cookie sent
INFO - 2018-07-23 18:50:55 --> Input Class Initialized
INFO - 2018-07-23 18:50:55 --> Language Class Initialized
INFO - 2018-07-23 18:50:55 --> Loader Class Initialized
INFO - 2018-07-23 18:50:55 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:55 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:55 --> Controller Class Initialized
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:55 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:55 --> Total execution time: 0.0240
INFO - 2018-07-23 18:50:55 --> Config Class Initialized
INFO - 2018-07-23 18:50:55 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:55 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:55 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:55 --> URI Class Initialized
INFO - 2018-07-23 18:50:55 --> Router Class Initialized
INFO - 2018-07-23 18:50:55 --> Output Class Initialized
INFO - 2018-07-23 18:50:55 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:55 --> CSRF cookie sent
INFO - 2018-07-23 18:50:55 --> Input Class Initialized
INFO - 2018-07-23 18:50:55 --> Language Class Initialized
INFO - 2018-07-23 18:50:55 --> Loader Class Initialized
INFO - 2018-07-23 18:50:55 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:55 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:55 --> Controller Class Initialized
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:55 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:55 --> Total execution time: 0.0223
INFO - 2018-07-23 18:50:55 --> Config Class Initialized
INFO - 2018-07-23 18:50:55 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:55 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:55 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:55 --> URI Class Initialized
INFO - 2018-07-23 18:50:55 --> Router Class Initialized
INFO - 2018-07-23 18:50:55 --> Output Class Initialized
INFO - 2018-07-23 18:50:55 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:55 --> CSRF cookie sent
INFO - 2018-07-23 18:50:55 --> Input Class Initialized
INFO - 2018-07-23 18:50:55 --> Language Class Initialized
INFO - 2018-07-23 18:50:55 --> Loader Class Initialized
INFO - 2018-07-23 18:50:55 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:55 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:55 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:55 --> Controller Class Initialized
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-23 18:50:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:55 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:55 --> Total execution time: 0.0240
INFO - 2018-07-23 18:50:56 --> Config Class Initialized
INFO - 2018-07-23 18:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:56 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:56 --> URI Class Initialized
INFO - 2018-07-23 18:50:56 --> Router Class Initialized
INFO - 2018-07-23 18:50:56 --> Output Class Initialized
INFO - 2018-07-23 18:50:56 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:56 --> CSRF cookie sent
INFO - 2018-07-23 18:50:56 --> Input Class Initialized
INFO - 2018-07-23 18:50:56 --> Language Class Initialized
INFO - 2018-07-23 18:50:56 --> Loader Class Initialized
INFO - 2018-07-23 18:50:56 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:56 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:56 --> Controller Class Initialized
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:56 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:56 --> Total execution time: 0.0211
INFO - 2018-07-23 18:50:56 --> Config Class Initialized
INFO - 2018-07-23 18:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:56 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:56 --> URI Class Initialized
INFO - 2018-07-23 18:50:56 --> Router Class Initialized
INFO - 2018-07-23 18:50:56 --> Output Class Initialized
INFO - 2018-07-23 18:50:56 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:56 --> CSRF cookie sent
INFO - 2018-07-23 18:50:56 --> Input Class Initialized
INFO - 2018-07-23 18:50:56 --> Language Class Initialized
INFO - 2018-07-23 18:50:56 --> Loader Class Initialized
INFO - 2018-07-23 18:50:56 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:56 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:56 --> Controller Class Initialized
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-23 18:50:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-23 18:50:56 --> Could not find the language line "req_email"
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:56 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:56 --> Total execution time: 0.0217
INFO - 2018-07-23 18:50:56 --> Config Class Initialized
INFO - 2018-07-23 18:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-23 18:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-23 18:50:56 --> Utf8 Class Initialized
INFO - 2018-07-23 18:50:56 --> URI Class Initialized
INFO - 2018-07-23 18:50:56 --> Router Class Initialized
INFO - 2018-07-23 18:50:56 --> Output Class Initialized
INFO - 2018-07-23 18:50:56 --> Security Class Initialized
DEBUG - 2018-07-23 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 18:50:56 --> CSRF cookie sent
INFO - 2018-07-23 18:50:56 --> Input Class Initialized
INFO - 2018-07-23 18:50:56 --> Language Class Initialized
INFO - 2018-07-23 18:50:56 --> Loader Class Initialized
INFO - 2018-07-23 18:50:56 --> Helper loaded: url_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: form_helper
INFO - 2018-07-23 18:50:56 --> Helper loaded: language_helper
DEBUG - 2018-07-23 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 18:50:56 --> User Agent Class Initialized
INFO - 2018-07-23 18:50:56 --> Controller Class Initialized
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 18:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 18:50:56 --> Pixel_Model class loaded
INFO - 2018-07-23 18:50:56 --> Database Driver Class Initialized
INFO - 2018-07-23 18:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-23 18:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 18:50:56 --> Final output sent to browser
DEBUG - 2018-07-23 18:50:56 --> Total execution time: 0.0333
INFO - 2018-07-23 19:24:38 --> Config Class Initialized
INFO - 2018-07-23 19:24:38 --> Hooks Class Initialized
DEBUG - 2018-07-23 19:24:38 --> UTF-8 Support Enabled
INFO - 2018-07-23 19:24:38 --> Utf8 Class Initialized
INFO - 2018-07-23 19:24:38 --> URI Class Initialized
DEBUG - 2018-07-23 19:24:38 --> No URI present. Default controller set.
INFO - 2018-07-23 19:24:38 --> Router Class Initialized
INFO - 2018-07-23 19:24:39 --> Output Class Initialized
INFO - 2018-07-23 19:24:39 --> Security Class Initialized
DEBUG - 2018-07-23 19:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 19:24:39 --> CSRF cookie sent
INFO - 2018-07-23 19:24:39 --> Input Class Initialized
INFO - 2018-07-23 19:24:39 --> Language Class Initialized
INFO - 2018-07-23 19:24:39 --> Loader Class Initialized
INFO - 2018-07-23 19:24:39 --> Helper loaded: url_helper
INFO - 2018-07-23 19:24:39 --> Helper loaded: form_helper
INFO - 2018-07-23 19:24:39 --> Helper loaded: language_helper
DEBUG - 2018-07-23 19:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 19:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 19:24:39 --> User Agent Class Initialized
INFO - 2018-07-23 19:24:39 --> Controller Class Initialized
INFO - 2018-07-23 19:24:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 19:24:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 19:24:39 --> Pixel_Model class loaded
INFO - 2018-07-23 19:24:39 --> Database Driver Class Initialized
INFO - 2018-07-23 19:24:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 19:24:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 19:24:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 19:24:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 19:24:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 19:24:39 --> Final output sent to browser
DEBUG - 2018-07-23 19:24:39 --> Total execution time: 0.0368
INFO - 2018-07-23 21:50:22 --> Config Class Initialized
INFO - 2018-07-23 21:50:22 --> Hooks Class Initialized
DEBUG - 2018-07-23 21:50:22 --> UTF-8 Support Enabled
INFO - 2018-07-23 21:50:22 --> Utf8 Class Initialized
INFO - 2018-07-23 21:50:22 --> URI Class Initialized
DEBUG - 2018-07-23 21:50:22 --> No URI present. Default controller set.
INFO - 2018-07-23 21:50:22 --> Router Class Initialized
INFO - 2018-07-23 21:50:22 --> Output Class Initialized
INFO - 2018-07-23 21:50:22 --> Security Class Initialized
DEBUG - 2018-07-23 21:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 21:50:22 --> CSRF cookie sent
INFO - 2018-07-23 21:50:22 --> Input Class Initialized
INFO - 2018-07-23 21:50:22 --> Language Class Initialized
INFO - 2018-07-23 21:50:22 --> Loader Class Initialized
INFO - 2018-07-23 21:50:22 --> Helper loaded: url_helper
INFO - 2018-07-23 21:50:22 --> Helper loaded: form_helper
INFO - 2018-07-23 21:50:22 --> Helper loaded: language_helper
DEBUG - 2018-07-23 21:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-23 21:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-23 21:50:22 --> User Agent Class Initialized
INFO - 2018-07-23 21:50:22 --> Controller Class Initialized
INFO - 2018-07-23 21:50:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-23 21:50:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-23 21:50:22 --> Pixel_Model class loaded
INFO - 2018-07-23 21:50:22 --> Database Driver Class Initialized
INFO - 2018-07-23 21:50:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-23 21:50:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-23 21:50:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-23 21:50:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-23 21:50:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-23 21:50:22 --> Final output sent to browser
DEBUG - 2018-07-23 21:50:22 --> Total execution time: 0.0337

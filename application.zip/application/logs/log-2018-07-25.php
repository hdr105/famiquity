<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-25 01:57:07 --> Config Class Initialized
INFO - 2018-07-25 01:57:07 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:57:07 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:57:07 --> Utf8 Class Initialized
INFO - 2018-07-25 01:57:07 --> URI Class Initialized
DEBUG - 2018-07-25 01:57:07 --> No URI present. Default controller set.
INFO - 2018-07-25 01:57:07 --> Router Class Initialized
INFO - 2018-07-25 01:57:07 --> Output Class Initialized
INFO - 2018-07-25 01:57:07 --> Security Class Initialized
DEBUG - 2018-07-25 01:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:57:07 --> CSRF cookie sent
INFO - 2018-07-25 01:57:07 --> Input Class Initialized
INFO - 2018-07-25 01:57:07 --> Language Class Initialized
INFO - 2018-07-25 01:57:07 --> Loader Class Initialized
INFO - 2018-07-25 01:57:07 --> Helper loaded: url_helper
INFO - 2018-07-25 01:57:07 --> Helper loaded: form_helper
INFO - 2018-07-25 01:57:07 --> Helper loaded: language_helper
DEBUG - 2018-07-25 01:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:57:07 --> User Agent Class Initialized
INFO - 2018-07-25 01:57:07 --> Controller Class Initialized
INFO - 2018-07-25 01:57:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 01:57:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 01:57:07 --> Pixel_Model class loaded
INFO - 2018-07-25 01:57:07 --> Database Driver Class Initialized
INFO - 2018-07-25 01:57:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 01:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 01:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 01:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 01:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 01:57:07 --> Final output sent to browser
DEBUG - 2018-07-25 01:57:07 --> Total execution time: 0.0471
INFO - 2018-07-25 06:29:42 --> Config Class Initialized
INFO - 2018-07-25 06:29:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 06:29:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 06:29:42 --> Utf8 Class Initialized
INFO - 2018-07-25 06:29:42 --> URI Class Initialized
DEBUG - 2018-07-25 06:29:42 --> No URI present. Default controller set.
INFO - 2018-07-25 06:29:42 --> Router Class Initialized
INFO - 2018-07-25 06:29:42 --> Output Class Initialized
INFO - 2018-07-25 06:29:42 --> Security Class Initialized
DEBUG - 2018-07-25 06:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 06:29:42 --> CSRF cookie sent
INFO - 2018-07-25 06:29:42 --> Input Class Initialized
INFO - 2018-07-25 06:29:42 --> Language Class Initialized
INFO - 2018-07-25 06:29:42 --> Loader Class Initialized
INFO - 2018-07-25 06:29:42 --> Helper loaded: url_helper
INFO - 2018-07-25 06:29:42 --> Helper loaded: form_helper
INFO - 2018-07-25 06:29:42 --> Helper loaded: language_helper
DEBUG - 2018-07-25 06:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 06:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 06:29:42 --> User Agent Class Initialized
INFO - 2018-07-25 06:29:42 --> Controller Class Initialized
INFO - 2018-07-25 06:29:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 06:29:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 06:29:42 --> Pixel_Model class loaded
INFO - 2018-07-25 06:29:42 --> Database Driver Class Initialized
INFO - 2018-07-25 06:29:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 06:29:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 06:29:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 06:29:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 06:29:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 06:29:42 --> Final output sent to browser
DEBUG - 2018-07-25 06:29:42 --> Total execution time: 0.0351
INFO - 2018-07-25 07:50:59 --> Config Class Initialized
INFO - 2018-07-25 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 07:50:59 --> Utf8 Class Initialized
INFO - 2018-07-25 07:50:59 --> URI Class Initialized
INFO - 2018-07-25 07:50:59 --> Router Class Initialized
INFO - 2018-07-25 07:50:59 --> Output Class Initialized
INFO - 2018-07-25 07:50:59 --> Security Class Initialized
DEBUG - 2018-07-25 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 07:50:59 --> CSRF cookie sent
INFO - 2018-07-25 07:50:59 --> Input Class Initialized
INFO - 2018-07-25 07:50:59 --> Language Class Initialized
ERROR - 2018-07-25 07:50:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-25 07:50:59 --> Config Class Initialized
INFO - 2018-07-25 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 07:50:59 --> Utf8 Class Initialized
INFO - 2018-07-25 07:50:59 --> URI Class Initialized
INFO - 2018-07-25 07:50:59 --> Router Class Initialized
INFO - 2018-07-25 07:50:59 --> Output Class Initialized
INFO - 2018-07-25 07:50:59 --> Security Class Initialized
DEBUG - 2018-07-25 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 07:50:59 --> CSRF cookie sent
INFO - 2018-07-25 07:50:59 --> Input Class Initialized
INFO - 2018-07-25 07:50:59 --> Language Class Initialized
INFO - 2018-07-25 07:50:59 --> Loader Class Initialized
INFO - 2018-07-25 07:50:59 --> Helper loaded: url_helper
INFO - 2018-07-25 07:50:59 --> Helper loaded: form_helper
INFO - 2018-07-25 07:50:59 --> Helper loaded: language_helper
DEBUG - 2018-07-25 07:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 07:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 07:50:59 --> User Agent Class Initialized
INFO - 2018-07-25 07:50:59 --> Controller Class Initialized
INFO - 2018-07-25 07:50:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 07:50:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 07:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 07:50:59 --> Final output sent to browser
DEBUG - 2018-07-25 07:50:59 --> Total execution time: 0.0341
INFO - 2018-07-25 07:51:02 --> Config Class Initialized
INFO - 2018-07-25 07:51:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 07:51:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 07:51:02 --> Utf8 Class Initialized
INFO - 2018-07-25 07:51:02 --> URI Class Initialized
INFO - 2018-07-25 07:51:02 --> Router Class Initialized
INFO - 2018-07-25 07:51:02 --> Output Class Initialized
INFO - 2018-07-25 07:51:02 --> Security Class Initialized
DEBUG - 2018-07-25 07:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 07:51:02 --> CSRF cookie sent
INFO - 2018-07-25 07:51:02 --> Input Class Initialized
INFO - 2018-07-25 07:51:02 --> Language Class Initialized
INFO - 2018-07-25 07:51:02 --> Loader Class Initialized
INFO - 2018-07-25 07:51:02 --> Helper loaded: url_helper
INFO - 2018-07-25 07:51:02 --> Helper loaded: form_helper
INFO - 2018-07-25 07:51:02 --> Helper loaded: language_helper
DEBUG - 2018-07-25 07:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 07:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 07:51:02 --> User Agent Class Initialized
INFO - 2018-07-25 07:51:02 --> Controller Class Initialized
INFO - 2018-07-25 07:51:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 07:51:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 07:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 07:51:02 --> Final output sent to browser
DEBUG - 2018-07-25 07:51:02 --> Total execution time: 0.0225
INFO - 2018-07-25 08:21:30 --> Config Class Initialized
INFO - 2018-07-25 08:21:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 08:21:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 08:21:30 --> Utf8 Class Initialized
INFO - 2018-07-25 08:21:30 --> URI Class Initialized
DEBUG - 2018-07-25 08:21:30 --> No URI present. Default controller set.
INFO - 2018-07-25 08:21:30 --> Router Class Initialized
INFO - 2018-07-25 08:21:30 --> Output Class Initialized
INFO - 2018-07-25 08:21:30 --> Security Class Initialized
DEBUG - 2018-07-25 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 08:21:30 --> CSRF cookie sent
INFO - 2018-07-25 08:21:30 --> Input Class Initialized
INFO - 2018-07-25 08:21:30 --> Language Class Initialized
INFO - 2018-07-25 08:21:30 --> Loader Class Initialized
INFO - 2018-07-25 08:21:30 --> Helper loaded: url_helper
INFO - 2018-07-25 08:21:30 --> Helper loaded: form_helper
INFO - 2018-07-25 08:21:30 --> Helper loaded: language_helper
DEBUG - 2018-07-25 08:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 08:21:30 --> User Agent Class Initialized
INFO - 2018-07-25 08:21:30 --> Controller Class Initialized
INFO - 2018-07-25 08:21:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 08:21:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 08:21:30 --> Pixel_Model class loaded
INFO - 2018-07-25 08:21:30 --> Database Driver Class Initialized
INFO - 2018-07-25 08:21:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 08:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 08:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 08:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 08:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 08:21:30 --> Final output sent to browser
DEBUG - 2018-07-25 08:21:30 --> Total execution time: 0.0345
INFO - 2018-07-25 09:37:37 --> Config Class Initialized
INFO - 2018-07-25 09:37:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 09:37:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 09:37:37 --> Utf8 Class Initialized
INFO - 2018-07-25 09:37:37 --> URI Class Initialized
INFO - 2018-07-25 09:37:37 --> Router Class Initialized
INFO - 2018-07-25 09:37:37 --> Output Class Initialized
INFO - 2018-07-25 09:37:37 --> Security Class Initialized
DEBUG - 2018-07-25 09:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 09:37:37 --> CSRF cookie sent
INFO - 2018-07-25 09:37:37 --> Input Class Initialized
INFO - 2018-07-25 09:37:37 --> Language Class Initialized
ERROR - 2018-07-25 09:37:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-25 09:37:37 --> Config Class Initialized
INFO - 2018-07-25 09:37:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 09:37:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 09:37:37 --> Utf8 Class Initialized
INFO - 2018-07-25 09:37:37 --> URI Class Initialized
DEBUG - 2018-07-25 09:37:37 --> No URI present. Default controller set.
INFO - 2018-07-25 09:37:37 --> Router Class Initialized
INFO - 2018-07-25 09:37:37 --> Output Class Initialized
INFO - 2018-07-25 09:37:37 --> Security Class Initialized
DEBUG - 2018-07-25 09:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 09:37:37 --> CSRF cookie sent
INFO - 2018-07-25 09:37:37 --> Input Class Initialized
INFO - 2018-07-25 09:37:37 --> Language Class Initialized
INFO - 2018-07-25 09:37:37 --> Loader Class Initialized
INFO - 2018-07-25 09:37:37 --> Helper loaded: url_helper
INFO - 2018-07-25 09:37:37 --> Helper loaded: form_helper
INFO - 2018-07-25 09:37:37 --> Helper loaded: language_helper
DEBUG - 2018-07-25 09:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 09:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 09:37:37 --> User Agent Class Initialized
INFO - 2018-07-25 09:37:37 --> Controller Class Initialized
INFO - 2018-07-25 09:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 09:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 09:37:37 --> Pixel_Model class loaded
INFO - 2018-07-25 09:37:37 --> Database Driver Class Initialized
INFO - 2018-07-25 09:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 09:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 09:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 09:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 09:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 09:37:37 --> Final output sent to browser
DEBUG - 2018-07-25 09:37:37 --> Total execution time: 0.0289
INFO - 2018-07-25 10:17:25 --> Config Class Initialized
INFO - 2018-07-25 10:17:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 10:17:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 10:17:25 --> Utf8 Class Initialized
INFO - 2018-07-25 10:17:25 --> URI Class Initialized
DEBUG - 2018-07-25 10:17:25 --> No URI present. Default controller set.
INFO - 2018-07-25 10:17:25 --> Router Class Initialized
INFO - 2018-07-25 10:17:25 --> Output Class Initialized
INFO - 2018-07-25 10:17:25 --> Security Class Initialized
DEBUG - 2018-07-25 10:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 10:17:25 --> CSRF cookie sent
INFO - 2018-07-25 10:17:25 --> Input Class Initialized
INFO - 2018-07-25 10:17:25 --> Language Class Initialized
INFO - 2018-07-25 10:17:25 --> Loader Class Initialized
INFO - 2018-07-25 10:17:25 --> Helper loaded: url_helper
INFO - 2018-07-25 10:17:25 --> Helper loaded: form_helper
INFO - 2018-07-25 10:17:25 --> Helper loaded: language_helper
DEBUG - 2018-07-25 10:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 10:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 10:17:25 --> User Agent Class Initialized
INFO - 2018-07-25 10:17:25 --> Controller Class Initialized
INFO - 2018-07-25 10:17:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 10:17:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 10:17:25 --> Pixel_Model class loaded
INFO - 2018-07-25 10:17:25 --> Database Driver Class Initialized
INFO - 2018-07-25 10:17:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 10:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 10:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 10:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 10:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 10:17:25 --> Final output sent to browser
DEBUG - 2018-07-25 10:17:25 --> Total execution time: 0.0467
INFO - 2018-07-25 10:24:38 --> Config Class Initialized
INFO - 2018-07-25 10:24:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 10:24:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 10:24:38 --> Utf8 Class Initialized
INFO - 2018-07-25 10:24:38 --> URI Class Initialized
DEBUG - 2018-07-25 10:24:38 --> No URI present. Default controller set.
INFO - 2018-07-25 10:24:38 --> Router Class Initialized
INFO - 2018-07-25 10:24:38 --> Output Class Initialized
INFO - 2018-07-25 10:24:38 --> Security Class Initialized
DEBUG - 2018-07-25 10:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 10:24:38 --> CSRF cookie sent
INFO - 2018-07-25 10:24:38 --> Input Class Initialized
INFO - 2018-07-25 10:24:38 --> Language Class Initialized
INFO - 2018-07-25 10:24:38 --> Loader Class Initialized
INFO - 2018-07-25 10:24:38 --> Helper loaded: url_helper
INFO - 2018-07-25 10:24:38 --> Helper loaded: form_helper
INFO - 2018-07-25 10:24:38 --> Helper loaded: language_helper
DEBUG - 2018-07-25 10:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 10:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 10:24:38 --> User Agent Class Initialized
INFO - 2018-07-25 10:24:38 --> Controller Class Initialized
INFO - 2018-07-25 10:24:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 10:24:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 10:24:38 --> Pixel_Model class loaded
INFO - 2018-07-25 10:24:38 --> Database Driver Class Initialized
INFO - 2018-07-25 10:24:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 10:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 10:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 10:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 10:24:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 10:24:38 --> Final output sent to browser
DEBUG - 2018-07-25 10:24:38 --> Total execution time: 0.0383
INFO - 2018-07-25 10:27:58 --> Config Class Initialized
INFO - 2018-07-25 10:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 10:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 10:27:58 --> Utf8 Class Initialized
INFO - 2018-07-25 10:27:58 --> URI Class Initialized
DEBUG - 2018-07-25 10:27:58 --> No URI present. Default controller set.
INFO - 2018-07-25 10:27:58 --> Router Class Initialized
INFO - 2018-07-25 10:27:58 --> Output Class Initialized
INFO - 2018-07-25 10:27:58 --> Security Class Initialized
DEBUG - 2018-07-25 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 10:27:58 --> CSRF cookie sent
INFO - 2018-07-25 10:27:58 --> Input Class Initialized
INFO - 2018-07-25 10:27:58 --> Language Class Initialized
INFO - 2018-07-25 10:27:58 --> Loader Class Initialized
INFO - 2018-07-25 10:27:58 --> Helper loaded: url_helper
INFO - 2018-07-25 10:27:58 --> Helper loaded: form_helper
INFO - 2018-07-25 10:27:58 --> Helper loaded: language_helper
DEBUG - 2018-07-25 10:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 10:27:58 --> User Agent Class Initialized
INFO - 2018-07-25 10:27:58 --> Controller Class Initialized
INFO - 2018-07-25 10:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 10:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 10:27:58 --> Pixel_Model class loaded
INFO - 2018-07-25 10:27:58 --> Database Driver Class Initialized
INFO - 2018-07-25 10:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 10:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 10:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 10:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 10:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 10:27:58 --> Final output sent to browser
DEBUG - 2018-07-25 10:27:58 --> Total execution time: 0.0354
INFO - 2018-07-25 11:39:41 --> Config Class Initialized
INFO - 2018-07-25 11:39:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 11:39:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 11:39:41 --> Utf8 Class Initialized
INFO - 2018-07-25 11:39:41 --> URI Class Initialized
DEBUG - 2018-07-25 11:39:41 --> No URI present. Default controller set.
INFO - 2018-07-25 11:39:41 --> Router Class Initialized
INFO - 2018-07-25 11:39:41 --> Output Class Initialized
INFO - 2018-07-25 11:39:41 --> Security Class Initialized
DEBUG - 2018-07-25 11:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 11:39:41 --> CSRF cookie sent
INFO - 2018-07-25 11:39:41 --> Input Class Initialized
INFO - 2018-07-25 11:39:41 --> Language Class Initialized
INFO - 2018-07-25 11:39:41 --> Loader Class Initialized
INFO - 2018-07-25 11:39:41 --> Helper loaded: url_helper
INFO - 2018-07-25 11:39:41 --> Helper loaded: form_helper
INFO - 2018-07-25 11:39:41 --> Helper loaded: language_helper
DEBUG - 2018-07-25 11:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 11:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 11:39:41 --> User Agent Class Initialized
INFO - 2018-07-25 11:39:41 --> Controller Class Initialized
INFO - 2018-07-25 11:39:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 11:39:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 11:39:41 --> Pixel_Model class loaded
INFO - 2018-07-25 11:39:41 --> Database Driver Class Initialized
INFO - 2018-07-25 11:39:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 11:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 11:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 11:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 11:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 11:39:41 --> Final output sent to browser
DEBUG - 2018-07-25 11:39:41 --> Total execution time: 0.0337
INFO - 2018-07-25 12:15:52 --> Config Class Initialized
INFO - 2018-07-25 12:15:52 --> Config Class Initialized
INFO - 2018-07-25 12:15:52 --> Hooks Class Initialized
INFO - 2018-07-25 12:15:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:15:52 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 12:15:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:15:52 --> Utf8 Class Initialized
INFO - 2018-07-25 12:15:52 --> Utf8 Class Initialized
INFO - 2018-07-25 12:15:52 --> URI Class Initialized
INFO - 2018-07-25 12:15:52 --> URI Class Initialized
DEBUG - 2018-07-25 12:15:52 --> No URI present. Default controller set.
DEBUG - 2018-07-25 12:15:52 --> No URI present. Default controller set.
INFO - 2018-07-25 12:15:52 --> Router Class Initialized
INFO - 2018-07-25 12:15:52 --> Router Class Initialized
INFO - 2018-07-25 12:15:52 --> Output Class Initialized
INFO - 2018-07-25 12:15:52 --> Output Class Initialized
INFO - 2018-07-25 12:15:52 --> Security Class Initialized
INFO - 2018-07-25 12:15:52 --> Security Class Initialized
DEBUG - 2018-07-25 12:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 12:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:15:52 --> CSRF cookie sent
INFO - 2018-07-25 12:15:52 --> Input Class Initialized
INFO - 2018-07-25 12:15:52 --> CSRF cookie sent
INFO - 2018-07-25 12:15:52 --> Input Class Initialized
INFO - 2018-07-25 12:15:52 --> Language Class Initialized
INFO - 2018-07-25 12:15:52 --> Language Class Initialized
INFO - 2018-07-25 12:15:52 --> Loader Class Initialized
INFO - 2018-07-25 12:15:52 --> Loader Class Initialized
INFO - 2018-07-25 12:15:52 --> Helper loaded: url_helper
INFO - 2018-07-25 12:15:52 --> Helper loaded: url_helper
INFO - 2018-07-25 12:15:52 --> Helper loaded: form_helper
INFO - 2018-07-25 12:15:52 --> Helper loaded: form_helper
INFO - 2018-07-25 12:15:52 --> Helper loaded: language_helper
INFO - 2018-07-25 12:15:52 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-25 12:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:15:52 --> User Agent Class Initialized
INFO - 2018-07-25 12:15:52 --> User Agent Class Initialized
INFO - 2018-07-25 12:15:52 --> Controller Class Initialized
INFO - 2018-07-25 12:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:15:52 --> Controller Class Initialized
INFO - 2018-07-25 12:15:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:15:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:15:52 --> Pixel_Model class loaded
INFO - 2018-07-25 12:15:52 --> Pixel_Model class loaded
INFO - 2018-07-25 12:15:52 --> Database Driver Class Initialized
INFO - 2018-07-25 12:15:52 --> Database Driver Class Initialized
INFO - 2018-07-25 12:15:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:15:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:15:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:15:52 --> Final output sent to browser
DEBUG - 2018-07-25 12:15:52 --> Total execution time: 0.0446
INFO - 2018-07-25 12:15:52 --> Final output sent to browser
DEBUG - 2018-07-25 12:15:52 --> Total execution time: 0.0455
INFO - 2018-07-25 12:16:06 --> Config Class Initialized
INFO - 2018-07-25 12:16:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:16:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:16:06 --> Utf8 Class Initialized
INFO - 2018-07-25 12:16:06 --> URI Class Initialized
INFO - 2018-07-25 12:16:06 --> Router Class Initialized
INFO - 2018-07-25 12:16:06 --> Output Class Initialized
INFO - 2018-07-25 12:16:06 --> Security Class Initialized
DEBUG - 2018-07-25 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:16:06 --> CSRF cookie sent
INFO - 2018-07-25 12:16:06 --> Input Class Initialized
INFO - 2018-07-25 12:16:06 --> Language Class Initialized
INFO - 2018-07-25 12:16:06 --> Loader Class Initialized
INFO - 2018-07-25 12:16:06 --> Helper loaded: url_helper
INFO - 2018-07-25 12:16:06 --> Helper loaded: form_helper
INFO - 2018-07-25 12:16:06 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:16:06 --> User Agent Class Initialized
INFO - 2018-07-25 12:16:06 --> Controller Class Initialized
INFO - 2018-07-25 12:16:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:16:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:16:06 --> Pixel_Model class loaded
INFO - 2018-07-25 12:16:06 --> Database Driver Class Initialized
INFO - 2018-07-25 12:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:16:06 --> Config Class Initialized
INFO - 2018-07-25 12:16:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:16:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:16:06 --> Utf8 Class Initialized
INFO - 2018-07-25 12:16:06 --> URI Class Initialized
INFO - 2018-07-25 12:16:06 --> Router Class Initialized
INFO - 2018-07-25 12:16:06 --> Output Class Initialized
INFO - 2018-07-25 12:16:06 --> Security Class Initialized
DEBUG - 2018-07-25 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:16:06 --> CSRF cookie sent
INFO - 2018-07-25 12:16:06 --> Input Class Initialized
INFO - 2018-07-25 12:16:06 --> Language Class Initialized
INFO - 2018-07-25 12:16:06 --> Loader Class Initialized
INFO - 2018-07-25 12:16:06 --> Helper loaded: url_helper
INFO - 2018-07-25 12:16:06 --> Helper loaded: form_helper
INFO - 2018-07-25 12:16:06 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:16:06 --> User Agent Class Initialized
INFO - 2018-07-25 12:16:06 --> Controller Class Initialized
INFO - 2018-07-25 12:16:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:16:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 12:16:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 12:16:06 --> Could not find the language line "req_email"
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 12:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:16:06 --> Final output sent to browser
DEBUG - 2018-07-25 12:16:06 --> Total execution time: 0.0228
INFO - 2018-07-25 12:16:12 --> Config Class Initialized
INFO - 2018-07-25 12:16:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:16:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:16:12 --> Utf8 Class Initialized
INFO - 2018-07-25 12:16:12 --> URI Class Initialized
INFO - 2018-07-25 12:16:12 --> Router Class Initialized
INFO - 2018-07-25 12:16:12 --> Output Class Initialized
INFO - 2018-07-25 12:16:12 --> Security Class Initialized
DEBUG - 2018-07-25 12:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:16:12 --> CSRF cookie sent
INFO - 2018-07-25 12:16:12 --> Input Class Initialized
INFO - 2018-07-25 12:16:12 --> Language Class Initialized
INFO - 2018-07-25 12:16:12 --> Loader Class Initialized
INFO - 2018-07-25 12:16:12 --> Helper loaded: url_helper
INFO - 2018-07-25 12:16:12 --> Helper loaded: form_helper
INFO - 2018-07-25 12:16:12 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:16:12 --> User Agent Class Initialized
INFO - 2018-07-25 12:16:12 --> Controller Class Initialized
INFO - 2018-07-25 12:16:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:16:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 12:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:16:12 --> Final output sent to browser
DEBUG - 2018-07-25 12:16:12 --> Total execution time: 0.0207
INFO - 2018-07-25 12:17:48 --> Config Class Initialized
INFO - 2018-07-25 12:17:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:17:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:17:48 --> Utf8 Class Initialized
INFO - 2018-07-25 12:17:48 --> URI Class Initialized
INFO - 2018-07-25 12:17:48 --> Router Class Initialized
INFO - 2018-07-25 12:17:48 --> Output Class Initialized
INFO - 2018-07-25 12:17:48 --> Security Class Initialized
DEBUG - 2018-07-25 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:17:48 --> CSRF cookie sent
INFO - 2018-07-25 12:17:48 --> Input Class Initialized
INFO - 2018-07-25 12:17:48 --> Language Class Initialized
INFO - 2018-07-25 12:17:48 --> Loader Class Initialized
INFO - 2018-07-25 12:17:48 --> Helper loaded: url_helper
INFO - 2018-07-25 12:17:48 --> Helper loaded: form_helper
INFO - 2018-07-25 12:17:48 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:17:48 --> User Agent Class Initialized
INFO - 2018-07-25 12:17:48 --> Controller Class Initialized
INFO - 2018-07-25 12:17:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:17:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-25 12:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:17:48 --> Final output sent to browser
DEBUG - 2018-07-25 12:17:48 --> Total execution time: 0.0215
INFO - 2018-07-25 12:18:12 --> Config Class Initialized
INFO - 2018-07-25 12:18:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:18:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:18:12 --> Utf8 Class Initialized
INFO - 2018-07-25 12:18:12 --> URI Class Initialized
INFO - 2018-07-25 12:18:12 --> Router Class Initialized
INFO - 2018-07-25 12:18:12 --> Output Class Initialized
INFO - 2018-07-25 12:18:12 --> Security Class Initialized
DEBUG - 2018-07-25 12:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:18:12 --> CSRF cookie sent
INFO - 2018-07-25 12:18:12 --> Input Class Initialized
INFO - 2018-07-25 12:18:12 --> Language Class Initialized
INFO - 2018-07-25 12:18:12 --> Loader Class Initialized
INFO - 2018-07-25 12:18:12 --> Helper loaded: url_helper
INFO - 2018-07-25 12:18:12 --> Helper loaded: form_helper
INFO - 2018-07-25 12:18:12 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:18:12 --> User Agent Class Initialized
INFO - 2018-07-25 12:18:12 --> Controller Class Initialized
INFO - 2018-07-25 12:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-25 12:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:18:12 --> Final output sent to browser
DEBUG - 2018-07-25 12:18:12 --> Total execution time: 0.0242
INFO - 2018-07-25 12:19:24 --> Config Class Initialized
INFO - 2018-07-25 12:19:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:19:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:19:24 --> Utf8 Class Initialized
INFO - 2018-07-25 12:19:24 --> URI Class Initialized
INFO - 2018-07-25 12:19:24 --> Router Class Initialized
INFO - 2018-07-25 12:19:24 --> Output Class Initialized
INFO - 2018-07-25 12:19:24 --> Security Class Initialized
DEBUG - 2018-07-25 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:19:24 --> CSRF cookie sent
INFO - 2018-07-25 12:19:24 --> Input Class Initialized
INFO - 2018-07-25 12:19:24 --> Language Class Initialized
INFO - 2018-07-25 12:19:24 --> Loader Class Initialized
INFO - 2018-07-25 12:19:24 --> Helper loaded: url_helper
INFO - 2018-07-25 12:19:24 --> Helper loaded: form_helper
INFO - 2018-07-25 12:19:24 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:19:24 --> User Agent Class Initialized
INFO - 2018-07-25 12:19:24 --> Controller Class Initialized
INFO - 2018-07-25 12:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 12:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:19:24 --> Final output sent to browser
DEBUG - 2018-07-25 12:19:24 --> Total execution time: 0.0232
INFO - 2018-07-25 12:22:44 --> Config Class Initialized
INFO - 2018-07-25 12:22:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:22:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:22:44 --> Utf8 Class Initialized
INFO - 2018-07-25 12:22:44 --> URI Class Initialized
DEBUG - 2018-07-25 12:22:44 --> No URI present. Default controller set.
INFO - 2018-07-25 12:22:44 --> Router Class Initialized
INFO - 2018-07-25 12:22:44 --> Output Class Initialized
INFO - 2018-07-25 12:22:44 --> Security Class Initialized
DEBUG - 2018-07-25 12:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:22:44 --> CSRF cookie sent
INFO - 2018-07-25 12:22:44 --> Input Class Initialized
INFO - 2018-07-25 12:22:44 --> Language Class Initialized
INFO - 2018-07-25 12:22:44 --> Loader Class Initialized
INFO - 2018-07-25 12:22:44 --> Helper loaded: url_helper
INFO - 2018-07-25 12:22:44 --> Helper loaded: form_helper
INFO - 2018-07-25 12:22:44 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:22:44 --> User Agent Class Initialized
INFO - 2018-07-25 12:22:44 --> Controller Class Initialized
INFO - 2018-07-25 12:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:22:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:22:44 --> Pixel_Model class loaded
INFO - 2018-07-25 12:22:44 --> Database Driver Class Initialized
INFO - 2018-07-25 12:22:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:22:44 --> Final output sent to browser
DEBUG - 2018-07-25 12:22:44 --> Total execution time: 0.0361
INFO - 2018-07-25 12:22:54 --> Config Class Initialized
INFO - 2018-07-25 12:22:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:22:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:22:54 --> Utf8 Class Initialized
INFO - 2018-07-25 12:22:54 --> URI Class Initialized
INFO - 2018-07-25 12:22:54 --> Router Class Initialized
INFO - 2018-07-25 12:22:54 --> Output Class Initialized
INFO - 2018-07-25 12:22:54 --> Security Class Initialized
DEBUG - 2018-07-25 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:22:54 --> CSRF cookie sent
INFO - 2018-07-25 12:22:54 --> CSRF token verified
INFO - 2018-07-25 12:22:54 --> Input Class Initialized
INFO - 2018-07-25 12:22:54 --> Language Class Initialized
INFO - 2018-07-25 12:22:54 --> Loader Class Initialized
INFO - 2018-07-25 12:22:54 --> Helper loaded: url_helper
INFO - 2018-07-25 12:22:54 --> Helper loaded: form_helper
INFO - 2018-07-25 12:22:54 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:22:54 --> User Agent Class Initialized
INFO - 2018-07-25 12:22:54 --> Controller Class Initialized
INFO - 2018-07-25 12:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:22:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:22:54 --> Pixel_Model class loaded
INFO - 2018-07-25 12:22:54 --> Database Driver Class Initialized
INFO - 2018-07-25 12:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:22:54 --> Config Class Initialized
INFO - 2018-07-25 12:22:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:22:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:22:54 --> Utf8 Class Initialized
INFO - 2018-07-25 12:22:54 --> URI Class Initialized
INFO - 2018-07-25 12:22:54 --> Router Class Initialized
INFO - 2018-07-25 12:22:54 --> Output Class Initialized
INFO - 2018-07-25 12:22:54 --> Security Class Initialized
DEBUG - 2018-07-25 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:22:54 --> CSRF cookie sent
INFO - 2018-07-25 12:22:54 --> Input Class Initialized
INFO - 2018-07-25 12:22:54 --> Language Class Initialized
INFO - 2018-07-25 12:22:54 --> Loader Class Initialized
INFO - 2018-07-25 12:22:54 --> Helper loaded: url_helper
INFO - 2018-07-25 12:22:54 --> Helper loaded: form_helper
INFO - 2018-07-25 12:22:54 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:22:54 --> User Agent Class Initialized
INFO - 2018-07-25 12:22:54 --> Controller Class Initialized
INFO - 2018-07-25 12:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:22:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 12:22:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 12:22:54 --> Could not find the language line "req_email"
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 12:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:22:54 --> Final output sent to browser
DEBUG - 2018-07-25 12:22:54 --> Total execution time: 0.0234
INFO - 2018-07-25 12:22:57 --> Config Class Initialized
INFO - 2018-07-25 12:22:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:22:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:22:57 --> Utf8 Class Initialized
INFO - 2018-07-25 12:22:57 --> URI Class Initialized
DEBUG - 2018-07-25 12:22:57 --> No URI present. Default controller set.
INFO - 2018-07-25 12:22:57 --> Router Class Initialized
INFO - 2018-07-25 12:22:57 --> Output Class Initialized
INFO - 2018-07-25 12:22:57 --> Security Class Initialized
DEBUG - 2018-07-25 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:22:57 --> CSRF cookie sent
INFO - 2018-07-25 12:22:57 --> Input Class Initialized
INFO - 2018-07-25 12:22:57 --> Language Class Initialized
INFO - 2018-07-25 12:22:57 --> Loader Class Initialized
INFO - 2018-07-25 12:22:57 --> Helper loaded: url_helper
INFO - 2018-07-25 12:22:57 --> Helper loaded: form_helper
INFO - 2018-07-25 12:22:57 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:22:57 --> User Agent Class Initialized
INFO - 2018-07-25 12:22:57 --> Controller Class Initialized
INFO - 2018-07-25 12:22:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:22:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:22:57 --> Pixel_Model class loaded
INFO - 2018-07-25 12:22:57 --> Database Driver Class Initialized
INFO - 2018-07-25 12:22:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:22:57 --> Final output sent to browser
DEBUG - 2018-07-25 12:22:57 --> Total execution time: 0.0414
INFO - 2018-07-25 12:23:32 --> Config Class Initialized
INFO - 2018-07-25 12:23:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:23:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:23:32 --> Utf8 Class Initialized
INFO - 2018-07-25 12:23:32 --> URI Class Initialized
DEBUG - 2018-07-25 12:23:32 --> No URI present. Default controller set.
INFO - 2018-07-25 12:23:32 --> Router Class Initialized
INFO - 2018-07-25 12:23:32 --> Output Class Initialized
INFO - 2018-07-25 12:23:32 --> Security Class Initialized
DEBUG - 2018-07-25 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:23:32 --> CSRF cookie sent
INFO - 2018-07-25 12:23:32 --> Input Class Initialized
INFO - 2018-07-25 12:23:32 --> Language Class Initialized
INFO - 2018-07-25 12:23:32 --> Loader Class Initialized
INFO - 2018-07-25 12:23:32 --> Helper loaded: url_helper
INFO - 2018-07-25 12:23:32 --> Helper loaded: form_helper
INFO - 2018-07-25 12:23:32 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:23:32 --> User Agent Class Initialized
INFO - 2018-07-25 12:23:32 --> Controller Class Initialized
INFO - 2018-07-25 12:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:23:32 --> Pixel_Model class loaded
INFO - 2018-07-25 12:23:32 --> Database Driver Class Initialized
INFO - 2018-07-25 12:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:23:32 --> Final output sent to browser
DEBUG - 2018-07-25 12:23:32 --> Total execution time: 0.0333
INFO - 2018-07-25 12:23:57 --> Config Class Initialized
INFO - 2018-07-25 12:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:23:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:23:57 --> Utf8 Class Initialized
INFO - 2018-07-25 12:23:57 --> URI Class Initialized
INFO - 2018-07-25 12:23:57 --> Router Class Initialized
INFO - 2018-07-25 12:23:57 --> Output Class Initialized
INFO - 2018-07-25 12:23:57 --> Security Class Initialized
DEBUG - 2018-07-25 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:23:57 --> CSRF cookie sent
INFO - 2018-07-25 12:23:57 --> Input Class Initialized
INFO - 2018-07-25 12:23:57 --> Language Class Initialized
INFO - 2018-07-25 12:23:57 --> Loader Class Initialized
INFO - 2018-07-25 12:23:57 --> Helper loaded: url_helper
INFO - 2018-07-25 12:23:57 --> Helper loaded: form_helper
INFO - 2018-07-25 12:23:57 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:23:57 --> User Agent Class Initialized
INFO - 2018-07-25 12:23:57 --> Controller Class Initialized
INFO - 2018-07-25 12:23:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:23:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:23:57 --> Pixel_Model class loaded
INFO - 2018-07-25 12:23:57 --> Database Driver Class Initialized
INFO - 2018-07-25 12:23:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:23:57 --> Config Class Initialized
INFO - 2018-07-25 12:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:23:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:23:57 --> Utf8 Class Initialized
INFO - 2018-07-25 12:23:57 --> URI Class Initialized
INFO - 2018-07-25 12:23:57 --> Router Class Initialized
INFO - 2018-07-25 12:23:57 --> Output Class Initialized
INFO - 2018-07-25 12:23:57 --> Security Class Initialized
DEBUG - 2018-07-25 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:23:57 --> CSRF cookie sent
INFO - 2018-07-25 12:23:57 --> Input Class Initialized
INFO - 2018-07-25 12:23:57 --> Language Class Initialized
INFO - 2018-07-25 12:23:57 --> Loader Class Initialized
INFO - 2018-07-25 12:23:57 --> Helper loaded: url_helper
INFO - 2018-07-25 12:23:57 --> Helper loaded: form_helper
INFO - 2018-07-25 12:23:57 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:23:57 --> User Agent Class Initialized
INFO - 2018-07-25 12:23:57 --> Controller Class Initialized
INFO - 2018-07-25 12:23:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:23:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 12:23:57 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 12:23:57 --> Could not find the language line "req_email"
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 12:23:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:23:57 --> Final output sent to browser
DEBUG - 2018-07-25 12:23:57 --> Total execution time: 0.0217
INFO - 2018-07-25 12:23:59 --> Config Class Initialized
INFO - 2018-07-25 12:23:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:23:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:23:59 --> Utf8 Class Initialized
INFO - 2018-07-25 12:23:59 --> URI Class Initialized
INFO - 2018-07-25 12:23:59 --> Router Class Initialized
INFO - 2018-07-25 12:23:59 --> Output Class Initialized
INFO - 2018-07-25 12:23:59 --> Security Class Initialized
DEBUG - 2018-07-25 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:23:59 --> CSRF cookie sent
INFO - 2018-07-25 12:23:59 --> Input Class Initialized
INFO - 2018-07-25 12:23:59 --> Language Class Initialized
INFO - 2018-07-25 12:23:59 --> Loader Class Initialized
INFO - 2018-07-25 12:23:59 --> Helper loaded: url_helper
INFO - 2018-07-25 12:23:59 --> Helper loaded: form_helper
INFO - 2018-07-25 12:23:59 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:23:59 --> User Agent Class Initialized
INFO - 2018-07-25 12:23:59 --> Controller Class Initialized
INFO - 2018-07-25 12:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-25 12:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:23:59 --> Final output sent to browser
DEBUG - 2018-07-25 12:23:59 --> Total execution time: 0.0245
INFO - 2018-07-25 12:24:00 --> Config Class Initialized
INFO - 2018-07-25 12:24:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:00 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:00 --> URI Class Initialized
INFO - 2018-07-25 12:24:00 --> Router Class Initialized
INFO - 2018-07-25 12:24:00 --> Output Class Initialized
INFO - 2018-07-25 12:24:00 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:00 --> CSRF cookie sent
INFO - 2018-07-25 12:24:00 --> Input Class Initialized
INFO - 2018-07-25 12:24:00 --> Language Class Initialized
INFO - 2018-07-25 12:24:00 --> Loader Class Initialized
INFO - 2018-07-25 12:24:00 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:00 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:00 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:00 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:00 --> Controller Class Initialized
INFO - 2018-07-25 12:24:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-25 12:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:24:00 --> Final output sent to browser
DEBUG - 2018-07-25 12:24:00 --> Total execution time: 0.0233
INFO - 2018-07-25 12:24:04 --> Config Class Initialized
INFO - 2018-07-25 12:24:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:04 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:04 --> URI Class Initialized
INFO - 2018-07-25 12:24:04 --> Router Class Initialized
INFO - 2018-07-25 12:24:04 --> Output Class Initialized
INFO - 2018-07-25 12:24:04 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:04 --> CSRF cookie sent
INFO - 2018-07-25 12:24:04 --> Input Class Initialized
INFO - 2018-07-25 12:24:04 --> Language Class Initialized
INFO - 2018-07-25 12:24:04 --> Loader Class Initialized
INFO - 2018-07-25 12:24:04 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:04 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:04 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:04 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:04 --> Controller Class Initialized
INFO - 2018-07-25 12:24:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-07-25 12:24:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:24:04 --> Final output sent to browser
DEBUG - 2018-07-25 12:24:04 --> Total execution time: 0.0323
INFO - 2018-07-25 12:24:17 --> Config Class Initialized
INFO - 2018-07-25 12:24:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:17 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:17 --> URI Class Initialized
INFO - 2018-07-25 12:24:17 --> Router Class Initialized
INFO - 2018-07-25 12:24:17 --> Output Class Initialized
INFO - 2018-07-25 12:24:17 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:17 --> CSRF cookie sent
INFO - 2018-07-25 12:24:17 --> Input Class Initialized
INFO - 2018-07-25 12:24:17 --> Language Class Initialized
INFO - 2018-07-25 12:24:17 --> Loader Class Initialized
INFO - 2018-07-25 12:24:17 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:17 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:17 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:17 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:17 --> Controller Class Initialized
INFO - 2018-07-25 12:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:24:17 --> Pixel_Model class loaded
INFO - 2018-07-25 12:24:17 --> Database Driver Class Initialized
INFO - 2018-07-25 12:24:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:24:17 --> Config Class Initialized
INFO - 2018-07-25 12:24:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:17 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:17 --> URI Class Initialized
INFO - 2018-07-25 12:24:17 --> Router Class Initialized
INFO - 2018-07-25 12:24:17 --> Output Class Initialized
INFO - 2018-07-25 12:24:17 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:17 --> CSRF cookie sent
INFO - 2018-07-25 12:24:17 --> Input Class Initialized
INFO - 2018-07-25 12:24:17 --> Language Class Initialized
INFO - 2018-07-25 12:24:17 --> Loader Class Initialized
INFO - 2018-07-25 12:24:17 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:17 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:17 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:17 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:17 --> Controller Class Initialized
INFO - 2018-07-25 12:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 12:24:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 12:24:17 --> Could not find the language line "req_email"
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 12:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:24:17 --> Final output sent to browser
DEBUG - 2018-07-25 12:24:17 --> Total execution time: 0.0225
INFO - 2018-07-25 12:24:21 --> Config Class Initialized
INFO - 2018-07-25 12:24:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:21 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:21 --> URI Class Initialized
INFO - 2018-07-25 12:24:21 --> Router Class Initialized
INFO - 2018-07-25 12:24:21 --> Output Class Initialized
INFO - 2018-07-25 12:24:21 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:21 --> CSRF cookie sent
INFO - 2018-07-25 12:24:21 --> Input Class Initialized
INFO - 2018-07-25 12:24:21 --> Language Class Initialized
INFO - 2018-07-25 12:24:21 --> Loader Class Initialized
INFO - 2018-07-25 12:24:21 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:21 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:21 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:21 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:21 --> Controller Class Initialized
INFO - 2018-07-25 12:24:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-25 12:24:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:24:21 --> Final output sent to browser
DEBUG - 2018-07-25 12:24:21 --> Total execution time: 0.0307
INFO - 2018-07-25 12:24:25 --> Config Class Initialized
INFO - 2018-07-25 12:24:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:24:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:24:25 --> Utf8 Class Initialized
INFO - 2018-07-25 12:24:25 --> URI Class Initialized
INFO - 2018-07-25 12:24:25 --> Router Class Initialized
INFO - 2018-07-25 12:24:25 --> Output Class Initialized
INFO - 2018-07-25 12:24:25 --> Security Class Initialized
DEBUG - 2018-07-25 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:24:25 --> CSRF cookie sent
INFO - 2018-07-25 12:24:25 --> Input Class Initialized
INFO - 2018-07-25 12:24:25 --> Language Class Initialized
INFO - 2018-07-25 12:24:25 --> Loader Class Initialized
INFO - 2018-07-25 12:24:25 --> Helper loaded: url_helper
INFO - 2018-07-25 12:24:25 --> Helper loaded: form_helper
INFO - 2018-07-25 12:24:25 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:24:25 --> User Agent Class Initialized
INFO - 2018-07-25 12:24:25 --> Controller Class Initialized
INFO - 2018-07-25 12:24:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:24:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-25 12:24:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:24:25 --> Final output sent to browser
DEBUG - 2018-07-25 12:24:25 --> Total execution time: 0.0215
INFO - 2018-07-25 12:25:23 --> Config Class Initialized
INFO - 2018-07-25 12:25:23 --> Hooks Class Initialized
DEBUG - 2018-07-25 12:25:23 --> UTF-8 Support Enabled
INFO - 2018-07-25 12:25:23 --> Utf8 Class Initialized
INFO - 2018-07-25 12:25:23 --> URI Class Initialized
DEBUG - 2018-07-25 12:25:23 --> No URI present. Default controller set.
INFO - 2018-07-25 12:25:23 --> Router Class Initialized
INFO - 2018-07-25 12:25:23 --> Output Class Initialized
INFO - 2018-07-25 12:25:23 --> Security Class Initialized
DEBUG - 2018-07-25 12:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 12:25:23 --> CSRF cookie sent
INFO - 2018-07-25 12:25:23 --> Input Class Initialized
INFO - 2018-07-25 12:25:23 --> Language Class Initialized
INFO - 2018-07-25 12:25:23 --> Loader Class Initialized
INFO - 2018-07-25 12:25:23 --> Helper loaded: url_helper
INFO - 2018-07-25 12:25:23 --> Helper loaded: form_helper
INFO - 2018-07-25 12:25:23 --> Helper loaded: language_helper
DEBUG - 2018-07-25 12:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 12:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 12:25:23 --> User Agent Class Initialized
INFO - 2018-07-25 12:25:23 --> Controller Class Initialized
INFO - 2018-07-25 12:25:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 12:25:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 12:25:23 --> Pixel_Model class loaded
INFO - 2018-07-25 12:25:23 --> Database Driver Class Initialized
INFO - 2018-07-25 12:25:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 12:25:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 12:25:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 12:25:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 12:25:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 12:25:23 --> Final output sent to browser
DEBUG - 2018-07-25 12:25:23 --> Total execution time: 0.0356
INFO - 2018-07-25 13:55:31 --> Config Class Initialized
INFO - 2018-07-25 13:55:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 13:55:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 13:55:31 --> Utf8 Class Initialized
INFO - 2018-07-25 13:55:31 --> URI Class Initialized
DEBUG - 2018-07-25 13:55:31 --> No URI present. Default controller set.
INFO - 2018-07-25 13:55:31 --> Router Class Initialized
INFO - 2018-07-25 13:55:31 --> Output Class Initialized
INFO - 2018-07-25 13:55:31 --> Security Class Initialized
DEBUG - 2018-07-25 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 13:55:31 --> CSRF cookie sent
INFO - 2018-07-25 13:55:31 --> Input Class Initialized
INFO - 2018-07-25 13:55:31 --> Language Class Initialized
INFO - 2018-07-25 13:55:31 --> Loader Class Initialized
INFO - 2018-07-25 13:55:31 --> Helper loaded: url_helper
INFO - 2018-07-25 13:55:31 --> Helper loaded: form_helper
INFO - 2018-07-25 13:55:31 --> Helper loaded: language_helper
DEBUG - 2018-07-25 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 13:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 13:55:31 --> User Agent Class Initialized
INFO - 2018-07-25 13:55:31 --> Controller Class Initialized
INFO - 2018-07-25 13:55:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 13:55:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 13:55:31 --> Pixel_Model class loaded
INFO - 2018-07-25 13:55:31 --> Database Driver Class Initialized
INFO - 2018-07-25 13:55:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 13:55:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 13:55:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 13:55:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 13:55:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 13:55:31 --> Final output sent to browser
DEBUG - 2018-07-25 13:55:31 --> Total execution time: 0.0340
INFO - 2018-07-25 14:27:21 --> Config Class Initialized
INFO - 2018-07-25 14:27:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:27:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:27:21 --> Utf8 Class Initialized
INFO - 2018-07-25 14:27:21 --> URI Class Initialized
INFO - 2018-07-25 14:27:21 --> Router Class Initialized
INFO - 2018-07-25 14:27:21 --> Output Class Initialized
INFO - 2018-07-25 14:27:21 --> Security Class Initialized
DEBUG - 2018-07-25 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:27:21 --> CSRF cookie sent
INFO - 2018-07-25 14:27:21 --> Input Class Initialized
INFO - 2018-07-25 14:27:21 --> Language Class Initialized
INFO - 2018-07-25 14:27:21 --> Loader Class Initialized
INFO - 2018-07-25 14:27:21 --> Helper loaded: url_helper
INFO - 2018-07-25 14:27:21 --> Helper loaded: form_helper
INFO - 2018-07-25 14:27:21 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:27:21 --> User Agent Class Initialized
INFO - 2018-07-25 14:27:21 --> Controller Class Initialized
INFO - 2018-07-25 14:27:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:27:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-25 14:27:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:27:21 --> Final output sent to browser
DEBUG - 2018-07-25 14:27:21 --> Total execution time: 0.0228
INFO - 2018-07-25 14:29:57 --> Config Class Initialized
INFO - 2018-07-25 14:29:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:29:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:29:57 --> Utf8 Class Initialized
INFO - 2018-07-25 14:29:57 --> URI Class Initialized
INFO - 2018-07-25 14:29:57 --> Router Class Initialized
INFO - 2018-07-25 14:29:57 --> Output Class Initialized
INFO - 2018-07-25 14:29:57 --> Security Class Initialized
DEBUG - 2018-07-25 14:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:29:57 --> CSRF cookie sent
INFO - 2018-07-25 14:29:57 --> Input Class Initialized
INFO - 2018-07-25 14:29:57 --> Language Class Initialized
INFO - 2018-07-25 14:29:57 --> Loader Class Initialized
INFO - 2018-07-25 14:29:57 --> Helper loaded: url_helper
INFO - 2018-07-25 14:29:57 --> Helper loaded: form_helper
INFO - 2018-07-25 14:29:57 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:29:57 --> User Agent Class Initialized
INFO - 2018-07-25 14:29:57 --> Controller Class Initialized
INFO - 2018-07-25 14:29:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:29:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-25 14:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:29:57 --> Final output sent to browser
DEBUG - 2018-07-25 14:29:57 --> Total execution time: 0.0243
INFO - 2018-07-25 14:32:06 --> Config Class Initialized
INFO - 2018-07-25 14:32:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:32:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:32:06 --> Utf8 Class Initialized
INFO - 2018-07-25 14:32:06 --> URI Class Initialized
INFO - 2018-07-25 14:32:06 --> Router Class Initialized
INFO - 2018-07-25 14:32:06 --> Output Class Initialized
INFO - 2018-07-25 14:32:06 --> Security Class Initialized
DEBUG - 2018-07-25 14:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:32:06 --> CSRF cookie sent
INFO - 2018-07-25 14:32:06 --> Input Class Initialized
INFO - 2018-07-25 14:32:06 --> Language Class Initialized
INFO - 2018-07-25 14:32:06 --> Loader Class Initialized
INFO - 2018-07-25 14:32:06 --> Helper loaded: url_helper
INFO - 2018-07-25 14:32:06 --> Helper loaded: form_helper
INFO - 2018-07-25 14:32:06 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:32:06 --> User Agent Class Initialized
INFO - 2018-07-25 14:32:06 --> Controller Class Initialized
INFO - 2018-07-25 14:32:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:32:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:32:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 14:32:06 --> Could not find the language line "req_email"
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 14:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:32:06 --> Final output sent to browser
DEBUG - 2018-07-25 14:32:06 --> Total execution time: 0.0229
INFO - 2018-07-25 14:34:25 --> Config Class Initialized
INFO - 2018-07-25 14:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:34:25 --> Utf8 Class Initialized
INFO - 2018-07-25 14:34:25 --> URI Class Initialized
INFO - 2018-07-25 14:34:25 --> Router Class Initialized
INFO - 2018-07-25 14:34:25 --> Output Class Initialized
INFO - 2018-07-25 14:34:25 --> Security Class Initialized
DEBUG - 2018-07-25 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:34:25 --> CSRF cookie sent
INFO - 2018-07-25 14:34:25 --> Input Class Initialized
INFO - 2018-07-25 14:34:25 --> Language Class Initialized
INFO - 2018-07-25 14:34:25 --> Loader Class Initialized
INFO - 2018-07-25 14:34:25 --> Helper loaded: url_helper
INFO - 2018-07-25 14:34:25 --> Helper loaded: form_helper
INFO - 2018-07-25 14:34:25 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:34:25 --> User Agent Class Initialized
INFO - 2018-07-25 14:34:25 --> Controller Class Initialized
INFO - 2018-07-25 14:34:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:34:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:34:25 --> Pixel_Model class loaded
INFO - 2018-07-25 14:34:25 --> Database Driver Class Initialized
INFO - 2018-07-25 14:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-25 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:34:25 --> Final output sent to browser
DEBUG - 2018-07-25 14:34:25 --> Total execution time: 0.0467
INFO - 2018-07-25 14:49:02 --> Config Class Initialized
INFO - 2018-07-25 14:49:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:49:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:49:02 --> Utf8 Class Initialized
INFO - 2018-07-25 14:49:02 --> URI Class Initialized
DEBUG - 2018-07-25 14:49:02 --> No URI present. Default controller set.
INFO - 2018-07-25 14:49:02 --> Router Class Initialized
INFO - 2018-07-25 14:49:02 --> Output Class Initialized
INFO - 2018-07-25 14:49:02 --> Security Class Initialized
DEBUG - 2018-07-25 14:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:49:02 --> CSRF cookie sent
INFO - 2018-07-25 14:49:02 --> Input Class Initialized
INFO - 2018-07-25 14:49:02 --> Language Class Initialized
INFO - 2018-07-25 14:49:02 --> Loader Class Initialized
INFO - 2018-07-25 14:49:02 --> Helper loaded: url_helper
INFO - 2018-07-25 14:49:02 --> Helper loaded: form_helper
INFO - 2018-07-25 14:49:02 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:49:02 --> User Agent Class Initialized
INFO - 2018-07-25 14:49:02 --> Controller Class Initialized
INFO - 2018-07-25 14:49:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:49:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:49:02 --> Pixel_Model class loaded
INFO - 2018-07-25 14:49:02 --> Database Driver Class Initialized
INFO - 2018-07-25 14:49:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 14:49:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:49:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:49:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 14:49:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:49:02 --> Final output sent to browser
DEBUG - 2018-07-25 14:49:02 --> Total execution time: 0.0345
INFO - 2018-07-25 14:49:08 --> Config Class Initialized
INFO - 2018-07-25 14:49:08 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:49:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:49:08 --> Utf8 Class Initialized
INFO - 2018-07-25 14:49:08 --> URI Class Initialized
INFO - 2018-07-25 14:49:08 --> Router Class Initialized
INFO - 2018-07-25 14:49:08 --> Output Class Initialized
INFO - 2018-07-25 14:49:08 --> Security Class Initialized
DEBUG - 2018-07-25 14:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:49:08 --> CSRF cookie sent
INFO - 2018-07-25 14:49:08 --> Input Class Initialized
INFO - 2018-07-25 14:49:08 --> Language Class Initialized
INFO - 2018-07-25 14:49:08 --> Loader Class Initialized
INFO - 2018-07-25 14:49:08 --> Helper loaded: url_helper
INFO - 2018-07-25 14:49:08 --> Helper loaded: form_helper
INFO - 2018-07-25 14:49:08 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:49:08 --> User Agent Class Initialized
INFO - 2018-07-25 14:49:08 --> Controller Class Initialized
INFO - 2018-07-25 14:49:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:49:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:49:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 14:49:08 --> Could not find the language line "req_email"
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 14:49:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:49:08 --> Final output sent to browser
DEBUG - 2018-07-25 14:49:08 --> Total execution time: 0.0239
INFO - 2018-07-25 14:49:33 --> Config Class Initialized
INFO - 2018-07-25 14:49:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:49:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:49:33 --> Utf8 Class Initialized
INFO - 2018-07-25 14:49:33 --> URI Class Initialized
INFO - 2018-07-25 14:49:33 --> Router Class Initialized
INFO - 2018-07-25 14:49:33 --> Output Class Initialized
INFO - 2018-07-25 14:49:33 --> Security Class Initialized
DEBUG - 2018-07-25 14:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:49:33 --> CSRF cookie sent
INFO - 2018-07-25 14:49:33 --> CSRF token verified
INFO - 2018-07-25 14:49:33 --> Input Class Initialized
INFO - 2018-07-25 14:49:33 --> Language Class Initialized
INFO - 2018-07-25 14:49:33 --> Loader Class Initialized
INFO - 2018-07-25 14:49:33 --> Helper loaded: url_helper
INFO - 2018-07-25 14:49:33 --> Helper loaded: form_helper
INFO - 2018-07-25 14:49:33 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:49:33 --> User Agent Class Initialized
INFO - 2018-07-25 14:49:33 --> Controller Class Initialized
INFO - 2018-07-25 14:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:49:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:49:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:49:33 --> Form Validation Class Initialized
INFO - 2018-07-25 14:49:33 --> Pixel_Model class loaded
INFO - 2018-07-25 14:49:33 --> Database Driver Class Initialized
INFO - 2018-07-25 14:49:33 --> Model "AuthenticationModel" initialized
INFO - 2018-07-25 14:49:33 --> Config Class Initialized
INFO - 2018-07-25 14:49:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:49:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:49:33 --> Utf8 Class Initialized
INFO - 2018-07-25 14:49:33 --> URI Class Initialized
INFO - 2018-07-25 14:49:33 --> Router Class Initialized
INFO - 2018-07-25 14:49:33 --> Output Class Initialized
INFO - 2018-07-25 14:49:33 --> Security Class Initialized
DEBUG - 2018-07-25 14:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:49:33 --> CSRF cookie sent
INFO - 2018-07-25 14:49:33 --> Input Class Initialized
INFO - 2018-07-25 14:49:33 --> Language Class Initialized
INFO - 2018-07-25 14:49:33 --> Loader Class Initialized
INFO - 2018-07-25 14:49:33 --> Helper loaded: url_helper
INFO - 2018-07-25 14:49:33 --> Helper loaded: form_helper
INFO - 2018-07-25 14:49:33 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:49:33 --> User Agent Class Initialized
INFO - 2018-07-25 14:49:33 --> Controller Class Initialized
INFO - 2018-07-25 14:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:49:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:49:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-25 14:49:33 --> Could not find the language line "req_email"
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 14:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:49:33 --> Final output sent to browser
DEBUG - 2018-07-25 14:49:33 --> Total execution time: 0.0209
INFO - 2018-07-25 14:51:39 --> Config Class Initialized
INFO - 2018-07-25 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:51:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:51:39 --> Utf8 Class Initialized
INFO - 2018-07-25 14:51:39 --> URI Class Initialized
INFO - 2018-07-25 14:51:39 --> Router Class Initialized
INFO - 2018-07-25 14:51:39 --> Output Class Initialized
INFO - 2018-07-25 14:51:39 --> Security Class Initialized
DEBUG - 2018-07-25 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:51:39 --> CSRF cookie sent
INFO - 2018-07-25 14:51:39 --> CSRF token verified
INFO - 2018-07-25 14:51:39 --> Input Class Initialized
INFO - 2018-07-25 14:51:39 --> Language Class Initialized
INFO - 2018-07-25 14:51:39 --> Loader Class Initialized
INFO - 2018-07-25 14:51:39 --> Helper loaded: url_helper
INFO - 2018-07-25 14:51:39 --> Helper loaded: form_helper
INFO - 2018-07-25 14:51:39 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:51:39 --> User Agent Class Initialized
INFO - 2018-07-25 14:51:39 --> Controller Class Initialized
INFO - 2018-07-25 14:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:51:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:51:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:51:39 --> Form Validation Class Initialized
INFO - 2018-07-25 14:51:39 --> Pixel_Model class loaded
INFO - 2018-07-25 14:51:39 --> Database Driver Class Initialized
INFO - 2018-07-25 14:51:39 --> Model "AuthenticationModel" initialized
INFO - 2018-07-25 14:51:39 --> Config Class Initialized
INFO - 2018-07-25 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:51:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:51:39 --> Utf8 Class Initialized
INFO - 2018-07-25 14:51:39 --> URI Class Initialized
INFO - 2018-07-25 14:51:39 --> Router Class Initialized
INFO - 2018-07-25 14:51:39 --> Output Class Initialized
INFO - 2018-07-25 14:51:39 --> Security Class Initialized
DEBUG - 2018-07-25 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:51:39 --> CSRF cookie sent
INFO - 2018-07-25 14:51:39 --> Input Class Initialized
INFO - 2018-07-25 14:51:39 --> Language Class Initialized
INFO - 2018-07-25 14:51:39 --> Loader Class Initialized
INFO - 2018-07-25 14:51:39 --> Helper loaded: url_helper
INFO - 2018-07-25 14:51:39 --> Helper loaded: form_helper
INFO - 2018-07-25 14:51:39 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:51:39 --> User Agent Class Initialized
INFO - 2018-07-25 14:51:39 --> Controller Class Initialized
INFO - 2018-07-25 14:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:51:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:51:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-25 14:51:39 --> Could not find the language line "req_email"
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 14:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:51:39 --> Final output sent to browser
DEBUG - 2018-07-25 14:51:39 --> Total execution time: 0.0228
INFO - 2018-07-25 14:51:50 --> Config Class Initialized
INFO - 2018-07-25 14:51:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:51:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:51:50 --> Utf8 Class Initialized
INFO - 2018-07-25 14:51:50 --> URI Class Initialized
INFO - 2018-07-25 14:51:50 --> Router Class Initialized
INFO - 2018-07-25 14:51:50 --> Output Class Initialized
INFO - 2018-07-25 14:51:50 --> Security Class Initialized
DEBUG - 2018-07-25 14:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:51:50 --> CSRF cookie sent
INFO - 2018-07-25 14:51:50 --> CSRF token verified
INFO - 2018-07-25 14:51:50 --> Input Class Initialized
INFO - 2018-07-25 14:51:50 --> Language Class Initialized
INFO - 2018-07-25 14:51:50 --> Loader Class Initialized
INFO - 2018-07-25 14:51:50 --> Helper loaded: url_helper
INFO - 2018-07-25 14:51:50 --> Helper loaded: form_helper
INFO - 2018-07-25 14:51:50 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:51:50 --> User Agent Class Initialized
INFO - 2018-07-25 14:51:50 --> Controller Class Initialized
INFO - 2018-07-25 14:51:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:51:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:51:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:51:50 --> Form Validation Class Initialized
INFO - 2018-07-25 14:51:50 --> Pixel_Model class loaded
INFO - 2018-07-25 14:51:50 --> Database Driver Class Initialized
INFO - 2018-07-25 14:51:50 --> Model "AuthenticationModel" initialized
INFO - 2018-07-25 14:51:50 --> Config Class Initialized
INFO - 2018-07-25 14:51:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:51:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:51:50 --> Utf8 Class Initialized
INFO - 2018-07-25 14:51:50 --> URI Class Initialized
DEBUG - 2018-07-25 14:51:50 --> No URI present. Default controller set.
INFO - 2018-07-25 14:51:50 --> Router Class Initialized
INFO - 2018-07-25 14:51:50 --> Output Class Initialized
INFO - 2018-07-25 14:51:50 --> Security Class Initialized
DEBUG - 2018-07-25 14:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:51:50 --> CSRF cookie sent
INFO - 2018-07-25 14:51:50 --> Input Class Initialized
INFO - 2018-07-25 14:51:50 --> Language Class Initialized
INFO - 2018-07-25 14:51:50 --> Loader Class Initialized
INFO - 2018-07-25 14:51:50 --> Helper loaded: url_helper
INFO - 2018-07-25 14:51:50 --> Helper loaded: form_helper
INFO - 2018-07-25 14:51:50 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:51:50 --> User Agent Class Initialized
INFO - 2018-07-25 14:51:50 --> Controller Class Initialized
INFO - 2018-07-25 14:51:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:51:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:51:50 --> Pixel_Model class loaded
INFO - 2018-07-25 14:51:50 --> Database Driver Class Initialized
INFO - 2018-07-25 14:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 14:51:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:51:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:51:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:51:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 14:51:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:51:50 --> Final output sent to browser
DEBUG - 2018-07-25 14:51:50 --> Total execution time: 0.0434
INFO - 2018-07-25 14:51:58 --> Config Class Initialized
INFO - 2018-07-25 14:51:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:51:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:51:58 --> Utf8 Class Initialized
INFO - 2018-07-25 14:51:58 --> URI Class Initialized
INFO - 2018-07-25 14:51:58 --> Router Class Initialized
INFO - 2018-07-25 14:51:58 --> Output Class Initialized
INFO - 2018-07-25 14:51:58 --> Security Class Initialized
DEBUG - 2018-07-25 14:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:51:58 --> CSRF cookie sent
INFO - 2018-07-25 14:51:58 --> Input Class Initialized
INFO - 2018-07-25 14:51:58 --> Language Class Initialized
INFO - 2018-07-25 14:51:58 --> Loader Class Initialized
INFO - 2018-07-25 14:51:58 --> Helper loaded: url_helper
INFO - 2018-07-25 14:51:58 --> Helper loaded: form_helper
INFO - 2018-07-25 14:51:58 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:51:58 --> User Agent Class Initialized
INFO - 2018-07-25 14:51:58 --> Controller Class Initialized
INFO - 2018-07-25 14:51:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:51:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/import_fa.php
INFO - 2018-07-25 14:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:51:58 --> Final output sent to browser
DEBUG - 2018-07-25 14:51:58 --> Total execution time: 0.0316
INFO - 2018-07-25 14:52:21 --> Config Class Initialized
INFO - 2018-07-25 14:52:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:52:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:52:21 --> Utf8 Class Initialized
INFO - 2018-07-25 14:52:21 --> URI Class Initialized
INFO - 2018-07-25 14:52:21 --> Router Class Initialized
INFO - 2018-07-25 14:52:21 --> Output Class Initialized
INFO - 2018-07-25 14:52:21 --> Security Class Initialized
DEBUG - 2018-07-25 14:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:52:21 --> CSRF cookie sent
INFO - 2018-07-25 14:52:21 --> Input Class Initialized
INFO - 2018-07-25 14:52:21 --> Language Class Initialized
INFO - 2018-07-25 14:52:21 --> Loader Class Initialized
INFO - 2018-07-25 14:52:21 --> Helper loaded: url_helper
INFO - 2018-07-25 14:52:21 --> Helper loaded: form_helper
INFO - 2018-07-25 14:52:21 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:52:21 --> User Agent Class Initialized
INFO - 2018-07-25 14:52:21 --> Controller Class Initialized
INFO - 2018-07-25 14:52:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:52:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:52:21 --> Pixel_Model class loaded
INFO - 2018-07-25 14:52:21 --> Database Driver Class Initialized
INFO - 2018-07-25 14:52:21 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:52:21 --> Pagination Class Initialized
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:52:21 --> Final output sent to browser
DEBUG - 2018-07-25 14:52:21 --> Total execution time: 0.1644
INFO - 2018-07-25 14:52:26 --> Config Class Initialized
INFO - 2018-07-25 14:52:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:52:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:52:26 --> Utf8 Class Initialized
INFO - 2018-07-25 14:52:26 --> URI Class Initialized
INFO - 2018-07-25 14:52:26 --> Router Class Initialized
INFO - 2018-07-25 14:52:26 --> Output Class Initialized
INFO - 2018-07-25 14:52:26 --> Security Class Initialized
DEBUG - 2018-07-25 14:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:52:26 --> CSRF cookie sent
INFO - 2018-07-25 14:52:26 --> Input Class Initialized
INFO - 2018-07-25 14:52:26 --> Language Class Initialized
INFO - 2018-07-25 14:52:26 --> Loader Class Initialized
INFO - 2018-07-25 14:52:26 --> Helper loaded: url_helper
INFO - 2018-07-25 14:52:26 --> Helper loaded: form_helper
INFO - 2018-07-25 14:52:26 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:52:26 --> User Agent Class Initialized
INFO - 2018-07-25 14:52:26 --> Controller Class Initialized
INFO - 2018-07-25 14:52:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:52:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:52:26 --> Pixel_Model class loaded
INFO - 2018-07-25 14:52:26 --> Database Driver Class Initialized
INFO - 2018-07-25 14:52:26 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:52:26 --> Pagination Class Initialized
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:52:26 --> Final output sent to browser
DEBUG - 2018-07-25 14:52:26 --> Total execution time: 0.0346
INFO - 2018-07-25 14:52:30 --> Config Class Initialized
INFO - 2018-07-25 14:52:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:52:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:52:30 --> Utf8 Class Initialized
INFO - 2018-07-25 14:52:30 --> URI Class Initialized
INFO - 2018-07-25 14:52:30 --> Router Class Initialized
INFO - 2018-07-25 14:52:30 --> Output Class Initialized
INFO - 2018-07-25 14:52:30 --> Security Class Initialized
DEBUG - 2018-07-25 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:52:30 --> CSRF cookie sent
INFO - 2018-07-25 14:52:30 --> Input Class Initialized
INFO - 2018-07-25 14:52:30 --> Language Class Initialized
INFO - 2018-07-25 14:52:30 --> Loader Class Initialized
INFO - 2018-07-25 14:52:30 --> Helper loaded: url_helper
INFO - 2018-07-25 14:52:30 --> Helper loaded: form_helper
INFO - 2018-07-25 14:52:30 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:52:30 --> User Agent Class Initialized
INFO - 2018-07-25 14:52:30 --> Controller Class Initialized
INFO - 2018-07-25 14:52:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:52:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:52:30 --> Pixel_Model class loaded
INFO - 2018-07-25 14:52:30 --> Database Driver Class Initialized
INFO - 2018-07-25 14:52:30 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:52:30 --> Pagination Class Initialized
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:52:30 --> Final output sent to browser
DEBUG - 2018-07-25 14:52:30 --> Total execution time: 0.0408
INFO - 2018-07-25 14:52:44 --> Config Class Initialized
INFO - 2018-07-25 14:52:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:52:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:52:44 --> Utf8 Class Initialized
INFO - 2018-07-25 14:52:44 --> URI Class Initialized
INFO - 2018-07-25 14:52:44 --> Router Class Initialized
INFO - 2018-07-25 14:52:44 --> Output Class Initialized
INFO - 2018-07-25 14:52:44 --> Security Class Initialized
DEBUG - 2018-07-25 14:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:52:44 --> CSRF cookie sent
INFO - 2018-07-25 14:52:44 --> Input Class Initialized
INFO - 2018-07-25 14:52:44 --> Language Class Initialized
INFO - 2018-07-25 14:52:44 --> Loader Class Initialized
INFO - 2018-07-25 14:52:44 --> Helper loaded: url_helper
INFO - 2018-07-25 14:52:44 --> Helper loaded: form_helper
INFO - 2018-07-25 14:52:44 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:52:44 --> User Agent Class Initialized
INFO - 2018-07-25 14:52:44 --> Controller Class Initialized
INFO - 2018-07-25 14:52:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:52:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:52:44 --> Pixel_Model class loaded
INFO - 2018-07-25 14:52:44 --> Database Driver Class Initialized
INFO - 2018-07-25 14:52:44 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:52:44 --> Pagination Class Initialized
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:52:44 --> Final output sent to browser
DEBUG - 2018-07-25 14:52:44 --> Total execution time: 0.0355
INFO - 2018-07-25 14:53:25 --> Config Class Initialized
INFO - 2018-07-25 14:53:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:25 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:25 --> URI Class Initialized
INFO - 2018-07-25 14:53:25 --> Router Class Initialized
INFO - 2018-07-25 14:53:25 --> Output Class Initialized
INFO - 2018-07-25 14:53:25 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:25 --> CSRF cookie sent
INFO - 2018-07-25 14:53:25 --> Input Class Initialized
INFO - 2018-07-25 14:53:25 --> Language Class Initialized
INFO - 2018-07-25 14:53:25 --> Loader Class Initialized
INFO - 2018-07-25 14:53:25 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:25 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:25 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:25 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:25 --> Controller Class Initialized
INFO - 2018-07-25 14:53:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:53:25 --> Config Class Initialized
INFO - 2018-07-25 14:53:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:25 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:25 --> URI Class Initialized
INFO - 2018-07-25 14:53:25 --> Router Class Initialized
INFO - 2018-07-25 14:53:25 --> Output Class Initialized
INFO - 2018-07-25 14:53:25 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:25 --> CSRF cookie sent
INFO - 2018-07-25 14:53:25 --> Input Class Initialized
INFO - 2018-07-25 14:53:25 --> Language Class Initialized
INFO - 2018-07-25 14:53:25 --> Loader Class Initialized
INFO - 2018-07-25 14:53:25 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:25 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:25 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:25 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:25 --> Controller Class Initialized
INFO - 2018-07-25 14:53:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 14:53:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 14:53:25 --> Could not find the language line "req_email"
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 14:53:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:53:25 --> Final output sent to browser
DEBUG - 2018-07-25 14:53:25 --> Total execution time: 0.0294
INFO - 2018-07-25 14:53:31 --> Config Class Initialized
INFO - 2018-07-25 14:53:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:31 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:31 --> URI Class Initialized
INFO - 2018-07-25 14:53:31 --> Router Class Initialized
INFO - 2018-07-25 14:53:31 --> Output Class Initialized
INFO - 2018-07-25 14:53:31 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:31 --> CSRF cookie sent
INFO - 2018-07-25 14:53:31 --> Input Class Initialized
INFO - 2018-07-25 14:53:31 --> Language Class Initialized
INFO - 2018-07-25 14:53:31 --> Loader Class Initialized
INFO - 2018-07-25 14:53:31 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:31 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:31 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:31 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:31 --> Controller Class Initialized
INFO - 2018-07-25 14:53:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:53:31 --> Pixel_Model class loaded
INFO - 2018-07-25 14:53:31 --> Database Driver Class Initialized
INFO - 2018-07-25 14:53:31 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:53:31 --> Pagination Class Initialized
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:53:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:53:31 --> Final output sent to browser
DEBUG - 2018-07-25 14:53:31 --> Total execution time: 0.0362
INFO - 2018-07-25 14:53:33 --> Config Class Initialized
INFO - 2018-07-25 14:53:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:33 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:33 --> URI Class Initialized
INFO - 2018-07-25 14:53:33 --> Router Class Initialized
INFO - 2018-07-25 14:53:33 --> Output Class Initialized
INFO - 2018-07-25 14:53:33 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:33 --> CSRF cookie sent
INFO - 2018-07-25 14:53:33 --> Input Class Initialized
INFO - 2018-07-25 14:53:33 --> Language Class Initialized
INFO - 2018-07-25 14:53:33 --> Loader Class Initialized
INFO - 2018-07-25 14:53:33 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:33 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:33 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:33 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:33 --> Controller Class Initialized
INFO - 2018-07-25 14:53:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:53:33 --> Pixel_Model class loaded
INFO - 2018-07-25 14:53:33 --> Database Driver Class Initialized
INFO - 2018-07-25 14:53:33 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:53:33 --> Pagination Class Initialized
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:53:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:53:33 --> Final output sent to browser
DEBUG - 2018-07-25 14:53:33 --> Total execution time: 0.0369
INFO - 2018-07-25 14:53:44 --> Config Class Initialized
INFO - 2018-07-25 14:53:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:44 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:44 --> URI Class Initialized
INFO - 2018-07-25 14:53:44 --> Router Class Initialized
INFO - 2018-07-25 14:53:44 --> Output Class Initialized
INFO - 2018-07-25 14:53:44 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:44 --> CSRF cookie sent
INFO - 2018-07-25 14:53:44 --> Input Class Initialized
INFO - 2018-07-25 14:53:44 --> Language Class Initialized
INFO - 2018-07-25 14:53:44 --> Loader Class Initialized
INFO - 2018-07-25 14:53:44 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:44 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:44 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:44 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:44 --> Controller Class Initialized
INFO - 2018-07-25 14:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:53:44 --> Pixel_Model class loaded
INFO - 2018-07-25 14:53:44 --> Database Driver Class Initialized
INFO - 2018-07-25 14:53:44 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/edit_user.php
INFO - 2018-07-25 14:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:53:44 --> Final output sent to browser
DEBUG - 2018-07-25 14:53:44 --> Total execution time: 0.0445
INFO - 2018-07-25 14:53:48 --> Config Class Initialized
INFO - 2018-07-25 14:53:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 14:53:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 14:53:48 --> Utf8 Class Initialized
INFO - 2018-07-25 14:53:48 --> URI Class Initialized
INFO - 2018-07-25 14:53:48 --> Router Class Initialized
INFO - 2018-07-25 14:53:48 --> Output Class Initialized
INFO - 2018-07-25 14:53:48 --> Security Class Initialized
DEBUG - 2018-07-25 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 14:53:48 --> CSRF cookie sent
INFO - 2018-07-25 14:53:48 --> Input Class Initialized
INFO - 2018-07-25 14:53:48 --> Language Class Initialized
INFO - 2018-07-25 14:53:48 --> Loader Class Initialized
INFO - 2018-07-25 14:53:48 --> Helper loaded: url_helper
INFO - 2018-07-25 14:53:48 --> Helper loaded: form_helper
INFO - 2018-07-25 14:53:48 --> Helper loaded: language_helper
DEBUG - 2018-07-25 14:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 14:53:48 --> User Agent Class Initialized
INFO - 2018-07-25 14:53:48 --> Controller Class Initialized
INFO - 2018-07-25 14:53:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 14:53:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 14:53:48 --> Pixel_Model class loaded
INFO - 2018-07-25 14:53:48 --> Database Driver Class Initialized
INFO - 2018-07-25 14:53:48 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 14:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-07-25 14:53:48 --> Pagination Class Initialized
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/users_list.php
INFO - 2018-07-25 14:53:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 14:53:48 --> Final output sent to browser
DEBUG - 2018-07-25 14:53:48 --> Total execution time: 0.0357
INFO - 2018-07-25 15:00:00 --> Config Class Initialized
INFO - 2018-07-25 15:00:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:00:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:00:00 --> Utf8 Class Initialized
INFO - 2018-07-25 15:00:00 --> URI Class Initialized
DEBUG - 2018-07-25 15:00:00 --> No URI present. Default controller set.
INFO - 2018-07-25 15:00:00 --> Router Class Initialized
INFO - 2018-07-25 15:00:00 --> Output Class Initialized
INFO - 2018-07-25 15:00:00 --> Security Class Initialized
DEBUG - 2018-07-25 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:00:00 --> CSRF cookie sent
INFO - 2018-07-25 15:00:00 --> Input Class Initialized
INFO - 2018-07-25 15:00:00 --> Language Class Initialized
INFO - 2018-07-25 15:00:00 --> Loader Class Initialized
INFO - 2018-07-25 15:00:00 --> Helper loaded: url_helper
INFO - 2018-07-25 15:00:00 --> Helper loaded: form_helper
INFO - 2018-07-25 15:00:00 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:00:00 --> User Agent Class Initialized
INFO - 2018-07-25 15:00:00 --> Controller Class Initialized
INFO - 2018-07-25 15:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:00:00 --> Pixel_Model class loaded
INFO - 2018-07-25 15:00:00 --> Database Driver Class Initialized
INFO - 2018-07-25 15:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:00:00 --> Final output sent to browser
DEBUG - 2018-07-25 15:00:00 --> Total execution time: 0.0331
INFO - 2018-07-25 15:01:30 --> Config Class Initialized
INFO - 2018-07-25 15:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:30 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:30 --> URI Class Initialized
INFO - 2018-07-25 15:01:30 --> Router Class Initialized
INFO - 2018-07-25 15:01:30 --> Output Class Initialized
INFO - 2018-07-25 15:01:30 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:30 --> CSRF cookie sent
INFO - 2018-07-25 15:01:30 --> Input Class Initialized
INFO - 2018-07-25 15:01:30 --> Language Class Initialized
INFO - 2018-07-25 15:01:30 --> Loader Class Initialized
INFO - 2018-07-25 15:01:30 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:30 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:30 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:30 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:30 --> Controller Class Initialized
INFO - 2018-07-25 15:01:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-25 15:01:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:30 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:30 --> Total execution time: 0.0222
INFO - 2018-07-25 15:01:32 --> Config Class Initialized
INFO - 2018-07-25 15:01:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:32 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:32 --> URI Class Initialized
INFO - 2018-07-25 15:01:32 --> Router Class Initialized
INFO - 2018-07-25 15:01:32 --> Output Class Initialized
INFO - 2018-07-25 15:01:32 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:32 --> CSRF cookie sent
INFO - 2018-07-25 15:01:32 --> Input Class Initialized
INFO - 2018-07-25 15:01:32 --> Language Class Initialized
INFO - 2018-07-25 15:01:32 --> Loader Class Initialized
INFO - 2018-07-25 15:01:32 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:32 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:32 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:32 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:32 --> Controller Class Initialized
INFO - 2018-07-25 15:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:32 --> Config Class Initialized
INFO - 2018-07-25 15:01:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:32 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:32 --> URI Class Initialized
INFO - 2018-07-25 15:01:32 --> Router Class Initialized
INFO - 2018-07-25 15:01:32 --> Output Class Initialized
INFO - 2018-07-25 15:01:32 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:32 --> CSRF cookie sent
INFO - 2018-07-25 15:01:32 --> Input Class Initialized
INFO - 2018-07-25 15:01:32 --> Language Class Initialized
INFO - 2018-07-25 15:01:32 --> Loader Class Initialized
INFO - 2018-07-25 15:01:32 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:32 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:32 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:32 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:32 --> Controller Class Initialized
INFO - 2018-07-25 15:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 15:01:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 15:01:32 --> Could not find the language line "req_email"
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 15:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:32 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:32 --> Total execution time: 0.0230
INFO - 2018-07-25 15:01:35 --> Config Class Initialized
INFO - 2018-07-25 15:01:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:35 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:35 --> URI Class Initialized
INFO - 2018-07-25 15:01:35 --> Router Class Initialized
INFO - 2018-07-25 15:01:35 --> Output Class Initialized
INFO - 2018-07-25 15:01:35 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:35 --> CSRF cookie sent
INFO - 2018-07-25 15:01:35 --> Input Class Initialized
INFO - 2018-07-25 15:01:35 --> Language Class Initialized
INFO - 2018-07-25 15:01:35 --> Loader Class Initialized
INFO - 2018-07-25 15:01:35 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:35 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:35 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:35 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:35 --> Controller Class Initialized
INFO - 2018-07-25 15:01:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 15:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:35 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:35 --> Total execution time: 0.0321
INFO - 2018-07-25 15:01:37 --> Config Class Initialized
INFO - 2018-07-25 15:01:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:37 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:37 --> URI Class Initialized
INFO - 2018-07-25 15:01:37 --> Router Class Initialized
INFO - 2018-07-25 15:01:37 --> Output Class Initialized
INFO - 2018-07-25 15:01:37 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:37 --> CSRF cookie sent
INFO - 2018-07-25 15:01:37 --> Input Class Initialized
INFO - 2018-07-25 15:01:37 --> Language Class Initialized
INFO - 2018-07-25 15:01:37 --> Loader Class Initialized
INFO - 2018-07-25 15:01:37 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:37 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:37 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:37 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:37 --> Controller Class Initialized
INFO - 2018-07-25 15:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:37 --> Config Class Initialized
INFO - 2018-07-25 15:01:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:37 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:37 --> URI Class Initialized
INFO - 2018-07-25 15:01:37 --> Router Class Initialized
INFO - 2018-07-25 15:01:37 --> Output Class Initialized
INFO - 2018-07-25 15:01:37 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:37 --> CSRF cookie sent
INFO - 2018-07-25 15:01:37 --> Input Class Initialized
INFO - 2018-07-25 15:01:37 --> Language Class Initialized
INFO - 2018-07-25 15:01:37 --> Loader Class Initialized
INFO - 2018-07-25 15:01:37 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:37 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:37 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:37 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:37 --> Controller Class Initialized
INFO - 2018-07-25 15:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 15:01:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 15:01:37 --> Could not find the language line "req_email"
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:37 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:37 --> Total execution time: 0.0238
INFO - 2018-07-25 15:01:45 --> Config Class Initialized
INFO - 2018-07-25 15:01:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:45 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:45 --> URI Class Initialized
INFO - 2018-07-25 15:01:45 --> Router Class Initialized
INFO - 2018-07-25 15:01:45 --> Output Class Initialized
INFO - 2018-07-25 15:01:45 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:45 --> CSRF cookie sent
INFO - 2018-07-25 15:01:45 --> Input Class Initialized
INFO - 2018-07-25 15:01:45 --> Language Class Initialized
INFO - 2018-07-25 15:01:45 --> Loader Class Initialized
INFO - 2018-07-25 15:01:45 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:45 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:45 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:45 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:45 --> Controller Class Initialized
INFO - 2018-07-25 15:01:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:45 --> CSRF cookie sent
INFO - 2018-07-25 15:01:45 --> Config Class Initialized
INFO - 2018-07-25 15:01:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:45 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:45 --> URI Class Initialized
DEBUG - 2018-07-25 15:01:45 --> No URI present. Default controller set.
INFO - 2018-07-25 15:01:45 --> Router Class Initialized
INFO - 2018-07-25 15:01:45 --> Output Class Initialized
INFO - 2018-07-25 15:01:45 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:45 --> CSRF cookie sent
INFO - 2018-07-25 15:01:45 --> Input Class Initialized
INFO - 2018-07-25 15:01:45 --> Language Class Initialized
INFO - 2018-07-25 15:01:45 --> Loader Class Initialized
INFO - 2018-07-25 15:01:45 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:45 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:45 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:45 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:45 --> Controller Class Initialized
INFO - 2018-07-25 15:01:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:45 --> Pixel_Model class loaded
INFO - 2018-07-25 15:01:45 --> Database Driver Class Initialized
INFO - 2018-07-25 15:01:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 15:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:45 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:45 --> Total execution time: 0.0501
INFO - 2018-07-25 15:01:47 --> Config Class Initialized
INFO - 2018-07-25 15:01:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:47 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:47 --> URI Class Initialized
INFO - 2018-07-25 15:01:47 --> Router Class Initialized
INFO - 2018-07-25 15:01:47 --> Output Class Initialized
INFO - 2018-07-25 15:01:47 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:47 --> CSRF cookie sent
INFO - 2018-07-25 15:01:47 --> Input Class Initialized
INFO - 2018-07-25 15:01:47 --> Language Class Initialized
INFO - 2018-07-25 15:01:48 --> Loader Class Initialized
INFO - 2018-07-25 15:01:48 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:48 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:48 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:48 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:48 --> Controller Class Initialized
INFO - 2018-07-25 15:01:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 15:01:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:48 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:48 --> Total execution time: 0.0205
INFO - 2018-07-25 15:01:49 --> Config Class Initialized
INFO - 2018-07-25 15:01:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:49 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:49 --> URI Class Initialized
INFO - 2018-07-25 15:01:49 --> Router Class Initialized
INFO - 2018-07-25 15:01:49 --> Output Class Initialized
INFO - 2018-07-25 15:01:49 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:49 --> CSRF cookie sent
INFO - 2018-07-25 15:01:49 --> Input Class Initialized
INFO - 2018-07-25 15:01:49 --> Language Class Initialized
INFO - 2018-07-25 15:01:49 --> Loader Class Initialized
INFO - 2018-07-25 15:01:49 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:49 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:49 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:49 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:49 --> Controller Class Initialized
INFO - 2018-07-25 15:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:49 --> Pixel_Model class loaded
INFO - 2018-07-25 15:01:49 --> Database Driver Class Initialized
INFO - 2018-07-25 15:01:49 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-25 15:01:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-25 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:49 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:49 --> Total execution time: 0.0350
INFO - 2018-07-25 15:01:52 --> Config Class Initialized
INFO - 2018-07-25 15:01:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:52 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:52 --> URI Class Initialized
INFO - 2018-07-25 15:01:52 --> Router Class Initialized
INFO - 2018-07-25 15:01:52 --> Output Class Initialized
INFO - 2018-07-25 15:01:52 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:52 --> CSRF cookie sent
INFO - 2018-07-25 15:01:52 --> Input Class Initialized
INFO - 2018-07-25 15:01:52 --> Language Class Initialized
INFO - 2018-07-25 15:01:52 --> Loader Class Initialized
INFO - 2018-07-25 15:01:52 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:52 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:52 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:52 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:52 --> Controller Class Initialized
INFO - 2018-07-25 15:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:52 --> Pixel_Model class loaded
INFO - 2018-07-25 15:01:52 --> Database Driver Class Initialized
INFO - 2018-07-25 15:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:01:52 --> Config Class Initialized
INFO - 2018-07-25 15:01:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:52 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:52 --> URI Class Initialized
INFO - 2018-07-25 15:01:52 --> Router Class Initialized
INFO - 2018-07-25 15:01:52 --> Output Class Initialized
INFO - 2018-07-25 15:01:52 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:52 --> CSRF cookie sent
INFO - 2018-07-25 15:01:52 --> Input Class Initialized
INFO - 2018-07-25 15:01:52 --> Language Class Initialized
INFO - 2018-07-25 15:01:52 --> Loader Class Initialized
INFO - 2018-07-25 15:01:52 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:52 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:52 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:52 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:52 --> Controller Class Initialized
INFO - 2018-07-25 15:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 15:01:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 15:01:52 --> Could not find the language line "req_email"
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 15:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:52 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:52 --> Total execution time: 0.0232
INFO - 2018-07-25 15:01:56 --> Config Class Initialized
INFO - 2018-07-25 15:01:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:01:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:01:56 --> Utf8 Class Initialized
INFO - 2018-07-25 15:01:56 --> URI Class Initialized
DEBUG - 2018-07-25 15:01:56 --> No URI present. Default controller set.
INFO - 2018-07-25 15:01:56 --> Router Class Initialized
INFO - 2018-07-25 15:01:56 --> Output Class Initialized
INFO - 2018-07-25 15:01:56 --> Security Class Initialized
DEBUG - 2018-07-25 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:01:56 --> CSRF cookie sent
INFO - 2018-07-25 15:01:56 --> Input Class Initialized
INFO - 2018-07-25 15:01:56 --> Language Class Initialized
INFO - 2018-07-25 15:01:56 --> Loader Class Initialized
INFO - 2018-07-25 15:01:56 --> Helper loaded: url_helper
INFO - 2018-07-25 15:01:56 --> Helper loaded: form_helper
INFO - 2018-07-25 15:01:56 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:01:56 --> User Agent Class Initialized
INFO - 2018-07-25 15:01:56 --> Controller Class Initialized
INFO - 2018-07-25 15:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:01:56 --> Pixel_Model class loaded
INFO - 2018-07-25 15:01:56 --> Database Driver Class Initialized
INFO - 2018-07-25 15:01:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 15:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:01:56 --> Final output sent to browser
DEBUG - 2018-07-25 15:01:56 --> Total execution time: 0.0353
INFO - 2018-07-25 15:02:03 --> Config Class Initialized
INFO - 2018-07-25 15:02:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:03 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:03 --> URI Class Initialized
INFO - 2018-07-25 15:02:03 --> Router Class Initialized
INFO - 2018-07-25 15:02:03 --> Output Class Initialized
INFO - 2018-07-25 15:02:03 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:03 --> CSRF cookie sent
INFO - 2018-07-25 15:02:03 --> CSRF token verified
INFO - 2018-07-25 15:02:03 --> Input Class Initialized
INFO - 2018-07-25 15:02:03 --> Language Class Initialized
INFO - 2018-07-25 15:02:03 --> Loader Class Initialized
INFO - 2018-07-25 15:02:03 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:03 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:03 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:03 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:03 --> Controller Class Initialized
INFO - 2018-07-25 15:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:03 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:03 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:02:03 --> Config Class Initialized
INFO - 2018-07-25 15:02:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:03 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:03 --> URI Class Initialized
INFO - 2018-07-25 15:02:03 --> Router Class Initialized
INFO - 2018-07-25 15:02:03 --> Output Class Initialized
INFO - 2018-07-25 15:02:03 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:03 --> CSRF cookie sent
INFO - 2018-07-25 15:02:03 --> Input Class Initialized
INFO - 2018-07-25 15:02:03 --> Language Class Initialized
INFO - 2018-07-25 15:02:03 --> Loader Class Initialized
INFO - 2018-07-25 15:02:03 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:03 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:03 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:03 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:03 --> Controller Class Initialized
INFO - 2018-07-25 15:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 15:02:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 15:02:03 --> Could not find the language line "req_email"
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 15:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:02:03 --> Final output sent to browser
DEBUG - 2018-07-25 15:02:03 --> Total execution time: 0.0235
INFO - 2018-07-25 15:02:12 --> Config Class Initialized
INFO - 2018-07-25 15:02:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:12 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:12 --> URI Class Initialized
INFO - 2018-07-25 15:02:12 --> Router Class Initialized
INFO - 2018-07-25 15:02:12 --> Output Class Initialized
INFO - 2018-07-25 15:02:12 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:13 --> CSRF cookie sent
INFO - 2018-07-25 15:02:13 --> CSRF token verified
INFO - 2018-07-25 15:02:13 --> Input Class Initialized
INFO - 2018-07-25 15:02:13 --> Language Class Initialized
INFO - 2018-07-25 15:02:13 --> Loader Class Initialized
INFO - 2018-07-25 15:02:13 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:13 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:13 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:13 --> Controller Class Initialized
INFO - 2018-07-25 15:02:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 15:02:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:02:13 --> Form Validation Class Initialized
INFO - 2018-07-25 15:02:13 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:13 --> Model "AuthenticationModel" initialized
INFO - 2018-07-25 15:02:13 --> Config Class Initialized
INFO - 2018-07-25 15:02:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:13 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:13 --> URI Class Initialized
INFO - 2018-07-25 15:02:13 --> Router Class Initialized
INFO - 2018-07-25 15:02:13 --> Output Class Initialized
INFO - 2018-07-25 15:02:13 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:13 --> CSRF cookie sent
INFO - 2018-07-25 15:02:13 --> Input Class Initialized
INFO - 2018-07-25 15:02:13 --> Language Class Initialized
INFO - 2018-07-25 15:02:13 --> Loader Class Initialized
INFO - 2018-07-25 15:02:13 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:13 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:13 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:13 --> Controller Class Initialized
INFO - 2018-07-25 15:02:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:13 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:13 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-07-25 15:02:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:02:13 --> Final output sent to browser
DEBUG - 2018-07-25 15:02:13 --> Total execution time: 0.0626
INFO - 2018-07-25 15:02:26 --> Config Class Initialized
INFO - 2018-07-25 15:02:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:26 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:26 --> URI Class Initialized
INFO - 2018-07-25 15:02:26 --> Router Class Initialized
INFO - 2018-07-25 15:02:26 --> Output Class Initialized
INFO - 2018-07-25 15:02:26 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:26 --> CSRF cookie sent
INFO - 2018-07-25 15:02:26 --> Input Class Initialized
INFO - 2018-07-25 15:02:26 --> Language Class Initialized
INFO - 2018-07-25 15:02:26 --> Loader Class Initialized
INFO - 2018-07-25 15:02:26 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:26 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:26 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:26 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:26 --> Controller Class Initialized
INFO - 2018-07-25 15:02:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:26 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:26 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/application_view.php
INFO - 2018-07-25 15:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:02:26 --> Final output sent to browser
DEBUG - 2018-07-25 15:02:26 --> Total execution time: 0.0422
INFO - 2018-07-25 15:02:52 --> Config Class Initialized
INFO - 2018-07-25 15:02:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:52 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:52 --> URI Class Initialized
INFO - 2018-07-25 15:02:52 --> Router Class Initialized
INFO - 2018-07-25 15:02:52 --> Output Class Initialized
INFO - 2018-07-25 15:02:52 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:52 --> CSRF cookie sent
INFO - 2018-07-25 15:02:52 --> Input Class Initialized
INFO - 2018-07-25 15:02:52 --> Language Class Initialized
INFO - 2018-07-25 15:02:52 --> Loader Class Initialized
INFO - 2018-07-25 15:02:52 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:52 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:52 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:52 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:52 --> Controller Class Initialized
INFO - 2018-07-25 15:02:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:52 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:52 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:52 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-07-25 15:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:02:52 --> Final output sent to browser
DEBUG - 2018-07-25 15:02:52 --> Total execution time: 0.0327
INFO - 2018-07-25 15:02:54 --> Config Class Initialized
INFO - 2018-07-25 15:02:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:54 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:54 --> URI Class Initialized
INFO - 2018-07-25 15:02:54 --> Router Class Initialized
INFO - 2018-07-25 15:02:54 --> Output Class Initialized
INFO - 2018-07-25 15:02:54 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:54 --> CSRF cookie sent
INFO - 2018-07-25 15:02:54 --> Input Class Initialized
INFO - 2018-07-25 15:02:54 --> Language Class Initialized
INFO - 2018-07-25 15:02:54 --> Loader Class Initialized
INFO - 2018-07-25 15:02:54 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:54 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:54 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:54 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:54 --> Controller Class Initialized
INFO - 2018-07-25 15:02:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:54 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:54 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:54 --> Model "MyAccountModel" initialized
INFO - 2018-07-25 15:02:54 --> Config Class Initialized
INFO - 2018-07-25 15:02:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:02:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:02:54 --> Utf8 Class Initialized
INFO - 2018-07-25 15:02:54 --> URI Class Initialized
INFO - 2018-07-25 15:02:54 --> Router Class Initialized
INFO - 2018-07-25 15:02:54 --> Output Class Initialized
INFO - 2018-07-25 15:02:54 --> Security Class Initialized
DEBUG - 2018-07-25 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:02:54 --> CSRF cookie sent
INFO - 2018-07-25 15:02:54 --> Input Class Initialized
INFO - 2018-07-25 15:02:54 --> Language Class Initialized
INFO - 2018-07-25 15:02:54 --> Loader Class Initialized
INFO - 2018-07-25 15:02:54 --> Helper loaded: url_helper
INFO - 2018-07-25 15:02:54 --> Helper loaded: form_helper
INFO - 2018-07-25 15:02:54 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:02:54 --> User Agent Class Initialized
INFO - 2018-07-25 15:02:54 --> Controller Class Initialized
INFO - 2018-07-25 15:02:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:02:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:02:54 --> Pixel_Model class loaded
INFO - 2018-07-25 15:02:54 --> Database Driver Class Initialized
INFO - 2018-07-25 15:02:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-25 15:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:02:54 --> Final output sent to browser
DEBUG - 2018-07-25 15:02:54 --> Total execution time: 0.0523
INFO - 2018-07-25 15:03:02 --> Config Class Initialized
INFO - 2018-07-25 15:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:02 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:02 --> URI Class Initialized
INFO - 2018-07-25 15:03:02 --> Router Class Initialized
INFO - 2018-07-25 15:03:02 --> Output Class Initialized
INFO - 2018-07-25 15:03:02 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:02 --> CSRF cookie sent
INFO - 2018-07-25 15:03:02 --> CSRF token verified
INFO - 2018-07-25 15:03:02 --> Input Class Initialized
INFO - 2018-07-25 15:03:02 --> Language Class Initialized
INFO - 2018-07-25 15:03:02 --> Loader Class Initialized
INFO - 2018-07-25 15:03:02 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:02 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:02 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:02 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:02 --> Controller Class Initialized
INFO - 2018-07-25 15:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:02 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:02 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:02 --> Form Validation Class Initialized
INFO - 2018-07-25 15:03:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-25 15:03:02 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:02 --> Config Class Initialized
INFO - 2018-07-25 15:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:02 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:02 --> URI Class Initialized
INFO - 2018-07-25 15:03:02 --> Router Class Initialized
INFO - 2018-07-25 15:03:02 --> Output Class Initialized
INFO - 2018-07-25 15:03:02 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:02 --> CSRF cookie sent
INFO - 2018-07-25 15:03:02 --> Input Class Initialized
INFO - 2018-07-25 15:03:02 --> Language Class Initialized
INFO - 2018-07-25 15:03:02 --> Loader Class Initialized
INFO - 2018-07-25 15:03:02 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:02 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:02 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:02 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:02 --> Controller Class Initialized
INFO - 2018-07-25 15:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:02 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:02 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:02 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-25 15:03:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:03:02 --> Final output sent to browser
DEBUG - 2018-07-25 15:03:02 --> Total execution time: 0.0552
INFO - 2018-07-25 15:03:04 --> Config Class Initialized
INFO - 2018-07-25 15:03:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:04 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:04 --> URI Class Initialized
INFO - 2018-07-25 15:03:04 --> Router Class Initialized
INFO - 2018-07-25 15:03:04 --> Output Class Initialized
INFO - 2018-07-25 15:03:04 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:04 --> CSRF cookie sent
INFO - 2018-07-25 15:03:04 --> CSRF token verified
INFO - 2018-07-25 15:03:04 --> Input Class Initialized
INFO - 2018-07-25 15:03:04 --> Language Class Initialized
INFO - 2018-07-25 15:03:04 --> Loader Class Initialized
INFO - 2018-07-25 15:03:04 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:04 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:04 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:04 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:04 --> Controller Class Initialized
INFO - 2018-07-25 15:03:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:04 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:04 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:04 --> Form Validation Class Initialized
INFO - 2018-07-25 15:03:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-25 15:03:04 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:04 --> Config Class Initialized
INFO - 2018-07-25 15:03:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:04 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:04 --> URI Class Initialized
INFO - 2018-07-25 15:03:04 --> Router Class Initialized
INFO - 2018-07-25 15:03:04 --> Output Class Initialized
INFO - 2018-07-25 15:03:04 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:04 --> CSRF cookie sent
INFO - 2018-07-25 15:03:04 --> Input Class Initialized
INFO - 2018-07-25 15:03:04 --> Language Class Initialized
INFO - 2018-07-25 15:03:04 --> Loader Class Initialized
INFO - 2018-07-25 15:03:04 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:04 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:04 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:04 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:04 --> Controller Class Initialized
INFO - 2018-07-25 15:03:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:04 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:04 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:04 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-25 15:03:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:03:04 --> Final output sent to browser
DEBUG - 2018-07-25 15:03:04 --> Total execution time: 0.0518
INFO - 2018-07-25 15:03:13 --> Config Class Initialized
INFO - 2018-07-25 15:03:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:13 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:13 --> URI Class Initialized
INFO - 2018-07-25 15:03:13 --> Router Class Initialized
INFO - 2018-07-25 15:03:13 --> Output Class Initialized
INFO - 2018-07-25 15:03:13 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:13 --> CSRF cookie sent
INFO - 2018-07-25 15:03:13 --> CSRF token verified
INFO - 2018-07-25 15:03:13 --> Input Class Initialized
INFO - 2018-07-25 15:03:13 --> Language Class Initialized
INFO - 2018-07-25 15:03:13 --> Loader Class Initialized
INFO - 2018-07-25 15:03:13 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:13 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:13 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:13 --> Controller Class Initialized
INFO - 2018-07-25 15:03:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:13 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:13 --> Form Validation Class Initialized
INFO - 2018-07-25 15:03:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-25 15:03:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:14 --> Config Class Initialized
INFO - 2018-07-25 15:03:14 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:14 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:14 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:14 --> URI Class Initialized
INFO - 2018-07-25 15:03:14 --> Router Class Initialized
INFO - 2018-07-25 15:03:14 --> Output Class Initialized
INFO - 2018-07-25 15:03:14 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:14 --> CSRF cookie sent
INFO - 2018-07-25 15:03:14 --> Input Class Initialized
INFO - 2018-07-25 15:03:14 --> Language Class Initialized
INFO - 2018-07-25 15:03:14 --> Loader Class Initialized
INFO - 2018-07-25 15:03:14 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:14 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:14 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:14 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:14 --> Controller Class Initialized
INFO - 2018-07-25 15:03:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:14 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:14 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:14 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-25 15:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:03:14 --> Final output sent to browser
DEBUG - 2018-07-25 15:03:14 --> Total execution time: 0.0545
INFO - 2018-07-25 15:03:15 --> Config Class Initialized
INFO - 2018-07-25 15:03:15 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:15 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:15 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:15 --> URI Class Initialized
INFO - 2018-07-25 15:03:15 --> Router Class Initialized
INFO - 2018-07-25 15:03:15 --> Output Class Initialized
INFO - 2018-07-25 15:03:15 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:15 --> CSRF cookie sent
INFO - 2018-07-25 15:03:15 --> CSRF token verified
INFO - 2018-07-25 15:03:15 --> Input Class Initialized
INFO - 2018-07-25 15:03:15 --> Language Class Initialized
INFO - 2018-07-25 15:03:15 --> Loader Class Initialized
INFO - 2018-07-25 15:03:15 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:15 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:15 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:15 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:15 --> Controller Class Initialized
INFO - 2018-07-25 15:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:15 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:15 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:15 --> Form Validation Class Initialized
INFO - 2018-07-25 15:03:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-25 15:03:15 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:15 --> Config Class Initialized
INFO - 2018-07-25 15:03:15 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:03:15 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:03:15 --> Utf8 Class Initialized
INFO - 2018-07-25 15:03:15 --> URI Class Initialized
INFO - 2018-07-25 15:03:15 --> Router Class Initialized
INFO - 2018-07-25 15:03:15 --> Output Class Initialized
INFO - 2018-07-25 15:03:15 --> Security Class Initialized
DEBUG - 2018-07-25 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:03:15 --> CSRF cookie sent
INFO - 2018-07-25 15:03:15 --> Input Class Initialized
INFO - 2018-07-25 15:03:15 --> Language Class Initialized
INFO - 2018-07-25 15:03:15 --> Loader Class Initialized
INFO - 2018-07-25 15:03:15 --> Helper loaded: url_helper
INFO - 2018-07-25 15:03:15 --> Helper loaded: form_helper
INFO - 2018-07-25 15:03:15 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:03:15 --> User Agent Class Initialized
INFO - 2018-07-25 15:03:15 --> Controller Class Initialized
INFO - 2018-07-25 15:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:03:15 --> Pixel_Model class loaded
INFO - 2018-07-25 15:03:15 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:15 --> Database Driver Class Initialized
INFO - 2018-07-25 15:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-25 15:03:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:03:15 --> Final output sent to browser
DEBUG - 2018-07-25 15:03:15 --> Total execution time: 0.0391
INFO - 2018-07-25 15:04:19 --> Config Class Initialized
INFO - 2018-07-25 15:04:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:04:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:04:19 --> Utf8 Class Initialized
INFO - 2018-07-25 15:04:19 --> URI Class Initialized
INFO - 2018-07-25 15:04:19 --> Router Class Initialized
INFO - 2018-07-25 15:04:19 --> Output Class Initialized
INFO - 2018-07-25 15:04:19 --> Security Class Initialized
DEBUG - 2018-07-25 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:04:19 --> CSRF cookie sent
INFO - 2018-07-25 15:04:19 --> Input Class Initialized
INFO - 2018-07-25 15:04:19 --> Language Class Initialized
INFO - 2018-07-25 15:04:19 --> Loader Class Initialized
INFO - 2018-07-25 15:04:20 --> Helper loaded: url_helper
INFO - 2018-07-25 15:04:20 --> Helper loaded: form_helper
INFO - 2018-07-25 15:04:20 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:04:20 --> User Agent Class Initialized
INFO - 2018-07-25 15:04:20 --> Controller Class Initialized
INFO - 2018-07-25 15:04:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:04:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:04:20 --> Pixel_Model class loaded
INFO - 2018-07-25 15:04:20 --> Database Driver Class Initialized
INFO - 2018-07-25 15:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:04:20 --> Database Driver Class Initialized
INFO - 2018-07-25 15:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-25 15:04:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:04:20 --> Final output sent to browser
DEBUG - 2018-07-25 15:04:20 --> Total execution time: 0.0374
INFO - 2018-07-25 15:08:13 --> Config Class Initialized
INFO - 2018-07-25 15:08:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:08:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:08:13 --> Utf8 Class Initialized
INFO - 2018-07-25 15:08:13 --> URI Class Initialized
INFO - 2018-07-25 15:08:13 --> Router Class Initialized
INFO - 2018-07-25 15:08:13 --> Output Class Initialized
INFO - 2018-07-25 15:08:13 --> Security Class Initialized
DEBUG - 2018-07-25 15:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:08:13 --> CSRF cookie sent
INFO - 2018-07-25 15:08:13 --> Input Class Initialized
INFO - 2018-07-25 15:08:13 --> Language Class Initialized
INFO - 2018-07-25 15:08:13 --> Loader Class Initialized
INFO - 2018-07-25 15:08:13 --> Helper loaded: url_helper
INFO - 2018-07-25 15:08:13 --> Helper loaded: form_helper
INFO - 2018-07-25 15:08:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:08:13 --> User Agent Class Initialized
INFO - 2018-07-25 15:08:13 --> Controller Class Initialized
INFO - 2018-07-25 15:08:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:08:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:08:13 --> Pixel_Model class loaded
INFO - 2018-07-25 15:08:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:08:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:08:13 --> Database Driver Class Initialized
INFO - 2018-07-25 15:08:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-25 15:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:08:13 --> Final output sent to browser
DEBUG - 2018-07-25 15:08:13 --> Total execution time: 0.0551
INFO - 2018-07-25 15:08:58 --> Config Class Initialized
INFO - 2018-07-25 15:08:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:08:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:08:58 --> Utf8 Class Initialized
INFO - 2018-07-25 15:08:58 --> URI Class Initialized
INFO - 2018-07-25 15:08:58 --> Router Class Initialized
INFO - 2018-07-25 15:08:58 --> Output Class Initialized
INFO - 2018-07-25 15:08:58 --> Security Class Initialized
DEBUG - 2018-07-25 15:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:08:58 --> CSRF cookie sent
INFO - 2018-07-25 15:08:58 --> Input Class Initialized
INFO - 2018-07-25 15:08:58 --> Language Class Initialized
INFO - 2018-07-25 15:08:58 --> Loader Class Initialized
INFO - 2018-07-25 15:08:58 --> Helper loaded: url_helper
INFO - 2018-07-25 15:08:58 --> Helper loaded: form_helper
INFO - 2018-07-25 15:08:58 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:08:58 --> User Agent Class Initialized
INFO - 2018-07-25 15:08:58 --> Controller Class Initialized
INFO - 2018-07-25 15:08:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:08:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:08:58 --> Pixel_Model class loaded
INFO - 2018-07-25 15:08:58 --> Database Driver Class Initialized
INFO - 2018-07-25 15:08:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:08:58 --> Database Driver Class Initialized
INFO - 2018-07-25 15:08:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-25 15:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:08:58 --> Final output sent to browser
DEBUG - 2018-07-25 15:08:58 --> Total execution time: 0.0463
INFO - 2018-07-25 15:09:00 --> Config Class Initialized
INFO - 2018-07-25 15:09:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:09:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:09:00 --> Utf8 Class Initialized
INFO - 2018-07-25 15:09:00 --> URI Class Initialized
INFO - 2018-07-25 15:09:00 --> Router Class Initialized
INFO - 2018-07-25 15:09:00 --> Output Class Initialized
INFO - 2018-07-25 15:09:00 --> Security Class Initialized
DEBUG - 2018-07-25 15:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:09:00 --> CSRF cookie sent
INFO - 2018-07-25 15:09:00 --> Input Class Initialized
INFO - 2018-07-25 15:09:00 --> Language Class Initialized
INFO - 2018-07-25 15:09:00 --> Loader Class Initialized
INFO - 2018-07-25 15:09:00 --> Helper loaded: url_helper
INFO - 2018-07-25 15:09:00 --> Helper loaded: form_helper
INFO - 2018-07-25 15:09:00 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:09:00 --> User Agent Class Initialized
INFO - 2018-07-25 15:09:00 --> Controller Class Initialized
INFO - 2018-07-25 15:09:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:09:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:09:00 --> Pixel_Model class loaded
INFO - 2018-07-25 15:09:00 --> Database Driver Class Initialized
INFO - 2018-07-25 15:09:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:09:00 --> Database Driver Class Initialized
INFO - 2018-07-25 15:09:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-25 15:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:09:00 --> Final output sent to browser
DEBUG - 2018-07-25 15:09:00 --> Total execution time: 0.0466
INFO - 2018-07-25 15:17:50 --> Config Class Initialized
INFO - 2018-07-25 15:17:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:17:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:17:50 --> Utf8 Class Initialized
INFO - 2018-07-25 15:17:50 --> URI Class Initialized
DEBUG - 2018-07-25 15:17:50 --> No URI present. Default controller set.
INFO - 2018-07-25 15:17:50 --> Router Class Initialized
INFO - 2018-07-25 15:17:50 --> Output Class Initialized
INFO - 2018-07-25 15:17:50 --> Security Class Initialized
DEBUG - 2018-07-25 15:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:17:50 --> CSRF cookie sent
INFO - 2018-07-25 15:17:50 --> Input Class Initialized
INFO - 2018-07-25 15:17:50 --> Language Class Initialized
INFO - 2018-07-25 15:17:50 --> Loader Class Initialized
INFO - 2018-07-25 15:17:50 --> Helper loaded: url_helper
INFO - 2018-07-25 15:17:50 --> Helper loaded: form_helper
INFO - 2018-07-25 15:17:50 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:17:50 --> User Agent Class Initialized
INFO - 2018-07-25 15:17:50 --> Controller Class Initialized
INFO - 2018-07-25 15:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:17:50 --> Pixel_Model class loaded
INFO - 2018-07-25 15:17:50 --> Database Driver Class Initialized
INFO - 2018-07-25 15:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 15:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 15:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:17:50 --> Final output sent to browser
DEBUG - 2018-07-25 15:17:50 --> Total execution time: 0.0356
INFO - 2018-07-25 15:18:42 --> Config Class Initialized
INFO - 2018-07-25 15:18:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 15:18:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 15:18:42 --> Utf8 Class Initialized
INFO - 2018-07-25 15:18:42 --> URI Class Initialized
INFO - 2018-07-25 15:18:42 --> Router Class Initialized
INFO - 2018-07-25 15:18:42 --> Output Class Initialized
INFO - 2018-07-25 15:18:42 --> Security Class Initialized
DEBUG - 2018-07-25 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 15:18:42 --> CSRF cookie sent
INFO - 2018-07-25 15:18:42 --> Input Class Initialized
INFO - 2018-07-25 15:18:42 --> Language Class Initialized
INFO - 2018-07-25 15:18:42 --> Loader Class Initialized
INFO - 2018-07-25 15:18:42 --> Helper loaded: url_helper
INFO - 2018-07-25 15:18:42 --> Helper loaded: form_helper
INFO - 2018-07-25 15:18:42 --> Helper loaded: language_helper
DEBUG - 2018-07-25 15:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 15:18:42 --> User Agent Class Initialized
INFO - 2018-07-25 15:18:42 --> Controller Class Initialized
INFO - 2018-07-25 15:18:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 15:18:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 15:18:42 --> Pixel_Model class loaded
INFO - 2018-07-25 15:18:42 --> Database Driver Class Initialized
INFO - 2018-07-25 15:18:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-25 15:18:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-25 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 15:18:42 --> Final output sent to browser
DEBUG - 2018-07-25 15:18:42 --> Total execution time: 0.0368
INFO - 2018-07-25 16:24:54 --> Config Class Initialized
INFO - 2018-07-25 16:24:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 16:24:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 16:24:54 --> Utf8 Class Initialized
INFO - 2018-07-25 16:24:54 --> URI Class Initialized
DEBUG - 2018-07-25 16:24:54 --> No URI present. Default controller set.
INFO - 2018-07-25 16:24:54 --> Router Class Initialized
INFO - 2018-07-25 16:24:54 --> Output Class Initialized
INFO - 2018-07-25 16:24:54 --> Security Class Initialized
DEBUG - 2018-07-25 16:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 16:24:54 --> CSRF cookie sent
INFO - 2018-07-25 16:24:54 --> Input Class Initialized
INFO - 2018-07-25 16:24:54 --> Language Class Initialized
INFO - 2018-07-25 16:24:54 --> Loader Class Initialized
INFO - 2018-07-25 16:24:54 --> Helper loaded: url_helper
INFO - 2018-07-25 16:24:54 --> Helper loaded: form_helper
INFO - 2018-07-25 16:24:54 --> Helper loaded: language_helper
DEBUG - 2018-07-25 16:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 16:24:54 --> User Agent Class Initialized
INFO - 2018-07-25 16:24:54 --> Controller Class Initialized
INFO - 2018-07-25 16:24:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 16:24:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 16:24:54 --> Pixel_Model class loaded
INFO - 2018-07-25 16:24:54 --> Database Driver Class Initialized
INFO - 2018-07-25 16:24:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 16:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 16:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 16:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 16:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 16:24:54 --> Final output sent to browser
DEBUG - 2018-07-25 16:24:54 --> Total execution time: 0.0355
INFO - 2018-07-25 16:34:49 --> Config Class Initialized
INFO - 2018-07-25 16:34:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 16:34:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 16:34:49 --> Utf8 Class Initialized
INFO - 2018-07-25 16:34:49 --> URI Class Initialized
INFO - 2018-07-25 16:34:49 --> Router Class Initialized
INFO - 2018-07-25 16:34:49 --> Output Class Initialized
INFO - 2018-07-25 16:34:49 --> Security Class Initialized
DEBUG - 2018-07-25 16:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 16:34:49 --> CSRF cookie sent
INFO - 2018-07-25 16:34:49 --> Input Class Initialized
INFO - 2018-07-25 16:34:49 --> Language Class Initialized
INFO - 2018-07-25 16:34:49 --> Loader Class Initialized
INFO - 2018-07-25 16:34:49 --> Helper loaded: url_helper
INFO - 2018-07-25 16:34:49 --> Helper loaded: form_helper
INFO - 2018-07-25 16:34:49 --> Helper loaded: language_helper
DEBUG - 2018-07-25 16:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 16:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 16:34:49 --> User Agent Class Initialized
INFO - 2018-07-25 16:34:49 --> Controller Class Initialized
INFO - 2018-07-25 16:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 16:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-25 16:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 16:34:49 --> Final output sent to browser
DEBUG - 2018-07-25 16:34:49 --> Total execution time: 0.0221
INFO - 2018-07-25 17:12:59 --> Config Class Initialized
INFO - 2018-07-25 17:12:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:12:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:12:59 --> Utf8 Class Initialized
INFO - 2018-07-25 17:12:59 --> URI Class Initialized
DEBUG - 2018-07-25 17:12:59 --> No URI present. Default controller set.
INFO - 2018-07-25 17:12:59 --> Router Class Initialized
INFO - 2018-07-25 17:12:59 --> Output Class Initialized
INFO - 2018-07-25 17:12:59 --> Security Class Initialized
DEBUG - 2018-07-25 17:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:12:59 --> CSRF cookie sent
INFO - 2018-07-25 17:12:59 --> Input Class Initialized
INFO - 2018-07-25 17:12:59 --> Language Class Initialized
INFO - 2018-07-25 17:12:59 --> Loader Class Initialized
INFO - 2018-07-25 17:12:59 --> Helper loaded: url_helper
INFO - 2018-07-25 17:12:59 --> Helper loaded: form_helper
INFO - 2018-07-25 17:12:59 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:12:59 --> User Agent Class Initialized
INFO - 2018-07-25 17:12:59 --> Controller Class Initialized
INFO - 2018-07-25 17:12:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:12:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:12:59 --> Pixel_Model class loaded
INFO - 2018-07-25 17:12:59 --> Database Driver Class Initialized
INFO - 2018-07-25 17:12:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 17:12:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:12:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:12:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 17:12:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:12:59 --> Final output sent to browser
DEBUG - 2018-07-25 17:12:59 --> Total execution time: 0.0379
INFO - 2018-07-25 17:30:36 --> Config Class Initialized
INFO - 2018-07-25 17:30:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:30:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:30:36 --> Utf8 Class Initialized
INFO - 2018-07-25 17:30:36 --> URI Class Initialized
DEBUG - 2018-07-25 17:30:36 --> No URI present. Default controller set.
INFO - 2018-07-25 17:30:36 --> Router Class Initialized
INFO - 2018-07-25 17:30:36 --> Output Class Initialized
INFO - 2018-07-25 17:30:36 --> Security Class Initialized
DEBUG - 2018-07-25 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:30:36 --> CSRF cookie sent
INFO - 2018-07-25 17:30:36 --> Input Class Initialized
INFO - 2018-07-25 17:30:36 --> Language Class Initialized
INFO - 2018-07-25 17:30:36 --> Loader Class Initialized
INFO - 2018-07-25 17:30:36 --> Helper loaded: url_helper
INFO - 2018-07-25 17:30:36 --> Helper loaded: form_helper
INFO - 2018-07-25 17:30:36 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:30:37 --> User Agent Class Initialized
INFO - 2018-07-25 17:30:37 --> Controller Class Initialized
INFO - 2018-07-25 17:30:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:30:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:30:37 --> Pixel_Model class loaded
INFO - 2018-07-25 17:30:37 --> Database Driver Class Initialized
INFO - 2018-07-25 17:30:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 17:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 17:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:30:37 --> Final output sent to browser
DEBUG - 2018-07-25 17:30:37 --> Total execution time: 0.0381
INFO - 2018-07-25 17:50:29 --> Config Class Initialized
INFO - 2018-07-25 17:50:29 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:50:29 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:50:29 --> Utf8 Class Initialized
INFO - 2018-07-25 17:50:29 --> URI Class Initialized
DEBUG - 2018-07-25 17:50:29 --> No URI present. Default controller set.
INFO - 2018-07-25 17:50:29 --> Router Class Initialized
INFO - 2018-07-25 17:50:29 --> Output Class Initialized
INFO - 2018-07-25 17:50:29 --> Security Class Initialized
DEBUG - 2018-07-25 17:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:50:29 --> CSRF cookie sent
INFO - 2018-07-25 17:50:29 --> Input Class Initialized
INFO - 2018-07-25 17:50:29 --> Language Class Initialized
INFO - 2018-07-25 17:50:29 --> Loader Class Initialized
INFO - 2018-07-25 17:50:29 --> Helper loaded: url_helper
INFO - 2018-07-25 17:50:29 --> Helper loaded: form_helper
INFO - 2018-07-25 17:50:29 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:50:29 --> User Agent Class Initialized
INFO - 2018-07-25 17:50:29 --> Controller Class Initialized
INFO - 2018-07-25 17:50:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:50:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:50:29 --> Pixel_Model class loaded
INFO - 2018-07-25 17:50:29 --> Database Driver Class Initialized
INFO - 2018-07-25 17:50:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 17:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:50:29 --> Final output sent to browser
DEBUG - 2018-07-25 17:50:29 --> Total execution time: 0.0380
INFO - 2018-07-25 17:51:05 --> Config Class Initialized
INFO - 2018-07-25 17:51:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:51:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:51:05 --> Utf8 Class Initialized
INFO - 2018-07-25 17:51:05 --> URI Class Initialized
INFO - 2018-07-25 17:51:05 --> Router Class Initialized
INFO - 2018-07-25 17:51:05 --> Output Class Initialized
INFO - 2018-07-25 17:51:05 --> Security Class Initialized
DEBUG - 2018-07-25 17:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:51:05 --> CSRF cookie sent
INFO - 2018-07-25 17:51:05 --> Input Class Initialized
INFO - 2018-07-25 17:51:05 --> Language Class Initialized
INFO - 2018-07-25 17:51:05 --> Loader Class Initialized
INFO - 2018-07-25 17:51:05 --> Helper loaded: url_helper
INFO - 2018-07-25 17:51:05 --> Helper loaded: form_helper
INFO - 2018-07-25 17:51:05 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:51:05 --> User Agent Class Initialized
INFO - 2018-07-25 17:51:05 --> Controller Class Initialized
INFO - 2018-07-25 17:51:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:51:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:51:05 --> Pixel_Model class loaded
INFO - 2018-07-25 17:51:05 --> Database Driver Class Initialized
INFO - 2018-07-25 17:51:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 17:51:06 --> Config Class Initialized
INFO - 2018-07-25 17:51:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:51:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:51:06 --> Utf8 Class Initialized
INFO - 2018-07-25 17:51:06 --> URI Class Initialized
INFO - 2018-07-25 17:51:06 --> Router Class Initialized
INFO - 2018-07-25 17:51:06 --> Output Class Initialized
INFO - 2018-07-25 17:51:06 --> Security Class Initialized
DEBUG - 2018-07-25 17:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:51:06 --> CSRF cookie sent
INFO - 2018-07-25 17:51:06 --> Input Class Initialized
INFO - 2018-07-25 17:51:06 --> Language Class Initialized
INFO - 2018-07-25 17:51:06 --> Loader Class Initialized
INFO - 2018-07-25 17:51:06 --> Helper loaded: url_helper
INFO - 2018-07-25 17:51:06 --> Helper loaded: form_helper
INFO - 2018-07-25 17:51:06 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:51:06 --> User Agent Class Initialized
INFO - 2018-07-25 17:51:06 --> Controller Class Initialized
INFO - 2018-07-25 17:51:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:51:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 17:51:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 17:51:06 --> Could not find the language line "req_email"
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 17:51:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:51:06 --> Final output sent to browser
DEBUG - 2018-07-25 17:51:06 --> Total execution time: 0.0238
INFO - 2018-07-25 17:51:16 --> Config Class Initialized
INFO - 2018-07-25 17:51:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:51:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:51:16 --> Utf8 Class Initialized
INFO - 2018-07-25 17:51:16 --> URI Class Initialized
INFO - 2018-07-25 17:51:16 --> Router Class Initialized
INFO - 2018-07-25 17:51:16 --> Output Class Initialized
INFO - 2018-07-25 17:51:16 --> Security Class Initialized
DEBUG - 2018-07-25 17:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:51:16 --> CSRF cookie sent
INFO - 2018-07-25 17:51:16 --> Input Class Initialized
INFO - 2018-07-25 17:51:16 --> Language Class Initialized
INFO - 2018-07-25 17:51:16 --> Loader Class Initialized
INFO - 2018-07-25 17:51:16 --> Helper loaded: url_helper
INFO - 2018-07-25 17:51:16 --> Helper loaded: form_helper
INFO - 2018-07-25 17:51:16 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:51:16 --> User Agent Class Initialized
INFO - 2018-07-25 17:51:16 --> Controller Class Initialized
INFO - 2018-07-25 17:51:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:51:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:51:16 --> Pixel_Model class loaded
INFO - 2018-07-25 17:51:16 --> Database Driver Class Initialized
INFO - 2018-07-25 17:51:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-25 17:51:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-25 17:51:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:51:16 --> Final output sent to browser
DEBUG - 2018-07-25 17:51:16 --> Total execution time: 0.0329
INFO - 2018-07-25 17:55:34 --> Config Class Initialized
INFO - 2018-07-25 17:55:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 17:55:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 17:55:34 --> Utf8 Class Initialized
INFO - 2018-07-25 17:55:34 --> URI Class Initialized
DEBUG - 2018-07-25 17:55:34 --> No URI present. Default controller set.
INFO - 2018-07-25 17:55:34 --> Router Class Initialized
INFO - 2018-07-25 17:55:34 --> Output Class Initialized
INFO - 2018-07-25 17:55:34 --> Security Class Initialized
DEBUG - 2018-07-25 17:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 17:55:34 --> CSRF cookie sent
INFO - 2018-07-25 17:55:34 --> Input Class Initialized
INFO - 2018-07-25 17:55:34 --> Language Class Initialized
INFO - 2018-07-25 17:55:34 --> Loader Class Initialized
INFO - 2018-07-25 17:55:34 --> Helper loaded: url_helper
INFO - 2018-07-25 17:55:34 --> Helper loaded: form_helper
INFO - 2018-07-25 17:55:34 --> Helper loaded: language_helper
DEBUG - 2018-07-25 17:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 17:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 17:55:34 --> User Agent Class Initialized
INFO - 2018-07-25 17:55:34 --> Controller Class Initialized
INFO - 2018-07-25 17:55:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 17:55:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 17:55:34 --> Pixel_Model class loaded
INFO - 2018-07-25 17:55:34 --> Database Driver Class Initialized
INFO - 2018-07-25 17:55:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 17:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 17:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 17:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 17:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 17:55:34 --> Final output sent to browser
DEBUG - 2018-07-25 17:55:34 --> Total execution time: 0.0344
INFO - 2018-07-25 18:17:04 --> Config Class Initialized
INFO - 2018-07-25 18:17:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 18:17:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 18:17:04 --> Utf8 Class Initialized
INFO - 2018-07-25 18:17:04 --> URI Class Initialized
INFO - 2018-07-25 18:17:04 --> Router Class Initialized
INFO - 2018-07-25 18:17:04 --> Output Class Initialized
INFO - 2018-07-25 18:17:04 --> Security Class Initialized
DEBUG - 2018-07-25 18:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 18:17:04 --> CSRF cookie sent
INFO - 2018-07-25 18:17:04 --> Input Class Initialized
INFO - 2018-07-25 18:17:04 --> Language Class Initialized
INFO - 2018-07-25 18:17:04 --> Loader Class Initialized
INFO - 2018-07-25 18:17:04 --> Helper loaded: url_helper
INFO - 2018-07-25 18:17:04 --> Helper loaded: form_helper
INFO - 2018-07-25 18:17:04 --> Helper loaded: language_helper
DEBUG - 2018-07-25 18:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 18:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 18:17:04 --> User Agent Class Initialized
INFO - 2018-07-25 18:17:04 --> Controller Class Initialized
INFO - 2018-07-25 18:17:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 18:17:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 18:17:04 --> Pixel_Model class loaded
INFO - 2018-07-25 18:17:04 --> Database Driver Class Initialized
INFO - 2018-07-25 18:17:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 18:17:05 --> Config Class Initialized
INFO - 2018-07-25 18:17:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 18:17:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 18:17:05 --> Utf8 Class Initialized
INFO - 2018-07-25 18:17:05 --> URI Class Initialized
INFO - 2018-07-25 18:17:05 --> Router Class Initialized
INFO - 2018-07-25 18:17:05 --> Output Class Initialized
INFO - 2018-07-25 18:17:05 --> Security Class Initialized
DEBUG - 2018-07-25 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 18:17:05 --> CSRF cookie sent
INFO - 2018-07-25 18:17:05 --> Input Class Initialized
INFO - 2018-07-25 18:17:05 --> Language Class Initialized
INFO - 2018-07-25 18:17:05 --> Loader Class Initialized
INFO - 2018-07-25 18:17:05 --> Helper loaded: url_helper
INFO - 2018-07-25 18:17:05 --> Helper loaded: form_helper
INFO - 2018-07-25 18:17:05 --> Helper loaded: language_helper
DEBUG - 2018-07-25 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 18:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 18:17:05 --> User Agent Class Initialized
INFO - 2018-07-25 18:17:05 --> Controller Class Initialized
INFO - 2018-07-25 18:17:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 18:17:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 18:17:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 18:17:05 --> Could not find the language line "req_email"
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 18:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 18:17:05 --> Final output sent to browser
DEBUG - 2018-07-25 18:17:05 --> Total execution time: 0.0234
INFO - 2018-07-25 18:21:18 --> Config Class Initialized
INFO - 2018-07-25 18:21:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 18:21:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 18:21:18 --> Utf8 Class Initialized
INFO - 2018-07-25 18:21:18 --> URI Class Initialized
DEBUG - 2018-07-25 18:21:18 --> No URI present. Default controller set.
INFO - 2018-07-25 18:21:18 --> Router Class Initialized
INFO - 2018-07-25 18:21:18 --> Output Class Initialized
INFO - 2018-07-25 18:21:18 --> Security Class Initialized
DEBUG - 2018-07-25 18:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 18:21:18 --> CSRF cookie sent
INFO - 2018-07-25 18:21:18 --> Input Class Initialized
INFO - 2018-07-25 18:21:18 --> Language Class Initialized
INFO - 2018-07-25 18:21:18 --> Loader Class Initialized
INFO - 2018-07-25 18:21:18 --> Helper loaded: url_helper
INFO - 2018-07-25 18:21:18 --> Helper loaded: form_helper
INFO - 2018-07-25 18:21:18 --> Helper loaded: language_helper
DEBUG - 2018-07-25 18:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 18:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 18:21:18 --> User Agent Class Initialized
INFO - 2018-07-25 18:21:18 --> Controller Class Initialized
INFO - 2018-07-25 18:21:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 18:21:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 18:21:18 --> Pixel_Model class loaded
INFO - 2018-07-25 18:21:18 --> Database Driver Class Initialized
INFO - 2018-07-25 18:21:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 18:21:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 18:21:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 18:21:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 18:21:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 18:21:18 --> Final output sent to browser
DEBUG - 2018-07-25 18:21:18 --> Total execution time: 0.0368
INFO - 2018-07-25 18:23:56 --> Config Class Initialized
INFO - 2018-07-25 18:23:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 18:23:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 18:23:56 --> Utf8 Class Initialized
INFO - 2018-07-25 18:23:56 --> URI Class Initialized
INFO - 2018-07-25 18:23:56 --> Router Class Initialized
INFO - 2018-07-25 18:23:56 --> Output Class Initialized
INFO - 2018-07-25 18:23:56 --> Security Class Initialized
DEBUG - 2018-07-25 18:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 18:23:56 --> CSRF cookie sent
INFO - 2018-07-25 18:23:56 --> Input Class Initialized
INFO - 2018-07-25 18:23:56 --> Language Class Initialized
ERROR - 2018-07-25 18:23:56 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-25 18:52:40 --> Config Class Initialized
INFO - 2018-07-25 18:52:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 18:52:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 18:52:40 --> Utf8 Class Initialized
INFO - 2018-07-25 18:52:40 --> URI Class Initialized
DEBUG - 2018-07-25 18:52:40 --> No URI present. Default controller set.
INFO - 2018-07-25 18:52:40 --> Router Class Initialized
INFO - 2018-07-25 18:52:40 --> Output Class Initialized
INFO - 2018-07-25 18:52:40 --> Security Class Initialized
DEBUG - 2018-07-25 18:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 18:52:40 --> CSRF cookie sent
INFO - 2018-07-25 18:52:40 --> Input Class Initialized
INFO - 2018-07-25 18:52:40 --> Language Class Initialized
INFO - 2018-07-25 18:52:40 --> Loader Class Initialized
INFO - 2018-07-25 18:52:40 --> Helper loaded: url_helper
INFO - 2018-07-25 18:52:40 --> Helper loaded: form_helper
INFO - 2018-07-25 18:52:40 --> Helper loaded: language_helper
DEBUG - 2018-07-25 18:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 18:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 18:52:40 --> User Agent Class Initialized
INFO - 2018-07-25 18:52:40 --> Controller Class Initialized
INFO - 2018-07-25 18:52:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 18:52:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 18:52:40 --> Pixel_Model class loaded
INFO - 2018-07-25 18:52:40 --> Database Driver Class Initialized
INFO - 2018-07-25 18:52:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 18:52:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 18:52:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 18:52:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 18:52:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 18:52:40 --> Final output sent to browser
DEBUG - 2018-07-25 18:52:40 --> Total execution time: 0.0345
INFO - 2018-07-25 19:01:05 --> Config Class Initialized
INFO - 2018-07-25 19:01:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:05 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:05 --> URI Class Initialized
DEBUG - 2018-07-25 19:01:05 --> No URI present. Default controller set.
INFO - 2018-07-25 19:01:05 --> Router Class Initialized
INFO - 2018-07-25 19:01:05 --> Output Class Initialized
INFO - 2018-07-25 19:01:05 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:05 --> CSRF cookie sent
INFO - 2018-07-25 19:01:05 --> Input Class Initialized
INFO - 2018-07-25 19:01:05 --> Language Class Initialized
INFO - 2018-07-25 19:01:05 --> Loader Class Initialized
INFO - 2018-07-25 19:01:05 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:05 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:05 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:05 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:05 --> Controller Class Initialized
INFO - 2018-07-25 19:01:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:05 --> Pixel_Model class loaded
INFO - 2018-07-25 19:01:05 --> Database Driver Class Initialized
INFO - 2018-07-25 19:01:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:05 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:05 --> Total execution time: 0.0349
INFO - 2018-07-25 19:01:21 --> Config Class Initialized
INFO - 2018-07-25 19:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:21 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:21 --> URI Class Initialized
INFO - 2018-07-25 19:01:21 --> Router Class Initialized
INFO - 2018-07-25 19:01:21 --> Output Class Initialized
INFO - 2018-07-25 19:01:21 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:21 --> CSRF cookie sent
INFO - 2018-07-25 19:01:21 --> Input Class Initialized
INFO - 2018-07-25 19:01:21 --> Language Class Initialized
INFO - 2018-07-25 19:01:21 --> Loader Class Initialized
INFO - 2018-07-25 19:01:21 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:21 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:21 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:21 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:21 --> Controller Class Initialized
INFO - 2018-07-25 19:01:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-25 19:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:21 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:21 --> Total execution time: 0.0249
INFO - 2018-07-25 19:01:27 --> Config Class Initialized
INFO - 2018-07-25 19:01:27 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:27 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:27 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:27 --> URI Class Initialized
INFO - 2018-07-25 19:01:27 --> Router Class Initialized
INFO - 2018-07-25 19:01:27 --> Output Class Initialized
INFO - 2018-07-25 19:01:27 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:27 --> CSRF cookie sent
INFO - 2018-07-25 19:01:27 --> Input Class Initialized
INFO - 2018-07-25 19:01:27 --> Language Class Initialized
INFO - 2018-07-25 19:01:27 --> Loader Class Initialized
INFO - 2018-07-25 19:01:27 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:27 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:27 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:27 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:27 --> Controller Class Initialized
INFO - 2018-07-25 19:01:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-25 19:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:27 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:27 --> Total execution time: 0.0210
INFO - 2018-07-25 19:01:33 --> Config Class Initialized
INFO - 2018-07-25 19:01:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:33 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:33 --> URI Class Initialized
INFO - 2018-07-25 19:01:33 --> Router Class Initialized
INFO - 2018-07-25 19:01:33 --> Output Class Initialized
INFO - 2018-07-25 19:01:33 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:33 --> CSRF cookie sent
INFO - 2018-07-25 19:01:33 --> Input Class Initialized
INFO - 2018-07-25 19:01:33 --> Language Class Initialized
INFO - 2018-07-25 19:01:33 --> Loader Class Initialized
INFO - 2018-07-25 19:01:33 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:33 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:33 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:33 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:33 --> Controller Class Initialized
INFO - 2018-07-25 19:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-07-25 19:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:33 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:33 --> Total execution time: 0.0374
INFO - 2018-07-25 19:01:45 --> Config Class Initialized
INFO - 2018-07-25 19:01:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:45 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:45 --> URI Class Initialized
INFO - 2018-07-25 19:01:45 --> Router Class Initialized
INFO - 2018-07-25 19:01:45 --> Output Class Initialized
INFO - 2018-07-25 19:01:45 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:45 --> CSRF cookie sent
INFO - 2018-07-25 19:01:45 --> Input Class Initialized
INFO - 2018-07-25 19:01:45 --> Language Class Initialized
INFO - 2018-07-25 19:01:45 --> Loader Class Initialized
INFO - 2018-07-25 19:01:45 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:45 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:45 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:45 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:45 --> Controller Class Initialized
INFO - 2018-07-25 19:01:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-25 19:01:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:45 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:45 --> Total execution time: 0.0218
INFO - 2018-07-25 19:01:49 --> Config Class Initialized
INFO - 2018-07-25 19:01:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:01:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:01:49 --> Utf8 Class Initialized
INFO - 2018-07-25 19:01:49 --> URI Class Initialized
INFO - 2018-07-25 19:01:49 --> Router Class Initialized
INFO - 2018-07-25 19:01:49 --> Output Class Initialized
INFO - 2018-07-25 19:01:49 --> Security Class Initialized
DEBUG - 2018-07-25 19:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:01:49 --> CSRF cookie sent
INFO - 2018-07-25 19:01:49 --> Input Class Initialized
INFO - 2018-07-25 19:01:49 --> Language Class Initialized
INFO - 2018-07-25 19:01:49 --> Loader Class Initialized
INFO - 2018-07-25 19:01:49 --> Helper loaded: url_helper
INFO - 2018-07-25 19:01:49 --> Helper loaded: form_helper
INFO - 2018-07-25 19:01:49 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:01:49 --> User Agent Class Initialized
INFO - 2018-07-25 19:01:49 --> Controller Class Initialized
INFO - 2018-07-25 19:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-07-25 19:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:01:49 --> Final output sent to browser
DEBUG - 2018-07-25 19:01:49 --> Total execution time: 0.0315
INFO - 2018-07-25 19:02:03 --> Config Class Initialized
INFO - 2018-07-25 19:02:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:03 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:03 --> URI Class Initialized
INFO - 2018-07-25 19:02:03 --> Router Class Initialized
INFO - 2018-07-25 19:02:03 --> Output Class Initialized
INFO - 2018-07-25 19:02:03 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:03 --> CSRF cookie sent
INFO - 2018-07-25 19:02:03 --> Input Class Initialized
INFO - 2018-07-25 19:02:03 --> Language Class Initialized
INFO - 2018-07-25 19:02:03 --> Loader Class Initialized
INFO - 2018-07-25 19:02:03 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:03 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:03 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:03 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:03 --> Controller Class Initialized
INFO - 2018-07-25 19:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:03 --> Pixel_Model class loaded
INFO - 2018-07-25 19:02:03 --> Database Driver Class Initialized
INFO - 2018-07-25 19:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:02:04 --> Config Class Initialized
INFO - 2018-07-25 19:02:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:04 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:04 --> URI Class Initialized
INFO - 2018-07-25 19:02:04 --> Router Class Initialized
INFO - 2018-07-25 19:02:04 --> Output Class Initialized
INFO - 2018-07-25 19:02:04 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:04 --> CSRF cookie sent
INFO - 2018-07-25 19:02:04 --> Input Class Initialized
INFO - 2018-07-25 19:02:04 --> Language Class Initialized
INFO - 2018-07-25 19:02:04 --> Loader Class Initialized
INFO - 2018-07-25 19:02:04 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:04 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:04 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:04 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:04 --> Controller Class Initialized
INFO - 2018-07-25 19:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 19:02:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 19:02:04 --> Could not find the language line "req_email"
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 19:02:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:04 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:04 --> Total execution time: 0.0300
INFO - 2018-07-25 19:02:09 --> Config Class Initialized
INFO - 2018-07-25 19:02:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:09 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:09 --> URI Class Initialized
DEBUG - 2018-07-25 19:02:09 --> No URI present. Default controller set.
INFO - 2018-07-25 19:02:09 --> Router Class Initialized
INFO - 2018-07-25 19:02:09 --> Output Class Initialized
INFO - 2018-07-25 19:02:09 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:09 --> CSRF cookie sent
INFO - 2018-07-25 19:02:09 --> Input Class Initialized
INFO - 2018-07-25 19:02:09 --> Language Class Initialized
INFO - 2018-07-25 19:02:09 --> Loader Class Initialized
INFO - 2018-07-25 19:02:09 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:09 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:09 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:09 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:09 --> Controller Class Initialized
INFO - 2018-07-25 19:02:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:09 --> Pixel_Model class loaded
INFO - 2018-07-25 19:02:09 --> Database Driver Class Initialized
INFO - 2018-07-25 19:02:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:09 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:09 --> Total execution time: 0.0418
INFO - 2018-07-25 19:02:16 --> Config Class Initialized
INFO - 2018-07-25 19:02:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:16 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:16 --> URI Class Initialized
INFO - 2018-07-25 19:02:16 --> Router Class Initialized
INFO - 2018-07-25 19:02:16 --> Output Class Initialized
INFO - 2018-07-25 19:02:16 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:16 --> CSRF cookie sent
INFO - 2018-07-25 19:02:16 --> Input Class Initialized
INFO - 2018-07-25 19:02:16 --> Language Class Initialized
INFO - 2018-07-25 19:02:16 --> Loader Class Initialized
INFO - 2018-07-25 19:02:16 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:16 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:16 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:16 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:16 --> Controller Class Initialized
INFO - 2018-07-25 19:02:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:16 --> Pixel_Model class loaded
INFO - 2018-07-25 19:02:16 --> Database Driver Class Initialized
INFO - 2018-07-25 19:02:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:02:16 --> Config Class Initialized
INFO - 2018-07-25 19:02:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:16 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:16 --> URI Class Initialized
INFO - 2018-07-25 19:02:16 --> Router Class Initialized
INFO - 2018-07-25 19:02:16 --> Output Class Initialized
INFO - 2018-07-25 19:02:16 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:16 --> CSRF cookie sent
INFO - 2018-07-25 19:02:16 --> Input Class Initialized
INFO - 2018-07-25 19:02:16 --> Language Class Initialized
INFO - 2018-07-25 19:02:16 --> Loader Class Initialized
INFO - 2018-07-25 19:02:16 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:16 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:16 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:16 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:16 --> Controller Class Initialized
INFO - 2018-07-25 19:02:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 19:02:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 19:02:16 --> Could not find the language line "req_email"
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 19:02:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:16 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:16 --> Total execution time: 0.0275
INFO - 2018-07-25 19:02:18 --> Config Class Initialized
INFO - 2018-07-25 19:02:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:18 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:18 --> URI Class Initialized
INFO - 2018-07-25 19:02:18 --> Router Class Initialized
INFO - 2018-07-25 19:02:18 --> Output Class Initialized
INFO - 2018-07-25 19:02:18 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:18 --> CSRF cookie sent
INFO - 2018-07-25 19:02:18 --> Input Class Initialized
INFO - 2018-07-25 19:02:18 --> Language Class Initialized
INFO - 2018-07-25 19:02:18 --> Loader Class Initialized
INFO - 2018-07-25 19:02:18 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:18 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:18 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:18 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:18 --> Controller Class Initialized
INFO - 2018-07-25 19:02:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 19:02:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:18 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:18 --> Total execution time: 0.0256
INFO - 2018-07-25 19:02:23 --> Config Class Initialized
INFO - 2018-07-25 19:02:23 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:23 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:23 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:23 --> URI Class Initialized
INFO - 2018-07-25 19:02:23 --> Router Class Initialized
INFO - 2018-07-25 19:02:23 --> Output Class Initialized
INFO - 2018-07-25 19:02:23 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:23 --> CSRF cookie sent
INFO - 2018-07-25 19:02:23 --> Input Class Initialized
INFO - 2018-07-25 19:02:23 --> Language Class Initialized
ERROR - 2018-07-25 19:02:23 --> 404 Page Not Found: Faviconico/index
INFO - 2018-07-25 19:02:28 --> Config Class Initialized
INFO - 2018-07-25 19:02:28 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:28 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:28 --> URI Class Initialized
INFO - 2018-07-25 19:02:28 --> Router Class Initialized
INFO - 2018-07-25 19:02:28 --> Output Class Initialized
INFO - 2018-07-25 19:02:28 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:28 --> CSRF cookie sent
INFO - 2018-07-25 19:02:28 --> Input Class Initialized
INFO - 2018-07-25 19:02:28 --> Language Class Initialized
INFO - 2018-07-25 19:02:28 --> Loader Class Initialized
INFO - 2018-07-25 19:02:28 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:28 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:28 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:28 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:28 --> Controller Class Initialized
INFO - 2018-07-25 19:02:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 19:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:28 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:28 --> Total execution time: 0.0196
INFO - 2018-07-25 19:02:31 --> Config Class Initialized
INFO - 2018-07-25 19:02:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:02:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:02:31 --> Utf8 Class Initialized
INFO - 2018-07-25 19:02:31 --> URI Class Initialized
INFO - 2018-07-25 19:02:31 --> Router Class Initialized
INFO - 2018-07-25 19:02:31 --> Output Class Initialized
INFO - 2018-07-25 19:02:31 --> Security Class Initialized
DEBUG - 2018-07-25 19:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:02:31 --> CSRF cookie sent
INFO - 2018-07-25 19:02:31 --> Input Class Initialized
INFO - 2018-07-25 19:02:31 --> Language Class Initialized
INFO - 2018-07-25 19:02:31 --> Loader Class Initialized
INFO - 2018-07-25 19:02:31 --> Helper loaded: url_helper
INFO - 2018-07-25 19:02:31 --> Helper loaded: form_helper
INFO - 2018-07-25 19:02:31 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:02:31 --> User Agent Class Initialized
INFO - 2018-07-25 19:02:31 --> Controller Class Initialized
INFO - 2018-07-25 19:02:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:02:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-25 19:02:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:02:31 --> Final output sent to browser
DEBUG - 2018-07-25 19:02:31 --> Total execution time: 0.0219
INFO - 2018-07-25 19:03:39 --> Config Class Initialized
INFO - 2018-07-25 19:03:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:03:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:03:39 --> Utf8 Class Initialized
INFO - 2018-07-25 19:03:39 --> URI Class Initialized
INFO - 2018-07-25 19:03:39 --> Router Class Initialized
INFO - 2018-07-25 19:03:39 --> Output Class Initialized
INFO - 2018-07-25 19:03:39 --> Security Class Initialized
DEBUG - 2018-07-25 19:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:03:39 --> CSRF cookie sent
INFO - 2018-07-25 19:03:39 --> Input Class Initialized
INFO - 2018-07-25 19:03:39 --> Language Class Initialized
INFO - 2018-07-25 19:03:39 --> Loader Class Initialized
INFO - 2018-07-25 19:03:39 --> Helper loaded: url_helper
INFO - 2018-07-25 19:03:39 --> Helper loaded: form_helper
INFO - 2018-07-25 19:03:39 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:03:39 --> User Agent Class Initialized
INFO - 2018-07-25 19:03:39 --> Controller Class Initialized
INFO - 2018-07-25 19:03:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:03:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 19:03:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:03:39 --> Final output sent to browser
DEBUG - 2018-07-25 19:03:39 --> Total execution time: 0.0252
INFO - 2018-07-25 19:19:13 --> Config Class Initialized
INFO - 2018-07-25 19:19:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:19:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:19:13 --> Utf8 Class Initialized
INFO - 2018-07-25 19:19:13 --> URI Class Initialized
DEBUG - 2018-07-25 19:19:13 --> No URI present. Default controller set.
INFO - 2018-07-25 19:19:13 --> Router Class Initialized
INFO - 2018-07-25 19:19:13 --> Output Class Initialized
INFO - 2018-07-25 19:19:13 --> Security Class Initialized
DEBUG - 2018-07-25 19:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:19:13 --> CSRF cookie sent
INFO - 2018-07-25 19:19:13 --> Input Class Initialized
INFO - 2018-07-25 19:19:13 --> Language Class Initialized
INFO - 2018-07-25 19:19:13 --> Loader Class Initialized
INFO - 2018-07-25 19:19:13 --> Helper loaded: url_helper
INFO - 2018-07-25 19:19:13 --> Helper loaded: form_helper
INFO - 2018-07-25 19:19:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:19:13 --> User Agent Class Initialized
INFO - 2018-07-25 19:19:13 --> Controller Class Initialized
INFO - 2018-07-25 19:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:19:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:19:13 --> Pixel_Model class loaded
INFO - 2018-07-25 19:19:13 --> Database Driver Class Initialized
INFO - 2018-07-25 19:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:19:13 --> Final output sent to browser
DEBUG - 2018-07-25 19:19:13 --> Total execution time: 0.0365
INFO - 2018-07-25 19:30:00 --> Config Class Initialized
INFO - 2018-07-25 19:30:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:00 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:00 --> URI Class Initialized
DEBUG - 2018-07-25 19:30:00 --> No URI present. Default controller set.
INFO - 2018-07-25 19:30:00 --> Router Class Initialized
INFO - 2018-07-25 19:30:00 --> Output Class Initialized
INFO - 2018-07-25 19:30:00 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:00 --> CSRF cookie sent
INFO - 2018-07-25 19:30:00 --> Input Class Initialized
INFO - 2018-07-25 19:30:00 --> Language Class Initialized
INFO - 2018-07-25 19:30:00 --> Loader Class Initialized
INFO - 2018-07-25 19:30:00 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:00 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:00 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:00 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:00 --> Controller Class Initialized
INFO - 2018-07-25 19:30:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:00 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:00 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:00 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:00 --> Total execution time: 0.0346
INFO - 2018-07-25 19:30:01 --> Config Class Initialized
INFO - 2018-07-25 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:01 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:01 --> URI Class Initialized
DEBUG - 2018-07-25 19:30:01 --> No URI present. Default controller set.
INFO - 2018-07-25 19:30:01 --> Router Class Initialized
INFO - 2018-07-25 19:30:01 --> Output Class Initialized
INFO - 2018-07-25 19:30:01 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:01 --> CSRF cookie sent
INFO - 2018-07-25 19:30:01 --> Input Class Initialized
INFO - 2018-07-25 19:30:01 --> Language Class Initialized
INFO - 2018-07-25 19:30:01 --> Loader Class Initialized
INFO - 2018-07-25 19:30:01 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:01 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:01 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:01 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:01 --> Controller Class Initialized
INFO - 2018-07-25 19:30:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:01 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:01 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:01 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:01 --> Total execution time: 0.2044
INFO - 2018-07-25 19:30:02 --> Config Class Initialized
INFO - 2018-07-25 19:30:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:02 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:02 --> URI Class Initialized
DEBUG - 2018-07-25 19:30:02 --> No URI present. Default controller set.
INFO - 2018-07-25 19:30:02 --> Router Class Initialized
INFO - 2018-07-25 19:30:02 --> Output Class Initialized
INFO - 2018-07-25 19:30:02 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:02 --> CSRF cookie sent
INFO - 2018-07-25 19:30:02 --> Input Class Initialized
INFO - 2018-07-25 19:30:02 --> Language Class Initialized
INFO - 2018-07-25 19:30:02 --> Loader Class Initialized
INFO - 2018-07-25 19:30:02 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:02 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:02 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:02 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:02 --> Controller Class Initialized
INFO - 2018-07-25 19:30:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:02 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:02 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:30:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:02 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:02 --> Total execution time: 0.0574
INFO - 2018-07-25 19:30:02 --> Config Class Initialized
INFO - 2018-07-25 19:30:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:02 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:02 --> URI Class Initialized
INFO - 2018-07-25 19:30:02 --> Router Class Initialized
INFO - 2018-07-25 19:30:03 --> Output Class Initialized
INFO - 2018-07-25 19:30:03 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:03 --> CSRF cookie sent
INFO - 2018-07-25 19:30:03 --> Input Class Initialized
INFO - 2018-07-25 19:30:03 --> Language Class Initialized
ERROR - 2018-07-25 19:30:03 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-25 19:30:10 --> Config Class Initialized
INFO - 2018-07-25 19:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:10 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:10 --> URI Class Initialized
DEBUG - 2018-07-25 19:30:10 --> No URI present. Default controller set.
INFO - 2018-07-25 19:30:10 --> Router Class Initialized
INFO - 2018-07-25 19:30:10 --> Output Class Initialized
INFO - 2018-07-25 19:30:10 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:10 --> CSRF cookie sent
INFO - 2018-07-25 19:30:10 --> Input Class Initialized
INFO - 2018-07-25 19:30:10 --> Language Class Initialized
INFO - 2018-07-25 19:30:10 --> Loader Class Initialized
INFO - 2018-07-25 19:30:10 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:10 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:10 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:10 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:10 --> Controller Class Initialized
INFO - 2018-07-25 19:30:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:10 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:10 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:10 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:10 --> Total execution time: 0.0315
INFO - 2018-07-25 19:30:10 --> Config Class Initialized
INFO - 2018-07-25 19:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:10 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:10 --> URI Class Initialized
INFO - 2018-07-25 19:30:10 --> Router Class Initialized
INFO - 2018-07-25 19:30:10 --> Output Class Initialized
INFO - 2018-07-25 19:30:10 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:10 --> CSRF cookie sent
INFO - 2018-07-25 19:30:10 --> Input Class Initialized
INFO - 2018-07-25 19:30:10 --> Language Class Initialized
ERROR - 2018-07-25 19:30:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-25 19:30:10 --> Config Class Initialized
INFO - 2018-07-25 19:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:10 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:10 --> URI Class Initialized
INFO - 2018-07-25 19:30:10 --> Router Class Initialized
INFO - 2018-07-25 19:30:10 --> Output Class Initialized
INFO - 2018-07-25 19:30:10 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:10 --> CSRF cookie sent
INFO - 2018-07-25 19:30:10 --> Input Class Initialized
INFO - 2018-07-25 19:30:10 --> Language Class Initialized
ERROR - 2018-07-25 19:30:10 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-25 19:30:11 --> Config Class Initialized
INFO - 2018-07-25 19:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:11 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:11 --> URI Class Initialized
INFO - 2018-07-25 19:30:11 --> Router Class Initialized
INFO - 2018-07-25 19:30:11 --> Output Class Initialized
INFO - 2018-07-25 19:30:11 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:11 --> CSRF cookie sent
INFO - 2018-07-25 19:30:11 --> Input Class Initialized
INFO - 2018-07-25 19:30:11 --> Language Class Initialized
INFO - 2018-07-25 19:30:11 --> Loader Class Initialized
INFO - 2018-07-25 19:30:11 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:11 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:11 --> Controller Class Initialized
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:11 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:11 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:11 --> Config Class Initialized
INFO - 2018-07-25 19:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:11 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:11 --> URI Class Initialized
INFO - 2018-07-25 19:30:11 --> Router Class Initialized
INFO - 2018-07-25 19:30:11 --> Output Class Initialized
INFO - 2018-07-25 19:30:11 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:11 --> CSRF cookie sent
INFO - 2018-07-25 19:30:11 --> Input Class Initialized
INFO - 2018-07-25 19:30:11 --> Language Class Initialized
INFO - 2018-07-25 19:30:11 --> Loader Class Initialized
INFO - 2018-07-25 19:30:11 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:11 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:11 --> Controller Class Initialized
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 19:30:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 19:30:11 --> Could not find the language line "req_email"
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:11 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:11 --> Total execution time: 0.0248
INFO - 2018-07-25 19:30:11 --> Config Class Initialized
INFO - 2018-07-25 19:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:11 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:11 --> URI Class Initialized
INFO - 2018-07-25 19:30:11 --> Router Class Initialized
INFO - 2018-07-25 19:30:11 --> Output Class Initialized
INFO - 2018-07-25 19:30:11 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:11 --> CSRF cookie sent
INFO - 2018-07-25 19:30:11 --> Input Class Initialized
INFO - 2018-07-25 19:30:11 --> Language Class Initialized
INFO - 2018-07-25 19:30:11 --> Loader Class Initialized
INFO - 2018-07-25 19:30:11 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:11 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:11 --> Controller Class Initialized
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:11 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:11 --> Total execution time: 0.0236
INFO - 2018-07-25 19:30:11 --> Config Class Initialized
INFO - 2018-07-25 19:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:11 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:11 --> URI Class Initialized
INFO - 2018-07-25 19:30:11 --> Router Class Initialized
INFO - 2018-07-25 19:30:11 --> Output Class Initialized
INFO - 2018-07-25 19:30:11 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:11 --> CSRF cookie sent
INFO - 2018-07-25 19:30:11 --> Input Class Initialized
INFO - 2018-07-25 19:30:11 --> Language Class Initialized
INFO - 2018-07-25 19:30:11 --> Loader Class Initialized
INFO - 2018-07-25 19:30:11 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:11 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:11 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:11 --> Controller Class Initialized
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-25 19:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:11 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:11 --> Total execution time: 0.0216
INFO - 2018-07-25 19:30:12 --> Config Class Initialized
INFO - 2018-07-25 19:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:12 --> URI Class Initialized
INFO - 2018-07-25 19:30:12 --> Router Class Initialized
INFO - 2018-07-25 19:30:12 --> Output Class Initialized
INFO - 2018-07-25 19:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:12 --> CSRF cookie sent
INFO - 2018-07-25 19:30:12 --> Input Class Initialized
INFO - 2018-07-25 19:30:12 --> Language Class Initialized
INFO - 2018-07-25 19:30:12 --> Loader Class Initialized
INFO - 2018-07-25 19:30:12 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:12 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:12 --> Controller Class Initialized
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:12 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:12 --> Total execution time: 0.0214
INFO - 2018-07-25 19:30:12 --> Config Class Initialized
INFO - 2018-07-25 19:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:12 --> URI Class Initialized
INFO - 2018-07-25 19:30:12 --> Router Class Initialized
INFO - 2018-07-25 19:30:12 --> Output Class Initialized
INFO - 2018-07-25 19:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:12 --> CSRF cookie sent
INFO - 2018-07-25 19:30:12 --> Input Class Initialized
INFO - 2018-07-25 19:30:12 --> Language Class Initialized
INFO - 2018-07-25 19:30:12 --> Loader Class Initialized
INFO - 2018-07-25 19:30:12 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:12 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:12 --> Controller Class Initialized
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:12 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:12 --> Total execution time: 0.0340
INFO - 2018-07-25 19:30:12 --> Config Class Initialized
INFO - 2018-07-25 19:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:12 --> URI Class Initialized
INFO - 2018-07-25 19:30:12 --> Router Class Initialized
INFO - 2018-07-25 19:30:12 --> Output Class Initialized
INFO - 2018-07-25 19:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:12 --> CSRF cookie sent
INFO - 2018-07-25 19:30:12 --> Input Class Initialized
INFO - 2018-07-25 19:30:12 --> Language Class Initialized
INFO - 2018-07-25 19:30:12 --> Loader Class Initialized
INFO - 2018-07-25 19:30:12 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:12 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:12 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:12 --> Controller Class Initialized
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 19:30:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 19:30:12 --> Could not find the language line "req_email"
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 19:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:12 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:12 --> Total execution time: 0.0281
INFO - 2018-07-25 19:30:13 --> Config Class Initialized
INFO - 2018-07-25 19:30:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:30:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:30:13 --> Utf8 Class Initialized
INFO - 2018-07-25 19:30:13 --> URI Class Initialized
INFO - 2018-07-25 19:30:13 --> Router Class Initialized
INFO - 2018-07-25 19:30:13 --> Output Class Initialized
INFO - 2018-07-25 19:30:13 --> Security Class Initialized
DEBUG - 2018-07-25 19:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:30:13 --> CSRF cookie sent
INFO - 2018-07-25 19:30:13 --> Input Class Initialized
INFO - 2018-07-25 19:30:13 --> Language Class Initialized
INFO - 2018-07-25 19:30:13 --> Loader Class Initialized
INFO - 2018-07-25 19:30:13 --> Helper loaded: url_helper
INFO - 2018-07-25 19:30:13 --> Helper loaded: form_helper
INFO - 2018-07-25 19:30:13 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:30:13 --> User Agent Class Initialized
INFO - 2018-07-25 19:30:13 --> Controller Class Initialized
INFO - 2018-07-25 19:30:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:30:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:30:13 --> Pixel_Model class loaded
INFO - 2018-07-25 19:30:13 --> Database Driver Class Initialized
INFO - 2018-07-25 19:30:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-25 19:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:30:13 --> Final output sent to browser
DEBUG - 2018-07-25 19:30:13 --> Total execution time: 0.0543
INFO - 2018-07-25 19:31:34 --> Config Class Initialized
INFO - 2018-07-25 19:31:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:31:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:31:34 --> Utf8 Class Initialized
INFO - 2018-07-25 19:31:34 --> URI Class Initialized
DEBUG - 2018-07-25 19:31:34 --> No URI present. Default controller set.
INFO - 2018-07-25 19:31:34 --> Router Class Initialized
INFO - 2018-07-25 19:31:34 --> Output Class Initialized
INFO - 2018-07-25 19:31:34 --> Security Class Initialized
DEBUG - 2018-07-25 19:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:31:34 --> CSRF cookie sent
INFO - 2018-07-25 19:31:34 --> Input Class Initialized
INFO - 2018-07-25 19:31:34 --> Language Class Initialized
INFO - 2018-07-25 19:31:34 --> Loader Class Initialized
INFO - 2018-07-25 19:31:34 --> Helper loaded: url_helper
INFO - 2018-07-25 19:31:34 --> Helper loaded: form_helper
INFO - 2018-07-25 19:31:34 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:31:34 --> User Agent Class Initialized
INFO - 2018-07-25 19:31:34 --> Controller Class Initialized
INFO - 2018-07-25 19:31:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:31:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:31:34 --> Pixel_Model class loaded
INFO - 2018-07-25 19:31:34 --> Database Driver Class Initialized
INFO - 2018-07-25 19:31:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:31:34 --> Final output sent to browser
DEBUG - 2018-07-25 19:31:34 --> Total execution time: 0.0320
INFO - 2018-07-25 19:32:53 --> Config Class Initialized
INFO - 2018-07-25 19:32:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:32:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:32:53 --> Utf8 Class Initialized
INFO - 2018-07-25 19:32:53 --> URI Class Initialized
INFO - 2018-07-25 19:32:53 --> Router Class Initialized
INFO - 2018-07-25 19:32:53 --> Output Class Initialized
INFO - 2018-07-25 19:32:53 --> Security Class Initialized
DEBUG - 2018-07-25 19:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:32:53 --> CSRF cookie sent
INFO - 2018-07-25 19:32:53 --> Input Class Initialized
INFO - 2018-07-25 19:32:53 --> Language Class Initialized
INFO - 2018-07-25 19:32:53 --> Loader Class Initialized
INFO - 2018-07-25 19:32:53 --> Helper loaded: url_helper
INFO - 2018-07-25 19:32:53 --> Helper loaded: form_helper
INFO - 2018-07-25 19:32:53 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:32:53 --> User Agent Class Initialized
INFO - 2018-07-25 19:32:53 --> Controller Class Initialized
INFO - 2018-07-25 19:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-25 19:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:32:53 --> Final output sent to browser
DEBUG - 2018-07-25 19:32:53 --> Total execution time: 0.0241
INFO - 2018-07-25 19:37:45 --> Config Class Initialized
INFO - 2018-07-25 19:37:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 19:37:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 19:37:45 --> Utf8 Class Initialized
INFO - 2018-07-25 19:37:45 --> URI Class Initialized
DEBUG - 2018-07-25 19:37:45 --> No URI present. Default controller set.
INFO - 2018-07-25 19:37:45 --> Router Class Initialized
INFO - 2018-07-25 19:37:45 --> Output Class Initialized
INFO - 2018-07-25 19:37:45 --> Security Class Initialized
DEBUG - 2018-07-25 19:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 19:37:45 --> CSRF cookie sent
INFO - 2018-07-25 19:37:45 --> Input Class Initialized
INFO - 2018-07-25 19:37:45 --> Language Class Initialized
INFO - 2018-07-25 19:37:45 --> Loader Class Initialized
INFO - 2018-07-25 19:37:45 --> Helper loaded: url_helper
INFO - 2018-07-25 19:37:45 --> Helper loaded: form_helper
INFO - 2018-07-25 19:37:45 --> Helper loaded: language_helper
DEBUG - 2018-07-25 19:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 19:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 19:37:45 --> User Agent Class Initialized
INFO - 2018-07-25 19:37:45 --> Controller Class Initialized
INFO - 2018-07-25 19:37:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 19:37:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 19:37:45 --> Pixel_Model class loaded
INFO - 2018-07-25 19:37:45 --> Database Driver Class Initialized
INFO - 2018-07-25 19:37:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 19:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 19:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 19:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 19:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 19:37:45 --> Final output sent to browser
DEBUG - 2018-07-25 19:37:45 --> Total execution time: 0.0349
INFO - 2018-07-25 20:48:44 --> Config Class Initialized
INFO - 2018-07-25 20:48:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 20:48:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 20:48:44 --> Utf8 Class Initialized
INFO - 2018-07-25 20:48:44 --> URI Class Initialized
INFO - 2018-07-25 20:48:44 --> Router Class Initialized
INFO - 2018-07-25 20:48:44 --> Output Class Initialized
INFO - 2018-07-25 20:48:44 --> Security Class Initialized
DEBUG - 2018-07-25 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 20:48:44 --> CSRF cookie sent
INFO - 2018-07-25 20:48:44 --> Input Class Initialized
INFO - 2018-07-25 20:48:44 --> Language Class Initialized
ERROR - 2018-07-25 20:48:44 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-25 20:48:44 --> Config Class Initialized
INFO - 2018-07-25 20:48:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 20:48:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 20:48:44 --> Utf8 Class Initialized
INFO - 2018-07-25 20:48:44 --> URI Class Initialized
INFO - 2018-07-25 20:48:44 --> Router Class Initialized
INFO - 2018-07-25 20:48:44 --> Output Class Initialized
INFO - 2018-07-25 20:48:44 --> Security Class Initialized
DEBUG - 2018-07-25 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 20:48:44 --> CSRF cookie sent
INFO - 2018-07-25 20:48:44 --> Input Class Initialized
INFO - 2018-07-25 20:48:44 --> Language Class Initialized
INFO - 2018-07-25 20:48:44 --> Loader Class Initialized
INFO - 2018-07-25 20:48:44 --> Helper loaded: url_helper
INFO - 2018-07-25 20:48:44 --> Helper loaded: form_helper
INFO - 2018-07-25 20:48:44 --> Helper loaded: language_helper
DEBUG - 2018-07-25 20:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 20:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 20:48:44 --> User Agent Class Initialized
INFO - 2018-07-25 20:48:44 --> Controller Class Initialized
INFO - 2018-07-25 20:48:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 20:48:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 20:48:45 --> Config Class Initialized
INFO - 2018-07-25 20:48:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 20:48:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 20:48:45 --> Utf8 Class Initialized
INFO - 2018-07-25 20:48:45 --> URI Class Initialized
INFO - 2018-07-25 20:48:45 --> Router Class Initialized
INFO - 2018-07-25 20:48:45 --> Output Class Initialized
INFO - 2018-07-25 20:48:45 --> Security Class Initialized
DEBUG - 2018-07-25 20:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 20:48:45 --> CSRF cookie sent
INFO - 2018-07-25 20:48:45 --> Input Class Initialized
INFO - 2018-07-25 20:48:45 --> Language Class Initialized
INFO - 2018-07-25 20:48:45 --> Loader Class Initialized
INFO - 2018-07-25 20:48:45 --> Helper loaded: url_helper
INFO - 2018-07-25 20:48:45 --> Helper loaded: form_helper
INFO - 2018-07-25 20:48:45 --> Helper loaded: language_helper
DEBUG - 2018-07-25 20:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 20:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 20:48:45 --> User Agent Class Initialized
INFO - 2018-07-25 20:48:45 --> Controller Class Initialized
INFO - 2018-07-25 20:48:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 20:48:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-25 20:48:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-25 20:48:45 --> Could not find the language line "req_email"
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-25 20:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 20:48:45 --> Final output sent to browser
DEBUG - 2018-07-25 20:48:45 --> Total execution time: 0.0322
INFO - 2018-07-25 22:04:34 --> Config Class Initialized
INFO - 2018-07-25 22:04:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:34 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:34 --> URI Class Initialized
INFO - 2018-07-25 22:04:34 --> Router Class Initialized
INFO - 2018-07-25 22:04:34 --> Output Class Initialized
INFO - 2018-07-25 22:04:34 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:34 --> CSRF cookie sent
INFO - 2018-07-25 22:04:34 --> Input Class Initialized
INFO - 2018-07-25 22:04:34 --> Language Class Initialized
INFO - 2018-07-25 22:04:34 --> Loader Class Initialized
INFO - 2018-07-25 22:04:34 --> Helper loaded: url_helper
INFO - 2018-07-25 22:04:34 --> Helper loaded: form_helper
INFO - 2018-07-25 22:04:34 --> Helper loaded: language_helper
DEBUG - 2018-07-25 22:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:04:34 --> User Agent Class Initialized
INFO - 2018-07-25 22:04:34 --> Controller Class Initialized
INFO - 2018-07-25 22:04:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 22:04:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-25 22:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 22:04:34 --> Final output sent to browser
DEBUG - 2018-07-25 22:04:34 --> Total execution time: 0.0249
INFO - 2018-07-25 23:07:42 --> Config Class Initialized
INFO - 2018-07-25 23:07:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 23:07:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 23:07:42 --> Utf8 Class Initialized
INFO - 2018-07-25 23:07:42 --> URI Class Initialized
DEBUG - 2018-07-25 23:07:42 --> No URI present. Default controller set.
INFO - 2018-07-25 23:07:42 --> Router Class Initialized
INFO - 2018-07-25 23:07:42 --> Output Class Initialized
INFO - 2018-07-25 23:07:42 --> Security Class Initialized
DEBUG - 2018-07-25 23:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 23:07:42 --> CSRF cookie sent
INFO - 2018-07-25 23:07:42 --> Input Class Initialized
INFO - 2018-07-25 23:07:42 --> Language Class Initialized
INFO - 2018-07-25 23:07:42 --> Loader Class Initialized
INFO - 2018-07-25 23:07:42 --> Helper loaded: url_helper
INFO - 2018-07-25 23:07:42 --> Helper loaded: form_helper
INFO - 2018-07-25 23:07:42 --> Helper loaded: language_helper
DEBUG - 2018-07-25 23:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 23:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 23:07:42 --> User Agent Class Initialized
INFO - 2018-07-25 23:07:42 --> Controller Class Initialized
INFO - 2018-07-25 23:07:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-25 23:07:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-25 23:07:42 --> Pixel_Model class loaded
INFO - 2018-07-25 23:07:42 --> Database Driver Class Initialized
INFO - 2018-07-25 23:07:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-25 23:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-25 23:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-25 23:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-25 23:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-25 23:07:42 --> Final output sent to browser
DEBUG - 2018-07-25 23:07:42 --> Total execution time: 0.0400

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-27 00:33:43 --> Config Class Initialized
INFO - 2018-07-27 00:33:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 00:33:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:33:43 --> Utf8 Class Initialized
INFO - 2018-07-27 00:33:43 --> URI Class Initialized
DEBUG - 2018-07-27 00:33:43 --> No URI present. Default controller set.
INFO - 2018-07-27 00:33:43 --> Router Class Initialized
INFO - 2018-07-27 00:33:43 --> Output Class Initialized
INFO - 2018-07-27 00:33:43 --> Security Class Initialized
DEBUG - 2018-07-27 00:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:33:43 --> CSRF cookie sent
INFO - 2018-07-27 00:33:43 --> Input Class Initialized
INFO - 2018-07-27 00:33:43 --> Language Class Initialized
INFO - 2018-07-27 00:33:43 --> Loader Class Initialized
INFO - 2018-07-27 00:33:43 --> Helper loaded: url_helper
INFO - 2018-07-27 00:33:43 --> Helper loaded: form_helper
INFO - 2018-07-27 00:33:43 --> Helper loaded: language_helper
DEBUG - 2018-07-27 00:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 00:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 00:33:43 --> User Agent Class Initialized
INFO - 2018-07-27 00:33:43 --> Controller Class Initialized
INFO - 2018-07-27 00:33:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 00:33:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 00:33:43 --> Pixel_Model class loaded
INFO - 2018-07-27 00:33:43 --> Database Driver Class Initialized
INFO - 2018-07-27 00:33:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 00:33:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 00:33:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 00:33:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 00:33:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 00:33:43 --> Final output sent to browser
DEBUG - 2018-07-27 00:33:43 --> Total execution time: 0.0382
INFO - 2018-07-27 01:50:06 --> Config Class Initialized
INFO - 2018-07-27 01:50:06 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:50:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:50:06 --> Utf8 Class Initialized
INFO - 2018-07-27 01:50:06 --> URI Class Initialized
DEBUG - 2018-07-27 01:50:06 --> No URI present. Default controller set.
INFO - 2018-07-27 01:50:06 --> Router Class Initialized
INFO - 2018-07-27 01:50:06 --> Output Class Initialized
INFO - 2018-07-27 01:50:07 --> Security Class Initialized
DEBUG - 2018-07-27 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:50:07 --> CSRF cookie sent
INFO - 2018-07-27 01:50:07 --> Input Class Initialized
INFO - 2018-07-27 01:50:07 --> Language Class Initialized
INFO - 2018-07-27 01:50:07 --> Loader Class Initialized
INFO - 2018-07-27 01:50:07 --> Helper loaded: url_helper
INFO - 2018-07-27 01:50:07 --> Helper loaded: form_helper
INFO - 2018-07-27 01:50:07 --> Helper loaded: language_helper
DEBUG - 2018-07-27 01:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:50:07 --> User Agent Class Initialized
INFO - 2018-07-27 01:50:07 --> Controller Class Initialized
INFO - 2018-07-27 01:50:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 01:50:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 01:50:07 --> Pixel_Model class loaded
INFO - 2018-07-27 01:50:07 --> Database Driver Class Initialized
INFO - 2018-07-27 01:50:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 01:50:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 01:50:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 01:50:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 01:50:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 01:50:07 --> Final output sent to browser
DEBUG - 2018-07-27 01:50:07 --> Total execution time: 0.0371
INFO - 2018-07-27 09:17:56 --> Config Class Initialized
INFO - 2018-07-27 09:17:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 09:17:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 09:17:56 --> Utf8 Class Initialized
INFO - 2018-07-27 09:17:56 --> URI Class Initialized
DEBUG - 2018-07-27 09:17:56 --> No URI present. Default controller set.
INFO - 2018-07-27 09:17:56 --> Router Class Initialized
INFO - 2018-07-27 09:17:56 --> Output Class Initialized
INFO - 2018-07-27 09:17:56 --> Security Class Initialized
DEBUG - 2018-07-27 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 09:17:56 --> CSRF cookie sent
INFO - 2018-07-27 09:17:56 --> Input Class Initialized
INFO - 2018-07-27 09:17:56 --> Language Class Initialized
INFO - 2018-07-27 09:17:56 --> Loader Class Initialized
INFO - 2018-07-27 09:17:56 --> Helper loaded: url_helper
INFO - 2018-07-27 09:17:56 --> Helper loaded: form_helper
INFO - 2018-07-27 09:17:56 --> Helper loaded: language_helper
DEBUG - 2018-07-27 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 09:17:56 --> User Agent Class Initialized
INFO - 2018-07-27 09:17:56 --> Controller Class Initialized
INFO - 2018-07-27 09:17:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 09:17:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 09:17:56 --> Pixel_Model class loaded
INFO - 2018-07-27 09:17:56 --> Database Driver Class Initialized
INFO - 2018-07-27 09:17:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 09:17:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 09:17:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 09:17:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 09:17:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 09:17:56 --> Final output sent to browser
DEBUG - 2018-07-27 09:17:56 --> Total execution time: 0.0330
INFO - 2018-07-27 09:50:47 --> Config Class Initialized
INFO - 2018-07-27 09:50:47 --> Hooks Class Initialized
DEBUG - 2018-07-27 09:50:47 --> UTF-8 Support Enabled
INFO - 2018-07-27 09:50:47 --> Utf8 Class Initialized
INFO - 2018-07-27 09:50:47 --> URI Class Initialized
DEBUG - 2018-07-27 09:50:47 --> No URI present. Default controller set.
INFO - 2018-07-27 09:50:47 --> Router Class Initialized
INFO - 2018-07-27 09:50:47 --> Output Class Initialized
INFO - 2018-07-27 09:50:47 --> Security Class Initialized
DEBUG - 2018-07-27 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 09:50:47 --> CSRF cookie sent
INFO - 2018-07-27 09:50:47 --> Input Class Initialized
INFO - 2018-07-27 09:50:47 --> Language Class Initialized
INFO - 2018-07-27 09:50:47 --> Loader Class Initialized
INFO - 2018-07-27 09:50:47 --> Helper loaded: url_helper
INFO - 2018-07-27 09:50:47 --> Helper loaded: form_helper
INFO - 2018-07-27 09:50:47 --> Helper loaded: language_helper
DEBUG - 2018-07-27 09:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 09:50:47 --> User Agent Class Initialized
INFO - 2018-07-27 09:50:47 --> Controller Class Initialized
INFO - 2018-07-27 09:50:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 09:50:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 09:50:47 --> Pixel_Model class loaded
INFO - 2018-07-27 09:50:47 --> Database Driver Class Initialized
INFO - 2018-07-27 09:50:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 09:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 09:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 09:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 09:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 09:50:47 --> Final output sent to browser
DEBUG - 2018-07-27 09:50:47 --> Total execution time: 0.0319
INFO - 2018-07-27 13:14:53 --> Config Class Initialized
INFO - 2018-07-27 13:14:53 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:14:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:14:53 --> Utf8 Class Initialized
INFO - 2018-07-27 13:14:53 --> URI Class Initialized
DEBUG - 2018-07-27 13:14:53 --> No URI present. Default controller set.
INFO - 2018-07-27 13:14:53 --> Router Class Initialized
INFO - 2018-07-27 13:14:53 --> Output Class Initialized
INFO - 2018-07-27 13:14:53 --> Security Class Initialized
DEBUG - 2018-07-27 13:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:14:53 --> CSRF cookie sent
INFO - 2018-07-27 13:14:53 --> Input Class Initialized
INFO - 2018-07-27 13:14:53 --> Language Class Initialized
INFO - 2018-07-27 13:14:53 --> Loader Class Initialized
INFO - 2018-07-27 13:14:53 --> Helper loaded: url_helper
INFO - 2018-07-27 13:14:53 --> Helper loaded: form_helper
INFO - 2018-07-27 13:14:53 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:14:53 --> User Agent Class Initialized
INFO - 2018-07-27 13:14:53 --> Controller Class Initialized
INFO - 2018-07-27 13:14:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:14:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:14:53 --> Pixel_Model class loaded
INFO - 2018-07-27 13:14:53 --> Database Driver Class Initialized
INFO - 2018-07-27 13:14:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 13:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:14:53 --> Final output sent to browser
DEBUG - 2018-07-27 13:14:53 --> Total execution time: 0.0359
INFO - 2018-07-27 13:15:11 --> Config Class Initialized
INFO - 2018-07-27 13:15:11 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:15:11 --> Utf8 Class Initialized
INFO - 2018-07-27 13:15:11 --> URI Class Initialized
INFO - 2018-07-27 13:15:11 --> Router Class Initialized
INFO - 2018-07-27 13:15:11 --> Output Class Initialized
INFO - 2018-07-27 13:15:11 --> Security Class Initialized
DEBUG - 2018-07-27 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:15:11 --> CSRF cookie sent
INFO - 2018-07-27 13:15:11 --> CSRF token verified
INFO - 2018-07-27 13:15:11 --> Input Class Initialized
INFO - 2018-07-27 13:15:11 --> Language Class Initialized
INFO - 2018-07-27 13:15:11 --> Loader Class Initialized
INFO - 2018-07-27 13:15:11 --> Helper loaded: url_helper
INFO - 2018-07-27 13:15:11 --> Helper loaded: form_helper
INFO - 2018-07-27 13:15:11 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:15:11 --> User Agent Class Initialized
INFO - 2018-07-27 13:15:11 --> Controller Class Initialized
INFO - 2018-07-27 13:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:15:11 --> Pixel_Model class loaded
INFO - 2018-07-27 13:15:11 --> Database Driver Class Initialized
INFO - 2018-07-27 13:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:15:11 --> Config Class Initialized
INFO - 2018-07-27 13:15:11 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:15:11 --> Utf8 Class Initialized
INFO - 2018-07-27 13:15:11 --> URI Class Initialized
INFO - 2018-07-27 13:15:11 --> Router Class Initialized
INFO - 2018-07-27 13:15:11 --> Output Class Initialized
INFO - 2018-07-27 13:15:11 --> Security Class Initialized
DEBUG - 2018-07-27 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:15:11 --> CSRF cookie sent
INFO - 2018-07-27 13:15:11 --> Input Class Initialized
INFO - 2018-07-27 13:15:11 --> Language Class Initialized
INFO - 2018-07-27 13:15:11 --> Loader Class Initialized
INFO - 2018-07-27 13:15:11 --> Helper loaded: url_helper
INFO - 2018-07-27 13:15:11 --> Helper loaded: form_helper
INFO - 2018-07-27 13:15:11 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:15:11 --> User Agent Class Initialized
INFO - 2018-07-27 13:15:11 --> Controller Class Initialized
INFO - 2018-07-27 13:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:15:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 13:15:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 13:15:11 --> Could not find the language line "req_email"
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 13:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:15:11 --> Final output sent to browser
DEBUG - 2018-07-27 13:15:11 --> Total execution time: 0.0212
INFO - 2018-07-27 13:15:14 --> Config Class Initialized
INFO - 2018-07-27 13:15:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:15:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:15:14 --> Utf8 Class Initialized
INFO - 2018-07-27 13:15:14 --> URI Class Initialized
DEBUG - 2018-07-27 13:15:14 --> No URI present. Default controller set.
INFO - 2018-07-27 13:15:14 --> Router Class Initialized
INFO - 2018-07-27 13:15:14 --> Output Class Initialized
INFO - 2018-07-27 13:15:14 --> Security Class Initialized
DEBUG - 2018-07-27 13:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:15:14 --> CSRF cookie sent
INFO - 2018-07-27 13:15:14 --> Input Class Initialized
INFO - 2018-07-27 13:15:14 --> Language Class Initialized
INFO - 2018-07-27 13:15:14 --> Loader Class Initialized
INFO - 2018-07-27 13:15:14 --> Helper loaded: url_helper
INFO - 2018-07-27 13:15:14 --> Helper loaded: form_helper
INFO - 2018-07-27 13:15:14 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:15:14 --> User Agent Class Initialized
INFO - 2018-07-27 13:15:14 --> Controller Class Initialized
INFO - 2018-07-27 13:15:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:15:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:15:14 --> Pixel_Model class loaded
INFO - 2018-07-27 13:15:14 --> Database Driver Class Initialized
INFO - 2018-07-27 13:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 13:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:15:14 --> Final output sent to browser
DEBUG - 2018-07-27 13:15:14 --> Total execution time: 0.0325
INFO - 2018-07-27 13:18:20 --> Config Class Initialized
INFO - 2018-07-27 13:18:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:18:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:18:20 --> Utf8 Class Initialized
INFO - 2018-07-27 13:18:20 --> URI Class Initialized
INFO - 2018-07-27 13:18:20 --> Router Class Initialized
INFO - 2018-07-27 13:18:20 --> Output Class Initialized
INFO - 2018-07-27 13:18:20 --> Security Class Initialized
DEBUG - 2018-07-27 13:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:18:20 --> CSRF cookie sent
INFO - 2018-07-27 13:18:20 --> Input Class Initialized
INFO - 2018-07-27 13:18:20 --> Language Class Initialized
INFO - 2018-07-27 13:18:20 --> Loader Class Initialized
INFO - 2018-07-27 13:18:20 --> Helper loaded: url_helper
INFO - 2018-07-27 13:18:20 --> Helper loaded: form_helper
INFO - 2018-07-27 13:18:20 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:18:20 --> User Agent Class Initialized
INFO - 2018-07-27 13:18:20 --> Controller Class Initialized
INFO - 2018-07-27 13:18:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:18:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:18:20 --> Pixel_Model class loaded
INFO - 2018-07-27 13:18:20 --> Database Driver Class Initialized
INFO - 2018-07-27 13:18:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:18:20 --> Config Class Initialized
INFO - 2018-07-27 13:18:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:18:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:18:20 --> Utf8 Class Initialized
INFO - 2018-07-27 13:18:20 --> URI Class Initialized
INFO - 2018-07-27 13:18:20 --> Router Class Initialized
INFO - 2018-07-27 13:18:20 --> Output Class Initialized
INFO - 2018-07-27 13:18:20 --> Security Class Initialized
DEBUG - 2018-07-27 13:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:18:20 --> CSRF cookie sent
INFO - 2018-07-27 13:18:20 --> Input Class Initialized
INFO - 2018-07-27 13:18:20 --> Language Class Initialized
INFO - 2018-07-27 13:18:20 --> Loader Class Initialized
INFO - 2018-07-27 13:18:20 --> Helper loaded: url_helper
INFO - 2018-07-27 13:18:20 --> Helper loaded: form_helper
INFO - 2018-07-27 13:18:20 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:18:20 --> User Agent Class Initialized
INFO - 2018-07-27 13:18:20 --> Controller Class Initialized
INFO - 2018-07-27 13:18:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:18:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 13:18:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 13:18:20 --> Could not find the language line "req_email"
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 13:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:18:20 --> Final output sent to browser
DEBUG - 2018-07-27 13:18:20 --> Total execution time: 0.0254
INFO - 2018-07-27 13:18:26 --> Config Class Initialized
INFO - 2018-07-27 13:18:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:18:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:18:26 --> Utf8 Class Initialized
INFO - 2018-07-27 13:18:26 --> URI Class Initialized
INFO - 2018-07-27 13:18:26 --> Router Class Initialized
INFO - 2018-07-27 13:18:26 --> Output Class Initialized
INFO - 2018-07-27 13:18:26 --> Security Class Initialized
DEBUG - 2018-07-27 13:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:18:26 --> CSRF cookie sent
INFO - 2018-07-27 13:18:26 --> Input Class Initialized
INFO - 2018-07-27 13:18:26 --> Language Class Initialized
INFO - 2018-07-27 13:18:26 --> Loader Class Initialized
INFO - 2018-07-27 13:18:26 --> Helper loaded: url_helper
INFO - 2018-07-27 13:18:26 --> Helper loaded: form_helper
INFO - 2018-07-27 13:18:26 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:18:26 --> User Agent Class Initialized
INFO - 2018-07-27 13:18:26 --> Controller Class Initialized
INFO - 2018-07-27 13:18:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:18:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-27 13:18:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:18:26 --> Final output sent to browser
DEBUG - 2018-07-27 13:18:26 --> Total execution time: 0.0202
INFO - 2018-07-27 13:18:47 --> Config Class Initialized
INFO - 2018-07-27 13:18:47 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:18:47 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:18:47 --> Utf8 Class Initialized
INFO - 2018-07-27 13:18:47 --> URI Class Initialized
INFO - 2018-07-27 13:18:47 --> Router Class Initialized
INFO - 2018-07-27 13:18:47 --> Output Class Initialized
INFO - 2018-07-27 13:18:47 --> Security Class Initialized
DEBUG - 2018-07-27 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:18:47 --> CSRF cookie sent
INFO - 2018-07-27 13:18:47 --> Input Class Initialized
INFO - 2018-07-27 13:18:47 --> Language Class Initialized
INFO - 2018-07-27 13:18:47 --> Loader Class Initialized
INFO - 2018-07-27 13:18:47 --> Helper loaded: url_helper
INFO - 2018-07-27 13:18:47 --> Helper loaded: form_helper
INFO - 2018-07-27 13:18:47 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:18:47 --> User Agent Class Initialized
INFO - 2018-07-27 13:18:47 --> Controller Class Initialized
INFO - 2018-07-27 13:18:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:18:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-27 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:18:47 --> Final output sent to browser
DEBUG - 2018-07-27 13:18:47 --> Total execution time: 0.0214
INFO - 2018-07-27 13:18:53 --> Config Class Initialized
INFO - 2018-07-27 13:18:53 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:18:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:18:53 --> Utf8 Class Initialized
INFO - 2018-07-27 13:18:53 --> URI Class Initialized
INFO - 2018-07-27 13:18:53 --> Router Class Initialized
INFO - 2018-07-27 13:18:53 --> Output Class Initialized
INFO - 2018-07-27 13:18:53 --> Security Class Initialized
DEBUG - 2018-07-27 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:18:53 --> CSRF cookie sent
INFO - 2018-07-27 13:18:53 --> Input Class Initialized
INFO - 2018-07-27 13:18:53 --> Language Class Initialized
INFO - 2018-07-27 13:18:53 --> Loader Class Initialized
INFO - 2018-07-27 13:18:53 --> Helper loaded: url_helper
INFO - 2018-07-27 13:18:53 --> Helper loaded: form_helper
INFO - 2018-07-27 13:18:53 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:18:53 --> User Agent Class Initialized
INFO - 2018-07-27 13:18:53 --> Controller Class Initialized
INFO - 2018-07-27 13:18:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:18:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-27 13:18:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:18:53 --> Final output sent to browser
DEBUG - 2018-07-27 13:18:53 --> Total execution time: 0.0212
INFO - 2018-07-27 13:19:00 --> Config Class Initialized
INFO - 2018-07-27 13:19:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:19:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:19:00 --> Utf8 Class Initialized
INFO - 2018-07-27 13:19:00 --> URI Class Initialized
INFO - 2018-07-27 13:19:00 --> Router Class Initialized
INFO - 2018-07-27 13:19:00 --> Output Class Initialized
INFO - 2018-07-27 13:19:00 --> Security Class Initialized
DEBUG - 2018-07-27 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:19:00 --> CSRF cookie sent
INFO - 2018-07-27 13:19:00 --> Input Class Initialized
INFO - 2018-07-27 13:19:00 --> Language Class Initialized
INFO - 2018-07-27 13:19:00 --> Loader Class Initialized
INFO - 2018-07-27 13:19:00 --> Helper loaded: url_helper
INFO - 2018-07-27 13:19:00 --> Helper loaded: form_helper
INFO - 2018-07-27 13:19:00 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:19:00 --> User Agent Class Initialized
INFO - 2018-07-27 13:19:00 --> Controller Class Initialized
INFO - 2018-07-27 13:19:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:19:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-27 13:19:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:19:00 --> Final output sent to browser
DEBUG - 2018-07-27 13:19:00 --> Total execution time: 0.0206
INFO - 2018-07-27 13:19:05 --> Config Class Initialized
INFO - 2018-07-27 13:19:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:19:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:19:05 --> Utf8 Class Initialized
INFO - 2018-07-27 13:19:05 --> URI Class Initialized
DEBUG - 2018-07-27 13:19:05 --> No URI present. Default controller set.
INFO - 2018-07-27 13:19:05 --> Router Class Initialized
INFO - 2018-07-27 13:19:05 --> Output Class Initialized
INFO - 2018-07-27 13:19:05 --> Security Class Initialized
DEBUG - 2018-07-27 13:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:19:05 --> CSRF cookie sent
INFO - 2018-07-27 13:19:05 --> Input Class Initialized
INFO - 2018-07-27 13:19:05 --> Language Class Initialized
INFO - 2018-07-27 13:19:05 --> Loader Class Initialized
INFO - 2018-07-27 13:19:05 --> Helper loaded: url_helper
INFO - 2018-07-27 13:19:05 --> Helper loaded: form_helper
INFO - 2018-07-27 13:19:05 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:19:05 --> User Agent Class Initialized
INFO - 2018-07-27 13:19:05 --> Controller Class Initialized
INFO - 2018-07-27 13:19:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:19:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:19:05 --> Pixel_Model class loaded
INFO - 2018-07-27 13:19:05 --> Database Driver Class Initialized
INFO - 2018-07-27 13:19:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:19:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:19:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:19:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 13:19:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:19:05 --> Final output sent to browser
DEBUG - 2018-07-27 13:19:05 --> Total execution time: 0.0323
INFO - 2018-07-27 13:29:58 --> Config Class Initialized
INFO - 2018-07-27 13:29:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:29:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:29:58 --> Utf8 Class Initialized
INFO - 2018-07-27 13:29:58 --> URI Class Initialized
DEBUG - 2018-07-27 13:29:58 --> No URI present. Default controller set.
INFO - 2018-07-27 13:29:58 --> Router Class Initialized
INFO - 2018-07-27 13:29:58 --> Output Class Initialized
INFO - 2018-07-27 13:29:58 --> Security Class Initialized
DEBUG - 2018-07-27 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:29:58 --> CSRF cookie sent
INFO - 2018-07-27 13:29:58 --> Input Class Initialized
INFO - 2018-07-27 13:29:58 --> Language Class Initialized
INFO - 2018-07-27 13:29:58 --> Loader Class Initialized
INFO - 2018-07-27 13:29:58 --> Helper loaded: url_helper
INFO - 2018-07-27 13:29:58 --> Helper loaded: form_helper
INFO - 2018-07-27 13:29:58 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:29:58 --> User Agent Class Initialized
INFO - 2018-07-27 13:29:58 --> Controller Class Initialized
INFO - 2018-07-27 13:29:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:29:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:29:58 --> Pixel_Model class loaded
INFO - 2018-07-27 13:29:58 --> Database Driver Class Initialized
INFO - 2018-07-27 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:29:58 --> Final output sent to browser
DEBUG - 2018-07-27 13:29:58 --> Total execution time: 0.0361
INFO - 2018-07-27 13:29:58 --> Config Class Initialized
INFO - 2018-07-27 13:29:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:29:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:29:58 --> Utf8 Class Initialized
INFO - 2018-07-27 13:29:58 --> URI Class Initialized
DEBUG - 2018-07-27 13:29:58 --> No URI present. Default controller set.
INFO - 2018-07-27 13:29:58 --> Router Class Initialized
INFO - 2018-07-27 13:29:58 --> Output Class Initialized
INFO - 2018-07-27 13:29:58 --> Security Class Initialized
DEBUG - 2018-07-27 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:29:58 --> CSRF cookie sent
INFO - 2018-07-27 13:29:58 --> Input Class Initialized
INFO - 2018-07-27 13:29:58 --> Language Class Initialized
INFO - 2018-07-27 13:29:58 --> Loader Class Initialized
INFO - 2018-07-27 13:29:58 --> Helper loaded: url_helper
INFO - 2018-07-27 13:29:58 --> Helper loaded: form_helper
INFO - 2018-07-27 13:29:58 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:29:58 --> User Agent Class Initialized
INFO - 2018-07-27 13:29:58 --> Controller Class Initialized
INFO - 2018-07-27 13:29:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:29:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:29:58 --> Pixel_Model class loaded
INFO - 2018-07-27 13:29:58 --> Database Driver Class Initialized
INFO - 2018-07-27 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:29:58 --> Final output sent to browser
DEBUG - 2018-07-27 13:29:58 --> Total execution time: 0.0311
INFO - 2018-07-27 13:30:04 --> Config Class Initialized
INFO - 2018-07-27 13:30:04 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:30:04 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:30:04 --> Utf8 Class Initialized
INFO - 2018-07-27 13:30:04 --> URI Class Initialized
INFO - 2018-07-27 13:30:04 --> Router Class Initialized
INFO - 2018-07-27 13:30:04 --> Output Class Initialized
INFO - 2018-07-27 13:30:04 --> Security Class Initialized
DEBUG - 2018-07-27 13:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:30:04 --> CSRF cookie sent
INFO - 2018-07-27 13:30:04 --> Input Class Initialized
INFO - 2018-07-27 13:30:04 --> Language Class Initialized
INFO - 2018-07-27 13:30:04 --> Loader Class Initialized
INFO - 2018-07-27 13:30:04 --> Helper loaded: url_helper
INFO - 2018-07-27 13:30:04 --> Helper loaded: form_helper
INFO - 2018-07-27 13:30:04 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:30:04 --> User Agent Class Initialized
INFO - 2018-07-27 13:30:04 --> Controller Class Initialized
INFO - 2018-07-27 13:30:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:30:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-27 13:30:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:30:04 --> Final output sent to browser
DEBUG - 2018-07-27 13:30:04 --> Total execution time: 0.0217
INFO - 2018-07-27 13:30:07 --> Config Class Initialized
INFO - 2018-07-27 13:30:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:30:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:30:07 --> Utf8 Class Initialized
INFO - 2018-07-27 13:30:07 --> URI Class Initialized
INFO - 2018-07-27 13:30:07 --> Router Class Initialized
INFO - 2018-07-27 13:30:07 --> Output Class Initialized
INFO - 2018-07-27 13:30:07 --> Security Class Initialized
DEBUG - 2018-07-27 13:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:30:07 --> CSRF cookie sent
INFO - 2018-07-27 13:30:07 --> Input Class Initialized
INFO - 2018-07-27 13:30:07 --> Language Class Initialized
ERROR - 2018-07-27 13:30:07 --> 404 Page Not Found: Faviconico/index
INFO - 2018-07-27 13:30:10 --> Config Class Initialized
INFO - 2018-07-27 13:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:30:10 --> Utf8 Class Initialized
INFO - 2018-07-27 13:30:10 --> URI Class Initialized
INFO - 2018-07-27 13:30:10 --> Router Class Initialized
INFO - 2018-07-27 13:30:10 --> Output Class Initialized
INFO - 2018-07-27 13:30:10 --> Security Class Initialized
DEBUG - 2018-07-27 13:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:30:10 --> CSRF cookie sent
INFO - 2018-07-27 13:30:10 --> Input Class Initialized
INFO - 2018-07-27 13:30:10 --> Language Class Initialized
INFO - 2018-07-27 13:30:10 --> Loader Class Initialized
INFO - 2018-07-27 13:30:10 --> Helper loaded: url_helper
INFO - 2018-07-27 13:30:10 --> Helper loaded: form_helper
INFO - 2018-07-27 13:30:10 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:30:10 --> User Agent Class Initialized
INFO - 2018-07-27 13:30:10 --> Controller Class Initialized
INFO - 2018-07-27 13:30:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:30:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-27 13:30:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:30:10 --> Final output sent to browser
DEBUG - 2018-07-27 13:30:10 --> Total execution time: 0.0228
INFO - 2018-07-27 13:30:12 --> Config Class Initialized
INFO - 2018-07-27 13:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-27 13:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-27 13:30:12 --> Utf8 Class Initialized
INFO - 2018-07-27 13:30:12 --> URI Class Initialized
INFO - 2018-07-27 13:30:12 --> Router Class Initialized
INFO - 2018-07-27 13:30:12 --> Output Class Initialized
INFO - 2018-07-27 13:30:12 --> Security Class Initialized
DEBUG - 2018-07-27 13:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 13:30:12 --> CSRF cookie sent
INFO - 2018-07-27 13:30:12 --> Input Class Initialized
INFO - 2018-07-27 13:30:12 --> Language Class Initialized
INFO - 2018-07-27 13:30:12 --> Loader Class Initialized
INFO - 2018-07-27 13:30:12 --> Helper loaded: url_helper
INFO - 2018-07-27 13:30:12 --> Helper loaded: form_helper
INFO - 2018-07-27 13:30:12 --> Helper loaded: language_helper
DEBUG - 2018-07-27 13:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 13:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 13:30:12 --> User Agent Class Initialized
INFO - 2018-07-27 13:30:12 --> Controller Class Initialized
INFO - 2018-07-27 13:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 13:30:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-27 13:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 13:30:12 --> Final output sent to browser
DEBUG - 2018-07-27 13:30:12 --> Total execution time: 0.0276
INFO - 2018-07-27 15:16:00 --> Config Class Initialized
INFO - 2018-07-27 15:16:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 15:16:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 15:16:00 --> Utf8 Class Initialized
INFO - 2018-07-27 15:16:00 --> URI Class Initialized
INFO - 2018-07-27 15:16:00 --> Router Class Initialized
INFO - 2018-07-27 15:16:00 --> Output Class Initialized
INFO - 2018-07-27 15:16:00 --> Security Class Initialized
DEBUG - 2018-07-27 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 15:16:00 --> CSRF cookie sent
INFO - 2018-07-27 15:16:00 --> Input Class Initialized
INFO - 2018-07-27 15:16:00 --> Language Class Initialized
ERROR - 2018-07-27 15:16:00 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-27 15:16:03 --> Config Class Initialized
INFO - 2018-07-27 15:16:03 --> Hooks Class Initialized
DEBUG - 2018-07-27 15:16:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 15:16:03 --> Utf8 Class Initialized
INFO - 2018-07-27 15:16:03 --> URI Class Initialized
INFO - 2018-07-27 15:16:03 --> Router Class Initialized
INFO - 2018-07-27 15:16:03 --> Output Class Initialized
INFO - 2018-07-27 15:16:03 --> Security Class Initialized
DEBUG - 2018-07-27 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 15:16:03 --> CSRF cookie sent
INFO - 2018-07-27 15:16:03 --> Input Class Initialized
INFO - 2018-07-27 15:16:03 --> Language Class Initialized
INFO - 2018-07-27 15:16:03 --> Loader Class Initialized
INFO - 2018-07-27 15:16:03 --> Helper loaded: url_helper
INFO - 2018-07-27 15:16:03 --> Helper loaded: form_helper
INFO - 2018-07-27 15:16:03 --> Helper loaded: language_helper
DEBUG - 2018-07-27 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 15:16:03 --> User Agent Class Initialized
INFO - 2018-07-27 15:16:03 --> Controller Class Initialized
INFO - 2018-07-27 15:16:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 15:16:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-27 15:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 15:16:03 --> Final output sent to browser
DEBUG - 2018-07-27 15:16:03 --> Total execution time: 0.0320
INFO - 2018-07-27 16:19:34 --> Config Class Initialized
INFO - 2018-07-27 16:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:34 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:34 --> URI Class Initialized
DEBUG - 2018-07-27 16:19:34 --> No URI present. Default controller set.
INFO - 2018-07-27 16:19:34 --> Router Class Initialized
INFO - 2018-07-27 16:19:34 --> Output Class Initialized
INFO - 2018-07-27 16:19:34 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:34 --> CSRF cookie sent
INFO - 2018-07-27 16:19:34 --> Input Class Initialized
INFO - 2018-07-27 16:19:34 --> Language Class Initialized
INFO - 2018-07-27 16:19:34 --> Loader Class Initialized
INFO - 2018-07-27 16:19:34 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:34 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:34 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:34 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:34 --> Controller Class Initialized
INFO - 2018-07-27 16:19:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:34 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:34 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 16:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:34 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:34 --> Total execution time: 0.0338
INFO - 2018-07-27 16:19:35 --> Config Class Initialized
INFO - 2018-07-27 16:19:35 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:35 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:35 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:35 --> URI Class Initialized
INFO - 2018-07-27 16:19:35 --> Router Class Initialized
INFO - 2018-07-27 16:19:35 --> Output Class Initialized
INFO - 2018-07-27 16:19:35 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:35 --> CSRF cookie sent
INFO - 2018-07-27 16:19:35 --> Input Class Initialized
INFO - 2018-07-27 16:19:35 --> Language Class Initialized
ERROR - 2018-07-27 16:19:35 --> 404 Page Not Found: Assets/css
INFO - 2018-07-27 16:19:39 --> Config Class Initialized
INFO - 2018-07-27 16:19:39 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:39 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:39 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:39 --> URI Class Initialized
INFO - 2018-07-27 16:19:39 --> Router Class Initialized
INFO - 2018-07-27 16:19:39 --> Output Class Initialized
INFO - 2018-07-27 16:19:39 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:39 --> CSRF cookie sent
INFO - 2018-07-27 16:19:39 --> Input Class Initialized
INFO - 2018-07-27 16:19:39 --> Language Class Initialized
INFO - 2018-07-27 16:19:39 --> Loader Class Initialized
INFO - 2018-07-27 16:19:39 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:39 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:39 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:39 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:39 --> Controller Class Initialized
INFO - 2018-07-27 16:19:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 16:19:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 16:19:39 --> Could not find the language line "req_email"
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 16:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:39 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:39 --> Total execution time: 0.0231
INFO - 2018-07-27 16:19:44 --> Config Class Initialized
INFO - 2018-07-27 16:19:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:44 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:44 --> URI Class Initialized
INFO - 2018-07-27 16:19:44 --> Router Class Initialized
INFO - 2018-07-27 16:19:44 --> Output Class Initialized
INFO - 2018-07-27 16:19:44 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:44 --> CSRF cookie sent
INFO - 2018-07-27 16:19:44 --> CSRF token verified
INFO - 2018-07-27 16:19:44 --> Input Class Initialized
INFO - 2018-07-27 16:19:44 --> Language Class Initialized
INFO - 2018-07-27 16:19:44 --> Loader Class Initialized
INFO - 2018-07-27 16:19:44 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:44 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:44 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:44 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:44 --> Controller Class Initialized
INFO - 2018-07-27 16:19:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 16:19:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 16:19:44 --> Form Validation Class Initialized
INFO - 2018-07-27 16:19:44 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:44 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:44 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 16:19:44 --> Config Class Initialized
INFO - 2018-07-27 16:19:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:44 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:44 --> URI Class Initialized
INFO - 2018-07-27 16:19:44 --> Router Class Initialized
INFO - 2018-07-27 16:19:44 --> Output Class Initialized
INFO - 2018-07-27 16:19:44 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:44 --> CSRF cookie sent
INFO - 2018-07-27 16:19:44 --> Input Class Initialized
INFO - 2018-07-27 16:19:44 --> Language Class Initialized
INFO - 2018-07-27 16:19:44 --> Loader Class Initialized
INFO - 2018-07-27 16:19:44 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:44 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:44 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:44 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:44 --> Controller Class Initialized
INFO - 2018-07-27 16:19:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:44 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:44 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:44 --> Model "MyAccountModel" initialized
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-07-27 16:19:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:44 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:44 --> Total execution time: 0.0390
INFO - 2018-07-27 16:19:46 --> Config Class Initialized
INFO - 2018-07-27 16:19:46 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:46 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:46 --> URI Class Initialized
INFO - 2018-07-27 16:19:46 --> Router Class Initialized
INFO - 2018-07-27 16:19:46 --> Output Class Initialized
INFO - 2018-07-27 16:19:46 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:46 --> CSRF cookie sent
INFO - 2018-07-27 16:19:46 --> Input Class Initialized
INFO - 2018-07-27 16:19:46 --> Language Class Initialized
INFO - 2018-07-27 16:19:46 --> Loader Class Initialized
INFO - 2018-07-27 16:19:46 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:46 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:46 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:46 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:46 --> Controller Class Initialized
INFO - 2018-07-27 16:19:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:46 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:46 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:46 --> Model "MyAccountModel" initialized
INFO - 2018-07-27 16:19:46 --> Config Class Initialized
INFO - 2018-07-27 16:19:46 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:46 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:46 --> URI Class Initialized
INFO - 2018-07-27 16:19:46 --> Router Class Initialized
INFO - 2018-07-27 16:19:46 --> Output Class Initialized
INFO - 2018-07-27 16:19:46 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:46 --> CSRF cookie sent
INFO - 2018-07-27 16:19:46 --> Input Class Initialized
INFO - 2018-07-27 16:19:46 --> Language Class Initialized
INFO - 2018-07-27 16:19:46 --> Loader Class Initialized
INFO - 2018-07-27 16:19:46 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:46 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:46 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:46 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:46 --> Controller Class Initialized
INFO - 2018-07-27 16:19:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:46 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:46 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:46 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-27 16:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:46 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:46 --> Total execution time: 0.0365
INFO - 2018-07-27 16:19:49 --> Config Class Initialized
INFO - 2018-07-27 16:19:49 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:49 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:49 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:49 --> URI Class Initialized
INFO - 2018-07-27 16:19:49 --> Router Class Initialized
INFO - 2018-07-27 16:19:49 --> Output Class Initialized
INFO - 2018-07-27 16:19:49 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:49 --> CSRF cookie sent
INFO - 2018-07-27 16:19:49 --> CSRF token verified
INFO - 2018-07-27 16:19:49 --> Input Class Initialized
INFO - 2018-07-27 16:19:49 --> Language Class Initialized
INFO - 2018-07-27 16:19:49 --> Loader Class Initialized
INFO - 2018-07-27 16:19:49 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:49 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:49 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:49 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:49 --> Controller Class Initialized
INFO - 2018-07-27 16:19:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:49 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:49 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:49 --> Form Validation Class Initialized
INFO - 2018-07-27 16:19:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 16:19:49 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:49 --> Config Class Initialized
INFO - 2018-07-27 16:19:49 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:49 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:49 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:49 --> URI Class Initialized
INFO - 2018-07-27 16:19:49 --> Router Class Initialized
INFO - 2018-07-27 16:19:49 --> Output Class Initialized
INFO - 2018-07-27 16:19:49 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:49 --> CSRF cookie sent
INFO - 2018-07-27 16:19:49 --> Input Class Initialized
INFO - 2018-07-27 16:19:49 --> Language Class Initialized
INFO - 2018-07-27 16:19:49 --> Loader Class Initialized
INFO - 2018-07-27 16:19:49 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:49 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:49 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:49 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:49 --> Controller Class Initialized
INFO - 2018-07-27 16:19:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:49 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:49 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:49 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-27 16:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:49 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:49 --> Total execution time: 0.0406
INFO - 2018-07-27 16:19:50 --> Config Class Initialized
INFO - 2018-07-27 16:19:50 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:50 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:50 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:50 --> URI Class Initialized
INFO - 2018-07-27 16:19:50 --> Router Class Initialized
INFO - 2018-07-27 16:19:50 --> Output Class Initialized
INFO - 2018-07-27 16:19:50 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:50 --> CSRF cookie sent
INFO - 2018-07-27 16:19:50 --> Input Class Initialized
INFO - 2018-07-27 16:19:50 --> Language Class Initialized
INFO - 2018-07-27 16:19:50 --> Loader Class Initialized
INFO - 2018-07-27 16:19:50 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:50 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:50 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:50 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:50 --> Controller Class Initialized
INFO - 2018-07-27 16:19:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:50 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:50 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:50 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-27 16:19:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:50 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:50 --> Total execution time: 0.0435
INFO - 2018-07-27 16:19:54 --> Config Class Initialized
INFO - 2018-07-27 16:19:54 --> Hooks Class Initialized
DEBUG - 2018-07-27 16:19:54 --> UTF-8 Support Enabled
INFO - 2018-07-27 16:19:54 --> Utf8 Class Initialized
INFO - 2018-07-27 16:19:54 --> URI Class Initialized
INFO - 2018-07-27 16:19:54 --> Router Class Initialized
INFO - 2018-07-27 16:19:54 --> Output Class Initialized
INFO - 2018-07-27 16:19:54 --> Security Class Initialized
DEBUG - 2018-07-27 16:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 16:19:54 --> CSRF cookie sent
INFO - 2018-07-27 16:19:54 --> Input Class Initialized
INFO - 2018-07-27 16:19:54 --> Language Class Initialized
INFO - 2018-07-27 16:19:54 --> Loader Class Initialized
INFO - 2018-07-27 16:19:54 --> Helper loaded: url_helper
INFO - 2018-07-27 16:19:54 --> Helper loaded: form_helper
INFO - 2018-07-27 16:19:54 --> Helper loaded: language_helper
DEBUG - 2018-07-27 16:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 16:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 16:19:54 --> User Agent Class Initialized
INFO - 2018-07-27 16:19:54 --> Controller Class Initialized
INFO - 2018-07-27 16:19:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 16:19:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 16:19:54 --> Pixel_Model class loaded
INFO - 2018-07-27 16:19:54 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:54 --> Database Driver Class Initialized
INFO - 2018-07-27 16:19:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-27 16:19:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 16:19:54 --> Final output sent to browser
DEBUG - 2018-07-27 16:19:54 --> Total execution time: 0.0579
INFO - 2018-07-27 17:44:42 --> Config Class Initialized
INFO - 2018-07-27 17:44:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 17:44:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 17:44:42 --> Utf8 Class Initialized
INFO - 2018-07-27 17:44:42 --> URI Class Initialized
INFO - 2018-07-27 17:44:42 --> Router Class Initialized
INFO - 2018-07-27 17:44:42 --> Output Class Initialized
INFO - 2018-07-27 17:44:42 --> Security Class Initialized
DEBUG - 2018-07-27 17:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 17:44:42 --> CSRF cookie sent
INFO - 2018-07-27 17:44:42 --> Input Class Initialized
INFO - 2018-07-27 17:44:42 --> Language Class Initialized
ERROR - 2018-07-27 17:44:42 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-27 17:50:14 --> Config Class Initialized
INFO - 2018-07-27 17:50:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 17:50:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 17:50:14 --> Utf8 Class Initialized
INFO - 2018-07-27 17:50:14 --> URI Class Initialized
DEBUG - 2018-07-27 17:50:14 --> No URI present. Default controller set.
INFO - 2018-07-27 17:50:14 --> Router Class Initialized
INFO - 2018-07-27 17:50:14 --> Output Class Initialized
INFO - 2018-07-27 17:50:14 --> Security Class Initialized
DEBUG - 2018-07-27 17:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 17:50:14 --> CSRF cookie sent
INFO - 2018-07-27 17:50:14 --> Input Class Initialized
INFO - 2018-07-27 17:50:14 --> Language Class Initialized
INFO - 2018-07-27 17:50:14 --> Loader Class Initialized
INFO - 2018-07-27 17:50:14 --> Helper loaded: url_helper
INFO - 2018-07-27 17:50:14 --> Helper loaded: form_helper
INFO - 2018-07-27 17:50:14 --> Helper loaded: language_helper
DEBUG - 2018-07-27 17:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 17:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 17:50:14 --> User Agent Class Initialized
INFO - 2018-07-27 17:50:14 --> Controller Class Initialized
INFO - 2018-07-27 17:50:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 17:50:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 17:50:14 --> Pixel_Model class loaded
INFO - 2018-07-27 17:50:14 --> Database Driver Class Initialized
INFO - 2018-07-27 17:50:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 17:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 17:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 17:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 17:50:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 17:50:14 --> Final output sent to browser
DEBUG - 2018-07-27 17:50:14 --> Total execution time: 0.0343
INFO - 2018-07-27 18:15:30 --> Config Class Initialized
INFO - 2018-07-27 18:15:30 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:15:30 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:15:30 --> Utf8 Class Initialized
INFO - 2018-07-27 18:15:30 --> URI Class Initialized
DEBUG - 2018-07-27 18:15:30 --> No URI present. Default controller set.
INFO - 2018-07-27 18:15:30 --> Router Class Initialized
INFO - 2018-07-27 18:15:30 --> Output Class Initialized
INFO - 2018-07-27 18:15:30 --> Security Class Initialized
DEBUG - 2018-07-27 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:15:30 --> CSRF cookie sent
INFO - 2018-07-27 18:15:30 --> Input Class Initialized
INFO - 2018-07-27 18:15:30 --> Language Class Initialized
INFO - 2018-07-27 18:15:30 --> Loader Class Initialized
INFO - 2018-07-27 18:15:30 --> Helper loaded: url_helper
INFO - 2018-07-27 18:15:30 --> Helper loaded: form_helper
INFO - 2018-07-27 18:15:30 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:15:30 --> User Agent Class Initialized
INFO - 2018-07-27 18:15:30 --> Controller Class Initialized
INFO - 2018-07-27 18:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 18:15:30 --> Pixel_Model class loaded
INFO - 2018-07-27 18:15:30 --> Database Driver Class Initialized
INFO - 2018-07-27 18:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 18:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 18:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:15:30 --> Final output sent to browser
DEBUG - 2018-07-27 18:15:30 --> Total execution time: 0.0437
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
DEBUG - 2018-07-27 18:40:09 --> No URI present. Default controller set.
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
INFO - 2018-07-27 18:40:09 --> Loader Class Initialized
INFO - 2018-07-27 18:40:09 --> Helper loaded: url_helper
INFO - 2018-07-27 18:40:09 --> Helper loaded: form_helper
INFO - 2018-07-27 18:40:09 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:40:09 --> User Agent Class Initialized
INFO - 2018-07-27 18:40:09 --> Controller Class Initialized
INFO - 2018-07-27 18:40:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:40:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 18:40:09 --> Pixel_Model class loaded
INFO - 2018-07-27 18:40:09 --> Database Driver Class Initialized
INFO - 2018-07-27 18:40:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 18:40:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:40:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:40:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 18:40:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:40:09 --> Final output sent to browser
DEBUG - 2018-07-27 18:40:09 --> Total execution time: 0.0391
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
ERROR - 2018-07-27 18:40:09 --> 404 Page Not Found: Images/team
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
INFO - 2018-07-27 18:40:09 --> Config Class Initialized
INFO - 2018-07-27 18:40:09 --> Hooks Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
DEBUG - 2018-07-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:40:09 --> Utf8 Class Initialized
INFO - 2018-07-27 18:40:09 --> URI Class Initialized
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Router Class Initialized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
INFO - 2018-07-27 18:40:09 --> Output Class Initialized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
ERROR - 2018-07-27 18:40:09 --> 404 Page Not Found: Images/team
ERROR - 2018-07-27 18:40:09 --> 404 Page Not Found: Images/team
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> Security Class Initialized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
DEBUG - 2018-07-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:40:09 --> CSRF cookie sent
INFO - 2018-07-27 18:40:09 --> Input Class Initialized
ERROR - 2018-07-27 18:40:09 --> 404 Page Not Found: Images/team
INFO - 2018-07-27 18:40:09 --> Language Class Initialized
ERROR - 2018-07-27 18:40:09 --> 404 Page Not Found: Faviconico/index
INFO - 2018-07-27 18:41:25 --> Config Class Initialized
INFO - 2018-07-27 18:41:25 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:41:25 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:41:25 --> Utf8 Class Initialized
INFO - 2018-07-27 18:41:25 --> URI Class Initialized
INFO - 2018-07-27 18:41:25 --> Router Class Initialized
INFO - 2018-07-27 18:41:25 --> Output Class Initialized
INFO - 2018-07-27 18:41:25 --> Security Class Initialized
DEBUG - 2018-07-27 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:41:25 --> CSRF cookie sent
INFO - 2018-07-27 18:41:25 --> Input Class Initialized
INFO - 2018-07-27 18:41:25 --> Language Class Initialized
INFO - 2018-07-27 18:41:25 --> Loader Class Initialized
INFO - 2018-07-27 18:41:25 --> Helper loaded: url_helper
INFO - 2018-07-27 18:41:25 --> Helper loaded: form_helper
INFO - 2018-07-27 18:41:25 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:41:25 --> User Agent Class Initialized
INFO - 2018-07-27 18:41:25 --> Controller Class Initialized
INFO - 2018-07-27 18:41:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:41:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-27 18:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:41:26 --> Final output sent to browser
DEBUG - 2018-07-27 18:41:26 --> Total execution time: 0.0219
INFO - 2018-07-27 18:45:18 --> Config Class Initialized
INFO - 2018-07-27 18:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:45:18 --> Utf8 Class Initialized
INFO - 2018-07-27 18:45:18 --> URI Class Initialized
INFO - 2018-07-27 18:45:18 --> Router Class Initialized
INFO - 2018-07-27 18:45:18 --> Output Class Initialized
INFO - 2018-07-27 18:45:18 --> Security Class Initialized
DEBUG - 2018-07-27 18:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:45:18 --> CSRF cookie sent
INFO - 2018-07-27 18:45:18 --> Input Class Initialized
INFO - 2018-07-27 18:45:18 --> Language Class Initialized
ERROR - 2018-07-27 18:45:18 --> 404 Page Not Found: Assets/components
INFO - 2018-07-27 18:45:18 --> Config Class Initialized
INFO - 2018-07-27 18:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:45:18 --> Utf8 Class Initialized
INFO - 2018-07-27 18:45:18 --> URI Class Initialized
INFO - 2018-07-27 18:45:18 --> Router Class Initialized
INFO - 2018-07-27 18:45:18 --> Output Class Initialized
INFO - 2018-07-27 18:45:18 --> Security Class Initialized
DEBUG - 2018-07-27 18:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:45:18 --> CSRF cookie sent
INFO - 2018-07-27 18:55:13 --> Config Class Initialized
INFO - 2018-07-27 18:55:13 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:55:13 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:55:13 --> Utf8 Class Initialized
INFO - 2018-07-27 18:55:13 --> URI Class Initialized
INFO - 2018-07-27 18:55:13 --> Router Class Initialized
INFO - 2018-07-27 18:55:13 --> Output Class Initialized
INFO - 2018-07-27 18:55:13 --> Security Class Initialized
DEBUG - 2018-07-27 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:55:13 --> CSRF cookie sent
INFO - 2018-07-27 18:55:13 --> Input Class Initialized
INFO - 2018-07-27 18:55:13 --> Language Class Initialized
INFO - 2018-07-27 18:55:13 --> Loader Class Initialized
INFO - 2018-07-27 18:55:13 --> Helper loaded: url_helper
INFO - 2018-07-27 18:55:13 --> Helper loaded: form_helper
INFO - 2018-07-27 18:55:13 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:55:13 --> User Agent Class Initialized
INFO - 2018-07-27 18:55:13 --> Controller Class Initialized
INFO - 2018-07-27 18:55:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:55:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 18:55:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 18:55:13 --> Could not find the language line "req_email"
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 18:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:55:13 --> Final output sent to browser
DEBUG - 2018-07-27 18:55:13 --> Total execution time: 0.0207
INFO - 2018-07-27 18:55:36 --> Config Class Initialized
INFO - 2018-07-27 18:55:36 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:55:36 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:55:36 --> Utf8 Class Initialized
INFO - 2018-07-27 18:55:36 --> URI Class Initialized
INFO - 2018-07-27 18:55:36 --> Router Class Initialized
INFO - 2018-07-27 18:55:36 --> Output Class Initialized
INFO - 2018-07-27 18:55:36 --> Security Class Initialized
DEBUG - 2018-07-27 18:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:55:36 --> CSRF cookie sent
INFO - 2018-07-27 18:55:36 --> CSRF token verified
INFO - 2018-07-27 18:55:36 --> Input Class Initialized
INFO - 2018-07-27 18:55:36 --> Language Class Initialized
INFO - 2018-07-27 18:55:36 --> Loader Class Initialized
INFO - 2018-07-27 18:55:36 --> Helper loaded: url_helper
INFO - 2018-07-27 18:55:36 --> Helper loaded: form_helper
INFO - 2018-07-27 18:55:36 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:55:36 --> User Agent Class Initialized
INFO - 2018-07-27 18:55:36 --> Controller Class Initialized
INFO - 2018-07-27 18:55:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:55:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 18:55:36 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 18:55:36 --> Form Validation Class Initialized
INFO - 2018-07-27 18:55:37 --> Config Class Initialized
INFO - 2018-07-27 18:55:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:55:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:55:37 --> Utf8 Class Initialized
INFO - 2018-07-27 18:55:37 --> URI Class Initialized
INFO - 2018-07-27 18:55:37 --> Router Class Initialized
INFO - 2018-07-27 18:55:37 --> Output Class Initialized
INFO - 2018-07-27 18:55:37 --> Security Class Initialized
DEBUG - 2018-07-27 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:55:37 --> CSRF cookie sent
INFO - 2018-07-27 18:55:37 --> Input Class Initialized
INFO - 2018-07-27 18:55:37 --> Language Class Initialized
INFO - 2018-07-27 18:55:37 --> Loader Class Initialized
INFO - 2018-07-27 18:55:37 --> Helper loaded: url_helper
INFO - 2018-07-27 18:55:37 --> Helper loaded: form_helper
INFO - 2018-07-27 18:55:37 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:55:37 --> User Agent Class Initialized
INFO - 2018-07-27 18:55:37 --> Controller Class Initialized
INFO - 2018-07-27 18:55:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:55:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 18:55:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 18:55:37 --> Could not find the language line "req_email"
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 18:55:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:55:37 --> Final output sent to browser
DEBUG - 2018-07-27 18:55:37 --> Total execution time: 0.0287
INFO - 2018-07-27 18:56:06 --> Config Class Initialized
INFO - 2018-07-27 18:56:06 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:56:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:56:06 --> Utf8 Class Initialized
INFO - 2018-07-27 18:56:06 --> URI Class Initialized
INFO - 2018-07-27 18:56:06 --> Router Class Initialized
INFO - 2018-07-27 18:56:06 --> Output Class Initialized
INFO - 2018-07-27 18:56:06 --> Security Class Initialized
DEBUG - 2018-07-27 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:56:06 --> CSRF cookie sent
INFO - 2018-07-27 18:56:06 --> CSRF token verified
INFO - 2018-07-27 18:56:06 --> Input Class Initialized
INFO - 2018-07-27 18:56:06 --> Language Class Initialized
INFO - 2018-07-27 18:56:06 --> Loader Class Initialized
INFO - 2018-07-27 18:56:06 --> Helper loaded: url_helper
INFO - 2018-07-27 18:56:06 --> Helper loaded: form_helper
INFO - 2018-07-27 18:56:06 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:56:06 --> User Agent Class Initialized
INFO - 2018-07-27 18:56:06 --> Controller Class Initialized
INFO - 2018-07-27 18:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:56:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 18:56:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 18:56:06 --> Form Validation Class Initialized
INFO - 2018-07-27 18:56:06 --> Pixel_Model class loaded
INFO - 2018-07-27 18:56:06 --> Database Driver Class Initialized
INFO - 2018-07-27 18:56:06 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 18:56:07 --> Config Class Initialized
INFO - 2018-07-27 18:56:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 18:56:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 18:56:07 --> Utf8 Class Initialized
INFO - 2018-07-27 18:56:07 --> URI Class Initialized
INFO - 2018-07-27 18:56:07 --> Router Class Initialized
INFO - 2018-07-27 18:56:07 --> Output Class Initialized
INFO - 2018-07-27 18:56:07 --> Security Class Initialized
DEBUG - 2018-07-27 18:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 18:56:07 --> CSRF cookie sent
INFO - 2018-07-27 18:56:07 --> Input Class Initialized
INFO - 2018-07-27 18:56:07 --> Language Class Initialized
INFO - 2018-07-27 18:56:07 --> Loader Class Initialized
INFO - 2018-07-27 18:56:07 --> Helper loaded: url_helper
INFO - 2018-07-27 18:56:07 --> Helper loaded: form_helper
INFO - 2018-07-27 18:56:07 --> Helper loaded: language_helper
DEBUG - 2018-07-27 18:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 18:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 18:56:07 --> User Agent Class Initialized
INFO - 2018-07-27 18:56:07 --> Controller Class Initialized
INFO - 2018-07-27 18:56:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 18:56:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 18:56:07 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-27 18:56:07 --> Could not find the language line "req_email"
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 18:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 18:56:07 --> Final output sent to browser
DEBUG - 2018-07-27 18:56:07 --> Total execution time: 0.0230
INFO - 2018-07-27 19:14:00 --> Config Class Initialized
INFO - 2018-07-27 19:14:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:14:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:14:00 --> Utf8 Class Initialized
INFO - 2018-07-27 19:14:00 --> URI Class Initialized
DEBUG - 2018-07-27 19:14:00 --> No URI present. Default controller set.
INFO - 2018-07-27 19:14:00 --> Router Class Initialized
INFO - 2018-07-27 19:14:00 --> Output Class Initialized
INFO - 2018-07-27 19:14:00 --> Security Class Initialized
DEBUG - 2018-07-27 19:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:14:00 --> CSRF cookie sent
INFO - 2018-07-27 19:14:00 --> Input Class Initialized
INFO - 2018-07-27 19:14:00 --> Language Class Initialized
INFO - 2018-07-27 19:14:00 --> Loader Class Initialized
INFO - 2018-07-27 19:14:00 --> Helper loaded: url_helper
INFO - 2018-07-27 19:14:00 --> Helper loaded: form_helper
INFO - 2018-07-27 19:14:00 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:14:00 --> User Agent Class Initialized
INFO - 2018-07-27 19:14:01 --> Controller Class Initialized
INFO - 2018-07-27 19:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:14:01 --> Pixel_Model class loaded
INFO - 2018-07-27 19:14:01 --> Database Driver Class Initialized
INFO - 2018-07-27 19:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 19:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:14:01 --> Final output sent to browser
DEBUG - 2018-07-27 19:14:01 --> Total execution time: 0.0329
INFO - 2018-07-27 19:21:55 --> Config Class Initialized
INFO - 2018-07-27 19:21:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:21:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:21:55 --> Utf8 Class Initialized
INFO - 2018-07-27 19:21:55 --> URI Class Initialized
DEBUG - 2018-07-27 19:21:55 --> No URI present. Default controller set.
INFO - 2018-07-27 19:21:55 --> Router Class Initialized
INFO - 2018-07-27 19:21:55 --> Output Class Initialized
INFO - 2018-07-27 19:21:55 --> Security Class Initialized
DEBUG - 2018-07-27 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:21:55 --> CSRF cookie sent
INFO - 2018-07-27 19:21:55 --> Input Class Initialized
INFO - 2018-07-27 19:21:55 --> Language Class Initialized
INFO - 2018-07-27 19:21:55 --> Loader Class Initialized
INFO - 2018-07-27 19:21:55 --> Helper loaded: url_helper
INFO - 2018-07-27 19:21:55 --> Helper loaded: form_helper
INFO - 2018-07-27 19:21:55 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:21:55 --> User Agent Class Initialized
INFO - 2018-07-27 19:21:55 --> Controller Class Initialized
INFO - 2018-07-27 19:21:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:21:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:21:55 --> Pixel_Model class loaded
INFO - 2018-07-27 19:21:55 --> Database Driver Class Initialized
INFO - 2018-07-27 19:21:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 19:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:21:55 --> Final output sent to browser
DEBUG - 2018-07-27 19:21:55 --> Total execution time: 0.0354
INFO - 2018-07-27 19:22:03 --> Config Class Initialized
INFO - 2018-07-27 19:22:03 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:03 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:03 --> URI Class Initialized
INFO - 2018-07-27 19:22:03 --> Router Class Initialized
INFO - 2018-07-27 19:22:03 --> Output Class Initialized
INFO - 2018-07-27 19:22:03 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:03 --> CSRF cookie sent
INFO - 2018-07-27 19:22:03 --> Input Class Initialized
INFO - 2018-07-27 19:22:03 --> Language Class Initialized
INFO - 2018-07-27 19:22:03 --> Loader Class Initialized
INFO - 2018-07-27 19:22:03 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:03 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:03 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:03 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:03 --> Controller Class Initialized
INFO - 2018-07-27 19:22:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:22:03 --> Pixel_Model class loaded
INFO - 2018-07-27 19:22:03 --> Database Driver Class Initialized
INFO - 2018-07-27 19:22:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:22:03 --> Config Class Initialized
INFO - 2018-07-27 19:22:03 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:03 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:03 --> URI Class Initialized
INFO - 2018-07-27 19:22:03 --> Router Class Initialized
INFO - 2018-07-27 19:22:03 --> Output Class Initialized
INFO - 2018-07-27 19:22:03 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:03 --> CSRF cookie sent
INFO - 2018-07-27 19:22:03 --> Input Class Initialized
INFO - 2018-07-27 19:22:03 --> Language Class Initialized
INFO - 2018-07-27 19:22:03 --> Loader Class Initialized
INFO - 2018-07-27 19:22:03 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:03 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:03 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:03 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:03 --> Controller Class Initialized
INFO - 2018-07-27 19:22:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 19:22:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 19:22:03 --> Could not find the language line "req_email"
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 19:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:22:03 --> Final output sent to browser
DEBUG - 2018-07-27 19:22:03 --> Total execution time: 0.0215
INFO - 2018-07-27 19:22:07 --> Config Class Initialized
INFO - 2018-07-27 19:22:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:07 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:07 --> URI Class Initialized
INFO - 2018-07-27 19:22:07 --> Router Class Initialized
INFO - 2018-07-27 19:22:07 --> Output Class Initialized
INFO - 2018-07-27 19:22:07 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:07 --> CSRF cookie sent
INFO - 2018-07-27 19:22:07 --> Input Class Initialized
INFO - 2018-07-27 19:22:07 --> Language Class Initialized
INFO - 2018-07-27 19:22:07 --> Loader Class Initialized
INFO - 2018-07-27 19:22:07 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:07 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:07 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:07 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:07 --> Controller Class Initialized
INFO - 2018-07-27 19:22:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:22:07 --> Pixel_Model class loaded
INFO - 2018-07-27 19:22:07 --> Database Driver Class Initialized
INFO - 2018-07-27 19:22:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:22:07 --> Config Class Initialized
INFO - 2018-07-27 19:22:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:07 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:07 --> URI Class Initialized
INFO - 2018-07-27 19:22:07 --> Router Class Initialized
INFO - 2018-07-27 19:22:07 --> Output Class Initialized
INFO - 2018-07-27 19:22:07 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:07 --> CSRF cookie sent
INFO - 2018-07-27 19:22:07 --> Input Class Initialized
INFO - 2018-07-27 19:22:07 --> Language Class Initialized
INFO - 2018-07-27 19:22:07 --> Loader Class Initialized
INFO - 2018-07-27 19:22:07 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:07 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:07 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:07 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:07 --> Controller Class Initialized
INFO - 2018-07-27 19:22:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 19:22:07 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 19:22:07 --> Could not find the language line "req_email"
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 19:22:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:22:07 --> Final output sent to browser
DEBUG - 2018-07-27 19:22:07 --> Total execution time: 0.0230
INFO - 2018-07-27 19:22:10 --> Config Class Initialized
INFO - 2018-07-27 19:22:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:10 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:10 --> URI Class Initialized
DEBUG - 2018-07-27 19:22:10 --> No URI present. Default controller set.
INFO - 2018-07-27 19:22:10 --> Router Class Initialized
INFO - 2018-07-27 19:22:10 --> Output Class Initialized
INFO - 2018-07-27 19:22:10 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:10 --> CSRF cookie sent
INFO - 2018-07-27 19:22:10 --> Input Class Initialized
INFO - 2018-07-27 19:22:10 --> Language Class Initialized
INFO - 2018-07-27 19:22:10 --> Loader Class Initialized
INFO - 2018-07-27 19:22:10 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:10 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:10 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:10 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:10 --> Controller Class Initialized
INFO - 2018-07-27 19:22:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:22:10 --> Pixel_Model class loaded
INFO - 2018-07-27 19:22:10 --> Database Driver Class Initialized
INFO - 2018-07-27 19:22:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 19:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:22:10 --> Final output sent to browser
DEBUG - 2018-07-27 19:22:10 --> Total execution time: 0.0335
INFO - 2018-07-27 19:22:18 --> Config Class Initialized
INFO - 2018-07-27 19:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:18 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:18 --> URI Class Initialized
INFO - 2018-07-27 19:22:18 --> Router Class Initialized
INFO - 2018-07-27 19:22:18 --> Output Class Initialized
INFO - 2018-07-27 19:22:18 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:18 --> CSRF cookie sent
INFO - 2018-07-27 19:22:18 --> Input Class Initialized
INFO - 2018-07-27 19:22:18 --> Language Class Initialized
INFO - 2018-07-27 19:22:18 --> Loader Class Initialized
INFO - 2018-07-27 19:22:18 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:18 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:18 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:18 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:18 --> Controller Class Initialized
INFO - 2018-07-27 19:22:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:22:18 --> Pixel_Model class loaded
INFO - 2018-07-27 19:22:18 --> Database Driver Class Initialized
INFO - 2018-07-27 19:22:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:22:18 --> Config Class Initialized
INFO - 2018-07-27 19:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:22:18 --> Utf8 Class Initialized
INFO - 2018-07-27 19:22:18 --> URI Class Initialized
INFO - 2018-07-27 19:22:18 --> Router Class Initialized
INFO - 2018-07-27 19:22:18 --> Output Class Initialized
INFO - 2018-07-27 19:22:18 --> Security Class Initialized
DEBUG - 2018-07-27 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:22:18 --> CSRF cookie sent
INFO - 2018-07-27 19:22:18 --> Input Class Initialized
INFO - 2018-07-27 19:22:18 --> Language Class Initialized
INFO - 2018-07-27 19:22:18 --> Loader Class Initialized
INFO - 2018-07-27 19:22:18 --> Helper loaded: url_helper
INFO - 2018-07-27 19:22:18 --> Helper loaded: form_helper
INFO - 2018-07-27 19:22:18 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:22:18 --> User Agent Class Initialized
INFO - 2018-07-27 19:22:18 --> Controller Class Initialized
INFO - 2018-07-27 19:22:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:22:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 19:22:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 19:22:18 --> Could not find the language line "req_email"
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 19:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:22:18 --> Final output sent to browser
DEBUG - 2018-07-27 19:22:18 --> Total execution time: 0.0234
INFO - 2018-07-27 19:24:16 --> Config Class Initialized
INFO - 2018-07-27 19:24:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:24:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:24:16 --> Utf8 Class Initialized
INFO - 2018-07-27 19:24:16 --> URI Class Initialized
INFO - 2018-07-27 19:24:16 --> Router Class Initialized
INFO - 2018-07-27 19:24:16 --> Output Class Initialized
INFO - 2018-07-27 19:24:16 --> Security Class Initialized
DEBUG - 2018-07-27 19:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:24:16 --> CSRF cookie sent
INFO - 2018-07-27 19:24:16 --> Input Class Initialized
INFO - 2018-07-27 19:24:16 --> Language Class Initialized
INFO - 2018-07-27 19:24:16 --> Loader Class Initialized
INFO - 2018-07-27 19:24:16 --> Helper loaded: url_helper
INFO - 2018-07-27 19:24:16 --> Helper loaded: form_helper
INFO - 2018-07-27 19:24:16 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:24:16 --> User Agent Class Initialized
INFO - 2018-07-27 19:24:16 --> Controller Class Initialized
INFO - 2018-07-27 19:24:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:24:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-27 19:24:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:24:16 --> Final output sent to browser
DEBUG - 2018-07-27 19:24:16 --> Total execution time: 0.0278
INFO - 2018-07-27 19:24:22 --> Config Class Initialized
INFO - 2018-07-27 19:24:22 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:24:22 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:24:22 --> Utf8 Class Initialized
INFO - 2018-07-27 19:24:22 --> URI Class Initialized
INFO - 2018-07-27 19:24:22 --> Router Class Initialized
INFO - 2018-07-27 19:24:22 --> Output Class Initialized
INFO - 2018-07-27 19:24:22 --> Security Class Initialized
DEBUG - 2018-07-27 19:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:24:22 --> CSRF cookie sent
INFO - 2018-07-27 19:24:22 --> Input Class Initialized
INFO - 2018-07-27 19:24:22 --> Language Class Initialized
INFO - 2018-07-27 19:24:22 --> Loader Class Initialized
INFO - 2018-07-27 19:24:22 --> Helper loaded: url_helper
INFO - 2018-07-27 19:24:22 --> Helper loaded: form_helper
INFO - 2018-07-27 19:24:22 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:24:22 --> User Agent Class Initialized
INFO - 2018-07-27 19:24:22 --> Controller Class Initialized
INFO - 2018-07-27 19:24:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:24:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-27 19:24:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:24:22 --> Final output sent to browser
DEBUG - 2018-07-27 19:24:22 --> Total execution time: 0.0225
INFO - 2018-07-27 19:24:45 --> Config Class Initialized
INFO - 2018-07-27 19:24:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:24:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:24:45 --> Utf8 Class Initialized
INFO - 2018-07-27 19:24:45 --> URI Class Initialized
INFO - 2018-07-27 19:24:45 --> Router Class Initialized
INFO - 2018-07-27 19:24:45 --> Output Class Initialized
INFO - 2018-07-27 19:24:45 --> Security Class Initialized
DEBUG - 2018-07-27 19:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:24:45 --> CSRF cookie sent
INFO - 2018-07-27 19:24:45 --> Input Class Initialized
INFO - 2018-07-27 19:24:45 --> Language Class Initialized
INFO - 2018-07-27 19:24:45 --> Loader Class Initialized
INFO - 2018-07-27 19:24:45 --> Helper loaded: url_helper
INFO - 2018-07-27 19:24:45 --> Helper loaded: form_helper
INFO - 2018-07-27 19:24:45 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:24:45 --> User Agent Class Initialized
INFO - 2018-07-27 19:24:45 --> Controller Class Initialized
INFO - 2018-07-27 19:24:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:24:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 19:24:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 19:24:45 --> Could not find the language line "req_email"
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 19:24:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:24:45 --> Final output sent to browser
DEBUG - 2018-07-27 19:24:45 --> Total execution time: 0.0264
INFO - 2018-07-27 19:25:33 --> Config Class Initialized
INFO - 2018-07-27 19:25:33 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:25:33 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:25:33 --> Utf8 Class Initialized
INFO - 2018-07-27 19:25:33 --> URI Class Initialized
INFO - 2018-07-27 19:25:33 --> Router Class Initialized
INFO - 2018-07-27 19:25:33 --> Output Class Initialized
INFO - 2018-07-27 19:25:33 --> Security Class Initialized
DEBUG - 2018-07-27 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:25:33 --> CSRF cookie sent
INFO - 2018-07-27 19:25:33 --> Input Class Initialized
INFO - 2018-07-27 19:25:33 --> Language Class Initialized
INFO - 2018-07-27 19:25:33 --> Loader Class Initialized
INFO - 2018-07-27 19:25:33 --> Helper loaded: url_helper
INFO - 2018-07-27 19:25:33 --> Helper loaded: form_helper
INFO - 2018-07-27 19:25:33 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:25:33 --> User Agent Class Initialized
INFO - 2018-07-27 19:25:33 --> Controller Class Initialized
INFO - 2018-07-27 19:25:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:25:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:25:33 --> Pixel_Model class loaded
INFO - 2018-07-27 19:25:33 --> Database Driver Class Initialized
INFO - 2018-07-27 19:25:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:25:34 --> Config Class Initialized
INFO - 2018-07-27 19:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:25:34 --> Utf8 Class Initialized
INFO - 2018-07-27 19:25:34 --> URI Class Initialized
INFO - 2018-07-27 19:25:34 --> Router Class Initialized
INFO - 2018-07-27 19:25:34 --> Output Class Initialized
INFO - 2018-07-27 19:25:34 --> Security Class Initialized
DEBUG - 2018-07-27 19:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:25:34 --> CSRF cookie sent
INFO - 2018-07-27 19:25:34 --> Input Class Initialized
INFO - 2018-07-27 19:25:34 --> Language Class Initialized
INFO - 2018-07-27 19:25:34 --> Loader Class Initialized
INFO - 2018-07-27 19:25:34 --> Helper loaded: url_helper
INFO - 2018-07-27 19:25:34 --> Helper loaded: form_helper
INFO - 2018-07-27 19:25:34 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:25:34 --> User Agent Class Initialized
INFO - 2018-07-27 19:25:34 --> Controller Class Initialized
INFO - 2018-07-27 19:25:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:25:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 19:25:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 19:25:34 --> Could not find the language line "req_email"
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 19:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:25:34 --> Final output sent to browser
DEBUG - 2018-07-27 19:25:34 --> Total execution time: 0.0241
INFO - 2018-07-27 19:41:34 --> Config Class Initialized
INFO - 2018-07-27 19:41:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 19:41:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 19:41:34 --> Utf8 Class Initialized
INFO - 2018-07-27 19:41:34 --> URI Class Initialized
DEBUG - 2018-07-27 19:41:34 --> No URI present. Default controller set.
INFO - 2018-07-27 19:41:34 --> Router Class Initialized
INFO - 2018-07-27 19:41:34 --> Output Class Initialized
INFO - 2018-07-27 19:41:34 --> Security Class Initialized
DEBUG - 2018-07-27 19:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 19:41:34 --> CSRF cookie sent
INFO - 2018-07-27 19:41:34 --> Input Class Initialized
INFO - 2018-07-27 19:41:34 --> Language Class Initialized
INFO - 2018-07-27 19:41:34 --> Loader Class Initialized
INFO - 2018-07-27 19:41:34 --> Helper loaded: url_helper
INFO - 2018-07-27 19:41:34 --> Helper loaded: form_helper
INFO - 2018-07-27 19:41:34 --> Helper loaded: language_helper
DEBUG - 2018-07-27 19:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 19:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 19:41:34 --> User Agent Class Initialized
INFO - 2018-07-27 19:41:34 --> Controller Class Initialized
INFO - 2018-07-27 19:41:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 19:41:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 19:41:34 --> Pixel_Model class loaded
INFO - 2018-07-27 19:41:34 --> Database Driver Class Initialized
INFO - 2018-07-27 19:41:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 19:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 19:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 19:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 19:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 19:41:34 --> Final output sent to browser
DEBUG - 2018-07-27 19:41:34 --> Total execution time: 0.0445
INFO - 2018-07-27 21:43:02 --> Config Class Initialized
INFO - 2018-07-27 21:43:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:43:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:43:02 --> Utf8 Class Initialized
INFO - 2018-07-27 21:43:02 --> URI Class Initialized
INFO - 2018-07-27 21:43:02 --> Router Class Initialized
INFO - 2018-07-27 21:43:02 --> Output Class Initialized
INFO - 2018-07-27 21:43:02 --> Security Class Initialized
DEBUG - 2018-07-27 21:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:43:02 --> CSRF cookie sent
INFO - 2018-07-27 21:43:02 --> Input Class Initialized
INFO - 2018-07-27 21:43:02 --> Language Class Initialized
ERROR - 2018-07-27 21:43:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-27 21:43:05 --> Config Class Initialized
INFO - 2018-07-27 21:43:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:43:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:43:05 --> Utf8 Class Initialized
INFO - 2018-07-27 21:43:05 --> URI Class Initialized
DEBUG - 2018-07-27 21:43:05 --> No URI present. Default controller set.
INFO - 2018-07-27 21:43:05 --> Router Class Initialized
INFO - 2018-07-27 21:43:05 --> Output Class Initialized
INFO - 2018-07-27 21:43:05 --> Security Class Initialized
DEBUG - 2018-07-27 21:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:43:05 --> CSRF cookie sent
INFO - 2018-07-27 21:43:05 --> Input Class Initialized
INFO - 2018-07-27 21:43:05 --> Language Class Initialized
INFO - 2018-07-27 21:43:05 --> Loader Class Initialized
INFO - 2018-07-27 21:43:05 --> Helper loaded: url_helper
INFO - 2018-07-27 21:43:05 --> Helper loaded: form_helper
INFO - 2018-07-27 21:43:05 --> Helper loaded: language_helper
DEBUG - 2018-07-27 21:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 21:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 21:43:05 --> User Agent Class Initialized
INFO - 2018-07-27 21:43:05 --> Controller Class Initialized
INFO - 2018-07-27 21:43:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 21:43:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 21:43:05 --> Pixel_Model class loaded
INFO - 2018-07-27 21:43:05 --> Database Driver Class Initialized
INFO - 2018-07-27 21:43:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 21:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 21:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 21:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 21:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 21:43:05 --> Final output sent to browser
DEBUG - 2018-07-27 21:43:05 --> Total execution time: 0.0328
INFO - 2018-07-27 22:19:55 --> Config Class Initialized
INFO - 2018-07-27 22:19:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:19:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:19:55 --> Utf8 Class Initialized
INFO - 2018-07-27 22:19:55 --> URI Class Initialized
DEBUG - 2018-07-27 22:19:55 --> No URI present. Default controller set.
INFO - 2018-07-27 22:19:55 --> Router Class Initialized
INFO - 2018-07-27 22:19:55 --> Output Class Initialized
INFO - 2018-07-27 22:19:55 --> Security Class Initialized
DEBUG - 2018-07-27 22:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:19:55 --> CSRF cookie sent
INFO - 2018-07-27 22:19:55 --> Input Class Initialized
INFO - 2018-07-27 22:19:55 --> Language Class Initialized
INFO - 2018-07-27 22:19:55 --> Loader Class Initialized
INFO - 2018-07-27 22:19:55 --> Helper loaded: url_helper
INFO - 2018-07-27 22:19:55 --> Helper loaded: form_helper
INFO - 2018-07-27 22:19:55 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:19:55 --> User Agent Class Initialized
INFO - 2018-07-27 22:19:55 --> Controller Class Initialized
INFO - 2018-07-27 22:19:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:19:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:19:55 --> Pixel_Model class loaded
INFO - 2018-07-27 22:19:55 --> Database Driver Class Initialized
INFO - 2018-07-27 22:19:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:19:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:19:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:19:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:19:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:19:55 --> Final output sent to browser
DEBUG - 2018-07-27 22:19:55 --> Total execution time: 0.0419
INFO - 2018-07-27 22:20:53 --> Config Class Initialized
INFO - 2018-07-27 22:20:53 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:20:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:20:53 --> Utf8 Class Initialized
INFO - 2018-07-27 22:20:53 --> URI Class Initialized
INFO - 2018-07-27 22:20:53 --> Router Class Initialized
INFO - 2018-07-27 22:20:53 --> Output Class Initialized
INFO - 2018-07-27 22:20:53 --> Security Class Initialized
DEBUG - 2018-07-27 22:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:20:53 --> CSRF cookie sent
INFO - 2018-07-27 22:20:53 --> CSRF token verified
INFO - 2018-07-27 22:20:53 --> Input Class Initialized
INFO - 2018-07-27 22:20:53 --> Language Class Initialized
INFO - 2018-07-27 22:20:53 --> Loader Class Initialized
INFO - 2018-07-27 22:20:53 --> Helper loaded: url_helper
INFO - 2018-07-27 22:20:53 --> Helper loaded: form_helper
INFO - 2018-07-27 22:20:53 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:20:53 --> User Agent Class Initialized
INFO - 2018-07-27 22:20:53 --> Controller Class Initialized
INFO - 2018-07-27 22:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:20:53 --> Pixel_Model class loaded
INFO - 2018-07-27 22:20:53 --> Database Driver Class Initialized
INFO - 2018-07-27 22:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:20:53 --> Config Class Initialized
INFO - 2018-07-27 22:20:53 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:20:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:20:53 --> Utf8 Class Initialized
INFO - 2018-07-27 22:20:53 --> URI Class Initialized
INFO - 2018-07-27 22:20:53 --> Router Class Initialized
INFO - 2018-07-27 22:20:53 --> Output Class Initialized
INFO - 2018-07-27 22:20:53 --> Security Class Initialized
DEBUG - 2018-07-27 22:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:20:53 --> CSRF cookie sent
INFO - 2018-07-27 22:20:53 --> Input Class Initialized
INFO - 2018-07-27 22:20:53 --> Language Class Initialized
INFO - 2018-07-27 22:20:53 --> Loader Class Initialized
INFO - 2018-07-27 22:20:53 --> Helper loaded: url_helper
INFO - 2018-07-27 22:20:53 --> Helper loaded: form_helper
INFO - 2018-07-27 22:20:53 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:20:53 --> User Agent Class Initialized
INFO - 2018-07-27 22:20:53 --> Controller Class Initialized
INFO - 2018-07-27 22:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:20:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:20:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:20:53 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:20:53 --> Final output sent to browser
DEBUG - 2018-07-27 22:20:53 --> Total execution time: 0.0270
INFO - 2018-07-27 22:21:21 --> Config Class Initialized
INFO - 2018-07-27 22:21:21 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:21:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:21:21 --> Utf8 Class Initialized
INFO - 2018-07-27 22:21:21 --> URI Class Initialized
DEBUG - 2018-07-27 22:21:21 --> No URI present. Default controller set.
INFO - 2018-07-27 22:21:21 --> Router Class Initialized
INFO - 2018-07-27 22:21:21 --> Output Class Initialized
INFO - 2018-07-27 22:21:21 --> Security Class Initialized
DEBUG - 2018-07-27 22:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:21:21 --> CSRF cookie sent
INFO - 2018-07-27 22:21:21 --> Input Class Initialized
INFO - 2018-07-27 22:21:21 --> Language Class Initialized
INFO - 2018-07-27 22:21:21 --> Loader Class Initialized
INFO - 2018-07-27 22:21:21 --> Helper loaded: url_helper
INFO - 2018-07-27 22:21:21 --> Helper loaded: form_helper
INFO - 2018-07-27 22:21:21 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:21:21 --> User Agent Class Initialized
INFO - 2018-07-27 22:21:21 --> Controller Class Initialized
INFO - 2018-07-27 22:21:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:21:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:21:21 --> Pixel_Model class loaded
INFO - 2018-07-27 22:21:21 --> Database Driver Class Initialized
INFO - 2018-07-27 22:21:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:21:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:21:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:21:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:21:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:21:21 --> Final output sent to browser
DEBUG - 2018-07-27 22:21:21 --> Total execution time: 0.0401
INFO - 2018-07-27 22:21:47 --> Config Class Initialized
INFO - 2018-07-27 22:21:47 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:21:47 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:21:47 --> Utf8 Class Initialized
INFO - 2018-07-27 22:21:47 --> URI Class Initialized
DEBUG - 2018-07-27 22:21:47 --> No URI present. Default controller set.
INFO - 2018-07-27 22:21:47 --> Router Class Initialized
INFO - 2018-07-27 22:21:47 --> Output Class Initialized
INFO - 2018-07-27 22:21:47 --> Security Class Initialized
DEBUG - 2018-07-27 22:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:21:47 --> CSRF cookie sent
INFO - 2018-07-27 22:21:47 --> Input Class Initialized
INFO - 2018-07-27 22:21:47 --> Language Class Initialized
INFO - 2018-07-27 22:21:47 --> Loader Class Initialized
INFO - 2018-07-27 22:21:47 --> Helper loaded: url_helper
INFO - 2018-07-27 22:21:47 --> Helper loaded: form_helper
INFO - 2018-07-27 22:21:47 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:21:47 --> User Agent Class Initialized
INFO - 2018-07-27 22:21:47 --> Controller Class Initialized
INFO - 2018-07-27 22:21:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:21:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:21:47 --> Pixel_Model class loaded
INFO - 2018-07-27 22:21:47 --> Database Driver Class Initialized
INFO - 2018-07-27 22:21:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:21:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:21:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:21:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:21:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:21:47 --> Final output sent to browser
DEBUG - 2018-07-27 22:21:47 --> Total execution time: 0.0466
INFO - 2018-07-27 22:21:58 --> Config Class Initialized
INFO - 2018-07-27 22:21:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:21:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:21:58 --> Utf8 Class Initialized
INFO - 2018-07-27 22:21:58 --> URI Class Initialized
INFO - 2018-07-27 22:21:58 --> Router Class Initialized
INFO - 2018-07-27 22:21:58 --> Output Class Initialized
INFO - 2018-07-27 22:21:58 --> Security Class Initialized
DEBUG - 2018-07-27 22:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:21:58 --> CSRF cookie sent
INFO - 2018-07-27 22:21:58 --> CSRF token verified
INFO - 2018-07-27 22:21:58 --> Input Class Initialized
INFO - 2018-07-27 22:21:58 --> Language Class Initialized
INFO - 2018-07-27 22:21:58 --> Loader Class Initialized
INFO - 2018-07-27 22:21:58 --> Helper loaded: url_helper
INFO - 2018-07-27 22:21:58 --> Helper loaded: form_helper
INFO - 2018-07-27 22:21:58 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:21:58 --> User Agent Class Initialized
INFO - 2018-07-27 22:21:58 --> Controller Class Initialized
INFO - 2018-07-27 22:21:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:21:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:21:58 --> Pixel_Model class loaded
INFO - 2018-07-27 22:21:58 --> Database Driver Class Initialized
INFO - 2018-07-27 22:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:21:58 --> Config Class Initialized
INFO - 2018-07-27 22:21:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:21:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:21:58 --> Utf8 Class Initialized
INFO - 2018-07-27 22:21:58 --> URI Class Initialized
INFO - 2018-07-27 22:21:58 --> Router Class Initialized
INFO - 2018-07-27 22:21:58 --> Output Class Initialized
INFO - 2018-07-27 22:21:58 --> Security Class Initialized
DEBUG - 2018-07-27 22:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:21:58 --> CSRF cookie sent
INFO - 2018-07-27 22:21:58 --> Input Class Initialized
INFO - 2018-07-27 22:21:58 --> Language Class Initialized
INFO - 2018-07-27 22:21:58 --> Loader Class Initialized
INFO - 2018-07-27 22:21:58 --> Helper loaded: url_helper
INFO - 2018-07-27 22:21:58 --> Helper loaded: form_helper
INFO - 2018-07-27 22:21:58 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:21:58 --> User Agent Class Initialized
INFO - 2018-07-27 22:21:58 --> Controller Class Initialized
INFO - 2018-07-27 22:21:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:21:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:21:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:21:58 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:21:58 --> Final output sent to browser
DEBUG - 2018-07-27 22:21:58 --> Total execution time: 0.0241
INFO - 2018-07-27 22:22:13 --> Config Class Initialized
INFO - 2018-07-27 22:22:13 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:13 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:13 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:13 --> URI Class Initialized
DEBUG - 2018-07-27 22:22:13 --> No URI present. Default controller set.
INFO - 2018-07-27 22:22:13 --> Router Class Initialized
INFO - 2018-07-27 22:22:13 --> Output Class Initialized
INFO - 2018-07-27 22:22:13 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:13 --> CSRF cookie sent
INFO - 2018-07-27 22:22:13 --> Input Class Initialized
INFO - 2018-07-27 22:22:13 --> Language Class Initialized
INFO - 2018-07-27 22:22:13 --> Loader Class Initialized
INFO - 2018-07-27 22:22:13 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:13 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:13 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:13 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:13 --> Controller Class Initialized
INFO - 2018-07-27 22:22:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:22:13 --> Pixel_Model class loaded
INFO - 2018-07-27 22:22:13 --> Database Driver Class Initialized
INFO - 2018-07-27 22:22:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:22:13 --> Final output sent to browser
DEBUG - 2018-07-27 22:22:13 --> Total execution time: 0.0384
INFO - 2018-07-27 22:22:24 --> Config Class Initialized
INFO - 2018-07-27 22:22:24 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:24 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:24 --> URI Class Initialized
INFO - 2018-07-27 22:22:24 --> Router Class Initialized
INFO - 2018-07-27 22:22:24 --> Output Class Initialized
INFO - 2018-07-27 22:22:24 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:24 --> CSRF cookie sent
INFO - 2018-07-27 22:22:24 --> Input Class Initialized
INFO - 2018-07-27 22:22:24 --> Language Class Initialized
INFO - 2018-07-27 22:22:24 --> Loader Class Initialized
INFO - 2018-07-27 22:22:24 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:24 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:24 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:24 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:24 --> Controller Class Initialized
INFO - 2018-07-27 22:22:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:22:24 --> Pixel_Model class loaded
INFO - 2018-07-27 22:22:24 --> Database Driver Class Initialized
INFO - 2018-07-27 22:22:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:22:24 --> Config Class Initialized
INFO - 2018-07-27 22:22:24 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:24 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:24 --> URI Class Initialized
INFO - 2018-07-27 22:22:24 --> Router Class Initialized
INFO - 2018-07-27 22:22:24 --> Output Class Initialized
INFO - 2018-07-27 22:22:24 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:24 --> CSRF cookie sent
INFO - 2018-07-27 22:22:24 --> Input Class Initialized
INFO - 2018-07-27 22:22:24 --> Language Class Initialized
INFO - 2018-07-27 22:22:24 --> Loader Class Initialized
INFO - 2018-07-27 22:22:24 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:24 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:24 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:24 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:24 --> Controller Class Initialized
INFO - 2018-07-27 22:22:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:22:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:22:24 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:22:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:22:24 --> Final output sent to browser
DEBUG - 2018-07-27 22:22:24 --> Total execution time: 0.0238
INFO - 2018-07-27 22:22:40 --> Config Class Initialized
INFO - 2018-07-27 22:22:40 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:40 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:40 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:40 --> URI Class Initialized
INFO - 2018-07-27 22:22:40 --> Router Class Initialized
INFO - 2018-07-27 22:22:40 --> Output Class Initialized
INFO - 2018-07-27 22:22:40 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:40 --> CSRF cookie sent
INFO - 2018-07-27 22:22:40 --> Input Class Initialized
INFO - 2018-07-27 22:22:40 --> Language Class Initialized
INFO - 2018-07-27 22:22:40 --> Loader Class Initialized
INFO - 2018-07-27 22:22:40 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:40 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:40 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:40 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:40 --> Controller Class Initialized
INFO - 2018-07-27 22:22:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:22:40 --> Pixel_Model class loaded
INFO - 2018-07-27 22:22:40 --> Database Driver Class Initialized
INFO - 2018-07-27 22:22:40 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-27 22:22:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-27 22:22:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:22:40 --> Final output sent to browser
DEBUG - 2018-07-27 22:22:40 --> Total execution time: 0.0474
INFO - 2018-07-27 22:22:43 --> Config Class Initialized
INFO - 2018-07-27 22:22:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:43 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:43 --> URI Class Initialized
INFO - 2018-07-27 22:22:43 --> Router Class Initialized
INFO - 2018-07-27 22:22:43 --> Output Class Initialized
INFO - 2018-07-27 22:22:43 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:43 --> CSRF cookie sent
INFO - 2018-07-27 22:22:43 --> Input Class Initialized
INFO - 2018-07-27 22:22:43 --> Language Class Initialized
INFO - 2018-07-27 22:22:43 --> Loader Class Initialized
INFO - 2018-07-27 22:22:43 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:43 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:43 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:43 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:43 --> Controller Class Initialized
INFO - 2018-07-27 22:22:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:22:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:22:43 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:22:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:22:43 --> Final output sent to browser
DEBUG - 2018-07-27 22:22:43 --> Total execution time: 0.0239
INFO - 2018-07-27 22:22:51 --> Config Class Initialized
INFO - 2018-07-27 22:22:51 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:22:51 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:22:51 --> Utf8 Class Initialized
INFO - 2018-07-27 22:22:51 --> URI Class Initialized
INFO - 2018-07-27 22:22:51 --> Router Class Initialized
INFO - 2018-07-27 22:22:51 --> Output Class Initialized
INFO - 2018-07-27 22:22:51 --> Security Class Initialized
DEBUG - 2018-07-27 22:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:22:51 --> CSRF cookie sent
INFO - 2018-07-27 22:22:51 --> Input Class Initialized
INFO - 2018-07-27 22:22:51 --> Language Class Initialized
INFO - 2018-07-27 22:22:51 --> Loader Class Initialized
INFO - 2018-07-27 22:22:51 --> Helper loaded: url_helper
INFO - 2018-07-27 22:22:51 --> Helper loaded: form_helper
INFO - 2018-07-27 22:22:51 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:22:51 --> User Agent Class Initialized
INFO - 2018-07-27 22:22:51 --> Controller Class Initialized
INFO - 2018-07-27 22:22:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:22:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:22:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:22:51 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-27 22:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:22:51 --> Final output sent to browser
DEBUG - 2018-07-27 22:22:51 --> Total execution time: 0.0230
INFO - 2018-07-27 22:23:19 --> Config Class Initialized
INFO - 2018-07-27 22:23:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:23:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:23:19 --> Utf8 Class Initialized
INFO - 2018-07-27 22:23:19 --> URI Class Initialized
INFO - 2018-07-27 22:23:19 --> Router Class Initialized
INFO - 2018-07-27 22:23:19 --> Output Class Initialized
INFO - 2018-07-27 22:23:19 --> Security Class Initialized
DEBUG - 2018-07-27 22:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:23:19 --> CSRF cookie sent
INFO - 2018-07-27 22:23:19 --> CSRF token verified
INFO - 2018-07-27 22:23:19 --> Input Class Initialized
INFO - 2018-07-27 22:23:19 --> Language Class Initialized
INFO - 2018-07-27 22:23:20 --> Loader Class Initialized
INFO - 2018-07-27 22:23:20 --> Helper loaded: url_helper
INFO - 2018-07-27 22:23:20 --> Helper loaded: form_helper
INFO - 2018-07-27 22:23:20 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:23:20 --> User Agent Class Initialized
INFO - 2018-07-27 22:23:20 --> Controller Class Initialized
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:23:20 --> Form Validation Class Initialized
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-07-27 22:23:20 --> Pixel_Model class loaded
INFO - 2018-07-27 22:23:20 --> Database Driver Class Initialized
INFO - 2018-07-27 22:23:20 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 22:23:20 --> Helper loaded: string_helper
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-07-27 22:23:20 --> Email Class Initialized
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/email_lang.php
INFO - 2018-07-27 22:23:20 --> Config Class Initialized
INFO - 2018-07-27 22:23:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:23:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:23:20 --> Utf8 Class Initialized
INFO - 2018-07-27 22:23:20 --> URI Class Initialized
INFO - 2018-07-27 22:23:20 --> Router Class Initialized
INFO - 2018-07-27 22:23:20 --> Output Class Initialized
INFO - 2018-07-27 22:23:20 --> Security Class Initialized
DEBUG - 2018-07-27 22:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:23:20 --> CSRF cookie sent
INFO - 2018-07-27 22:23:20 --> Input Class Initialized
INFO - 2018-07-27 22:23:20 --> Language Class Initialized
INFO - 2018-07-27 22:23:20 --> Loader Class Initialized
INFO - 2018-07-27 22:23:20 --> Helper loaded: url_helper
INFO - 2018-07-27 22:23:20 --> Helper loaded: form_helper
INFO - 2018-07-27 22:23:20 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:23:20 --> User Agent Class Initialized
INFO - 2018-07-27 22:23:20 --> Controller Class Initialized
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:23:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:23:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-27 22:23:20 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-27 22:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:23:20 --> Final output sent to browser
DEBUG - 2018-07-27 22:23:20 --> Total execution time: 0.0210
INFO - 2018-07-27 22:24:38 --> Config Class Initialized
INFO - 2018-07-27 22:24:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:24:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:24:38 --> Utf8 Class Initialized
INFO - 2018-07-27 22:24:38 --> URI Class Initialized
INFO - 2018-07-27 22:24:38 --> Router Class Initialized
INFO - 2018-07-27 22:24:38 --> Output Class Initialized
INFO - 2018-07-27 22:24:38 --> Security Class Initialized
DEBUG - 2018-07-27 22:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:24:38 --> CSRF cookie sent
INFO - 2018-07-27 22:24:38 --> Input Class Initialized
INFO - 2018-07-27 22:24:38 --> Language Class Initialized
ERROR - 2018-07-27 22:24:38 --> 404 Page Not Found: Assets/images
INFO - 2018-07-27 22:25:14 --> Config Class Initialized
INFO - 2018-07-27 22:25:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:14 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:14 --> URI Class Initialized
INFO - 2018-07-27 22:25:14 --> Router Class Initialized
INFO - 2018-07-27 22:25:14 --> Output Class Initialized
INFO - 2018-07-27 22:25:14 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:14 --> CSRF cookie sent
INFO - 2018-07-27 22:25:14 --> CSRF token verified
INFO - 2018-07-27 22:25:14 --> Input Class Initialized
INFO - 2018-07-27 22:25:14 --> Language Class Initialized
INFO - 2018-07-27 22:25:14 --> Loader Class Initialized
INFO - 2018-07-27 22:25:14 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:14 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:14 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:14 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:14 --> Controller Class Initialized
INFO - 2018-07-27 22:25:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:25:14 --> Form Validation Class Initialized
INFO - 2018-07-27 22:25:14 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-07-27 22:25:14 --> Pixel_Model class loaded
INFO - 2018-07-27 22:25:14 --> Database Driver Class Initialized
INFO - 2018-07-27 22:25:14 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 22:25:15 --> Config Class Initialized
INFO - 2018-07-27 22:25:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:15 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:15 --> URI Class Initialized
INFO - 2018-07-27 22:25:15 --> Router Class Initialized
INFO - 2018-07-27 22:25:15 --> Output Class Initialized
INFO - 2018-07-27 22:25:15 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:15 --> CSRF cookie sent
INFO - 2018-07-27 22:25:15 --> Input Class Initialized
INFO - 2018-07-27 22:25:15 --> Language Class Initialized
INFO - 2018-07-27 22:25:15 --> Loader Class Initialized
INFO - 2018-07-27 22:25:15 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:15 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:15 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:15 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:15 --> Controller Class Initialized
INFO - 2018-07-27 22:25:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:25:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-27 22:25:15 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-27 22:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:25:15 --> Final output sent to browser
DEBUG - 2018-07-27 22:25:15 --> Total execution time: 0.0224
INFO - 2018-07-27 22:25:26 --> Config Class Initialized
INFO - 2018-07-27 22:25:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:26 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:26 --> URI Class Initialized
INFO - 2018-07-27 22:25:26 --> Router Class Initialized
INFO - 2018-07-27 22:25:26 --> Output Class Initialized
INFO - 2018-07-27 22:25:26 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:26 --> CSRF cookie sent
INFO - 2018-07-27 22:25:26 --> Input Class Initialized
INFO - 2018-07-27 22:25:26 --> Language Class Initialized
INFO - 2018-07-27 22:25:26 --> Loader Class Initialized
INFO - 2018-07-27 22:25:26 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:26 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:26 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:26 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:26 --> Controller Class Initialized
INFO - 2018-07-27 22:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:25:26 --> Pixel_Model class loaded
INFO - 2018-07-27 22:25:26 --> Database Driver Class Initialized
INFO - 2018-07-27 22:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:25:26 --> Config Class Initialized
INFO - 2018-07-27 22:25:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:26 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:26 --> URI Class Initialized
INFO - 2018-07-27 22:25:26 --> Router Class Initialized
INFO - 2018-07-27 22:25:26 --> Output Class Initialized
INFO - 2018-07-27 22:25:26 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:26 --> CSRF cookie sent
INFO - 2018-07-27 22:25:26 --> Input Class Initialized
INFO - 2018-07-27 22:25:26 --> Language Class Initialized
INFO - 2018-07-27 22:25:26 --> Loader Class Initialized
INFO - 2018-07-27 22:25:26 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:26 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:26 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:26 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:26 --> Controller Class Initialized
INFO - 2018-07-27 22:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:25:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:25:26 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:25:26 --> Final output sent to browser
DEBUG - 2018-07-27 22:25:26 --> Total execution time: 0.0279
INFO - 2018-07-27 22:25:51 --> Config Class Initialized
INFO - 2018-07-27 22:25:51 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:51 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:51 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:51 --> URI Class Initialized
INFO - 2018-07-27 22:25:51 --> Router Class Initialized
INFO - 2018-07-27 22:25:51 --> Output Class Initialized
INFO - 2018-07-27 22:25:51 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:51 --> CSRF cookie sent
INFO - 2018-07-27 22:25:51 --> CSRF token verified
INFO - 2018-07-27 22:25:51 --> Input Class Initialized
INFO - 2018-07-27 22:25:51 --> Language Class Initialized
INFO - 2018-07-27 22:25:51 --> Loader Class Initialized
INFO - 2018-07-27 22:25:51 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:51 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:51 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:51 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:51 --> Controller Class Initialized
INFO - 2018-07-27 22:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:25:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:25:51 --> Form Validation Class Initialized
INFO - 2018-07-27 22:25:51 --> Pixel_Model class loaded
INFO - 2018-07-27 22:25:51 --> Database Driver Class Initialized
INFO - 2018-07-27 22:25:51 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 22:25:51 --> Config Class Initialized
INFO - 2018-07-27 22:25:51 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:25:51 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:25:51 --> Utf8 Class Initialized
INFO - 2018-07-27 22:25:51 --> URI Class Initialized
INFO - 2018-07-27 22:25:51 --> Router Class Initialized
INFO - 2018-07-27 22:25:51 --> Output Class Initialized
INFO - 2018-07-27 22:25:51 --> Security Class Initialized
DEBUG - 2018-07-27 22:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:25:51 --> CSRF cookie sent
INFO - 2018-07-27 22:25:51 --> Input Class Initialized
INFO - 2018-07-27 22:25:51 --> Language Class Initialized
INFO - 2018-07-27 22:25:51 --> Loader Class Initialized
INFO - 2018-07-27 22:25:51 --> Helper loaded: url_helper
INFO - 2018-07-27 22:25:51 --> Helper loaded: form_helper
INFO - 2018-07-27 22:25:51 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:25:51 --> User Agent Class Initialized
INFO - 2018-07-27 22:25:51 --> Controller Class Initialized
INFO - 2018-07-27 22:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:25:51 --> Pixel_Model class loaded
INFO - 2018-07-27 22:25:51 --> Database Driver Class Initialized
INFO - 2018-07-27 22:25:51 --> Model "MyAccountModel" initialized
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-07-27 22:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:25:51 --> Final output sent to browser
DEBUG - 2018-07-27 22:25:51 --> Total execution time: 0.0338
INFO - 2018-07-27 22:26:00 --> Config Class Initialized
INFO - 2018-07-27 22:26:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:00 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:00 --> URI Class Initialized
INFO - 2018-07-27 22:26:00 --> Router Class Initialized
INFO - 2018-07-27 22:26:00 --> Output Class Initialized
INFO - 2018-07-27 22:26:00 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:00 --> CSRF cookie sent
INFO - 2018-07-27 22:26:00 --> Input Class Initialized
INFO - 2018-07-27 22:26:00 --> Language Class Initialized
INFO - 2018-07-27 22:26:00 --> Loader Class Initialized
INFO - 2018-07-27 22:26:00 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:00 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:00 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:00 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:00 --> Controller Class Initialized
INFO - 2018-07-27 22:26:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:00 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:00 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-27 22:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:26:00 --> Final output sent to browser
DEBUG - 2018-07-27 22:26:00 --> Total execution time: 0.0373
INFO - 2018-07-27 22:26:17 --> Config Class Initialized
INFO - 2018-07-27 22:26:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:17 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:17 --> URI Class Initialized
INFO - 2018-07-27 22:26:17 --> Router Class Initialized
INFO - 2018-07-27 22:26:17 --> Output Class Initialized
INFO - 2018-07-27 22:26:17 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:17 --> CSRF cookie sent
INFO - 2018-07-27 22:26:17 --> CSRF token verified
INFO - 2018-07-27 22:26:17 --> Input Class Initialized
INFO - 2018-07-27 22:26:17 --> Language Class Initialized
INFO - 2018-07-27 22:26:17 --> Loader Class Initialized
INFO - 2018-07-27 22:26:17 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:17 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:17 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:17 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:17 --> Controller Class Initialized
INFO - 2018-07-27 22:26:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:17 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:17 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:17 --> Form Validation Class Initialized
INFO - 2018-07-27 22:26:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 22:26:17 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:17 --> Config Class Initialized
INFO - 2018-07-27 22:26:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:17 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:17 --> URI Class Initialized
INFO - 2018-07-27 22:26:17 --> Router Class Initialized
INFO - 2018-07-27 22:26:17 --> Output Class Initialized
INFO - 2018-07-27 22:26:17 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:17 --> CSRF cookie sent
INFO - 2018-07-27 22:26:17 --> Input Class Initialized
INFO - 2018-07-27 22:26:17 --> Language Class Initialized
INFO - 2018-07-27 22:26:17 --> Loader Class Initialized
INFO - 2018-07-27 22:26:17 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:18 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:18 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:18 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:18 --> Controller Class Initialized
INFO - 2018-07-27 22:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:18 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:18 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:18 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-27 22:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:26:18 --> Final output sent to browser
DEBUG - 2018-07-27 22:26:18 --> Total execution time: 0.0453
INFO - 2018-07-27 22:26:33 --> Config Class Initialized
INFO - 2018-07-27 22:26:33 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:33 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:33 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:33 --> URI Class Initialized
INFO - 2018-07-27 22:26:33 --> Router Class Initialized
INFO - 2018-07-27 22:26:33 --> Output Class Initialized
INFO - 2018-07-27 22:26:33 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:33 --> CSRF cookie sent
INFO - 2018-07-27 22:26:33 --> CSRF token verified
INFO - 2018-07-27 22:26:33 --> Input Class Initialized
INFO - 2018-07-27 22:26:33 --> Language Class Initialized
INFO - 2018-07-27 22:26:33 --> Loader Class Initialized
INFO - 2018-07-27 22:26:33 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:33 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:33 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:33 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:33 --> Controller Class Initialized
INFO - 2018-07-27 22:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:33 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:33 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:33 --> Form Validation Class Initialized
INFO - 2018-07-27 22:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 22:26:33 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:33 --> Config Class Initialized
INFO - 2018-07-27 22:26:33 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:33 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:33 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:33 --> URI Class Initialized
INFO - 2018-07-27 22:26:33 --> Router Class Initialized
INFO - 2018-07-27 22:26:33 --> Output Class Initialized
INFO - 2018-07-27 22:26:33 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:33 --> CSRF cookie sent
INFO - 2018-07-27 22:26:33 --> Input Class Initialized
INFO - 2018-07-27 22:26:33 --> Language Class Initialized
INFO - 2018-07-27 22:26:33 --> Loader Class Initialized
INFO - 2018-07-27 22:26:33 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:33 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:33 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:33 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:33 --> Controller Class Initialized
INFO - 2018-07-27 22:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:33 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:33 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:33 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-27 22:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:26:33 --> Final output sent to browser
DEBUG - 2018-07-27 22:26:33 --> Total execution time: 0.0480
INFO - 2018-07-27 22:26:56 --> Config Class Initialized
INFO - 2018-07-27 22:26:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:56 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:56 --> URI Class Initialized
INFO - 2018-07-27 22:26:56 --> Router Class Initialized
INFO - 2018-07-27 22:26:56 --> Output Class Initialized
INFO - 2018-07-27 22:26:56 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:56 --> CSRF cookie sent
INFO - 2018-07-27 22:26:56 --> CSRF token verified
INFO - 2018-07-27 22:26:56 --> Input Class Initialized
INFO - 2018-07-27 22:26:56 --> Language Class Initialized
INFO - 2018-07-27 22:26:56 --> Loader Class Initialized
INFO - 2018-07-27 22:26:56 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:56 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:56 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:56 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:56 --> Controller Class Initialized
INFO - 2018-07-27 22:26:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:56 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:56 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:56 --> Form Validation Class Initialized
INFO - 2018-07-27 22:26:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 22:26:56 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:56 --> Config Class Initialized
INFO - 2018-07-27 22:26:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:26:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:26:56 --> Utf8 Class Initialized
INFO - 2018-07-27 22:26:56 --> URI Class Initialized
INFO - 2018-07-27 22:26:56 --> Router Class Initialized
INFO - 2018-07-27 22:26:56 --> Output Class Initialized
INFO - 2018-07-27 22:26:56 --> Security Class Initialized
DEBUG - 2018-07-27 22:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:26:56 --> CSRF cookie sent
INFO - 2018-07-27 22:26:56 --> Input Class Initialized
INFO - 2018-07-27 22:26:56 --> Language Class Initialized
INFO - 2018-07-27 22:26:56 --> Loader Class Initialized
INFO - 2018-07-27 22:26:56 --> Helper loaded: url_helper
INFO - 2018-07-27 22:26:56 --> Helper loaded: form_helper
INFO - 2018-07-27 22:26:56 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:26:56 --> User Agent Class Initialized
INFO - 2018-07-27 22:26:56 --> Controller Class Initialized
INFO - 2018-07-27 22:26:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:26:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:26:56 --> Pixel_Model class loaded
INFO - 2018-07-27 22:26:56 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:56 --> Database Driver Class Initialized
INFO - 2018-07-27 22:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-27 22:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:26:56 --> Final output sent to browser
DEBUG - 2018-07-27 22:26:56 --> Total execution time: 0.0314
INFO - 2018-07-27 22:27:30 --> Config Class Initialized
INFO - 2018-07-27 22:27:30 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:27:30 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:27:30 --> Utf8 Class Initialized
INFO - 2018-07-27 22:27:30 --> URI Class Initialized
INFO - 2018-07-27 22:27:30 --> Router Class Initialized
INFO - 2018-07-27 22:27:30 --> Output Class Initialized
INFO - 2018-07-27 22:27:30 --> Security Class Initialized
DEBUG - 2018-07-27 22:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:27:30 --> CSRF cookie sent
INFO - 2018-07-27 22:27:30 --> CSRF token verified
INFO - 2018-07-27 22:27:30 --> Input Class Initialized
INFO - 2018-07-27 22:27:30 --> Language Class Initialized
INFO - 2018-07-27 22:27:30 --> Loader Class Initialized
INFO - 2018-07-27 22:27:30 --> Helper loaded: url_helper
INFO - 2018-07-27 22:27:30 --> Helper loaded: form_helper
INFO - 2018-07-27 22:27:30 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:27:30 --> User Agent Class Initialized
INFO - 2018-07-27 22:27:30 --> Controller Class Initialized
INFO - 2018-07-27 22:27:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:27:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:27:30 --> Pixel_Model class loaded
INFO - 2018-07-27 22:27:30 --> Database Driver Class Initialized
INFO - 2018-07-27 22:27:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:27:30 --> Form Validation Class Initialized
INFO - 2018-07-27 22:27:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 22:27:30 --> Database Driver Class Initialized
INFO - 2018-07-27 22:27:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:27:30 --> Config Class Initialized
INFO - 2018-07-27 22:27:30 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:27:30 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:27:30 --> Utf8 Class Initialized
INFO - 2018-07-27 22:27:30 --> URI Class Initialized
INFO - 2018-07-27 22:27:30 --> Router Class Initialized
INFO - 2018-07-27 22:27:30 --> Output Class Initialized
INFO - 2018-07-27 22:27:30 --> Security Class Initialized
DEBUG - 2018-07-27 22:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:27:30 --> CSRF cookie sent
INFO - 2018-07-27 22:27:30 --> Input Class Initialized
INFO - 2018-07-27 22:27:30 --> Language Class Initialized
INFO - 2018-07-27 22:27:30 --> Loader Class Initialized
INFO - 2018-07-27 22:27:30 --> Helper loaded: url_helper
INFO - 2018-07-27 22:27:30 --> Helper loaded: form_helper
INFO - 2018-07-27 22:27:30 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:27:30 --> User Agent Class Initialized
INFO - 2018-07-27 22:27:30 --> Controller Class Initialized
INFO - 2018-07-27 22:27:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:27:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:27:30 --> Pixel_Model class loaded
INFO - 2018-07-27 22:27:30 --> Database Driver Class Initialized
INFO - 2018-07-27 22:27:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:27:30 --> Database Driver Class Initialized
INFO - 2018-07-27 22:27:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-27 22:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:27:30 --> Final output sent to browser
DEBUG - 2018-07-27 22:27:30 --> Total execution time: 0.0332
INFO - 2018-07-27 22:28:24 --> Config Class Initialized
INFO - 2018-07-27 22:28:24 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:28:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:28:24 --> Utf8 Class Initialized
INFO - 2018-07-27 22:28:24 --> URI Class Initialized
INFO - 2018-07-27 22:28:24 --> Router Class Initialized
INFO - 2018-07-27 22:28:24 --> Output Class Initialized
INFO - 2018-07-27 22:28:24 --> Security Class Initialized
DEBUG - 2018-07-27 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:28:24 --> CSRF cookie sent
INFO - 2018-07-27 22:28:24 --> Input Class Initialized
INFO - 2018-07-27 22:28:24 --> Language Class Initialized
INFO - 2018-07-27 22:28:24 --> Loader Class Initialized
INFO - 2018-07-27 22:28:24 --> Helper loaded: url_helper
INFO - 2018-07-27 22:28:24 --> Helper loaded: form_helper
INFO - 2018-07-27 22:28:24 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:28:24 --> User Agent Class Initialized
INFO - 2018-07-27 22:28:24 --> Controller Class Initialized
INFO - 2018-07-27 22:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:28:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:28:24 --> Pixel_Model class loaded
INFO - 2018-07-27 22:28:24 --> Database Driver Class Initialized
INFO - 2018-07-27 22:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:28:24 --> Database Driver Class Initialized
INFO - 2018-07-27 22:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-27 22:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:28:24 --> Final output sent to browser
DEBUG - 2018-07-27 22:28:24 --> Total execution time: 0.0444
INFO - 2018-07-27 22:30:49 --> Config Class Initialized
INFO - 2018-07-27 22:30:49 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:30:49 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:30:49 --> Utf8 Class Initialized
INFO - 2018-07-27 22:30:49 --> URI Class Initialized
INFO - 2018-07-27 22:30:49 --> Router Class Initialized
INFO - 2018-07-27 22:30:49 --> Output Class Initialized
INFO - 2018-07-27 22:30:49 --> Security Class Initialized
DEBUG - 2018-07-27 22:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:30:49 --> CSRF cookie sent
INFO - 2018-07-27 22:30:49 --> Input Class Initialized
INFO - 2018-07-27 22:30:49 --> Language Class Initialized
INFO - 2018-07-27 22:30:49 --> Loader Class Initialized
INFO - 2018-07-27 22:30:49 --> Helper loaded: url_helper
INFO - 2018-07-27 22:30:49 --> Helper loaded: form_helper
INFO - 2018-07-27 22:30:49 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:30:49 --> User Agent Class Initialized
INFO - 2018-07-27 22:30:49 --> Controller Class Initialized
INFO - 2018-07-27 22:30:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:30:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_password.php
INFO - 2018-07-27 22:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:30:49 --> Final output sent to browser
DEBUG - 2018-07-27 22:30:49 --> Total execution time: 0.0493
INFO - 2018-07-27 22:31:54 --> Config Class Initialized
INFO - 2018-07-27 22:31:54 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:31:54 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:31:54 --> Utf8 Class Initialized
INFO - 2018-07-27 22:31:54 --> URI Class Initialized
INFO - 2018-07-27 22:31:54 --> Router Class Initialized
INFO - 2018-07-27 22:31:54 --> Output Class Initialized
INFO - 2018-07-27 22:31:54 --> Security Class Initialized
DEBUG - 2018-07-27 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:31:54 --> CSRF cookie sent
INFO - 2018-07-27 22:31:54 --> CSRF token verified
INFO - 2018-07-27 22:31:54 --> Input Class Initialized
INFO - 2018-07-27 22:31:54 --> Language Class Initialized
INFO - 2018-07-27 22:31:54 --> Loader Class Initialized
INFO - 2018-07-27 22:31:54 --> Helper loaded: url_helper
INFO - 2018-07-27 22:31:54 --> Helper loaded: form_helper
INFO - 2018-07-27 22:31:54 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:31:54 --> User Agent Class Initialized
INFO - 2018-07-27 22:31:54 --> Controller Class Initialized
INFO - 2018-07-27 22:31:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:31:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:31:54 --> Form Validation Class Initialized
INFO - 2018-07-27 22:31:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-27 22:31:54 --> Pixel_Model class loaded
INFO - 2018-07-27 22:31:54 --> Database Driver Class Initialized
INFO - 2018-07-27 22:31:54 --> Model "AuthenticationModel" initialized
INFO - 2018-07-27 22:31:55 --> Config Class Initialized
INFO - 2018-07-27 22:31:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:31:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:31:55 --> Utf8 Class Initialized
INFO - 2018-07-27 22:31:55 --> URI Class Initialized
INFO - 2018-07-27 22:31:55 --> Router Class Initialized
INFO - 2018-07-27 22:31:55 --> Output Class Initialized
INFO - 2018-07-27 22:31:55 --> Security Class Initialized
DEBUG - 2018-07-27 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:31:55 --> CSRF cookie sent
INFO - 2018-07-27 22:31:55 --> Input Class Initialized
INFO - 2018-07-27 22:31:55 --> Language Class Initialized
INFO - 2018-07-27 22:31:55 --> Loader Class Initialized
INFO - 2018-07-27 22:31:55 --> Helper loaded: url_helper
INFO - 2018-07-27 22:31:55 --> Helper loaded: form_helper
INFO - 2018-07-27 22:31:55 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:31:55 --> User Agent Class Initialized
INFO - 2018-07-27 22:31:55 --> Controller Class Initialized
INFO - 2018-07-27 22:31:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:31:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_password.php
INFO - 2018-07-27 22:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:31:55 --> Final output sent to browser
DEBUG - 2018-07-27 22:31:55 --> Total execution time: 0.0240
INFO - 2018-07-27 22:42:05 --> Config Class Initialized
INFO - 2018-07-27 22:42:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:05 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:05 --> URI Class Initialized
DEBUG - 2018-07-27 22:42:05 --> No URI present. Default controller set.
INFO - 2018-07-27 22:42:05 --> Router Class Initialized
INFO - 2018-07-27 22:42:05 --> Output Class Initialized
INFO - 2018-07-27 22:42:05 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:05 --> CSRF cookie sent
INFO - 2018-07-27 22:42:05 --> Input Class Initialized
INFO - 2018-07-27 22:42:05 --> Language Class Initialized
INFO - 2018-07-27 22:42:05 --> Loader Class Initialized
INFO - 2018-07-27 22:42:05 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:05 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:05 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:05 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:05 --> Controller Class Initialized
INFO - 2018-07-27 22:42:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:05 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:05 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:42:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:05 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:05 --> Total execution time: 0.0324
INFO - 2018-07-27 22:42:06 --> Config Class Initialized
INFO - 2018-07-27 22:42:06 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:06 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:06 --> URI Class Initialized
DEBUG - 2018-07-27 22:42:06 --> No URI present. Default controller set.
INFO - 2018-07-27 22:42:06 --> Router Class Initialized
INFO - 2018-07-27 22:42:06 --> Output Class Initialized
INFO - 2018-07-27 22:42:06 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:06 --> CSRF cookie sent
INFO - 2018-07-27 22:42:06 --> Input Class Initialized
INFO - 2018-07-27 22:42:06 --> Language Class Initialized
INFO - 2018-07-27 22:42:06 --> Loader Class Initialized
INFO - 2018-07-27 22:42:06 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:06 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:06 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:06 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:06 --> Controller Class Initialized
INFO - 2018-07-27 22:42:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:06 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:06 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:06 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:06 --> Total execution time: 0.0324
INFO - 2018-07-27 22:42:06 --> Config Class Initialized
INFO - 2018-07-27 22:42:06 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:06 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:06 --> URI Class Initialized
DEBUG - 2018-07-27 22:42:06 --> No URI present. Default controller set.
INFO - 2018-07-27 22:42:06 --> Router Class Initialized
INFO - 2018-07-27 22:42:06 --> Output Class Initialized
INFO - 2018-07-27 22:42:06 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:06 --> CSRF cookie sent
INFO - 2018-07-27 22:42:06 --> Input Class Initialized
INFO - 2018-07-27 22:42:06 --> Language Class Initialized
INFO - 2018-07-27 22:42:06 --> Loader Class Initialized
INFO - 2018-07-27 22:42:06 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:06 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:06 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:06 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:06 --> Controller Class Initialized
INFO - 2018-07-27 22:42:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:06 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:06 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:06 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:06 --> Total execution time: 0.0368
INFO - 2018-07-27 22:42:07 --> Config Class Initialized
INFO - 2018-07-27 22:42:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:07 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:07 --> URI Class Initialized
INFO - 2018-07-27 22:42:07 --> Router Class Initialized
INFO - 2018-07-27 22:42:07 --> Output Class Initialized
INFO - 2018-07-27 22:42:07 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:07 --> CSRF cookie sent
INFO - 2018-07-27 22:42:07 --> Input Class Initialized
INFO - 2018-07-27 22:42:07 --> Language Class Initialized
ERROR - 2018-07-27 22:42:07 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-27 22:42:14 --> Config Class Initialized
INFO - 2018-07-27 22:42:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:14 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:14 --> URI Class Initialized
DEBUG - 2018-07-27 22:42:14 --> No URI present. Default controller set.
INFO - 2018-07-27 22:42:14 --> Router Class Initialized
INFO - 2018-07-27 22:42:14 --> Output Class Initialized
INFO - 2018-07-27 22:42:14 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:14 --> CSRF cookie sent
INFO - 2018-07-27 22:42:14 --> Input Class Initialized
INFO - 2018-07-27 22:42:14 --> Language Class Initialized
INFO - 2018-07-27 22:42:14 --> Loader Class Initialized
INFO - 2018-07-27 22:42:14 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:14 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:14 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:14 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:14 --> Controller Class Initialized
INFO - 2018-07-27 22:42:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:14 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:14 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:14 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:14 --> Total execution time: 0.0343
INFO - 2018-07-27 22:42:14 --> Config Class Initialized
INFO - 2018-07-27 22:42:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:14 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:14 --> URI Class Initialized
INFO - 2018-07-27 22:42:14 --> Router Class Initialized
INFO - 2018-07-27 22:42:14 --> Output Class Initialized
INFO - 2018-07-27 22:42:14 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:14 --> CSRF cookie sent
INFO - 2018-07-27 22:42:14 --> Input Class Initialized
INFO - 2018-07-27 22:42:14 --> Language Class Initialized
ERROR - 2018-07-27 22:42:14 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-27 22:42:14 --> Config Class Initialized
INFO - 2018-07-27 22:42:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:14 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:14 --> URI Class Initialized
INFO - 2018-07-27 22:42:14 --> Router Class Initialized
INFO - 2018-07-27 22:42:14 --> Output Class Initialized
INFO - 2018-07-27 22:42:14 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:14 --> CSRF cookie sent
INFO - 2018-07-27 22:42:14 --> Input Class Initialized
INFO - 2018-07-27 22:42:14 --> Language Class Initialized
ERROR - 2018-07-27 22:42:14 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-27 22:42:15 --> Config Class Initialized
INFO - 2018-07-27 22:42:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:15 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:15 --> URI Class Initialized
INFO - 2018-07-27 22:42:15 --> Router Class Initialized
INFO - 2018-07-27 22:42:15 --> Output Class Initialized
INFO - 2018-07-27 22:42:15 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:15 --> CSRF cookie sent
INFO - 2018-07-27 22:42:15 --> Input Class Initialized
INFO - 2018-07-27 22:42:15 --> Language Class Initialized
INFO - 2018-07-27 22:42:15 --> Loader Class Initialized
INFO - 2018-07-27 22:42:15 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:15 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:15 --> Controller Class Initialized
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:15 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:15 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:15 --> Config Class Initialized
INFO - 2018-07-27 22:42:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:15 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:15 --> URI Class Initialized
INFO - 2018-07-27 22:42:15 --> Router Class Initialized
INFO - 2018-07-27 22:42:15 --> Output Class Initialized
INFO - 2018-07-27 22:42:15 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:15 --> CSRF cookie sent
INFO - 2018-07-27 22:42:15 --> Input Class Initialized
INFO - 2018-07-27 22:42:15 --> Language Class Initialized
INFO - 2018-07-27 22:42:15 --> Loader Class Initialized
INFO - 2018-07-27 22:42:15 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:15 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:15 --> Controller Class Initialized
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:42:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:42:15 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:15 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:15 --> Total execution time: 0.0221
INFO - 2018-07-27 22:42:15 --> Config Class Initialized
INFO - 2018-07-27 22:42:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:15 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:15 --> URI Class Initialized
INFO - 2018-07-27 22:42:15 --> Router Class Initialized
INFO - 2018-07-27 22:42:15 --> Output Class Initialized
INFO - 2018-07-27 22:42:15 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:15 --> CSRF cookie sent
INFO - 2018-07-27 22:42:15 --> Input Class Initialized
INFO - 2018-07-27 22:42:15 --> Language Class Initialized
INFO - 2018-07-27 22:42:15 --> Loader Class Initialized
INFO - 2018-07-27 22:42:15 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:15 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:15 --> Controller Class Initialized
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:15 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:15 --> Total execution time: 0.0303
INFO - 2018-07-27 22:42:15 --> Config Class Initialized
INFO - 2018-07-27 22:42:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:15 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:15 --> URI Class Initialized
INFO - 2018-07-27 22:42:15 --> Router Class Initialized
INFO - 2018-07-27 22:42:15 --> Output Class Initialized
INFO - 2018-07-27 22:42:15 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:15 --> CSRF cookie sent
INFO - 2018-07-27 22:42:15 --> Input Class Initialized
INFO - 2018-07-27 22:42:15 --> Language Class Initialized
INFO - 2018-07-27 22:42:15 --> Loader Class Initialized
INFO - 2018-07-27 22:42:15 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:15 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:15 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:15 --> Controller Class Initialized
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-27 22:42:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:15 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:15 --> Total execution time: 0.0240
INFO - 2018-07-27 22:42:16 --> Config Class Initialized
INFO - 2018-07-27 22:42:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:16 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:16 --> URI Class Initialized
INFO - 2018-07-27 22:42:16 --> Router Class Initialized
INFO - 2018-07-27 22:42:16 --> Output Class Initialized
INFO - 2018-07-27 22:42:16 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:16 --> CSRF cookie sent
INFO - 2018-07-27 22:42:16 --> Input Class Initialized
INFO - 2018-07-27 22:42:16 --> Language Class Initialized
INFO - 2018-07-27 22:42:16 --> Loader Class Initialized
INFO - 2018-07-27 22:42:16 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:16 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:16 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:16 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:16 --> Controller Class Initialized
INFO - 2018-07-27 22:42:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:16 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:16 --> Total execution time: 0.0257
INFO - 2018-07-27 22:42:16 --> Config Class Initialized
INFO - 2018-07-27 22:42:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:16 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:16 --> URI Class Initialized
INFO - 2018-07-27 22:42:16 --> Router Class Initialized
INFO - 2018-07-27 22:42:16 --> Output Class Initialized
INFO - 2018-07-27 22:42:16 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:16 --> CSRF cookie sent
INFO - 2018-07-27 22:42:16 --> Input Class Initialized
INFO - 2018-07-27 22:42:16 --> Language Class Initialized
INFO - 2018-07-27 22:42:16 --> Loader Class Initialized
INFO - 2018-07-27 22:42:16 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:16 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:16 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:16 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:16 --> Controller Class Initialized
INFO - 2018-07-27 22:42:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-27 22:42:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:16 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:16 --> Total execution time: 0.0296
INFO - 2018-07-27 22:42:17 --> Config Class Initialized
INFO - 2018-07-27 22:42:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:17 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:17 --> URI Class Initialized
INFO - 2018-07-27 22:42:17 --> Router Class Initialized
INFO - 2018-07-27 22:42:17 --> Output Class Initialized
INFO - 2018-07-27 22:42:17 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:17 --> CSRF cookie sent
INFO - 2018-07-27 22:42:17 --> Input Class Initialized
INFO - 2018-07-27 22:42:17 --> Language Class Initialized
INFO - 2018-07-27 22:42:17 --> Loader Class Initialized
INFO - 2018-07-27 22:42:17 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:17 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:17 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:17 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:17 --> Controller Class Initialized
INFO - 2018-07-27 22:42:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-27 22:42:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-27 22:42:17 --> Could not find the language line "req_email"
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:17 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:17 --> Total execution time: 0.0228
INFO - 2018-07-27 22:42:17 --> Config Class Initialized
INFO - 2018-07-27 22:42:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:42:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:42:17 --> Utf8 Class Initialized
INFO - 2018-07-27 22:42:17 --> URI Class Initialized
INFO - 2018-07-27 22:42:17 --> Router Class Initialized
INFO - 2018-07-27 22:42:17 --> Output Class Initialized
INFO - 2018-07-27 22:42:17 --> Security Class Initialized
DEBUG - 2018-07-27 22:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:42:17 --> CSRF cookie sent
INFO - 2018-07-27 22:42:17 --> Input Class Initialized
INFO - 2018-07-27 22:42:17 --> Language Class Initialized
INFO - 2018-07-27 22:42:17 --> Loader Class Initialized
INFO - 2018-07-27 22:42:17 --> Helper loaded: url_helper
INFO - 2018-07-27 22:42:17 --> Helper loaded: form_helper
INFO - 2018-07-27 22:42:17 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:42:17 --> User Agent Class Initialized
INFO - 2018-07-27 22:42:17 --> Controller Class Initialized
INFO - 2018-07-27 22:42:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:42:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:42:17 --> Pixel_Model class loaded
INFO - 2018-07-27 22:42:17 --> Database Driver Class Initialized
INFO - 2018-07-27 22:42:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-27 22:42:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:42:17 --> Final output sent to browser
DEBUG - 2018-07-27 22:42:17 --> Total execution time: 0.0321
INFO - 2018-07-27 22:51:11 --> Config Class Initialized
INFO - 2018-07-27 22:51:11 --> Hooks Class Initialized
DEBUG - 2018-07-27 22:51:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 22:51:11 --> Utf8 Class Initialized
INFO - 2018-07-27 22:51:11 --> URI Class Initialized
DEBUG - 2018-07-27 22:51:11 --> No URI present. Default controller set.
INFO - 2018-07-27 22:51:11 --> Router Class Initialized
INFO - 2018-07-27 22:51:11 --> Output Class Initialized
INFO - 2018-07-27 22:51:11 --> Security Class Initialized
DEBUG - 2018-07-27 22:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 22:51:11 --> CSRF cookie sent
INFO - 2018-07-27 22:51:11 --> Input Class Initialized
INFO - 2018-07-27 22:51:11 --> Language Class Initialized
INFO - 2018-07-27 22:51:11 --> Loader Class Initialized
INFO - 2018-07-27 22:51:11 --> Helper loaded: url_helper
INFO - 2018-07-27 22:51:11 --> Helper loaded: form_helper
INFO - 2018-07-27 22:51:11 --> Helper loaded: language_helper
DEBUG - 2018-07-27 22:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 22:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 22:51:11 --> User Agent Class Initialized
INFO - 2018-07-27 22:51:11 --> Controller Class Initialized
INFO - 2018-07-27 22:51:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-27 22:51:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-27 22:51:11 --> Pixel_Model class loaded
INFO - 2018-07-27 22:51:11 --> Database Driver Class Initialized
INFO - 2018-07-27 22:51:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-27 22:51:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-27 22:51:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-27 22:51:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-27 22:51:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-27 22:51:11 --> Final output sent to browser
DEBUG - 2018-07-27 22:51:11 --> Total execution time: 0.0328

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-29 01:51:33 --> Config Class Initialized
INFO - 2018-07-29 01:51:33 --> Hooks Class Initialized
DEBUG - 2018-07-29 01:51:33 --> UTF-8 Support Enabled
INFO - 2018-07-29 01:51:33 --> Utf8 Class Initialized
INFO - 2018-07-29 01:51:33 --> URI Class Initialized
DEBUG - 2018-07-29 01:51:33 --> No URI present. Default controller set.
INFO - 2018-07-29 01:51:33 --> Router Class Initialized
INFO - 2018-07-29 01:51:33 --> Output Class Initialized
INFO - 2018-07-29 01:51:33 --> Security Class Initialized
DEBUG - 2018-07-29 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 01:51:33 --> CSRF cookie sent
INFO - 2018-07-29 01:51:33 --> Input Class Initialized
INFO - 2018-07-29 01:51:33 --> Language Class Initialized
INFO - 2018-07-29 01:51:33 --> Loader Class Initialized
INFO - 2018-07-29 01:51:33 --> Helper loaded: url_helper
INFO - 2018-07-29 01:51:33 --> Helper loaded: form_helper
INFO - 2018-07-29 01:51:33 --> Helper loaded: language_helper
DEBUG - 2018-07-29 01:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 01:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 01:51:33 --> User Agent Class Initialized
INFO - 2018-07-29 01:51:33 --> Controller Class Initialized
INFO - 2018-07-29 01:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 01:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 01:51:33 --> Pixel_Model class loaded
INFO - 2018-07-29 01:51:33 --> Database Driver Class Initialized
INFO - 2018-07-29 01:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 01:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 01:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 01:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 01:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 01:51:33 --> Final output sent to browser
DEBUG - 2018-07-29 01:51:33 --> Total execution time: 0.0377
INFO - 2018-07-29 02:29:21 --> Config Class Initialized
INFO - 2018-07-29 02:29:21 --> Hooks Class Initialized
DEBUG - 2018-07-29 02:29:21 --> UTF-8 Support Enabled
INFO - 2018-07-29 02:29:21 --> Utf8 Class Initialized
INFO - 2018-07-29 02:29:21 --> URI Class Initialized
INFO - 2018-07-29 02:29:21 --> Router Class Initialized
INFO - 2018-07-29 02:29:21 --> Output Class Initialized
INFO - 2018-07-29 02:29:21 --> Security Class Initialized
DEBUG - 2018-07-29 02:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 02:29:21 --> CSRF cookie sent
INFO - 2018-07-29 02:29:21 --> Input Class Initialized
INFO - 2018-07-29 02:29:21 --> Language Class Initialized
ERROR - 2018-07-29 02:29:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-29 02:29:25 --> Config Class Initialized
INFO - 2018-07-29 02:29:25 --> Hooks Class Initialized
DEBUG - 2018-07-29 02:29:25 --> UTF-8 Support Enabled
INFO - 2018-07-29 02:29:25 --> Utf8 Class Initialized
INFO - 2018-07-29 02:29:25 --> URI Class Initialized
INFO - 2018-07-29 02:29:25 --> Router Class Initialized
INFO - 2018-07-29 02:29:25 --> Output Class Initialized
INFO - 2018-07-29 02:29:25 --> Security Class Initialized
DEBUG - 2018-07-29 02:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 02:29:25 --> CSRF cookie sent
INFO - 2018-07-29 02:29:25 --> Input Class Initialized
INFO - 2018-07-29 02:29:25 --> Language Class Initialized
INFO - 2018-07-29 02:29:25 --> Loader Class Initialized
INFO - 2018-07-29 02:29:25 --> Helper loaded: url_helper
INFO - 2018-07-29 02:29:25 --> Helper loaded: form_helper
INFO - 2018-07-29 02:29:25 --> Helper loaded: language_helper
DEBUG - 2018-07-29 02:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 02:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 02:29:25 --> User Agent Class Initialized
INFO - 2018-07-29 02:29:25 --> Controller Class Initialized
INFO - 2018-07-29 02:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 02:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-29 02:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 02:29:25 --> Final output sent to browser
DEBUG - 2018-07-29 02:29:25 --> Total execution time: 0.0236
INFO - 2018-07-29 02:58:09 --> Config Class Initialized
INFO - 2018-07-29 02:58:09 --> Hooks Class Initialized
DEBUG - 2018-07-29 02:58:09 --> UTF-8 Support Enabled
INFO - 2018-07-29 02:58:09 --> Utf8 Class Initialized
INFO - 2018-07-29 02:58:09 --> URI Class Initialized
INFO - 2018-07-29 02:58:09 --> Router Class Initialized
INFO - 2018-07-29 02:58:09 --> Output Class Initialized
INFO - 2018-07-29 02:58:09 --> Security Class Initialized
DEBUG - 2018-07-29 02:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 02:58:09 --> CSRF cookie sent
INFO - 2018-07-29 02:58:09 --> Input Class Initialized
INFO - 2018-07-29 02:58:09 --> Language Class Initialized
ERROR - 2018-07-29 02:58:09 --> 404 Page Not Found: Wp-includes/js
INFO - 2018-07-29 08:07:49 --> Config Class Initialized
INFO - 2018-07-29 08:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-29 08:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-29 08:07:49 --> Utf8 Class Initialized
INFO - 2018-07-29 08:07:49 --> URI Class Initialized
INFO - 2018-07-29 08:07:49 --> Router Class Initialized
INFO - 2018-07-29 08:07:49 --> Output Class Initialized
INFO - 2018-07-29 08:07:49 --> Security Class Initialized
DEBUG - 2018-07-29 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 08:07:49 --> CSRF cookie sent
INFO - 2018-07-29 08:07:49 --> Input Class Initialized
INFO - 2018-07-29 08:07:49 --> Language Class Initialized
ERROR - 2018-07-29 08:07:49 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-29 09:50:18 --> Config Class Initialized
INFO - 2018-07-29 09:50:18 --> Hooks Class Initialized
DEBUG - 2018-07-29 09:50:18 --> UTF-8 Support Enabled
INFO - 2018-07-29 09:50:18 --> Utf8 Class Initialized
INFO - 2018-07-29 09:50:18 --> URI Class Initialized
DEBUG - 2018-07-29 09:50:18 --> No URI present. Default controller set.
INFO - 2018-07-29 09:50:18 --> Router Class Initialized
INFO - 2018-07-29 09:50:18 --> Output Class Initialized
INFO - 2018-07-29 09:50:18 --> Security Class Initialized
DEBUG - 2018-07-29 09:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 09:50:18 --> CSRF cookie sent
INFO - 2018-07-29 09:50:18 --> Input Class Initialized
INFO - 2018-07-29 09:50:18 --> Language Class Initialized
INFO - 2018-07-29 09:50:18 --> Loader Class Initialized
INFO - 2018-07-29 09:50:18 --> Helper loaded: url_helper
INFO - 2018-07-29 09:50:18 --> Helper loaded: form_helper
INFO - 2018-07-29 09:50:18 --> Helper loaded: language_helper
DEBUG - 2018-07-29 09:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 09:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 09:50:18 --> User Agent Class Initialized
INFO - 2018-07-29 09:50:18 --> Controller Class Initialized
INFO - 2018-07-29 09:50:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 09:50:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 09:50:18 --> Pixel_Model class loaded
INFO - 2018-07-29 09:50:18 --> Database Driver Class Initialized
INFO - 2018-07-29 09:50:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 09:50:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 09:50:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 09:50:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 09:50:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 09:50:18 --> Final output sent to browser
DEBUG - 2018-07-29 09:50:18 --> Total execution time: 0.0326
INFO - 2018-07-29 11:28:41 --> Config Class Initialized
INFO - 2018-07-29 11:28:41 --> Hooks Class Initialized
DEBUG - 2018-07-29 11:28:41 --> UTF-8 Support Enabled
INFO - 2018-07-29 11:28:41 --> Utf8 Class Initialized
INFO - 2018-07-29 11:28:41 --> URI Class Initialized
INFO - 2018-07-29 11:28:41 --> Router Class Initialized
INFO - 2018-07-29 11:28:41 --> Output Class Initialized
INFO - 2018-07-29 11:28:41 --> Security Class Initialized
DEBUG - 2018-07-29 11:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 11:28:41 --> CSRF cookie sent
INFO - 2018-07-29 11:28:41 --> Input Class Initialized
INFO - 2018-07-29 11:28:41 --> Language Class Initialized
ERROR - 2018-07-29 11:28:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-29 15:16:53 --> Config Class Initialized
INFO - 2018-07-29 15:16:53 --> Hooks Class Initialized
DEBUG - 2018-07-29 15:16:53 --> UTF-8 Support Enabled
INFO - 2018-07-29 15:16:53 --> Utf8 Class Initialized
INFO - 2018-07-29 15:16:53 --> URI Class Initialized
DEBUG - 2018-07-29 15:16:53 --> No URI present. Default controller set.
INFO - 2018-07-29 15:16:53 --> Router Class Initialized
INFO - 2018-07-29 15:16:53 --> Output Class Initialized
INFO - 2018-07-29 15:16:53 --> Security Class Initialized
DEBUG - 2018-07-29 15:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 15:16:53 --> CSRF cookie sent
INFO - 2018-07-29 15:16:53 --> Input Class Initialized
INFO - 2018-07-29 15:16:53 --> Language Class Initialized
INFO - 2018-07-29 15:16:53 --> Loader Class Initialized
INFO - 2018-07-29 15:16:53 --> Helper loaded: url_helper
INFO - 2018-07-29 15:16:53 --> Helper loaded: form_helper
INFO - 2018-07-29 15:16:53 --> Helper loaded: language_helper
DEBUG - 2018-07-29 15:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 15:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 15:16:53 --> User Agent Class Initialized
INFO - 2018-07-29 15:16:53 --> Controller Class Initialized
INFO - 2018-07-29 15:16:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 15:16:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 15:16:53 --> Pixel_Model class loaded
INFO - 2018-07-29 15:16:53 --> Database Driver Class Initialized
INFO - 2018-07-29 15:16:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 15:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 15:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 15:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 15:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 15:16:53 --> Final output sent to browser
DEBUG - 2018-07-29 15:16:53 --> Total execution time: 0.0420
INFO - 2018-07-29 17:49:57 --> Config Class Initialized
INFO - 2018-07-29 17:49:57 --> Hooks Class Initialized
DEBUG - 2018-07-29 17:49:57 --> UTF-8 Support Enabled
INFO - 2018-07-29 17:49:57 --> Utf8 Class Initialized
INFO - 2018-07-29 17:49:57 --> URI Class Initialized
DEBUG - 2018-07-29 17:49:57 --> No URI present. Default controller set.
INFO - 2018-07-29 17:49:57 --> Router Class Initialized
INFO - 2018-07-29 17:49:57 --> Output Class Initialized
INFO - 2018-07-29 17:49:57 --> Security Class Initialized
DEBUG - 2018-07-29 17:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 17:49:57 --> CSRF cookie sent
INFO - 2018-07-29 17:49:57 --> Input Class Initialized
INFO - 2018-07-29 17:49:57 --> Language Class Initialized
INFO - 2018-07-29 17:49:57 --> Loader Class Initialized
INFO - 2018-07-29 17:49:57 --> Helper loaded: url_helper
INFO - 2018-07-29 17:49:57 --> Helper loaded: form_helper
INFO - 2018-07-29 17:49:57 --> Helper loaded: language_helper
DEBUG - 2018-07-29 17:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 17:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 17:49:57 --> User Agent Class Initialized
INFO - 2018-07-29 17:49:57 --> Controller Class Initialized
INFO - 2018-07-29 17:49:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 17:49:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 17:49:57 --> Pixel_Model class loaded
INFO - 2018-07-29 17:49:57 --> Database Driver Class Initialized
INFO - 2018-07-29 17:49:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 17:49:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 17:49:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 17:49:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 17:49:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 17:49:57 --> Final output sent to browser
DEBUG - 2018-07-29 17:49:57 --> Total execution time: 0.0328
INFO - 2018-07-29 19:51:35 --> Config Class Initialized
INFO - 2018-07-29 19:51:35 --> Hooks Class Initialized
DEBUG - 2018-07-29 19:51:35 --> UTF-8 Support Enabled
INFO - 2018-07-29 19:51:35 --> Utf8 Class Initialized
INFO - 2018-07-29 19:51:35 --> URI Class Initialized
DEBUG - 2018-07-29 19:51:35 --> No URI present. Default controller set.
INFO - 2018-07-29 19:51:35 --> Router Class Initialized
INFO - 2018-07-29 19:51:35 --> Output Class Initialized
INFO - 2018-07-29 19:51:35 --> Security Class Initialized
DEBUG - 2018-07-29 19:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 19:51:35 --> CSRF cookie sent
INFO - 2018-07-29 19:51:35 --> Input Class Initialized
INFO - 2018-07-29 19:51:35 --> Language Class Initialized
INFO - 2018-07-29 19:51:35 --> Loader Class Initialized
INFO - 2018-07-29 19:51:35 --> Helper loaded: url_helper
INFO - 2018-07-29 19:51:35 --> Helper loaded: form_helper
INFO - 2018-07-29 19:51:35 --> Helper loaded: language_helper
DEBUG - 2018-07-29 19:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 19:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 19:51:35 --> User Agent Class Initialized
INFO - 2018-07-29 19:51:35 --> Controller Class Initialized
INFO - 2018-07-29 19:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 19:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 19:51:35 --> Pixel_Model class loaded
INFO - 2018-07-29 19:51:35 --> Database Driver Class Initialized
INFO - 2018-07-29 19:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 19:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 19:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 19:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 19:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 19:51:35 --> Final output sent to browser
DEBUG - 2018-07-29 19:51:35 --> Total execution time: 0.0333
INFO - 2018-07-29 20:18:10 --> Config Class Initialized
INFO - 2018-07-29 20:18:10 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:18:10 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:18:10 --> Utf8 Class Initialized
INFO - 2018-07-29 20:18:10 --> URI Class Initialized
DEBUG - 2018-07-29 20:18:10 --> No URI present. Default controller set.
INFO - 2018-07-29 20:18:10 --> Router Class Initialized
INFO - 2018-07-29 20:18:10 --> Output Class Initialized
INFO - 2018-07-29 20:18:10 --> Security Class Initialized
DEBUG - 2018-07-29 20:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:18:10 --> CSRF cookie sent
INFO - 2018-07-29 20:18:10 --> Input Class Initialized
INFO - 2018-07-29 20:18:10 --> Language Class Initialized
INFO - 2018-07-29 20:18:10 --> Loader Class Initialized
INFO - 2018-07-29 20:18:10 --> Helper loaded: url_helper
INFO - 2018-07-29 20:18:10 --> Helper loaded: form_helper
INFO - 2018-07-29 20:18:10 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:18:10 --> User Agent Class Initialized
INFO - 2018-07-29 20:18:10 --> Controller Class Initialized
INFO - 2018-07-29 20:18:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:18:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:18:10 --> Pixel_Model class loaded
INFO - 2018-07-29 20:18:10 --> Database Driver Class Initialized
INFO - 2018-07-29 20:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 20:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:18:10 --> Final output sent to browser
DEBUG - 2018-07-29 20:18:10 --> Total execution time: 0.0442
INFO - 2018-07-29 20:18:12 --> Config Class Initialized
INFO - 2018-07-29 20:18:12 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:18:12 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:18:12 --> Utf8 Class Initialized
INFO - 2018-07-29 20:18:12 --> URI Class Initialized
DEBUG - 2018-07-29 20:18:12 --> No URI present. Default controller set.
INFO - 2018-07-29 20:18:12 --> Router Class Initialized
INFO - 2018-07-29 20:18:12 --> Output Class Initialized
INFO - 2018-07-29 20:18:12 --> Security Class Initialized
DEBUG - 2018-07-29 20:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:18:12 --> CSRF cookie sent
INFO - 2018-07-29 20:18:12 --> Input Class Initialized
INFO - 2018-07-29 20:18:12 --> Language Class Initialized
INFO - 2018-07-29 20:18:12 --> Loader Class Initialized
INFO - 2018-07-29 20:18:12 --> Helper loaded: url_helper
INFO - 2018-07-29 20:18:12 --> Helper loaded: form_helper
INFO - 2018-07-29 20:18:12 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:18:12 --> User Agent Class Initialized
INFO - 2018-07-29 20:18:12 --> Controller Class Initialized
INFO - 2018-07-29 20:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:18:12 --> Pixel_Model class loaded
INFO - 2018-07-29 20:18:12 --> Database Driver Class Initialized
INFO - 2018-07-29 20:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 20:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:18:12 --> Final output sent to browser
DEBUG - 2018-07-29 20:18:12 --> Total execution time: 0.0485
INFO - 2018-07-29 20:18:59 --> Config Class Initialized
INFO - 2018-07-29 20:18:59 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:18:59 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:18:59 --> Utf8 Class Initialized
INFO - 2018-07-29 20:18:59 --> URI Class Initialized
INFO - 2018-07-29 20:18:59 --> Router Class Initialized
INFO - 2018-07-29 20:18:59 --> Output Class Initialized
INFO - 2018-07-29 20:18:59 --> Security Class Initialized
DEBUG - 2018-07-29 20:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:18:59 --> CSRF cookie sent
INFO - 2018-07-29 20:18:59 --> Input Class Initialized
INFO - 2018-07-29 20:18:59 --> Language Class Initialized
INFO - 2018-07-29 20:18:59 --> Loader Class Initialized
INFO - 2018-07-29 20:18:59 --> Helper loaded: url_helper
INFO - 2018-07-29 20:18:59 --> Helper loaded: form_helper
INFO - 2018-07-29 20:18:59 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:18:59 --> User Agent Class Initialized
INFO - 2018-07-29 20:18:59 --> Controller Class Initialized
INFO - 2018-07-29 20:18:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:18:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-29 20:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:18:59 --> Final output sent to browser
DEBUG - 2018-07-29 20:18:59 --> Total execution time: 0.0241
INFO - 2018-07-29 20:19:09 --> Config Class Initialized
INFO - 2018-07-29 20:19:09 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:19:09 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:19:09 --> Utf8 Class Initialized
INFO - 2018-07-29 20:19:09 --> URI Class Initialized
INFO - 2018-07-29 20:19:09 --> Router Class Initialized
INFO - 2018-07-29 20:19:09 --> Output Class Initialized
INFO - 2018-07-29 20:19:09 --> Security Class Initialized
DEBUG - 2018-07-29 20:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:19:09 --> CSRF cookie sent
INFO - 2018-07-29 20:19:09 --> Input Class Initialized
INFO - 2018-07-29 20:19:09 --> Language Class Initialized
INFO - 2018-07-29 20:19:09 --> Loader Class Initialized
INFO - 2018-07-29 20:19:09 --> Helper loaded: url_helper
INFO - 2018-07-29 20:19:09 --> Helper loaded: form_helper
INFO - 2018-07-29 20:19:09 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:19:09 --> User Agent Class Initialized
INFO - 2018-07-29 20:19:09 --> Controller Class Initialized
INFO - 2018-07-29 20:19:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:19:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-29 20:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:19:09 --> Final output sent to browser
DEBUG - 2018-07-29 20:19:09 --> Total execution time: 0.0217
INFO - 2018-07-29 20:21:25 --> Config Class Initialized
INFO - 2018-07-29 20:21:25 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:21:25 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:21:25 --> Utf8 Class Initialized
INFO - 2018-07-29 20:21:25 --> URI Class Initialized
DEBUG - 2018-07-29 20:21:25 --> No URI present. Default controller set.
INFO - 2018-07-29 20:21:25 --> Router Class Initialized
INFO - 2018-07-29 20:21:25 --> Output Class Initialized
INFO - 2018-07-29 20:21:25 --> Security Class Initialized
DEBUG - 2018-07-29 20:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:21:25 --> CSRF cookie sent
INFO - 2018-07-29 20:21:25 --> Input Class Initialized
INFO - 2018-07-29 20:21:25 --> Language Class Initialized
INFO - 2018-07-29 20:21:25 --> Loader Class Initialized
INFO - 2018-07-29 20:21:25 --> Helper loaded: url_helper
INFO - 2018-07-29 20:21:25 --> Helper loaded: form_helper
INFO - 2018-07-29 20:21:25 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:21:25 --> User Agent Class Initialized
INFO - 2018-07-29 20:21:25 --> Controller Class Initialized
INFO - 2018-07-29 20:21:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:21:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:21:25 --> Pixel_Model class loaded
INFO - 2018-07-29 20:21:25 --> Database Driver Class Initialized
INFO - 2018-07-29 20:21:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 20:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:21:25 --> Final output sent to browser
DEBUG - 2018-07-29 20:21:25 --> Total execution time: 0.0372
INFO - 2018-07-29 20:26:49 --> Config Class Initialized
INFO - 2018-07-29 20:26:49 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:26:49 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:26:49 --> Utf8 Class Initialized
INFO - 2018-07-29 20:26:49 --> URI Class Initialized
INFO - 2018-07-29 20:26:49 --> Router Class Initialized
INFO - 2018-07-29 20:26:49 --> Output Class Initialized
INFO - 2018-07-29 20:26:49 --> Security Class Initialized
DEBUG - 2018-07-29 20:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:26:49 --> CSRF cookie sent
INFO - 2018-07-29 20:26:49 --> Input Class Initialized
INFO - 2018-07-29 20:26:49 --> Language Class Initialized
INFO - 2018-07-29 20:26:49 --> Loader Class Initialized
INFO - 2018-07-29 20:26:49 --> Helper loaded: url_helper
INFO - 2018-07-29 20:26:49 --> Helper loaded: form_helper
INFO - 2018-07-29 20:26:49 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:26:49 --> User Agent Class Initialized
INFO - 2018-07-29 20:26:49 --> Controller Class Initialized
INFO - 2018-07-29 20:26:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:26:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-29 20:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:26:49 --> Final output sent to browser
DEBUG - 2018-07-29 20:26:49 --> Total execution time: 0.0231
INFO - 2018-07-29 20:37:21 --> Config Class Initialized
INFO - 2018-07-29 20:37:21 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:37:21 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:37:21 --> Utf8 Class Initialized
INFO - 2018-07-29 20:37:21 --> URI Class Initialized
DEBUG - 2018-07-29 20:37:21 --> No URI present. Default controller set.
INFO - 2018-07-29 20:37:21 --> Router Class Initialized
INFO - 2018-07-29 20:37:21 --> Output Class Initialized
INFO - 2018-07-29 20:37:21 --> Security Class Initialized
DEBUG - 2018-07-29 20:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:37:21 --> CSRF cookie sent
INFO - 2018-07-29 20:37:21 --> Input Class Initialized
INFO - 2018-07-29 20:37:21 --> Language Class Initialized
INFO - 2018-07-29 20:37:21 --> Loader Class Initialized
INFO - 2018-07-29 20:37:21 --> Helper loaded: url_helper
INFO - 2018-07-29 20:37:21 --> Helper loaded: form_helper
INFO - 2018-07-29 20:37:21 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:37:21 --> User Agent Class Initialized
INFO - 2018-07-29 20:37:21 --> Controller Class Initialized
INFO - 2018-07-29 20:37:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:37:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:37:21 --> Pixel_Model class loaded
INFO - 2018-07-29 20:37:21 --> Database Driver Class Initialized
INFO - 2018-07-29 20:37:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 20:37:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:37:21 --> Final output sent to browser
DEBUG - 2018-07-29 20:37:21 --> Total execution time: 0.0349
INFO - 2018-07-29 20:41:19 --> Config Class Initialized
INFO - 2018-07-29 20:41:19 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:19 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:19 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:19 --> URI Class Initialized
INFO - 2018-07-29 20:41:19 --> Router Class Initialized
INFO - 2018-07-29 20:41:19 --> Output Class Initialized
INFO - 2018-07-29 20:41:19 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:19 --> CSRF cookie sent
INFO - 2018-07-29 20:41:19 --> Input Class Initialized
INFO - 2018-07-29 20:41:19 --> Language Class Initialized
INFO - 2018-07-29 20:41:19 --> Loader Class Initialized
INFO - 2018-07-29 20:41:19 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:19 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:19 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:19 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:19 --> Controller Class Initialized
INFO - 2018-07-29 20:41:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-29 20:41:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:41:19 --> Final output sent to browser
DEBUG - 2018-07-29 20:41:19 --> Total execution time: 0.0245
INFO - 2018-07-29 20:41:31 --> Config Class Initialized
INFO - 2018-07-29 20:41:31 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:31 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:31 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:31 --> URI Class Initialized
INFO - 2018-07-29 20:41:31 --> Router Class Initialized
INFO - 2018-07-29 20:41:31 --> Output Class Initialized
INFO - 2018-07-29 20:41:31 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:31 --> CSRF cookie sent
INFO - 2018-07-29 20:41:31 --> Input Class Initialized
INFO - 2018-07-29 20:41:31 --> Language Class Initialized
INFO - 2018-07-29 20:41:31 --> Loader Class Initialized
INFO - 2018-07-29 20:41:31 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:31 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:31 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:31 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:31 --> Controller Class Initialized
INFO - 2018-07-29 20:41:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-29 20:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:41:31 --> Final output sent to browser
DEBUG - 2018-07-29 20:41:31 --> Total execution time: 0.0208
INFO - 2018-07-29 20:41:37 --> Config Class Initialized
INFO - 2018-07-29 20:41:37 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:37 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:37 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:37 --> URI Class Initialized
INFO - 2018-07-29 20:41:37 --> Router Class Initialized
INFO - 2018-07-29 20:41:37 --> Output Class Initialized
INFO - 2018-07-29 20:41:37 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:37 --> CSRF cookie sent
INFO - 2018-07-29 20:41:37 --> Input Class Initialized
INFO - 2018-07-29 20:41:37 --> Language Class Initialized
INFO - 2018-07-29 20:41:37 --> Loader Class Initialized
INFO - 2018-07-29 20:41:37 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:37 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:37 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:37 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:37 --> Controller Class Initialized
INFO - 2018-07-29 20:41:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-29 20:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:41:37 --> Final output sent to browser
DEBUG - 2018-07-29 20:41:37 --> Total execution time: 0.0230
INFO - 2018-07-29 20:41:42 --> Config Class Initialized
INFO - 2018-07-29 20:41:42 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:42 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:42 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:42 --> URI Class Initialized
INFO - 2018-07-29 20:41:42 --> Router Class Initialized
INFO - 2018-07-29 20:41:42 --> Output Class Initialized
INFO - 2018-07-29 20:41:42 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:42 --> CSRF cookie sent
INFO - 2018-07-29 20:41:42 --> Input Class Initialized
INFO - 2018-07-29 20:41:42 --> Language Class Initialized
INFO - 2018-07-29 20:41:42 --> Loader Class Initialized
INFO - 2018-07-29 20:41:42 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:42 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:42 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:42 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:42 --> Controller Class Initialized
INFO - 2018-07-29 20:41:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:41:42 --> Pixel_Model class loaded
INFO - 2018-07-29 20:41:42 --> Database Driver Class Initialized
INFO - 2018-07-29 20:41:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:41:42 --> Config Class Initialized
INFO - 2018-07-29 20:41:42 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:42 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:42 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:42 --> URI Class Initialized
INFO - 2018-07-29 20:41:42 --> Router Class Initialized
INFO - 2018-07-29 20:41:42 --> Output Class Initialized
INFO - 2018-07-29 20:41:42 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:42 --> CSRF cookie sent
INFO - 2018-07-29 20:41:42 --> Input Class Initialized
INFO - 2018-07-29 20:41:42 --> Language Class Initialized
INFO - 2018-07-29 20:41:42 --> Loader Class Initialized
INFO - 2018-07-29 20:41:42 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:42 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:42 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:42 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:42 --> Controller Class Initialized
INFO - 2018-07-29 20:41:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-29 20:41:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-29 20:41:42 --> Could not find the language line "req_email"
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-29 20:41:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:41:42 --> Final output sent to browser
DEBUG - 2018-07-29 20:41:42 --> Total execution time: 0.0211
INFO - 2018-07-29 20:41:44 --> Config Class Initialized
INFO - 2018-07-29 20:41:44 --> Hooks Class Initialized
DEBUG - 2018-07-29 20:41:44 --> UTF-8 Support Enabled
INFO - 2018-07-29 20:41:44 --> Utf8 Class Initialized
INFO - 2018-07-29 20:41:44 --> URI Class Initialized
DEBUG - 2018-07-29 20:41:44 --> No URI present. Default controller set.
INFO - 2018-07-29 20:41:44 --> Router Class Initialized
INFO - 2018-07-29 20:41:44 --> Output Class Initialized
INFO - 2018-07-29 20:41:44 --> Security Class Initialized
DEBUG - 2018-07-29 20:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 20:41:44 --> CSRF cookie sent
INFO - 2018-07-29 20:41:44 --> Input Class Initialized
INFO - 2018-07-29 20:41:44 --> Language Class Initialized
INFO - 2018-07-29 20:41:44 --> Loader Class Initialized
INFO - 2018-07-29 20:41:44 --> Helper loaded: url_helper
INFO - 2018-07-29 20:41:44 --> Helper loaded: form_helper
INFO - 2018-07-29 20:41:44 --> Helper loaded: language_helper
DEBUG - 2018-07-29 20:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 20:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 20:41:44 --> User Agent Class Initialized
INFO - 2018-07-29 20:41:44 --> Controller Class Initialized
INFO - 2018-07-29 20:41:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 20:41:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 20:41:44 --> Pixel_Model class loaded
INFO - 2018-07-29 20:41:44 --> Database Driver Class Initialized
INFO - 2018-07-29 20:41:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 20:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 20:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 20:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 20:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 20:41:44 --> Final output sent to browser
DEBUG - 2018-07-29 20:41:44 --> Total execution time: 0.0306
INFO - 2018-07-29 22:08:52 --> Config Class Initialized
INFO - 2018-07-29 22:08:52 --> Hooks Class Initialized
DEBUG - 2018-07-29 22:08:52 --> UTF-8 Support Enabled
INFO - 2018-07-29 22:08:52 --> Utf8 Class Initialized
INFO - 2018-07-29 22:08:52 --> URI Class Initialized
DEBUG - 2018-07-29 22:08:52 --> No URI present. Default controller set.
INFO - 2018-07-29 22:08:52 --> Router Class Initialized
INFO - 2018-07-29 22:08:52 --> Output Class Initialized
INFO - 2018-07-29 22:08:52 --> Security Class Initialized
DEBUG - 2018-07-29 22:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 22:08:52 --> CSRF cookie sent
INFO - 2018-07-29 22:08:52 --> Input Class Initialized
INFO - 2018-07-29 22:08:52 --> Language Class Initialized
INFO - 2018-07-29 22:08:52 --> Loader Class Initialized
INFO - 2018-07-29 22:08:52 --> Helper loaded: url_helper
INFO - 2018-07-29 22:08:52 --> Helper loaded: form_helper
INFO - 2018-07-29 22:08:52 --> Helper loaded: language_helper
DEBUG - 2018-07-29 22:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 22:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 22:08:52 --> User Agent Class Initialized
INFO - 2018-07-29 22:08:52 --> Controller Class Initialized
INFO - 2018-07-29 22:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 22:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 22:08:52 --> Pixel_Model class loaded
INFO - 2018-07-29 22:08:52 --> Database Driver Class Initialized
INFO - 2018-07-29 22:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 22:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 22:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 22:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 22:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 22:08:52 --> Final output sent to browser
DEBUG - 2018-07-29 22:08:52 --> Total execution time: 0.0373
INFO - 2018-07-29 23:13:56 --> Config Class Initialized
INFO - 2018-07-29 23:13:56 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:13:56 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:13:56 --> Utf8 Class Initialized
INFO - 2018-07-29 23:13:56 --> URI Class Initialized
DEBUG - 2018-07-29 23:13:56 --> No URI present. Default controller set.
INFO - 2018-07-29 23:13:56 --> Router Class Initialized
INFO - 2018-07-29 23:13:56 --> Output Class Initialized
INFO - 2018-07-29 23:13:56 --> Security Class Initialized
DEBUG - 2018-07-29 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:13:56 --> CSRF cookie sent
INFO - 2018-07-29 23:13:56 --> Input Class Initialized
INFO - 2018-07-29 23:13:56 --> Language Class Initialized
INFO - 2018-07-29 23:13:56 --> Loader Class Initialized
INFO - 2018-07-29 23:13:56 --> Helper loaded: url_helper
INFO - 2018-07-29 23:13:56 --> Helper loaded: form_helper
INFO - 2018-07-29 23:13:56 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:13:56 --> User Agent Class Initialized
INFO - 2018-07-29 23:13:56 --> Controller Class Initialized
INFO - 2018-07-29 23:13:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:13:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:13:56 --> Pixel_Model class loaded
INFO - 2018-07-29 23:13:56 --> Database Driver Class Initialized
INFO - 2018-07-29 23:13:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:13:56 --> Final output sent to browser
DEBUG - 2018-07-29 23:13:56 --> Total execution time: 0.0364
INFO - 2018-07-29 23:13:56 --> Config Class Initialized
INFO - 2018-07-29 23:13:56 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:13:56 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:13:56 --> Utf8 Class Initialized
INFO - 2018-07-29 23:13:56 --> URI Class Initialized
DEBUG - 2018-07-29 23:13:56 --> No URI present. Default controller set.
INFO - 2018-07-29 23:13:56 --> Router Class Initialized
INFO - 2018-07-29 23:13:56 --> Output Class Initialized
INFO - 2018-07-29 23:13:56 --> Security Class Initialized
DEBUG - 2018-07-29 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:13:56 --> CSRF cookie sent
INFO - 2018-07-29 23:13:56 --> Input Class Initialized
INFO - 2018-07-29 23:13:56 --> Language Class Initialized
INFO - 2018-07-29 23:13:56 --> Loader Class Initialized
INFO - 2018-07-29 23:13:56 --> Helper loaded: url_helper
INFO - 2018-07-29 23:13:56 --> Helper loaded: form_helper
INFO - 2018-07-29 23:13:56 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:13:56 --> User Agent Class Initialized
INFO - 2018-07-29 23:13:56 --> Controller Class Initialized
INFO - 2018-07-29 23:13:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:13:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:13:56 --> Pixel_Model class loaded
INFO - 2018-07-29 23:13:56 --> Database Driver Class Initialized
INFO - 2018-07-29 23:13:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 23:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:13:56 --> Final output sent to browser
DEBUG - 2018-07-29 23:13:56 --> Total execution time: 0.0377
INFO - 2018-07-29 23:13:57 --> Config Class Initialized
INFO - 2018-07-29 23:13:57 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:13:57 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:13:57 --> Utf8 Class Initialized
INFO - 2018-07-29 23:13:57 --> URI Class Initialized
DEBUG - 2018-07-29 23:13:57 --> No URI present. Default controller set.
INFO - 2018-07-29 23:13:57 --> Router Class Initialized
INFO - 2018-07-29 23:13:57 --> Output Class Initialized
INFO - 2018-07-29 23:13:57 --> Security Class Initialized
DEBUG - 2018-07-29 23:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:13:57 --> CSRF cookie sent
INFO - 2018-07-29 23:13:57 --> Input Class Initialized
INFO - 2018-07-29 23:13:57 --> Language Class Initialized
INFO - 2018-07-29 23:13:57 --> Loader Class Initialized
INFO - 2018-07-29 23:13:57 --> Helper loaded: url_helper
INFO - 2018-07-29 23:13:57 --> Helper loaded: form_helper
INFO - 2018-07-29 23:13:57 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:13:57 --> User Agent Class Initialized
INFO - 2018-07-29 23:13:57 --> Controller Class Initialized
INFO - 2018-07-29 23:13:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:13:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:13:57 --> Pixel_Model class loaded
INFO - 2018-07-29 23:13:57 --> Database Driver Class Initialized
INFO - 2018-07-29 23:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 23:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:13:57 --> Final output sent to browser
DEBUG - 2018-07-29 23:13:57 --> Total execution time: 0.0325
INFO - 2018-07-29 23:13:57 --> Config Class Initialized
INFO - 2018-07-29 23:13:57 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:13:57 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:13:57 --> Utf8 Class Initialized
INFO - 2018-07-29 23:13:57 --> URI Class Initialized
INFO - 2018-07-29 23:13:57 --> Router Class Initialized
INFO - 2018-07-29 23:13:57 --> Output Class Initialized
INFO - 2018-07-29 23:13:57 --> Security Class Initialized
DEBUG - 2018-07-29 23:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:13:57 --> CSRF cookie sent
INFO - 2018-07-29 23:13:57 --> Input Class Initialized
INFO - 2018-07-29 23:13:57 --> Language Class Initialized
ERROR - 2018-07-29 23:13:57 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-29 23:14:04 --> Config Class Initialized
INFO - 2018-07-29 23:14:04 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:04 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:04 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:04 --> URI Class Initialized
DEBUG - 2018-07-29 23:14:04 --> No URI present. Default controller set.
INFO - 2018-07-29 23:14:04 --> Router Class Initialized
INFO - 2018-07-29 23:14:04 --> Output Class Initialized
INFO - 2018-07-29 23:14:04 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:04 --> CSRF cookie sent
INFO - 2018-07-29 23:14:04 --> Input Class Initialized
INFO - 2018-07-29 23:14:04 --> Language Class Initialized
INFO - 2018-07-29 23:14:04 --> Loader Class Initialized
INFO - 2018-07-29 23:14:04 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:04 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:04 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:04 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:04 --> Controller Class Initialized
INFO - 2018-07-29 23:14:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:04 --> Pixel_Model class loaded
INFO - 2018-07-29 23:14:04 --> Database Driver Class Initialized
INFO - 2018-07-29 23:14:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 23:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:04 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:04 --> Total execution time: 0.0378
INFO - 2018-07-29 23:14:05 --> Config Class Initialized
INFO - 2018-07-29 23:14:05 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:05 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:05 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:05 --> URI Class Initialized
INFO - 2018-07-29 23:14:05 --> Router Class Initialized
INFO - 2018-07-29 23:14:05 --> Output Class Initialized
INFO - 2018-07-29 23:14:05 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:05 --> CSRF cookie sent
INFO - 2018-07-29 23:14:05 --> Input Class Initialized
INFO - 2018-07-29 23:14:05 --> Language Class Initialized
ERROR - 2018-07-29 23:14:05 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-29 23:14:05 --> Config Class Initialized
INFO - 2018-07-29 23:14:05 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:05 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:05 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:05 --> URI Class Initialized
INFO - 2018-07-29 23:14:05 --> Router Class Initialized
INFO - 2018-07-29 23:14:05 --> Output Class Initialized
INFO - 2018-07-29 23:14:05 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:05 --> CSRF cookie sent
INFO - 2018-07-29 23:14:05 --> Input Class Initialized
INFO - 2018-07-29 23:14:05 --> Language Class Initialized
ERROR - 2018-07-29 23:14:05 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-29 23:14:06 --> Config Class Initialized
INFO - 2018-07-29 23:14:06 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:06 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:06 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:06 --> URI Class Initialized
INFO - 2018-07-29 23:14:06 --> Router Class Initialized
INFO - 2018-07-29 23:14:06 --> Output Class Initialized
INFO - 2018-07-29 23:14:06 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:06 --> CSRF cookie sent
INFO - 2018-07-29 23:14:06 --> Input Class Initialized
INFO - 2018-07-29 23:14:06 --> Language Class Initialized
INFO - 2018-07-29 23:14:06 --> Loader Class Initialized
INFO - 2018-07-29 23:14:06 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:06 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:06 --> Controller Class Initialized
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:06 --> Pixel_Model class loaded
INFO - 2018-07-29 23:14:06 --> Database Driver Class Initialized
INFO - 2018-07-29 23:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:14:06 --> Config Class Initialized
INFO - 2018-07-29 23:14:06 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:06 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:06 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:06 --> URI Class Initialized
INFO - 2018-07-29 23:14:06 --> Router Class Initialized
INFO - 2018-07-29 23:14:06 --> Output Class Initialized
INFO - 2018-07-29 23:14:06 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:06 --> CSRF cookie sent
INFO - 2018-07-29 23:14:06 --> Input Class Initialized
INFO - 2018-07-29 23:14:06 --> Language Class Initialized
INFO - 2018-07-29 23:14:06 --> Loader Class Initialized
INFO - 2018-07-29 23:14:06 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:06 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:06 --> Controller Class Initialized
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-29 23:14:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-29 23:14:06 --> Could not find the language line "req_email"
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:06 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:06 --> Total execution time: 0.0268
INFO - 2018-07-29 23:14:06 --> Config Class Initialized
INFO - 2018-07-29 23:14:06 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:06 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:06 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:06 --> URI Class Initialized
INFO - 2018-07-29 23:14:06 --> Router Class Initialized
INFO - 2018-07-29 23:14:06 --> Output Class Initialized
INFO - 2018-07-29 23:14:06 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:06 --> CSRF cookie sent
INFO - 2018-07-29 23:14:06 --> Input Class Initialized
INFO - 2018-07-29 23:14:06 --> Language Class Initialized
INFO - 2018-07-29 23:14:06 --> Loader Class Initialized
INFO - 2018-07-29 23:14:06 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:06 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:06 --> Controller Class Initialized
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:06 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:06 --> Total execution time: 0.0374
INFO - 2018-07-29 23:14:06 --> Config Class Initialized
INFO - 2018-07-29 23:14:06 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:06 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:06 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:06 --> URI Class Initialized
INFO - 2018-07-29 23:14:06 --> Router Class Initialized
INFO - 2018-07-29 23:14:06 --> Output Class Initialized
INFO - 2018-07-29 23:14:06 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:06 --> CSRF cookie sent
INFO - 2018-07-29 23:14:06 --> Input Class Initialized
INFO - 2018-07-29 23:14:06 --> Language Class Initialized
INFO - 2018-07-29 23:14:06 --> Loader Class Initialized
INFO - 2018-07-29 23:14:06 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:06 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:06 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:06 --> Controller Class Initialized
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-29 23:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:06 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:06 --> Total execution time: 0.0319
INFO - 2018-07-29 23:14:07 --> Config Class Initialized
INFO - 2018-07-29 23:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:07 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:07 --> URI Class Initialized
INFO - 2018-07-29 23:14:07 --> Router Class Initialized
INFO - 2018-07-29 23:14:07 --> Output Class Initialized
INFO - 2018-07-29 23:14:07 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:07 --> CSRF cookie sent
INFO - 2018-07-29 23:14:07 --> Input Class Initialized
INFO - 2018-07-29 23:14:07 --> Language Class Initialized
INFO - 2018-07-29 23:14:07 --> Loader Class Initialized
INFO - 2018-07-29 23:14:07 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:07 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:07 --> Controller Class Initialized
INFO - 2018-07-29 23:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:07 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:07 --> Total execution time: 0.0215
INFO - 2018-07-29 23:14:07 --> Config Class Initialized
INFO - 2018-07-29 23:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:07 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:07 --> URI Class Initialized
INFO - 2018-07-29 23:14:07 --> Router Class Initialized
INFO - 2018-07-29 23:14:07 --> Output Class Initialized
INFO - 2018-07-29 23:14:07 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:07 --> CSRF cookie sent
INFO - 2018-07-29 23:14:07 --> Input Class Initialized
INFO - 2018-07-29 23:14:07 --> Language Class Initialized
INFO - 2018-07-29 23:14:07 --> Loader Class Initialized
INFO - 2018-07-29 23:14:07 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:07 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:07 --> Controller Class Initialized
INFO - 2018-07-29 23:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-29 23:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:07 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:07 --> Total execution time: 0.0224
INFO - 2018-07-29 23:14:07 --> Config Class Initialized
INFO - 2018-07-29 23:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:07 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:07 --> URI Class Initialized
INFO - 2018-07-29 23:14:07 --> Router Class Initialized
INFO - 2018-07-29 23:14:07 --> Output Class Initialized
INFO - 2018-07-29 23:14:07 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:07 --> CSRF cookie sent
INFO - 2018-07-29 23:14:07 --> Input Class Initialized
INFO - 2018-07-29 23:14:07 --> Language Class Initialized
INFO - 2018-07-29 23:14:07 --> Loader Class Initialized
INFO - 2018-07-29 23:14:07 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:07 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:07 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:08 --> Controller Class Initialized
INFO - 2018-07-29 23:14:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-29 23:14:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-29 23:14:08 --> Could not find the language line "req_email"
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:08 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:08 --> Total execution time: 0.0236
INFO - 2018-07-29 23:14:08 --> Config Class Initialized
INFO - 2018-07-29 23:14:08 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:14:08 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:14:08 --> Utf8 Class Initialized
INFO - 2018-07-29 23:14:08 --> URI Class Initialized
INFO - 2018-07-29 23:14:08 --> Router Class Initialized
INFO - 2018-07-29 23:14:08 --> Output Class Initialized
INFO - 2018-07-29 23:14:08 --> Security Class Initialized
DEBUG - 2018-07-29 23:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:14:08 --> CSRF cookie sent
INFO - 2018-07-29 23:14:08 --> Input Class Initialized
INFO - 2018-07-29 23:14:08 --> Language Class Initialized
INFO - 2018-07-29 23:14:08 --> Loader Class Initialized
INFO - 2018-07-29 23:14:08 --> Helper loaded: url_helper
INFO - 2018-07-29 23:14:08 --> Helper loaded: form_helper
INFO - 2018-07-29 23:14:08 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:14:08 --> User Agent Class Initialized
INFO - 2018-07-29 23:14:08 --> Controller Class Initialized
INFO - 2018-07-29 23:14:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:14:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:14:08 --> Pixel_Model class loaded
INFO - 2018-07-29 23:14:08 --> Database Driver Class Initialized
INFO - 2018-07-29 23:14:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-29 23:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:14:08 --> Final output sent to browser
DEBUG - 2018-07-29 23:14:08 --> Total execution time: 0.0298
INFO - 2018-07-29 23:15:44 --> Config Class Initialized
INFO - 2018-07-29 23:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:15:44 --> Utf8 Class Initialized
INFO - 2018-07-29 23:15:44 --> URI Class Initialized
INFO - 2018-07-29 23:15:44 --> Router Class Initialized
INFO - 2018-07-29 23:15:44 --> Output Class Initialized
INFO - 2018-07-29 23:15:44 --> Security Class Initialized
DEBUG - 2018-07-29 23:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:15:44 --> CSRF cookie sent
INFO - 2018-07-29 23:15:44 --> Input Class Initialized
INFO - 2018-07-29 23:15:44 --> Language Class Initialized
ERROR - 2018-07-29 23:15:44 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-29 23:15:48 --> Config Class Initialized
INFO - 2018-07-29 23:15:48 --> Hooks Class Initialized
DEBUG - 2018-07-29 23:15:48 --> UTF-8 Support Enabled
INFO - 2018-07-29 23:15:48 --> Utf8 Class Initialized
INFO - 2018-07-29 23:15:48 --> URI Class Initialized
DEBUG - 2018-07-29 23:15:48 --> No URI present. Default controller set.
INFO - 2018-07-29 23:15:48 --> Router Class Initialized
INFO - 2018-07-29 23:15:48 --> Output Class Initialized
INFO - 2018-07-29 23:15:48 --> Security Class Initialized
DEBUG - 2018-07-29 23:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-29 23:15:48 --> CSRF cookie sent
INFO - 2018-07-29 23:15:48 --> Input Class Initialized
INFO - 2018-07-29 23:15:48 --> Language Class Initialized
INFO - 2018-07-29 23:15:48 --> Loader Class Initialized
INFO - 2018-07-29 23:15:48 --> Helper loaded: url_helper
INFO - 2018-07-29 23:15:48 --> Helper loaded: form_helper
INFO - 2018-07-29 23:15:48 --> Helper loaded: language_helper
DEBUG - 2018-07-29 23:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-29 23:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-29 23:15:48 --> User Agent Class Initialized
INFO - 2018-07-29 23:15:48 --> Controller Class Initialized
INFO - 2018-07-29 23:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-29 23:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-29 23:15:48 --> Pixel_Model class loaded
INFO - 2018-07-29 23:15:48 --> Database Driver Class Initialized
INFO - 2018-07-29 23:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-29 23:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-29 23:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-29 23:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-29 23:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-29 23:15:48 --> Final output sent to browser
DEBUG - 2018-07-29 23:15:48 --> Total execution time: 0.0353

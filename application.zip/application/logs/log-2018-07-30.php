<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-30 00:07:17 --> Config Class Initialized
INFO - 2018-07-30 00:07:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 00:07:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 00:07:17 --> Utf8 Class Initialized
INFO - 2018-07-30 00:07:17 --> URI Class Initialized
DEBUG - 2018-07-30 00:07:17 --> No URI present. Default controller set.
INFO - 2018-07-30 00:07:17 --> Router Class Initialized
INFO - 2018-07-30 00:07:17 --> Output Class Initialized
INFO - 2018-07-30 00:07:17 --> Security Class Initialized
DEBUG - 2018-07-30 00:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 00:07:17 --> CSRF cookie sent
INFO - 2018-07-30 00:07:17 --> Input Class Initialized
INFO - 2018-07-30 00:07:17 --> Language Class Initialized
INFO - 2018-07-30 00:07:17 --> Loader Class Initialized
INFO - 2018-07-30 00:07:17 --> Helper loaded: url_helper
INFO - 2018-07-30 00:07:17 --> Helper loaded: form_helper
INFO - 2018-07-30 00:07:17 --> Helper loaded: language_helper
DEBUG - 2018-07-30 00:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 00:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 00:07:17 --> User Agent Class Initialized
INFO - 2018-07-30 00:07:17 --> Controller Class Initialized
INFO - 2018-07-30 00:07:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 00:07:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 00:07:17 --> Pixel_Model class loaded
INFO - 2018-07-30 00:07:17 --> Database Driver Class Initialized
INFO - 2018-07-30 00:07:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 00:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 00:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 00:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 00:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 00:07:17 --> Final output sent to browser
DEBUG - 2018-07-30 00:07:17 --> Total execution time: 0.0336
INFO - 2018-07-30 00:36:16 --> Config Class Initialized
INFO - 2018-07-30 00:36:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 00:36:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 00:36:16 --> Utf8 Class Initialized
INFO - 2018-07-30 00:36:16 --> URI Class Initialized
DEBUG - 2018-07-30 00:36:16 --> No URI present. Default controller set.
INFO - 2018-07-30 00:36:16 --> Router Class Initialized
INFO - 2018-07-30 00:36:16 --> Output Class Initialized
INFO - 2018-07-30 00:36:16 --> Security Class Initialized
DEBUG - 2018-07-30 00:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 00:36:16 --> CSRF cookie sent
INFO - 2018-07-30 00:36:16 --> Input Class Initialized
INFO - 2018-07-30 00:36:16 --> Language Class Initialized
INFO - 2018-07-30 00:36:16 --> Loader Class Initialized
INFO - 2018-07-30 00:36:16 --> Helper loaded: url_helper
INFO - 2018-07-30 00:36:16 --> Helper loaded: form_helper
INFO - 2018-07-30 00:36:16 --> Helper loaded: language_helper
DEBUG - 2018-07-30 00:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 00:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 00:36:16 --> User Agent Class Initialized
INFO - 2018-07-30 00:36:16 --> Controller Class Initialized
INFO - 2018-07-30 00:36:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 00:36:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 00:36:16 --> Pixel_Model class loaded
INFO - 2018-07-30 00:36:16 --> Database Driver Class Initialized
INFO - 2018-07-30 00:36:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 00:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 00:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 00:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 00:36:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 00:36:16 --> Final output sent to browser
DEBUG - 2018-07-30 00:36:16 --> Total execution time: 0.0351
INFO - 2018-07-30 01:53:04 --> Config Class Initialized
INFO - 2018-07-30 01:53:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 01:53:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 01:53:04 --> Utf8 Class Initialized
INFO - 2018-07-30 01:53:04 --> URI Class Initialized
DEBUG - 2018-07-30 01:53:04 --> No URI present. Default controller set.
INFO - 2018-07-30 01:53:04 --> Router Class Initialized
INFO - 2018-07-30 01:53:04 --> Output Class Initialized
INFO - 2018-07-30 01:53:04 --> Security Class Initialized
DEBUG - 2018-07-30 01:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 01:53:04 --> CSRF cookie sent
INFO - 2018-07-30 01:53:04 --> Input Class Initialized
INFO - 2018-07-30 01:53:04 --> Language Class Initialized
INFO - 2018-07-30 01:53:04 --> Loader Class Initialized
INFO - 2018-07-30 01:53:04 --> Helper loaded: url_helper
INFO - 2018-07-30 01:53:04 --> Helper loaded: form_helper
INFO - 2018-07-30 01:53:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 01:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 01:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 01:53:04 --> User Agent Class Initialized
INFO - 2018-07-30 01:53:04 --> Controller Class Initialized
INFO - 2018-07-30 01:53:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 01:53:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 01:53:04 --> Pixel_Model class loaded
INFO - 2018-07-30 01:53:04 --> Database Driver Class Initialized
INFO - 2018-07-30 01:53:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 01:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 01:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 01:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 01:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 01:53:04 --> Final output sent to browser
DEBUG - 2018-07-30 01:53:04 --> Total execution time: 0.0352
INFO - 2018-07-30 03:33:33 --> Config Class Initialized
INFO - 2018-07-30 03:33:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 03:33:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 03:33:33 --> Utf8 Class Initialized
INFO - 2018-07-30 03:33:33 --> URI Class Initialized
DEBUG - 2018-07-30 03:33:33 --> No URI present. Default controller set.
INFO - 2018-07-30 03:33:33 --> Router Class Initialized
INFO - 2018-07-30 03:33:33 --> Output Class Initialized
INFO - 2018-07-30 03:33:33 --> Security Class Initialized
DEBUG - 2018-07-30 03:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 03:33:33 --> CSRF cookie sent
INFO - 2018-07-30 03:33:33 --> Input Class Initialized
INFO - 2018-07-30 03:33:33 --> Language Class Initialized
INFO - 2018-07-30 03:33:33 --> Loader Class Initialized
INFO - 2018-07-30 03:33:33 --> Helper loaded: url_helper
INFO - 2018-07-30 03:33:33 --> Helper loaded: form_helper
INFO - 2018-07-30 03:33:33 --> Helper loaded: language_helper
DEBUG - 2018-07-30 03:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 03:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 03:33:34 --> User Agent Class Initialized
INFO - 2018-07-30 03:33:34 --> Controller Class Initialized
INFO - 2018-07-30 03:33:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 03:33:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 03:33:34 --> Pixel_Model class loaded
INFO - 2018-07-30 03:33:34 --> Database Driver Class Initialized
INFO - 2018-07-30 03:33:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 03:33:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 03:33:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 03:33:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 03:33:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 03:33:34 --> Final output sent to browser
DEBUG - 2018-07-30 03:33:34 --> Total execution time: 0.0347
INFO - 2018-07-30 09:54:40 --> Config Class Initialized
INFO - 2018-07-30 09:54:40 --> Hooks Class Initialized
DEBUG - 2018-07-30 09:54:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 09:54:40 --> Utf8 Class Initialized
INFO - 2018-07-30 09:54:40 --> URI Class Initialized
DEBUG - 2018-07-30 09:54:40 --> No URI present. Default controller set.
INFO - 2018-07-30 09:54:40 --> Router Class Initialized
INFO - 2018-07-30 09:54:40 --> Output Class Initialized
INFO - 2018-07-30 09:54:40 --> Security Class Initialized
DEBUG - 2018-07-30 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 09:54:40 --> CSRF cookie sent
INFO - 2018-07-30 09:54:40 --> Input Class Initialized
INFO - 2018-07-30 09:54:40 --> Language Class Initialized
INFO - 2018-07-30 09:54:40 --> Loader Class Initialized
INFO - 2018-07-30 09:54:40 --> Helper loaded: url_helper
INFO - 2018-07-30 09:54:40 --> Helper loaded: form_helper
INFO - 2018-07-30 09:54:40 --> Helper loaded: language_helper
DEBUG - 2018-07-30 09:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 09:54:40 --> User Agent Class Initialized
INFO - 2018-07-30 09:54:40 --> Controller Class Initialized
INFO - 2018-07-30 09:54:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 09:54:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 09:54:40 --> Pixel_Model class loaded
INFO - 2018-07-30 09:54:40 --> Database Driver Class Initialized
INFO - 2018-07-30 09:54:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 09:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 09:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 09:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 09:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 09:54:40 --> Final output sent to browser
DEBUG - 2018-07-30 09:54:40 --> Total execution time: 0.0483
INFO - 2018-07-30 14:37:51 --> Config Class Initialized
INFO - 2018-07-30 14:37:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:37:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:37:51 --> Utf8 Class Initialized
INFO - 2018-07-30 14:37:51 --> URI Class Initialized
DEBUG - 2018-07-30 14:37:51 --> No URI present. Default controller set.
INFO - 2018-07-30 14:37:51 --> Router Class Initialized
INFO - 2018-07-30 14:37:51 --> Output Class Initialized
INFO - 2018-07-30 14:37:51 --> Security Class Initialized
DEBUG - 2018-07-30 14:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:37:51 --> CSRF cookie sent
INFO - 2018-07-30 14:37:51 --> Input Class Initialized
INFO - 2018-07-30 14:37:51 --> Language Class Initialized
INFO - 2018-07-30 14:37:51 --> Loader Class Initialized
INFO - 2018-07-30 14:37:51 --> Helper loaded: url_helper
INFO - 2018-07-30 14:37:51 --> Helper loaded: form_helper
INFO - 2018-07-30 14:37:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:37:51 --> User Agent Class Initialized
INFO - 2018-07-30 14:37:51 --> Controller Class Initialized
INFO - 2018-07-30 14:37:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:37:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:37:51 --> Pixel_Model class loaded
INFO - 2018-07-30 14:37:51 --> Database Driver Class Initialized
INFO - 2018-07-30 14:37:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 14:37:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:37:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:37:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 14:37:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:37:51 --> Final output sent to browser
DEBUG - 2018-07-30 14:37:51 --> Total execution time: 0.1600
INFO - 2018-07-30 14:38:07 --> Config Class Initialized
INFO - 2018-07-30 14:38:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:38:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:38:07 --> Utf8 Class Initialized
INFO - 2018-07-30 14:38:07 --> URI Class Initialized
INFO - 2018-07-30 14:38:07 --> Router Class Initialized
INFO - 2018-07-30 14:38:07 --> Output Class Initialized
INFO - 2018-07-30 14:38:07 --> Security Class Initialized
DEBUG - 2018-07-30 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:38:07 --> CSRF cookie sent
INFO - 2018-07-30 14:38:07 --> Input Class Initialized
INFO - 2018-07-30 14:38:07 --> Language Class Initialized
INFO - 2018-07-30 14:38:07 --> Loader Class Initialized
INFO - 2018-07-30 14:38:07 --> Helper loaded: url_helper
INFO - 2018-07-30 14:38:07 --> Helper loaded: form_helper
INFO - 2018-07-30 14:38:07 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:38:07 --> User Agent Class Initialized
INFO - 2018-07-30 14:38:07 --> Controller Class Initialized
INFO - 2018-07-30 14:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:38:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:38:07 --> Pixel_Model class loaded
INFO - 2018-07-30 14:38:07 --> Database Driver Class Initialized
INFO - 2018-07-30 14:38:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 14:38:07 --> Config Class Initialized
INFO - 2018-07-30 14:38:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:38:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:38:08 --> Utf8 Class Initialized
INFO - 2018-07-30 14:38:08 --> URI Class Initialized
INFO - 2018-07-30 14:38:08 --> Router Class Initialized
INFO - 2018-07-30 14:38:08 --> Output Class Initialized
INFO - 2018-07-30 14:38:08 --> Security Class Initialized
DEBUG - 2018-07-30 14:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:38:08 --> CSRF cookie sent
INFO - 2018-07-30 14:38:08 --> Input Class Initialized
INFO - 2018-07-30 14:38:08 --> Language Class Initialized
INFO - 2018-07-30 14:38:08 --> Loader Class Initialized
INFO - 2018-07-30 14:38:08 --> Helper loaded: url_helper
INFO - 2018-07-30 14:38:08 --> Helper loaded: form_helper
INFO - 2018-07-30 14:38:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:38:08 --> User Agent Class Initialized
INFO - 2018-07-30 14:38:08 --> Controller Class Initialized
INFO - 2018-07-30 14:38:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:38:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 14:38:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 14:38:08 --> Could not find the language line "req_email"
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 14:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:38:08 --> Final output sent to browser
DEBUG - 2018-07-30 14:38:08 --> Total execution time: 0.0341
INFO - 2018-07-30 14:38:09 --> Config Class Initialized
INFO - 2018-07-30 14:38:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:38:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:38:09 --> Utf8 Class Initialized
INFO - 2018-07-30 14:38:09 --> URI Class Initialized
INFO - 2018-07-30 14:38:09 --> Router Class Initialized
INFO - 2018-07-30 14:38:09 --> Output Class Initialized
INFO - 2018-07-30 14:38:09 --> Security Class Initialized
DEBUG - 2018-07-30 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:38:09 --> CSRF cookie sent
INFO - 2018-07-30 14:38:09 --> Input Class Initialized
INFO - 2018-07-30 14:38:09 --> Language Class Initialized
INFO - 2018-07-30 14:38:09 --> Loader Class Initialized
INFO - 2018-07-30 14:38:09 --> Helper loaded: url_helper
INFO - 2018-07-30 14:38:09 --> Helper loaded: form_helper
INFO - 2018-07-30 14:38:09 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:38:09 --> User Agent Class Initialized
INFO - 2018-07-30 14:38:09 --> Controller Class Initialized
INFO - 2018-07-30 14:38:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:38:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-30 14:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:38:09 --> Final output sent to browser
DEBUG - 2018-07-30 14:38:09 --> Total execution time: 0.0244
INFO - 2018-07-30 14:38:14 --> Config Class Initialized
INFO - 2018-07-30 14:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:38:14 --> Utf8 Class Initialized
INFO - 2018-07-30 14:38:14 --> URI Class Initialized
INFO - 2018-07-30 14:38:14 --> Router Class Initialized
INFO - 2018-07-30 14:38:14 --> Output Class Initialized
INFO - 2018-07-30 14:38:14 --> Security Class Initialized
DEBUG - 2018-07-30 14:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:38:14 --> CSRF cookie sent
INFO - 2018-07-30 14:38:14 --> Input Class Initialized
INFO - 2018-07-30 14:38:14 --> Language Class Initialized
INFO - 2018-07-30 14:38:14 --> Loader Class Initialized
INFO - 2018-07-30 14:38:14 --> Helper loaded: url_helper
INFO - 2018-07-30 14:38:14 --> Helper loaded: form_helper
INFO - 2018-07-30 14:38:14 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:38:14 --> User Agent Class Initialized
INFO - 2018-07-30 14:38:14 --> Controller Class Initialized
INFO - 2018-07-30 14:38:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:38:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-30 14:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:38:14 --> Final output sent to browser
DEBUG - 2018-07-30 14:38:14 --> Total execution time: 0.0240
INFO - 2018-07-30 14:38:59 --> Config Class Initialized
INFO - 2018-07-30 14:38:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:38:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:38:59 --> Utf8 Class Initialized
INFO - 2018-07-30 14:38:59 --> URI Class Initialized
INFO - 2018-07-30 14:38:59 --> Router Class Initialized
INFO - 2018-07-30 14:38:59 --> Output Class Initialized
INFO - 2018-07-30 14:38:59 --> Security Class Initialized
DEBUG - 2018-07-30 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:38:59 --> CSRF cookie sent
INFO - 2018-07-30 14:38:59 --> Input Class Initialized
INFO - 2018-07-30 14:38:59 --> Language Class Initialized
INFO - 2018-07-30 14:38:59 --> Loader Class Initialized
INFO - 2018-07-30 14:38:59 --> Helper loaded: url_helper
INFO - 2018-07-30 14:38:59 --> Helper loaded: form_helper
INFO - 2018-07-30 14:38:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:38:59 --> User Agent Class Initialized
INFO - 2018-07-30 14:38:59 --> Controller Class Initialized
INFO - 2018-07-30 14:38:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:38:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-30 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:38:59 --> Final output sent to browser
DEBUG - 2018-07-30 14:38:59 --> Total execution time: 0.0229
INFO - 2018-07-30 14:39:06 --> Config Class Initialized
INFO - 2018-07-30 14:39:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:39:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:39:06 --> Utf8 Class Initialized
INFO - 2018-07-30 14:39:06 --> URI Class Initialized
DEBUG - 2018-07-30 14:39:06 --> No URI present. Default controller set.
INFO - 2018-07-30 14:39:06 --> Router Class Initialized
INFO - 2018-07-30 14:39:06 --> Output Class Initialized
INFO - 2018-07-30 14:39:06 --> Security Class Initialized
DEBUG - 2018-07-30 14:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:39:06 --> CSRF cookie sent
INFO - 2018-07-30 14:39:06 --> Input Class Initialized
INFO - 2018-07-30 14:39:06 --> Language Class Initialized
INFO - 2018-07-30 14:39:06 --> Loader Class Initialized
INFO - 2018-07-30 14:39:06 --> Helper loaded: url_helper
INFO - 2018-07-30 14:39:06 --> Helper loaded: form_helper
INFO - 2018-07-30 14:39:06 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:39:06 --> User Agent Class Initialized
INFO - 2018-07-30 14:39:06 --> Controller Class Initialized
INFO - 2018-07-30 14:39:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:39:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:39:06 --> Pixel_Model class loaded
INFO - 2018-07-30 14:39:06 --> Database Driver Class Initialized
INFO - 2018-07-30 14:39:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 14:39:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:39:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:39:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 14:39:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:39:06 --> Final output sent to browser
DEBUG - 2018-07-30 14:39:06 --> Total execution time: 0.0400
INFO - 2018-07-30 14:39:21 --> Config Class Initialized
INFO - 2018-07-30 14:39:21 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:39:21 --> Utf8 Class Initialized
INFO - 2018-07-30 14:39:21 --> URI Class Initialized
INFO - 2018-07-30 14:39:21 --> Router Class Initialized
INFO - 2018-07-30 14:39:21 --> Output Class Initialized
INFO - 2018-07-30 14:39:21 --> Security Class Initialized
DEBUG - 2018-07-30 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:39:21 --> CSRF cookie sent
INFO - 2018-07-30 14:39:21 --> CSRF token verified
INFO - 2018-07-30 14:39:21 --> Input Class Initialized
INFO - 2018-07-30 14:39:21 --> Language Class Initialized
INFO - 2018-07-30 14:39:21 --> Loader Class Initialized
INFO - 2018-07-30 14:39:21 --> Helper loaded: url_helper
INFO - 2018-07-30 14:39:21 --> Helper loaded: form_helper
INFO - 2018-07-30 14:39:21 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:39:21 --> User Agent Class Initialized
INFO - 2018-07-30 14:39:21 --> Controller Class Initialized
INFO - 2018-07-30 14:39:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:39:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 14:39:21 --> Pixel_Model class loaded
INFO - 2018-07-30 14:39:21 --> Database Driver Class Initialized
INFO - 2018-07-30 14:39:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 14:39:21 --> Config Class Initialized
INFO - 2018-07-30 14:39:21 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 14:39:21 --> Utf8 Class Initialized
INFO - 2018-07-30 14:39:21 --> URI Class Initialized
INFO - 2018-07-30 14:39:21 --> Router Class Initialized
INFO - 2018-07-30 14:39:21 --> Output Class Initialized
INFO - 2018-07-30 14:39:21 --> Security Class Initialized
DEBUG - 2018-07-30 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 14:39:21 --> CSRF cookie sent
INFO - 2018-07-30 14:39:21 --> Input Class Initialized
INFO - 2018-07-30 14:39:21 --> Language Class Initialized
INFO - 2018-07-30 14:39:21 --> Loader Class Initialized
INFO - 2018-07-30 14:39:21 --> Helper loaded: url_helper
INFO - 2018-07-30 14:39:21 --> Helper loaded: form_helper
INFO - 2018-07-30 14:39:21 --> Helper loaded: language_helper
DEBUG - 2018-07-30 14:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 14:39:21 --> User Agent Class Initialized
INFO - 2018-07-30 14:39:21 --> Controller Class Initialized
INFO - 2018-07-30 14:39:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 14:39:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 14:39:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 14:39:21 --> Could not find the language line "req_email"
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 14:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 14:39:21 --> Final output sent to browser
DEBUG - 2018-07-30 14:39:21 --> Total execution time: 0.0220
INFO - 2018-07-30 15:34:18 --> Config Class Initialized
INFO - 2018-07-30 15:34:18 --> Hooks Class Initialized
DEBUG - 2018-07-30 15:34:18 --> UTF-8 Support Enabled
INFO - 2018-07-30 15:34:18 --> Utf8 Class Initialized
INFO - 2018-07-30 15:34:18 --> URI Class Initialized
INFO - 2018-07-30 15:34:18 --> Router Class Initialized
INFO - 2018-07-30 15:34:18 --> Output Class Initialized
INFO - 2018-07-30 15:34:18 --> Security Class Initialized
DEBUG - 2018-07-30 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 15:34:18 --> CSRF cookie sent
INFO - 2018-07-30 15:34:18 --> Input Class Initialized
INFO - 2018-07-30 15:34:18 --> Language Class Initialized
INFO - 2018-07-30 15:34:18 --> Loader Class Initialized
INFO - 2018-07-30 15:34:18 --> Helper loaded: url_helper
INFO - 2018-07-30 15:34:18 --> Helper loaded: form_helper
INFO - 2018-07-30 15:34:18 --> Helper loaded: language_helper
DEBUG - 2018-07-30 15:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 15:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 15:34:18 --> User Agent Class Initialized
INFO - 2018-07-30 15:34:18 --> Controller Class Initialized
INFO - 2018-07-30 15:34:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 15:34:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 15:34:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 15:34:18 --> Could not find the language line "req_email"
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 15:34:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 15:34:18 --> Final output sent to browser
DEBUG - 2018-07-30 15:34:18 --> Total execution time: 0.0320
INFO - 2018-07-30 18:01:16 --> Config Class Initialized
INFO - 2018-07-30 18:01:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 18:01:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 18:01:16 --> Utf8 Class Initialized
INFO - 2018-07-30 18:01:16 --> URI Class Initialized
DEBUG - 2018-07-30 18:01:16 --> No URI present. Default controller set.
INFO - 2018-07-30 18:01:16 --> Router Class Initialized
INFO - 2018-07-30 18:01:16 --> Output Class Initialized
INFO - 2018-07-30 18:01:16 --> Security Class Initialized
DEBUG - 2018-07-30 18:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 18:01:16 --> CSRF cookie sent
INFO - 2018-07-30 18:01:16 --> Input Class Initialized
INFO - 2018-07-30 18:01:16 --> Language Class Initialized
INFO - 2018-07-30 18:01:16 --> Loader Class Initialized
INFO - 2018-07-30 18:01:16 --> Helper loaded: url_helper
INFO - 2018-07-30 18:01:16 --> Helper loaded: form_helper
INFO - 2018-07-30 18:01:16 --> Helper loaded: language_helper
DEBUG - 2018-07-30 18:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 18:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 18:01:16 --> User Agent Class Initialized
INFO - 2018-07-30 18:01:16 --> Controller Class Initialized
INFO - 2018-07-30 18:01:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 18:01:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 18:01:16 --> Pixel_Model class loaded
INFO - 2018-07-30 18:01:16 --> Database Driver Class Initialized
INFO - 2018-07-30 18:01:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 18:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 18:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 18:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 18:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 18:01:16 --> Final output sent to browser
DEBUG - 2018-07-30 18:01:16 --> Total execution time: 0.0659
INFO - 2018-07-30 19:56:35 --> Config Class Initialized
INFO - 2018-07-30 19:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 19:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 19:56:35 --> Utf8 Class Initialized
INFO - 2018-07-30 19:56:35 --> URI Class Initialized
DEBUG - 2018-07-30 19:56:35 --> No URI present. Default controller set.
INFO - 2018-07-30 19:56:35 --> Router Class Initialized
INFO - 2018-07-30 19:56:35 --> Output Class Initialized
INFO - 2018-07-30 19:56:35 --> Security Class Initialized
DEBUG - 2018-07-30 19:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 19:56:35 --> CSRF cookie sent
INFO - 2018-07-30 19:56:35 --> Input Class Initialized
INFO - 2018-07-30 19:56:35 --> Language Class Initialized
INFO - 2018-07-30 19:56:35 --> Loader Class Initialized
INFO - 2018-07-30 19:56:35 --> Helper loaded: url_helper
INFO - 2018-07-30 19:56:35 --> Helper loaded: form_helper
INFO - 2018-07-30 19:56:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 19:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 19:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 19:56:35 --> User Agent Class Initialized
INFO - 2018-07-30 19:56:35 --> Controller Class Initialized
INFO - 2018-07-30 19:56:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 19:56:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 19:56:35 --> Pixel_Model class loaded
INFO - 2018-07-30 19:56:35 --> Database Driver Class Initialized
INFO - 2018-07-30 19:56:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 19:56:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 19:56:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 19:56:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 19:56:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 19:56:35 --> Final output sent to browser
DEBUG - 2018-07-30 19:56:35 --> Total execution time: 0.0446
INFO - 2018-07-30 20:08:27 --> Config Class Initialized
INFO - 2018-07-30 20:08:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:08:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:08:27 --> Utf8 Class Initialized
INFO - 2018-07-30 20:08:27 --> URI Class Initialized
INFO - 2018-07-30 20:08:27 --> Router Class Initialized
INFO - 2018-07-30 20:08:27 --> Output Class Initialized
INFO - 2018-07-30 20:08:27 --> Security Class Initialized
DEBUG - 2018-07-30 20:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:08:27 --> CSRF cookie sent
INFO - 2018-07-30 20:08:27 --> Input Class Initialized
INFO - 2018-07-30 20:08:27 --> Language Class Initialized
INFO - 2018-07-30 20:08:27 --> Loader Class Initialized
INFO - 2018-07-30 20:08:27 --> Helper loaded: url_helper
INFO - 2018-07-30 20:08:27 --> Helper loaded: form_helper
INFO - 2018-07-30 20:08:27 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:08:27 --> User Agent Class Initialized
INFO - 2018-07-30 20:08:27 --> Controller Class Initialized
INFO - 2018-07-30 20:08:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:08:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:08:27 --> Final output sent to browser
DEBUG - 2018-07-30 20:08:27 --> Total execution time: 0.0234
INFO - 2018-07-30 20:08:27 --> Config Class Initialized
INFO - 2018-07-30 20:08:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:08:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:08:27 --> Utf8 Class Initialized
INFO - 2018-07-30 20:08:27 --> URI Class Initialized
INFO - 2018-07-30 20:08:27 --> Router Class Initialized
INFO - 2018-07-30 20:08:27 --> Output Class Initialized
INFO - 2018-07-30 20:08:27 --> Security Class Initialized
DEBUG - 2018-07-30 20:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:08:27 --> CSRF cookie sent
INFO - 2018-07-30 20:08:27 --> Input Class Initialized
INFO - 2018-07-30 20:08:27 --> Language Class Initialized
INFO - 2018-07-30 20:08:27 --> Loader Class Initialized
INFO - 2018-07-30 20:08:27 --> Helper loaded: url_helper
INFO - 2018-07-30 20:08:27 --> Helper loaded: form_helper
INFO - 2018-07-30 20:08:27 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:08:27 --> User Agent Class Initialized
INFO - 2018-07-30 20:08:27 --> Controller Class Initialized
INFO - 2018-07-30 20:08:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:08:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-30 20:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:08:27 --> Final output sent to browser
DEBUG - 2018-07-30 20:08:27 --> Total execution time: 0.0274
INFO - 2018-07-30 20:22:41 --> Config Class Initialized
INFO - 2018-07-30 20:22:41 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:41 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:41 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:41 --> URI Class Initialized
DEBUG - 2018-07-30 20:22:41 --> No URI present. Default controller set.
INFO - 2018-07-30 20:22:41 --> Router Class Initialized
INFO - 2018-07-30 20:22:41 --> Output Class Initialized
INFO - 2018-07-30 20:22:41 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:41 --> CSRF cookie sent
INFO - 2018-07-30 20:22:41 --> Input Class Initialized
INFO - 2018-07-30 20:22:41 --> Language Class Initialized
INFO - 2018-07-30 20:22:41 --> Loader Class Initialized
INFO - 2018-07-30 20:22:41 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:41 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:41 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:41 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:41 --> Controller Class Initialized
INFO - 2018-07-30 20:22:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:41 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:41 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 20:22:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:41 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:41 --> Total execution time: 0.0364
INFO - 2018-07-30 20:22:46 --> Config Class Initialized
INFO - 2018-07-30 20:22:46 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:46 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:46 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:46 --> URI Class Initialized
INFO - 2018-07-30 20:22:46 --> Router Class Initialized
INFO - 2018-07-30 20:22:46 --> Output Class Initialized
INFO - 2018-07-30 20:22:46 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:46 --> CSRF cookie sent
INFO - 2018-07-30 20:22:46 --> Input Class Initialized
INFO - 2018-07-30 20:22:46 --> Language Class Initialized
INFO - 2018-07-30 20:22:46 --> Loader Class Initialized
INFO - 2018-07-30 20:22:46 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:46 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:46 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:46 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:46 --> Controller Class Initialized
INFO - 2018-07-30 20:22:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:46 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:46 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-30 20:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:46 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:46 --> Total execution time: 0.0407
INFO - 2018-07-30 20:22:47 --> Config Class Initialized
INFO - 2018-07-30 20:22:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:47 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:47 --> URI Class Initialized
INFO - 2018-07-30 20:22:47 --> Router Class Initialized
INFO - 2018-07-30 20:22:47 --> Output Class Initialized
INFO - 2018-07-30 20:22:47 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:47 --> CSRF cookie sent
INFO - 2018-07-30 20:22:47 --> CSRF token verified
INFO - 2018-07-30 20:22:47 --> Input Class Initialized
INFO - 2018-07-30 20:22:47 --> Language Class Initialized
INFO - 2018-07-30 20:22:47 --> Loader Class Initialized
INFO - 2018-07-30 20:22:47 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:47 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:47 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:47 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:47 --> Controller Class Initialized
INFO - 2018-07-30 20:22:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:47 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:48 --> Config Class Initialized
INFO - 2018-07-30 20:22:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:48 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:48 --> URI Class Initialized
INFO - 2018-07-30 20:22:48 --> Router Class Initialized
INFO - 2018-07-30 20:22:48 --> Output Class Initialized
INFO - 2018-07-30 20:22:48 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:48 --> CSRF cookie sent
INFO - 2018-07-30 20:22:48 --> Input Class Initialized
INFO - 2018-07-30 20:22:48 --> Language Class Initialized
INFO - 2018-07-30 20:22:48 --> Loader Class Initialized
INFO - 2018-07-30 20:22:48 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:48 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:48 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:48 --> Controller Class Initialized
INFO - 2018-07-30 20:22:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:48 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-30 20:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:48 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:48 --> Total execution time: 0.0416
INFO - 2018-07-30 20:22:51 --> Config Class Initialized
INFO - 2018-07-30 20:22:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:51 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:51 --> URI Class Initialized
INFO - 2018-07-30 20:22:51 --> Router Class Initialized
INFO - 2018-07-30 20:22:51 --> Output Class Initialized
INFO - 2018-07-30 20:22:51 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:51 --> CSRF cookie sent
INFO - 2018-07-30 20:22:51 --> CSRF token verified
INFO - 2018-07-30 20:22:51 --> Input Class Initialized
INFO - 2018-07-30 20:22:51 --> Language Class Initialized
INFO - 2018-07-30 20:22:51 --> Loader Class Initialized
INFO - 2018-07-30 20:22:51 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:51 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:51 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:51 --> Controller Class Initialized
INFO - 2018-07-30 20:22:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:51 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:51 --> Form Validation Class Initialized
INFO - 2018-07-30 20:22:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:22:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:51 --> Config Class Initialized
INFO - 2018-07-30 20:22:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:51 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:51 --> URI Class Initialized
INFO - 2018-07-30 20:22:51 --> Router Class Initialized
INFO - 2018-07-30 20:22:51 --> Output Class Initialized
INFO - 2018-07-30 20:22:51 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:51 --> CSRF cookie sent
INFO - 2018-07-30 20:22:51 --> Input Class Initialized
INFO - 2018-07-30 20:22:51 --> Language Class Initialized
INFO - 2018-07-30 20:22:51 --> Loader Class Initialized
INFO - 2018-07-30 20:22:51 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:51 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:51 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:51 --> Controller Class Initialized
INFO - 2018-07-30 20:22:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:51 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-30 20:22:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:51 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:51 --> Total execution time: 0.0542
INFO - 2018-07-30 20:22:53 --> Config Class Initialized
INFO - 2018-07-30 20:22:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:53 --> URI Class Initialized
INFO - 2018-07-30 20:22:53 --> Router Class Initialized
INFO - 2018-07-30 20:22:53 --> Output Class Initialized
INFO - 2018-07-30 20:22:53 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:53 --> CSRF cookie sent
INFO - 2018-07-30 20:22:53 --> CSRF token verified
INFO - 2018-07-30 20:22:53 --> Input Class Initialized
INFO - 2018-07-30 20:22:53 --> Language Class Initialized
INFO - 2018-07-30 20:22:53 --> Loader Class Initialized
INFO - 2018-07-30 20:22:53 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:53 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:53 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:53 --> Controller Class Initialized
INFO - 2018-07-30 20:22:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:53 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:53 --> Form Validation Class Initialized
INFO - 2018-07-30 20:22:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:22:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:53 --> Config Class Initialized
INFO - 2018-07-30 20:22:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:53 --> URI Class Initialized
INFO - 2018-07-30 20:22:53 --> Router Class Initialized
INFO - 2018-07-30 20:22:53 --> Output Class Initialized
INFO - 2018-07-30 20:22:53 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:53 --> CSRF cookie sent
INFO - 2018-07-30 20:22:53 --> Input Class Initialized
INFO - 2018-07-30 20:22:53 --> Language Class Initialized
INFO - 2018-07-30 20:22:53 --> Loader Class Initialized
INFO - 2018-07-30 20:22:53 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:53 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:53 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:53 --> Controller Class Initialized
INFO - 2018-07-30 20:22:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:53 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-30 20:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:53 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:53 --> Total execution time: 0.0390
INFO - 2018-07-30 20:22:53 --> Config Class Initialized
INFO - 2018-07-30 20:22:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:53 --> URI Class Initialized
INFO - 2018-07-30 20:22:54 --> Router Class Initialized
INFO - 2018-07-30 20:22:54 --> Output Class Initialized
INFO - 2018-07-30 20:22:54 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:54 --> CSRF cookie sent
INFO - 2018-07-30 20:22:54 --> CSRF token verified
INFO - 2018-07-30 20:22:54 --> Input Class Initialized
INFO - 2018-07-30 20:22:54 --> Language Class Initialized
INFO - 2018-07-30 20:22:54 --> Loader Class Initialized
INFO - 2018-07-30 20:22:54 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:54 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:54 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:54 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:54 --> Controller Class Initialized
INFO - 2018-07-30 20:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:54 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:54 --> Form Validation Class Initialized
INFO - 2018-07-30 20:22:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:22:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:54 --> Config Class Initialized
INFO - 2018-07-30 20:22:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:54 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:54 --> URI Class Initialized
INFO - 2018-07-30 20:22:54 --> Router Class Initialized
INFO - 2018-07-30 20:22:54 --> Output Class Initialized
INFO - 2018-07-30 20:22:54 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:54 --> CSRF cookie sent
INFO - 2018-07-30 20:22:54 --> Input Class Initialized
INFO - 2018-07-30 20:22:54 --> Language Class Initialized
INFO - 2018-07-30 20:22:54 --> Loader Class Initialized
INFO - 2018-07-30 20:22:54 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:54 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:54 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:54 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:54 --> Controller Class Initialized
INFO - 2018-07-30 20:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:54 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-30 20:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:54 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:54 --> Total execution time: 0.0406
INFO - 2018-07-30 20:22:58 --> Config Class Initialized
INFO - 2018-07-30 20:22:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:58 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:58 --> URI Class Initialized
INFO - 2018-07-30 20:22:58 --> Router Class Initialized
INFO - 2018-07-30 20:22:58 --> Output Class Initialized
INFO - 2018-07-30 20:22:58 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:58 --> CSRF cookie sent
INFO - 2018-07-30 20:22:58 --> CSRF token verified
INFO - 2018-07-30 20:22:58 --> Input Class Initialized
INFO - 2018-07-30 20:22:58 --> Language Class Initialized
INFO - 2018-07-30 20:22:58 --> Loader Class Initialized
INFO - 2018-07-30 20:22:58 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:58 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:58 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:58 --> Controller Class Initialized
INFO - 2018-07-30 20:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:58 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:58 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:58 --> Form Validation Class Initialized
INFO - 2018-07-30 20:22:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:22:58 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:58 --> Config Class Initialized
INFO - 2018-07-30 20:22:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:22:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:22:58 --> Utf8 Class Initialized
INFO - 2018-07-30 20:22:58 --> URI Class Initialized
INFO - 2018-07-30 20:22:58 --> Router Class Initialized
INFO - 2018-07-30 20:22:58 --> Output Class Initialized
INFO - 2018-07-30 20:22:58 --> Security Class Initialized
DEBUG - 2018-07-30 20:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:22:58 --> CSRF cookie sent
INFO - 2018-07-30 20:22:58 --> Input Class Initialized
INFO - 2018-07-30 20:22:58 --> Language Class Initialized
INFO - 2018-07-30 20:22:59 --> Loader Class Initialized
INFO - 2018-07-30 20:22:59 --> Helper loaded: url_helper
INFO - 2018-07-30 20:22:59 --> Helper loaded: form_helper
INFO - 2018-07-30 20:22:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:22:59 --> User Agent Class Initialized
INFO - 2018-07-30 20:22:59 --> Controller Class Initialized
INFO - 2018-07-30 20:22:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:22:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:22:59 --> Pixel_Model class loaded
INFO - 2018-07-30 20:22:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:22:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:22:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:22:59 --> Final output sent to browser
DEBUG - 2018-07-30 20:22:59 --> Total execution time: 0.0431
INFO - 2018-07-30 20:23:03 --> Config Class Initialized
INFO - 2018-07-30 20:23:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:03 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:03 --> URI Class Initialized
INFO - 2018-07-30 20:23:03 --> Router Class Initialized
INFO - 2018-07-30 20:23:03 --> Output Class Initialized
INFO - 2018-07-30 20:23:03 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:03 --> CSRF cookie sent
INFO - 2018-07-30 20:23:03 --> CSRF token verified
INFO - 2018-07-30 20:23:03 --> Input Class Initialized
INFO - 2018-07-30 20:23:03 --> Language Class Initialized
INFO - 2018-07-30 20:23:03 --> Loader Class Initialized
INFO - 2018-07-30 20:23:03 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:03 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:03 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:03 --> Controller Class Initialized
INFO - 2018-07-30 20:23:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:03 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:04 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:23:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:04 --> Config Class Initialized
INFO - 2018-07-30 20:23:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:04 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:04 --> URI Class Initialized
INFO - 2018-07-30 20:23:04 --> Router Class Initialized
INFO - 2018-07-30 20:23:04 --> Output Class Initialized
INFO - 2018-07-30 20:23:04 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:04 --> CSRF cookie sent
INFO - 2018-07-30 20:23:04 --> Input Class Initialized
INFO - 2018-07-30 20:23:04 --> Language Class Initialized
INFO - 2018-07-30 20:23:04 --> Loader Class Initialized
INFO - 2018-07-30 20:23:04 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:04 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:04 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:04 --> Controller Class Initialized
INFO - 2018-07-30 20:23:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:04 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:23:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:04 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:04 --> Total execution time: 0.0414
INFO - 2018-07-30 20:23:08 --> Config Class Initialized
INFO - 2018-07-30 20:23:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:08 --> URI Class Initialized
INFO - 2018-07-30 20:23:08 --> Router Class Initialized
INFO - 2018-07-30 20:23:08 --> Output Class Initialized
INFO - 2018-07-30 20:23:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:08 --> CSRF cookie sent
INFO - 2018-07-30 20:23:08 --> CSRF token verified
INFO - 2018-07-30 20:23:08 --> Input Class Initialized
INFO - 2018-07-30 20:23:08 --> Language Class Initialized
INFO - 2018-07-30 20:23:08 --> Loader Class Initialized
INFO - 2018-07-30 20:23:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:08 --> Controller Class Initialized
INFO - 2018-07-30 20:23:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:08 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:08 --> Config Class Initialized
INFO - 2018-07-30 20:23:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:08 --> URI Class Initialized
INFO - 2018-07-30 20:23:08 --> Router Class Initialized
INFO - 2018-07-30 20:23:08 --> Output Class Initialized
INFO - 2018-07-30 20:23:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:08 --> CSRF cookie sent
INFO - 2018-07-30 20:23:08 --> Input Class Initialized
INFO - 2018-07-30 20:23:08 --> Language Class Initialized
INFO - 2018-07-30 20:23:08 --> Loader Class Initialized
INFO - 2018-07-30 20:23:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:08 --> Controller Class Initialized
INFO - 2018-07-30 20:23:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:08 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:08 --> Total execution time: 0.0552
INFO - 2018-07-30 20:23:10 --> Config Class Initialized
INFO - 2018-07-30 20:23:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:10 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:10 --> URI Class Initialized
INFO - 2018-07-30 20:23:10 --> Router Class Initialized
INFO - 2018-07-30 20:23:10 --> Output Class Initialized
INFO - 2018-07-30 20:23:10 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:10 --> CSRF cookie sent
INFO - 2018-07-30 20:23:10 --> CSRF token verified
INFO - 2018-07-30 20:23:10 --> Input Class Initialized
INFO - 2018-07-30 20:23:10 --> Language Class Initialized
INFO - 2018-07-30 20:23:10 --> Loader Class Initialized
INFO - 2018-07-30 20:23:10 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:10 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:10 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:10 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:10 --> Controller Class Initialized
INFO - 2018-07-30 20:23:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:10 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:10 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:23:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:10 --> Config Class Initialized
INFO - 2018-07-30 20:23:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:10 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:10 --> URI Class Initialized
INFO - 2018-07-30 20:23:10 --> Router Class Initialized
INFO - 2018-07-30 20:23:10 --> Output Class Initialized
INFO - 2018-07-30 20:23:10 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:10 --> CSRF cookie sent
INFO - 2018-07-30 20:23:10 --> Input Class Initialized
INFO - 2018-07-30 20:23:10 --> Language Class Initialized
INFO - 2018-07-30 20:23:10 --> Loader Class Initialized
INFO - 2018-07-30 20:23:10 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:10 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:10 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:10 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:10 --> Controller Class Initialized
INFO - 2018-07-30 20:23:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:10 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-30 20:23:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:10 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:10 --> Total execution time: 0.0472
INFO - 2018-07-30 20:23:12 --> Config Class Initialized
INFO - 2018-07-30 20:23:12 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:12 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:12 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:12 --> URI Class Initialized
INFO - 2018-07-30 20:23:12 --> Router Class Initialized
INFO - 2018-07-30 20:23:12 --> Output Class Initialized
INFO - 2018-07-30 20:23:12 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:12 --> CSRF cookie sent
INFO - 2018-07-30 20:23:12 --> Input Class Initialized
INFO - 2018-07-30 20:23:12 --> Language Class Initialized
INFO - 2018-07-30 20:23:12 --> Loader Class Initialized
INFO - 2018-07-30 20:23:12 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:12 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:12 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:12 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:12 --> Controller Class Initialized
INFO - 2018-07-30 20:23:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:12 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:12 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:12 --> Total execution time: 0.0449
INFO - 2018-07-30 20:23:13 --> Config Class Initialized
INFO - 2018-07-30 20:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:13 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:13 --> URI Class Initialized
INFO - 2018-07-30 20:23:13 --> Router Class Initialized
INFO - 2018-07-30 20:23:13 --> Output Class Initialized
INFO - 2018-07-30 20:23:13 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:13 --> CSRF cookie sent
INFO - 2018-07-30 20:23:13 --> Input Class Initialized
INFO - 2018-07-30 20:23:13 --> Language Class Initialized
INFO - 2018-07-30 20:23:13 --> Loader Class Initialized
INFO - 2018-07-30 20:23:13 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:13 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:13 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:13 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:13 --> Controller Class Initialized
INFO - 2018-07-30 20:23:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:13 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:13 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:13 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-30 20:23:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:13 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:13 --> Total execution time: 0.0547
INFO - 2018-07-30 20:23:15 --> Config Class Initialized
INFO - 2018-07-30 20:23:15 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:15 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:15 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:15 --> URI Class Initialized
INFO - 2018-07-30 20:23:15 --> Router Class Initialized
INFO - 2018-07-30 20:23:15 --> Output Class Initialized
INFO - 2018-07-30 20:23:15 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:15 --> CSRF cookie sent
INFO - 2018-07-30 20:23:15 --> CSRF token verified
INFO - 2018-07-30 20:23:15 --> Input Class Initialized
INFO - 2018-07-30 20:23:15 --> Language Class Initialized
INFO - 2018-07-30 20:23:15 --> Loader Class Initialized
INFO - 2018-07-30 20:23:15 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:15 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:15 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:15 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:15 --> Controller Class Initialized
INFO - 2018-07-30 20:23:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:15 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:15 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:23:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:15 --> Config Class Initialized
INFO - 2018-07-30 20:23:15 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:15 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:15 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:15 --> URI Class Initialized
INFO - 2018-07-30 20:23:15 --> Router Class Initialized
INFO - 2018-07-30 20:23:15 --> Output Class Initialized
INFO - 2018-07-30 20:23:15 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:15 --> CSRF cookie sent
INFO - 2018-07-30 20:23:15 --> Input Class Initialized
INFO - 2018-07-30 20:23:15 --> Language Class Initialized
INFO - 2018-07-30 20:23:15 --> Loader Class Initialized
INFO - 2018-07-30 20:23:15 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:15 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:15 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:15 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:15 --> Controller Class Initialized
INFO - 2018-07-30 20:23:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:15 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:23:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:15 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:15 --> Total execution time: 0.0468
INFO - 2018-07-30 20:23:16 --> Config Class Initialized
INFO - 2018-07-30 20:23:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:16 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:16 --> URI Class Initialized
INFO - 2018-07-30 20:23:16 --> Router Class Initialized
INFO - 2018-07-30 20:23:16 --> Output Class Initialized
INFO - 2018-07-30 20:23:16 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:16 --> CSRF cookie sent
INFO - 2018-07-30 20:23:16 --> CSRF token verified
INFO - 2018-07-30 20:23:16 --> Input Class Initialized
INFO - 2018-07-30 20:23:16 --> Language Class Initialized
INFO - 2018-07-30 20:23:16 --> Loader Class Initialized
INFO - 2018-07-30 20:23:16 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:16 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:16 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:16 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:16 --> Controller Class Initialized
INFO - 2018-07-30 20:23:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:16 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:16 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:16 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:23:16 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:16 --> Config Class Initialized
INFO - 2018-07-30 20:23:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:16 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:16 --> URI Class Initialized
INFO - 2018-07-30 20:23:16 --> Router Class Initialized
INFO - 2018-07-30 20:23:16 --> Output Class Initialized
INFO - 2018-07-30 20:23:16 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:16 --> CSRF cookie sent
INFO - 2018-07-30 20:23:16 --> Input Class Initialized
INFO - 2018-07-30 20:23:16 --> Language Class Initialized
INFO - 2018-07-30 20:23:16 --> Loader Class Initialized
INFO - 2018-07-30 20:23:16 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:16 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:16 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:16 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:16 --> Controller Class Initialized
INFO - 2018-07-30 20:23:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:16 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:16 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:17 --> Config Class Initialized
INFO - 2018-07-30 20:23:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:17 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:17 --> URI Class Initialized
INFO - 2018-07-30 20:23:17 --> Router Class Initialized
INFO - 2018-07-30 20:23:17 --> Output Class Initialized
INFO - 2018-07-30 20:23:17 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:17 --> CSRF cookie sent
INFO - 2018-07-30 20:23:17 --> Input Class Initialized
INFO - 2018-07-30 20:23:17 --> Language Class Initialized
INFO - 2018-07-30 20:23:17 --> Loader Class Initialized
INFO - 2018-07-30 20:23:17 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:17 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:17 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:17 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:17 --> Controller Class Initialized
INFO - 2018-07-30 20:23:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:17 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:17 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:17 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 20:23:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 20:23:17 --> Could not find the language line "req_email"
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 20:23:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:17 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:17 --> Total execution time: 0.0378
INFO - 2018-07-30 20:23:31 --> Config Class Initialized
INFO - 2018-07-30 20:23:31 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:31 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:31 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:31 --> URI Class Initialized
INFO - 2018-07-30 20:23:31 --> Router Class Initialized
INFO - 2018-07-30 20:23:31 --> Output Class Initialized
INFO - 2018-07-30 20:23:31 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:31 --> CSRF cookie sent
INFO - 2018-07-30 20:23:31 --> Input Class Initialized
INFO - 2018-07-30 20:23:31 --> Language Class Initialized
INFO - 2018-07-30 20:23:31 --> Loader Class Initialized
INFO - 2018-07-30 20:23:31 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:31 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:31 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:31 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:31 --> Controller Class Initialized
INFO - 2018-07-30 20:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:31 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 20:23:31 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 20:23:31 --> Could not find the language line "req_email"
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 20:23:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:31 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:31 --> Total execution time: 0.0223
INFO - 2018-07-30 20:23:35 --> Config Class Initialized
INFO - 2018-07-30 20:23:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:35 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:35 --> URI Class Initialized
INFO - 2018-07-30 20:23:35 --> Router Class Initialized
INFO - 2018-07-30 20:23:35 --> Output Class Initialized
INFO - 2018-07-30 20:23:35 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:35 --> CSRF cookie sent
INFO - 2018-07-30 20:23:35 --> CSRF token verified
INFO - 2018-07-30 20:23:35 --> Input Class Initialized
INFO - 2018-07-30 20:23:35 --> Language Class Initialized
INFO - 2018-07-30 20:23:35 --> Loader Class Initialized
INFO - 2018-07-30 20:23:35 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:35 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:35 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:35 --> Controller Class Initialized
INFO - 2018-07-30 20:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 20:23:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:23:35 --> Form Validation Class Initialized
INFO - 2018-07-30 20:23:35 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:35 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 20:23:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:35 --> Config Class Initialized
INFO - 2018-07-30 20:23:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:35 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:35 --> URI Class Initialized
INFO - 2018-07-30 20:23:35 --> Router Class Initialized
INFO - 2018-07-30 20:23:35 --> Output Class Initialized
INFO - 2018-07-30 20:23:35 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:35 --> CSRF cookie sent
INFO - 2018-07-30 20:23:35 --> Input Class Initialized
INFO - 2018-07-30 20:23:35 --> Language Class Initialized
INFO - 2018-07-30 20:23:35 --> Loader Class Initialized
INFO - 2018-07-30 20:23:35 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:35 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:35 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:35 --> Controller Class Initialized
INFO - 2018-07-30 20:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:35 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-30 20:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:35 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:35 --> Total execution time: 0.0498
INFO - 2018-07-30 20:23:58 --> Config Class Initialized
INFO - 2018-07-30 20:23:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:23:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:23:58 --> Utf8 Class Initialized
INFO - 2018-07-30 20:23:58 --> URI Class Initialized
DEBUG - 2018-07-30 20:23:58 --> No URI present. Default controller set.
INFO - 2018-07-30 20:23:58 --> Router Class Initialized
INFO - 2018-07-30 20:23:58 --> Output Class Initialized
INFO - 2018-07-30 20:23:58 --> Security Class Initialized
DEBUG - 2018-07-30 20:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:23:58 --> CSRF cookie sent
INFO - 2018-07-30 20:23:58 --> Input Class Initialized
INFO - 2018-07-30 20:23:58 --> Language Class Initialized
INFO - 2018-07-30 20:23:58 --> Loader Class Initialized
INFO - 2018-07-30 20:23:58 --> Helper loaded: url_helper
INFO - 2018-07-30 20:23:58 --> Helper loaded: form_helper
INFO - 2018-07-30 20:23:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:23:58 --> User Agent Class Initialized
INFO - 2018-07-30 20:23:58 --> Controller Class Initialized
INFO - 2018-07-30 20:23:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:23:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:23:58 --> Pixel_Model class loaded
INFO - 2018-07-30 20:23:58 --> Database Driver Class Initialized
INFO - 2018-07-30 20:23:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:23:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:23:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:23:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 20:23:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:23:58 --> Final output sent to browser
DEBUG - 2018-07-30 20:23:58 --> Total execution time: 0.0474
INFO - 2018-07-30 20:25:34 --> Config Class Initialized
INFO - 2018-07-30 20:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:34 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:34 --> URI Class Initialized
INFO - 2018-07-30 20:25:34 --> Router Class Initialized
INFO - 2018-07-30 20:25:34 --> Output Class Initialized
INFO - 2018-07-30 20:25:34 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:34 --> CSRF cookie sent
INFO - 2018-07-30 20:25:34 --> CSRF token verified
INFO - 2018-07-30 20:25:34 --> Input Class Initialized
INFO - 2018-07-30 20:25:34 --> Language Class Initialized
INFO - 2018-07-30 20:25:34 --> Loader Class Initialized
INFO - 2018-07-30 20:25:34 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:34 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:34 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:34 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:34 --> Controller Class Initialized
INFO - 2018-07-30 20:25:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:34 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:34 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:34 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:34 --> Config Class Initialized
INFO - 2018-07-30 20:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:34 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:34 --> URI Class Initialized
INFO - 2018-07-30 20:25:34 --> Router Class Initialized
INFO - 2018-07-30 20:25:34 --> Output Class Initialized
INFO - 2018-07-30 20:25:34 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:34 --> CSRF cookie sent
INFO - 2018-07-30 20:25:34 --> Input Class Initialized
INFO - 2018-07-30 20:25:34 --> Language Class Initialized
INFO - 2018-07-30 20:25:34 --> Loader Class Initialized
INFO - 2018-07-30 20:25:34 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:34 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:34 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:34 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:34 --> Controller Class Initialized
INFO - 2018-07-30 20:25:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:34 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:34 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:34 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-30 20:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:25:34 --> Final output sent to browser
DEBUG - 2018-07-30 20:25:34 --> Total execution time: 0.0435
INFO - 2018-07-30 20:25:39 --> Config Class Initialized
INFO - 2018-07-30 20:25:39 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:39 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:39 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:39 --> URI Class Initialized
INFO - 2018-07-30 20:25:39 --> Router Class Initialized
INFO - 2018-07-30 20:25:39 --> Output Class Initialized
INFO - 2018-07-30 20:25:39 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:39 --> CSRF cookie sent
INFO - 2018-07-30 20:25:39 --> CSRF token verified
INFO - 2018-07-30 20:25:39 --> Input Class Initialized
INFO - 2018-07-30 20:25:39 --> Language Class Initialized
INFO - 2018-07-30 20:25:39 --> Loader Class Initialized
INFO - 2018-07-30 20:25:39 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:39 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:39 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:39 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:39 --> Controller Class Initialized
INFO - 2018-07-30 20:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:39 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:39 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:39 --> Form Validation Class Initialized
INFO - 2018-07-30 20:25:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:25:39 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:39 --> Config Class Initialized
INFO - 2018-07-30 20:25:39 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:39 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:39 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:39 --> URI Class Initialized
INFO - 2018-07-30 20:25:39 --> Router Class Initialized
INFO - 2018-07-30 20:25:39 --> Output Class Initialized
INFO - 2018-07-30 20:25:39 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:39 --> CSRF cookie sent
INFO - 2018-07-30 20:25:39 --> Input Class Initialized
INFO - 2018-07-30 20:25:39 --> Language Class Initialized
INFO - 2018-07-30 20:25:39 --> Loader Class Initialized
INFO - 2018-07-30 20:25:39 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:39 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:39 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:39 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:39 --> Controller Class Initialized
INFO - 2018-07-30 20:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:39 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:39 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:39 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-30 20:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:25:39 --> Final output sent to browser
DEBUG - 2018-07-30 20:25:39 --> Total execution time: 0.0459
INFO - 2018-07-30 20:25:44 --> Config Class Initialized
INFO - 2018-07-30 20:25:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:44 --> URI Class Initialized
INFO - 2018-07-30 20:25:44 --> Router Class Initialized
INFO - 2018-07-30 20:25:44 --> Output Class Initialized
INFO - 2018-07-30 20:25:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:44 --> CSRF cookie sent
INFO - 2018-07-30 20:25:44 --> CSRF token verified
INFO - 2018-07-30 20:25:44 --> Input Class Initialized
INFO - 2018-07-30 20:25:44 --> Language Class Initialized
INFO - 2018-07-30 20:25:44 --> Loader Class Initialized
INFO - 2018-07-30 20:25:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:44 --> Controller Class Initialized
INFO - 2018-07-30 20:25:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:44 --> Form Validation Class Initialized
INFO - 2018-07-30 20:25:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:25:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:44 --> Config Class Initialized
INFO - 2018-07-30 20:25:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:44 --> URI Class Initialized
INFO - 2018-07-30 20:25:44 --> Router Class Initialized
INFO - 2018-07-30 20:25:44 --> Output Class Initialized
INFO - 2018-07-30 20:25:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:44 --> CSRF cookie sent
INFO - 2018-07-30 20:25:44 --> Input Class Initialized
INFO - 2018-07-30 20:25:44 --> Language Class Initialized
INFO - 2018-07-30 20:25:44 --> Loader Class Initialized
INFO - 2018-07-30 20:25:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:44 --> Controller Class Initialized
INFO - 2018-07-30 20:25:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-30 20:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:25:44 --> Final output sent to browser
DEBUG - 2018-07-30 20:25:44 --> Total execution time: 0.0362
INFO - 2018-07-30 20:25:50 --> Config Class Initialized
INFO - 2018-07-30 20:25:50 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:50 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:50 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:50 --> URI Class Initialized
INFO - 2018-07-30 20:25:50 --> Router Class Initialized
INFO - 2018-07-30 20:25:50 --> Output Class Initialized
INFO - 2018-07-30 20:25:50 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:50 --> CSRF cookie sent
INFO - 2018-07-30 20:25:50 --> CSRF token verified
INFO - 2018-07-30 20:25:50 --> Input Class Initialized
INFO - 2018-07-30 20:25:50 --> Language Class Initialized
INFO - 2018-07-30 20:25:50 --> Loader Class Initialized
INFO - 2018-07-30 20:25:50 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:50 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:50 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:50 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:50 --> Controller Class Initialized
INFO - 2018-07-30 20:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:50 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:50 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:50 --> Form Validation Class Initialized
INFO - 2018-07-30 20:25:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:25:50 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:50 --> Config Class Initialized
INFO - 2018-07-30 20:25:50 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:25:50 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:25:50 --> Utf8 Class Initialized
INFO - 2018-07-30 20:25:50 --> URI Class Initialized
INFO - 2018-07-30 20:25:50 --> Router Class Initialized
INFO - 2018-07-30 20:25:50 --> Output Class Initialized
INFO - 2018-07-30 20:25:50 --> Security Class Initialized
DEBUG - 2018-07-30 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:25:50 --> CSRF cookie sent
INFO - 2018-07-30 20:25:50 --> Input Class Initialized
INFO - 2018-07-30 20:25:50 --> Language Class Initialized
INFO - 2018-07-30 20:25:50 --> Loader Class Initialized
INFO - 2018-07-30 20:25:50 --> Helper loaded: url_helper
INFO - 2018-07-30 20:25:50 --> Helper loaded: form_helper
INFO - 2018-07-30 20:25:50 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:25:50 --> User Agent Class Initialized
INFO - 2018-07-30 20:25:50 --> Controller Class Initialized
INFO - 2018-07-30 20:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:25:50 --> Pixel_Model class loaded
INFO - 2018-07-30 20:25:50 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:50 --> Database Driver Class Initialized
INFO - 2018-07-30 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-30 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:25:50 --> Final output sent to browser
DEBUG - 2018-07-30 20:25:50 --> Total execution time: 0.0462
INFO - 2018-07-30 20:26:01 --> Config Class Initialized
INFO - 2018-07-30 20:26:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:26:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:26:01 --> Utf8 Class Initialized
INFO - 2018-07-30 20:26:01 --> URI Class Initialized
INFO - 2018-07-30 20:26:01 --> Router Class Initialized
INFO - 2018-07-30 20:26:01 --> Output Class Initialized
INFO - 2018-07-30 20:26:01 --> Security Class Initialized
DEBUG - 2018-07-30 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:26:01 --> CSRF cookie sent
INFO - 2018-07-30 20:26:01 --> CSRF token verified
INFO - 2018-07-30 20:26:01 --> Input Class Initialized
INFO - 2018-07-30 20:26:01 --> Language Class Initialized
INFO - 2018-07-30 20:26:01 --> Loader Class Initialized
INFO - 2018-07-30 20:26:01 --> Helper loaded: url_helper
INFO - 2018-07-30 20:26:01 --> Helper loaded: form_helper
INFO - 2018-07-30 20:26:01 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:26:01 --> User Agent Class Initialized
INFO - 2018-07-30 20:26:01 --> Controller Class Initialized
INFO - 2018-07-30 20:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:26:01 --> Pixel_Model class loaded
INFO - 2018-07-30 20:26:01 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:01 --> Form Validation Class Initialized
INFO - 2018-07-30 20:26:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:26:01 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:01 --> Config Class Initialized
INFO - 2018-07-30 20:26:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:26:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:26:01 --> Utf8 Class Initialized
INFO - 2018-07-30 20:26:01 --> URI Class Initialized
INFO - 2018-07-30 20:26:01 --> Router Class Initialized
INFO - 2018-07-30 20:26:01 --> Output Class Initialized
INFO - 2018-07-30 20:26:01 --> Security Class Initialized
DEBUG - 2018-07-30 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:26:01 --> CSRF cookie sent
INFO - 2018-07-30 20:26:01 --> Input Class Initialized
INFO - 2018-07-30 20:26:01 --> Language Class Initialized
INFO - 2018-07-30 20:26:01 --> Loader Class Initialized
INFO - 2018-07-30 20:26:01 --> Helper loaded: url_helper
INFO - 2018-07-30 20:26:01 --> Helper loaded: form_helper
INFO - 2018-07-30 20:26:01 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:26:01 --> User Agent Class Initialized
INFO - 2018-07-30 20:26:01 --> Controller Class Initialized
INFO - 2018-07-30 20:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:26:01 --> Pixel_Model class loaded
INFO - 2018-07-30 20:26:01 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:01 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:26:01 --> Final output sent to browser
DEBUG - 2018-07-30 20:26:01 --> Total execution time: 0.0466
INFO - 2018-07-30 20:26:04 --> Config Class Initialized
INFO - 2018-07-30 20:26:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:26:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:26:04 --> Utf8 Class Initialized
INFO - 2018-07-30 20:26:04 --> URI Class Initialized
INFO - 2018-07-30 20:26:04 --> Router Class Initialized
INFO - 2018-07-30 20:26:04 --> Output Class Initialized
INFO - 2018-07-30 20:26:04 --> Security Class Initialized
DEBUG - 2018-07-30 20:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:26:04 --> CSRF cookie sent
INFO - 2018-07-30 20:26:04 --> Input Class Initialized
INFO - 2018-07-30 20:26:04 --> Language Class Initialized
INFO - 2018-07-30 20:26:04 --> Loader Class Initialized
INFO - 2018-07-30 20:26:04 --> Helper loaded: url_helper
INFO - 2018-07-30 20:26:04 --> Helper loaded: form_helper
INFO - 2018-07-30 20:26:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:26:04 --> User Agent Class Initialized
INFO - 2018-07-30 20:26:04 --> Controller Class Initialized
INFO - 2018-07-30 20:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:26:04 --> Pixel_Model class loaded
INFO - 2018-07-30 20:26:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:26:04 --> Final output sent to browser
DEBUG - 2018-07-30 20:26:04 --> Total execution time: 0.0384
INFO - 2018-07-30 20:26:10 --> Config Class Initialized
INFO - 2018-07-30 20:26:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:26:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:26:10 --> Utf8 Class Initialized
INFO - 2018-07-30 20:26:10 --> URI Class Initialized
INFO - 2018-07-30 20:26:10 --> Router Class Initialized
INFO - 2018-07-30 20:26:10 --> Output Class Initialized
INFO - 2018-07-30 20:26:10 --> Security Class Initialized
DEBUG - 2018-07-30 20:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:26:10 --> CSRF cookie sent
INFO - 2018-07-30 20:26:10 --> Input Class Initialized
INFO - 2018-07-30 20:26:10 --> Language Class Initialized
INFO - 2018-07-30 20:26:10 --> Loader Class Initialized
INFO - 2018-07-30 20:26:10 --> Helper loaded: url_helper
INFO - 2018-07-30 20:26:10 --> Helper loaded: form_helper
INFO - 2018-07-30 20:26:10 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:26:10 --> User Agent Class Initialized
INFO - 2018-07-30 20:26:10 --> Controller Class Initialized
INFO - 2018-07-30 20:26:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:26:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:26:10 --> Pixel_Model class loaded
INFO - 2018-07-30 20:26:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:26:10 --> Final output sent to browser
DEBUG - 2018-07-30 20:26:10 --> Total execution time: 0.0426
INFO - 2018-07-30 20:32:35 --> Config Class Initialized
INFO - 2018-07-30 20:32:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:35 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:35 --> URI Class Initialized
INFO - 2018-07-30 20:32:35 --> Router Class Initialized
INFO - 2018-07-30 20:32:35 --> Output Class Initialized
INFO - 2018-07-30 20:32:35 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:35 --> CSRF cookie sent
INFO - 2018-07-30 20:32:35 --> CSRF token verified
INFO - 2018-07-30 20:32:35 --> Input Class Initialized
INFO - 2018-07-30 20:32:35 --> Language Class Initialized
INFO - 2018-07-30 20:32:35 --> Loader Class Initialized
INFO - 2018-07-30 20:32:35 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:35 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:35 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:35 --> Controller Class Initialized
INFO - 2018-07-30 20:32:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:35 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:35 --> Form Validation Class Initialized
INFO - 2018-07-30 20:32:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:32:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:35 --> Config Class Initialized
INFO - 2018-07-30 20:32:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:35 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:35 --> URI Class Initialized
INFO - 2018-07-30 20:32:35 --> Router Class Initialized
INFO - 2018-07-30 20:32:35 --> Output Class Initialized
INFO - 2018-07-30 20:32:35 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:35 --> CSRF cookie sent
INFO - 2018-07-30 20:32:35 --> Input Class Initialized
INFO - 2018-07-30 20:32:35 --> Language Class Initialized
INFO - 2018-07-30 20:32:35 --> Loader Class Initialized
INFO - 2018-07-30 20:32:35 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:35 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:35 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:35 --> Controller Class Initialized
INFO - 2018-07-30 20:32:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:35 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:32:35 --> Final output sent to browser
DEBUG - 2018-07-30 20:32:35 --> Total execution time: 0.0445
INFO - 2018-07-30 20:32:44 --> Config Class Initialized
INFO - 2018-07-30 20:32:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:44 --> URI Class Initialized
INFO - 2018-07-30 20:32:44 --> Router Class Initialized
INFO - 2018-07-30 20:32:44 --> Output Class Initialized
INFO - 2018-07-30 20:32:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:44 --> CSRF cookie sent
INFO - 2018-07-30 20:32:44 --> CSRF token verified
INFO - 2018-07-30 20:32:44 --> Input Class Initialized
INFO - 2018-07-30 20:32:44 --> Language Class Initialized
INFO - 2018-07-30 20:32:44 --> Loader Class Initialized
INFO - 2018-07-30 20:32:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:44 --> Controller Class Initialized
INFO - 2018-07-30 20:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:44 --> Form Validation Class Initialized
INFO - 2018-07-30 20:32:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:32:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:44 --> Config Class Initialized
INFO - 2018-07-30 20:32:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:44 --> URI Class Initialized
INFO - 2018-07-30 20:32:44 --> Router Class Initialized
INFO - 2018-07-30 20:32:44 --> Output Class Initialized
INFO - 2018-07-30 20:32:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:44 --> CSRF cookie sent
INFO - 2018-07-30 20:32:44 --> Input Class Initialized
INFO - 2018-07-30 20:32:44 --> Language Class Initialized
INFO - 2018-07-30 20:32:44 --> Loader Class Initialized
INFO - 2018-07-30 20:32:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:44 --> Controller Class Initialized
INFO - 2018-07-30 20:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:32:44 --> Final output sent to browser
DEBUG - 2018-07-30 20:32:44 --> Total execution time: 0.0409
INFO - 2018-07-30 20:32:52 --> Config Class Initialized
INFO - 2018-07-30 20:32:52 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:52 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:52 --> URI Class Initialized
INFO - 2018-07-30 20:32:52 --> Router Class Initialized
INFO - 2018-07-30 20:32:52 --> Output Class Initialized
INFO - 2018-07-30 20:32:52 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:52 --> CSRF cookie sent
INFO - 2018-07-30 20:32:52 --> CSRF token verified
INFO - 2018-07-30 20:32:52 --> Input Class Initialized
INFO - 2018-07-30 20:32:52 --> Language Class Initialized
INFO - 2018-07-30 20:32:52 --> Loader Class Initialized
INFO - 2018-07-30 20:32:52 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:52 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:52 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:52 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:52 --> Controller Class Initialized
INFO - 2018-07-30 20:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:52 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:52 --> Form Validation Class Initialized
INFO - 2018-07-30 20:32:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:32:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:52 --> Config Class Initialized
INFO - 2018-07-30 20:32:52 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:52 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:52 --> URI Class Initialized
INFO - 2018-07-30 20:32:52 --> Router Class Initialized
INFO - 2018-07-30 20:32:52 --> Output Class Initialized
INFO - 2018-07-30 20:32:52 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:52 --> CSRF cookie sent
INFO - 2018-07-30 20:32:52 --> Input Class Initialized
INFO - 2018-07-30 20:32:52 --> Language Class Initialized
INFO - 2018-07-30 20:32:52 --> Loader Class Initialized
INFO - 2018-07-30 20:32:52 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:52 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:52 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:52 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:52 --> Controller Class Initialized
INFO - 2018-07-30 20:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:52 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-07-30 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:32:52 --> Final output sent to browser
DEBUG - 2018-07-30 20:32:52 --> Total execution time: 0.0641
INFO - 2018-07-30 20:32:56 --> Config Class Initialized
INFO - 2018-07-30 20:32:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:56 --> URI Class Initialized
INFO - 2018-07-30 20:32:56 --> Router Class Initialized
INFO - 2018-07-30 20:32:56 --> Output Class Initialized
INFO - 2018-07-30 20:32:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:56 --> CSRF cookie sent
INFO - 2018-07-30 20:32:56 --> CSRF token verified
INFO - 2018-07-30 20:32:56 --> Input Class Initialized
INFO - 2018-07-30 20:32:56 --> Language Class Initialized
INFO - 2018-07-30 20:32:56 --> Loader Class Initialized
INFO - 2018-07-30 20:32:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:56 --> Controller Class Initialized
INFO - 2018-07-30 20:32:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:56 --> Form Validation Class Initialized
INFO - 2018-07-30 20:32:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:32:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:56 --> Config Class Initialized
INFO - 2018-07-30 20:32:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:32:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:32:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:32:56 --> URI Class Initialized
INFO - 2018-07-30 20:32:56 --> Router Class Initialized
INFO - 2018-07-30 20:32:56 --> Output Class Initialized
INFO - 2018-07-30 20:32:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:32:56 --> CSRF cookie sent
INFO - 2018-07-30 20:32:56 --> Input Class Initialized
INFO - 2018-07-30 20:32:56 --> Language Class Initialized
INFO - 2018-07-30 20:32:56 --> Loader Class Initialized
INFO - 2018-07-30 20:32:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:32:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:32:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:32:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:32:56 --> Controller Class Initialized
INFO - 2018-07-30 20:32:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:32:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:32:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:32:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:32:56 --> Final output sent to browser
DEBUG - 2018-07-30 20:32:56 --> Total execution time: 0.0450
INFO - 2018-07-30 20:33:03 --> Config Class Initialized
INFO - 2018-07-30 20:33:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:33:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:33:03 --> Utf8 Class Initialized
INFO - 2018-07-30 20:33:03 --> URI Class Initialized
INFO - 2018-07-30 20:33:03 --> Router Class Initialized
INFO - 2018-07-30 20:33:03 --> Output Class Initialized
INFO - 2018-07-30 20:33:03 --> Security Class Initialized
DEBUG - 2018-07-30 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:33:03 --> CSRF cookie sent
INFO - 2018-07-30 20:33:03 --> CSRF token verified
INFO - 2018-07-30 20:33:03 --> Input Class Initialized
INFO - 2018-07-30 20:33:03 --> Language Class Initialized
INFO - 2018-07-30 20:33:03 --> Loader Class Initialized
INFO - 2018-07-30 20:33:03 --> Helper loaded: url_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: form_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:33:03 --> User Agent Class Initialized
INFO - 2018-07-30 20:33:03 --> Controller Class Initialized
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:33:03 --> Pixel_Model class loaded
INFO - 2018-07-30 20:33:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:33:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:33:03 --> Form Validation Class Initialized
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:33:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:33:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:33:03 --> Config Class Initialized
INFO - 2018-07-30 20:33:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:33:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:33:03 --> Utf8 Class Initialized
INFO - 2018-07-30 20:33:03 --> URI Class Initialized
INFO - 2018-07-30 20:33:03 --> Router Class Initialized
INFO - 2018-07-30 20:33:03 --> Output Class Initialized
INFO - 2018-07-30 20:33:03 --> Security Class Initialized
DEBUG - 2018-07-30 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:33:03 --> CSRF cookie sent
INFO - 2018-07-30 20:33:03 --> Input Class Initialized
INFO - 2018-07-30 20:33:03 --> Language Class Initialized
INFO - 2018-07-30 20:33:03 --> Loader Class Initialized
INFO - 2018-07-30 20:33:03 --> Helper loaded: url_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: form_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:33:03 --> User Agent Class Initialized
INFO - 2018-07-30 20:33:03 --> Controller Class Initialized
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:33:03 --> Pixel_Model class loaded
INFO - 2018-07-30 20:33:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:33:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:33:03 --> Config Class Initialized
INFO - 2018-07-30 20:33:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:33:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:33:03 --> Utf8 Class Initialized
INFO - 2018-07-30 20:33:03 --> URI Class Initialized
INFO - 2018-07-30 20:33:03 --> Router Class Initialized
INFO - 2018-07-30 20:33:03 --> Output Class Initialized
INFO - 2018-07-30 20:33:03 --> Security Class Initialized
DEBUG - 2018-07-30 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:33:03 --> CSRF cookie sent
INFO - 2018-07-30 20:33:03 --> Input Class Initialized
INFO - 2018-07-30 20:33:03 --> Language Class Initialized
INFO - 2018-07-30 20:33:03 --> Loader Class Initialized
INFO - 2018-07-30 20:33:03 --> Helper loaded: url_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: form_helper
INFO - 2018-07-30 20:33:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:33:03 --> User Agent Class Initialized
INFO - 2018-07-30 20:33:03 --> Controller Class Initialized
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:33:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:33:03 --> Pixel_Model class loaded
INFO - 2018-07-30 20:33:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:33:03 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 20:33:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 20:33:03 --> Could not find the language line "req_email"
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 20:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:33:03 --> Final output sent to browser
DEBUG - 2018-07-30 20:33:03 --> Total execution time: 0.0364
INFO - 2018-07-30 20:34:23 --> Config Class Initialized
INFO - 2018-07-30 20:34:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:34:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:34:23 --> Utf8 Class Initialized
INFO - 2018-07-30 20:34:23 --> URI Class Initialized
INFO - 2018-07-30 20:34:23 --> Router Class Initialized
INFO - 2018-07-30 20:34:23 --> Output Class Initialized
INFO - 2018-07-30 20:34:23 --> Security Class Initialized
DEBUG - 2018-07-30 20:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:34:23 --> CSRF cookie sent
INFO - 2018-07-30 20:34:23 --> Input Class Initialized
INFO - 2018-07-30 20:34:23 --> Language Class Initialized
INFO - 2018-07-30 20:34:23 --> Loader Class Initialized
INFO - 2018-07-30 20:34:23 --> Helper loaded: url_helper
INFO - 2018-07-30 20:34:23 --> Helper loaded: form_helper
INFO - 2018-07-30 20:34:23 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:34:23 --> User Agent Class Initialized
INFO - 2018-07-30 20:34:23 --> Controller Class Initialized
INFO - 2018-07-30 20:34:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:34:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:34:23 --> Pixel_Model class loaded
INFO - 2018-07-30 20:34:23 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:23 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:34:23 --> Final output sent to browser
DEBUG - 2018-07-30 20:34:23 --> Total execution time: 0.0596
INFO - 2018-07-30 20:34:26 --> Config Class Initialized
INFO - 2018-07-30 20:34:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:34:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:34:26 --> Utf8 Class Initialized
INFO - 2018-07-30 20:34:26 --> URI Class Initialized
INFO - 2018-07-30 20:34:26 --> Router Class Initialized
INFO - 2018-07-30 20:34:26 --> Output Class Initialized
INFO - 2018-07-30 20:34:26 --> Security Class Initialized
DEBUG - 2018-07-30 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:34:26 --> CSRF cookie sent
INFO - 2018-07-30 20:34:26 --> Input Class Initialized
INFO - 2018-07-30 20:34:26 --> Language Class Initialized
INFO - 2018-07-30 20:34:26 --> Loader Class Initialized
INFO - 2018-07-30 20:34:26 --> Helper loaded: url_helper
INFO - 2018-07-30 20:34:26 --> Helper loaded: form_helper
INFO - 2018-07-30 20:34:26 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:34:26 --> User Agent Class Initialized
INFO - 2018-07-30 20:34:26 --> Controller Class Initialized
INFO - 2018-07-30 20:34:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:34:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:34:26 --> Pixel_Model class loaded
INFO - 2018-07-30 20:34:26 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:26 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:34:26 --> Final output sent to browser
DEBUG - 2018-07-30 20:34:26 --> Total execution time: 0.0411
INFO - 2018-07-30 20:34:37 --> Config Class Initialized
INFO - 2018-07-30 20:34:37 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:34:37 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:34:37 --> Utf8 Class Initialized
INFO - 2018-07-30 20:34:37 --> URI Class Initialized
INFO - 2018-07-30 20:34:37 --> Router Class Initialized
INFO - 2018-07-30 20:34:37 --> Output Class Initialized
INFO - 2018-07-30 20:34:37 --> Security Class Initialized
DEBUG - 2018-07-30 20:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:34:37 --> CSRF cookie sent
INFO - 2018-07-30 20:34:37 --> Input Class Initialized
INFO - 2018-07-30 20:34:37 --> Language Class Initialized
INFO - 2018-07-30 20:34:37 --> Loader Class Initialized
INFO - 2018-07-30 20:34:37 --> Helper loaded: url_helper
INFO - 2018-07-30 20:34:37 --> Helper loaded: form_helper
INFO - 2018-07-30 20:34:37 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:34:37 --> User Agent Class Initialized
INFO - 2018-07-30 20:34:37 --> Controller Class Initialized
INFO - 2018-07-30 20:34:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:34:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:34:37 --> Pixel_Model class loaded
INFO - 2018-07-30 20:34:37 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:37 --> Database Driver Class Initialized
INFO - 2018-07-30 20:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:34:37 --> Final output sent to browser
DEBUG - 2018-07-30 20:34:37 --> Total execution time: 0.0692
INFO - 2018-07-30 20:35:54 --> Config Class Initialized
INFO - 2018-07-30 20:35:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:35:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:35:54 --> Utf8 Class Initialized
INFO - 2018-07-30 20:35:54 --> URI Class Initialized
INFO - 2018-07-30 20:35:54 --> Router Class Initialized
INFO - 2018-07-30 20:35:54 --> Output Class Initialized
INFO - 2018-07-30 20:35:54 --> Security Class Initialized
DEBUG - 2018-07-30 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:35:54 --> CSRF cookie sent
INFO - 2018-07-30 20:35:54 --> Input Class Initialized
INFO - 2018-07-30 20:35:54 --> Language Class Initialized
INFO - 2018-07-30 20:35:54 --> Loader Class Initialized
INFO - 2018-07-30 20:35:54 --> Helper loaded: url_helper
INFO - 2018-07-30 20:35:54 --> Helper loaded: form_helper
INFO - 2018-07-30 20:35:54 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:35:54 --> User Agent Class Initialized
INFO - 2018-07-30 20:35:54 --> Controller Class Initialized
INFO - 2018-07-30 20:35:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:35:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:35:54 --> Pixel_Model class loaded
INFO - 2018-07-30 20:35:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:35:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-07-30 20:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:35:54 --> Final output sent to browser
DEBUG - 2018-07-30 20:35:54 --> Total execution time: 0.0483
INFO - 2018-07-30 20:35:56 --> Config Class Initialized
INFO - 2018-07-30 20:35:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:35:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:35:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:35:56 --> URI Class Initialized
INFO - 2018-07-30 20:35:56 --> Router Class Initialized
INFO - 2018-07-30 20:35:56 --> Output Class Initialized
INFO - 2018-07-30 20:35:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:35:56 --> CSRF cookie sent
INFO - 2018-07-30 20:35:56 --> Input Class Initialized
INFO - 2018-07-30 20:35:56 --> Language Class Initialized
INFO - 2018-07-30 20:35:56 --> Loader Class Initialized
INFO - 2018-07-30 20:35:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:35:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:35:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:35:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:35:56 --> Controller Class Initialized
INFO - 2018-07-30 20:35:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:35:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:35:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:35:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:35:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:35:56 --> Config Class Initialized
INFO - 2018-07-30 20:35:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:35:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:35:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:35:56 --> URI Class Initialized
DEBUG - 2018-07-30 20:35:56 --> No URI present. Default controller set.
INFO - 2018-07-30 20:35:56 --> Router Class Initialized
INFO - 2018-07-30 20:35:56 --> Output Class Initialized
INFO - 2018-07-30 20:35:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:35:56 --> CSRF cookie sent
INFO - 2018-07-30 20:35:56 --> Input Class Initialized
INFO - 2018-07-30 20:35:56 --> Language Class Initialized
INFO - 2018-07-30 20:35:56 --> Loader Class Initialized
INFO - 2018-07-30 20:35:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:35:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:35:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:35:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:35:56 --> Controller Class Initialized
INFO - 2018-07-30 20:35:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:35:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:35:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:35:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:35:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 20:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:35:56 --> Final output sent to browser
DEBUG - 2018-07-30 20:35:56 --> Total execution time: 0.0376
INFO - 2018-07-30 20:36:02 --> Config Class Initialized
INFO - 2018-07-30 20:36:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:02 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:02 --> URI Class Initialized
INFO - 2018-07-30 20:36:02 --> Router Class Initialized
INFO - 2018-07-30 20:36:02 --> Output Class Initialized
INFO - 2018-07-30 20:36:02 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:02 --> CSRF cookie sent
INFO - 2018-07-30 20:36:02 --> CSRF token verified
INFO - 2018-07-30 20:36:02 --> Input Class Initialized
INFO - 2018-07-30 20:36:02 --> Language Class Initialized
INFO - 2018-07-30 20:36:02 --> Loader Class Initialized
INFO - 2018-07-30 20:36:02 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:02 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:02 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:02 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:02 --> Controller Class Initialized
INFO - 2018-07-30 20:36:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:02 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:02 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:02 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:02 --> Config Class Initialized
INFO - 2018-07-30 20:36:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:02 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:02 --> URI Class Initialized
INFO - 2018-07-30 20:36:02 --> Router Class Initialized
INFO - 2018-07-30 20:36:02 --> Output Class Initialized
INFO - 2018-07-30 20:36:02 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:02 --> CSRF cookie sent
INFO - 2018-07-30 20:36:02 --> Input Class Initialized
INFO - 2018-07-30 20:36:02 --> Language Class Initialized
INFO - 2018-07-30 20:36:02 --> Loader Class Initialized
INFO - 2018-07-30 20:36:02 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:02 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:02 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:02 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:02 --> Controller Class Initialized
INFO - 2018-07-30 20:36:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:02 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:02 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:02 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-30 20:36:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:02 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:02 --> Total execution time: 0.0424
INFO - 2018-07-30 20:36:05 --> Config Class Initialized
INFO - 2018-07-30 20:36:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:05 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:05 --> URI Class Initialized
INFO - 2018-07-30 20:36:05 --> Router Class Initialized
INFO - 2018-07-30 20:36:05 --> Output Class Initialized
INFO - 2018-07-30 20:36:05 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:05 --> CSRF cookie sent
INFO - 2018-07-30 20:36:05 --> CSRF token verified
INFO - 2018-07-30 20:36:05 --> Input Class Initialized
INFO - 2018-07-30 20:36:05 --> Language Class Initialized
INFO - 2018-07-30 20:36:05 --> Loader Class Initialized
INFO - 2018-07-30 20:36:05 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:05 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:05 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:05 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:05 --> Controller Class Initialized
INFO - 2018-07-30 20:36:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:05 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:05 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:05 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:05 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:06 --> Config Class Initialized
INFO - 2018-07-30 20:36:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:06 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:06 --> URI Class Initialized
INFO - 2018-07-30 20:36:06 --> Router Class Initialized
INFO - 2018-07-30 20:36:06 --> Output Class Initialized
INFO - 2018-07-30 20:36:06 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:06 --> CSRF cookie sent
INFO - 2018-07-30 20:36:06 --> Input Class Initialized
INFO - 2018-07-30 20:36:06 --> Language Class Initialized
INFO - 2018-07-30 20:36:06 --> Loader Class Initialized
INFO - 2018-07-30 20:36:06 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:06 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:06 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:06 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:06 --> Controller Class Initialized
INFO - 2018-07-30 20:36:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:06 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:06 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:06 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-30 20:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:06 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:06 --> Total execution time: 0.0386
INFO - 2018-07-30 20:36:08 --> Config Class Initialized
INFO - 2018-07-30 20:36:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:08 --> URI Class Initialized
INFO - 2018-07-30 20:36:08 --> Router Class Initialized
INFO - 2018-07-30 20:36:08 --> Output Class Initialized
INFO - 2018-07-30 20:36:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:08 --> CSRF cookie sent
INFO - 2018-07-30 20:36:08 --> CSRF token verified
INFO - 2018-07-30 20:36:08 --> Input Class Initialized
INFO - 2018-07-30 20:36:08 --> Language Class Initialized
INFO - 2018-07-30 20:36:08 --> Loader Class Initialized
INFO - 2018-07-30 20:36:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:08 --> Controller Class Initialized
INFO - 2018-07-30 20:36:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:08 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:08 --> Config Class Initialized
INFO - 2018-07-30 20:36:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:08 --> URI Class Initialized
INFO - 2018-07-30 20:36:08 --> Router Class Initialized
INFO - 2018-07-30 20:36:08 --> Output Class Initialized
INFO - 2018-07-30 20:36:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:08 --> CSRF cookie sent
INFO - 2018-07-30 20:36:08 --> Input Class Initialized
INFO - 2018-07-30 20:36:08 --> Language Class Initialized
INFO - 2018-07-30 20:36:08 --> Loader Class Initialized
INFO - 2018-07-30 20:36:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:08 --> Controller Class Initialized
INFO - 2018-07-30 20:36:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-30 20:36:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:08 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:08 --> Total execution time: 0.0297
INFO - 2018-07-30 20:36:10 --> Config Class Initialized
INFO - 2018-07-30 20:36:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:10 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:10 --> URI Class Initialized
INFO - 2018-07-30 20:36:10 --> Router Class Initialized
INFO - 2018-07-30 20:36:10 --> Output Class Initialized
INFO - 2018-07-30 20:36:10 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:10 --> CSRF cookie sent
INFO - 2018-07-30 20:36:10 --> CSRF token verified
INFO - 2018-07-30 20:36:10 --> Input Class Initialized
INFO - 2018-07-30 20:36:10 --> Language Class Initialized
INFO - 2018-07-30 20:36:10 --> Loader Class Initialized
INFO - 2018-07-30 20:36:10 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:10 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:10 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:10 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:10 --> Controller Class Initialized
INFO - 2018-07-30 20:36:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:10 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:10 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:10 --> Config Class Initialized
INFO - 2018-07-30 20:36:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:10 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:10 --> URI Class Initialized
INFO - 2018-07-30 20:36:10 --> Router Class Initialized
INFO - 2018-07-30 20:36:10 --> Output Class Initialized
INFO - 2018-07-30 20:36:10 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:10 --> CSRF cookie sent
INFO - 2018-07-30 20:36:10 --> Input Class Initialized
INFO - 2018-07-30 20:36:10 --> Language Class Initialized
INFO - 2018-07-30 20:36:10 --> Loader Class Initialized
INFO - 2018-07-30 20:36:10 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:10 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:10 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:10 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:10 --> Controller Class Initialized
INFO - 2018-07-30 20:36:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:10 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:10 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-30 20:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:10 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:10 --> Total execution time: 0.0391
INFO - 2018-07-30 20:36:19 --> Config Class Initialized
INFO - 2018-07-30 20:36:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:19 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:19 --> URI Class Initialized
INFO - 2018-07-30 20:36:19 --> Router Class Initialized
INFO - 2018-07-30 20:36:19 --> Output Class Initialized
INFO - 2018-07-30 20:36:19 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:19 --> CSRF cookie sent
INFO - 2018-07-30 20:36:19 --> CSRF token verified
INFO - 2018-07-30 20:36:19 --> Input Class Initialized
INFO - 2018-07-30 20:36:19 --> Language Class Initialized
INFO - 2018-07-30 20:36:19 --> Loader Class Initialized
INFO - 2018-07-30 20:36:19 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:19 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:19 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:19 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:19 --> Controller Class Initialized
INFO - 2018-07-30 20:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:19 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:19 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:19 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:19 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:19 --> Config Class Initialized
INFO - 2018-07-30 20:36:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:19 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:19 --> URI Class Initialized
INFO - 2018-07-30 20:36:19 --> Router Class Initialized
INFO - 2018-07-30 20:36:19 --> Output Class Initialized
INFO - 2018-07-30 20:36:19 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:19 --> CSRF cookie sent
INFO - 2018-07-30 20:36:19 --> Input Class Initialized
INFO - 2018-07-30 20:36:19 --> Language Class Initialized
INFO - 2018-07-30 20:36:19 --> Loader Class Initialized
INFO - 2018-07-30 20:36:19 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:19 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:19 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:19 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:19 --> Controller Class Initialized
INFO - 2018-07-30 20:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:19 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:19 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:19 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:19 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:19 --> Total execution time: 0.0402
INFO - 2018-07-30 20:36:24 --> Config Class Initialized
INFO - 2018-07-30 20:36:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:24 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:24 --> URI Class Initialized
INFO - 2018-07-30 20:36:24 --> Router Class Initialized
INFO - 2018-07-30 20:36:24 --> Output Class Initialized
INFO - 2018-07-30 20:36:24 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:24 --> CSRF cookie sent
INFO - 2018-07-30 20:36:24 --> CSRF token verified
INFO - 2018-07-30 20:36:24 --> Input Class Initialized
INFO - 2018-07-30 20:36:24 --> Language Class Initialized
INFO - 2018-07-30 20:36:24 --> Loader Class Initialized
INFO - 2018-07-30 20:36:24 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:24 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:24 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:24 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:24 --> Controller Class Initialized
INFO - 2018-07-30 20:36:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:24 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:24 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:24 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:24 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:25 --> Config Class Initialized
INFO - 2018-07-30 20:36:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:25 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:25 --> URI Class Initialized
INFO - 2018-07-30 20:36:25 --> Router Class Initialized
INFO - 2018-07-30 20:36:25 --> Output Class Initialized
INFO - 2018-07-30 20:36:25 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:25 --> CSRF cookie sent
INFO - 2018-07-30 20:36:25 --> Input Class Initialized
INFO - 2018-07-30 20:36:25 --> Language Class Initialized
INFO - 2018-07-30 20:36:25 --> Loader Class Initialized
INFO - 2018-07-30 20:36:25 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:25 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:25 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:25 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:25 --> Controller Class Initialized
INFO - 2018-07-30 20:36:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:25 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:25 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:25 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:25 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:25 --> Total execution time: 0.0390
INFO - 2018-07-30 20:36:32 --> Config Class Initialized
INFO - 2018-07-30 20:36:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:32 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:32 --> URI Class Initialized
INFO - 2018-07-30 20:36:32 --> Router Class Initialized
INFO - 2018-07-30 20:36:32 --> Output Class Initialized
INFO - 2018-07-30 20:36:32 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:32 --> CSRF cookie sent
INFO - 2018-07-30 20:36:32 --> CSRF token verified
INFO - 2018-07-30 20:36:32 --> Input Class Initialized
INFO - 2018-07-30 20:36:32 --> Language Class Initialized
INFO - 2018-07-30 20:36:32 --> Loader Class Initialized
INFO - 2018-07-30 20:36:32 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:32 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:32 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:32 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:32 --> Controller Class Initialized
INFO - 2018-07-30 20:36:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:32 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:32 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:32 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:32 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:32 --> Config Class Initialized
INFO - 2018-07-30 20:36:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:32 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:32 --> URI Class Initialized
INFO - 2018-07-30 20:36:32 --> Router Class Initialized
INFO - 2018-07-30 20:36:32 --> Output Class Initialized
INFO - 2018-07-30 20:36:32 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:32 --> CSRF cookie sent
INFO - 2018-07-30 20:36:32 --> Input Class Initialized
INFO - 2018-07-30 20:36:32 --> Language Class Initialized
INFO - 2018-07-30 20:36:32 --> Loader Class Initialized
INFO - 2018-07-30 20:36:32 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:32 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:32 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:32 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:32 --> Controller Class Initialized
INFO - 2018-07-30 20:36:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:32 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:32 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:32 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:32 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:32 --> Total execution time: 0.0416
INFO - 2018-07-30 20:36:36 --> Config Class Initialized
INFO - 2018-07-30 20:36:36 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:36 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:36 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:36 --> URI Class Initialized
INFO - 2018-07-30 20:36:36 --> Router Class Initialized
INFO - 2018-07-30 20:36:36 --> Output Class Initialized
INFO - 2018-07-30 20:36:36 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:36 --> CSRF cookie sent
INFO - 2018-07-30 20:36:36 --> CSRF token verified
INFO - 2018-07-30 20:36:36 --> Input Class Initialized
INFO - 2018-07-30 20:36:36 --> Language Class Initialized
INFO - 2018-07-30 20:36:36 --> Loader Class Initialized
INFO - 2018-07-30 20:36:36 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:36 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:36 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:36 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:36 --> Controller Class Initialized
INFO - 2018-07-30 20:36:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:36 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:36 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:36 --> Config Class Initialized
INFO - 2018-07-30 20:36:36 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:36 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:36 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:36 --> URI Class Initialized
INFO - 2018-07-30 20:36:36 --> Router Class Initialized
INFO - 2018-07-30 20:36:36 --> Output Class Initialized
INFO - 2018-07-30 20:36:36 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:36 --> CSRF cookie sent
INFO - 2018-07-30 20:36:36 --> Input Class Initialized
INFO - 2018-07-30 20:36:36 --> Language Class Initialized
INFO - 2018-07-30 20:36:36 --> Loader Class Initialized
INFO - 2018-07-30 20:36:36 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:36 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:36 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:36 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:36 --> Controller Class Initialized
INFO - 2018-07-30 20:36:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:36 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-30 20:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:36 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:36 --> Total execution time: 0.0394
INFO - 2018-07-30 20:36:40 --> Config Class Initialized
INFO - 2018-07-30 20:36:40 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:40 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:40 --> URI Class Initialized
INFO - 2018-07-30 20:36:40 --> Router Class Initialized
INFO - 2018-07-30 20:36:40 --> Output Class Initialized
INFO - 2018-07-30 20:36:40 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:40 --> CSRF cookie sent
INFO - 2018-07-30 20:36:40 --> CSRF token verified
INFO - 2018-07-30 20:36:40 --> Input Class Initialized
INFO - 2018-07-30 20:36:40 --> Language Class Initialized
INFO - 2018-07-30 20:36:40 --> Loader Class Initialized
INFO - 2018-07-30 20:36:40 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:40 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:40 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:40 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:40 --> Controller Class Initialized
INFO - 2018-07-30 20:36:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:40 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:40 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:40 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:40 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:40 --> Config Class Initialized
INFO - 2018-07-30 20:36:40 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:40 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:40 --> URI Class Initialized
INFO - 2018-07-30 20:36:40 --> Router Class Initialized
INFO - 2018-07-30 20:36:40 --> Output Class Initialized
INFO - 2018-07-30 20:36:40 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:40 --> CSRF cookie sent
INFO - 2018-07-30 20:36:40 --> Input Class Initialized
INFO - 2018-07-30 20:36:40 --> Language Class Initialized
INFO - 2018-07-30 20:36:40 --> Loader Class Initialized
INFO - 2018-07-30 20:36:40 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:40 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:40 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:40 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:40 --> Controller Class Initialized
INFO - 2018-07-30 20:36:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:40 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:40 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:40 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:36:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:40 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:40 --> Total execution time: 0.0398
INFO - 2018-07-30 20:36:44 --> Config Class Initialized
INFO - 2018-07-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:44 --> URI Class Initialized
INFO - 2018-07-30 20:36:44 --> Router Class Initialized
INFO - 2018-07-30 20:36:44 --> Output Class Initialized
INFO - 2018-07-30 20:36:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:44 --> CSRF cookie sent
INFO - 2018-07-30 20:36:44 --> CSRF token verified
INFO - 2018-07-30 20:36:44 --> Input Class Initialized
INFO - 2018-07-30 20:36:44 --> Language Class Initialized
INFO - 2018-07-30 20:36:44 --> Loader Class Initialized
INFO - 2018-07-30 20:36:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:44 --> Controller Class Initialized
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:44 --> Form Validation Class Initialized
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:36:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:44 --> Config Class Initialized
INFO - 2018-07-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:44 --> URI Class Initialized
INFO - 2018-07-30 20:36:44 --> Router Class Initialized
INFO - 2018-07-30 20:36:44 --> Output Class Initialized
INFO - 2018-07-30 20:36:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:44 --> CSRF cookie sent
INFO - 2018-07-30 20:36:44 --> Input Class Initialized
INFO - 2018-07-30 20:36:44 --> Language Class Initialized
INFO - 2018-07-30 20:36:44 --> Loader Class Initialized
INFO - 2018-07-30 20:36:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:44 --> Controller Class Initialized
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:44 --> Config Class Initialized
INFO - 2018-07-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:44 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:44 --> URI Class Initialized
INFO - 2018-07-30 20:36:44 --> Router Class Initialized
INFO - 2018-07-30 20:36:44 --> Output Class Initialized
INFO - 2018-07-30 20:36:44 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:44 --> CSRF cookie sent
INFO - 2018-07-30 20:36:44 --> Input Class Initialized
INFO - 2018-07-30 20:36:44 --> Language Class Initialized
INFO - 2018-07-30 20:36:44 --> Loader Class Initialized
INFO - 2018-07-30 20:36:44 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:44 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:44 --> Controller Class Initialized
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:44 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:44 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:44 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 20:36:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 20:36:44 --> Could not find the language line "req_email"
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 20:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:44 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:44 --> Total execution time: 0.0354
INFO - 2018-07-30 20:36:47 --> Config Class Initialized
INFO - 2018-07-30 20:36:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:47 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:47 --> URI Class Initialized
INFO - 2018-07-30 20:36:47 --> Router Class Initialized
INFO - 2018-07-30 20:36:47 --> Output Class Initialized
INFO - 2018-07-30 20:36:47 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:47 --> CSRF cookie sent
INFO - 2018-07-30 20:36:47 --> Input Class Initialized
INFO - 2018-07-30 20:36:47 --> Language Class Initialized
INFO - 2018-07-30 20:36:47 --> Loader Class Initialized
INFO - 2018-07-30 20:36:47 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:47 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:47 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:47 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:47 --> Controller Class Initialized
INFO - 2018-07-30 20:36:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:47 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:47 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:47 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:47 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:47 --> Total execution time: 0.0451
INFO - 2018-07-30 20:36:49 --> Config Class Initialized
INFO - 2018-07-30 20:36:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:49 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:49 --> URI Class Initialized
INFO - 2018-07-30 20:36:49 --> Router Class Initialized
INFO - 2018-07-30 20:36:49 --> Output Class Initialized
INFO - 2018-07-30 20:36:49 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:49 --> CSRF cookie sent
INFO - 2018-07-30 20:36:49 --> Input Class Initialized
INFO - 2018-07-30 20:36:49 --> Language Class Initialized
INFO - 2018-07-30 20:36:49 --> Loader Class Initialized
INFO - 2018-07-30 20:36:49 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:49 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:49 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:49 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:49 --> Controller Class Initialized
INFO - 2018-07-30 20:36:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:49 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:49 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:49 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:49 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:49 --> Total execution time: 0.0674
INFO - 2018-07-30 20:36:52 --> Config Class Initialized
INFO - 2018-07-30 20:36:52 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:52 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:52 --> URI Class Initialized
INFO - 2018-07-30 20:36:52 --> Router Class Initialized
INFO - 2018-07-30 20:36:52 --> Output Class Initialized
INFO - 2018-07-30 20:36:52 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:52 --> CSRF cookie sent
INFO - 2018-07-30 20:36:52 --> Input Class Initialized
INFO - 2018-07-30 20:36:52 --> Language Class Initialized
INFO - 2018-07-30 20:36:52 --> Loader Class Initialized
INFO - 2018-07-30 20:36:52 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:52 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:52 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:52 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:52 --> Controller Class Initialized
INFO - 2018-07-30 20:36:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:52 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:52 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:52 --> Total execution time: 0.0677
INFO - 2018-07-30 20:36:56 --> Config Class Initialized
INFO - 2018-07-30 20:36:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:56 --> URI Class Initialized
INFO - 2018-07-30 20:36:56 --> Router Class Initialized
INFO - 2018-07-30 20:36:56 --> Output Class Initialized
INFO - 2018-07-30 20:36:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:56 --> CSRF cookie sent
INFO - 2018-07-30 20:36:56 --> Input Class Initialized
INFO - 2018-07-30 20:36:56 --> Language Class Initialized
INFO - 2018-07-30 20:36:56 --> Loader Class Initialized
INFO - 2018-07-30 20:36:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:56 --> Controller Class Initialized
INFO - 2018-07-30 20:36:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-30 20:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:56 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:56 --> Total execution time: 0.0559
INFO - 2018-07-30 20:36:59 --> Config Class Initialized
INFO - 2018-07-30 20:36:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:36:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:36:59 --> Utf8 Class Initialized
INFO - 2018-07-30 20:36:59 --> URI Class Initialized
INFO - 2018-07-30 20:36:59 --> Router Class Initialized
INFO - 2018-07-30 20:36:59 --> Output Class Initialized
INFO - 2018-07-30 20:36:59 --> Security Class Initialized
DEBUG - 2018-07-30 20:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:36:59 --> CSRF cookie sent
INFO - 2018-07-30 20:36:59 --> Input Class Initialized
INFO - 2018-07-30 20:36:59 --> Language Class Initialized
INFO - 2018-07-30 20:36:59 --> Loader Class Initialized
INFO - 2018-07-30 20:36:59 --> Helper loaded: url_helper
INFO - 2018-07-30 20:36:59 --> Helper loaded: form_helper
INFO - 2018-07-30 20:36:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:36:59 --> User Agent Class Initialized
INFO - 2018-07-30 20:36:59 --> Controller Class Initialized
INFO - 2018-07-30 20:36:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:36:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:36:59 --> Pixel_Model class loaded
INFO - 2018-07-30 20:36:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:36:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:36:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:36:59 --> Final output sent to browser
DEBUG - 2018-07-30 20:36:59 --> Total execution time: 0.0400
INFO - 2018-07-30 20:37:00 --> Config Class Initialized
INFO - 2018-07-30 20:37:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:37:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:37:00 --> Utf8 Class Initialized
INFO - 2018-07-30 20:37:00 --> URI Class Initialized
INFO - 2018-07-30 20:37:00 --> Router Class Initialized
INFO - 2018-07-30 20:37:00 --> Output Class Initialized
INFO - 2018-07-30 20:37:00 --> Security Class Initialized
DEBUG - 2018-07-30 20:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:37:00 --> CSRF cookie sent
INFO - 2018-07-30 20:37:00 --> Input Class Initialized
INFO - 2018-07-30 20:37:00 --> Language Class Initialized
INFO - 2018-07-30 20:37:00 --> Loader Class Initialized
INFO - 2018-07-30 20:37:00 --> Helper loaded: url_helper
INFO - 2018-07-30 20:37:00 --> Helper loaded: form_helper
INFO - 2018-07-30 20:37:00 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:37:00 --> User Agent Class Initialized
INFO - 2018-07-30 20:37:00 --> Controller Class Initialized
INFO - 2018-07-30 20:37:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:37:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:37:00 --> Pixel_Model class loaded
INFO - 2018-07-30 20:37:00 --> Database Driver Class Initialized
INFO - 2018-07-30 20:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:37:00 --> Database Driver Class Initialized
INFO - 2018-07-30 20:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:37:00 --> Final output sent to browser
DEBUG - 2018-07-30 20:37:00 --> Total execution time: 0.0409
INFO - 2018-07-30 20:37:03 --> Config Class Initialized
INFO - 2018-07-30 20:37:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:37:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:37:03 --> Utf8 Class Initialized
INFO - 2018-07-30 20:37:03 --> URI Class Initialized
INFO - 2018-07-30 20:37:03 --> Router Class Initialized
INFO - 2018-07-30 20:37:03 --> Output Class Initialized
INFO - 2018-07-30 20:37:03 --> Security Class Initialized
DEBUG - 2018-07-30 20:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:37:03 --> CSRF cookie sent
INFO - 2018-07-30 20:37:03 --> Input Class Initialized
INFO - 2018-07-30 20:37:03 --> Language Class Initialized
INFO - 2018-07-30 20:37:03 --> Loader Class Initialized
INFO - 2018-07-30 20:37:03 --> Helper loaded: url_helper
INFO - 2018-07-30 20:37:03 --> Helper loaded: form_helper
INFO - 2018-07-30 20:37:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:37:03 --> User Agent Class Initialized
INFO - 2018-07-30 20:37:03 --> Controller Class Initialized
INFO - 2018-07-30 20:37:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:37:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:37:03 --> Pixel_Model class loaded
INFO - 2018-07-30 20:37:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:37:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:37:03 --> Database Driver Class Initialized
INFO - 2018-07-30 20:37:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:37:03 --> Final output sent to browser
DEBUG - 2018-07-30 20:37:03 --> Total execution time: 0.0457
INFO - 2018-07-30 20:51:17 --> Config Class Initialized
INFO - 2018-07-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:17 --> URI Class Initialized
INFO - 2018-07-30 20:51:17 --> Router Class Initialized
INFO - 2018-07-30 20:51:17 --> Output Class Initialized
INFO - 2018-07-30 20:51:17 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:17 --> CSRF cookie sent
INFO - 2018-07-30 20:51:17 --> Input Class Initialized
INFO - 2018-07-30 20:51:17 --> Language Class Initialized
INFO - 2018-07-30 20:51:17 --> Loader Class Initialized
INFO - 2018-07-30 20:51:17 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:17 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:17 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:17 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:17 --> Controller Class Initialized
INFO - 2018-07-30 20:51:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:17 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:17 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-30 20:51:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:51:17 --> Final output sent to browser
DEBUG - 2018-07-30 20:51:17 --> Total execution time: 0.0484
INFO - 2018-07-30 20:51:29 --> Config Class Initialized
INFO - 2018-07-30 20:51:29 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:29 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:29 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:29 --> URI Class Initialized
INFO - 2018-07-30 20:51:29 --> Router Class Initialized
INFO - 2018-07-30 20:51:29 --> Output Class Initialized
INFO - 2018-07-30 20:51:29 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:29 --> CSRF cookie sent
INFO - 2018-07-30 20:51:29 --> CSRF token verified
INFO - 2018-07-30 20:51:29 --> Input Class Initialized
INFO - 2018-07-30 20:51:29 --> Language Class Initialized
INFO - 2018-07-30 20:51:29 --> Loader Class Initialized
INFO - 2018-07-30 20:51:29 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:29 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:29 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:29 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:29 --> Controller Class Initialized
INFO - 2018-07-30 20:51:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:29 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:29 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:29 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:30 --> Config Class Initialized
INFO - 2018-07-30 20:51:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:30 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:30 --> URI Class Initialized
INFO - 2018-07-30 20:51:30 --> Router Class Initialized
INFO - 2018-07-30 20:51:30 --> Output Class Initialized
INFO - 2018-07-30 20:51:30 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:30 --> CSRF cookie sent
INFO - 2018-07-30 20:51:30 --> Input Class Initialized
INFO - 2018-07-30 20:51:30 --> Language Class Initialized
INFO - 2018-07-30 20:51:30 --> Loader Class Initialized
INFO - 2018-07-30 20:51:30 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:30 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:30 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:30 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:30 --> Controller Class Initialized
INFO - 2018-07-30 20:51:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:30 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:30 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:30 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-30 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:51:30 --> Final output sent to browser
DEBUG - 2018-07-30 20:51:30 --> Total execution time: 0.0589
INFO - 2018-07-30 20:51:48 --> Config Class Initialized
INFO - 2018-07-30 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:48 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:48 --> URI Class Initialized
INFO - 2018-07-30 20:51:48 --> Router Class Initialized
INFO - 2018-07-30 20:51:48 --> Output Class Initialized
INFO - 2018-07-30 20:51:48 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:48 --> CSRF cookie sent
INFO - 2018-07-30 20:51:48 --> CSRF token verified
INFO - 2018-07-30 20:51:48 --> Input Class Initialized
INFO - 2018-07-30 20:51:48 --> Language Class Initialized
INFO - 2018-07-30 20:51:48 --> Loader Class Initialized
INFO - 2018-07-30 20:51:48 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:48 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:48 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:48 --> Controller Class Initialized
INFO - 2018-07-30 20:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:48 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:48 --> Form Validation Class Initialized
INFO - 2018-07-30 20:51:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:51:48 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:48 --> Config Class Initialized
INFO - 2018-07-30 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:48 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:48 --> URI Class Initialized
INFO - 2018-07-30 20:51:48 --> Router Class Initialized
INFO - 2018-07-30 20:51:48 --> Output Class Initialized
INFO - 2018-07-30 20:51:48 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:48 --> CSRF cookie sent
INFO - 2018-07-30 20:51:48 --> Input Class Initialized
INFO - 2018-07-30 20:51:48 --> Language Class Initialized
INFO - 2018-07-30 20:51:49 --> Loader Class Initialized
INFO - 2018-07-30 20:51:49 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:49 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:49 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:49 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:49 --> Controller Class Initialized
INFO - 2018-07-30 20:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:49 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:49 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:49 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-30 20:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:51:49 --> Final output sent to browser
DEBUG - 2018-07-30 20:51:49 --> Total execution time: 0.0422
INFO - 2018-07-30 20:51:56 --> Config Class Initialized
INFO - 2018-07-30 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:56 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:56 --> URI Class Initialized
INFO - 2018-07-30 20:51:56 --> Router Class Initialized
INFO - 2018-07-30 20:51:56 --> Output Class Initialized
INFO - 2018-07-30 20:51:56 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:56 --> CSRF cookie sent
INFO - 2018-07-30 20:51:56 --> CSRF token verified
INFO - 2018-07-30 20:51:56 --> Input Class Initialized
INFO - 2018-07-30 20:51:56 --> Language Class Initialized
INFO - 2018-07-30 20:51:56 --> Loader Class Initialized
INFO - 2018-07-30 20:51:56 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:56 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:56 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:56 --> Controller Class Initialized
INFO - 2018-07-30 20:51:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:56 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:56 --> Form Validation Class Initialized
INFO - 2018-07-30 20:51:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:51:56 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:57 --> Config Class Initialized
INFO - 2018-07-30 20:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:51:57 --> Utf8 Class Initialized
INFO - 2018-07-30 20:51:57 --> URI Class Initialized
INFO - 2018-07-30 20:51:57 --> Router Class Initialized
INFO - 2018-07-30 20:51:57 --> Output Class Initialized
INFO - 2018-07-30 20:51:57 --> Security Class Initialized
DEBUG - 2018-07-30 20:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:51:57 --> CSRF cookie sent
INFO - 2018-07-30 20:51:57 --> Input Class Initialized
INFO - 2018-07-30 20:51:57 --> Language Class Initialized
INFO - 2018-07-30 20:51:57 --> Loader Class Initialized
INFO - 2018-07-30 20:51:57 --> Helper loaded: url_helper
INFO - 2018-07-30 20:51:57 --> Helper loaded: form_helper
INFO - 2018-07-30 20:51:57 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:51:57 --> User Agent Class Initialized
INFO - 2018-07-30 20:51:57 --> Controller Class Initialized
INFO - 2018-07-30 20:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:51:57 --> Pixel_Model class loaded
INFO - 2018-07-30 20:51:57 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:57 --> Database Driver Class Initialized
INFO - 2018-07-30 20:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-30 20:51:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:51:57 --> Final output sent to browser
DEBUG - 2018-07-30 20:51:57 --> Total execution time: 0.0877
INFO - 2018-07-30 20:52:11 --> Config Class Initialized
INFO - 2018-07-30 20:52:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:11 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:11 --> URI Class Initialized
INFO - 2018-07-30 20:52:11 --> Router Class Initialized
INFO - 2018-07-30 20:52:11 --> Output Class Initialized
INFO - 2018-07-30 20:52:11 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:12 --> CSRF cookie sent
INFO - 2018-07-30 20:52:12 --> CSRF token verified
INFO - 2018-07-30 20:52:12 --> Input Class Initialized
INFO - 2018-07-30 20:52:12 --> Language Class Initialized
INFO - 2018-07-30 20:52:12 --> Loader Class Initialized
INFO - 2018-07-30 20:52:12 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:12 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:12 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:12 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:12 --> Controller Class Initialized
INFO - 2018-07-30 20:52:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:12 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:12 --> Form Validation Class Initialized
INFO - 2018-07-30 20:52:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:52:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:12 --> Config Class Initialized
INFO - 2018-07-30 20:52:12 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:12 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:12 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:12 --> URI Class Initialized
INFO - 2018-07-30 20:52:12 --> Router Class Initialized
INFO - 2018-07-30 20:52:12 --> Output Class Initialized
INFO - 2018-07-30 20:52:12 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:12 --> CSRF cookie sent
INFO - 2018-07-30 20:52:12 --> Input Class Initialized
INFO - 2018-07-30 20:52:12 --> Language Class Initialized
INFO - 2018-07-30 20:52:12 --> Loader Class Initialized
INFO - 2018-07-30 20:52:12 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:12 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:12 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:12 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:12 --> Controller Class Initialized
INFO - 2018-07-30 20:52:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:12 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:12 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-30 20:52:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:52:12 --> Final output sent to browser
DEBUG - 2018-07-30 20:52:12 --> Total execution time: 0.0373
INFO - 2018-07-30 20:52:26 --> Config Class Initialized
INFO - 2018-07-30 20:52:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:26 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:26 --> URI Class Initialized
INFO - 2018-07-30 20:52:26 --> Router Class Initialized
INFO - 2018-07-30 20:52:26 --> Output Class Initialized
INFO - 2018-07-30 20:52:26 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:26 --> CSRF cookie sent
INFO - 2018-07-30 20:52:26 --> CSRF token verified
INFO - 2018-07-30 20:52:26 --> Input Class Initialized
INFO - 2018-07-30 20:52:26 --> Language Class Initialized
INFO - 2018-07-30 20:52:26 --> Loader Class Initialized
INFO - 2018-07-30 20:52:26 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:26 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:26 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:26 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:26 --> Controller Class Initialized
INFO - 2018-07-30 20:52:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:26 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:26 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:26 --> Form Validation Class Initialized
INFO - 2018-07-30 20:52:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:52:26 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:26 --> Config Class Initialized
INFO - 2018-07-30 20:52:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:26 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:26 --> URI Class Initialized
INFO - 2018-07-30 20:52:26 --> Router Class Initialized
INFO - 2018-07-30 20:52:26 --> Output Class Initialized
INFO - 2018-07-30 20:52:26 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:26 --> CSRF cookie sent
INFO - 2018-07-30 20:52:26 --> Input Class Initialized
INFO - 2018-07-30 20:52:26 --> Language Class Initialized
INFO - 2018-07-30 20:52:27 --> Loader Class Initialized
INFO - 2018-07-30 20:52:27 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:27 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:27 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:27 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:27 --> Controller Class Initialized
INFO - 2018-07-30 20:52:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:27 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:27 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-07-30 20:52:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:52:27 --> Final output sent to browser
DEBUG - 2018-07-30 20:52:27 --> Total execution time: 0.0327
INFO - 2018-07-30 20:52:37 --> Config Class Initialized
INFO - 2018-07-30 20:52:37 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:37 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:37 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:37 --> URI Class Initialized
INFO - 2018-07-30 20:52:37 --> Router Class Initialized
INFO - 2018-07-30 20:52:37 --> Output Class Initialized
INFO - 2018-07-30 20:52:37 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:37 --> CSRF cookie sent
INFO - 2018-07-30 20:52:37 --> CSRF token verified
INFO - 2018-07-30 20:52:37 --> Input Class Initialized
INFO - 2018-07-30 20:52:37 --> Language Class Initialized
INFO - 2018-07-30 20:52:37 --> Loader Class Initialized
INFO - 2018-07-30 20:52:37 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:37 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:37 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:37 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:37 --> Controller Class Initialized
INFO - 2018-07-30 20:52:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:37 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:37 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:37 --> Form Validation Class Initialized
INFO - 2018-07-30 20:52:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:52:37 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:38 --> Config Class Initialized
INFO - 2018-07-30 20:52:38 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:38 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:38 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:38 --> URI Class Initialized
INFO - 2018-07-30 20:52:38 --> Router Class Initialized
INFO - 2018-07-30 20:52:38 --> Output Class Initialized
INFO - 2018-07-30 20:52:38 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:38 --> CSRF cookie sent
INFO - 2018-07-30 20:52:38 --> Input Class Initialized
INFO - 2018-07-30 20:52:38 --> Language Class Initialized
INFO - 2018-07-30 20:52:38 --> Loader Class Initialized
INFO - 2018-07-30 20:52:38 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:38 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:38 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:38 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:38 --> Controller Class Initialized
INFO - 2018-07-30 20:52:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:38 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:38 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:38 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 20:52:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:52:38 --> Final output sent to browser
DEBUG - 2018-07-30 20:52:38 --> Total execution time: 0.0620
INFO - 2018-07-30 20:52:54 --> Config Class Initialized
INFO - 2018-07-30 20:52:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:54 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:54 --> URI Class Initialized
INFO - 2018-07-30 20:52:54 --> Router Class Initialized
INFO - 2018-07-30 20:52:54 --> Output Class Initialized
INFO - 2018-07-30 20:52:54 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:54 --> CSRF cookie sent
INFO - 2018-07-30 20:52:54 --> CSRF token verified
INFO - 2018-07-30 20:52:54 --> Input Class Initialized
INFO - 2018-07-30 20:52:54 --> Language Class Initialized
INFO - 2018-07-30 20:52:54 --> Loader Class Initialized
INFO - 2018-07-30 20:52:54 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:54 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:54 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:54 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:54 --> Controller Class Initialized
INFO - 2018-07-30 20:52:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:54 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:54 --> Form Validation Class Initialized
INFO - 2018-07-30 20:52:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:52:54 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:55 --> Config Class Initialized
INFO - 2018-07-30 20:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:52:55 --> Utf8 Class Initialized
INFO - 2018-07-30 20:52:55 --> URI Class Initialized
INFO - 2018-07-30 20:52:55 --> Router Class Initialized
INFO - 2018-07-30 20:52:55 --> Output Class Initialized
INFO - 2018-07-30 20:52:55 --> Security Class Initialized
DEBUG - 2018-07-30 20:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:52:55 --> CSRF cookie sent
INFO - 2018-07-30 20:52:55 --> Input Class Initialized
INFO - 2018-07-30 20:52:55 --> Language Class Initialized
INFO - 2018-07-30 20:52:55 --> Loader Class Initialized
INFO - 2018-07-30 20:52:55 --> Helper loaded: url_helper
INFO - 2018-07-30 20:52:55 --> Helper loaded: form_helper
INFO - 2018-07-30 20:52:55 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:52:55 --> User Agent Class Initialized
INFO - 2018-07-30 20:52:55 --> Controller Class Initialized
INFO - 2018-07-30 20:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:52:55 --> Pixel_Model class loaded
INFO - 2018-07-30 20:52:55 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:55 --> Database Driver Class Initialized
INFO - 2018-07-30 20:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:52:55 --> Final output sent to browser
DEBUG - 2018-07-30 20:52:55 --> Total execution time: 0.0407
INFO - 2018-07-30 20:53:04 --> Config Class Initialized
INFO - 2018-07-30 20:53:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:53:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:53:04 --> Utf8 Class Initialized
INFO - 2018-07-30 20:53:04 --> URI Class Initialized
INFO - 2018-07-30 20:53:04 --> Router Class Initialized
INFO - 2018-07-30 20:53:04 --> Output Class Initialized
INFO - 2018-07-30 20:53:04 --> Security Class Initialized
DEBUG - 2018-07-30 20:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:53:04 --> CSRF cookie sent
INFO - 2018-07-30 20:53:04 --> Input Class Initialized
INFO - 2018-07-30 20:53:04 --> Language Class Initialized
INFO - 2018-07-30 20:53:04 --> Loader Class Initialized
INFO - 2018-07-30 20:53:04 --> Helper loaded: url_helper
INFO - 2018-07-30 20:53:04 --> Helper loaded: form_helper
INFO - 2018-07-30 20:53:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:53:04 --> User Agent Class Initialized
INFO - 2018-07-30 20:53:04 --> Controller Class Initialized
INFO - 2018-07-30 20:53:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:53:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:53:04 --> Pixel_Model class loaded
INFO - 2018-07-30 20:53:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:53:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:53:04 --> Database Driver Class Initialized
INFO - 2018-07-30 20:53:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:53:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:53:04 --> Final output sent to browser
DEBUG - 2018-07-30 20:53:04 --> Total execution time: 0.0444
INFO - 2018-07-30 20:53:15 --> Config Class Initialized
INFO - 2018-07-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:53:15 --> Utf8 Class Initialized
INFO - 2018-07-30 20:53:15 --> URI Class Initialized
INFO - 2018-07-30 20:53:15 --> Router Class Initialized
INFO - 2018-07-30 20:53:15 --> Output Class Initialized
INFO - 2018-07-30 20:53:15 --> Security Class Initialized
DEBUG - 2018-07-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:53:15 --> CSRF cookie sent
INFO - 2018-07-30 20:53:15 --> Input Class Initialized
INFO - 2018-07-30 20:53:15 --> Language Class Initialized
INFO - 2018-07-30 20:53:15 --> Loader Class Initialized
INFO - 2018-07-30 20:53:15 --> Helper loaded: url_helper
INFO - 2018-07-30 20:53:15 --> Helper loaded: form_helper
INFO - 2018-07-30 20:53:15 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:53:15 --> User Agent Class Initialized
INFO - 2018-07-30 20:53:15 --> Controller Class Initialized
INFO - 2018-07-30 20:53:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:53:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:53:15 --> Pixel_Model class loaded
INFO - 2018-07-30 20:53:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:53:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:53:15 --> Database Driver Class Initialized
INFO - 2018-07-30 20:53:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 20:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:53:15 --> Final output sent to browser
DEBUG - 2018-07-30 20:53:15 --> Total execution time: 0.0473
INFO - 2018-07-30 20:54:51 --> Config Class Initialized
INFO - 2018-07-30 20:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:54:51 --> Utf8 Class Initialized
INFO - 2018-07-30 20:54:51 --> URI Class Initialized
INFO - 2018-07-30 20:54:51 --> Router Class Initialized
INFO - 2018-07-30 20:54:51 --> Output Class Initialized
INFO - 2018-07-30 20:54:51 --> Security Class Initialized
DEBUG - 2018-07-30 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:54:51 --> CSRF cookie sent
INFO - 2018-07-30 20:54:51 --> CSRF token verified
INFO - 2018-07-30 20:54:51 --> Input Class Initialized
INFO - 2018-07-30 20:54:51 --> Language Class Initialized
INFO - 2018-07-30 20:54:51 --> Loader Class Initialized
INFO - 2018-07-30 20:54:51 --> Helper loaded: url_helper
INFO - 2018-07-30 20:54:51 --> Helper loaded: form_helper
INFO - 2018-07-30 20:54:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:54:51 --> User Agent Class Initialized
INFO - 2018-07-30 20:54:51 --> Controller Class Initialized
INFO - 2018-07-30 20:54:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:54:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:54:51 --> Pixel_Model class loaded
INFO - 2018-07-30 20:54:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:51 --> Form Validation Class Initialized
INFO - 2018-07-30 20:54:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:54:51 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:52 --> Config Class Initialized
INFO - 2018-07-30 20:54:52 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:54:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:54:52 --> Utf8 Class Initialized
INFO - 2018-07-30 20:54:52 --> URI Class Initialized
INFO - 2018-07-30 20:54:52 --> Router Class Initialized
INFO - 2018-07-30 20:54:52 --> Output Class Initialized
INFO - 2018-07-30 20:54:52 --> Security Class Initialized
DEBUG - 2018-07-30 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:54:52 --> CSRF cookie sent
INFO - 2018-07-30 20:54:52 --> Input Class Initialized
INFO - 2018-07-30 20:54:52 --> Language Class Initialized
INFO - 2018-07-30 20:54:52 --> Loader Class Initialized
INFO - 2018-07-30 20:54:52 --> Helper loaded: url_helper
INFO - 2018-07-30 20:54:52 --> Helper loaded: form_helper
INFO - 2018-07-30 20:54:52 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:54:52 --> User Agent Class Initialized
INFO - 2018-07-30 20:54:52 --> Controller Class Initialized
INFO - 2018-07-30 20:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:54:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:54:52 --> Pixel_Model class loaded
INFO - 2018-07-30 20:54:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:52 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:54:52 --> Final output sent to browser
DEBUG - 2018-07-30 20:54:52 --> Total execution time: 0.0423
INFO - 2018-07-30 20:54:59 --> Config Class Initialized
INFO - 2018-07-30 20:54:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:54:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:54:59 --> Utf8 Class Initialized
INFO - 2018-07-30 20:54:59 --> URI Class Initialized
INFO - 2018-07-30 20:54:59 --> Router Class Initialized
INFO - 2018-07-30 20:54:59 --> Output Class Initialized
INFO - 2018-07-30 20:54:59 --> Security Class Initialized
DEBUG - 2018-07-30 20:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:54:59 --> CSRF cookie sent
INFO - 2018-07-30 20:54:59 --> Input Class Initialized
INFO - 2018-07-30 20:54:59 --> Language Class Initialized
INFO - 2018-07-30 20:54:59 --> Loader Class Initialized
INFO - 2018-07-30 20:54:59 --> Helper loaded: url_helper
INFO - 2018-07-30 20:54:59 --> Helper loaded: form_helper
INFO - 2018-07-30 20:54:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:54:59 --> User Agent Class Initialized
INFO - 2018-07-30 20:54:59 --> Controller Class Initialized
INFO - 2018-07-30 20:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:54:59 --> Pixel_Model class loaded
INFO - 2018-07-30 20:54:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:59 --> Database Driver Class Initialized
INFO - 2018-07-30 20:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 20:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:54:59 --> Final output sent to browser
DEBUG - 2018-07-30 20:54:59 --> Total execution time: 0.0459
INFO - 2018-07-30 20:55:53 --> Config Class Initialized
INFO - 2018-07-30 20:55:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:55:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:55:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:55:53 --> URI Class Initialized
INFO - 2018-07-30 20:55:53 --> Router Class Initialized
INFO - 2018-07-30 20:55:53 --> Output Class Initialized
INFO - 2018-07-30 20:55:53 --> Security Class Initialized
DEBUG - 2018-07-30 20:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:55:53 --> CSRF cookie sent
INFO - 2018-07-30 20:55:53 --> Input Class Initialized
INFO - 2018-07-30 20:55:53 --> Language Class Initialized
INFO - 2018-07-30 20:55:53 --> Loader Class Initialized
INFO - 2018-07-30 20:55:53 --> Helper loaded: url_helper
INFO - 2018-07-30 20:55:53 --> Helper loaded: form_helper
INFO - 2018-07-30 20:55:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:55:53 --> User Agent Class Initialized
INFO - 2018-07-30 20:55:53 --> Controller Class Initialized
INFO - 2018-07-30 20:55:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:55:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:55:53 --> Pixel_Model class loaded
INFO - 2018-07-30 20:55:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:55:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 20:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:55:53 --> Final output sent to browser
DEBUG - 2018-07-30 20:55:53 --> Total execution time: 0.0557
INFO - 2018-07-30 20:56:08 --> Config Class Initialized
INFO - 2018-07-30 20:56:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:08 --> URI Class Initialized
INFO - 2018-07-30 20:56:08 --> Router Class Initialized
INFO - 2018-07-30 20:56:08 --> Output Class Initialized
INFO - 2018-07-30 20:56:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:08 --> CSRF cookie sent
INFO - 2018-07-30 20:56:08 --> CSRF token verified
INFO - 2018-07-30 20:56:08 --> Input Class Initialized
INFO - 2018-07-30 20:56:08 --> Language Class Initialized
INFO - 2018-07-30 20:56:08 --> Loader Class Initialized
INFO - 2018-07-30 20:56:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:08 --> Controller Class Initialized
INFO - 2018-07-30 20:56:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:08 --> Form Validation Class Initialized
INFO - 2018-07-30 20:56:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:56:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:09 --> Config Class Initialized
INFO - 2018-07-30 20:56:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:09 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:09 --> URI Class Initialized
INFO - 2018-07-30 20:56:09 --> Router Class Initialized
INFO - 2018-07-30 20:56:09 --> Output Class Initialized
INFO - 2018-07-30 20:56:09 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:09 --> CSRF cookie sent
INFO - 2018-07-30 20:56:09 --> Input Class Initialized
INFO - 2018-07-30 20:56:09 --> Language Class Initialized
INFO - 2018-07-30 20:56:09 --> Loader Class Initialized
INFO - 2018-07-30 20:56:09 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:09 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:09 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:09 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:09 --> Controller Class Initialized
INFO - 2018-07-30 20:56:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:09 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:09 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:09 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-07-30 20:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:56:09 --> Final output sent to browser
DEBUG - 2018-07-30 20:56:09 --> Total execution time: 0.0455
INFO - 2018-07-30 20:56:35 --> Config Class Initialized
INFO - 2018-07-30 20:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:35 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:35 --> URI Class Initialized
INFO - 2018-07-30 20:56:35 --> Router Class Initialized
INFO - 2018-07-30 20:56:35 --> Output Class Initialized
INFO - 2018-07-30 20:56:35 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:35 --> CSRF cookie sent
INFO - 2018-07-30 20:56:35 --> CSRF token verified
INFO - 2018-07-30 20:56:35 --> Input Class Initialized
INFO - 2018-07-30 20:56:35 --> Language Class Initialized
INFO - 2018-07-30 20:56:35 --> Loader Class Initialized
INFO - 2018-07-30 20:56:35 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:35 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:35 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:35 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:35 --> Controller Class Initialized
INFO - 2018-07-30 20:56:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:35 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:35 --> Form Validation Class Initialized
INFO - 2018-07-30 20:56:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:56:35 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:36 --> Config Class Initialized
INFO - 2018-07-30 20:56:36 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:36 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:36 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:36 --> URI Class Initialized
INFO - 2018-07-30 20:56:36 --> Router Class Initialized
INFO - 2018-07-30 20:56:36 --> Output Class Initialized
INFO - 2018-07-30 20:56:36 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:36 --> CSRF cookie sent
INFO - 2018-07-30 20:56:36 --> Input Class Initialized
INFO - 2018-07-30 20:56:36 --> Language Class Initialized
INFO - 2018-07-30 20:56:36 --> Loader Class Initialized
INFO - 2018-07-30 20:56:36 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:36 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:36 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:36 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:36 --> Controller Class Initialized
INFO - 2018-07-30 20:56:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:36 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:36 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-07-30 20:56:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:56:36 --> Final output sent to browser
DEBUG - 2018-07-30 20:56:36 --> Total execution time: 0.0455
INFO - 2018-07-30 20:56:53 --> Config Class Initialized
INFO - 2018-07-30 20:56:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:53 --> URI Class Initialized
INFO - 2018-07-30 20:56:53 --> Router Class Initialized
INFO - 2018-07-30 20:56:53 --> Output Class Initialized
INFO - 2018-07-30 20:56:53 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:53 --> CSRF cookie sent
INFO - 2018-07-30 20:56:53 --> CSRF token verified
INFO - 2018-07-30 20:56:53 --> Input Class Initialized
INFO - 2018-07-30 20:56:53 --> Language Class Initialized
INFO - 2018-07-30 20:56:53 --> Loader Class Initialized
INFO - 2018-07-30 20:56:53 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:53 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:53 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:53 --> Controller Class Initialized
INFO - 2018-07-30 20:56:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:53 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:53 --> Form Validation Class Initialized
INFO - 2018-07-30 20:56:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:56:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:53 --> Config Class Initialized
INFO - 2018-07-30 20:56:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:56:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:56:53 --> Utf8 Class Initialized
INFO - 2018-07-30 20:56:53 --> URI Class Initialized
INFO - 2018-07-30 20:56:53 --> Router Class Initialized
INFO - 2018-07-30 20:56:53 --> Output Class Initialized
INFO - 2018-07-30 20:56:53 --> Security Class Initialized
DEBUG - 2018-07-30 20:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:56:53 --> CSRF cookie sent
INFO - 2018-07-30 20:56:53 --> Input Class Initialized
INFO - 2018-07-30 20:56:53 --> Language Class Initialized
INFO - 2018-07-30 20:56:53 --> Loader Class Initialized
INFO - 2018-07-30 20:56:53 --> Helper loaded: url_helper
INFO - 2018-07-30 20:56:53 --> Helper loaded: form_helper
INFO - 2018-07-30 20:56:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:56:53 --> User Agent Class Initialized
INFO - 2018-07-30 20:56:53 --> Controller Class Initialized
INFO - 2018-07-30 20:56:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:56:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:56:53 --> Pixel_Model class loaded
INFO - 2018-07-30 20:56:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:53 --> Database Driver Class Initialized
INFO - 2018-07-30 20:56:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 20:56:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:56:53 --> Final output sent to browser
DEBUG - 2018-07-30 20:56:53 --> Total execution time: 0.0519
INFO - 2018-07-30 20:57:06 --> Config Class Initialized
INFO - 2018-07-30 20:57:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:57:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:57:06 --> Utf8 Class Initialized
INFO - 2018-07-30 20:57:06 --> URI Class Initialized
INFO - 2018-07-30 20:57:06 --> Router Class Initialized
INFO - 2018-07-30 20:57:06 --> Output Class Initialized
INFO - 2018-07-30 20:57:06 --> Security Class Initialized
DEBUG - 2018-07-30 20:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:57:06 --> CSRF cookie sent
INFO - 2018-07-30 20:57:06 --> CSRF token verified
INFO - 2018-07-30 20:57:06 --> Input Class Initialized
INFO - 2018-07-30 20:57:06 --> Language Class Initialized
INFO - 2018-07-30 20:57:06 --> Loader Class Initialized
INFO - 2018-07-30 20:57:06 --> Helper loaded: url_helper
INFO - 2018-07-30 20:57:06 --> Helper loaded: form_helper
INFO - 2018-07-30 20:57:06 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:57:06 --> User Agent Class Initialized
INFO - 2018-07-30 20:57:06 --> Controller Class Initialized
INFO - 2018-07-30 20:57:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:57:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:57:06 --> Pixel_Model class loaded
INFO - 2018-07-30 20:57:06 --> Database Driver Class Initialized
INFO - 2018-07-30 20:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:57:06 --> Form Validation Class Initialized
INFO - 2018-07-30 20:57:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 20:57:06 --> Database Driver Class Initialized
INFO - 2018-07-30 20:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:57:07 --> Config Class Initialized
INFO - 2018-07-30 20:57:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:57:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:57:07 --> Utf8 Class Initialized
INFO - 2018-07-30 20:57:07 --> URI Class Initialized
INFO - 2018-07-30 20:57:07 --> Router Class Initialized
INFO - 2018-07-30 20:57:07 --> Output Class Initialized
INFO - 2018-07-30 20:57:07 --> Security Class Initialized
DEBUG - 2018-07-30 20:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:57:07 --> CSRF cookie sent
INFO - 2018-07-30 20:57:07 --> Input Class Initialized
INFO - 2018-07-30 20:57:07 --> Language Class Initialized
INFO - 2018-07-30 20:57:07 --> Loader Class Initialized
INFO - 2018-07-30 20:57:07 --> Helper loaded: url_helper
INFO - 2018-07-30 20:57:07 --> Helper loaded: form_helper
INFO - 2018-07-30 20:57:07 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:57:07 --> User Agent Class Initialized
INFO - 2018-07-30 20:57:07 --> Controller Class Initialized
INFO - 2018-07-30 20:57:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:57:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:57:07 --> Pixel_Model class loaded
INFO - 2018-07-30 20:57:07 --> Database Driver Class Initialized
INFO - 2018-07-30 20:57:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 20:57:08 --> Config Class Initialized
INFO - 2018-07-30 20:57:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 20:57:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 20:57:08 --> Utf8 Class Initialized
INFO - 2018-07-30 20:57:08 --> URI Class Initialized
INFO - 2018-07-30 20:57:08 --> Router Class Initialized
INFO - 2018-07-30 20:57:08 --> Output Class Initialized
INFO - 2018-07-30 20:57:08 --> Security Class Initialized
DEBUG - 2018-07-30 20:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 20:57:08 --> CSRF cookie sent
INFO - 2018-07-30 20:57:08 --> Input Class Initialized
INFO - 2018-07-30 20:57:08 --> Language Class Initialized
INFO - 2018-07-30 20:57:08 --> Loader Class Initialized
INFO - 2018-07-30 20:57:08 --> Helper loaded: url_helper
INFO - 2018-07-30 20:57:08 --> Helper loaded: form_helper
INFO - 2018-07-30 20:57:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 20:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 20:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 20:57:08 --> User Agent Class Initialized
INFO - 2018-07-30 20:57:08 --> Controller Class Initialized
INFO - 2018-07-30 20:57:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 20:57:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 20:57:08 --> Pixel_Model class loaded
INFO - 2018-07-30 20:57:08 --> Database Driver Class Initialized
INFO - 2018-07-30 20:57:08 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 20:57:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 20:57:08 --> Could not find the language line "req_email"
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 20:57:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 20:57:08 --> Final output sent to browser
DEBUG - 2018-07-30 20:57:08 --> Total execution time: 0.0380
INFO - 2018-07-30 21:01:25 --> Config Class Initialized
INFO - 2018-07-30 21:01:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:01:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:01:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:01:25 --> URI Class Initialized
INFO - 2018-07-30 21:01:25 --> Router Class Initialized
INFO - 2018-07-30 21:01:25 --> Output Class Initialized
INFO - 2018-07-30 21:01:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:01:25 --> CSRF cookie sent
INFO - 2018-07-30 21:01:25 --> CSRF token verified
INFO - 2018-07-30 21:01:25 --> Input Class Initialized
INFO - 2018-07-30 21:01:25 --> Language Class Initialized
INFO - 2018-07-30 21:01:25 --> Loader Class Initialized
INFO - 2018-07-30 21:01:25 --> Helper loaded: url_helper
INFO - 2018-07-30 21:01:25 --> Helper loaded: form_helper
INFO - 2018-07-30 21:01:25 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:01:25 --> User Agent Class Initialized
INFO - 2018-07-30 21:01:25 --> Controller Class Initialized
INFO - 2018-07-30 21:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:01:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:01:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:01:25 --> Form Validation Class Initialized
INFO - 2018-07-30 21:01:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:01:25 --> Pixel_Model class loaded
INFO - 2018-07-30 21:01:25 --> Database Driver Class Initialized
INFO - 2018-07-30 21:01:25 --> Model "RegistrationModel" initialized
INFO - 2018-07-30 21:01:26 --> Config Class Initialized
INFO - 2018-07-30 21:01:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:01:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:01:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:01:26 --> URI Class Initialized
INFO - 2018-07-30 21:01:26 --> Router Class Initialized
INFO - 2018-07-30 21:01:26 --> Output Class Initialized
INFO - 2018-07-30 21:01:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:01:26 --> CSRF cookie sent
INFO - 2018-07-30 21:01:26 --> Input Class Initialized
INFO - 2018-07-30 21:01:26 --> Language Class Initialized
INFO - 2018-07-30 21:01:26 --> Loader Class Initialized
INFO - 2018-07-30 21:01:26 --> Helper loaded: url_helper
INFO - 2018-07-30 21:01:26 --> Helper loaded: form_helper
INFO - 2018-07-30 21:01:26 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:01:26 --> User Agent Class Initialized
INFO - 2018-07-30 21:01:26 --> Controller Class Initialized
INFO - 2018-07-30 21:01:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:01:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:01:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:01:26 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-30 21:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:01:26 --> Final output sent to browser
DEBUG - 2018-07-30 21:01:26 --> Total execution time: 0.0338
INFO - 2018-07-30 21:01:49 --> Config Class Initialized
INFO - 2018-07-30 21:01:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:01:49 --> Utf8 Class Initialized
INFO - 2018-07-30 21:01:49 --> URI Class Initialized
INFO - 2018-07-30 21:01:49 --> Router Class Initialized
INFO - 2018-07-30 21:01:49 --> Output Class Initialized
INFO - 2018-07-30 21:01:49 --> Security Class Initialized
DEBUG - 2018-07-30 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:01:49 --> CSRF cookie sent
INFO - 2018-07-30 21:01:49 --> Input Class Initialized
INFO - 2018-07-30 21:01:49 --> Language Class Initialized
INFO - 2018-07-30 21:01:49 --> Loader Class Initialized
INFO - 2018-07-30 21:01:49 --> Helper loaded: url_helper
INFO - 2018-07-30 21:01:49 --> Helper loaded: form_helper
INFO - 2018-07-30 21:01:49 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:01:49 --> User Agent Class Initialized
INFO - 2018-07-30 21:01:49 --> Controller Class Initialized
INFO - 2018-07-30 21:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:01:49 --> Pixel_Model class loaded
INFO - 2018-07-30 21:01:49 --> Database Driver Class Initialized
INFO - 2018-07-30 21:01:49 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 21:01:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:01:49 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 21:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:01:49 --> Final output sent to browser
DEBUG - 2018-07-30 21:01:49 --> Total execution time: 0.0376
INFO - 2018-07-30 21:02:28 --> Config Class Initialized
INFO - 2018-07-30 21:02:28 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:02:28 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:02:28 --> Utf8 Class Initialized
INFO - 2018-07-30 21:02:28 --> URI Class Initialized
INFO - 2018-07-30 21:02:28 --> Router Class Initialized
INFO - 2018-07-30 21:02:28 --> Output Class Initialized
INFO - 2018-07-30 21:02:28 --> Security Class Initialized
DEBUG - 2018-07-30 21:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:02:28 --> CSRF cookie sent
INFO - 2018-07-30 21:02:28 --> CSRF token verified
INFO - 2018-07-30 21:02:28 --> Input Class Initialized
INFO - 2018-07-30 21:02:28 --> Language Class Initialized
INFO - 2018-07-30 21:02:28 --> Loader Class Initialized
INFO - 2018-07-30 21:02:28 --> Helper loaded: url_helper
INFO - 2018-07-30 21:02:28 --> Helper loaded: form_helper
INFO - 2018-07-30 21:02:28 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:02:28 --> User Agent Class Initialized
INFO - 2018-07-30 21:02:28 --> Controller Class Initialized
INFO - 2018-07-30 21:02:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:02:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:02:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:02:28 --> Form Validation Class Initialized
INFO - 2018-07-30 21:02:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:02:28 --> Pixel_Model class loaded
INFO - 2018-07-30 21:02:28 --> Database Driver Class Initialized
INFO - 2018-07-30 21:02:28 --> Model "RegistrationModel" initialized
INFO - 2018-07-30 21:02:28 --> Helper loaded: string_helper
INFO - 2018-07-30 21:02:28 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-07-30 21:02:28 --> Database Driver Class Initialized
INFO - 2018-07-30 21:02:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-07-30 21:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-07-30 21:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-07-30 21:02:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-07-30 21:02:28 --> Email Class Initialized
INFO - 2018-07-30 21:02:28 --> Language file loaded: language/english/email_lang.php
INFO - 2018-07-30 21:02:29 --> Config Class Initialized
INFO - 2018-07-30 21:02:29 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:02:29 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:02:29 --> Utf8 Class Initialized
INFO - 2018-07-30 21:02:29 --> URI Class Initialized
INFO - 2018-07-30 21:02:29 --> Router Class Initialized
INFO - 2018-07-30 21:02:29 --> Output Class Initialized
INFO - 2018-07-30 21:02:29 --> Security Class Initialized
DEBUG - 2018-07-30 21:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:02:29 --> CSRF cookie sent
INFO - 2018-07-30 21:02:29 --> Input Class Initialized
INFO - 2018-07-30 21:02:29 --> Language Class Initialized
INFO - 2018-07-30 21:02:29 --> Loader Class Initialized
INFO - 2018-07-30 21:02:29 --> Helper loaded: url_helper
INFO - 2018-07-30 21:02:29 --> Helper loaded: form_helper
INFO - 2018-07-30 21:02:29 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:02:29 --> User Agent Class Initialized
INFO - 2018-07-30 21:02:29 --> Controller Class Initialized
INFO - 2018-07-30 21:02:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:02:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:02:30 --> Config Class Initialized
INFO - 2018-07-30 21:02:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:02:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:02:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:02:30 --> URI Class Initialized
INFO - 2018-07-30 21:02:30 --> Router Class Initialized
INFO - 2018-07-30 21:02:30 --> Output Class Initialized
INFO - 2018-07-30 21:02:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:02:30 --> CSRF cookie sent
INFO - 2018-07-30 21:02:30 --> Input Class Initialized
INFO - 2018-07-30 21:02:30 --> Language Class Initialized
INFO - 2018-07-30 21:02:30 --> Loader Class Initialized
INFO - 2018-07-30 21:02:30 --> Helper loaded: url_helper
INFO - 2018-07-30 21:02:30 --> Helper loaded: form_helper
INFO - 2018-07-30 21:02:30 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:02:30 --> User Agent Class Initialized
INFO - 2018-07-30 21:02:30 --> Controller Class Initialized
INFO - 2018-07-30 21:02:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:02:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:02:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:02:30 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:02:30 --> Final output sent to browser
DEBUG - 2018-07-30 21:02:30 --> Total execution time: 0.0269
INFO - 2018-07-30 21:02:58 --> Config Class Initialized
INFO - 2018-07-30 21:02:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:02:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:02:58 --> Utf8 Class Initialized
INFO - 2018-07-30 21:02:58 --> URI Class Initialized
INFO - 2018-07-30 21:02:58 --> Router Class Initialized
INFO - 2018-07-30 21:02:58 --> Output Class Initialized
INFO - 2018-07-30 21:02:58 --> Security Class Initialized
DEBUG - 2018-07-30 21:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:02:58 --> CSRF cookie sent
INFO - 2018-07-30 21:02:58 --> CSRF token verified
INFO - 2018-07-30 21:02:58 --> Input Class Initialized
INFO - 2018-07-30 21:02:58 --> Language Class Initialized
INFO - 2018-07-30 21:02:58 --> Loader Class Initialized
INFO - 2018-07-30 21:02:58 --> Helper loaded: url_helper
INFO - 2018-07-30 21:02:58 --> Helper loaded: form_helper
INFO - 2018-07-30 21:02:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:02:58 --> User Agent Class Initialized
INFO - 2018-07-30 21:02:58 --> Controller Class Initialized
INFO - 2018-07-30 21:02:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:02:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:02:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:02:58 --> Form Validation Class Initialized
INFO - 2018-07-30 21:02:58 --> Pixel_Model class loaded
INFO - 2018-07-30 21:02:58 --> Database Driver Class Initialized
INFO - 2018-07-30 21:02:58 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:02:59 --> Config Class Initialized
INFO - 2018-07-30 21:02:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:02:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:02:59 --> Utf8 Class Initialized
INFO - 2018-07-30 21:02:59 --> URI Class Initialized
INFO - 2018-07-30 21:02:59 --> Router Class Initialized
INFO - 2018-07-30 21:02:59 --> Output Class Initialized
INFO - 2018-07-30 21:02:59 --> Security Class Initialized
DEBUG - 2018-07-30 21:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:02:59 --> CSRF cookie sent
INFO - 2018-07-30 21:02:59 --> Input Class Initialized
INFO - 2018-07-30 21:02:59 --> Language Class Initialized
INFO - 2018-07-30 21:02:59 --> Loader Class Initialized
INFO - 2018-07-30 21:02:59 --> Helper loaded: url_helper
INFO - 2018-07-30 21:02:59 --> Helper loaded: form_helper
INFO - 2018-07-30 21:02:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:02:59 --> User Agent Class Initialized
INFO - 2018-07-30 21:02:59 --> Controller Class Initialized
INFO - 2018-07-30 21:02:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:02:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:02:59 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:02:59 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:02:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:02:59 --> Final output sent to browser
DEBUG - 2018-07-30 21:02:59 --> Total execution time: 0.0348
INFO - 2018-07-30 21:03:55 --> Config Class Initialized
INFO - 2018-07-30 21:03:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:03:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:03:55 --> Utf8 Class Initialized
INFO - 2018-07-30 21:03:55 --> URI Class Initialized
INFO - 2018-07-30 21:03:55 --> Router Class Initialized
INFO - 2018-07-30 21:03:55 --> Output Class Initialized
INFO - 2018-07-30 21:03:55 --> Security Class Initialized
DEBUG - 2018-07-30 21:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:03:55 --> CSRF cookie sent
INFO - 2018-07-30 21:03:55 --> Input Class Initialized
INFO - 2018-07-30 21:03:55 --> Language Class Initialized
INFO - 2018-07-30 21:03:55 --> Loader Class Initialized
INFO - 2018-07-30 21:03:55 --> Helper loaded: url_helper
INFO - 2018-07-30 21:03:55 --> Helper loaded: form_helper
INFO - 2018-07-30 21:03:55 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:03:55 --> User Agent Class Initialized
INFO - 2018-07-30 21:03:55 --> Controller Class Initialized
INFO - 2018-07-30 21:03:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:03:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:03:56 --> Config Class Initialized
INFO - 2018-07-30 21:03:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:03:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:03:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:03:56 --> URI Class Initialized
INFO - 2018-07-30 21:03:56 --> Router Class Initialized
INFO - 2018-07-30 21:03:56 --> Output Class Initialized
INFO - 2018-07-30 21:03:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:03:56 --> CSRF cookie sent
INFO - 2018-07-30 21:03:56 --> Input Class Initialized
INFO - 2018-07-30 21:03:56 --> Language Class Initialized
INFO - 2018-07-30 21:03:56 --> Loader Class Initialized
INFO - 2018-07-30 21:03:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:03:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:03:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:03:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:03:56 --> Controller Class Initialized
INFO - 2018-07-30 21:03:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:03:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:03:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:03:56 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:03:56 --> Final output sent to browser
DEBUG - 2018-07-30 21:03:56 --> Total execution time: 0.0244
INFO - 2018-07-30 21:04:13 --> Config Class Initialized
INFO - 2018-07-30 21:04:13 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:04:13 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:04:13 --> Utf8 Class Initialized
INFO - 2018-07-30 21:04:13 --> URI Class Initialized
INFO - 2018-07-30 21:04:13 --> Router Class Initialized
INFO - 2018-07-30 21:04:13 --> Output Class Initialized
INFO - 2018-07-30 21:04:13 --> Security Class Initialized
DEBUG - 2018-07-30 21:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:04:13 --> CSRF cookie sent
INFO - 2018-07-30 21:04:13 --> CSRF token verified
INFO - 2018-07-30 21:04:13 --> Input Class Initialized
INFO - 2018-07-30 21:04:13 --> Language Class Initialized
INFO - 2018-07-30 21:04:13 --> Loader Class Initialized
INFO - 2018-07-30 21:04:13 --> Helper loaded: url_helper
INFO - 2018-07-30 21:04:13 --> Helper loaded: form_helper
INFO - 2018-07-30 21:04:13 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:04:13 --> User Agent Class Initialized
INFO - 2018-07-30 21:04:13 --> Controller Class Initialized
INFO - 2018-07-30 21:04:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:04:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:04:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:04:14 --> Form Validation Class Initialized
INFO - 2018-07-30 21:04:14 --> Pixel_Model class loaded
INFO - 2018-07-30 21:04:14 --> Database Driver Class Initialized
INFO - 2018-07-30 21:04:14 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:04:14 --> Config Class Initialized
INFO - 2018-07-30 21:04:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:04:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:04:14 --> Utf8 Class Initialized
INFO - 2018-07-30 21:04:14 --> URI Class Initialized
INFO - 2018-07-30 21:04:14 --> Router Class Initialized
INFO - 2018-07-30 21:04:14 --> Output Class Initialized
INFO - 2018-07-30 21:04:14 --> Security Class Initialized
DEBUG - 2018-07-30 21:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:04:14 --> CSRF cookie sent
INFO - 2018-07-30 21:04:14 --> Input Class Initialized
INFO - 2018-07-30 21:04:14 --> Language Class Initialized
INFO - 2018-07-30 21:04:14 --> Loader Class Initialized
INFO - 2018-07-30 21:04:14 --> Helper loaded: url_helper
INFO - 2018-07-30 21:04:14 --> Helper loaded: form_helper
INFO - 2018-07-30 21:04:14 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:04:14 --> User Agent Class Initialized
INFO - 2018-07-30 21:04:14 --> Controller Class Initialized
INFO - 2018-07-30 21:04:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:04:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:04:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:04:14 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:04:14 --> Final output sent to browser
DEBUG - 2018-07-30 21:04:14 --> Total execution time: 0.0257
INFO - 2018-07-30 21:14:43 --> Config Class Initialized
INFO - 2018-07-30 21:14:43 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:14:43 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:14:43 --> Utf8 Class Initialized
INFO - 2018-07-30 21:14:43 --> URI Class Initialized
INFO - 2018-07-30 21:14:43 --> Router Class Initialized
INFO - 2018-07-30 21:14:43 --> Output Class Initialized
INFO - 2018-07-30 21:14:43 --> Security Class Initialized
DEBUG - 2018-07-30 21:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:14:43 --> CSRF cookie sent
INFO - 2018-07-30 21:14:43 --> Input Class Initialized
INFO - 2018-07-30 21:14:43 --> Language Class Initialized
ERROR - 2018-07-30 21:14:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-30 21:14:46 --> Config Class Initialized
INFO - 2018-07-30 21:14:46 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:14:46 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:14:46 --> Utf8 Class Initialized
INFO - 2018-07-30 21:14:46 --> URI Class Initialized
DEBUG - 2018-07-30 21:14:46 --> No URI present. Default controller set.
INFO - 2018-07-30 21:14:46 --> Router Class Initialized
INFO - 2018-07-30 21:14:46 --> Output Class Initialized
INFO - 2018-07-30 21:14:46 --> Security Class Initialized
DEBUG - 2018-07-30 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:14:46 --> CSRF cookie sent
INFO - 2018-07-30 21:14:46 --> Input Class Initialized
INFO - 2018-07-30 21:14:46 --> Language Class Initialized
INFO - 2018-07-30 21:14:46 --> Loader Class Initialized
INFO - 2018-07-30 21:14:46 --> Helper loaded: url_helper
INFO - 2018-07-30 21:14:46 --> Helper loaded: form_helper
INFO - 2018-07-30 21:14:46 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:14:46 --> User Agent Class Initialized
INFO - 2018-07-30 21:14:46 --> Controller Class Initialized
INFO - 2018-07-30 21:14:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:14:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:14:46 --> Pixel_Model class loaded
INFO - 2018-07-30 21:14:46 --> Database Driver Class Initialized
INFO - 2018-07-30 21:14:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:14:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:14:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:14:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 21:14:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:14:46 --> Final output sent to browser
DEBUG - 2018-07-30 21:14:46 --> Total execution time: 0.0335
INFO - 2018-07-30 21:20:43 --> Config Class Initialized
INFO - 2018-07-30 21:20:43 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:43 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:43 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:43 --> URI Class Initialized
DEBUG - 2018-07-30 21:20:43 --> No URI present. Default controller set.
INFO - 2018-07-30 21:20:43 --> Router Class Initialized
INFO - 2018-07-30 21:20:43 --> Output Class Initialized
INFO - 2018-07-30 21:20:43 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:43 --> CSRF cookie sent
INFO - 2018-07-30 21:20:43 --> Input Class Initialized
INFO - 2018-07-30 21:20:43 --> Language Class Initialized
INFO - 2018-07-30 21:20:43 --> Loader Class Initialized
INFO - 2018-07-30 21:20:43 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:43 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:43 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:43 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:43 --> Controller Class Initialized
INFO - 2018-07-30 21:20:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:43 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:43 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 21:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:20:43 --> Final output sent to browser
DEBUG - 2018-07-30 21:20:43 --> Total execution time: 0.0484
INFO - 2018-07-30 21:20:48 --> Config Class Initialized
INFO - 2018-07-30 21:20:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:48 --> URI Class Initialized
INFO - 2018-07-30 21:20:48 --> Router Class Initialized
INFO - 2018-07-30 21:20:48 --> Output Class Initialized
INFO - 2018-07-30 21:20:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:48 --> CSRF cookie sent
INFO - 2018-07-30 21:20:48 --> CSRF token verified
INFO - 2018-07-30 21:20:48 --> Input Class Initialized
INFO - 2018-07-30 21:20:48 --> Language Class Initialized
INFO - 2018-07-30 21:20:48 --> Loader Class Initialized
INFO - 2018-07-30 21:20:48 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:48 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:48 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:48 --> Controller Class Initialized
INFO - 2018-07-30 21:20:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:48 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:48 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:48 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:49 --> Config Class Initialized
INFO - 2018-07-30 21:20:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:49 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:49 --> URI Class Initialized
INFO - 2018-07-30 21:20:49 --> Router Class Initialized
INFO - 2018-07-30 21:20:49 --> Output Class Initialized
INFO - 2018-07-30 21:20:49 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:49 --> CSRF cookie sent
INFO - 2018-07-30 21:20:49 --> Input Class Initialized
INFO - 2018-07-30 21:20:49 --> Language Class Initialized
INFO - 2018-07-30 21:20:49 --> Loader Class Initialized
INFO - 2018-07-30 21:20:49 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:49 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:49 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:49 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:49 --> Controller Class Initialized
INFO - 2018-07-30 21:20:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:49 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:49 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:49 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-30 21:20:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:20:49 --> Final output sent to browser
DEBUG - 2018-07-30 21:20:49 --> Total execution time: 0.0476
INFO - 2018-07-30 21:20:53 --> Config Class Initialized
INFO - 2018-07-30 21:20:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:53 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:53 --> URI Class Initialized
INFO - 2018-07-30 21:20:53 --> Router Class Initialized
INFO - 2018-07-30 21:20:53 --> Output Class Initialized
INFO - 2018-07-30 21:20:53 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:53 --> CSRF cookie sent
INFO - 2018-07-30 21:20:53 --> CSRF token verified
INFO - 2018-07-30 21:20:53 --> Input Class Initialized
INFO - 2018-07-30 21:20:53 --> Language Class Initialized
INFO - 2018-07-30 21:20:53 --> Loader Class Initialized
INFO - 2018-07-30 21:20:53 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:53 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:53 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:53 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:53 --> Controller Class Initialized
INFO - 2018-07-30 21:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:53 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:53 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:53 --> Form Validation Class Initialized
INFO - 2018-07-30 21:20:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:20:53 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:54 --> Config Class Initialized
INFO - 2018-07-30 21:20:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:54 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:54 --> URI Class Initialized
INFO - 2018-07-30 21:20:54 --> Router Class Initialized
INFO - 2018-07-30 21:20:54 --> Output Class Initialized
INFO - 2018-07-30 21:20:54 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:54 --> CSRF cookie sent
INFO - 2018-07-30 21:20:54 --> Input Class Initialized
INFO - 2018-07-30 21:20:54 --> Language Class Initialized
INFO - 2018-07-30 21:20:54 --> Loader Class Initialized
INFO - 2018-07-30 21:20:54 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:54 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:54 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:54 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:54 --> Controller Class Initialized
INFO - 2018-07-30 21:20:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:54 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:54 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:54 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-30 21:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:20:54 --> Final output sent to browser
DEBUG - 2018-07-30 21:20:54 --> Total execution time: 0.0417
INFO - 2018-07-30 21:20:56 --> Config Class Initialized
INFO - 2018-07-30 21:20:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:56 --> URI Class Initialized
INFO - 2018-07-30 21:20:56 --> Router Class Initialized
INFO - 2018-07-30 21:20:56 --> Output Class Initialized
INFO - 2018-07-30 21:20:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:56 --> CSRF cookie sent
INFO - 2018-07-30 21:20:56 --> CSRF token verified
INFO - 2018-07-30 21:20:56 --> Input Class Initialized
INFO - 2018-07-30 21:20:56 --> Language Class Initialized
INFO - 2018-07-30 21:20:56 --> Loader Class Initialized
INFO - 2018-07-30 21:20:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:56 --> Controller Class Initialized
INFO - 2018-07-30 21:20:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:56 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:56 --> Form Validation Class Initialized
INFO - 2018-07-30 21:20:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:20:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:58 --> Config Class Initialized
INFO - 2018-07-30 21:20:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:20:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:20:58 --> Utf8 Class Initialized
INFO - 2018-07-30 21:20:58 --> URI Class Initialized
INFO - 2018-07-30 21:20:58 --> Router Class Initialized
INFO - 2018-07-30 21:20:58 --> Output Class Initialized
INFO - 2018-07-30 21:20:58 --> Security Class Initialized
DEBUG - 2018-07-30 21:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:20:58 --> CSRF cookie sent
INFO - 2018-07-30 21:20:58 --> Input Class Initialized
INFO - 2018-07-30 21:20:58 --> Language Class Initialized
INFO - 2018-07-30 21:20:58 --> Loader Class Initialized
INFO - 2018-07-30 21:20:58 --> Helper loaded: url_helper
INFO - 2018-07-30 21:20:58 --> Helper loaded: form_helper
INFO - 2018-07-30 21:20:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:20:58 --> User Agent Class Initialized
INFO - 2018-07-30 21:20:58 --> Controller Class Initialized
INFO - 2018-07-30 21:20:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:20:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:20:58 --> Pixel_Model class loaded
INFO - 2018-07-30 21:20:58 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:58 --> Database Driver Class Initialized
INFO - 2018-07-30 21:20:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-30 21:20:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:20:58 --> Final output sent to browser
DEBUG - 2018-07-30 21:20:58 --> Total execution time: 0.0481
INFO - 2018-07-30 21:21:02 --> Config Class Initialized
INFO - 2018-07-30 21:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:02 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:02 --> URI Class Initialized
INFO - 2018-07-30 21:21:02 --> Router Class Initialized
INFO - 2018-07-30 21:21:02 --> Output Class Initialized
INFO - 2018-07-30 21:21:02 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:02 --> CSRF cookie sent
INFO - 2018-07-30 21:21:02 --> CSRF token verified
INFO - 2018-07-30 21:21:02 --> Input Class Initialized
INFO - 2018-07-30 21:21:02 --> Language Class Initialized
INFO - 2018-07-30 21:21:02 --> Loader Class Initialized
INFO - 2018-07-30 21:21:02 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:02 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:02 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:02 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:02 --> Controller Class Initialized
INFO - 2018-07-30 21:21:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:02 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:02 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:02 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:02 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:03 --> Config Class Initialized
INFO - 2018-07-30 21:21:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:03 --> URI Class Initialized
INFO - 2018-07-30 21:21:03 --> Router Class Initialized
INFO - 2018-07-30 21:21:03 --> Output Class Initialized
INFO - 2018-07-30 21:21:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:03 --> CSRF cookie sent
INFO - 2018-07-30 21:21:03 --> Input Class Initialized
INFO - 2018-07-30 21:21:03 --> Language Class Initialized
INFO - 2018-07-30 21:21:03 --> Loader Class Initialized
INFO - 2018-07-30 21:21:03 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:03 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:03 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:03 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:03 --> Controller Class Initialized
INFO - 2018-07-30 21:21:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:03 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:03 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:03 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-30 21:21:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:03 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:03 --> Total execution time: 0.0374
INFO - 2018-07-30 21:21:12 --> Config Class Initialized
INFO - 2018-07-30 21:21:12 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:12 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:12 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:12 --> URI Class Initialized
INFO - 2018-07-30 21:21:12 --> Router Class Initialized
INFO - 2018-07-30 21:21:12 --> Output Class Initialized
INFO - 2018-07-30 21:21:12 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:12 --> CSRF cookie sent
INFO - 2018-07-30 21:21:12 --> CSRF token verified
INFO - 2018-07-30 21:21:12 --> Input Class Initialized
INFO - 2018-07-30 21:21:12 --> Language Class Initialized
INFO - 2018-07-30 21:21:12 --> Loader Class Initialized
INFO - 2018-07-30 21:21:12 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:12 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:12 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:12 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:12 --> Controller Class Initialized
INFO - 2018-07-30 21:21:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:12 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:12 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:12 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:12 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:13 --> Config Class Initialized
INFO - 2018-07-30 21:21:13 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:13 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:13 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:13 --> URI Class Initialized
INFO - 2018-07-30 21:21:13 --> Router Class Initialized
INFO - 2018-07-30 21:21:13 --> Output Class Initialized
INFO - 2018-07-30 21:21:13 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:13 --> CSRF cookie sent
INFO - 2018-07-30 21:21:13 --> Input Class Initialized
INFO - 2018-07-30 21:21:13 --> Language Class Initialized
INFO - 2018-07-30 21:21:13 --> Loader Class Initialized
INFO - 2018-07-30 21:21:13 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:13 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:13 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:13 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:13 --> Controller Class Initialized
INFO - 2018-07-30 21:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:13 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:13 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:13 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-30 21:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:13 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:13 --> Total execution time: 0.0603
INFO - 2018-07-30 21:21:23 --> Config Class Initialized
INFO - 2018-07-30 21:21:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:23 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:23 --> URI Class Initialized
INFO - 2018-07-30 21:21:23 --> Router Class Initialized
INFO - 2018-07-30 21:21:23 --> Output Class Initialized
INFO - 2018-07-30 21:21:23 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:23 --> CSRF cookie sent
INFO - 2018-07-30 21:21:23 --> CSRF token verified
INFO - 2018-07-30 21:21:23 --> Input Class Initialized
INFO - 2018-07-30 21:21:23 --> Language Class Initialized
INFO - 2018-07-30 21:21:23 --> Loader Class Initialized
INFO - 2018-07-30 21:21:23 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:23 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:23 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:23 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:23 --> Controller Class Initialized
INFO - 2018-07-30 21:21:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:23 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:23 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:23 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:23 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:24 --> Config Class Initialized
INFO - 2018-07-30 21:21:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:24 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:24 --> URI Class Initialized
INFO - 2018-07-30 21:21:24 --> Router Class Initialized
INFO - 2018-07-30 21:21:24 --> Output Class Initialized
INFO - 2018-07-30 21:21:24 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:24 --> CSRF cookie sent
INFO - 2018-07-30 21:21:24 --> Input Class Initialized
INFO - 2018-07-30 21:21:24 --> Language Class Initialized
INFO - 2018-07-30 21:21:24 --> Loader Class Initialized
INFO - 2018-07-30 21:21:24 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:24 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:24 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:24 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:24 --> Controller Class Initialized
INFO - 2018-07-30 21:21:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:24 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:24 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:24 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-30 21:21:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:24 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:24 --> Total execution time: 0.0503
INFO - 2018-07-30 21:21:33 --> Config Class Initialized
INFO - 2018-07-30 21:21:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:33 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:33 --> URI Class Initialized
INFO - 2018-07-30 21:21:33 --> Router Class Initialized
INFO - 2018-07-30 21:21:33 --> Output Class Initialized
INFO - 2018-07-30 21:21:33 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:33 --> CSRF cookie sent
INFO - 2018-07-30 21:21:33 --> CSRF token verified
INFO - 2018-07-30 21:21:33 --> Input Class Initialized
INFO - 2018-07-30 21:21:33 --> Language Class Initialized
INFO - 2018-07-30 21:21:33 --> Loader Class Initialized
INFO - 2018-07-30 21:21:33 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:33 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:33 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:33 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:33 --> Controller Class Initialized
INFO - 2018-07-30 21:21:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:33 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:33 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:33 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:33 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:34 --> Config Class Initialized
INFO - 2018-07-30 21:21:34 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:34 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:34 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:34 --> URI Class Initialized
INFO - 2018-07-30 21:21:34 --> Router Class Initialized
INFO - 2018-07-30 21:21:34 --> Output Class Initialized
INFO - 2018-07-30 21:21:34 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:34 --> CSRF cookie sent
INFO - 2018-07-30 21:21:34 --> Input Class Initialized
INFO - 2018-07-30 21:21:34 --> Language Class Initialized
INFO - 2018-07-30 21:21:34 --> Loader Class Initialized
INFO - 2018-07-30 21:21:34 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:34 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:34 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:34 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:34 --> Controller Class Initialized
INFO - 2018-07-30 21:21:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:34 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:34 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:34 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-30 21:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:34 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:34 --> Total execution time: 0.0446
INFO - 2018-07-30 21:21:47 --> Config Class Initialized
INFO - 2018-07-30 21:21:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:47 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:47 --> URI Class Initialized
INFO - 2018-07-30 21:21:47 --> Router Class Initialized
INFO - 2018-07-30 21:21:47 --> Output Class Initialized
INFO - 2018-07-30 21:21:47 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:47 --> CSRF cookie sent
INFO - 2018-07-30 21:21:47 --> CSRF token verified
INFO - 2018-07-30 21:21:47 --> Input Class Initialized
INFO - 2018-07-30 21:21:47 --> Language Class Initialized
INFO - 2018-07-30 21:21:47 --> Loader Class Initialized
INFO - 2018-07-30 21:21:47 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:47 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:47 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:47 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:47 --> Controller Class Initialized
INFO - 2018-07-30 21:21:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:47 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:47 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:47 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:47 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:48 --> Config Class Initialized
INFO - 2018-07-30 21:21:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:48 --> URI Class Initialized
INFO - 2018-07-30 21:21:48 --> Router Class Initialized
INFO - 2018-07-30 21:21:48 --> Output Class Initialized
INFO - 2018-07-30 21:21:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:48 --> CSRF cookie sent
INFO - 2018-07-30 21:21:48 --> Input Class Initialized
INFO - 2018-07-30 21:21:48 --> Language Class Initialized
INFO - 2018-07-30 21:21:48 --> Loader Class Initialized
INFO - 2018-07-30 21:21:48 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:48 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:48 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:48 --> Controller Class Initialized
INFO - 2018-07-30 21:21:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:48 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:48 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:48 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-07-30 21:21:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:48 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:48 --> Total execution time: 0.0467
INFO - 2018-07-30 21:21:51 --> Config Class Initialized
INFO - 2018-07-30 21:21:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:51 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:51 --> URI Class Initialized
INFO - 2018-07-30 21:21:51 --> Router Class Initialized
INFO - 2018-07-30 21:21:51 --> Output Class Initialized
INFO - 2018-07-30 21:21:51 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:51 --> CSRF cookie sent
INFO - 2018-07-30 21:21:51 --> CSRF token verified
INFO - 2018-07-30 21:21:51 --> Input Class Initialized
INFO - 2018-07-30 21:21:51 --> Language Class Initialized
INFO - 2018-07-30 21:21:51 --> Loader Class Initialized
INFO - 2018-07-30 21:21:51 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:51 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:51 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:51 --> Controller Class Initialized
INFO - 2018-07-30 21:21:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:51 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:51 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:51 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:51 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:51 --> Config Class Initialized
INFO - 2018-07-30 21:21:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:51 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:51 --> URI Class Initialized
INFO - 2018-07-30 21:21:51 --> Router Class Initialized
INFO - 2018-07-30 21:21:51 --> Output Class Initialized
INFO - 2018-07-30 21:21:51 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:51 --> CSRF cookie sent
INFO - 2018-07-30 21:21:51 --> Input Class Initialized
INFO - 2018-07-30 21:21:51 --> Language Class Initialized
INFO - 2018-07-30 21:21:51 --> Loader Class Initialized
INFO - 2018-07-30 21:21:51 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:51 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:51 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:51 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:51 --> Controller Class Initialized
INFO - 2018-07-30 21:21:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:51 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:51 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:51 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-30 21:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:51 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:51 --> Total execution time: 0.0478
INFO - 2018-07-30 21:21:56 --> Config Class Initialized
INFO - 2018-07-30 21:21:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:56 --> URI Class Initialized
INFO - 2018-07-30 21:21:56 --> Router Class Initialized
INFO - 2018-07-30 21:21:56 --> Output Class Initialized
INFO - 2018-07-30 21:21:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:56 --> CSRF cookie sent
INFO - 2018-07-30 21:21:56 --> CSRF token verified
INFO - 2018-07-30 21:21:56 --> Input Class Initialized
INFO - 2018-07-30 21:21:56 --> Language Class Initialized
INFO - 2018-07-30 21:21:56 --> Loader Class Initialized
INFO - 2018-07-30 21:21:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:56 --> Controller Class Initialized
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:56 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:56 --> Form Validation Class Initialized
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:21:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:56 --> Config Class Initialized
INFO - 2018-07-30 21:21:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:56 --> URI Class Initialized
INFO - 2018-07-30 21:21:56 --> Router Class Initialized
INFO - 2018-07-30 21:21:56 --> Output Class Initialized
INFO - 2018-07-30 21:21:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:56 --> CSRF cookie sent
INFO - 2018-07-30 21:21:56 --> Input Class Initialized
INFO - 2018-07-30 21:21:56 --> Language Class Initialized
INFO - 2018-07-30 21:21:56 --> Loader Class Initialized
INFO - 2018-07-30 21:21:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:56 --> Controller Class Initialized
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:56 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:21:56 --> Config Class Initialized
INFO - 2018-07-30 21:21:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:21:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:21:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:21:56 --> URI Class Initialized
INFO - 2018-07-30 21:21:56 --> Router Class Initialized
INFO - 2018-07-30 21:21:56 --> Output Class Initialized
INFO - 2018-07-30 21:21:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:21:56 --> CSRF cookie sent
INFO - 2018-07-30 21:21:56 --> Input Class Initialized
INFO - 2018-07-30 21:21:56 --> Language Class Initialized
INFO - 2018-07-30 21:21:56 --> Loader Class Initialized
INFO - 2018-07-30 21:21:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:21:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:21:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:21:56 --> Controller Class Initialized
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:21:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:21:56 --> Pixel_Model class loaded
INFO - 2018-07-30 21:21:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:21:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 21:21:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:21:56 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 21:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:21:56 --> Final output sent to browser
DEBUG - 2018-07-30 21:21:56 --> Total execution time: 0.0363
INFO - 2018-07-30 21:22:32 --> Config Class Initialized
INFO - 2018-07-30 21:22:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:22:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:22:32 --> Utf8 Class Initialized
INFO - 2018-07-30 21:22:32 --> URI Class Initialized
INFO - 2018-07-30 21:22:32 --> Router Class Initialized
INFO - 2018-07-30 21:22:32 --> Output Class Initialized
INFO - 2018-07-30 21:22:32 --> Security Class Initialized
DEBUG - 2018-07-30 21:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:22:32 --> CSRF cookie sent
INFO - 2018-07-30 21:22:32 --> CSRF token verified
INFO - 2018-07-30 21:22:32 --> Input Class Initialized
INFO - 2018-07-30 21:22:32 --> Language Class Initialized
INFO - 2018-07-30 21:22:32 --> Loader Class Initialized
INFO - 2018-07-30 21:22:32 --> Helper loaded: url_helper
INFO - 2018-07-30 21:22:32 --> Helper loaded: form_helper
INFO - 2018-07-30 21:22:32 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:22:32 --> User Agent Class Initialized
INFO - 2018-07-30 21:22:32 --> Controller Class Initialized
INFO - 2018-07-30 21:22:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:22:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:22:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:22:33 --> Form Validation Class Initialized
INFO - 2018-07-30 21:22:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-30 21:22:33 --> Pixel_Model class loaded
INFO - 2018-07-30 21:22:33 --> Database Driver Class Initialized
INFO - 2018-07-30 21:22:33 --> Model "RegistrationModel" initialized
INFO - 2018-07-30 21:22:33 --> Config Class Initialized
INFO - 2018-07-30 21:22:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:22:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:22:33 --> Utf8 Class Initialized
INFO - 2018-07-30 21:22:33 --> URI Class Initialized
INFO - 2018-07-30 21:22:33 --> Router Class Initialized
INFO - 2018-07-30 21:22:33 --> Output Class Initialized
INFO - 2018-07-30 21:22:33 --> Security Class Initialized
DEBUG - 2018-07-30 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:22:33 --> CSRF cookie sent
INFO - 2018-07-30 21:22:33 --> Input Class Initialized
INFO - 2018-07-30 21:22:33 --> Language Class Initialized
INFO - 2018-07-30 21:22:33 --> Loader Class Initialized
INFO - 2018-07-30 21:22:33 --> Helper loaded: url_helper
INFO - 2018-07-30 21:22:33 --> Helper loaded: form_helper
INFO - 2018-07-30 21:22:33 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:22:33 --> User Agent Class Initialized
INFO - 2018-07-30 21:22:33 --> Controller Class Initialized
INFO - 2018-07-30 21:22:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:22:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:22:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:22:33 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-30 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:22:33 --> Final output sent to browser
DEBUG - 2018-07-30 21:22:33 --> Total execution time: 0.0221
INFO - 2018-07-30 21:22:44 --> Config Class Initialized
INFO - 2018-07-30 21:22:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:22:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:22:44 --> Utf8 Class Initialized
INFO - 2018-07-30 21:22:44 --> URI Class Initialized
INFO - 2018-07-30 21:22:44 --> Router Class Initialized
INFO - 2018-07-30 21:22:44 --> Output Class Initialized
INFO - 2018-07-30 21:22:44 --> Security Class Initialized
DEBUG - 2018-07-30 21:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:22:44 --> CSRF cookie sent
INFO - 2018-07-30 21:22:44 --> Input Class Initialized
INFO - 2018-07-30 21:22:44 --> Language Class Initialized
INFO - 2018-07-30 21:22:44 --> Loader Class Initialized
INFO - 2018-07-30 21:22:44 --> Helper loaded: url_helper
INFO - 2018-07-30 21:22:44 --> Helper loaded: form_helper
INFO - 2018-07-30 21:22:44 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:22:44 --> User Agent Class Initialized
INFO - 2018-07-30 21:22:44 --> Controller Class Initialized
INFO - 2018-07-30 21:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:22:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:22:44 --> Pixel_Model class loaded
INFO - 2018-07-30 21:22:44 --> Database Driver Class Initialized
INFO - 2018-07-30 21:22:44 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 21:22:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:22:44 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 21:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:22:44 --> Final output sent to browser
DEBUG - 2018-07-30 21:22:44 --> Total execution time: 0.0546
INFO - 2018-07-30 21:22:48 --> Config Class Initialized
INFO - 2018-07-30 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:22:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:22:48 --> URI Class Initialized
INFO - 2018-07-30 21:22:48 --> Router Class Initialized
INFO - 2018-07-30 21:22:48 --> Output Class Initialized
INFO - 2018-07-30 21:22:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:22:48 --> CSRF cookie sent
INFO - 2018-07-30 21:22:48 --> Input Class Initialized
INFO - 2018-07-30 21:22:48 --> Language Class Initialized
INFO - 2018-07-30 21:22:48 --> Loader Class Initialized
INFO - 2018-07-30 21:22:48 --> Helper loaded: url_helper
INFO - 2018-07-30 21:22:48 --> Helper loaded: form_helper
INFO - 2018-07-30 21:22:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:22:48 --> User Agent Class Initialized
INFO - 2018-07-30 21:22:48 --> Controller Class Initialized
INFO - 2018-07-30 21:22:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:22:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:22:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:22:48 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:22:48 --> Final output sent to browser
DEBUG - 2018-07-30 21:22:48 --> Total execution time: 0.0300
INFO - 2018-07-30 21:23:08 --> Config Class Initialized
INFO - 2018-07-30 21:23:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:23:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:23:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:23:08 --> URI Class Initialized
INFO - 2018-07-30 21:23:08 --> Router Class Initialized
INFO - 2018-07-30 21:23:08 --> Output Class Initialized
INFO - 2018-07-30 21:23:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:23:08 --> CSRF cookie sent
INFO - 2018-07-30 21:23:08 --> CSRF token verified
INFO - 2018-07-30 21:23:08 --> Input Class Initialized
INFO - 2018-07-30 21:23:08 --> Language Class Initialized
INFO - 2018-07-30 21:23:08 --> Loader Class Initialized
INFO - 2018-07-30 21:23:08 --> Helper loaded: url_helper
INFO - 2018-07-30 21:23:08 --> Helper loaded: form_helper
INFO - 2018-07-30 21:23:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:23:08 --> User Agent Class Initialized
INFO - 2018-07-30 21:23:08 --> Controller Class Initialized
INFO - 2018-07-30 21:23:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:23:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:23:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:23:08 --> Form Validation Class Initialized
INFO - 2018-07-30 21:23:08 --> Pixel_Model class loaded
INFO - 2018-07-30 21:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 21:23:08 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 21:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:23:08 --> Config Class Initialized
INFO - 2018-07-30 21:23:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:23:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:23:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:23:08 --> URI Class Initialized
INFO - 2018-07-30 21:23:08 --> Router Class Initialized
INFO - 2018-07-30 21:23:08 --> Output Class Initialized
INFO - 2018-07-30 21:23:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:23:08 --> CSRF cookie sent
INFO - 2018-07-30 21:23:08 --> Input Class Initialized
INFO - 2018-07-30 21:23:08 --> Language Class Initialized
INFO - 2018-07-30 21:23:08 --> Loader Class Initialized
INFO - 2018-07-30 21:23:08 --> Helper loaded: url_helper
INFO - 2018-07-30 21:23:08 --> Helper loaded: form_helper
INFO - 2018-07-30 21:23:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:23:08 --> User Agent Class Initialized
INFO - 2018-07-30 21:23:08 --> Controller Class Initialized
INFO - 2018-07-30 21:23:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:23:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:23:08 --> Pixel_Model class loaded
INFO - 2018-07-30 21:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 21:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:23:08 --> Database Driver Class Initialized
INFO - 2018-07-30 21:23:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-30 21:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:23:08 --> Final output sent to browser
DEBUG - 2018-07-30 21:23:08 --> Total execution time: 0.0366
INFO - 2018-07-30 21:23:21 --> Config Class Initialized
INFO - 2018-07-30 21:23:21 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:23:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:23:21 --> Utf8 Class Initialized
INFO - 2018-07-30 21:23:21 --> URI Class Initialized
INFO - 2018-07-30 21:23:21 --> Router Class Initialized
INFO - 2018-07-30 21:23:21 --> Output Class Initialized
INFO - 2018-07-30 21:23:21 --> Security Class Initialized
DEBUG - 2018-07-30 21:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:23:21 --> CSRF cookie sent
INFO - 2018-07-30 21:23:21 --> Input Class Initialized
INFO - 2018-07-30 21:23:21 --> Language Class Initialized
INFO - 2018-07-30 21:23:21 --> Loader Class Initialized
INFO - 2018-07-30 21:23:21 --> Helper loaded: url_helper
INFO - 2018-07-30 21:23:21 --> Helper loaded: form_helper
INFO - 2018-07-30 21:23:21 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:23:21 --> User Agent Class Initialized
INFO - 2018-07-30 21:23:21 --> Controller Class Initialized
INFO - 2018-07-30 21:23:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:23:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:23:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 21:23:21 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:23:21 --> Final output sent to browser
DEBUG - 2018-07-30 21:23:21 --> Total execution time: 0.0234
INFO - 2018-07-30 21:23:38 --> Config Class Initialized
INFO - 2018-07-30 21:23:38 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:23:38 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:23:38 --> Utf8 Class Initialized
INFO - 2018-07-30 21:23:38 --> URI Class Initialized
INFO - 2018-07-30 21:23:38 --> Router Class Initialized
INFO - 2018-07-30 21:23:38 --> Output Class Initialized
INFO - 2018-07-30 21:23:38 --> Security Class Initialized
DEBUG - 2018-07-30 21:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:23:38 --> CSRF cookie sent
INFO - 2018-07-30 21:23:38 --> CSRF token verified
INFO - 2018-07-30 21:23:38 --> Input Class Initialized
INFO - 2018-07-30 21:23:38 --> Language Class Initialized
INFO - 2018-07-30 21:23:38 --> Loader Class Initialized
INFO - 2018-07-30 21:23:38 --> Helper loaded: url_helper
INFO - 2018-07-30 21:23:38 --> Helper loaded: form_helper
INFO - 2018-07-30 21:23:38 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:23:38 --> User Agent Class Initialized
INFO - 2018-07-30 21:23:38 --> Controller Class Initialized
INFO - 2018-07-30 21:23:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:23:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:23:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:23:38 --> Form Validation Class Initialized
INFO - 2018-07-30 21:23:38 --> Pixel_Model class loaded
INFO - 2018-07-30 21:23:38 --> Database Driver Class Initialized
INFO - 2018-07-30 21:23:38 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:23:38 --> Config Class Initialized
INFO - 2018-07-30 21:23:38 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:23:38 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:23:38 --> Utf8 Class Initialized
INFO - 2018-07-30 21:23:38 --> URI Class Initialized
INFO - 2018-07-30 21:23:38 --> Router Class Initialized
INFO - 2018-07-30 21:23:38 --> Output Class Initialized
INFO - 2018-07-30 21:23:38 --> Security Class Initialized
DEBUG - 2018-07-30 21:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:23:38 --> CSRF cookie sent
INFO - 2018-07-30 21:23:38 --> Input Class Initialized
INFO - 2018-07-30 21:23:38 --> Language Class Initialized
INFO - 2018-07-30 21:23:39 --> Loader Class Initialized
INFO - 2018-07-30 21:23:39 --> Helper loaded: url_helper
INFO - 2018-07-30 21:23:39 --> Helper loaded: form_helper
INFO - 2018-07-30 21:23:39 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:23:39 --> User Agent Class Initialized
INFO - 2018-07-30 21:23:39 --> Controller Class Initialized
INFO - 2018-07-30 21:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:23:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:23:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:23:39 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:23:39 --> Final output sent to browser
DEBUG - 2018-07-30 21:23:39 --> Total execution time: 0.0287
INFO - 2018-07-30 21:24:08 --> Config Class Initialized
INFO - 2018-07-30 21:24:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:08 --> URI Class Initialized
INFO - 2018-07-30 21:24:08 --> Router Class Initialized
INFO - 2018-07-30 21:24:08 --> Output Class Initialized
INFO - 2018-07-30 21:24:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:08 --> CSRF cookie sent
INFO - 2018-07-30 21:24:08 --> CSRF token verified
INFO - 2018-07-30 21:24:08 --> Input Class Initialized
INFO - 2018-07-30 21:24:08 --> Language Class Initialized
INFO - 2018-07-30 21:24:08 --> Loader Class Initialized
INFO - 2018-07-30 21:24:08 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:08 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:08 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:08 --> Controller Class Initialized
INFO - 2018-07-30 21:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:24:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:24:08 --> Form Validation Class Initialized
INFO - 2018-07-30 21:24:08 --> Pixel_Model class loaded
INFO - 2018-07-30 21:24:08 --> Database Driver Class Initialized
INFO - 2018-07-30 21:24:08 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:24:08 --> Config Class Initialized
INFO - 2018-07-30 21:24:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:08 --> URI Class Initialized
INFO - 2018-07-30 21:24:08 --> Router Class Initialized
INFO - 2018-07-30 21:24:08 --> Output Class Initialized
INFO - 2018-07-30 21:24:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:08 --> CSRF cookie sent
INFO - 2018-07-30 21:24:08 --> Input Class Initialized
INFO - 2018-07-30 21:24:08 --> Language Class Initialized
INFO - 2018-07-30 21:24:08 --> Loader Class Initialized
INFO - 2018-07-30 21:24:08 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:08 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:08 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:08 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:08 --> Controller Class Initialized
INFO - 2018-07-30 21:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:24:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:24:08 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:24:08 --> Final output sent to browser
DEBUG - 2018-07-30 21:24:08 --> Total execution time: 0.0220
INFO - 2018-07-30 21:24:19 --> Config Class Initialized
INFO - 2018-07-30 21:24:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:19 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:19 --> URI Class Initialized
INFO - 2018-07-30 21:24:19 --> Router Class Initialized
INFO - 2018-07-30 21:24:19 --> Output Class Initialized
INFO - 2018-07-30 21:24:19 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:19 --> CSRF cookie sent
INFO - 2018-07-30 21:24:19 --> CSRF token verified
INFO - 2018-07-30 21:24:19 --> Input Class Initialized
INFO - 2018-07-30 21:24:19 --> Language Class Initialized
INFO - 2018-07-30 21:24:19 --> Loader Class Initialized
INFO - 2018-07-30 21:24:19 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:19 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:19 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:19 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:19 --> Controller Class Initialized
INFO - 2018-07-30 21:24:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:24:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:24:19 --> Config Class Initialized
INFO - 2018-07-30 21:24:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:19 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:19 --> URI Class Initialized
INFO - 2018-07-30 21:24:19 --> Router Class Initialized
INFO - 2018-07-30 21:24:19 --> Output Class Initialized
INFO - 2018-07-30 21:24:19 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:19 --> CSRF cookie sent
INFO - 2018-07-30 21:24:19 --> Input Class Initialized
INFO - 2018-07-30 21:24:19 --> Language Class Initialized
INFO - 2018-07-30 21:24:19 --> Loader Class Initialized
INFO - 2018-07-30 21:24:19 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:19 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:19 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:19 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:19 --> Controller Class Initialized
INFO - 2018-07-30 21:24:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:24:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-30 21:24:19 --> Could not find the language line "req_email"
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 21:24:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:24:19 --> Final output sent to browser
DEBUG - 2018-07-30 21:24:19 --> Total execution time: 0.0265
INFO - 2018-07-30 21:24:46 --> Config Class Initialized
INFO - 2018-07-30 21:24:46 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:46 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:46 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:46 --> URI Class Initialized
INFO - 2018-07-30 21:24:46 --> Router Class Initialized
INFO - 2018-07-30 21:24:46 --> Output Class Initialized
INFO - 2018-07-30 21:24:46 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:46 --> CSRF cookie sent
INFO - 2018-07-30 21:24:46 --> CSRF token verified
INFO - 2018-07-30 21:24:46 --> Input Class Initialized
INFO - 2018-07-30 21:24:46 --> Language Class Initialized
INFO - 2018-07-30 21:24:46 --> Loader Class Initialized
INFO - 2018-07-30 21:24:46 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:46 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:46 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:46 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:46 --> Controller Class Initialized
INFO - 2018-07-30 21:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 21:24:46 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 21:24:46 --> Form Validation Class Initialized
INFO - 2018-07-30 21:24:46 --> Pixel_Model class loaded
INFO - 2018-07-30 21:24:46 --> Database Driver Class Initialized
INFO - 2018-07-30 21:24:46 --> Model "AuthenticationModel" initialized
INFO - 2018-07-30 21:24:47 --> Config Class Initialized
INFO - 2018-07-30 21:24:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:47 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:47 --> URI Class Initialized
DEBUG - 2018-07-30 21:24:47 --> No URI present. Default controller set.
INFO - 2018-07-30 21:24:47 --> Router Class Initialized
INFO - 2018-07-30 21:24:47 --> Output Class Initialized
INFO - 2018-07-30 21:24:47 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:47 --> CSRF cookie sent
INFO - 2018-07-30 21:24:47 --> Input Class Initialized
INFO - 2018-07-30 21:24:47 --> Language Class Initialized
INFO - 2018-07-30 21:24:47 --> Loader Class Initialized
INFO - 2018-07-30 21:24:47 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:47 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:47 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:47 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:47 --> Controller Class Initialized
INFO - 2018-07-30 21:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:24:47 --> Pixel_Model class loaded
INFO - 2018-07-30 21:24:47 --> Database Driver Class Initialized
INFO - 2018-07-30 21:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 21:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:24:47 --> Final output sent to browser
DEBUG - 2018-07-30 21:24:47 --> Total execution time: 0.0327
INFO - 2018-07-30 21:24:56 --> Config Class Initialized
INFO - 2018-07-30 21:24:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:24:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:24:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:24:56 --> URI Class Initialized
INFO - 2018-07-30 21:24:56 --> Router Class Initialized
INFO - 2018-07-30 21:24:56 --> Output Class Initialized
INFO - 2018-07-30 21:24:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:24:56 --> CSRF cookie sent
INFO - 2018-07-30 21:24:56 --> Input Class Initialized
INFO - 2018-07-30 21:24:56 --> Language Class Initialized
INFO - 2018-07-30 21:24:56 --> Loader Class Initialized
INFO - 2018-07-30 21:24:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:24:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:24:56 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:24:56 --> User Agent Class Initialized
INFO - 2018-07-30 21:24:56 --> Controller Class Initialized
INFO - 2018-07-30 21:24:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:24:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:24:56 --> Pixel_Model class loaded
INFO - 2018-07-30 21:24:56 --> Database Driver Class Initialized
INFO - 2018-07-30 21:24:56 --> Model "MyAccountModel" initialized
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-07-30 21:24:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:24:56 --> Final output sent to browser
DEBUG - 2018-07-30 21:24:56 --> Total execution time: 0.0326
INFO - 2018-07-30 21:37:04 --> Config Class Initialized
INFO - 2018-07-30 21:37:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:04 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:04 --> URI Class Initialized
INFO - 2018-07-30 21:37:04 --> Router Class Initialized
INFO - 2018-07-30 21:37:04 --> Output Class Initialized
INFO - 2018-07-30 21:37:04 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:04 --> CSRF cookie sent
INFO - 2018-07-30 21:37:04 --> Input Class Initialized
INFO - 2018-07-30 21:37:04 --> Language Class Initialized
INFO - 2018-07-30 21:37:04 --> Loader Class Initialized
INFO - 2018-07-30 21:37:04 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:04 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:04 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:04 --> Controller Class Initialized
INFO - 2018-07-30 21:37:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:04 --> Pixel_Model class loaded
INFO - 2018-07-30 21:37:04 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:04 --> Model "MyAccountModel" initialized
INFO - 2018-07-30 21:37:04 --> Config Class Initialized
INFO - 2018-07-30 21:37:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:04 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:04 --> URI Class Initialized
INFO - 2018-07-30 21:37:04 --> Router Class Initialized
INFO - 2018-07-30 21:37:04 --> Output Class Initialized
INFO - 2018-07-30 21:37:04 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:04 --> CSRF cookie sent
INFO - 2018-07-30 21:37:04 --> Input Class Initialized
INFO - 2018-07-30 21:37:04 --> Language Class Initialized
INFO - 2018-07-30 21:37:04 --> Loader Class Initialized
INFO - 2018-07-30 21:37:04 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:04 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:04 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:04 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:04 --> Controller Class Initialized
INFO - 2018-07-30 21:37:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:04 --> Pixel_Model class loaded
INFO - 2018-07-30 21:37:04 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:04 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-30 21:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:37:04 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:04 --> Total execution time: 0.0382
INFO - 2018-07-30 21:37:10 --> Config Class Initialized
INFO - 2018-07-30 21:37:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:10 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:10 --> URI Class Initialized
INFO - 2018-07-30 21:37:10 --> Router Class Initialized
INFO - 2018-07-30 21:37:10 --> Output Class Initialized
INFO - 2018-07-30 21:37:10 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:10 --> CSRF cookie sent
INFO - 2018-07-30 21:37:10 --> Input Class Initialized
INFO - 2018-07-30 21:37:10 --> Language Class Initialized
INFO - 2018-07-30 21:37:10 --> Loader Class Initialized
INFO - 2018-07-30 21:37:10 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:11 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:11 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:11 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:11 --> Controller Class Initialized
INFO - 2018-07-30 21:37:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:11 --> Pixel_Model class loaded
INFO - 2018-07-30 21:37:11 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:11 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 21:37:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:37:11 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:11 --> Total execution time: 0.0461
INFO - 2018-07-30 21:37:23 --> Config Class Initialized
INFO - 2018-07-30 21:37:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:23 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:23 --> URI Class Initialized
INFO - 2018-07-30 21:37:23 --> Router Class Initialized
INFO - 2018-07-30 21:37:23 --> Output Class Initialized
INFO - 2018-07-30 21:37:23 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:23 --> CSRF cookie sent
INFO - 2018-07-30 21:37:23 --> Input Class Initialized
INFO - 2018-07-30 21:37:23 --> Language Class Initialized
INFO - 2018-07-30 21:37:23 --> Loader Class Initialized
INFO - 2018-07-30 21:37:23 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:23 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:23 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:23 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:23 --> Controller Class Initialized
INFO - 2018-07-30 21:37:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:23 --> Pixel_Model class loaded
INFO - 2018-07-30 21:37:23 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:23 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-30 21:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:37:23 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:23 --> Total execution time: 0.0490
INFO - 2018-07-30 21:37:27 --> Config Class Initialized
INFO - 2018-07-30 21:37:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:27 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:27 --> URI Class Initialized
INFO - 2018-07-30 21:37:27 --> Router Class Initialized
INFO - 2018-07-30 21:37:27 --> Output Class Initialized
INFO - 2018-07-30 21:37:27 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:27 --> CSRF cookie sent
INFO - 2018-07-30 21:37:27 --> Input Class Initialized
INFO - 2018-07-30 21:37:27 --> Language Class Initialized
INFO - 2018-07-30 21:37:27 --> Loader Class Initialized
INFO - 2018-07-30 21:37:27 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:27 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:27 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:27 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:27 --> Controller Class Initialized
INFO - 2018-07-30 21:37:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:27 --> CSRF cookie sent
INFO - 2018-07-30 21:37:27 --> Config Class Initialized
INFO - 2018-07-30 21:37:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:27 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:27 --> URI Class Initialized
DEBUG - 2018-07-30 21:37:27 --> No URI present. Default controller set.
INFO - 2018-07-30 21:37:27 --> Router Class Initialized
INFO - 2018-07-30 21:37:27 --> Output Class Initialized
INFO - 2018-07-30 21:37:27 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:27 --> CSRF cookie sent
INFO - 2018-07-30 21:37:27 --> Input Class Initialized
INFO - 2018-07-30 21:37:27 --> Language Class Initialized
INFO - 2018-07-30 21:37:27 --> Loader Class Initialized
INFO - 2018-07-30 21:37:27 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:27 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:27 --> Helper loaded: language_helper
DEBUG - 2018-07-30 21:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:27 --> User Agent Class Initialized
INFO - 2018-07-30 21:37:27 --> Controller Class Initialized
INFO - 2018-07-30 21:37:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 21:37:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 21:37:27 --> Pixel_Model class loaded
INFO - 2018-07-30 21:37:27 --> Database Driver Class Initialized
INFO - 2018-07-30 21:37:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 21:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 21:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 21:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 21:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 21:37:27 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:27 --> Total execution time: 0.0325
INFO - 2018-07-30 22:02:16 --> Config Class Initialized
INFO - 2018-07-30 22:02:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:02:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:02:16 --> Utf8 Class Initialized
INFO - 2018-07-30 22:02:16 --> URI Class Initialized
INFO - 2018-07-30 22:02:16 --> Router Class Initialized
INFO - 2018-07-30 22:02:16 --> Output Class Initialized
INFO - 2018-07-30 22:02:16 --> Security Class Initialized
DEBUG - 2018-07-30 22:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:02:16 --> CSRF cookie sent
INFO - 2018-07-30 22:02:16 --> Input Class Initialized
INFO - 2018-07-30 22:02:16 --> Language Class Initialized
ERROR - 2018-07-30 22:02:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-30 22:02:17 --> Config Class Initialized
INFO - 2018-07-30 22:02:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:02:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:02:17 --> Utf8 Class Initialized
INFO - 2018-07-30 22:02:17 --> URI Class Initialized
INFO - 2018-07-30 22:02:17 --> Router Class Initialized
INFO - 2018-07-30 22:02:17 --> Output Class Initialized
INFO - 2018-07-30 22:02:17 --> Security Class Initialized
DEBUG - 2018-07-30 22:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:02:17 --> CSRF cookie sent
INFO - 2018-07-30 22:02:17 --> Input Class Initialized
INFO - 2018-07-30 22:02:17 --> Language Class Initialized
INFO - 2018-07-30 22:02:17 --> Loader Class Initialized
INFO - 2018-07-30 22:02:17 --> Helper loaded: url_helper
INFO - 2018-07-30 22:02:17 --> Helper loaded: form_helper
INFO - 2018-07-30 22:02:17 --> Helper loaded: language_helper
DEBUG - 2018-07-30 22:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:02:17 --> User Agent Class Initialized
INFO - 2018-07-30 22:02:17 --> Controller Class Initialized
INFO - 2018-07-30 22:02:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 22:02:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 22:02:17 --> Pixel_Model class loaded
INFO - 2018-07-30 22:02:17 --> Database Driver Class Initialized
INFO - 2018-07-30 22:02:17 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-30 22:02:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 22:02:17 --> Could not find the language line "req_email"
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-30 22:02:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 22:02:17 --> Final output sent to browser
DEBUG - 2018-07-30 22:02:17 --> Total execution time: 0.0383
INFO - 2018-07-30 23:27:47 --> Config Class Initialized
INFO - 2018-07-30 23:27:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:47 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:47 --> URI Class Initialized
DEBUG - 2018-07-30 23:27:47 --> No URI present. Default controller set.
INFO - 2018-07-30 23:27:47 --> Router Class Initialized
INFO - 2018-07-30 23:27:47 --> Output Class Initialized
INFO - 2018-07-30 23:27:47 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:47 --> CSRF cookie sent
INFO - 2018-07-30 23:27:47 --> Input Class Initialized
INFO - 2018-07-30 23:27:47 --> Language Class Initialized
INFO - 2018-07-30 23:27:47 --> Loader Class Initialized
INFO - 2018-07-30 23:27:47 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:47 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:47 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:47 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:47 --> Controller Class Initialized
INFO - 2018-07-30 23:27:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:47 --> Pixel_Model class loaded
INFO - 2018-07-30 23:27:47 --> Database Driver Class Initialized
INFO - 2018-07-30 23:27:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:27:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 23:27:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:47 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:47 --> Total execution time: 0.0330
INFO - 2018-07-30 23:27:48 --> Config Class Initialized
INFO - 2018-07-30 23:27:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:48 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:48 --> URI Class Initialized
DEBUG - 2018-07-30 23:27:48 --> No URI present. Default controller set.
INFO - 2018-07-30 23:27:48 --> Router Class Initialized
INFO - 2018-07-30 23:27:48 --> Output Class Initialized
INFO - 2018-07-30 23:27:48 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:48 --> CSRF cookie sent
INFO - 2018-07-30 23:27:48 --> Input Class Initialized
INFO - 2018-07-30 23:27:48 --> Language Class Initialized
INFO - 2018-07-30 23:27:48 --> Loader Class Initialized
INFO - 2018-07-30 23:27:48 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:48 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:48 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:48 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:48 --> Controller Class Initialized
INFO - 2018-07-30 23:27:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:48 --> Pixel_Model class loaded
INFO - 2018-07-30 23:27:48 --> Database Driver Class Initialized
INFO - 2018-07-30 23:27:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:27:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 23:27:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:48 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:48 --> Total execution time: 0.0371
INFO - 2018-07-30 23:27:49 --> Config Class Initialized
INFO - 2018-07-30 23:27:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:49 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:49 --> URI Class Initialized
DEBUG - 2018-07-30 23:27:49 --> No URI present. Default controller set.
INFO - 2018-07-30 23:27:49 --> Router Class Initialized
INFO - 2018-07-30 23:27:49 --> Output Class Initialized
INFO - 2018-07-30 23:27:49 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:49 --> CSRF cookie sent
INFO - 2018-07-30 23:27:49 --> Input Class Initialized
INFO - 2018-07-30 23:27:49 --> Language Class Initialized
INFO - 2018-07-30 23:27:49 --> Loader Class Initialized
INFO - 2018-07-30 23:27:49 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:49 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:49 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:49 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:49 --> Controller Class Initialized
INFO - 2018-07-30 23:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:49 --> Pixel_Model class loaded
INFO - 2018-07-30 23:27:49 --> Database Driver Class Initialized
INFO - 2018-07-30 23:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 23:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:49 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:49 --> Total execution time: 0.0294
INFO - 2018-07-30 23:27:49 --> Config Class Initialized
INFO - 2018-07-30 23:27:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:49 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:49 --> URI Class Initialized
INFO - 2018-07-30 23:27:49 --> Router Class Initialized
INFO - 2018-07-30 23:27:49 --> Output Class Initialized
INFO - 2018-07-30 23:27:49 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:49 --> CSRF cookie sent
INFO - 2018-07-30 23:27:49 --> Input Class Initialized
INFO - 2018-07-30 23:27:49 --> Language Class Initialized
ERROR - 2018-07-30 23:27:49 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-30 23:27:57 --> Config Class Initialized
INFO - 2018-07-30 23:27:57 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:57 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:57 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:57 --> URI Class Initialized
DEBUG - 2018-07-30 23:27:57 --> No URI present. Default controller set.
INFO - 2018-07-30 23:27:57 --> Router Class Initialized
INFO - 2018-07-30 23:27:57 --> Output Class Initialized
INFO - 2018-07-30 23:27:57 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:57 --> CSRF cookie sent
INFO - 2018-07-30 23:27:57 --> Input Class Initialized
INFO - 2018-07-30 23:27:57 --> Language Class Initialized
INFO - 2018-07-30 23:27:57 --> Loader Class Initialized
INFO - 2018-07-30 23:27:57 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:57 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:57 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:57 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:57 --> Controller Class Initialized
INFO - 2018-07-30 23:27:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:57 --> Pixel_Model class loaded
INFO - 2018-07-30 23:27:57 --> Database Driver Class Initialized
INFO - 2018-07-30 23:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-30 23:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:57 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:57 --> Total execution time: 0.0350
INFO - 2018-07-30 23:27:57 --> Config Class Initialized
INFO - 2018-07-30 23:27:57 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:57 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:57 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:57 --> URI Class Initialized
INFO - 2018-07-30 23:27:57 --> Router Class Initialized
INFO - 2018-07-30 23:27:57 --> Output Class Initialized
INFO - 2018-07-30 23:27:57 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:57 --> CSRF cookie sent
INFO - 2018-07-30 23:27:57 --> Input Class Initialized
INFO - 2018-07-30 23:27:57 --> Language Class Initialized
ERROR - 2018-07-30 23:27:57 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-30 23:27:58 --> Config Class Initialized
INFO - 2018-07-30 23:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:58 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:58 --> URI Class Initialized
INFO - 2018-07-30 23:27:58 --> Router Class Initialized
INFO - 2018-07-30 23:27:58 --> Output Class Initialized
INFO - 2018-07-30 23:27:58 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:58 --> CSRF cookie sent
INFO - 2018-07-30 23:27:58 --> Input Class Initialized
INFO - 2018-07-30 23:27:58 --> Language Class Initialized
ERROR - 2018-07-30 23:27:58 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-30 23:27:58 --> Config Class Initialized
INFO - 2018-07-30 23:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:58 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:58 --> URI Class Initialized
INFO - 2018-07-30 23:27:58 --> Router Class Initialized
INFO - 2018-07-30 23:27:58 --> Output Class Initialized
INFO - 2018-07-30 23:27:58 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:58 --> CSRF cookie sent
INFO - 2018-07-30 23:27:58 --> Input Class Initialized
INFO - 2018-07-30 23:27:58 --> Language Class Initialized
INFO - 2018-07-30 23:27:58 --> Loader Class Initialized
INFO - 2018-07-30 23:27:58 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:58 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:58 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:58 --> Controller Class Initialized
INFO - 2018-07-30 23:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:58 --> Pixel_Model class loaded
INFO - 2018-07-30 23:27:58 --> Database Driver Class Initialized
INFO - 2018-07-30 23:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:58 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:58 --> Total execution time: 0.0394
INFO - 2018-07-30 23:27:58 --> Config Class Initialized
INFO - 2018-07-30 23:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:58 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:58 --> URI Class Initialized
INFO - 2018-07-30 23:27:58 --> Router Class Initialized
INFO - 2018-07-30 23:27:58 --> Output Class Initialized
INFO - 2018-07-30 23:27:58 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:58 --> CSRF cookie sent
INFO - 2018-07-30 23:27:58 --> Input Class Initialized
INFO - 2018-07-30 23:27:58 --> Language Class Initialized
INFO - 2018-07-30 23:27:58 --> Loader Class Initialized
INFO - 2018-07-30 23:27:58 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:58 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:58 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:58 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:58 --> Controller Class Initialized
INFO - 2018-07-30 23:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-30 23:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:58 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:58 --> Total execution time: 0.0230
INFO - 2018-07-30 23:27:59 --> Config Class Initialized
INFO - 2018-07-30 23:27:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:59 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:59 --> URI Class Initialized
INFO - 2018-07-30 23:27:59 --> Router Class Initialized
INFO - 2018-07-30 23:27:59 --> Output Class Initialized
INFO - 2018-07-30 23:27:59 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:59 --> CSRF cookie sent
INFO - 2018-07-30 23:27:59 --> Input Class Initialized
INFO - 2018-07-30 23:27:59 --> Language Class Initialized
INFO - 2018-07-30 23:27:59 --> Loader Class Initialized
INFO - 2018-07-30 23:27:59 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:59 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:59 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:59 --> Controller Class Initialized
INFO - 2018-07-30 23:27:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:59 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:59 --> Total execution time: 0.0259
INFO - 2018-07-30 23:27:59 --> Config Class Initialized
INFO - 2018-07-30 23:27:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:27:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:27:59 --> Utf8 Class Initialized
INFO - 2018-07-30 23:27:59 --> URI Class Initialized
INFO - 2018-07-30 23:27:59 --> Router Class Initialized
INFO - 2018-07-30 23:27:59 --> Output Class Initialized
INFO - 2018-07-30 23:27:59 --> Security Class Initialized
DEBUG - 2018-07-30 23:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:27:59 --> CSRF cookie sent
INFO - 2018-07-30 23:27:59 --> Input Class Initialized
INFO - 2018-07-30 23:27:59 --> Language Class Initialized
INFO - 2018-07-30 23:27:59 --> Loader Class Initialized
INFO - 2018-07-30 23:27:59 --> Helper loaded: url_helper
INFO - 2018-07-30 23:27:59 --> Helper loaded: form_helper
INFO - 2018-07-30 23:27:59 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:27:59 --> User Agent Class Initialized
INFO - 2018-07-30 23:27:59 --> Controller Class Initialized
INFO - 2018-07-30 23:27:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:27:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-30 23:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:27:59 --> Final output sent to browser
DEBUG - 2018-07-30 23:27:59 --> Total execution time: 0.0197
INFO - 2018-07-30 23:28:00 --> Config Class Initialized
INFO - 2018-07-30 23:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:28:00 --> Utf8 Class Initialized
INFO - 2018-07-30 23:28:00 --> URI Class Initialized
INFO - 2018-07-30 23:28:00 --> Router Class Initialized
INFO - 2018-07-30 23:28:00 --> Output Class Initialized
INFO - 2018-07-30 23:28:00 --> Security Class Initialized
DEBUG - 2018-07-30 23:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:28:00 --> CSRF cookie sent
INFO - 2018-07-30 23:28:00 --> Input Class Initialized
INFO - 2018-07-30 23:28:00 --> Language Class Initialized
INFO - 2018-07-30 23:28:00 --> Loader Class Initialized
INFO - 2018-07-30 23:28:00 --> Helper loaded: url_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: form_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:28:00 --> User Agent Class Initialized
INFO - 2018-07-30 23:28:00 --> Controller Class Initialized
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:28:00 --> Final output sent to browser
DEBUG - 2018-07-30 23:28:00 --> Total execution time: 0.0229
INFO - 2018-07-30 23:28:00 --> Config Class Initialized
INFO - 2018-07-30 23:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:28:00 --> Utf8 Class Initialized
INFO - 2018-07-30 23:28:00 --> URI Class Initialized
INFO - 2018-07-30 23:28:00 --> Router Class Initialized
INFO - 2018-07-30 23:28:00 --> Output Class Initialized
INFO - 2018-07-30 23:28:00 --> Security Class Initialized
DEBUG - 2018-07-30 23:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:28:00 --> CSRF cookie sent
INFO - 2018-07-30 23:28:00 --> Input Class Initialized
INFO - 2018-07-30 23:28:00 --> Language Class Initialized
INFO - 2018-07-30 23:28:00 --> Loader Class Initialized
INFO - 2018-07-30 23:28:00 --> Helper loaded: url_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: form_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:28:00 --> User Agent Class Initialized
INFO - 2018-07-30 23:28:00 --> Controller Class Initialized
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-30 23:28:00 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-30 23:28:00 --> Could not find the language line "req_email"
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:28:00 --> Final output sent to browser
DEBUG - 2018-07-30 23:28:00 --> Total execution time: 0.0212
INFO - 2018-07-30 23:28:00 --> Config Class Initialized
INFO - 2018-07-30 23:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:28:00 --> Utf8 Class Initialized
INFO - 2018-07-30 23:28:00 --> URI Class Initialized
INFO - 2018-07-30 23:28:00 --> Router Class Initialized
INFO - 2018-07-30 23:28:00 --> Output Class Initialized
INFO - 2018-07-30 23:28:00 --> Security Class Initialized
DEBUG - 2018-07-30 23:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:28:00 --> CSRF cookie sent
INFO - 2018-07-30 23:28:00 --> Input Class Initialized
INFO - 2018-07-30 23:28:00 --> Language Class Initialized
INFO - 2018-07-30 23:28:00 --> Loader Class Initialized
INFO - 2018-07-30 23:28:00 --> Helper loaded: url_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: form_helper
INFO - 2018-07-30 23:28:00 --> Helper loaded: language_helper
DEBUG - 2018-07-30 23:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:28:00 --> User Agent Class Initialized
INFO - 2018-07-30 23:28:00 --> Controller Class Initialized
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-30 23:28:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-30 23:28:00 --> Pixel_Model class loaded
INFO - 2018-07-30 23:28:00 --> Database Driver Class Initialized
INFO - 2018-07-30 23:28:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-30 23:28:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-30 23:28:00 --> Final output sent to browser
DEBUG - 2018-07-30 23:28:00 --> Total execution time: 0.0347

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-02 03:48:49 --> Config Class Initialized
INFO - 2018-08-02 03:48:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:48:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:48:49 --> Utf8 Class Initialized
INFO - 2018-08-02 03:48:49 --> URI Class Initialized
DEBUG - 2018-08-02 03:48:49 --> No URI present. Default controller set.
INFO - 2018-08-02 03:48:49 --> Router Class Initialized
INFO - 2018-08-02 03:48:49 --> Output Class Initialized
INFO - 2018-08-02 03:48:49 --> Security Class Initialized
DEBUG - 2018-08-02 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:48:49 --> CSRF cookie sent
INFO - 2018-08-02 03:48:49 --> Input Class Initialized
INFO - 2018-08-02 03:48:49 --> Language Class Initialized
INFO - 2018-08-02 03:48:49 --> Loader Class Initialized
INFO - 2018-08-02 03:48:49 --> Helper loaded: url_helper
INFO - 2018-08-02 03:48:49 --> Helper loaded: form_helper
INFO - 2018-08-02 03:48:49 --> Helper loaded: language_helper
DEBUG - 2018-08-02 03:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:48:49 --> User Agent Class Initialized
INFO - 2018-08-02 03:48:49 --> Controller Class Initialized
INFO - 2018-08-02 03:48:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 03:48:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 03:48:49 --> Pixel_Model class loaded
INFO - 2018-08-02 03:48:49 --> Database Driver Class Initialized
INFO - 2018-08-02 03:48:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 03:48:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 03:48:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 03:48:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 03:48:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 03:48:49 --> Final output sent to browser
DEBUG - 2018-08-02 03:48:49 --> Total execution time: 0.0357
INFO - 2018-08-02 13:06:48 --> Config Class Initialized
INFO - 2018-08-02 13:06:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:06:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:06:48 --> Utf8 Class Initialized
INFO - 2018-08-02 13:06:48 --> URI Class Initialized
INFO - 2018-08-02 13:06:48 --> Router Class Initialized
INFO - 2018-08-02 13:06:48 --> Output Class Initialized
INFO - 2018-08-02 13:06:48 --> Security Class Initialized
DEBUG - 2018-08-02 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:06:48 --> CSRF cookie sent
INFO - 2018-08-02 13:06:49 --> Config Class Initialized
INFO - 2018-08-02 13:06:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:06:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:06:49 --> Utf8 Class Initialized
INFO - 2018-08-02 13:06:49 --> URI Class Initialized
INFO - 2018-08-02 13:06:49 --> Router Class Initialized
INFO - 2018-08-02 13:06:49 --> Output Class Initialized
INFO - 2018-08-02 13:06:49 --> Security Class Initialized
DEBUG - 2018-08-02 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:06:49 --> CSRF cookie sent
INFO - 2018-08-02 13:06:49 --> Input Class Initialized
INFO - 2018-08-02 13:06:49 --> Language Class Initialized
ERROR - 2018-08-02 13:06:49 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-02 13:06:55 --> Config Class Initialized
INFO - 2018-08-02 13:06:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:06:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:06:55 --> Utf8 Class Initialized
INFO - 2018-08-02 13:06:55 --> URI Class Initialized
INFO - 2018-08-02 13:06:55 --> Router Class Initialized
INFO - 2018-08-02 13:06:55 --> Output Class Initialized
INFO - 2018-08-02 13:06:55 --> Security Class Initialized
DEBUG - 2018-08-02 13:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:06:55 --> CSRF cookie sent
INFO - 2018-08-02 13:07:01 --> Config Class Initialized
INFO - 2018-08-02 13:07:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:01 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:01 --> URI Class Initialized
DEBUG - 2018-08-02 13:07:01 --> No URI present. Default controller set.
INFO - 2018-08-02 13:07:01 --> Router Class Initialized
INFO - 2018-08-02 13:07:01 --> Output Class Initialized
INFO - 2018-08-02 13:07:01 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:01 --> CSRF cookie sent
INFO - 2018-08-02 13:07:01 --> Input Class Initialized
INFO - 2018-08-02 13:07:01 --> Language Class Initialized
INFO - 2018-08-02 13:07:01 --> Loader Class Initialized
INFO - 2018-08-02 13:07:01 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:01 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:01 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:01 --> Controller Class Initialized
INFO - 2018-08-02 13:07:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:01 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:01 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 13:07:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:01 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:01 --> Total execution time: 0.0346
INFO - 2018-08-02 13:07:04 --> Config Class Initialized
INFO - 2018-08-02 13:07:04 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:04 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:04 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:04 --> URI Class Initialized
DEBUG - 2018-08-02 13:07:04 --> No URI present. Default controller set.
INFO - 2018-08-02 13:07:04 --> Router Class Initialized
INFO - 2018-08-02 13:07:04 --> Output Class Initialized
INFO - 2018-08-02 13:07:04 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:04 --> CSRF cookie sent
INFO - 2018-08-02 13:07:04 --> Input Class Initialized
INFO - 2018-08-02 13:07:04 --> Language Class Initialized
INFO - 2018-08-02 13:07:04 --> Loader Class Initialized
INFO - 2018-08-02 13:07:04 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:04 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:04 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:04 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:04 --> Controller Class Initialized
INFO - 2018-08-02 13:07:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:04 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:04 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 13:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:04 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:04 --> Total execution time: 0.0442
INFO - 2018-08-02 13:07:15 --> Config Class Initialized
INFO - 2018-08-02 13:07:15 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:15 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:15 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:15 --> URI Class Initialized
INFO - 2018-08-02 13:07:15 --> Router Class Initialized
INFO - 2018-08-02 13:07:15 --> Output Class Initialized
INFO - 2018-08-02 13:07:15 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:15 --> CSRF cookie sent
INFO - 2018-08-02 13:07:15 --> CSRF token verified
INFO - 2018-08-02 13:07:15 --> Input Class Initialized
INFO - 2018-08-02 13:07:15 --> Language Class Initialized
INFO - 2018-08-02 13:07:15 --> Loader Class Initialized
INFO - 2018-08-02 13:07:15 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:15 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:15 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:15 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:15 --> Controller Class Initialized
INFO - 2018-08-02 13:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:15 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:15 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:15 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:15 --> Config Class Initialized
INFO - 2018-08-02 13:07:15 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:15 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:15 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:15 --> URI Class Initialized
INFO - 2018-08-02 13:07:15 --> Router Class Initialized
INFO - 2018-08-02 13:07:15 --> Output Class Initialized
INFO - 2018-08-02 13:07:15 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:15 --> CSRF cookie sent
INFO - 2018-08-02 13:07:15 --> Input Class Initialized
INFO - 2018-08-02 13:07:15 --> Language Class Initialized
INFO - 2018-08-02 13:07:15 --> Loader Class Initialized
INFO - 2018-08-02 13:07:15 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:15 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:15 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:15 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:15 --> Controller Class Initialized
INFO - 2018-08-02 13:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:15 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:15 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:15 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 13:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:15 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:15 --> Total execution time: 0.0453
INFO - 2018-08-02 13:07:31 --> Config Class Initialized
INFO - 2018-08-02 13:07:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:31 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:31 --> URI Class Initialized
INFO - 2018-08-02 13:07:31 --> Router Class Initialized
INFO - 2018-08-02 13:07:31 --> Output Class Initialized
INFO - 2018-08-02 13:07:31 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:31 --> CSRF cookie sent
INFO - 2018-08-02 13:07:31 --> CSRF token verified
INFO - 2018-08-02 13:07:31 --> Input Class Initialized
INFO - 2018-08-02 13:07:31 --> Language Class Initialized
INFO - 2018-08-02 13:07:31 --> Loader Class Initialized
INFO - 2018-08-02 13:07:31 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:31 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:31 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:31 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:31 --> Controller Class Initialized
INFO - 2018-08-02 13:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:31 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:31 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:31 --> Form Validation Class Initialized
INFO - 2018-08-02 13:07:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:07:31 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:31 --> Config Class Initialized
INFO - 2018-08-02 13:07:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:31 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:31 --> URI Class Initialized
INFO - 2018-08-02 13:07:31 --> Router Class Initialized
INFO - 2018-08-02 13:07:31 --> Output Class Initialized
INFO - 2018-08-02 13:07:31 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:31 --> CSRF cookie sent
INFO - 2018-08-02 13:07:31 --> Input Class Initialized
INFO - 2018-08-02 13:07:31 --> Language Class Initialized
INFO - 2018-08-02 13:07:31 --> Loader Class Initialized
INFO - 2018-08-02 13:07:31 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:31 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:31 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:31 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:31 --> Controller Class Initialized
INFO - 2018-08-02 13:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:31 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:31 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:31 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 13:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:31 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:31 --> Total execution time: 0.0438
INFO - 2018-08-02 13:07:37 --> Config Class Initialized
INFO - 2018-08-02 13:07:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:37 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:37 --> URI Class Initialized
INFO - 2018-08-02 13:07:37 --> Router Class Initialized
INFO - 2018-08-02 13:07:37 --> Output Class Initialized
INFO - 2018-08-02 13:07:37 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:37 --> CSRF cookie sent
INFO - 2018-08-02 13:07:37 --> CSRF token verified
INFO - 2018-08-02 13:07:37 --> Input Class Initialized
INFO - 2018-08-02 13:07:37 --> Language Class Initialized
INFO - 2018-08-02 13:07:37 --> Loader Class Initialized
INFO - 2018-08-02 13:07:37 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:37 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:37 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:37 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:37 --> Controller Class Initialized
INFO - 2018-08-02 13:07:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:37 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:37 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:37 --> Form Validation Class Initialized
INFO - 2018-08-02 13:07:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:07:37 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:38 --> Config Class Initialized
INFO - 2018-08-02 13:07:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:38 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:38 --> URI Class Initialized
INFO - 2018-08-02 13:07:38 --> Router Class Initialized
INFO - 2018-08-02 13:07:38 --> Output Class Initialized
INFO - 2018-08-02 13:07:38 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:38 --> CSRF cookie sent
INFO - 2018-08-02 13:07:38 --> Input Class Initialized
INFO - 2018-08-02 13:07:38 --> Language Class Initialized
INFO - 2018-08-02 13:07:38 --> Loader Class Initialized
INFO - 2018-08-02 13:07:38 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:38 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:38 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:38 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:38 --> Controller Class Initialized
INFO - 2018-08-02 13:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:38 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:38 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:38 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-02 13:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:38 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:38 --> Total execution time: 0.0381
INFO - 2018-08-02 13:07:45 --> Config Class Initialized
INFO - 2018-08-02 13:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:45 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:45 --> URI Class Initialized
INFO - 2018-08-02 13:07:45 --> Router Class Initialized
INFO - 2018-08-02 13:07:45 --> Output Class Initialized
INFO - 2018-08-02 13:07:45 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:45 --> CSRF cookie sent
INFO - 2018-08-02 13:07:45 --> CSRF token verified
INFO - 2018-08-02 13:07:45 --> Input Class Initialized
INFO - 2018-08-02 13:07:45 --> Language Class Initialized
INFO - 2018-08-02 13:07:45 --> Loader Class Initialized
INFO - 2018-08-02 13:07:45 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:45 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:45 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:45 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:45 --> Controller Class Initialized
INFO - 2018-08-02 13:07:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:45 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:45 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:45 --> Form Validation Class Initialized
INFO - 2018-08-02 13:07:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:07:45 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:45 --> Config Class Initialized
INFO - 2018-08-02 13:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:07:45 --> Utf8 Class Initialized
INFO - 2018-08-02 13:07:45 --> URI Class Initialized
INFO - 2018-08-02 13:07:45 --> Router Class Initialized
INFO - 2018-08-02 13:07:45 --> Output Class Initialized
INFO - 2018-08-02 13:07:45 --> Security Class Initialized
DEBUG - 2018-08-02 13:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:07:45 --> CSRF cookie sent
INFO - 2018-08-02 13:07:45 --> Input Class Initialized
INFO - 2018-08-02 13:07:45 --> Language Class Initialized
INFO - 2018-08-02 13:07:45 --> Loader Class Initialized
INFO - 2018-08-02 13:07:45 --> Helper loaded: url_helper
INFO - 2018-08-02 13:07:45 --> Helper loaded: form_helper
INFO - 2018-08-02 13:07:45 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:07:45 --> User Agent Class Initialized
INFO - 2018-08-02 13:07:45 --> Controller Class Initialized
INFO - 2018-08-02 13:07:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:07:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:07:45 --> Pixel_Model class loaded
INFO - 2018-08-02 13:07:45 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:45 --> Database Driver Class Initialized
INFO - 2018-08-02 13:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-02 13:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:07:45 --> Final output sent to browser
DEBUG - 2018-08-02 13:07:45 --> Total execution time: 0.0554
INFO - 2018-08-02 13:08:01 --> Config Class Initialized
INFO - 2018-08-02 13:08:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:01 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:01 --> URI Class Initialized
INFO - 2018-08-02 13:08:01 --> Router Class Initialized
INFO - 2018-08-02 13:08:01 --> Output Class Initialized
INFO - 2018-08-02 13:08:01 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:01 --> CSRF cookie sent
INFO - 2018-08-02 13:08:01 --> CSRF token verified
INFO - 2018-08-02 13:08:01 --> Input Class Initialized
INFO - 2018-08-02 13:08:01 --> Language Class Initialized
INFO - 2018-08-02 13:08:01 --> Loader Class Initialized
INFO - 2018-08-02 13:08:01 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:01 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:01 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:01 --> Controller Class Initialized
INFO - 2018-08-02 13:08:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:01 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:01 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:01 --> Form Validation Class Initialized
INFO - 2018-08-02 13:08:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:08:01 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:01 --> Config Class Initialized
INFO - 2018-08-02 13:08:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:01 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:01 --> URI Class Initialized
INFO - 2018-08-02 13:08:01 --> Router Class Initialized
INFO - 2018-08-02 13:08:01 --> Output Class Initialized
INFO - 2018-08-02 13:08:01 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:01 --> CSRF cookie sent
INFO - 2018-08-02 13:08:01 --> Input Class Initialized
INFO - 2018-08-02 13:08:01 --> Language Class Initialized
INFO - 2018-08-02 13:08:01 --> Loader Class Initialized
INFO - 2018-08-02 13:08:01 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:01 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:01 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:01 --> Controller Class Initialized
INFO - 2018-08-02 13:08:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:01 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:01 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:01 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-02 13:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:08:01 --> Final output sent to browser
DEBUG - 2018-08-02 13:08:01 --> Total execution time: 0.0527
INFO - 2018-08-02 13:08:27 --> Config Class Initialized
INFO - 2018-08-02 13:08:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:27 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:27 --> URI Class Initialized
INFO - 2018-08-02 13:08:27 --> Router Class Initialized
INFO - 2018-08-02 13:08:27 --> Output Class Initialized
INFO - 2018-08-02 13:08:27 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:27 --> CSRF cookie sent
INFO - 2018-08-02 13:08:27 --> CSRF token verified
INFO - 2018-08-02 13:08:27 --> Input Class Initialized
INFO - 2018-08-02 13:08:27 --> Language Class Initialized
INFO - 2018-08-02 13:08:27 --> Loader Class Initialized
INFO - 2018-08-02 13:08:27 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:27 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:27 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:27 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:27 --> Controller Class Initialized
INFO - 2018-08-02 13:08:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:27 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:27 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:27 --> Form Validation Class Initialized
INFO - 2018-08-02 13:08:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:08:27 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:27 --> Config Class Initialized
INFO - 2018-08-02 13:08:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:27 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:27 --> URI Class Initialized
INFO - 2018-08-02 13:08:27 --> Router Class Initialized
INFO - 2018-08-02 13:08:27 --> Output Class Initialized
INFO - 2018-08-02 13:08:27 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:27 --> CSRF cookie sent
INFO - 2018-08-02 13:08:27 --> Input Class Initialized
INFO - 2018-08-02 13:08:27 --> Language Class Initialized
INFO - 2018-08-02 13:08:27 --> Loader Class Initialized
INFO - 2018-08-02 13:08:27 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:27 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:27 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:28 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:28 --> Controller Class Initialized
INFO - 2018-08-02 13:08:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:28 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:28 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:28 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-02 13:08:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:08:28 --> Final output sent to browser
DEBUG - 2018-08-02 13:08:28 --> Total execution time: 0.0453
INFO - 2018-08-02 13:08:39 --> Config Class Initialized
INFO - 2018-08-02 13:08:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:39 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:39 --> URI Class Initialized
INFO - 2018-08-02 13:08:39 --> Router Class Initialized
INFO - 2018-08-02 13:08:39 --> Output Class Initialized
INFO - 2018-08-02 13:08:39 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:39 --> CSRF cookie sent
INFO - 2018-08-02 13:08:39 --> CSRF token verified
INFO - 2018-08-02 13:08:39 --> Input Class Initialized
INFO - 2018-08-02 13:08:39 --> Language Class Initialized
INFO - 2018-08-02 13:08:39 --> Loader Class Initialized
INFO - 2018-08-02 13:08:39 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:39 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:39 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:39 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:39 --> Controller Class Initialized
INFO - 2018-08-02 13:08:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:39 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:39 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:39 --> Form Validation Class Initialized
INFO - 2018-08-02 13:08:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:08:39 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:39 --> Config Class Initialized
INFO - 2018-08-02 13:08:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:39 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:39 --> URI Class Initialized
INFO - 2018-08-02 13:08:39 --> Router Class Initialized
INFO - 2018-08-02 13:08:39 --> Output Class Initialized
INFO - 2018-08-02 13:08:39 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:39 --> CSRF cookie sent
INFO - 2018-08-02 13:08:39 --> Input Class Initialized
INFO - 2018-08-02 13:08:39 --> Language Class Initialized
INFO - 2018-08-02 13:08:39 --> Loader Class Initialized
INFO - 2018-08-02 13:08:39 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:39 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:39 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:39 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:39 --> Controller Class Initialized
INFO - 2018-08-02 13:08:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:39 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:39 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:39 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-02 13:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:08:39 --> Final output sent to browser
DEBUG - 2018-08-02 13:08:39 --> Total execution time: 0.0674
INFO - 2018-08-02 13:08:48 --> Config Class Initialized
INFO - 2018-08-02 13:08:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:48 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:48 --> URI Class Initialized
INFO - 2018-08-02 13:08:48 --> Router Class Initialized
INFO - 2018-08-02 13:08:48 --> Output Class Initialized
INFO - 2018-08-02 13:08:48 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:48 --> CSRF cookie sent
INFO - 2018-08-02 13:08:48 --> CSRF token verified
INFO - 2018-08-02 13:08:48 --> Input Class Initialized
INFO - 2018-08-02 13:08:48 --> Language Class Initialized
INFO - 2018-08-02 13:08:48 --> Loader Class Initialized
INFO - 2018-08-02 13:08:48 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:48 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:48 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:48 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:48 --> Controller Class Initialized
INFO - 2018-08-02 13:08:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:48 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:48 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:48 --> Form Validation Class Initialized
INFO - 2018-08-02 13:08:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:08:48 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:48 --> Config Class Initialized
INFO - 2018-08-02 13:08:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:48 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:48 --> URI Class Initialized
INFO - 2018-08-02 13:08:48 --> Router Class Initialized
INFO - 2018-08-02 13:08:48 --> Output Class Initialized
INFO - 2018-08-02 13:08:48 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:48 --> CSRF cookie sent
INFO - 2018-08-02 13:08:48 --> Input Class Initialized
INFO - 2018-08-02 13:08:48 --> Language Class Initialized
INFO - 2018-08-02 13:08:48 --> Loader Class Initialized
INFO - 2018-08-02 13:08:48 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:48 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:48 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:48 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:48 --> Controller Class Initialized
INFO - 2018-08-02 13:08:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:48 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:48 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:48 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-02 13:08:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:08:48 --> Final output sent to browser
DEBUG - 2018-08-02 13:08:48 --> Total execution time: 0.0657
INFO - 2018-08-02 13:08:54 --> Config Class Initialized
INFO - 2018-08-02 13:08:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:54 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:54 --> URI Class Initialized
INFO - 2018-08-02 13:08:54 --> Router Class Initialized
INFO - 2018-08-02 13:08:54 --> Output Class Initialized
INFO - 2018-08-02 13:08:54 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:54 --> CSRF cookie sent
INFO - 2018-08-02 13:08:54 --> CSRF token verified
INFO - 2018-08-02 13:08:54 --> Input Class Initialized
INFO - 2018-08-02 13:08:54 --> Language Class Initialized
INFO - 2018-08-02 13:08:54 --> Loader Class Initialized
INFO - 2018-08-02 13:08:54 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:54 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:54 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:54 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:54 --> Controller Class Initialized
INFO - 2018-08-02 13:08:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:54 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:54 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:54 --> Form Validation Class Initialized
INFO - 2018-08-02 13:08:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:08:54 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:54 --> Config Class Initialized
INFO - 2018-08-02 13:08:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:08:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:08:54 --> Utf8 Class Initialized
INFO - 2018-08-02 13:08:54 --> URI Class Initialized
INFO - 2018-08-02 13:08:54 --> Router Class Initialized
INFO - 2018-08-02 13:08:54 --> Output Class Initialized
INFO - 2018-08-02 13:08:54 --> Security Class Initialized
DEBUG - 2018-08-02 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:08:54 --> CSRF cookie sent
INFO - 2018-08-02 13:08:54 --> Input Class Initialized
INFO - 2018-08-02 13:08:54 --> Language Class Initialized
INFO - 2018-08-02 13:08:54 --> Loader Class Initialized
INFO - 2018-08-02 13:08:54 --> Helper loaded: url_helper
INFO - 2018-08-02 13:08:54 --> Helper loaded: form_helper
INFO - 2018-08-02 13:08:54 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:08:54 --> User Agent Class Initialized
INFO - 2018-08-02 13:08:54 --> Controller Class Initialized
INFO - 2018-08-02 13:08:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:08:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:08:54 --> Pixel_Model class loaded
INFO - 2018-08-02 13:08:54 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:54 --> Database Driver Class Initialized
INFO - 2018-08-02 13:08:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-02 13:08:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:08:54 --> Final output sent to browser
DEBUG - 2018-08-02 13:08:54 --> Total execution time: 0.0469
INFO - 2018-08-02 13:09:00 --> Config Class Initialized
INFO - 2018-08-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:09:00 --> Utf8 Class Initialized
INFO - 2018-08-02 13:09:00 --> URI Class Initialized
INFO - 2018-08-02 13:09:00 --> Router Class Initialized
INFO - 2018-08-02 13:09:00 --> Output Class Initialized
INFO - 2018-08-02 13:09:00 --> Security Class Initialized
DEBUG - 2018-08-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:09:00 --> CSRF cookie sent
INFO - 2018-08-02 13:09:00 --> CSRF token verified
INFO - 2018-08-02 13:09:00 --> Input Class Initialized
INFO - 2018-08-02 13:09:00 --> Language Class Initialized
INFO - 2018-08-02 13:09:00 --> Loader Class Initialized
INFO - 2018-08-02 13:09:00 --> Helper loaded: url_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: form_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:09:00 --> User Agent Class Initialized
INFO - 2018-08-02 13:09:00 --> Controller Class Initialized
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:09:00 --> Pixel_Model class loaded
INFO - 2018-08-02 13:09:00 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:00 --> Form Validation Class Initialized
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 13:09:00 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:00 --> Config Class Initialized
INFO - 2018-08-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:09:00 --> Utf8 Class Initialized
INFO - 2018-08-02 13:09:00 --> URI Class Initialized
INFO - 2018-08-02 13:09:00 --> Router Class Initialized
INFO - 2018-08-02 13:09:00 --> Output Class Initialized
INFO - 2018-08-02 13:09:00 --> Security Class Initialized
DEBUG - 2018-08-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:09:00 --> CSRF cookie sent
INFO - 2018-08-02 13:09:00 --> Input Class Initialized
INFO - 2018-08-02 13:09:00 --> Language Class Initialized
INFO - 2018-08-02 13:09:00 --> Loader Class Initialized
INFO - 2018-08-02 13:09:00 --> Helper loaded: url_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: form_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:09:00 --> User Agent Class Initialized
INFO - 2018-08-02 13:09:00 --> Controller Class Initialized
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:09:00 --> Pixel_Model class loaded
INFO - 2018-08-02 13:09:00 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:00 --> Config Class Initialized
INFO - 2018-08-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:09:00 --> Utf8 Class Initialized
INFO - 2018-08-02 13:09:00 --> URI Class Initialized
INFO - 2018-08-02 13:09:00 --> Router Class Initialized
INFO - 2018-08-02 13:09:00 --> Output Class Initialized
INFO - 2018-08-02 13:09:00 --> Security Class Initialized
DEBUG - 2018-08-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:09:00 --> CSRF cookie sent
INFO - 2018-08-02 13:09:00 --> Input Class Initialized
INFO - 2018-08-02 13:09:00 --> Language Class Initialized
INFO - 2018-08-02 13:09:00 --> Loader Class Initialized
INFO - 2018-08-02 13:09:00 --> Helper loaded: url_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: form_helper
INFO - 2018-08-02 13:09:00 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:09:00 --> User Agent Class Initialized
INFO - 2018-08-02 13:09:00 --> Controller Class Initialized
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:09:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:09:00 --> Pixel_Model class loaded
INFO - 2018-08-02 13:09:00 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:00 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-02 13:09:00 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-02 13:09:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:09:00 --> Final output sent to browser
DEBUG - 2018-08-02 13:09:00 --> Total execution time: 0.0301
INFO - 2018-08-02 13:09:13 --> Config Class Initialized
INFO - 2018-08-02 13:09:13 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:09:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:09:13 --> Utf8 Class Initialized
INFO - 2018-08-02 13:09:13 --> URI Class Initialized
INFO - 2018-08-02 13:09:13 --> Router Class Initialized
INFO - 2018-08-02 13:09:13 --> Output Class Initialized
INFO - 2018-08-02 13:09:13 --> Security Class Initialized
DEBUG - 2018-08-02 13:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:09:13 --> CSRF cookie sent
INFO - 2018-08-02 13:09:13 --> Input Class Initialized
INFO - 2018-08-02 13:09:13 --> Language Class Initialized
INFO - 2018-08-02 13:09:13 --> Loader Class Initialized
INFO - 2018-08-02 13:09:13 --> Helper loaded: url_helper
INFO - 2018-08-02 13:09:13 --> Helper loaded: form_helper
INFO - 2018-08-02 13:09:13 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:09:13 --> User Agent Class Initialized
INFO - 2018-08-02 13:09:13 --> Controller Class Initialized
INFO - 2018-08-02 13:09:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:09:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:09:13 --> Pixel_Model class loaded
INFO - 2018-08-02 13:09:13 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:13 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-02 13:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:09:13 --> Final output sent to browser
DEBUG - 2018-08-02 13:09:13 --> Total execution time: 0.0435
INFO - 2018-08-02 13:09:14 --> Config Class Initialized
INFO - 2018-08-02 13:09:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:09:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:09:14 --> Utf8 Class Initialized
INFO - 2018-08-02 13:09:14 --> URI Class Initialized
INFO - 2018-08-02 13:09:14 --> Router Class Initialized
INFO - 2018-08-02 13:09:14 --> Output Class Initialized
INFO - 2018-08-02 13:09:14 --> Security Class Initialized
DEBUG - 2018-08-02 13:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:09:14 --> CSRF cookie sent
INFO - 2018-08-02 13:09:14 --> Input Class Initialized
INFO - 2018-08-02 13:09:14 --> Language Class Initialized
INFO - 2018-08-02 13:09:14 --> Loader Class Initialized
INFO - 2018-08-02 13:09:14 --> Helper loaded: url_helper
INFO - 2018-08-02 13:09:14 --> Helper loaded: form_helper
INFO - 2018-08-02 13:09:14 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:09:14 --> User Agent Class Initialized
INFO - 2018-08-02 13:09:14 --> Controller Class Initialized
INFO - 2018-08-02 13:09:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:09:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:09:14 --> Pixel_Model class loaded
INFO - 2018-08-02 13:09:14 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:14 --> Database Driver Class Initialized
INFO - 2018-08-02 13:09:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-02 13:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:09:14 --> Final output sent to browser
DEBUG - 2018-08-02 13:09:14 --> Total execution time: 0.0562
INFO - 2018-08-02 13:10:05 --> Config Class Initialized
INFO - 2018-08-02 13:10:05 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:10:05 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:10:05 --> Utf8 Class Initialized
INFO - 2018-08-02 13:10:05 --> URI Class Initialized
INFO - 2018-08-02 13:10:05 --> Router Class Initialized
INFO - 2018-08-02 13:10:05 --> Output Class Initialized
INFO - 2018-08-02 13:10:05 --> Security Class Initialized
DEBUG - 2018-08-02 13:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:10:05 --> CSRF cookie sent
INFO - 2018-08-02 13:10:05 --> Input Class Initialized
INFO - 2018-08-02 13:10:05 --> Language Class Initialized
INFO - 2018-08-02 13:10:05 --> Loader Class Initialized
INFO - 2018-08-02 13:10:05 --> Helper loaded: url_helper
INFO - 2018-08-02 13:10:05 --> Helper loaded: form_helper
INFO - 2018-08-02 13:10:05 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:10:05 --> User Agent Class Initialized
INFO - 2018-08-02 13:10:05 --> Controller Class Initialized
INFO - 2018-08-02 13:10:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:10:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-02 13:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:10:05 --> Final output sent to browser
DEBUG - 2018-08-02 13:10:05 --> Total execution time: 0.0286
INFO - 2018-08-02 13:10:38 --> Config Class Initialized
INFO - 2018-08-02 13:10:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:10:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:10:38 --> Utf8 Class Initialized
INFO - 2018-08-02 13:10:38 --> URI Class Initialized
INFO - 2018-08-02 13:10:38 --> Router Class Initialized
INFO - 2018-08-02 13:10:38 --> Output Class Initialized
INFO - 2018-08-02 13:10:38 --> Security Class Initialized
DEBUG - 2018-08-02 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:10:38 --> CSRF cookie sent
INFO - 2018-08-02 13:10:38 --> Input Class Initialized
INFO - 2018-08-02 13:10:38 --> Language Class Initialized
INFO - 2018-08-02 13:10:38 --> Loader Class Initialized
INFO - 2018-08-02 13:10:38 --> Helper loaded: url_helper
INFO - 2018-08-02 13:10:38 --> Helper loaded: form_helper
INFO - 2018-08-02 13:10:38 --> Helper loaded: language_helper
DEBUG - 2018-08-02 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 13:10:38 --> User Agent Class Initialized
INFO - 2018-08-02 13:10:38 --> Controller Class Initialized
INFO - 2018-08-02 13:10:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 13:10:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-08-02 13:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 13:10:38 --> Final output sent to browser
DEBUG - 2018-08-02 13:10:38 --> Total execution time: 0.0232
INFO - 2018-08-02 13:19:29 --> Config Class Initialized
INFO - 2018-08-02 13:19:29 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:19:29 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:19:29 --> Utf8 Class Initialized
INFO - 2018-08-02 13:19:29 --> URI Class Initialized
INFO - 2018-08-02 13:19:29 --> Router Class Initialized
INFO - 2018-08-02 13:19:29 --> Output Class Initialized
INFO - 2018-08-02 13:19:29 --> Security Class Initialized
DEBUG - 2018-08-02 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:19:29 --> CSRF cookie sent
INFO - 2018-08-02 13:19:29 --> Input Class Initialized
INFO - 2018-08-02 13:19:29 --> Language Class Initialized
ERROR - 2018-08-02 13:19:29 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 13:19:31 --> Config Class Initialized
INFO - 2018-08-02 13:19:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:19:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:19:31 --> Utf8 Class Initialized
INFO - 2018-08-02 13:19:31 --> URI Class Initialized
INFO - 2018-08-02 13:19:31 --> Router Class Initialized
INFO - 2018-08-02 13:19:31 --> Output Class Initialized
INFO - 2018-08-02 13:19:31 --> Security Class Initialized
DEBUG - 2018-08-02 13:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:19:31 --> CSRF cookie sent
INFO - 2018-08-02 13:19:31 --> Input Class Initialized
INFO - 2018-08-02 13:19:31 --> Language Class Initialized
ERROR - 2018-08-02 13:19:31 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-02 13:19:42 --> Config Class Initialized
INFO - 2018-08-02 13:19:42 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:19:42 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:19:42 --> Utf8 Class Initialized
INFO - 2018-08-02 13:19:42 --> URI Class Initialized
INFO - 2018-08-02 13:19:42 --> Router Class Initialized
INFO - 2018-08-02 13:19:42 --> Output Class Initialized
INFO - 2018-08-02 13:19:42 --> Security Class Initialized
DEBUG - 2018-08-02 13:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:19:42 --> CSRF cookie sent
INFO - 2018-08-02 13:19:42 --> Input Class Initialized
INFO - 2018-08-02 13:19:42 --> Language Class Initialized
ERROR - 2018-08-02 13:19:42 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 13:19:50 --> Config Class Initialized
INFO - 2018-08-02 13:19:50 --> Hooks Class Initialized
DEBUG - 2018-08-02 13:19:50 --> UTF-8 Support Enabled
INFO - 2018-08-02 13:19:50 --> Utf8 Class Initialized
INFO - 2018-08-02 13:19:50 --> URI Class Initialized
INFO - 2018-08-02 13:19:50 --> Router Class Initialized
INFO - 2018-08-02 13:19:50 --> Output Class Initialized
INFO - 2018-08-02 13:19:50 --> Security Class Initialized
DEBUG - 2018-08-02 13:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 13:19:50 --> CSRF cookie sent
INFO - 2018-08-02 13:19:50 --> Input Class Initialized
INFO - 2018-08-02 13:19:50 --> Language Class Initialized
ERROR - 2018-08-02 13:19:50 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 15:11:03 --> Config Class Initialized
INFO - 2018-08-02 15:11:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:11:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:11:03 --> Utf8 Class Initialized
INFO - 2018-08-02 15:11:03 --> URI Class Initialized
INFO - 2018-08-02 15:11:03 --> Router Class Initialized
INFO - 2018-08-02 15:11:03 --> Output Class Initialized
INFO - 2018-08-02 15:11:03 --> Security Class Initialized
DEBUG - 2018-08-02 15:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:11:03 --> CSRF cookie sent
INFO - 2018-08-02 15:11:03 --> Input Class Initialized
INFO - 2018-08-02 15:11:03 --> Language Class Initialized
INFO - 2018-08-02 15:11:03 --> Loader Class Initialized
INFO - 2018-08-02 15:11:03 --> Helper loaded: url_helper
INFO - 2018-08-02 15:11:03 --> Helper loaded: form_helper
INFO - 2018-08-02 15:11:03 --> Helper loaded: language_helper
DEBUG - 2018-08-02 15:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 15:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 15:11:03 --> User Agent Class Initialized
INFO - 2018-08-02 15:11:03 --> Controller Class Initialized
INFO - 2018-08-02 15:11:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 15:11:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-08-02 15:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 15:11:03 --> Final output sent to browser
DEBUG - 2018-08-02 15:11:03 --> Total execution time: 0.0239
INFO - 2018-08-02 15:13:23 --> Config Class Initialized
INFO - 2018-08-02 15:13:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:13:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:13:23 --> Utf8 Class Initialized
INFO - 2018-08-02 15:13:23 --> URI Class Initialized
INFO - 2018-08-02 15:13:23 --> Router Class Initialized
INFO - 2018-08-02 15:13:23 --> Output Class Initialized
INFO - 2018-08-02 15:13:23 --> Security Class Initialized
DEBUG - 2018-08-02 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:13:23 --> CSRF cookie sent
INFO - 2018-08-02 15:13:23 --> Input Class Initialized
INFO - 2018-08-02 15:13:23 --> Language Class Initialized
ERROR - 2018-08-02 15:13:23 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 15:13:24 --> Config Class Initialized
INFO - 2018-08-02 15:13:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:13:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:13:24 --> Utf8 Class Initialized
INFO - 2018-08-02 15:13:24 --> URI Class Initialized
INFO - 2018-08-02 15:13:24 --> Router Class Initialized
INFO - 2018-08-02 15:13:24 --> Output Class Initialized
INFO - 2018-08-02 15:13:24 --> Security Class Initialized
DEBUG - 2018-08-02 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:13:24 --> CSRF cookie sent
INFO - 2018-08-02 15:13:24 --> Input Class Initialized
INFO - 2018-08-02 15:13:24 --> Language Class Initialized
ERROR - 2018-08-02 15:13:24 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-02 15:13:32 --> Config Class Initialized
INFO - 2018-08-02 15:13:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:13:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:13:33 --> Utf8 Class Initialized
INFO - 2018-08-02 15:13:33 --> URI Class Initialized
DEBUG - 2018-08-02 15:13:33 --> No URI present. Default controller set.
INFO - 2018-08-02 15:13:33 --> Router Class Initialized
INFO - 2018-08-02 15:13:33 --> Output Class Initialized
INFO - 2018-08-02 15:13:33 --> Security Class Initialized
DEBUG - 2018-08-02 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:13:33 --> CSRF cookie sent
INFO - 2018-08-02 15:13:33 --> Input Class Initialized
INFO - 2018-08-02 15:13:33 --> Language Class Initialized
INFO - 2018-08-02 15:13:33 --> Loader Class Initialized
INFO - 2018-08-02 15:13:33 --> Helper loaded: url_helper
INFO - 2018-08-02 15:13:33 --> Helper loaded: form_helper
INFO - 2018-08-02 15:13:33 --> Helper loaded: language_helper
DEBUG - 2018-08-02 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 15:13:33 --> User Agent Class Initialized
INFO - 2018-08-02 15:13:33 --> Controller Class Initialized
INFO - 2018-08-02 15:13:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 15:13:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 15:13:33 --> Pixel_Model class loaded
INFO - 2018-08-02 15:13:33 --> Database Driver Class Initialized
INFO - 2018-08-02 15:13:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 15:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 15:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 15:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 15:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 15:13:33 --> Final output sent to browser
DEBUG - 2018-08-02 15:13:33 --> Total execution time: 0.0330
INFO - 2018-08-02 15:16:48 --> Config Class Initialized
INFO - 2018-08-02 15:16:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:16:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:16:48 --> Utf8 Class Initialized
INFO - 2018-08-02 15:16:48 --> URI Class Initialized
INFO - 2018-08-02 15:16:48 --> Router Class Initialized
INFO - 2018-08-02 15:16:48 --> Output Class Initialized
INFO - 2018-08-02 15:16:48 --> Security Class Initialized
DEBUG - 2018-08-02 15:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:16:48 --> CSRF cookie sent
INFO - 2018-08-02 15:16:48 --> Input Class Initialized
INFO - 2018-08-02 15:16:48 --> Language Class Initialized
ERROR - 2018-08-02 15:16:48 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 15:16:54 --> Config Class Initialized
INFO - 2018-08-02 15:16:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:16:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:16:54 --> Utf8 Class Initialized
INFO - 2018-08-02 15:16:54 --> URI Class Initialized
DEBUG - 2018-08-02 15:16:54 --> No URI present. Default controller set.
INFO - 2018-08-02 15:16:54 --> Router Class Initialized
INFO - 2018-08-02 15:16:54 --> Output Class Initialized
INFO - 2018-08-02 15:16:54 --> Security Class Initialized
DEBUG - 2018-08-02 15:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:16:54 --> CSRF cookie sent
INFO - 2018-08-02 15:16:54 --> Input Class Initialized
INFO - 2018-08-02 15:16:54 --> Language Class Initialized
INFO - 2018-08-02 15:16:54 --> Loader Class Initialized
INFO - 2018-08-02 15:16:54 --> Helper loaded: url_helper
INFO - 2018-08-02 15:16:54 --> Helper loaded: form_helper
INFO - 2018-08-02 15:16:54 --> Helper loaded: language_helper
DEBUG - 2018-08-02 15:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 15:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 15:16:54 --> User Agent Class Initialized
INFO - 2018-08-02 15:16:54 --> Controller Class Initialized
INFO - 2018-08-02 15:16:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 15:16:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 15:16:54 --> Pixel_Model class loaded
INFO - 2018-08-02 15:16:54 --> Database Driver Class Initialized
INFO - 2018-08-02 15:16:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 15:16:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 15:16:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 15:16:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 15:16:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 15:16:54 --> Final output sent to browser
DEBUG - 2018-08-02 15:16:54 --> Total execution time: 0.0431
INFO - 2018-08-02 15:18:10 --> Config Class Initialized
INFO - 2018-08-02 15:18:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:18:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:18:10 --> Utf8 Class Initialized
INFO - 2018-08-02 15:18:10 --> URI Class Initialized
INFO - 2018-08-02 15:18:10 --> Router Class Initialized
INFO - 2018-08-02 15:18:10 --> Output Class Initialized
INFO - 2018-08-02 15:18:10 --> Security Class Initialized
DEBUG - 2018-08-02 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:18:10 --> CSRF cookie sent
INFO - 2018-08-02 15:18:10 --> Input Class Initialized
INFO - 2018-08-02 15:18:10 --> Language Class Initialized
ERROR - 2018-08-02 15:18:10 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 15:18:18 --> Config Class Initialized
INFO - 2018-08-02 15:18:18 --> Hooks Class Initialized
DEBUG - 2018-08-02 15:18:18 --> UTF-8 Support Enabled
INFO - 2018-08-02 15:18:18 --> Utf8 Class Initialized
INFO - 2018-08-02 15:18:18 --> URI Class Initialized
DEBUG - 2018-08-02 15:18:18 --> No URI present. Default controller set.
INFO - 2018-08-02 15:18:18 --> Router Class Initialized
INFO - 2018-08-02 15:18:18 --> Output Class Initialized
INFO - 2018-08-02 15:18:18 --> Security Class Initialized
DEBUG - 2018-08-02 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 15:18:18 --> CSRF cookie sent
INFO - 2018-08-02 15:18:18 --> Input Class Initialized
INFO - 2018-08-02 15:18:18 --> Language Class Initialized
INFO - 2018-08-02 15:18:18 --> Loader Class Initialized
INFO - 2018-08-02 15:18:18 --> Helper loaded: url_helper
INFO - 2018-08-02 15:18:18 --> Helper loaded: form_helper
INFO - 2018-08-02 15:18:18 --> Helper loaded: language_helper
DEBUG - 2018-08-02 15:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 15:18:18 --> User Agent Class Initialized
INFO - 2018-08-02 15:18:18 --> Controller Class Initialized
INFO - 2018-08-02 15:18:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 15:18:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 15:18:18 --> Pixel_Model class loaded
INFO - 2018-08-02 15:18:18 --> Database Driver Class Initialized
INFO - 2018-08-02 15:18:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 15:18:18 --> Final output sent to browser
DEBUG - 2018-08-02 15:18:18 --> Total execution time: 0.0336
INFO - 2018-08-02 18:28:57 --> Config Class Initialized
INFO - 2018-08-02 18:28:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 18:28:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 18:28:57 --> Utf8 Class Initialized
INFO - 2018-08-02 18:28:57 --> URI Class Initialized
INFO - 2018-08-02 18:28:57 --> Router Class Initialized
INFO - 2018-08-02 18:28:57 --> Output Class Initialized
INFO - 2018-08-02 18:28:57 --> Security Class Initialized
DEBUG - 2018-08-02 18:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 18:28:57 --> CSRF cookie sent
INFO - 2018-08-02 18:28:57 --> Input Class Initialized
INFO - 2018-08-02 18:28:57 --> Language Class Initialized
ERROR - 2018-08-02 18:28:57 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 18:29:00 --> Config Class Initialized
INFO - 2018-08-02 18:29:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 18:29:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 18:29:00 --> Utf8 Class Initialized
INFO - 2018-08-02 18:29:00 --> URI Class Initialized
DEBUG - 2018-08-02 18:29:00 --> No URI present. Default controller set.
INFO - 2018-08-02 18:29:00 --> Router Class Initialized
INFO - 2018-08-02 18:29:00 --> Output Class Initialized
INFO - 2018-08-02 18:29:00 --> Security Class Initialized
DEBUG - 2018-08-02 18:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 18:29:00 --> CSRF cookie sent
INFO - 2018-08-02 18:29:00 --> Input Class Initialized
INFO - 2018-08-02 18:29:00 --> Language Class Initialized
INFO - 2018-08-02 18:29:00 --> Loader Class Initialized
INFO - 2018-08-02 18:29:00 --> Helper loaded: url_helper
INFO - 2018-08-02 18:29:00 --> Helper loaded: form_helper
INFO - 2018-08-02 18:29:00 --> Helper loaded: language_helper
DEBUG - 2018-08-02 18:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 18:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 18:29:00 --> User Agent Class Initialized
INFO - 2018-08-02 18:29:00 --> Controller Class Initialized
INFO - 2018-08-02 18:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 18:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 18:29:00 --> Pixel_Model class loaded
INFO - 2018-08-02 18:29:00 --> Database Driver Class Initialized
INFO - 2018-08-02 18:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 18:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 18:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 18:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 18:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 18:29:00 --> Final output sent to browser
DEBUG - 2018-08-02 18:29:00 --> Total execution time: 0.0332
INFO - 2018-08-02 19:27:07 --> Config Class Initialized
INFO - 2018-08-02 19:27:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:27:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:27:07 --> Utf8 Class Initialized
INFO - 2018-08-02 19:27:07 --> URI Class Initialized
INFO - 2018-08-02 19:27:07 --> Router Class Initialized
INFO - 2018-08-02 19:27:07 --> Output Class Initialized
INFO - 2018-08-02 19:27:07 --> Security Class Initialized
DEBUG - 2018-08-02 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:27:07 --> CSRF cookie sent
INFO - 2018-08-02 19:27:07 --> Input Class Initialized
INFO - 2018-08-02 19:27:07 --> Language Class Initialized
ERROR - 2018-08-02 19:27:07 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 19:27:11 --> Config Class Initialized
INFO - 2018-08-02 19:27:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:27:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:27:11 --> Utf8 Class Initialized
INFO - 2018-08-02 19:27:11 --> URI Class Initialized
DEBUG - 2018-08-02 19:27:11 --> No URI present. Default controller set.
INFO - 2018-08-02 19:27:11 --> Router Class Initialized
INFO - 2018-08-02 19:27:11 --> Output Class Initialized
INFO - 2018-08-02 19:27:11 --> Security Class Initialized
DEBUG - 2018-08-02 19:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:27:11 --> CSRF cookie sent
INFO - 2018-08-02 19:27:11 --> Input Class Initialized
INFO - 2018-08-02 19:27:11 --> Language Class Initialized
INFO - 2018-08-02 19:27:11 --> Loader Class Initialized
INFO - 2018-08-02 19:27:11 --> Helper loaded: url_helper
INFO - 2018-08-02 19:27:11 --> Helper loaded: form_helper
INFO - 2018-08-02 19:27:11 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:27:11 --> User Agent Class Initialized
INFO - 2018-08-02 19:27:11 --> Controller Class Initialized
INFO - 2018-08-02 19:27:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:27:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:27:11 --> Pixel_Model class loaded
INFO - 2018-08-02 19:27:11 --> Database Driver Class Initialized
INFO - 2018-08-02 19:27:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:27:11 --> Final output sent to browser
DEBUG - 2018-08-02 19:27:11 --> Total execution time: 0.0344
INFO - 2018-08-02 19:27:20 --> Config Class Initialized
INFO - 2018-08-02 19:27:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:27:20 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:27:20 --> Utf8 Class Initialized
INFO - 2018-08-02 19:27:20 --> URI Class Initialized
INFO - 2018-08-02 19:27:20 --> Router Class Initialized
INFO - 2018-08-02 19:27:20 --> Output Class Initialized
INFO - 2018-08-02 19:27:20 --> Security Class Initialized
DEBUG - 2018-08-02 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:27:20 --> CSRF cookie sent
INFO - 2018-08-02 19:27:20 --> CSRF token verified
INFO - 2018-08-02 19:27:20 --> Input Class Initialized
INFO - 2018-08-02 19:27:20 --> Language Class Initialized
INFO - 2018-08-02 19:27:20 --> Loader Class Initialized
INFO - 2018-08-02 19:27:20 --> Helper loaded: url_helper
INFO - 2018-08-02 19:27:20 --> Helper loaded: form_helper
INFO - 2018-08-02 19:27:20 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:27:20 --> User Agent Class Initialized
INFO - 2018-08-02 19:27:20 --> Controller Class Initialized
INFO - 2018-08-02 19:27:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:27:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:27:20 --> Pixel_Model class loaded
INFO - 2018-08-02 19:27:20 --> Database Driver Class Initialized
INFO - 2018-08-02 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:27:20 --> Database Driver Class Initialized
INFO - 2018-08-02 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:27:20 --> Config Class Initialized
INFO - 2018-08-02 19:27:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:27:20 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:27:20 --> Utf8 Class Initialized
INFO - 2018-08-02 19:27:20 --> URI Class Initialized
INFO - 2018-08-02 19:27:20 --> Router Class Initialized
INFO - 2018-08-02 19:27:20 --> Output Class Initialized
INFO - 2018-08-02 19:27:20 --> Security Class Initialized
DEBUG - 2018-08-02 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:27:20 --> CSRF cookie sent
INFO - 2018-08-02 19:27:20 --> Input Class Initialized
INFO - 2018-08-02 19:27:20 --> Language Class Initialized
INFO - 2018-08-02 19:27:20 --> Loader Class Initialized
INFO - 2018-08-02 19:27:20 --> Helper loaded: url_helper
INFO - 2018-08-02 19:27:20 --> Helper loaded: form_helper
INFO - 2018-08-02 19:27:20 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:27:20 --> User Agent Class Initialized
INFO - 2018-08-02 19:27:20 --> Controller Class Initialized
INFO - 2018-08-02 19:27:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:27:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:27:20 --> Pixel_Model class loaded
INFO - 2018-08-02 19:27:20 --> Database Driver Class Initialized
INFO - 2018-08-02 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:27:20 --> Database Driver Class Initialized
INFO - 2018-08-02 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:27:20 --> Final output sent to browser
DEBUG - 2018-08-02 19:27:20 --> Total execution time: 0.0477
INFO - 2018-08-02 19:28:11 --> Config Class Initialized
INFO - 2018-08-02 19:28:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:11 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:11 --> URI Class Initialized
INFO - 2018-08-02 19:28:11 --> Router Class Initialized
INFO - 2018-08-02 19:28:11 --> Output Class Initialized
INFO - 2018-08-02 19:28:11 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:11 --> CSRF cookie sent
INFO - 2018-08-02 19:28:11 --> Input Class Initialized
INFO - 2018-08-02 19:28:11 --> Language Class Initialized
INFO - 2018-08-02 19:28:11 --> Loader Class Initialized
INFO - 2018-08-02 19:28:11 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:11 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:11 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:11 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:11 --> Controller Class Initialized
INFO - 2018-08-02 19:28:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:11 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:11 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:11 --> Config Class Initialized
INFO - 2018-08-02 19:28:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:11 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:11 --> URI Class Initialized
INFO - 2018-08-02 19:28:11 --> Router Class Initialized
INFO - 2018-08-02 19:28:11 --> Output Class Initialized
INFO - 2018-08-02 19:28:11 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:11 --> CSRF cookie sent
INFO - 2018-08-02 19:28:11 --> Input Class Initialized
INFO - 2018-08-02 19:28:11 --> Language Class Initialized
INFO - 2018-08-02 19:28:11 --> Loader Class Initialized
INFO - 2018-08-02 19:28:11 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:11 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:11 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:11 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:11 --> Controller Class Initialized
INFO - 2018-08-02 19:28:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:11 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:11 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:11 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-02 19:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:28:11 --> Final output sent to browser
DEBUG - 2018-08-02 19:28:11 --> Total execution time: 0.0525
INFO - 2018-08-02 19:28:16 --> Config Class Initialized
INFO - 2018-08-02 19:28:16 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:16 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:16 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:16 --> URI Class Initialized
INFO - 2018-08-02 19:28:16 --> Router Class Initialized
INFO - 2018-08-02 19:28:16 --> Output Class Initialized
INFO - 2018-08-02 19:28:16 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:16 --> CSRF cookie sent
INFO - 2018-08-02 19:28:16 --> CSRF token verified
INFO - 2018-08-02 19:28:16 --> Input Class Initialized
INFO - 2018-08-02 19:28:16 --> Language Class Initialized
INFO - 2018-08-02 19:28:16 --> Loader Class Initialized
INFO - 2018-08-02 19:28:16 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:16 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:16 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:16 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:16 --> Controller Class Initialized
INFO - 2018-08-02 19:28:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:16 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:16 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:16 --> Form Validation Class Initialized
INFO - 2018-08-02 19:28:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:28:16 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:16 --> Config Class Initialized
INFO - 2018-08-02 19:28:16 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:16 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:16 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:16 --> URI Class Initialized
INFO - 2018-08-02 19:28:16 --> Router Class Initialized
INFO - 2018-08-02 19:28:16 --> Output Class Initialized
INFO - 2018-08-02 19:28:16 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:16 --> CSRF cookie sent
INFO - 2018-08-02 19:28:16 --> Input Class Initialized
INFO - 2018-08-02 19:28:16 --> Language Class Initialized
INFO - 2018-08-02 19:28:16 --> Loader Class Initialized
INFO - 2018-08-02 19:28:16 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:16 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:16 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:16 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:16 --> Controller Class Initialized
INFO - 2018-08-02 19:28:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:16 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:16 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:16 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-02 19:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:28:16 --> Final output sent to browser
DEBUG - 2018-08-02 19:28:16 --> Total execution time: 0.0409
INFO - 2018-08-02 19:28:21 --> Config Class Initialized
INFO - 2018-08-02 19:28:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:21 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:21 --> URI Class Initialized
INFO - 2018-08-02 19:28:21 --> Router Class Initialized
INFO - 2018-08-02 19:28:21 --> Output Class Initialized
INFO - 2018-08-02 19:28:21 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:21 --> CSRF cookie sent
INFO - 2018-08-02 19:28:21 --> Input Class Initialized
INFO - 2018-08-02 19:28:21 --> Language Class Initialized
INFO - 2018-08-02 19:28:21 --> Loader Class Initialized
INFO - 2018-08-02 19:28:21 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:21 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:21 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:21 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:21 --> Controller Class Initialized
INFO - 2018-08-02 19:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:21 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:22 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:22 --> Config Class Initialized
INFO - 2018-08-02 19:28:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:22 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:22 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:22 --> URI Class Initialized
INFO - 2018-08-02 19:28:22 --> Router Class Initialized
INFO - 2018-08-02 19:28:22 --> Output Class Initialized
INFO - 2018-08-02 19:28:22 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:22 --> CSRF cookie sent
INFO - 2018-08-02 19:28:22 --> Input Class Initialized
INFO - 2018-08-02 19:28:22 --> Language Class Initialized
INFO - 2018-08-02 19:28:22 --> Loader Class Initialized
INFO - 2018-08-02 19:28:22 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:22 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:22 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:22 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:22 --> Controller Class Initialized
INFO - 2018-08-02 19:28:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:22 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:22 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:22 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-02 19:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:28:22 --> Final output sent to browser
DEBUG - 2018-08-02 19:28:22 --> Total execution time: 0.0484
INFO - 2018-08-02 19:28:37 --> Config Class Initialized
INFO - 2018-08-02 19:28:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:37 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:37 --> URI Class Initialized
INFO - 2018-08-02 19:28:37 --> Router Class Initialized
INFO - 2018-08-02 19:28:37 --> Output Class Initialized
INFO - 2018-08-02 19:28:37 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:37 --> CSRF cookie sent
INFO - 2018-08-02 19:28:37 --> Input Class Initialized
INFO - 2018-08-02 19:28:37 --> Language Class Initialized
ERROR - 2018-08-02 19:28:37 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-02 19:28:43 --> Config Class Initialized
INFO - 2018-08-02 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:43 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:43 --> URI Class Initialized
DEBUG - 2018-08-02 19:28:43 --> No URI present. Default controller set.
INFO - 2018-08-02 19:28:43 --> Router Class Initialized
INFO - 2018-08-02 19:28:43 --> Output Class Initialized
INFO - 2018-08-02 19:28:43 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:43 --> CSRF cookie sent
INFO - 2018-08-02 19:28:43 --> Input Class Initialized
INFO - 2018-08-02 19:28:43 --> Language Class Initialized
INFO - 2018-08-02 19:28:43 --> Loader Class Initialized
INFO - 2018-08-02 19:28:43 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:43 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:43 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:43 --> Controller Class Initialized
INFO - 2018-08-02 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:43 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:43 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:28:43 --> Final output sent to browser
DEBUG - 2018-08-02 19:28:43 --> Total execution time: 0.0400
INFO - 2018-08-02 19:28:43 --> Config Class Initialized
INFO - 2018-08-02 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:28:43 --> Utf8 Class Initialized
INFO - 2018-08-02 19:28:43 --> URI Class Initialized
DEBUG - 2018-08-02 19:28:43 --> No URI present. Default controller set.
INFO - 2018-08-02 19:28:43 --> Router Class Initialized
INFO - 2018-08-02 19:28:43 --> Output Class Initialized
INFO - 2018-08-02 19:28:43 --> Security Class Initialized
DEBUG - 2018-08-02 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:28:43 --> CSRF cookie sent
INFO - 2018-08-02 19:28:43 --> Input Class Initialized
INFO - 2018-08-02 19:28:43 --> Language Class Initialized
INFO - 2018-08-02 19:28:43 --> Loader Class Initialized
INFO - 2018-08-02 19:28:43 --> Helper loaded: url_helper
INFO - 2018-08-02 19:28:43 --> Helper loaded: form_helper
INFO - 2018-08-02 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:28:43 --> User Agent Class Initialized
INFO - 2018-08-02 19:28:43 --> Controller Class Initialized
INFO - 2018-08-02 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:28:43 --> Pixel_Model class loaded
INFO - 2018-08-02 19:28:43 --> Database Driver Class Initialized
INFO - 2018-08-02 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:28:43 --> Final output sent to browser
DEBUG - 2018-08-02 19:28:43 --> Total execution time: 0.0283
INFO - 2018-08-02 19:29:06 --> Config Class Initialized
INFO - 2018-08-02 19:29:06 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:29:06 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:29:06 --> Utf8 Class Initialized
INFO - 2018-08-02 19:29:06 --> URI Class Initialized
DEBUG - 2018-08-02 19:29:06 --> No URI present. Default controller set.
INFO - 2018-08-02 19:29:06 --> Router Class Initialized
INFO - 2018-08-02 19:29:06 --> Output Class Initialized
INFO - 2018-08-02 19:29:06 --> Security Class Initialized
DEBUG - 2018-08-02 19:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:29:06 --> CSRF cookie sent
INFO - 2018-08-02 19:29:06 --> Input Class Initialized
INFO - 2018-08-02 19:29:06 --> Language Class Initialized
INFO - 2018-08-02 19:29:06 --> Loader Class Initialized
INFO - 2018-08-02 19:29:06 --> Helper loaded: url_helper
INFO - 2018-08-02 19:29:06 --> Helper loaded: form_helper
INFO - 2018-08-02 19:29:06 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:29:06 --> User Agent Class Initialized
INFO - 2018-08-02 19:29:06 --> Controller Class Initialized
INFO - 2018-08-02 19:29:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:29:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:29:06 --> Pixel_Model class loaded
INFO - 2018-08-02 19:29:06 --> Database Driver Class Initialized
INFO - 2018-08-02 19:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:29:06 --> Final output sent to browser
DEBUG - 2018-08-02 19:29:06 --> Total execution time: 0.0348
INFO - 2018-08-02 19:29:36 --> Config Class Initialized
INFO - 2018-08-02 19:29:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:29:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:29:36 --> Utf8 Class Initialized
INFO - 2018-08-02 19:29:36 --> URI Class Initialized
INFO - 2018-08-02 19:29:36 --> Router Class Initialized
INFO - 2018-08-02 19:29:36 --> Output Class Initialized
INFO - 2018-08-02 19:29:36 --> Security Class Initialized
DEBUG - 2018-08-02 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:29:36 --> CSRF cookie sent
INFO - 2018-08-02 19:29:36 --> Input Class Initialized
INFO - 2018-08-02 19:29:36 --> Language Class Initialized
INFO - 2018-08-02 19:29:36 --> Loader Class Initialized
INFO - 2018-08-02 19:29:36 --> Helper loaded: url_helper
INFO - 2018-08-02 19:29:36 --> Helper loaded: form_helper
INFO - 2018-08-02 19:29:36 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:29:36 --> User Agent Class Initialized
INFO - 2018-08-02 19:29:36 --> Controller Class Initialized
INFO - 2018-08-02 19:29:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:29:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-08-02 19:29:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:29:36 --> Final output sent to browser
DEBUG - 2018-08-02 19:29:36 --> Total execution time: 0.0277
INFO - 2018-08-02 19:30:56 --> Config Class Initialized
INFO - 2018-08-02 19:30:56 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:30:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:30:56 --> Utf8 Class Initialized
INFO - 2018-08-02 19:30:56 --> URI Class Initialized
INFO - 2018-08-02 19:30:56 --> Router Class Initialized
INFO - 2018-08-02 19:30:56 --> Output Class Initialized
INFO - 2018-08-02 19:30:56 --> Security Class Initialized
DEBUG - 2018-08-02 19:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:30:56 --> CSRF cookie sent
INFO - 2018-08-02 19:30:56 --> Input Class Initialized
INFO - 2018-08-02 19:30:56 --> Language Class Initialized
INFO - 2018-08-02 19:30:56 --> Loader Class Initialized
INFO - 2018-08-02 19:30:56 --> Helper loaded: url_helper
INFO - 2018-08-02 19:30:56 --> Helper loaded: form_helper
INFO - 2018-08-02 19:30:56 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:30:56 --> User Agent Class Initialized
INFO - 2018-08-02 19:30:56 --> Controller Class Initialized
INFO - 2018-08-02 19:30:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:30:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-02 19:30:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-02 19:30:56 --> Could not find the language line "req_email"
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-02 19:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:30:56 --> Final output sent to browser
DEBUG - 2018-08-02 19:30:56 --> Total execution time: 0.0267
INFO - 2018-08-02 19:37:03 --> Config Class Initialized
INFO - 2018-08-02 19:37:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:37:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:37:03 --> Utf8 Class Initialized
INFO - 2018-08-02 19:37:03 --> URI Class Initialized
INFO - 2018-08-02 19:37:03 --> Router Class Initialized
INFO - 2018-08-02 19:37:03 --> Output Class Initialized
INFO - 2018-08-02 19:37:03 --> Security Class Initialized
DEBUG - 2018-08-02 19:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:37:03 --> CSRF cookie sent
INFO - 2018-08-02 19:37:03 --> Input Class Initialized
INFO - 2018-08-02 19:37:03 --> Language Class Initialized
INFO - 2018-08-02 19:37:03 --> Loader Class Initialized
INFO - 2018-08-02 19:37:03 --> Helper loaded: url_helper
INFO - 2018-08-02 19:37:03 --> Helper loaded: form_helper
INFO - 2018-08-02 19:37:03 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:37:03 --> User Agent Class Initialized
INFO - 2018-08-02 19:37:03 --> Controller Class Initialized
INFO - 2018-08-02 19:37:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:37:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-08-02 19:37:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:37:03 --> Final output sent to browser
DEBUG - 2018-08-02 19:37:03 --> Total execution time: 0.0229
INFO - 2018-08-02 19:37:07 --> Config Class Initialized
INFO - 2018-08-02 19:37:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:37:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:37:07 --> Utf8 Class Initialized
INFO - 2018-08-02 19:37:07 --> URI Class Initialized
INFO - 2018-08-02 19:37:07 --> Router Class Initialized
INFO - 2018-08-02 19:37:07 --> Output Class Initialized
INFO - 2018-08-02 19:37:07 --> Security Class Initialized
DEBUG - 2018-08-02 19:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:37:07 --> CSRF cookie sent
INFO - 2018-08-02 19:37:07 --> Input Class Initialized
INFO - 2018-08-02 19:37:07 --> Language Class Initialized
INFO - 2018-08-02 19:37:07 --> Loader Class Initialized
INFO - 2018-08-02 19:37:07 --> Helper loaded: url_helper
INFO - 2018-08-02 19:37:07 --> Helper loaded: form_helper
INFO - 2018-08-02 19:37:07 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:37:07 --> User Agent Class Initialized
INFO - 2018-08-02 19:37:07 --> Controller Class Initialized
INFO - 2018-08-02 19:37:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:37:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-02 19:37:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:37:07 --> Final output sent to browser
DEBUG - 2018-08-02 19:37:07 --> Total execution time: 0.0220
INFO - 2018-08-02 19:37:26 --> Config Class Initialized
INFO - 2018-08-02 19:37:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:37:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:37:26 --> Utf8 Class Initialized
INFO - 2018-08-02 19:37:26 --> URI Class Initialized
INFO - 2018-08-02 19:37:26 --> Router Class Initialized
INFO - 2018-08-02 19:37:26 --> Output Class Initialized
INFO - 2018-08-02 19:37:26 --> Security Class Initialized
DEBUG - 2018-08-02 19:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:37:26 --> CSRF cookie sent
INFO - 2018-08-02 19:37:26 --> Input Class Initialized
INFO - 2018-08-02 19:37:26 --> Language Class Initialized
INFO - 2018-08-02 19:37:26 --> Loader Class Initialized
INFO - 2018-08-02 19:37:26 --> Helper loaded: url_helper
INFO - 2018-08-02 19:37:26 --> Helper loaded: form_helper
INFO - 2018-08-02 19:37:26 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:37:26 --> User Agent Class Initialized
INFO - 2018-08-02 19:37:26 --> Controller Class Initialized
INFO - 2018-08-02 19:37:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:37:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-08-02 19:37:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:37:26 --> Final output sent to browser
DEBUG - 2018-08-02 19:37:26 --> Total execution time: 0.0331
INFO - 2018-08-02 19:42:24 --> Config Class Initialized
INFO - 2018-08-02 19:42:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:42:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:42:24 --> Utf8 Class Initialized
INFO - 2018-08-02 19:42:24 --> URI Class Initialized
INFO - 2018-08-02 19:42:24 --> Router Class Initialized
INFO - 2018-08-02 19:42:24 --> Output Class Initialized
INFO - 2018-08-02 19:42:24 --> Security Class Initialized
DEBUG - 2018-08-02 19:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:42:24 --> CSRF cookie sent
INFO - 2018-08-02 19:42:24 --> Input Class Initialized
INFO - 2018-08-02 19:42:24 --> Language Class Initialized
INFO - 2018-08-02 19:42:24 --> Loader Class Initialized
INFO - 2018-08-02 19:42:24 --> Helper loaded: url_helper
INFO - 2018-08-02 19:42:24 --> Helper loaded: form_helper
INFO - 2018-08-02 19:42:24 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:42:24 --> User Agent Class Initialized
INFO - 2018-08-02 19:42:24 --> Controller Class Initialized
INFO - 2018-08-02 19:42:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:42:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:42:24 --> Pixel_Model class loaded
INFO - 2018-08-02 19:42:24 --> Database Driver Class Initialized
INFO - 2018-08-02 19:42:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-02 19:42:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:42:24 --> Final output sent to browser
DEBUG - 2018-08-02 19:42:24 --> Total execution time: 0.0464
INFO - 2018-08-02 19:43:21 --> Config Class Initialized
INFO - 2018-08-02 19:43:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:43:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:43:21 --> Utf8 Class Initialized
INFO - 2018-08-02 19:43:21 --> URI Class Initialized
INFO - 2018-08-02 19:43:21 --> Router Class Initialized
INFO - 2018-08-02 19:43:21 --> Output Class Initialized
INFO - 2018-08-02 19:43:21 --> Security Class Initialized
DEBUG - 2018-08-02 19:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:43:21 --> CSRF cookie sent
INFO - 2018-08-02 19:43:21 --> CSRF token verified
INFO - 2018-08-02 19:43:21 --> Input Class Initialized
INFO - 2018-08-02 19:43:21 --> Language Class Initialized
INFO - 2018-08-02 19:43:21 --> Loader Class Initialized
INFO - 2018-08-02 19:43:21 --> Helper loaded: url_helper
INFO - 2018-08-02 19:43:21 --> Helper loaded: form_helper
INFO - 2018-08-02 19:43:21 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:43:21 --> User Agent Class Initialized
INFO - 2018-08-02 19:43:21 --> Controller Class Initialized
INFO - 2018-08-02 19:43:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:43:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:43:21 --> Pixel_Model class loaded
INFO - 2018-08-02 19:43:21 --> Database Driver Class Initialized
INFO - 2018-08-02 19:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:43:21 --> Database Driver Class Initialized
INFO - 2018-08-02 19:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:43:21 --> Config Class Initialized
INFO - 2018-08-02 19:43:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:43:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:43:21 --> Utf8 Class Initialized
INFO - 2018-08-02 19:43:21 --> URI Class Initialized
INFO - 2018-08-02 19:43:21 --> Router Class Initialized
INFO - 2018-08-02 19:43:21 --> Output Class Initialized
INFO - 2018-08-02 19:43:21 --> Security Class Initialized
DEBUG - 2018-08-02 19:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:43:21 --> CSRF cookie sent
INFO - 2018-08-02 19:43:21 --> Input Class Initialized
INFO - 2018-08-02 19:43:21 --> Language Class Initialized
INFO - 2018-08-02 19:43:21 --> Loader Class Initialized
INFO - 2018-08-02 19:43:21 --> Helper loaded: url_helper
INFO - 2018-08-02 19:43:21 --> Helper loaded: form_helper
INFO - 2018-08-02 19:43:21 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:43:21 --> User Agent Class Initialized
INFO - 2018-08-02 19:43:21 --> Controller Class Initialized
INFO - 2018-08-02 19:43:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:43:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:43:21 --> Pixel_Model class loaded
INFO - 2018-08-02 19:43:21 --> Database Driver Class Initialized
INFO - 2018-08-02 19:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:43:21 --> Database Driver Class Initialized
INFO - 2018-08-02 19:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 19:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:43:21 --> Final output sent to browser
DEBUG - 2018-08-02 19:43:21 --> Total execution time: 0.0461
INFO - 2018-08-02 19:44:01 --> Config Class Initialized
INFO - 2018-08-02 19:44:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:01 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:01 --> URI Class Initialized
INFO - 2018-08-02 19:44:01 --> Router Class Initialized
INFO - 2018-08-02 19:44:01 --> Output Class Initialized
INFO - 2018-08-02 19:44:01 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:01 --> CSRF cookie sent
INFO - 2018-08-02 19:44:01 --> CSRF token verified
INFO - 2018-08-02 19:44:01 --> Input Class Initialized
INFO - 2018-08-02 19:44:01 --> Language Class Initialized
INFO - 2018-08-02 19:44:01 --> Loader Class Initialized
INFO - 2018-08-02 19:44:01 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:01 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:01 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:01 --> Controller Class Initialized
INFO - 2018-08-02 19:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:01 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:01 --> Form Validation Class Initialized
INFO - 2018-08-02 19:44:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:44:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:01 --> Config Class Initialized
INFO - 2018-08-02 19:44:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:01 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:01 --> URI Class Initialized
INFO - 2018-08-02 19:44:01 --> Router Class Initialized
INFO - 2018-08-02 19:44:01 --> Output Class Initialized
INFO - 2018-08-02 19:44:01 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:01 --> CSRF cookie sent
INFO - 2018-08-02 19:44:01 --> Input Class Initialized
INFO - 2018-08-02 19:44:01 --> Language Class Initialized
INFO - 2018-08-02 19:44:01 --> Loader Class Initialized
INFO - 2018-08-02 19:44:01 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:01 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:01 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:01 --> Controller Class Initialized
INFO - 2018-08-02 19:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:01 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:44:01 --> Final output sent to browser
DEBUG - 2018-08-02 19:44:01 --> Total execution time: 0.0458
INFO - 2018-08-02 19:44:06 --> Config Class Initialized
INFO - 2018-08-02 19:44:06 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:06 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:06 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:06 --> URI Class Initialized
INFO - 2018-08-02 19:44:06 --> Router Class Initialized
INFO - 2018-08-02 19:44:06 --> Output Class Initialized
INFO - 2018-08-02 19:44:06 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:06 --> CSRF cookie sent
INFO - 2018-08-02 19:44:06 --> Input Class Initialized
INFO - 2018-08-02 19:44:06 --> Language Class Initialized
INFO - 2018-08-02 19:44:06 --> Loader Class Initialized
INFO - 2018-08-02 19:44:06 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:06 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:06 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:06 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:06 --> Controller Class Initialized
INFO - 2018-08-02 19:44:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:06 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:06 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:06 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 19:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:44:06 --> Final output sent to browser
DEBUG - 2018-08-02 19:44:06 --> Total execution time: 0.0544
INFO - 2018-08-02 19:44:22 --> Config Class Initialized
INFO - 2018-08-02 19:44:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:22 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:22 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:22 --> URI Class Initialized
DEBUG - 2018-08-02 19:44:22 --> No URI present. Default controller set.
INFO - 2018-08-02 19:44:22 --> Router Class Initialized
INFO - 2018-08-02 19:44:22 --> Output Class Initialized
INFO - 2018-08-02 19:44:22 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:22 --> CSRF cookie sent
INFO - 2018-08-02 19:44:22 --> Input Class Initialized
INFO - 2018-08-02 19:44:22 --> Language Class Initialized
INFO - 2018-08-02 19:44:22 --> Loader Class Initialized
INFO - 2018-08-02 19:44:22 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:22 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:22 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:22 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:22 --> Controller Class Initialized
INFO - 2018-08-02 19:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:22 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:22 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:44:22 --> Final output sent to browser
DEBUG - 2018-08-02 19:44:22 --> Total execution time: 0.0378
INFO - 2018-08-02 19:44:47 --> Config Class Initialized
INFO - 2018-08-02 19:44:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:47 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:47 --> URI Class Initialized
INFO - 2018-08-02 19:44:47 --> Router Class Initialized
INFO - 2018-08-02 19:44:47 --> Output Class Initialized
INFO - 2018-08-02 19:44:47 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:47 --> CSRF cookie sent
INFO - 2018-08-02 19:44:47 --> CSRF token verified
INFO - 2018-08-02 19:44:47 --> Input Class Initialized
INFO - 2018-08-02 19:44:47 --> Language Class Initialized
INFO - 2018-08-02 19:44:47 --> Loader Class Initialized
INFO - 2018-08-02 19:44:47 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:47 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:47 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:47 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:47 --> Controller Class Initialized
INFO - 2018-08-02 19:44:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:47 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:47 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:47 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:48 --> Config Class Initialized
INFO - 2018-08-02 19:44:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:44:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:44:48 --> Utf8 Class Initialized
INFO - 2018-08-02 19:44:48 --> URI Class Initialized
INFO - 2018-08-02 19:44:48 --> Router Class Initialized
INFO - 2018-08-02 19:44:48 --> Output Class Initialized
INFO - 2018-08-02 19:44:48 --> Security Class Initialized
DEBUG - 2018-08-02 19:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:44:48 --> CSRF cookie sent
INFO - 2018-08-02 19:44:48 --> Input Class Initialized
INFO - 2018-08-02 19:44:48 --> Language Class Initialized
INFO - 2018-08-02 19:44:48 --> Loader Class Initialized
INFO - 2018-08-02 19:44:48 --> Helper loaded: url_helper
INFO - 2018-08-02 19:44:48 --> Helper loaded: form_helper
INFO - 2018-08-02 19:44:48 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:44:48 --> User Agent Class Initialized
INFO - 2018-08-02 19:44:48 --> Controller Class Initialized
INFO - 2018-08-02 19:44:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:44:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:44:48 --> Pixel_Model class loaded
INFO - 2018-08-02 19:44:48 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:48 --> Database Driver Class Initialized
INFO - 2018-08-02 19:44:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 19:44:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:44:48 --> Final output sent to browser
DEBUG - 2018-08-02 19:44:48 --> Total execution time: 0.0404
INFO - 2018-08-02 19:45:01 --> Config Class Initialized
INFO - 2018-08-02 19:45:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:01 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:01 --> URI Class Initialized
INFO - 2018-08-02 19:45:01 --> Router Class Initialized
INFO - 2018-08-02 19:45:01 --> Output Class Initialized
INFO - 2018-08-02 19:45:01 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:01 --> CSRF cookie sent
INFO - 2018-08-02 19:45:01 --> CSRF token verified
INFO - 2018-08-02 19:45:01 --> Input Class Initialized
INFO - 2018-08-02 19:45:01 --> Language Class Initialized
INFO - 2018-08-02 19:45:01 --> Loader Class Initialized
INFO - 2018-08-02 19:45:01 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:01 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:01 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:01 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:01 --> Controller Class Initialized
INFO - 2018-08-02 19:45:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:01 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:01 --> Form Validation Class Initialized
INFO - 2018-08-02 19:45:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:45:01 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:02 --> Config Class Initialized
INFO - 2018-08-02 19:45:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:03 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:03 --> URI Class Initialized
INFO - 2018-08-02 19:45:03 --> Router Class Initialized
INFO - 2018-08-02 19:45:03 --> Output Class Initialized
INFO - 2018-08-02 19:45:03 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:03 --> CSRF cookie sent
INFO - 2018-08-02 19:45:03 --> Input Class Initialized
INFO - 2018-08-02 19:45:03 --> Language Class Initialized
INFO - 2018-08-02 19:45:03 --> Loader Class Initialized
INFO - 2018-08-02 19:45:03 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:03 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:03 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:03 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:03 --> Controller Class Initialized
INFO - 2018-08-02 19:45:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:03 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:03 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:03 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:45:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:45:03 --> Final output sent to browser
DEBUG - 2018-08-02 19:45:03 --> Total execution time: 0.2279
INFO - 2018-08-02 19:45:07 --> Config Class Initialized
INFO - 2018-08-02 19:45:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:07 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:07 --> URI Class Initialized
DEBUG - 2018-08-02 19:45:07 --> No URI present. Default controller set.
INFO - 2018-08-02 19:45:07 --> Router Class Initialized
INFO - 2018-08-02 19:45:07 --> Output Class Initialized
INFO - 2018-08-02 19:45:07 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:07 --> CSRF cookie sent
INFO - 2018-08-02 19:45:07 --> Input Class Initialized
INFO - 2018-08-02 19:45:07 --> Language Class Initialized
INFO - 2018-08-02 19:45:07 --> Loader Class Initialized
INFO - 2018-08-02 19:45:07 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:07 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:07 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:07 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:07 --> Controller Class Initialized
INFO - 2018-08-02 19:45:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:07 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:07 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:45:07 --> Final output sent to browser
DEBUG - 2018-08-02 19:45:07 --> Total execution time: 0.0334
INFO - 2018-08-02 19:45:39 --> Config Class Initialized
INFO - 2018-08-02 19:45:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:39 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:39 --> URI Class Initialized
INFO - 2018-08-02 19:45:39 --> Router Class Initialized
INFO - 2018-08-02 19:45:39 --> Output Class Initialized
INFO - 2018-08-02 19:45:39 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:39 --> CSRF cookie sent
INFO - 2018-08-02 19:45:39 --> CSRF token verified
INFO - 2018-08-02 19:45:39 --> Input Class Initialized
INFO - 2018-08-02 19:45:39 --> Language Class Initialized
INFO - 2018-08-02 19:45:39 --> Loader Class Initialized
INFO - 2018-08-02 19:45:39 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:39 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:39 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:39 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:39 --> Controller Class Initialized
INFO - 2018-08-02 19:45:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:39 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:39 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:39 --> Form Validation Class Initialized
INFO - 2018-08-02 19:45:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:45:39 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:40 --> Config Class Initialized
INFO - 2018-08-02 19:45:40 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:40 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:40 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:40 --> URI Class Initialized
INFO - 2018-08-02 19:45:40 --> Router Class Initialized
INFO - 2018-08-02 19:45:40 --> Output Class Initialized
INFO - 2018-08-02 19:45:40 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:40 --> CSRF cookie sent
INFO - 2018-08-02 19:45:40 --> Input Class Initialized
INFO - 2018-08-02 19:45:40 --> Language Class Initialized
INFO - 2018-08-02 19:45:40 --> Loader Class Initialized
INFO - 2018-08-02 19:45:40 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:40 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:40 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:40 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:40 --> Controller Class Initialized
INFO - 2018-08-02 19:45:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:40 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:40 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:40 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-02 19:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:45:40 --> Final output sent to browser
DEBUG - 2018-08-02 19:45:40 --> Total execution time: 0.0381
INFO - 2018-08-02 19:45:48 --> Config Class Initialized
INFO - 2018-08-02 19:45:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:48 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:48 --> URI Class Initialized
INFO - 2018-08-02 19:45:48 --> Router Class Initialized
INFO - 2018-08-02 19:45:48 --> Output Class Initialized
INFO - 2018-08-02 19:45:48 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:48 --> CSRF cookie sent
INFO - 2018-08-02 19:45:48 --> CSRF token verified
INFO - 2018-08-02 19:45:48 --> Input Class Initialized
INFO - 2018-08-02 19:45:48 --> Language Class Initialized
INFO - 2018-08-02 19:45:48 --> Loader Class Initialized
INFO - 2018-08-02 19:45:48 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:48 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:48 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:48 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:48 --> Controller Class Initialized
INFO - 2018-08-02 19:45:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:48 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:48 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:48 --> Form Validation Class Initialized
INFO - 2018-08-02 19:45:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:45:48 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:49 --> Config Class Initialized
INFO - 2018-08-02 19:45:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:45:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:45:49 --> Utf8 Class Initialized
INFO - 2018-08-02 19:45:49 --> URI Class Initialized
INFO - 2018-08-02 19:45:49 --> Router Class Initialized
INFO - 2018-08-02 19:45:49 --> Output Class Initialized
INFO - 2018-08-02 19:45:49 --> Security Class Initialized
DEBUG - 2018-08-02 19:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:45:49 --> CSRF cookie sent
INFO - 2018-08-02 19:45:49 --> Input Class Initialized
INFO - 2018-08-02 19:45:49 --> Language Class Initialized
INFO - 2018-08-02 19:45:49 --> Loader Class Initialized
INFO - 2018-08-02 19:45:49 --> Helper loaded: url_helper
INFO - 2018-08-02 19:45:49 --> Helper loaded: form_helper
INFO - 2018-08-02 19:45:49 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:45:49 --> User Agent Class Initialized
INFO - 2018-08-02 19:45:49 --> Controller Class Initialized
INFO - 2018-08-02 19:45:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:45:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:45:49 --> Pixel_Model class loaded
INFO - 2018-08-02 19:45:49 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:49 --> Database Driver Class Initialized
INFO - 2018-08-02 19:45:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-02 19:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:45:49 --> Final output sent to browser
DEBUG - 2018-08-02 19:45:49 --> Total execution time: 0.0325
INFO - 2018-08-02 19:46:10 --> Config Class Initialized
INFO - 2018-08-02 19:46:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:46:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:46:10 --> Utf8 Class Initialized
INFO - 2018-08-02 19:46:10 --> URI Class Initialized
INFO - 2018-08-02 19:46:10 --> Router Class Initialized
INFO - 2018-08-02 19:46:10 --> Output Class Initialized
INFO - 2018-08-02 19:46:10 --> Security Class Initialized
DEBUG - 2018-08-02 19:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:46:10 --> CSRF cookie sent
INFO - 2018-08-02 19:46:10 --> CSRF token verified
INFO - 2018-08-02 19:46:10 --> Input Class Initialized
INFO - 2018-08-02 19:46:10 --> Language Class Initialized
INFO - 2018-08-02 19:46:10 --> Loader Class Initialized
INFO - 2018-08-02 19:46:10 --> Helper loaded: url_helper
INFO - 2018-08-02 19:46:10 --> Helper loaded: form_helper
INFO - 2018-08-02 19:46:10 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:46:10 --> User Agent Class Initialized
INFO - 2018-08-02 19:46:10 --> Controller Class Initialized
INFO - 2018-08-02 19:46:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:46:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:46:10 --> Pixel_Model class loaded
INFO - 2018-08-02 19:46:10 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:10 --> Form Validation Class Initialized
INFO - 2018-08-02 19:46:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:46:10 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:11 --> Config Class Initialized
INFO - 2018-08-02 19:46:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:46:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:46:11 --> Utf8 Class Initialized
INFO - 2018-08-02 19:46:11 --> URI Class Initialized
INFO - 2018-08-02 19:46:11 --> Router Class Initialized
INFO - 2018-08-02 19:46:11 --> Output Class Initialized
INFO - 2018-08-02 19:46:11 --> Security Class Initialized
DEBUG - 2018-08-02 19:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:46:11 --> CSRF cookie sent
INFO - 2018-08-02 19:46:11 --> Input Class Initialized
INFO - 2018-08-02 19:46:11 --> Language Class Initialized
INFO - 2018-08-02 19:46:11 --> Loader Class Initialized
INFO - 2018-08-02 19:46:11 --> Helper loaded: url_helper
INFO - 2018-08-02 19:46:11 --> Helper loaded: form_helper
INFO - 2018-08-02 19:46:11 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:46:11 --> User Agent Class Initialized
INFO - 2018-08-02 19:46:11 --> Controller Class Initialized
INFO - 2018-08-02 19:46:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:46:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:46:11 --> Pixel_Model class loaded
INFO - 2018-08-02 19:46:11 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-02 19:46:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:46:11 --> Final output sent to browser
DEBUG - 2018-08-02 19:46:11 --> Total execution time: 0.0281
INFO - 2018-08-02 19:46:18 --> Config Class Initialized
INFO - 2018-08-02 19:46:18 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:46:18 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:46:18 --> Utf8 Class Initialized
INFO - 2018-08-02 19:46:18 --> URI Class Initialized
INFO - 2018-08-02 19:46:18 --> Router Class Initialized
INFO - 2018-08-02 19:46:18 --> Output Class Initialized
INFO - 2018-08-02 19:46:18 --> Security Class Initialized
DEBUG - 2018-08-02 19:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:46:18 --> CSRF cookie sent
INFO - 2018-08-02 19:46:18 --> CSRF token verified
INFO - 2018-08-02 19:46:18 --> Input Class Initialized
INFO - 2018-08-02 19:46:18 --> Language Class Initialized
INFO - 2018-08-02 19:46:18 --> Loader Class Initialized
INFO - 2018-08-02 19:46:18 --> Helper loaded: url_helper
INFO - 2018-08-02 19:46:18 --> Helper loaded: form_helper
INFO - 2018-08-02 19:46:18 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:46:18 --> User Agent Class Initialized
INFO - 2018-08-02 19:46:18 --> Controller Class Initialized
INFO - 2018-08-02 19:46:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:46:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:46:18 --> Pixel_Model class loaded
INFO - 2018-08-02 19:46:18 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:18 --> Form Validation Class Initialized
INFO - 2018-08-02 19:46:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-02 19:46:18 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:19 --> Config Class Initialized
INFO - 2018-08-02 19:46:19 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:46:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:46:19 --> Utf8 Class Initialized
INFO - 2018-08-02 19:46:19 --> URI Class Initialized
INFO - 2018-08-02 19:46:19 --> Router Class Initialized
INFO - 2018-08-02 19:46:19 --> Output Class Initialized
INFO - 2018-08-02 19:46:19 --> Security Class Initialized
DEBUG - 2018-08-02 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:46:19 --> CSRF cookie sent
INFO - 2018-08-02 19:46:19 --> Input Class Initialized
INFO - 2018-08-02 19:46:19 --> Language Class Initialized
INFO - 2018-08-02 19:46:19 --> Loader Class Initialized
INFO - 2018-08-02 19:46:19 --> Helper loaded: url_helper
INFO - 2018-08-02 19:46:19 --> Helper loaded: form_helper
INFO - 2018-08-02 19:46:19 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:46:19 --> User Agent Class Initialized
INFO - 2018-08-02 19:46:19 --> Controller Class Initialized
INFO - 2018-08-02 19:46:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:46:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:46:19 --> Pixel_Model class loaded
INFO - 2018-08-02 19:46:19 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:19 --> Database Driver Class Initialized
INFO - 2018-08-02 19:46:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-02 19:46:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:46:19 --> Final output sent to browser
DEBUG - 2018-08-02 19:46:19 --> Total execution time: 0.0451
INFO - 2018-08-02 19:47:11 --> Config Class Initialized
INFO - 2018-08-02 19:47:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:47:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:47:11 --> Utf8 Class Initialized
INFO - 2018-08-02 19:47:11 --> URI Class Initialized
INFO - 2018-08-02 19:47:11 --> Router Class Initialized
INFO - 2018-08-02 19:47:11 --> Output Class Initialized
INFO - 2018-08-02 19:47:11 --> Security Class Initialized
DEBUG - 2018-08-02 19:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:47:11 --> CSRF cookie sent
INFO - 2018-08-02 19:47:11 --> Input Class Initialized
INFO - 2018-08-02 19:47:11 --> Language Class Initialized
INFO - 2018-08-02 19:47:11 --> Loader Class Initialized
INFO - 2018-08-02 19:47:11 --> Helper loaded: url_helper
INFO - 2018-08-02 19:47:11 --> Helper loaded: form_helper
INFO - 2018-08-02 19:47:11 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:47:11 --> User Agent Class Initialized
INFO - 2018-08-02 19:47:11 --> Controller Class Initialized
INFO - 2018-08-02 19:47:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:47:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-08-02 19:47:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:47:11 --> Final output sent to browser
DEBUG - 2018-08-02 19:47:11 --> Total execution time: 0.0353
INFO - 2018-08-02 19:47:17 --> Config Class Initialized
INFO - 2018-08-02 19:47:17 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:47:17 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:47:17 --> Utf8 Class Initialized
INFO - 2018-08-02 19:47:17 --> URI Class Initialized
INFO - 2018-08-02 19:47:17 --> Router Class Initialized
INFO - 2018-08-02 19:47:17 --> Output Class Initialized
INFO - 2018-08-02 19:47:17 --> Security Class Initialized
DEBUG - 2018-08-02 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:47:17 --> CSRF cookie sent
INFO - 2018-08-02 19:47:17 --> Input Class Initialized
INFO - 2018-08-02 19:47:17 --> Language Class Initialized
INFO - 2018-08-02 19:47:17 --> Loader Class Initialized
INFO - 2018-08-02 19:47:17 --> Helper loaded: url_helper
INFO - 2018-08-02 19:47:17 --> Helper loaded: form_helper
INFO - 2018-08-02 19:47:17 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:47:17 --> User Agent Class Initialized
INFO - 2018-08-02 19:47:17 --> Controller Class Initialized
INFO - 2018-08-02 19:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-08-02 19:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:47:17 --> Final output sent to browser
DEBUG - 2018-08-02 19:47:17 --> Total execution time: 0.0508
INFO - 2018-08-02 19:48:57 --> Config Class Initialized
INFO - 2018-08-02 19:48:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:48:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:48:57 --> Utf8 Class Initialized
INFO - 2018-08-02 19:48:57 --> URI Class Initialized
INFO - 2018-08-02 19:48:57 --> Router Class Initialized
INFO - 2018-08-02 19:48:57 --> Output Class Initialized
INFO - 2018-08-02 19:48:57 --> Security Class Initialized
DEBUG - 2018-08-02 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:48:57 --> CSRF cookie sent
INFO - 2018-08-02 19:48:57 --> CSRF token verified
INFO - 2018-08-02 19:48:57 --> Input Class Initialized
INFO - 2018-08-02 19:48:57 --> Language Class Initialized
INFO - 2018-08-02 19:48:57 --> Loader Class Initialized
INFO - 2018-08-02 19:48:57 --> Helper loaded: url_helper
INFO - 2018-08-02 19:48:57 --> Helper loaded: form_helper
INFO - 2018-08-02 19:48:57 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:48:57 --> User Agent Class Initialized
INFO - 2018-08-02 19:48:57 --> Controller Class Initialized
INFO - 2018-08-02 19:48:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:48:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:48:57 --> Pixel_Model class loaded
INFO - 2018-08-02 19:48:57 --> Database Driver Class Initialized
INFO - 2018-08-02 19:48:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:48:57 --> Database Driver Class Initialized
INFO - 2018-08-02 19:48:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:48:57 --> Config Class Initialized
INFO - 2018-08-02 19:48:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:48:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:48:57 --> Utf8 Class Initialized
INFO - 2018-08-02 19:48:57 --> URI Class Initialized
INFO - 2018-08-02 19:48:57 --> Router Class Initialized
INFO - 2018-08-02 19:48:57 --> Output Class Initialized
INFO - 2018-08-02 19:48:57 --> Security Class Initialized
DEBUG - 2018-08-02 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:48:57 --> CSRF cookie sent
INFO - 2018-08-02 19:48:57 --> Input Class Initialized
INFO - 2018-08-02 19:48:57 --> Language Class Initialized
INFO - 2018-08-02 19:48:57 --> Loader Class Initialized
INFO - 2018-08-02 19:48:57 --> Helper loaded: url_helper
INFO - 2018-08-02 19:48:57 --> Helper loaded: form_helper
INFO - 2018-08-02 19:48:57 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:48:57 --> User Agent Class Initialized
INFO - 2018-08-02 19:48:57 --> Controller Class Initialized
INFO - 2018-08-02 19:48:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:48:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:48:57 --> Pixel_Model class loaded
INFO - 2018-08-02 19:48:57 --> Database Driver Class Initialized
INFO - 2018-08-02 19:48:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:48:57 --> Database Driver Class Initialized
INFO - 2018-08-02 19:48:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:48:57 --> Final output sent to browser
DEBUG - 2018-08-02 19:48:57 --> Total execution time: 0.0451
INFO - 2018-08-02 19:50:21 --> Config Class Initialized
INFO - 2018-08-02 19:50:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:21 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:21 --> URI Class Initialized
DEBUG - 2018-08-02 19:50:21 --> No URI present. Default controller set.
INFO - 2018-08-02 19:50:21 --> Router Class Initialized
INFO - 2018-08-02 19:50:21 --> Output Class Initialized
INFO - 2018-08-02 19:50:21 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:21 --> CSRF cookie sent
INFO - 2018-08-02 19:50:21 --> Input Class Initialized
INFO - 2018-08-02 19:50:21 --> Language Class Initialized
INFO - 2018-08-02 19:50:21 --> Loader Class Initialized
INFO - 2018-08-02 19:50:21 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:21 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:21 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:21 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:21 --> Controller Class Initialized
INFO - 2018-08-02 19:50:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:21 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:21 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:50:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:21 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:21 --> Total execution time: 0.0485
INFO - 2018-08-02 19:50:28 --> Config Class Initialized
INFO - 2018-08-02 19:50:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:28 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:28 --> URI Class Initialized
INFO - 2018-08-02 19:50:28 --> Router Class Initialized
INFO - 2018-08-02 19:50:28 --> Output Class Initialized
INFO - 2018-08-02 19:50:28 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:28 --> CSRF cookie sent
INFO - 2018-08-02 19:50:28 --> Input Class Initialized
INFO - 2018-08-02 19:50:28 --> Language Class Initialized
INFO - 2018-08-02 19:50:28 --> Loader Class Initialized
INFO - 2018-08-02 19:50:28 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:28 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:28 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:28 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:28 --> Controller Class Initialized
INFO - 2018-08-02 19:50:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:28 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:28 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:29 --> Config Class Initialized
INFO - 2018-08-02 19:50:29 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:29 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:29 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:29 --> URI Class Initialized
INFO - 2018-08-02 19:50:29 --> Router Class Initialized
INFO - 2018-08-02 19:50:29 --> Output Class Initialized
INFO - 2018-08-02 19:50:29 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:29 --> CSRF cookie sent
INFO - 2018-08-02 19:50:29 --> Input Class Initialized
INFO - 2018-08-02 19:50:29 --> Language Class Initialized
INFO - 2018-08-02 19:50:29 --> Loader Class Initialized
INFO - 2018-08-02 19:50:29 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:29 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:29 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:29 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:29 --> Controller Class Initialized
INFO - 2018-08-02 19:50:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:29 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:29 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:29 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:50:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:29 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:29 --> Total execution time: 0.0431
INFO - 2018-08-02 19:50:33 --> Config Class Initialized
INFO - 2018-08-02 19:50:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:33 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:33 --> URI Class Initialized
DEBUG - 2018-08-02 19:50:33 --> No URI present. Default controller set.
INFO - 2018-08-02 19:50:33 --> Router Class Initialized
INFO - 2018-08-02 19:50:33 --> Output Class Initialized
INFO - 2018-08-02 19:50:33 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:33 --> CSRF cookie sent
INFO - 2018-08-02 19:50:33 --> Input Class Initialized
INFO - 2018-08-02 19:50:33 --> Language Class Initialized
INFO - 2018-08-02 19:50:33 --> Loader Class Initialized
INFO - 2018-08-02 19:50:33 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:33 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:33 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:33 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:33 --> Controller Class Initialized
INFO - 2018-08-02 19:50:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:33 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:34 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-02 19:50:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:34 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:34 --> Total execution time: 0.0324
INFO - 2018-08-02 19:50:36 --> Config Class Initialized
INFO - 2018-08-02 19:50:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:36 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:36 --> URI Class Initialized
INFO - 2018-08-02 19:50:36 --> Router Class Initialized
INFO - 2018-08-02 19:50:36 --> Output Class Initialized
INFO - 2018-08-02 19:50:36 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:36 --> CSRF cookie sent
INFO - 2018-08-02 19:50:36 --> Input Class Initialized
INFO - 2018-08-02 19:50:36 --> Language Class Initialized
INFO - 2018-08-02 19:50:36 --> Loader Class Initialized
INFO - 2018-08-02 19:50:36 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:36 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:36 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:36 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:36 --> Controller Class Initialized
INFO - 2018-08-02 19:50:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:36 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:36 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:36 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-02 19:50:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:36 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:36 --> Total execution time: 0.0460
INFO - 2018-08-02 19:50:38 --> Config Class Initialized
INFO - 2018-08-02 19:50:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:38 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:38 --> URI Class Initialized
INFO - 2018-08-02 19:50:38 --> Router Class Initialized
INFO - 2018-08-02 19:50:38 --> Output Class Initialized
INFO - 2018-08-02 19:50:38 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:38 --> CSRF cookie sent
INFO - 2018-08-02 19:50:38 --> Input Class Initialized
INFO - 2018-08-02 19:50:38 --> Language Class Initialized
INFO - 2018-08-02 19:50:38 --> Loader Class Initialized
INFO - 2018-08-02 19:50:38 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:38 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:38 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:38 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:38 --> Controller Class Initialized
INFO - 2018-08-02 19:50:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:38 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:38 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:38 --> Config Class Initialized
INFO - 2018-08-02 19:50:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:38 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:38 --> URI Class Initialized
INFO - 2018-08-02 19:50:38 --> Router Class Initialized
INFO - 2018-08-02 19:50:38 --> Output Class Initialized
INFO - 2018-08-02 19:50:38 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:38 --> CSRF cookie sent
INFO - 2018-08-02 19:50:38 --> Input Class Initialized
INFO - 2018-08-02 19:50:38 --> Language Class Initialized
INFO - 2018-08-02 19:50:38 --> Loader Class Initialized
INFO - 2018-08-02 19:50:38 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:38 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:38 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:38 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:38 --> Controller Class Initialized
INFO - 2018-08-02 19:50:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:38 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:38 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:38 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:38 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:38 --> Total execution time: 0.0439
INFO - 2018-08-02 19:50:40 --> Config Class Initialized
INFO - 2018-08-02 19:50:40 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:40 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:40 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:40 --> URI Class Initialized
INFO - 2018-08-02 19:50:40 --> Router Class Initialized
INFO - 2018-08-02 19:50:40 --> Output Class Initialized
INFO - 2018-08-02 19:50:40 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:40 --> CSRF cookie sent
INFO - 2018-08-02 19:50:40 --> Input Class Initialized
INFO - 2018-08-02 19:50:40 --> Language Class Initialized
INFO - 2018-08-02 19:50:40 --> Loader Class Initialized
INFO - 2018-08-02 19:50:40 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:40 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:40 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:40 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:40 --> Controller Class Initialized
INFO - 2018-08-02 19:50:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-02 19:50:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-02 19:50:40 --> Could not find the language line "req_email"
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-02 19:50:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:40 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:40 --> Total execution time: 0.0329
INFO - 2018-08-02 19:50:42 --> Config Class Initialized
INFO - 2018-08-02 19:50:42 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:42 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:42 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:42 --> URI Class Initialized
INFO - 2018-08-02 19:50:42 --> Router Class Initialized
INFO - 2018-08-02 19:50:42 --> Output Class Initialized
INFO - 2018-08-02 19:50:42 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:42 --> CSRF cookie sent
INFO - 2018-08-02 19:50:42 --> Input Class Initialized
INFO - 2018-08-02 19:50:42 --> Language Class Initialized
INFO - 2018-08-02 19:50:42 --> Loader Class Initialized
INFO - 2018-08-02 19:50:42 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:42 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:42 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:42 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:42 --> Controller Class Initialized
INFO - 2018-08-02 19:50:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-08-02 19:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:42 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:42 --> Total execution time: 0.0225
INFO - 2018-08-02 19:50:47 --> Config Class Initialized
INFO - 2018-08-02 19:50:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:47 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:47 --> URI Class Initialized
INFO - 2018-08-02 19:50:47 --> Router Class Initialized
INFO - 2018-08-02 19:50:47 --> Output Class Initialized
INFO - 2018-08-02 19:50:47 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:47 --> CSRF cookie sent
INFO - 2018-08-02 19:50:47 --> Input Class Initialized
INFO - 2018-08-02 19:50:47 --> Language Class Initialized
INFO - 2018-08-02 19:50:47 --> Loader Class Initialized
INFO - 2018-08-02 19:50:47 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:47 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:47 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:47 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:47 --> Controller Class Initialized
INFO - 2018-08-02 19:50:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-02 19:50:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-02 19:50:47 --> Could not find the language line "req_email"
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-02 19:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:47 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:47 --> Total execution time: 0.0228
INFO - 2018-08-02 19:50:49 --> Config Class Initialized
INFO - 2018-08-02 19:50:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 19:50:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 19:50:49 --> Utf8 Class Initialized
INFO - 2018-08-02 19:50:49 --> URI Class Initialized
INFO - 2018-08-02 19:50:49 --> Router Class Initialized
INFO - 2018-08-02 19:50:49 --> Output Class Initialized
INFO - 2018-08-02 19:50:49 --> Security Class Initialized
DEBUG - 2018-08-02 19:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 19:50:49 --> CSRF cookie sent
INFO - 2018-08-02 19:50:49 --> Input Class Initialized
INFO - 2018-08-02 19:50:49 --> Language Class Initialized
INFO - 2018-08-02 19:50:49 --> Loader Class Initialized
INFO - 2018-08-02 19:50:49 --> Helper loaded: url_helper
INFO - 2018-08-02 19:50:49 --> Helper loaded: form_helper
INFO - 2018-08-02 19:50:49 --> Helper loaded: language_helper
DEBUG - 2018-08-02 19:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 19:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 19:50:49 --> User Agent Class Initialized
INFO - 2018-08-02 19:50:49 --> Controller Class Initialized
INFO - 2018-08-02 19:50:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-02 19:50:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-02 19:50:49 --> Pixel_Model class loaded
INFO - 2018-08-02 19:50:49 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:49 --> Database Driver Class Initialized
INFO - 2018-08-02 19:50:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-02 19:50:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-02 19:50:49 --> Final output sent to browser
DEBUG - 2018-08-02 19:50:49 --> Total execution time: 0.0467

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-15 14:58:42 --> Config Class Initialized
INFO - 2018-08-15 14:58:42 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:58:42 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:58:42 --> Utf8 Class Initialized
INFO - 2018-08-15 14:58:42 --> URI Class Initialized
DEBUG - 2018-08-15 14:58:42 --> No URI present. Default controller set.
INFO - 2018-08-15 14:58:42 --> Router Class Initialized
INFO - 2018-08-15 14:58:42 --> Output Class Initialized
INFO - 2018-08-15 14:58:42 --> Security Class Initialized
DEBUG - 2018-08-15 14:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:58:42 --> CSRF cookie sent
INFO - 2018-08-15 14:58:42 --> Input Class Initialized
INFO - 2018-08-15 14:58:42 --> Language Class Initialized
INFO - 2018-08-15 14:58:42 --> Loader Class Initialized
INFO - 2018-08-15 14:58:42 --> Helper loaded: url_helper
INFO - 2018-08-15 14:58:42 --> Helper loaded: form_helper
INFO - 2018-08-15 14:58:42 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:58:42 --> User Agent Class Initialized
INFO - 2018-08-15 14:58:42 --> Controller Class Initialized
INFO - 2018-08-15 14:58:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:58:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:58:42 --> Pixel_Model class loaded
INFO - 2018-08-15 14:58:42 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 14:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:58:42 --> Final output sent to browser
DEBUG - 2018-08-15 14:58:42 --> Total execution time: 0.0390
INFO - 2018-08-15 14:58:44 --> Config Class Initialized
INFO - 2018-08-15 14:58:44 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:58:44 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:58:44 --> Utf8 Class Initialized
INFO - 2018-08-15 14:58:44 --> URI Class Initialized
DEBUG - 2018-08-15 14:58:44 --> No URI present. Default controller set.
INFO - 2018-08-15 14:58:44 --> Router Class Initialized
INFO - 2018-08-15 14:58:44 --> Output Class Initialized
INFO - 2018-08-15 14:58:44 --> Security Class Initialized
DEBUG - 2018-08-15 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:58:44 --> CSRF cookie sent
INFO - 2018-08-15 14:58:44 --> Input Class Initialized
INFO - 2018-08-15 14:58:44 --> Language Class Initialized
INFO - 2018-08-15 14:58:44 --> Loader Class Initialized
INFO - 2018-08-15 14:58:44 --> Helper loaded: url_helper
INFO - 2018-08-15 14:58:44 --> Helper loaded: form_helper
INFO - 2018-08-15 14:58:44 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:58:44 --> User Agent Class Initialized
INFO - 2018-08-15 14:58:44 --> Controller Class Initialized
INFO - 2018-08-15 14:58:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:58:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:58:44 --> Pixel_Model class loaded
INFO - 2018-08-15 14:58:44 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 14:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:58:44 --> Final output sent to browser
DEBUG - 2018-08-15 14:58:44 --> Total execution time: 0.0387
INFO - 2018-08-15 14:58:51 --> Config Class Initialized
INFO - 2018-08-15 14:58:51 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:58:51 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:58:51 --> Utf8 Class Initialized
INFO - 2018-08-15 14:58:51 --> URI Class Initialized
INFO - 2018-08-15 14:58:51 --> Router Class Initialized
INFO - 2018-08-15 14:58:51 --> Output Class Initialized
INFO - 2018-08-15 14:58:51 --> Security Class Initialized
DEBUG - 2018-08-15 14:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:58:51 --> CSRF cookie sent
INFO - 2018-08-15 14:58:51 --> CSRF token verified
INFO - 2018-08-15 14:58:51 --> Input Class Initialized
INFO - 2018-08-15 14:58:51 --> Language Class Initialized
INFO - 2018-08-15 14:58:51 --> Loader Class Initialized
INFO - 2018-08-15 14:58:51 --> Helper loaded: url_helper
INFO - 2018-08-15 14:58:51 --> Helper loaded: form_helper
INFO - 2018-08-15 14:58:51 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:58:51 --> User Agent Class Initialized
INFO - 2018-08-15 14:58:51 --> Controller Class Initialized
INFO - 2018-08-15 14:58:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:58:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:58:51 --> Pixel_Model class loaded
INFO - 2018-08-15 14:58:51 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:51 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:51 --> Config Class Initialized
INFO - 2018-08-15 14:58:51 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:58:51 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:58:51 --> Utf8 Class Initialized
INFO - 2018-08-15 14:58:51 --> URI Class Initialized
INFO - 2018-08-15 14:58:51 --> Router Class Initialized
INFO - 2018-08-15 14:58:51 --> Output Class Initialized
INFO - 2018-08-15 14:58:51 --> Security Class Initialized
DEBUG - 2018-08-15 14:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:58:51 --> CSRF cookie sent
INFO - 2018-08-15 14:58:51 --> Input Class Initialized
INFO - 2018-08-15 14:58:51 --> Language Class Initialized
INFO - 2018-08-15 14:58:51 --> Loader Class Initialized
INFO - 2018-08-15 14:58:51 --> Helper loaded: url_helper
INFO - 2018-08-15 14:58:51 --> Helper loaded: form_helper
INFO - 2018-08-15 14:58:51 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:58:51 --> User Agent Class Initialized
INFO - 2018-08-15 14:58:51 --> Controller Class Initialized
INFO - 2018-08-15 14:58:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:58:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:58:51 --> Pixel_Model class loaded
INFO - 2018-08-15 14:58:51 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:51 --> Database Driver Class Initialized
INFO - 2018-08-15 14:58:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-15 14:58:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:58:51 --> Final output sent to browser
DEBUG - 2018-08-15 14:58:51 --> Total execution time: 0.0648
INFO - 2018-08-15 14:59:00 --> Config Class Initialized
INFO - 2018-08-15 14:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:00 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:00 --> URI Class Initialized
INFO - 2018-08-15 14:59:00 --> Router Class Initialized
INFO - 2018-08-15 14:59:00 --> Output Class Initialized
INFO - 2018-08-15 14:59:00 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:00 --> CSRF cookie sent
INFO - 2018-08-15 14:59:00 --> CSRF token verified
INFO - 2018-08-15 14:59:00 --> Input Class Initialized
INFO - 2018-08-15 14:59:00 --> Language Class Initialized
INFO - 2018-08-15 14:59:00 --> Loader Class Initialized
INFO - 2018-08-15 14:59:00 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:00 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:00 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:00 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:00 --> Controller Class Initialized
INFO - 2018-08-15 14:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:00 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:00 --> Form Validation Class Initialized
INFO - 2018-08-15 14:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:00 --> Config Class Initialized
INFO - 2018-08-15 14:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:00 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:00 --> URI Class Initialized
INFO - 2018-08-15 14:59:00 --> Router Class Initialized
INFO - 2018-08-15 14:59:00 --> Output Class Initialized
INFO - 2018-08-15 14:59:00 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:00 --> CSRF cookie sent
INFO - 2018-08-15 14:59:00 --> Input Class Initialized
INFO - 2018-08-15 14:59:00 --> Language Class Initialized
INFO - 2018-08-15 14:59:00 --> Loader Class Initialized
INFO - 2018-08-15 14:59:00 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:00 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:00 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:00 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:00 --> Controller Class Initialized
INFO - 2018-08-15 14:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:00 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:01 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-15 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:59:01 --> Final output sent to browser
DEBUG - 2018-08-15 14:59:01 --> Total execution time: 0.0469
INFO - 2018-08-15 14:59:21 --> Config Class Initialized
INFO - 2018-08-15 14:59:21 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:21 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:21 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:21 --> URI Class Initialized
INFO - 2018-08-15 14:59:21 --> Router Class Initialized
INFO - 2018-08-15 14:59:21 --> Output Class Initialized
INFO - 2018-08-15 14:59:21 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:21 --> CSRF cookie sent
INFO - 2018-08-15 14:59:21 --> CSRF token verified
INFO - 2018-08-15 14:59:21 --> Input Class Initialized
INFO - 2018-08-15 14:59:21 --> Language Class Initialized
INFO - 2018-08-15 14:59:21 --> Loader Class Initialized
INFO - 2018-08-15 14:59:21 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:21 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:21 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:21 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:21 --> Controller Class Initialized
INFO - 2018-08-15 14:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:21 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:21 --> Form Validation Class Initialized
INFO - 2018-08-15 14:59:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:21 --> Config Class Initialized
INFO - 2018-08-15 14:59:21 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:21 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:21 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:21 --> URI Class Initialized
INFO - 2018-08-15 14:59:21 --> Router Class Initialized
INFO - 2018-08-15 14:59:21 --> Output Class Initialized
INFO - 2018-08-15 14:59:21 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:21 --> CSRF cookie sent
INFO - 2018-08-15 14:59:21 --> Input Class Initialized
INFO - 2018-08-15 14:59:21 --> Language Class Initialized
INFO - 2018-08-15 14:59:21 --> Loader Class Initialized
INFO - 2018-08-15 14:59:21 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:21 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:21 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:21 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:21 --> Controller Class Initialized
INFO - 2018-08-15 14:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:21 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-15 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:59:21 --> Final output sent to browser
DEBUG - 2018-08-15 14:59:21 --> Total execution time: 0.0414
INFO - 2018-08-15 14:59:25 --> Config Class Initialized
INFO - 2018-08-15 14:59:25 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:25 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:25 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:25 --> URI Class Initialized
INFO - 2018-08-15 14:59:25 --> Router Class Initialized
INFO - 2018-08-15 14:59:25 --> Output Class Initialized
INFO - 2018-08-15 14:59:25 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:25 --> CSRF cookie sent
INFO - 2018-08-15 14:59:25 --> CSRF token verified
INFO - 2018-08-15 14:59:25 --> Input Class Initialized
INFO - 2018-08-15 14:59:25 --> Language Class Initialized
INFO - 2018-08-15 14:59:25 --> Loader Class Initialized
INFO - 2018-08-15 14:59:25 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:25 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:25 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:25 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:25 --> Controller Class Initialized
INFO - 2018-08-15 14:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:25 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:25 --> Form Validation Class Initialized
INFO - 2018-08-15 14:59:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:25 --> Config Class Initialized
INFO - 2018-08-15 14:59:25 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:25 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:25 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:25 --> URI Class Initialized
INFO - 2018-08-15 14:59:25 --> Router Class Initialized
INFO - 2018-08-15 14:59:25 --> Output Class Initialized
INFO - 2018-08-15 14:59:25 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:25 --> CSRF cookie sent
INFO - 2018-08-15 14:59:25 --> Input Class Initialized
INFO - 2018-08-15 14:59:25 --> Language Class Initialized
INFO - 2018-08-15 14:59:25 --> Loader Class Initialized
INFO - 2018-08-15 14:59:25 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:25 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:25 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:25 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:25 --> Controller Class Initialized
INFO - 2018-08-15 14:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:25 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-15 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:59:25 --> Final output sent to browser
DEBUG - 2018-08-15 14:59:25 --> Total execution time: 0.0479
INFO - 2018-08-15 14:59:55 --> Config Class Initialized
INFO - 2018-08-15 14:59:55 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:55 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:55 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:55 --> URI Class Initialized
INFO - 2018-08-15 14:59:55 --> Router Class Initialized
INFO - 2018-08-15 14:59:55 --> Output Class Initialized
INFO - 2018-08-15 14:59:55 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:55 --> CSRF cookie sent
INFO - 2018-08-15 14:59:55 --> CSRF token verified
INFO - 2018-08-15 14:59:55 --> Input Class Initialized
INFO - 2018-08-15 14:59:55 --> Language Class Initialized
INFO - 2018-08-15 14:59:55 --> Loader Class Initialized
INFO - 2018-08-15 14:59:55 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:55 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:55 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:55 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:55 --> Controller Class Initialized
INFO - 2018-08-15 14:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:55 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:55 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:55 --> Form Validation Class Initialized
INFO - 2018-08-15 14:59:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 14:59:55 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:55 --> Config Class Initialized
INFO - 2018-08-15 14:59:55 --> Hooks Class Initialized
DEBUG - 2018-08-15 14:59:55 --> UTF-8 Support Enabled
INFO - 2018-08-15 14:59:55 --> Utf8 Class Initialized
INFO - 2018-08-15 14:59:55 --> URI Class Initialized
INFO - 2018-08-15 14:59:55 --> Router Class Initialized
INFO - 2018-08-15 14:59:55 --> Output Class Initialized
INFO - 2018-08-15 14:59:55 --> Security Class Initialized
DEBUG - 2018-08-15 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 14:59:55 --> CSRF cookie sent
INFO - 2018-08-15 14:59:55 --> Input Class Initialized
INFO - 2018-08-15 14:59:55 --> Language Class Initialized
INFO - 2018-08-15 14:59:55 --> Loader Class Initialized
INFO - 2018-08-15 14:59:55 --> Helper loaded: url_helper
INFO - 2018-08-15 14:59:55 --> Helper loaded: form_helper
INFO - 2018-08-15 14:59:55 --> Helper loaded: language_helper
DEBUG - 2018-08-15 14:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 14:59:55 --> User Agent Class Initialized
INFO - 2018-08-15 14:59:55 --> Controller Class Initialized
INFO - 2018-08-15 14:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 14:59:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 14:59:55 --> Pixel_Model class loaded
INFO - 2018-08-15 14:59:55 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:55 --> Database Driver Class Initialized
INFO - 2018-08-15 14:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-15 14:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 14:59:55 --> Final output sent to browser
DEBUG - 2018-08-15 14:59:55 --> Total execution time: 0.0443
INFO - 2018-08-15 15:00:06 --> Config Class Initialized
INFO - 2018-08-15 15:00:06 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:00:06 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:00:06 --> Utf8 Class Initialized
INFO - 2018-08-15 15:00:06 --> URI Class Initialized
INFO - 2018-08-15 15:00:06 --> Router Class Initialized
INFO - 2018-08-15 15:00:06 --> Output Class Initialized
INFO - 2018-08-15 15:00:06 --> Security Class Initialized
DEBUG - 2018-08-15 15:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:00:06 --> CSRF cookie sent
INFO - 2018-08-15 15:00:06 --> Input Class Initialized
INFO - 2018-08-15 15:00:06 --> Language Class Initialized
INFO - 2018-08-15 15:00:06 --> Loader Class Initialized
INFO - 2018-08-15 15:00:06 --> Helper loaded: url_helper
INFO - 2018-08-15 15:00:06 --> Helper loaded: form_helper
INFO - 2018-08-15 15:00:06 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:00:06 --> User Agent Class Initialized
INFO - 2018-08-15 15:00:06 --> Controller Class Initialized
INFO - 2018-08-15 15:00:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:00:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:00:06 --> Pixel_Model class loaded
INFO - 2018-08-15 15:00:06 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:06 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-15 15:00:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:00:06 --> Final output sent to browser
DEBUG - 2018-08-15 15:00:06 --> Total execution time: 0.0631
INFO - 2018-08-15 15:00:47 --> Config Class Initialized
INFO - 2018-08-15 15:00:47 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:00:47 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:00:47 --> Utf8 Class Initialized
INFO - 2018-08-15 15:00:47 --> URI Class Initialized
INFO - 2018-08-15 15:00:47 --> Router Class Initialized
INFO - 2018-08-15 15:00:47 --> Output Class Initialized
INFO - 2018-08-15 15:00:47 --> Security Class Initialized
DEBUG - 2018-08-15 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:00:47 --> CSRF cookie sent
INFO - 2018-08-15 15:00:47 --> Input Class Initialized
INFO - 2018-08-15 15:00:47 --> Language Class Initialized
INFO - 2018-08-15 15:00:47 --> Loader Class Initialized
INFO - 2018-08-15 15:00:47 --> Helper loaded: url_helper
INFO - 2018-08-15 15:00:47 --> Helper loaded: form_helper
INFO - 2018-08-15 15:00:47 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:00:47 --> User Agent Class Initialized
INFO - 2018-08-15 15:00:47 --> Controller Class Initialized
INFO - 2018-08-15 15:00:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:00:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:00:47 --> Pixel_Model class loaded
INFO - 2018-08-15 15:00:47 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:47 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-15 15:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:00:47 --> Final output sent to browser
DEBUG - 2018-08-15 15:00:47 --> Total execution time: 0.0451
INFO - 2018-08-15 15:00:52 --> Config Class Initialized
INFO - 2018-08-15 15:00:52 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:00:52 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:00:52 --> Utf8 Class Initialized
INFO - 2018-08-15 15:00:52 --> URI Class Initialized
INFO - 2018-08-15 15:00:52 --> Router Class Initialized
INFO - 2018-08-15 15:00:52 --> Output Class Initialized
INFO - 2018-08-15 15:00:52 --> Security Class Initialized
DEBUG - 2018-08-15 15:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:00:52 --> CSRF cookie sent
INFO - 2018-08-15 15:00:52 --> Input Class Initialized
INFO - 2018-08-15 15:00:52 --> Language Class Initialized
INFO - 2018-08-15 15:00:52 --> Loader Class Initialized
INFO - 2018-08-15 15:00:52 --> Helper loaded: url_helper
INFO - 2018-08-15 15:00:52 --> Helper loaded: form_helper
INFO - 2018-08-15 15:00:52 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:00:52 --> User Agent Class Initialized
INFO - 2018-08-15 15:00:52 --> Controller Class Initialized
INFO - 2018-08-15 15:00:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:00:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:00:52 --> Pixel_Model class loaded
INFO - 2018-08-15 15:00:52 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:52 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-15 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:00:52 --> Final output sent to browser
DEBUG - 2018-08-15 15:00:52 --> Total execution time: 0.0474
INFO - 2018-08-15 15:00:53 --> Config Class Initialized
INFO - 2018-08-15 15:00:53 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:00:53 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:00:53 --> Utf8 Class Initialized
INFO - 2018-08-15 15:00:53 --> URI Class Initialized
INFO - 2018-08-15 15:00:53 --> Router Class Initialized
INFO - 2018-08-15 15:00:53 --> Output Class Initialized
INFO - 2018-08-15 15:00:53 --> Security Class Initialized
DEBUG - 2018-08-15 15:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:00:53 --> CSRF cookie sent
INFO - 2018-08-15 15:00:53 --> Input Class Initialized
INFO - 2018-08-15 15:00:53 --> Language Class Initialized
INFO - 2018-08-15 15:00:53 --> Loader Class Initialized
INFO - 2018-08-15 15:00:53 --> Helper loaded: url_helper
INFO - 2018-08-15 15:00:53 --> Helper loaded: form_helper
INFO - 2018-08-15 15:00:53 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:00:53 --> User Agent Class Initialized
INFO - 2018-08-15 15:00:53 --> Controller Class Initialized
INFO - 2018-08-15 15:00:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:00:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:00:53 --> Pixel_Model class loaded
INFO - 2018-08-15 15:00:53 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:53 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-15 15:00:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:00:53 --> Final output sent to browser
DEBUG - 2018-08-15 15:00:53 --> Total execution time: 0.0535
INFO - 2018-08-15 15:00:55 --> Config Class Initialized
INFO - 2018-08-15 15:00:55 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:00:55 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:00:55 --> Utf8 Class Initialized
INFO - 2018-08-15 15:00:55 --> URI Class Initialized
INFO - 2018-08-15 15:00:55 --> Router Class Initialized
INFO - 2018-08-15 15:00:55 --> Output Class Initialized
INFO - 2018-08-15 15:00:55 --> Security Class Initialized
DEBUG - 2018-08-15 15:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:00:55 --> CSRF cookie sent
INFO - 2018-08-15 15:00:55 --> Input Class Initialized
INFO - 2018-08-15 15:00:55 --> Language Class Initialized
INFO - 2018-08-15 15:00:55 --> Loader Class Initialized
INFO - 2018-08-15 15:00:55 --> Helper loaded: url_helper
INFO - 2018-08-15 15:00:55 --> Helper loaded: form_helper
INFO - 2018-08-15 15:00:55 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:00:55 --> User Agent Class Initialized
INFO - 2018-08-15 15:00:55 --> Controller Class Initialized
INFO - 2018-08-15 15:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:00:55 --> Pixel_Model class loaded
INFO - 2018-08-15 15:00:55 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:55 --> Database Driver Class Initialized
INFO - 2018-08-15 15:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-15 15:00:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:00:55 --> Final output sent to browser
DEBUG - 2018-08-15 15:00:55 --> Total execution time: 0.0436
INFO - 2018-08-15 15:13:51 --> Config Class Initialized
INFO - 2018-08-15 15:13:51 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:13:51 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:13:51 --> Utf8 Class Initialized
INFO - 2018-08-15 15:13:51 --> URI Class Initialized
INFO - 2018-08-15 15:13:51 --> Router Class Initialized
INFO - 2018-08-15 15:13:51 --> Output Class Initialized
INFO - 2018-08-15 15:13:51 --> Security Class Initialized
DEBUG - 2018-08-15 15:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:13:51 --> CSRF cookie sent
INFO - 2018-08-15 15:13:51 --> Input Class Initialized
INFO - 2018-08-15 15:13:51 --> Language Class Initialized
ERROR - 2018-08-15 15:13:51 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-15 15:13:52 --> Config Class Initialized
INFO - 2018-08-15 15:13:52 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:13:52 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:13:52 --> Utf8 Class Initialized
INFO - 2018-08-15 15:13:52 --> URI Class Initialized
INFO - 2018-08-15 15:13:52 --> Router Class Initialized
INFO - 2018-08-15 15:13:52 --> Output Class Initialized
INFO - 2018-08-15 15:13:52 --> Security Class Initialized
DEBUG - 2018-08-15 15:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:13:52 --> CSRF cookie sent
INFO - 2018-08-15 15:13:52 --> Input Class Initialized
INFO - 2018-08-15 15:13:52 --> Language Class Initialized
ERROR - 2018-08-15 15:13:52 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-15 15:13:55 --> Config Class Initialized
INFO - 2018-08-15 15:13:55 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:13:55 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:13:55 --> Utf8 Class Initialized
INFO - 2018-08-15 15:13:55 --> URI Class Initialized
DEBUG - 2018-08-15 15:13:55 --> No URI present. Default controller set.
INFO - 2018-08-15 15:13:55 --> Router Class Initialized
INFO - 2018-08-15 15:13:55 --> Output Class Initialized
INFO - 2018-08-15 15:13:55 --> Security Class Initialized
DEBUG - 2018-08-15 15:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:13:55 --> CSRF cookie sent
INFO - 2018-08-15 15:13:55 --> Input Class Initialized
INFO - 2018-08-15 15:13:55 --> Language Class Initialized
INFO - 2018-08-15 15:13:55 --> Loader Class Initialized
INFO - 2018-08-15 15:13:55 --> Helper loaded: url_helper
INFO - 2018-08-15 15:13:55 --> Helper loaded: form_helper
INFO - 2018-08-15 15:13:55 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:13:55 --> User Agent Class Initialized
INFO - 2018-08-15 15:13:55 --> Controller Class Initialized
INFO - 2018-08-15 15:13:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:13:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:13:55 --> Pixel_Model class loaded
INFO - 2018-08-15 15:13:55 --> Database Driver Class Initialized
INFO - 2018-08-15 15:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:13:55 --> Final output sent to browser
DEBUG - 2018-08-15 15:13:55 --> Total execution time: 0.0361
INFO - 2018-08-15 15:13:55 --> Config Class Initialized
INFO - 2018-08-15 15:13:55 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:13:55 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:13:55 --> Utf8 Class Initialized
INFO - 2018-08-15 15:13:55 --> URI Class Initialized
DEBUG - 2018-08-15 15:13:55 --> No URI present. Default controller set.
INFO - 2018-08-15 15:13:55 --> Router Class Initialized
INFO - 2018-08-15 15:13:55 --> Output Class Initialized
INFO - 2018-08-15 15:13:55 --> Security Class Initialized
DEBUG - 2018-08-15 15:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:13:55 --> CSRF cookie sent
INFO - 2018-08-15 15:13:55 --> Input Class Initialized
INFO - 2018-08-15 15:13:55 --> Language Class Initialized
INFO - 2018-08-15 15:13:55 --> Loader Class Initialized
INFO - 2018-08-15 15:13:55 --> Helper loaded: url_helper
INFO - 2018-08-15 15:13:55 --> Helper loaded: form_helper
INFO - 2018-08-15 15:13:55 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:13:55 --> User Agent Class Initialized
INFO - 2018-08-15 15:13:55 --> Controller Class Initialized
INFO - 2018-08-15 15:13:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:13:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:13:55 --> Pixel_Model class loaded
INFO - 2018-08-15 15:13:55 --> Database Driver Class Initialized
INFO - 2018-08-15 15:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 15:13:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:13:55 --> Final output sent to browser
DEBUG - 2018-08-15 15:13:55 --> Total execution time: 0.0360
INFO - 2018-08-15 15:13:59 --> Config Class Initialized
INFO - 2018-08-15 15:13:59 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:13:59 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:13:59 --> Utf8 Class Initialized
INFO - 2018-08-15 15:13:59 --> URI Class Initialized
INFO - 2018-08-15 15:13:59 --> Router Class Initialized
INFO - 2018-08-15 15:13:59 --> Output Class Initialized
INFO - 2018-08-15 15:13:59 --> Security Class Initialized
DEBUG - 2018-08-15 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:13:59 --> CSRF cookie sent
INFO - 2018-08-15 15:13:59 --> Input Class Initialized
INFO - 2018-08-15 15:13:59 --> Language Class Initialized
INFO - 2018-08-15 15:13:59 --> Loader Class Initialized
INFO - 2018-08-15 15:13:59 --> Helper loaded: url_helper
INFO - 2018-08-15 15:13:59 --> Helper loaded: form_helper
INFO - 2018-08-15 15:13:59 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:13:59 --> User Agent Class Initialized
INFO - 2018-08-15 15:13:59 --> Controller Class Initialized
INFO - 2018-08-15 15:13:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:13:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-15 15:13:59 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-15 15:13:59 --> Could not find the language line "req_email"
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-15 15:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:13:59 --> Final output sent to browser
DEBUG - 2018-08-15 15:13:59 --> Total execution time: 0.0217
INFO - 2018-08-15 15:14:04 --> Config Class Initialized
INFO - 2018-08-15 15:14:04 --> Hooks Class Initialized
DEBUG - 2018-08-15 15:14:04 --> UTF-8 Support Enabled
INFO - 2018-08-15 15:14:04 --> Utf8 Class Initialized
INFO - 2018-08-15 15:14:04 --> URI Class Initialized
INFO - 2018-08-15 15:14:04 --> Router Class Initialized
INFO - 2018-08-15 15:14:04 --> Output Class Initialized
INFO - 2018-08-15 15:14:04 --> Security Class Initialized
DEBUG - 2018-08-15 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 15:14:04 --> CSRF cookie sent
INFO - 2018-08-15 15:14:04 --> Input Class Initialized
INFO - 2018-08-15 15:14:04 --> Language Class Initialized
INFO - 2018-08-15 15:14:04 --> Loader Class Initialized
INFO - 2018-08-15 15:14:04 --> Helper loaded: url_helper
INFO - 2018-08-15 15:14:04 --> Helper loaded: form_helper
INFO - 2018-08-15 15:14:04 --> Helper loaded: language_helper
DEBUG - 2018-08-15 15:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 15:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 15:14:04 --> User Agent Class Initialized
INFO - 2018-08-15 15:14:04 --> Controller Class Initialized
INFO - 2018-08-15 15:14:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 15:14:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 15:14:04 --> Pixel_Model class loaded
INFO - 2018-08-15 15:14:04 --> Database Driver Class Initialized
INFO - 2018-08-15 15:14:04 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-15 15:14:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-15 15:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 15:14:04 --> Final output sent to browser
DEBUG - 2018-08-15 15:14:04 --> Total execution time: 0.0438
INFO - 2018-08-15 16:06:37 --> Config Class Initialized
INFO - 2018-08-15 16:06:37 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:06:37 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:06:37 --> Utf8 Class Initialized
INFO - 2018-08-15 16:06:37 --> URI Class Initialized
INFO - 2018-08-15 16:06:37 --> Router Class Initialized
INFO - 2018-08-15 16:06:37 --> Output Class Initialized
INFO - 2018-08-15 16:06:37 --> Security Class Initialized
DEBUG - 2018-08-15 16:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:06:37 --> CSRF cookie sent
INFO - 2018-08-15 16:06:37 --> Input Class Initialized
INFO - 2018-08-15 16:06:37 --> Language Class Initialized
INFO - 2018-08-15 16:06:37 --> Loader Class Initialized
INFO - 2018-08-15 16:06:37 --> Helper loaded: url_helper
INFO - 2018-08-15 16:06:37 --> Helper loaded: form_helper
INFO - 2018-08-15 16:06:37 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:06:37 --> User Agent Class Initialized
INFO - 2018-08-15 16:06:37 --> Controller Class Initialized
INFO - 2018-08-15 16:06:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:06:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:06:37 --> Pixel_Model class loaded
INFO - 2018-08-15 16:06:37 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:38 --> Config Class Initialized
INFO - 2018-08-15 16:06:38 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:06:38 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:06:38 --> Utf8 Class Initialized
INFO - 2018-08-15 16:06:38 --> URI Class Initialized
INFO - 2018-08-15 16:06:38 --> Router Class Initialized
INFO - 2018-08-15 16:06:38 --> Output Class Initialized
INFO - 2018-08-15 16:06:38 --> Security Class Initialized
DEBUG - 2018-08-15 16:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:06:38 --> CSRF cookie sent
INFO - 2018-08-15 16:06:38 --> Input Class Initialized
INFO - 2018-08-15 16:06:38 --> Language Class Initialized
INFO - 2018-08-15 16:06:38 --> Loader Class Initialized
INFO - 2018-08-15 16:06:38 --> Helper loaded: url_helper
INFO - 2018-08-15 16:06:38 --> Helper loaded: form_helper
INFO - 2018-08-15 16:06:38 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:06:38 --> User Agent Class Initialized
INFO - 2018-08-15 16:06:38 --> Controller Class Initialized
INFO - 2018-08-15 16:06:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:06:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:06:38 --> Pixel_Model class loaded
INFO - 2018-08-15 16:06:38 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-15 16:06:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 16:06:38 --> Final output sent to browser
DEBUG - 2018-08-15 16:06:38 --> Total execution time: 0.0350
INFO - 2018-08-15 16:06:47 --> Config Class Initialized
INFO - 2018-08-15 16:06:47 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:06:47 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:06:47 --> Utf8 Class Initialized
INFO - 2018-08-15 16:06:47 --> URI Class Initialized
DEBUG - 2018-08-15 16:06:47 --> No URI present. Default controller set.
INFO - 2018-08-15 16:06:47 --> Router Class Initialized
INFO - 2018-08-15 16:06:47 --> Output Class Initialized
INFO - 2018-08-15 16:06:47 --> Security Class Initialized
DEBUG - 2018-08-15 16:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:06:47 --> CSRF cookie sent
INFO - 2018-08-15 16:06:47 --> Input Class Initialized
INFO - 2018-08-15 16:06:47 --> Language Class Initialized
INFO - 2018-08-15 16:06:47 --> Loader Class Initialized
INFO - 2018-08-15 16:06:47 --> Helper loaded: url_helper
INFO - 2018-08-15 16:06:47 --> Helper loaded: form_helper
INFO - 2018-08-15 16:06:47 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:06:47 --> User Agent Class Initialized
INFO - 2018-08-15 16:06:47 --> Controller Class Initialized
INFO - 2018-08-15 16:06:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:06:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:06:47 --> Pixel_Model class loaded
INFO - 2018-08-15 16:06:47 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 16:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 16:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 16:06:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 16:06:47 --> Final output sent to browser
DEBUG - 2018-08-15 16:06:47 --> Total execution time: 0.0332
INFO - 2018-08-15 16:06:56 --> Config Class Initialized
INFO - 2018-08-15 16:06:56 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:06:56 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:06:56 --> Utf8 Class Initialized
INFO - 2018-08-15 16:06:56 --> URI Class Initialized
INFO - 2018-08-15 16:06:56 --> Router Class Initialized
INFO - 2018-08-15 16:06:56 --> Output Class Initialized
INFO - 2018-08-15 16:06:56 --> Security Class Initialized
DEBUG - 2018-08-15 16:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:06:56 --> CSRF cookie sent
INFO - 2018-08-15 16:06:56 --> CSRF token verified
INFO - 2018-08-15 16:06:56 --> Input Class Initialized
INFO - 2018-08-15 16:06:56 --> Language Class Initialized
INFO - 2018-08-15 16:06:56 --> Loader Class Initialized
INFO - 2018-08-15 16:06:56 --> Helper loaded: url_helper
INFO - 2018-08-15 16:06:56 --> Helper loaded: form_helper
INFO - 2018-08-15 16:06:56 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:06:56 --> User Agent Class Initialized
INFO - 2018-08-15 16:06:56 --> Controller Class Initialized
INFO - 2018-08-15 16:06:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:06:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:06:56 --> Pixel_Model class loaded
INFO - 2018-08-15 16:06:56 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:56 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:57 --> Config Class Initialized
INFO - 2018-08-15 16:06:57 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:06:57 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:06:57 --> Utf8 Class Initialized
INFO - 2018-08-15 16:06:57 --> URI Class Initialized
INFO - 2018-08-15 16:06:57 --> Router Class Initialized
INFO - 2018-08-15 16:06:57 --> Output Class Initialized
INFO - 2018-08-15 16:06:57 --> Security Class Initialized
DEBUG - 2018-08-15 16:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:06:57 --> CSRF cookie sent
INFO - 2018-08-15 16:06:57 --> Input Class Initialized
INFO - 2018-08-15 16:06:57 --> Language Class Initialized
INFO - 2018-08-15 16:06:57 --> Loader Class Initialized
INFO - 2018-08-15 16:06:57 --> Helper loaded: url_helper
INFO - 2018-08-15 16:06:57 --> Helper loaded: form_helper
INFO - 2018-08-15 16:06:57 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:06:57 --> User Agent Class Initialized
INFO - 2018-08-15 16:06:57 --> Controller Class Initialized
INFO - 2018-08-15 16:06:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:06:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:06:57 --> Pixel_Model class loaded
INFO - 2018-08-15 16:06:57 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:57 --> Database Driver Class Initialized
INFO - 2018-08-15 16:06:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-15 16:06:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 16:06:57 --> Final output sent to browser
DEBUG - 2018-08-15 16:06:57 --> Total execution time: 0.0628
INFO - 2018-08-15 16:07:05 --> Config Class Initialized
INFO - 2018-08-15 16:07:05 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:07:05 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:07:05 --> Utf8 Class Initialized
INFO - 2018-08-15 16:07:05 --> URI Class Initialized
INFO - 2018-08-15 16:07:05 --> Router Class Initialized
INFO - 2018-08-15 16:07:05 --> Output Class Initialized
INFO - 2018-08-15 16:07:05 --> Security Class Initialized
DEBUG - 2018-08-15 16:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:07:05 --> CSRF cookie sent
INFO - 2018-08-15 16:07:05 --> CSRF token verified
INFO - 2018-08-15 16:07:05 --> Input Class Initialized
INFO - 2018-08-15 16:07:05 --> Language Class Initialized
INFO - 2018-08-15 16:07:05 --> Loader Class Initialized
INFO - 2018-08-15 16:07:05 --> Helper loaded: url_helper
INFO - 2018-08-15 16:07:05 --> Helper loaded: form_helper
INFO - 2018-08-15 16:07:05 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:07:05 --> User Agent Class Initialized
INFO - 2018-08-15 16:07:05 --> Controller Class Initialized
INFO - 2018-08-15 16:07:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:07:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:07:05 --> Pixel_Model class loaded
INFO - 2018-08-15 16:07:05 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:05 --> Form Validation Class Initialized
INFO - 2018-08-15 16:07:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 16:07:05 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:06 --> Config Class Initialized
INFO - 2018-08-15 16:07:06 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:07:06 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:07:06 --> Utf8 Class Initialized
INFO - 2018-08-15 16:07:06 --> URI Class Initialized
INFO - 2018-08-15 16:07:06 --> Router Class Initialized
INFO - 2018-08-15 16:07:06 --> Output Class Initialized
INFO - 2018-08-15 16:07:06 --> Security Class Initialized
DEBUG - 2018-08-15 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:07:06 --> CSRF cookie sent
INFO - 2018-08-15 16:07:06 --> Input Class Initialized
INFO - 2018-08-15 16:07:06 --> Language Class Initialized
INFO - 2018-08-15 16:07:06 --> Loader Class Initialized
INFO - 2018-08-15 16:07:06 --> Helper loaded: url_helper
INFO - 2018-08-15 16:07:06 --> Helper loaded: form_helper
INFO - 2018-08-15 16:07:06 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:07:06 --> User Agent Class Initialized
INFO - 2018-08-15 16:07:06 --> Controller Class Initialized
INFO - 2018-08-15 16:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:07:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:07:06 --> Pixel_Model class loaded
INFO - 2018-08-15 16:07:06 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:06 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-15 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 16:07:06 --> Final output sent to browser
DEBUG - 2018-08-15 16:07:06 --> Total execution time: 0.0486
INFO - 2018-08-15 16:07:38 --> Config Class Initialized
INFO - 2018-08-15 16:07:38 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:07:38 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:07:38 --> Utf8 Class Initialized
INFO - 2018-08-15 16:07:38 --> URI Class Initialized
INFO - 2018-08-15 16:07:38 --> Router Class Initialized
INFO - 2018-08-15 16:07:38 --> Output Class Initialized
INFO - 2018-08-15 16:07:38 --> Security Class Initialized
DEBUG - 2018-08-15 16:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:07:38 --> CSRF cookie sent
INFO - 2018-08-15 16:07:38 --> CSRF token verified
INFO - 2018-08-15 16:07:38 --> Input Class Initialized
INFO - 2018-08-15 16:07:38 --> Language Class Initialized
INFO - 2018-08-15 16:07:38 --> Loader Class Initialized
INFO - 2018-08-15 16:07:38 --> Helper loaded: url_helper
INFO - 2018-08-15 16:07:38 --> Helper loaded: form_helper
INFO - 2018-08-15 16:07:38 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:07:38 --> User Agent Class Initialized
INFO - 2018-08-15 16:07:38 --> Controller Class Initialized
INFO - 2018-08-15 16:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:07:38 --> Pixel_Model class loaded
INFO - 2018-08-15 16:07:39 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:39 --> Form Validation Class Initialized
INFO - 2018-08-15 16:07:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-15 16:07:39 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:39 --> Config Class Initialized
INFO - 2018-08-15 16:07:39 --> Hooks Class Initialized
DEBUG - 2018-08-15 16:07:39 --> UTF-8 Support Enabled
INFO - 2018-08-15 16:07:39 --> Utf8 Class Initialized
INFO - 2018-08-15 16:07:39 --> URI Class Initialized
INFO - 2018-08-15 16:07:39 --> Router Class Initialized
INFO - 2018-08-15 16:07:39 --> Output Class Initialized
INFO - 2018-08-15 16:07:39 --> Security Class Initialized
DEBUG - 2018-08-15 16:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 16:07:39 --> CSRF cookie sent
INFO - 2018-08-15 16:07:39 --> Input Class Initialized
INFO - 2018-08-15 16:07:39 --> Language Class Initialized
INFO - 2018-08-15 16:07:39 --> Loader Class Initialized
INFO - 2018-08-15 16:07:39 --> Helper loaded: url_helper
INFO - 2018-08-15 16:07:39 --> Helper loaded: form_helper
INFO - 2018-08-15 16:07:39 --> Helper loaded: language_helper
DEBUG - 2018-08-15 16:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 16:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 16:07:39 --> User Agent Class Initialized
INFO - 2018-08-15 16:07:39 --> Controller Class Initialized
INFO - 2018-08-15 16:07:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 16:07:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 16:07:39 --> Pixel_Model class loaded
INFO - 2018-08-15 16:07:39 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:39 --> Database Driver Class Initialized
INFO - 2018-08-15 16:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-15 16:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 16:07:39 --> Final output sent to browser
DEBUG - 2018-08-15 16:07:39 --> Total execution time: 0.0554
INFO - 2018-08-15 17:34:33 --> Config Class Initialized
INFO - 2018-08-15 17:34:33 --> Hooks Class Initialized
DEBUG - 2018-08-15 17:34:33 --> UTF-8 Support Enabled
INFO - 2018-08-15 17:34:33 --> Utf8 Class Initialized
INFO - 2018-08-15 17:34:33 --> URI Class Initialized
DEBUG - 2018-08-15 17:34:33 --> No URI present. Default controller set.
INFO - 2018-08-15 17:34:33 --> Router Class Initialized
INFO - 2018-08-15 17:34:33 --> Output Class Initialized
INFO - 2018-08-15 17:34:33 --> Security Class Initialized
DEBUG - 2018-08-15 17:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 17:34:33 --> CSRF cookie sent
INFO - 2018-08-15 17:34:33 --> Input Class Initialized
INFO - 2018-08-15 17:34:33 --> Language Class Initialized
INFO - 2018-08-15 17:34:33 --> Loader Class Initialized
INFO - 2018-08-15 17:34:33 --> Helper loaded: url_helper
INFO - 2018-08-15 17:34:33 --> Helper loaded: form_helper
INFO - 2018-08-15 17:34:33 --> Helper loaded: language_helper
DEBUG - 2018-08-15 17:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 17:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 17:34:33 --> User Agent Class Initialized
INFO - 2018-08-15 17:34:33 --> Controller Class Initialized
INFO - 2018-08-15 17:34:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 17:34:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 17:34:33 --> Pixel_Model class loaded
INFO - 2018-08-15 17:34:33 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 17:34:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 17:34:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 17:34:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 17:34:33 --> Final output sent to browser
DEBUG - 2018-08-15 17:34:33 --> Total execution time: 0.0442
INFO - 2018-08-15 17:34:34 --> Config Class Initialized
INFO - 2018-08-15 17:34:34 --> Hooks Class Initialized
DEBUG - 2018-08-15 17:34:34 --> UTF-8 Support Enabled
INFO - 2018-08-15 17:34:34 --> Utf8 Class Initialized
INFO - 2018-08-15 17:34:34 --> URI Class Initialized
DEBUG - 2018-08-15 17:34:34 --> No URI present. Default controller set.
INFO - 2018-08-15 17:34:34 --> Router Class Initialized
INFO - 2018-08-15 17:34:34 --> Output Class Initialized
INFO - 2018-08-15 17:34:34 --> Security Class Initialized
DEBUG - 2018-08-15 17:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 17:34:34 --> CSRF cookie sent
INFO - 2018-08-15 17:34:34 --> Input Class Initialized
INFO - 2018-08-15 17:34:34 --> Language Class Initialized
INFO - 2018-08-15 17:34:34 --> Loader Class Initialized
INFO - 2018-08-15 17:34:34 --> Helper loaded: url_helper
INFO - 2018-08-15 17:34:34 --> Helper loaded: form_helper
INFO - 2018-08-15 17:34:34 --> Helper loaded: language_helper
DEBUG - 2018-08-15 17:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 17:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 17:34:34 --> User Agent Class Initialized
INFO - 2018-08-15 17:34:34 --> Controller Class Initialized
INFO - 2018-08-15 17:34:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 17:34:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 17:34:34 --> Pixel_Model class loaded
INFO - 2018-08-15 17:34:34 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 17:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 17:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-15 17:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 17:34:34 --> Final output sent to browser
DEBUG - 2018-08-15 17:34:34 --> Total execution time: 0.0291
INFO - 2018-08-15 17:34:43 --> Config Class Initialized
INFO - 2018-08-15 17:34:43 --> Hooks Class Initialized
DEBUG - 2018-08-15 17:34:43 --> UTF-8 Support Enabled
INFO - 2018-08-15 17:34:43 --> Utf8 Class Initialized
INFO - 2018-08-15 17:34:43 --> URI Class Initialized
INFO - 2018-08-15 17:34:43 --> Router Class Initialized
INFO - 2018-08-15 17:34:43 --> Output Class Initialized
INFO - 2018-08-15 17:34:43 --> Security Class Initialized
DEBUG - 2018-08-15 17:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 17:34:43 --> CSRF cookie sent
INFO - 2018-08-15 17:34:43 --> CSRF token verified
INFO - 2018-08-15 17:34:43 --> Input Class Initialized
INFO - 2018-08-15 17:34:43 --> Language Class Initialized
INFO - 2018-08-15 17:34:43 --> Loader Class Initialized
INFO - 2018-08-15 17:34:43 --> Helper loaded: url_helper
INFO - 2018-08-15 17:34:43 --> Helper loaded: form_helper
INFO - 2018-08-15 17:34:43 --> Helper loaded: language_helper
DEBUG - 2018-08-15 17:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 17:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 17:34:43 --> User Agent Class Initialized
INFO - 2018-08-15 17:34:43 --> Controller Class Initialized
INFO - 2018-08-15 17:34:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 17:34:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 17:34:43 --> Pixel_Model class loaded
INFO - 2018-08-15 17:34:43 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:43 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:43 --> Config Class Initialized
INFO - 2018-08-15 17:34:43 --> Hooks Class Initialized
DEBUG - 2018-08-15 17:34:43 --> UTF-8 Support Enabled
INFO - 2018-08-15 17:34:43 --> Utf8 Class Initialized
INFO - 2018-08-15 17:34:43 --> URI Class Initialized
INFO - 2018-08-15 17:34:43 --> Router Class Initialized
INFO - 2018-08-15 17:34:43 --> Output Class Initialized
INFO - 2018-08-15 17:34:43 --> Security Class Initialized
DEBUG - 2018-08-15 17:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-15 17:34:43 --> CSRF cookie sent
INFO - 2018-08-15 17:34:43 --> Input Class Initialized
INFO - 2018-08-15 17:34:43 --> Language Class Initialized
INFO - 2018-08-15 17:34:43 --> Loader Class Initialized
INFO - 2018-08-15 17:34:43 --> Helper loaded: url_helper
INFO - 2018-08-15 17:34:43 --> Helper loaded: form_helper
INFO - 2018-08-15 17:34:43 --> Helper loaded: language_helper
DEBUG - 2018-08-15 17:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-15 17:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-15 17:34:43 --> User Agent Class Initialized
INFO - 2018-08-15 17:34:43 --> Controller Class Initialized
INFO - 2018-08-15 17:34:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-15 17:34:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-15 17:34:43 --> Pixel_Model class loaded
INFO - 2018-08-15 17:34:43 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:43 --> Database Driver Class Initialized
INFO - 2018-08-15 17:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-15 17:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-15 17:34:43 --> Final output sent to browser
DEBUG - 2018-08-15 17:34:43 --> Total execution time: 0.0485

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-16 01:10:42 --> Config Class Initialized
INFO - 2018-08-16 01:10:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:10:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:10:42 --> Utf8 Class Initialized
INFO - 2018-08-16 01:10:42 --> URI Class Initialized
DEBUG - 2018-08-16 01:10:42 --> No URI present. Default controller set.
INFO - 2018-08-16 01:10:42 --> Router Class Initialized
INFO - 2018-08-16 01:10:42 --> Output Class Initialized
INFO - 2018-08-16 01:10:42 --> Security Class Initialized
DEBUG - 2018-08-16 01:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:10:42 --> CSRF cookie sent
INFO - 2018-08-16 01:10:42 --> Input Class Initialized
INFO - 2018-08-16 01:10:42 --> Language Class Initialized
INFO - 2018-08-16 01:10:42 --> Loader Class Initialized
INFO - 2018-08-16 01:10:42 --> Helper loaded: url_helper
INFO - 2018-08-16 01:10:42 --> Helper loaded: form_helper
INFO - 2018-08-16 01:10:42 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:10:42 --> User Agent Class Initialized
INFO - 2018-08-16 01:10:42 --> Controller Class Initialized
INFO - 2018-08-16 01:10:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:10:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:10:42 --> Pixel_Model class loaded
INFO - 2018-08-16 01:10:42 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:10:42 --> Final output sent to browser
DEBUG - 2018-08-16 01:10:42 --> Total execution time: 0.0351
INFO - 2018-08-16 01:10:44 --> Config Class Initialized
INFO - 2018-08-16 01:10:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:10:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:10:44 --> Utf8 Class Initialized
INFO - 2018-08-16 01:10:44 --> URI Class Initialized
DEBUG - 2018-08-16 01:10:44 --> No URI present. Default controller set.
INFO - 2018-08-16 01:10:44 --> Router Class Initialized
INFO - 2018-08-16 01:10:44 --> Output Class Initialized
INFO - 2018-08-16 01:10:44 --> Security Class Initialized
DEBUG - 2018-08-16 01:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:10:44 --> CSRF cookie sent
INFO - 2018-08-16 01:10:44 --> Input Class Initialized
INFO - 2018-08-16 01:10:44 --> Language Class Initialized
INFO - 2018-08-16 01:10:44 --> Loader Class Initialized
INFO - 2018-08-16 01:10:44 --> Helper loaded: url_helper
INFO - 2018-08-16 01:10:44 --> Helper loaded: form_helper
INFO - 2018-08-16 01:10:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:10:44 --> User Agent Class Initialized
INFO - 2018-08-16 01:10:44 --> Controller Class Initialized
INFO - 2018-08-16 01:10:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:10:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:10:44 --> Pixel_Model class loaded
INFO - 2018-08-16 01:10:44 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:10:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:10:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:10:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:10:44 --> Final output sent to browser
DEBUG - 2018-08-16 01:10:44 --> Total execution time: 0.0351
INFO - 2018-08-16 01:10:57 --> Config Class Initialized
INFO - 2018-08-16 01:10:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:10:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:10:57 --> Utf8 Class Initialized
INFO - 2018-08-16 01:10:57 --> URI Class Initialized
INFO - 2018-08-16 01:10:57 --> Router Class Initialized
INFO - 2018-08-16 01:10:57 --> Output Class Initialized
INFO - 2018-08-16 01:10:57 --> Security Class Initialized
DEBUG - 2018-08-16 01:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:10:57 --> CSRF cookie sent
INFO - 2018-08-16 01:10:57 --> CSRF token verified
INFO - 2018-08-16 01:10:57 --> Input Class Initialized
INFO - 2018-08-16 01:10:57 --> Language Class Initialized
INFO - 2018-08-16 01:10:57 --> Loader Class Initialized
INFO - 2018-08-16 01:10:57 --> Helper loaded: url_helper
INFO - 2018-08-16 01:10:57 --> Helper loaded: form_helper
INFO - 2018-08-16 01:10:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:10:57 --> User Agent Class Initialized
INFO - 2018-08-16 01:10:57 --> Controller Class Initialized
INFO - 2018-08-16 01:10:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:10:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:10:57 --> Pixel_Model class loaded
INFO - 2018-08-16 01:10:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:58 --> Config Class Initialized
INFO - 2018-08-16 01:10:58 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:10:58 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:10:58 --> Utf8 Class Initialized
INFO - 2018-08-16 01:10:58 --> URI Class Initialized
INFO - 2018-08-16 01:10:58 --> Router Class Initialized
INFO - 2018-08-16 01:10:58 --> Output Class Initialized
INFO - 2018-08-16 01:10:58 --> Security Class Initialized
DEBUG - 2018-08-16 01:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:10:58 --> CSRF cookie sent
INFO - 2018-08-16 01:10:58 --> Input Class Initialized
INFO - 2018-08-16 01:10:58 --> Language Class Initialized
INFO - 2018-08-16 01:10:58 --> Loader Class Initialized
INFO - 2018-08-16 01:10:58 --> Helper loaded: url_helper
INFO - 2018-08-16 01:10:58 --> Helper loaded: form_helper
INFO - 2018-08-16 01:10:58 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:10:58 --> User Agent Class Initialized
INFO - 2018-08-16 01:10:58 --> Controller Class Initialized
INFO - 2018-08-16 01:10:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:10:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:10:58 --> Pixel_Model class loaded
INFO - 2018-08-16 01:10:58 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:58 --> Database Driver Class Initialized
INFO - 2018-08-16 01:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 01:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:10:58 --> Final output sent to browser
DEBUG - 2018-08-16 01:10:58 --> Total execution time: 0.0381
INFO - 2018-08-16 01:11:20 --> Config Class Initialized
INFO - 2018-08-16 01:11:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:20 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:20 --> URI Class Initialized
INFO - 2018-08-16 01:11:20 --> Router Class Initialized
INFO - 2018-08-16 01:11:20 --> Output Class Initialized
INFO - 2018-08-16 01:11:20 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:20 --> CSRF cookie sent
INFO - 2018-08-16 01:11:20 --> CSRF token verified
INFO - 2018-08-16 01:11:20 --> Input Class Initialized
INFO - 2018-08-16 01:11:20 --> Language Class Initialized
INFO - 2018-08-16 01:11:20 --> Loader Class Initialized
INFO - 2018-08-16 01:11:20 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:20 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:20 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:20 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:20 --> Controller Class Initialized
INFO - 2018-08-16 01:11:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:20 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:20 --> Form Validation Class Initialized
INFO - 2018-08-16 01:11:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:11:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:20 --> Config Class Initialized
INFO - 2018-08-16 01:11:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:20 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:20 --> URI Class Initialized
INFO - 2018-08-16 01:11:20 --> Router Class Initialized
INFO - 2018-08-16 01:11:20 --> Output Class Initialized
INFO - 2018-08-16 01:11:20 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:20 --> CSRF cookie sent
INFO - 2018-08-16 01:11:20 --> Input Class Initialized
INFO - 2018-08-16 01:11:20 --> Language Class Initialized
INFO - 2018-08-16 01:11:20 --> Loader Class Initialized
INFO - 2018-08-16 01:11:20 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:20 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:20 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:20 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:20 --> Controller Class Initialized
INFO - 2018-08-16 01:11:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:20 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 01:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:11:20 --> Final output sent to browser
DEBUG - 2018-08-16 01:11:20 --> Total execution time: 0.0453
INFO - 2018-08-16 01:11:36 --> Config Class Initialized
INFO - 2018-08-16 01:11:36 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:36 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:36 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:36 --> URI Class Initialized
INFO - 2018-08-16 01:11:36 --> Router Class Initialized
INFO - 2018-08-16 01:11:36 --> Output Class Initialized
INFO - 2018-08-16 01:11:36 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:36 --> CSRF cookie sent
INFO - 2018-08-16 01:11:36 --> CSRF token verified
INFO - 2018-08-16 01:11:36 --> Input Class Initialized
INFO - 2018-08-16 01:11:36 --> Language Class Initialized
INFO - 2018-08-16 01:11:36 --> Loader Class Initialized
INFO - 2018-08-16 01:11:36 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:36 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:36 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:36 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:36 --> Controller Class Initialized
INFO - 2018-08-16 01:11:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:36 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:36 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:36 --> Form Validation Class Initialized
INFO - 2018-08-16 01:11:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:11:36 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:37 --> Config Class Initialized
INFO - 2018-08-16 01:11:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:37 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:37 --> URI Class Initialized
INFO - 2018-08-16 01:11:37 --> Router Class Initialized
INFO - 2018-08-16 01:11:37 --> Output Class Initialized
INFO - 2018-08-16 01:11:37 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:37 --> CSRF cookie sent
INFO - 2018-08-16 01:11:37 --> Input Class Initialized
INFO - 2018-08-16 01:11:37 --> Language Class Initialized
INFO - 2018-08-16 01:11:37 --> Loader Class Initialized
INFO - 2018-08-16 01:11:37 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:37 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:37 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:37 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:37 --> Controller Class Initialized
INFO - 2018-08-16 01:11:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:37 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:37 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:37 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 01:11:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:11:37 --> Final output sent to browser
DEBUG - 2018-08-16 01:11:37 --> Total execution time: 0.0377
INFO - 2018-08-16 01:11:45 --> Config Class Initialized
INFO - 2018-08-16 01:11:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:45 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:45 --> URI Class Initialized
INFO - 2018-08-16 01:11:45 --> Router Class Initialized
INFO - 2018-08-16 01:11:45 --> Output Class Initialized
INFO - 2018-08-16 01:11:45 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:45 --> CSRF cookie sent
INFO - 2018-08-16 01:11:45 --> CSRF token verified
INFO - 2018-08-16 01:11:45 --> Input Class Initialized
INFO - 2018-08-16 01:11:45 --> Language Class Initialized
INFO - 2018-08-16 01:11:45 --> Loader Class Initialized
INFO - 2018-08-16 01:11:45 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:45 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:45 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:45 --> Controller Class Initialized
INFO - 2018-08-16 01:11:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:45 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:45 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:45 --> Form Validation Class Initialized
INFO - 2018-08-16 01:11:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:11:45 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:45 --> Config Class Initialized
INFO - 2018-08-16 01:11:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:11:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:11:45 --> Utf8 Class Initialized
INFO - 2018-08-16 01:11:45 --> URI Class Initialized
INFO - 2018-08-16 01:11:45 --> Router Class Initialized
INFO - 2018-08-16 01:11:45 --> Output Class Initialized
INFO - 2018-08-16 01:11:45 --> Security Class Initialized
DEBUG - 2018-08-16 01:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:11:45 --> CSRF cookie sent
INFO - 2018-08-16 01:11:45 --> Input Class Initialized
INFO - 2018-08-16 01:11:45 --> Language Class Initialized
INFO - 2018-08-16 01:11:45 --> Loader Class Initialized
INFO - 2018-08-16 01:11:45 --> Helper loaded: url_helper
INFO - 2018-08-16 01:11:45 --> Helper loaded: form_helper
INFO - 2018-08-16 01:11:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:11:45 --> User Agent Class Initialized
INFO - 2018-08-16 01:11:45 --> Controller Class Initialized
INFO - 2018-08-16 01:11:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:11:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:11:45 --> Pixel_Model class loaded
INFO - 2018-08-16 01:11:45 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:45 --> Database Driver Class Initialized
INFO - 2018-08-16 01:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 01:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:11:45 --> Final output sent to browser
DEBUG - 2018-08-16 01:11:45 --> Total execution time: 0.0508
INFO - 2018-08-16 01:12:02 --> Config Class Initialized
INFO - 2018-08-16 01:12:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:12:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:12:02 --> Utf8 Class Initialized
INFO - 2018-08-16 01:12:02 --> URI Class Initialized
INFO - 2018-08-16 01:12:02 --> Router Class Initialized
INFO - 2018-08-16 01:12:02 --> Output Class Initialized
INFO - 2018-08-16 01:12:02 --> Security Class Initialized
DEBUG - 2018-08-16 01:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:12:02 --> CSRF cookie sent
INFO - 2018-08-16 01:12:02 --> CSRF token verified
INFO - 2018-08-16 01:12:02 --> Input Class Initialized
INFO - 2018-08-16 01:12:02 --> Language Class Initialized
INFO - 2018-08-16 01:12:02 --> Loader Class Initialized
INFO - 2018-08-16 01:12:02 --> Helper loaded: url_helper
INFO - 2018-08-16 01:12:02 --> Helper loaded: form_helper
INFO - 2018-08-16 01:12:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:12:02 --> User Agent Class Initialized
INFO - 2018-08-16 01:12:02 --> Controller Class Initialized
INFO - 2018-08-16 01:12:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:12:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:12:02 --> Pixel_Model class loaded
INFO - 2018-08-16 01:12:02 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:02 --> Form Validation Class Initialized
INFO - 2018-08-16 01:12:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:12:02 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:02 --> Config Class Initialized
INFO - 2018-08-16 01:12:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:12:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:12:02 --> Utf8 Class Initialized
INFO - 2018-08-16 01:12:02 --> URI Class Initialized
INFO - 2018-08-16 01:12:02 --> Router Class Initialized
INFO - 2018-08-16 01:12:02 --> Output Class Initialized
INFO - 2018-08-16 01:12:02 --> Security Class Initialized
DEBUG - 2018-08-16 01:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:12:02 --> CSRF cookie sent
INFO - 2018-08-16 01:12:02 --> Input Class Initialized
INFO - 2018-08-16 01:12:02 --> Language Class Initialized
INFO - 2018-08-16 01:12:02 --> Loader Class Initialized
INFO - 2018-08-16 01:12:02 --> Helper loaded: url_helper
INFO - 2018-08-16 01:12:02 --> Helper loaded: form_helper
INFO - 2018-08-16 01:12:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:12:02 --> User Agent Class Initialized
INFO - 2018-08-16 01:12:02 --> Controller Class Initialized
INFO - 2018-08-16 01:12:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:12:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:12:02 --> Pixel_Model class loaded
INFO - 2018-08-16 01:12:02 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:02 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 01:12:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:12:02 --> Final output sent to browser
DEBUG - 2018-08-16 01:12:02 --> Total execution time: 0.0453
INFO - 2018-08-16 01:12:18 --> Config Class Initialized
INFO - 2018-08-16 01:12:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:12:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:12:18 --> Utf8 Class Initialized
INFO - 2018-08-16 01:12:18 --> URI Class Initialized
INFO - 2018-08-16 01:12:18 --> Router Class Initialized
INFO - 2018-08-16 01:12:18 --> Output Class Initialized
INFO - 2018-08-16 01:12:18 --> Security Class Initialized
DEBUG - 2018-08-16 01:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:12:18 --> CSRF cookie sent
INFO - 2018-08-16 01:12:18 --> Input Class Initialized
INFO - 2018-08-16 01:12:18 --> Language Class Initialized
INFO - 2018-08-16 01:12:18 --> Loader Class Initialized
INFO - 2018-08-16 01:12:18 --> Helper loaded: url_helper
INFO - 2018-08-16 01:12:18 --> Helper loaded: form_helper
INFO - 2018-08-16 01:12:18 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:12:18 --> User Agent Class Initialized
INFO - 2018-08-16 01:12:18 --> Controller Class Initialized
INFO - 2018-08-16 01:12:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:12:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:12:18 --> Pixel_Model class loaded
INFO - 2018-08-16 01:12:18 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:18 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 01:12:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:12:18 --> Final output sent to browser
DEBUG - 2018-08-16 01:12:18 --> Total execution time: 0.0427
INFO - 2018-08-16 01:12:26 --> Config Class Initialized
INFO - 2018-08-16 01:12:26 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:12:26 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:12:26 --> Utf8 Class Initialized
INFO - 2018-08-16 01:12:26 --> URI Class Initialized
INFO - 2018-08-16 01:12:26 --> Router Class Initialized
INFO - 2018-08-16 01:12:26 --> Output Class Initialized
INFO - 2018-08-16 01:12:26 --> Security Class Initialized
DEBUG - 2018-08-16 01:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:12:26 --> CSRF cookie sent
INFO - 2018-08-16 01:12:26 --> Input Class Initialized
INFO - 2018-08-16 01:12:26 --> Language Class Initialized
INFO - 2018-08-16 01:12:26 --> Loader Class Initialized
INFO - 2018-08-16 01:12:26 --> Helper loaded: url_helper
INFO - 2018-08-16 01:12:26 --> Helper loaded: form_helper
INFO - 2018-08-16 01:12:26 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:12:26 --> User Agent Class Initialized
INFO - 2018-08-16 01:12:26 --> Controller Class Initialized
INFO - 2018-08-16 01:12:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:12:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:12:26 --> Pixel_Model class loaded
INFO - 2018-08-16 01:12:26 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:26 --> Database Driver Class Initialized
INFO - 2018-08-16 01:12:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 01:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:12:26 --> Final output sent to browser
DEBUG - 2018-08-16 01:12:26 --> Total execution time: 0.0418
INFO - 2018-08-16 01:19:16 --> Config Class Initialized
INFO - 2018-08-16 01:19:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:19:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:19:16 --> Utf8 Class Initialized
INFO - 2018-08-16 01:19:16 --> URI Class Initialized
DEBUG - 2018-08-16 01:19:16 --> No URI present. Default controller set.
INFO - 2018-08-16 01:19:16 --> Router Class Initialized
INFO - 2018-08-16 01:19:16 --> Output Class Initialized
INFO - 2018-08-16 01:19:16 --> Security Class Initialized
DEBUG - 2018-08-16 01:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:19:16 --> CSRF cookie sent
INFO - 2018-08-16 01:19:16 --> Input Class Initialized
INFO - 2018-08-16 01:19:16 --> Language Class Initialized
INFO - 2018-08-16 01:19:16 --> Loader Class Initialized
INFO - 2018-08-16 01:19:16 --> Helper loaded: url_helper
INFO - 2018-08-16 01:19:16 --> Helper loaded: form_helper
INFO - 2018-08-16 01:19:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:19:16 --> User Agent Class Initialized
INFO - 2018-08-16 01:19:16 --> Controller Class Initialized
INFO - 2018-08-16 01:19:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:19:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:19:16 --> Pixel_Model class loaded
INFO - 2018-08-16 01:19:16 --> Database Driver Class Initialized
INFO - 2018-08-16 01:19:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:19:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:19:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:19:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:19:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:19:16 --> Final output sent to browser
DEBUG - 2018-08-16 01:19:16 --> Total execution time: 0.0334
INFO - 2018-08-16 01:19:18 --> Config Class Initialized
INFO - 2018-08-16 01:19:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:19:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:19:18 --> Utf8 Class Initialized
INFO - 2018-08-16 01:19:18 --> URI Class Initialized
DEBUG - 2018-08-16 01:19:18 --> No URI present. Default controller set.
INFO - 2018-08-16 01:19:18 --> Router Class Initialized
INFO - 2018-08-16 01:19:18 --> Output Class Initialized
INFO - 2018-08-16 01:19:18 --> Security Class Initialized
DEBUG - 2018-08-16 01:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:19:18 --> CSRF cookie sent
INFO - 2018-08-16 01:19:18 --> Input Class Initialized
INFO - 2018-08-16 01:19:18 --> Language Class Initialized
INFO - 2018-08-16 01:19:18 --> Loader Class Initialized
INFO - 2018-08-16 01:19:18 --> Helper loaded: url_helper
INFO - 2018-08-16 01:19:18 --> Helper loaded: form_helper
INFO - 2018-08-16 01:19:18 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:19:18 --> User Agent Class Initialized
INFO - 2018-08-16 01:19:18 --> Controller Class Initialized
INFO - 2018-08-16 01:19:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:19:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:19:18 --> Pixel_Model class loaded
INFO - 2018-08-16 01:19:18 --> Database Driver Class Initialized
INFO - 2018-08-16 01:19:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:19:18 --> Final output sent to browser
DEBUG - 2018-08-16 01:19:18 --> Total execution time: 0.0327
INFO - 2018-08-16 01:21:35 --> Config Class Initialized
INFO - 2018-08-16 01:21:35 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:21:35 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:21:35 --> Utf8 Class Initialized
INFO - 2018-08-16 01:21:35 --> URI Class Initialized
INFO - 2018-08-16 01:21:35 --> Router Class Initialized
INFO - 2018-08-16 01:21:35 --> Output Class Initialized
INFO - 2018-08-16 01:21:35 --> Security Class Initialized
DEBUG - 2018-08-16 01:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:21:35 --> CSRF cookie sent
INFO - 2018-08-16 01:21:35 --> CSRF token verified
INFO - 2018-08-16 01:21:35 --> Input Class Initialized
INFO - 2018-08-16 01:21:35 --> Language Class Initialized
INFO - 2018-08-16 01:21:35 --> Loader Class Initialized
INFO - 2018-08-16 01:21:35 --> Helper loaded: url_helper
INFO - 2018-08-16 01:21:35 --> Helper loaded: form_helper
INFO - 2018-08-16 01:21:35 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:21:35 --> User Agent Class Initialized
INFO - 2018-08-16 01:21:35 --> Controller Class Initialized
INFO - 2018-08-16 01:21:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:21:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:21:35 --> Pixel_Model class loaded
INFO - 2018-08-16 01:21:35 --> Database Driver Class Initialized
INFO - 2018-08-16 01:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:21:35 --> Database Driver Class Initialized
INFO - 2018-08-16 01:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:21:35 --> Config Class Initialized
INFO - 2018-08-16 01:21:35 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:21:35 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:21:35 --> Utf8 Class Initialized
INFO - 2018-08-16 01:21:35 --> URI Class Initialized
INFO - 2018-08-16 01:21:35 --> Router Class Initialized
INFO - 2018-08-16 01:21:35 --> Output Class Initialized
INFO - 2018-08-16 01:21:35 --> Security Class Initialized
DEBUG - 2018-08-16 01:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:21:35 --> CSRF cookie sent
INFO - 2018-08-16 01:21:35 --> Input Class Initialized
INFO - 2018-08-16 01:21:35 --> Language Class Initialized
INFO - 2018-08-16 01:21:35 --> Loader Class Initialized
INFO - 2018-08-16 01:21:35 --> Helper loaded: url_helper
INFO - 2018-08-16 01:21:35 --> Helper loaded: form_helper
INFO - 2018-08-16 01:21:35 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:21:35 --> User Agent Class Initialized
INFO - 2018-08-16 01:21:35 --> Controller Class Initialized
INFO - 2018-08-16 01:21:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:21:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:21:35 --> Pixel_Model class loaded
INFO - 2018-08-16 01:21:35 --> Database Driver Class Initialized
INFO - 2018-08-16 01:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:21:35 --> Database Driver Class Initialized
INFO - 2018-08-16 01:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 01:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:21:35 --> Final output sent to browser
DEBUG - 2018-08-16 01:21:35 --> Total execution time: 0.0601
INFO - 2018-08-16 01:27:49 --> Config Class Initialized
INFO - 2018-08-16 01:27:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:27:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:27:49 --> Utf8 Class Initialized
INFO - 2018-08-16 01:27:49 --> URI Class Initialized
DEBUG - 2018-08-16 01:27:49 --> No URI present. Default controller set.
INFO - 2018-08-16 01:27:49 --> Router Class Initialized
INFO - 2018-08-16 01:27:49 --> Output Class Initialized
INFO - 2018-08-16 01:27:49 --> Security Class Initialized
DEBUG - 2018-08-16 01:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:27:49 --> CSRF cookie sent
INFO - 2018-08-16 01:27:49 --> Input Class Initialized
INFO - 2018-08-16 01:27:49 --> Language Class Initialized
INFO - 2018-08-16 01:27:49 --> Loader Class Initialized
INFO - 2018-08-16 01:27:49 --> Helper loaded: url_helper
INFO - 2018-08-16 01:27:49 --> Helper loaded: form_helper
INFO - 2018-08-16 01:27:49 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:27:49 --> User Agent Class Initialized
INFO - 2018-08-16 01:27:49 --> Controller Class Initialized
INFO - 2018-08-16 01:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:27:49 --> Pixel_Model class loaded
INFO - 2018-08-16 01:27:49 --> Database Driver Class Initialized
INFO - 2018-08-16 01:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:27:49 --> Final output sent to browser
DEBUG - 2018-08-16 01:27:49 --> Total execution time: 0.0348
INFO - 2018-08-16 01:27:50 --> Config Class Initialized
INFO - 2018-08-16 01:27:50 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:27:50 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:27:50 --> Utf8 Class Initialized
INFO - 2018-08-16 01:27:50 --> URI Class Initialized
DEBUG - 2018-08-16 01:27:50 --> No URI present. Default controller set.
INFO - 2018-08-16 01:27:50 --> Router Class Initialized
INFO - 2018-08-16 01:27:50 --> Output Class Initialized
INFO - 2018-08-16 01:27:50 --> Security Class Initialized
DEBUG - 2018-08-16 01:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:27:50 --> CSRF cookie sent
INFO - 2018-08-16 01:27:50 --> Input Class Initialized
INFO - 2018-08-16 01:27:50 --> Language Class Initialized
INFO - 2018-08-16 01:27:50 --> Loader Class Initialized
INFO - 2018-08-16 01:27:50 --> Helper loaded: url_helper
INFO - 2018-08-16 01:27:50 --> Helper loaded: form_helper
INFO - 2018-08-16 01:27:50 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:27:50 --> User Agent Class Initialized
INFO - 2018-08-16 01:27:50 --> Controller Class Initialized
INFO - 2018-08-16 01:27:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:27:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:27:50 --> Pixel_Model class loaded
INFO - 2018-08-16 01:27:50 --> Database Driver Class Initialized
INFO - 2018-08-16 01:27:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:27:50 --> Final output sent to browser
DEBUG - 2018-08-16 01:27:50 --> Total execution time: 0.0356
INFO - 2018-08-16 01:35:00 --> Config Class Initialized
INFO - 2018-08-16 01:35:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:00 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:00 --> URI Class Initialized
DEBUG - 2018-08-16 01:35:00 --> No URI present. Default controller set.
INFO - 2018-08-16 01:35:00 --> Router Class Initialized
INFO - 2018-08-16 01:35:00 --> Output Class Initialized
INFO - 2018-08-16 01:35:00 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:00 --> CSRF cookie sent
INFO - 2018-08-16 01:35:00 --> Input Class Initialized
INFO - 2018-08-16 01:35:00 --> Language Class Initialized
INFO - 2018-08-16 01:35:00 --> Loader Class Initialized
INFO - 2018-08-16 01:35:00 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:00 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:00 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:00 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:00 --> Controller Class Initialized
INFO - 2018-08-16 01:35:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:00 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:00 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:35:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:00 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:00 --> Total execution time: 0.0319
INFO - 2018-08-16 01:35:03 --> Config Class Initialized
INFO - 2018-08-16 01:35:03 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:03 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:03 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:03 --> URI Class Initialized
DEBUG - 2018-08-16 01:35:03 --> No URI present. Default controller set.
INFO - 2018-08-16 01:35:03 --> Router Class Initialized
INFO - 2018-08-16 01:35:03 --> Output Class Initialized
INFO - 2018-08-16 01:35:03 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:03 --> CSRF cookie sent
INFO - 2018-08-16 01:35:03 --> Input Class Initialized
INFO - 2018-08-16 01:35:03 --> Language Class Initialized
INFO - 2018-08-16 01:35:03 --> Loader Class Initialized
INFO - 2018-08-16 01:35:03 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:03 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:03 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:03 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:03 --> Controller Class Initialized
INFO - 2018-08-16 01:35:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:03 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:03 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 01:35:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:03 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:03 --> Total execution time: 0.0378
INFO - 2018-08-16 01:35:08 --> Config Class Initialized
INFO - 2018-08-16 01:35:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:08 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:08 --> URI Class Initialized
INFO - 2018-08-16 01:35:08 --> Router Class Initialized
INFO - 2018-08-16 01:35:08 --> Output Class Initialized
INFO - 2018-08-16 01:35:08 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:08 --> CSRF cookie sent
INFO - 2018-08-16 01:35:08 --> CSRF token verified
INFO - 2018-08-16 01:35:08 --> Input Class Initialized
INFO - 2018-08-16 01:35:08 --> Language Class Initialized
INFO - 2018-08-16 01:35:08 --> Loader Class Initialized
INFO - 2018-08-16 01:35:08 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:08 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:08 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:08 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:08 --> Controller Class Initialized
INFO - 2018-08-16 01:35:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:08 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:09 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:09 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:09 --> Config Class Initialized
INFO - 2018-08-16 01:35:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:09 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:09 --> URI Class Initialized
INFO - 2018-08-16 01:35:09 --> Router Class Initialized
INFO - 2018-08-16 01:35:09 --> Output Class Initialized
INFO - 2018-08-16 01:35:09 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:09 --> CSRF cookie sent
INFO - 2018-08-16 01:35:09 --> Input Class Initialized
INFO - 2018-08-16 01:35:09 --> Language Class Initialized
INFO - 2018-08-16 01:35:09 --> Loader Class Initialized
INFO - 2018-08-16 01:35:09 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:09 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:09 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:09 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:09 --> Controller Class Initialized
INFO - 2018-08-16 01:35:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:09 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:09 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:09 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 01:35:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:09 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:09 --> Total execution time: 0.0466
INFO - 2018-08-16 01:35:15 --> Config Class Initialized
INFO - 2018-08-16 01:35:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:15 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:15 --> URI Class Initialized
INFO - 2018-08-16 01:35:15 --> Router Class Initialized
INFO - 2018-08-16 01:35:15 --> Output Class Initialized
INFO - 2018-08-16 01:35:15 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:15 --> CSRF cookie sent
INFO - 2018-08-16 01:35:15 --> CSRF token verified
INFO - 2018-08-16 01:35:15 --> Input Class Initialized
INFO - 2018-08-16 01:35:15 --> Language Class Initialized
INFO - 2018-08-16 01:35:15 --> Loader Class Initialized
INFO - 2018-08-16 01:35:15 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:15 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:15 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:15 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:15 --> Controller Class Initialized
INFO - 2018-08-16 01:35:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:15 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:15 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:15 --> Form Validation Class Initialized
INFO - 2018-08-16 01:35:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:35:15 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 01:35:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:15 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:15 --> Total execution time: 0.0590
INFO - 2018-08-16 01:35:20 --> Config Class Initialized
INFO - 2018-08-16 01:35:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:20 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:20 --> URI Class Initialized
INFO - 2018-08-16 01:35:20 --> Router Class Initialized
INFO - 2018-08-16 01:35:20 --> Output Class Initialized
INFO - 2018-08-16 01:35:20 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:20 --> CSRF cookie sent
INFO - 2018-08-16 01:35:20 --> CSRF token verified
INFO - 2018-08-16 01:35:20 --> Input Class Initialized
INFO - 2018-08-16 01:35:20 --> Language Class Initialized
INFO - 2018-08-16 01:35:20 --> Loader Class Initialized
INFO - 2018-08-16 01:35:20 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:20 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:20 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:20 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:20 --> Controller Class Initialized
INFO - 2018-08-16 01:35:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:20 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:20 --> Form Validation Class Initialized
INFO - 2018-08-16 01:35:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:35:20 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:21 --> Config Class Initialized
INFO - 2018-08-16 01:35:21 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:21 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:21 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:21 --> URI Class Initialized
INFO - 2018-08-16 01:35:21 --> Router Class Initialized
INFO - 2018-08-16 01:35:21 --> Output Class Initialized
INFO - 2018-08-16 01:35:21 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:21 --> CSRF cookie sent
INFO - 2018-08-16 01:35:21 --> Input Class Initialized
INFO - 2018-08-16 01:35:21 --> Language Class Initialized
INFO - 2018-08-16 01:35:21 --> Loader Class Initialized
INFO - 2018-08-16 01:35:21 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:21 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:21 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:21 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:21 --> Controller Class Initialized
INFO - 2018-08-16 01:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:21 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:21 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:21 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 01:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:21 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:21 --> Total execution time: 0.0456
INFO - 2018-08-16 01:35:30 --> Config Class Initialized
INFO - 2018-08-16 01:35:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:30 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:30 --> URI Class Initialized
INFO - 2018-08-16 01:35:30 --> Router Class Initialized
INFO - 2018-08-16 01:35:30 --> Output Class Initialized
INFO - 2018-08-16 01:35:30 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:30 --> CSRF cookie sent
INFO - 2018-08-16 01:35:30 --> CSRF token verified
INFO - 2018-08-16 01:35:30 --> Input Class Initialized
INFO - 2018-08-16 01:35:30 --> Language Class Initialized
INFO - 2018-08-16 01:35:30 --> Loader Class Initialized
INFO - 2018-08-16 01:35:30 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:30 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:30 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:30 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:30 --> Controller Class Initialized
INFO - 2018-08-16 01:35:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:30 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:30 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:30 --> Form Validation Class Initialized
INFO - 2018-08-16 01:35:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:35:30 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:30 --> Config Class Initialized
INFO - 2018-08-16 01:35:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:35:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:35:30 --> Utf8 Class Initialized
INFO - 2018-08-16 01:35:30 --> URI Class Initialized
INFO - 2018-08-16 01:35:30 --> Router Class Initialized
INFO - 2018-08-16 01:35:30 --> Output Class Initialized
INFO - 2018-08-16 01:35:30 --> Security Class Initialized
DEBUG - 2018-08-16 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:35:30 --> CSRF cookie sent
INFO - 2018-08-16 01:35:30 --> Input Class Initialized
INFO - 2018-08-16 01:35:30 --> Language Class Initialized
INFO - 2018-08-16 01:35:30 --> Loader Class Initialized
INFO - 2018-08-16 01:35:30 --> Helper loaded: url_helper
INFO - 2018-08-16 01:35:30 --> Helper loaded: form_helper
INFO - 2018-08-16 01:35:30 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:35:30 --> User Agent Class Initialized
INFO - 2018-08-16 01:35:30 --> Controller Class Initialized
INFO - 2018-08-16 01:35:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:35:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:35:30 --> Pixel_Model class loaded
INFO - 2018-08-16 01:35:30 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:30 --> Database Driver Class Initialized
INFO - 2018-08-16 01:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 01:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:35:30 --> Final output sent to browser
DEBUG - 2018-08-16 01:35:30 --> Total execution time: 0.0400
INFO - 2018-08-16 01:39:57 --> Config Class Initialized
INFO - 2018-08-16 01:39:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:39:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:39:57 --> Utf8 Class Initialized
INFO - 2018-08-16 01:39:57 --> URI Class Initialized
INFO - 2018-08-16 01:39:57 --> Router Class Initialized
INFO - 2018-08-16 01:39:57 --> Output Class Initialized
INFO - 2018-08-16 01:39:57 --> Security Class Initialized
DEBUG - 2018-08-16 01:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:39:57 --> CSRF cookie sent
INFO - 2018-08-16 01:39:57 --> CSRF token verified
INFO - 2018-08-16 01:39:57 --> Input Class Initialized
INFO - 2018-08-16 01:39:57 --> Language Class Initialized
INFO - 2018-08-16 01:39:57 --> Loader Class Initialized
INFO - 2018-08-16 01:39:57 --> Helper loaded: url_helper
INFO - 2018-08-16 01:39:57 --> Helper loaded: form_helper
INFO - 2018-08-16 01:39:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:39:57 --> User Agent Class Initialized
INFO - 2018-08-16 01:39:57 --> Controller Class Initialized
INFO - 2018-08-16 01:39:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:39:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:39:57 --> Pixel_Model class loaded
INFO - 2018-08-16 01:39:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:39:57 --> Form Validation Class Initialized
INFO - 2018-08-16 01:39:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:39:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:39:57 --> Config Class Initialized
INFO - 2018-08-16 01:39:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:39:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:39:57 --> Utf8 Class Initialized
INFO - 2018-08-16 01:39:57 --> URI Class Initialized
INFO - 2018-08-16 01:39:57 --> Router Class Initialized
INFO - 2018-08-16 01:39:57 --> Output Class Initialized
INFO - 2018-08-16 01:39:57 --> Security Class Initialized
DEBUG - 2018-08-16 01:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:39:57 --> CSRF cookie sent
INFO - 2018-08-16 01:39:57 --> Input Class Initialized
INFO - 2018-08-16 01:39:57 --> Language Class Initialized
INFO - 2018-08-16 01:39:57 --> Loader Class Initialized
INFO - 2018-08-16 01:39:57 --> Helper loaded: url_helper
INFO - 2018-08-16 01:39:57 --> Helper loaded: form_helper
INFO - 2018-08-16 01:39:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:39:57 --> User Agent Class Initialized
INFO - 2018-08-16 01:39:57 --> Controller Class Initialized
INFO - 2018-08-16 01:39:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:39:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:39:57 --> Pixel_Model class loaded
INFO - 2018-08-16 01:39:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:39:57 --> Database Driver Class Initialized
INFO - 2018-08-16 01:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 01:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:39:57 --> Final output sent to browser
DEBUG - 2018-08-16 01:39:57 --> Total execution time: 0.0337
INFO - 2018-08-16 01:40:05 --> Config Class Initialized
INFO - 2018-08-16 01:40:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:40:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:40:05 --> Utf8 Class Initialized
INFO - 2018-08-16 01:40:05 --> URI Class Initialized
INFO - 2018-08-16 01:40:05 --> Router Class Initialized
INFO - 2018-08-16 01:40:05 --> Output Class Initialized
INFO - 2018-08-16 01:40:05 --> Security Class Initialized
DEBUG - 2018-08-16 01:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:40:05 --> CSRF cookie sent
INFO - 2018-08-16 01:40:05 --> CSRF token verified
INFO - 2018-08-16 01:40:05 --> Input Class Initialized
INFO - 2018-08-16 01:40:05 --> Language Class Initialized
INFO - 2018-08-16 01:40:05 --> Loader Class Initialized
INFO - 2018-08-16 01:40:05 --> Helper loaded: url_helper
INFO - 2018-08-16 01:40:05 --> Helper loaded: form_helper
INFO - 2018-08-16 01:40:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:40:05 --> User Agent Class Initialized
INFO - 2018-08-16 01:40:05 --> Controller Class Initialized
INFO - 2018-08-16 01:40:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:40:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:40:05 --> Pixel_Model class loaded
INFO - 2018-08-16 01:40:05 --> Database Driver Class Initialized
INFO - 2018-08-16 01:40:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:40:05 --> Form Validation Class Initialized
INFO - 2018-08-16 01:40:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 01:40:05 --> Database Driver Class Initialized
INFO - 2018-08-16 01:40:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:40:05 --> Config Class Initialized
INFO - 2018-08-16 01:40:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 01:40:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 01:40:05 --> Utf8 Class Initialized
INFO - 2018-08-16 01:40:05 --> URI Class Initialized
INFO - 2018-08-16 01:40:05 --> Router Class Initialized
INFO - 2018-08-16 01:40:05 --> Output Class Initialized
INFO - 2018-08-16 01:40:05 --> Security Class Initialized
DEBUG - 2018-08-16 01:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 01:40:05 --> CSRF cookie sent
INFO - 2018-08-16 01:40:05 --> Input Class Initialized
INFO - 2018-08-16 01:40:05 --> Language Class Initialized
INFO - 2018-08-16 01:40:05 --> Loader Class Initialized
INFO - 2018-08-16 01:40:05 --> Helper loaded: url_helper
INFO - 2018-08-16 01:40:05 --> Helper loaded: form_helper
INFO - 2018-08-16 01:40:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 01:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 01:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 01:40:05 --> User Agent Class Initialized
INFO - 2018-08-16 01:40:05 --> Controller Class Initialized
INFO - 2018-08-16 01:40:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 01:40:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 01:40:05 --> Pixel_Model class loaded
INFO - 2018-08-16 01:40:05 --> Database Driver Class Initialized
INFO - 2018-08-16 01:40:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:40:05 --> Database Driver Class Initialized
INFO - 2018-08-16 01:40:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 01:40:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 01:40:05 --> Final output sent to browser
DEBUG - 2018-08-16 01:40:05 --> Total execution time: 0.0447
INFO - 2018-08-16 13:31:02 --> Config Class Initialized
INFO - 2018-08-16 13:31:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:31:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:31:02 --> Utf8 Class Initialized
INFO - 2018-08-16 13:31:02 --> URI Class Initialized
DEBUG - 2018-08-16 13:31:02 --> No URI present. Default controller set.
INFO - 2018-08-16 13:31:02 --> Router Class Initialized
INFO - 2018-08-16 13:31:02 --> Output Class Initialized
INFO - 2018-08-16 13:31:02 --> Security Class Initialized
DEBUG - 2018-08-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:31:02 --> CSRF cookie sent
INFO - 2018-08-16 13:31:02 --> Input Class Initialized
INFO - 2018-08-16 13:31:02 --> Language Class Initialized
INFO - 2018-08-16 13:31:02 --> Loader Class Initialized
INFO - 2018-08-16 13:31:02 --> Helper loaded: url_helper
INFO - 2018-08-16 13:31:02 --> Helper loaded: form_helper
INFO - 2018-08-16 13:31:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:31:02 --> User Agent Class Initialized
INFO - 2018-08-16 13:31:02 --> Controller Class Initialized
INFO - 2018-08-16 13:31:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:31:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:31:02 --> Pixel_Model class loaded
INFO - 2018-08-16 13:31:02 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:31:02 --> Final output sent to browser
DEBUG - 2018-08-16 13:31:02 --> Total execution time: 0.0368
INFO - 2018-08-16 13:31:02 --> Config Class Initialized
INFO - 2018-08-16 13:31:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:31:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:31:02 --> Utf8 Class Initialized
INFO - 2018-08-16 13:31:02 --> URI Class Initialized
DEBUG - 2018-08-16 13:31:02 --> No URI present. Default controller set.
INFO - 2018-08-16 13:31:02 --> Router Class Initialized
INFO - 2018-08-16 13:31:02 --> Output Class Initialized
INFO - 2018-08-16 13:31:02 --> Security Class Initialized
DEBUG - 2018-08-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:31:02 --> CSRF cookie sent
INFO - 2018-08-16 13:31:02 --> Input Class Initialized
INFO - 2018-08-16 13:31:02 --> Language Class Initialized
INFO - 2018-08-16 13:31:02 --> Loader Class Initialized
INFO - 2018-08-16 13:31:02 --> Helper loaded: url_helper
INFO - 2018-08-16 13:31:02 --> Helper loaded: form_helper
INFO - 2018-08-16 13:31:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:31:02 --> User Agent Class Initialized
INFO - 2018-08-16 13:31:02 --> Controller Class Initialized
INFO - 2018-08-16 13:31:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:31:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:31:02 --> Pixel_Model class loaded
INFO - 2018-08-16 13:31:02 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 13:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:31:02 --> Final output sent to browser
DEBUG - 2018-08-16 13:31:02 --> Total execution time: 0.0370
INFO - 2018-08-16 13:31:52 --> Config Class Initialized
INFO - 2018-08-16 13:31:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:31:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:31:52 --> Utf8 Class Initialized
INFO - 2018-08-16 13:31:52 --> URI Class Initialized
INFO - 2018-08-16 13:31:52 --> Router Class Initialized
INFO - 2018-08-16 13:31:52 --> Output Class Initialized
INFO - 2018-08-16 13:31:52 --> Security Class Initialized
DEBUG - 2018-08-16 13:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:31:52 --> CSRF cookie sent
INFO - 2018-08-16 13:31:52 --> CSRF token verified
INFO - 2018-08-16 13:31:52 --> Input Class Initialized
INFO - 2018-08-16 13:31:52 --> Language Class Initialized
INFO - 2018-08-16 13:31:52 --> Loader Class Initialized
INFO - 2018-08-16 13:31:52 --> Helper loaded: url_helper
INFO - 2018-08-16 13:31:52 --> Helper loaded: form_helper
INFO - 2018-08-16 13:31:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:31:52 --> User Agent Class Initialized
INFO - 2018-08-16 13:31:52 --> Controller Class Initialized
INFO - 2018-08-16 13:31:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:31:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:31:52 --> Pixel_Model class loaded
INFO - 2018-08-16 13:31:52 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:52 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:52 --> Config Class Initialized
INFO - 2018-08-16 13:31:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:31:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:31:52 --> Utf8 Class Initialized
INFO - 2018-08-16 13:31:52 --> URI Class Initialized
INFO - 2018-08-16 13:31:52 --> Router Class Initialized
INFO - 2018-08-16 13:31:52 --> Output Class Initialized
INFO - 2018-08-16 13:31:52 --> Security Class Initialized
DEBUG - 2018-08-16 13:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:31:52 --> CSRF cookie sent
INFO - 2018-08-16 13:31:52 --> Input Class Initialized
INFO - 2018-08-16 13:31:52 --> Language Class Initialized
INFO - 2018-08-16 13:31:52 --> Loader Class Initialized
INFO - 2018-08-16 13:31:52 --> Helper loaded: url_helper
INFO - 2018-08-16 13:31:52 --> Helper loaded: form_helper
INFO - 2018-08-16 13:31:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:31:52 --> User Agent Class Initialized
INFO - 2018-08-16 13:31:52 --> Controller Class Initialized
INFO - 2018-08-16 13:31:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:31:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:31:52 --> Pixel_Model class loaded
INFO - 2018-08-16 13:31:52 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:52 --> Database Driver Class Initialized
INFO - 2018-08-16 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 13:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:31:52 --> Final output sent to browser
DEBUG - 2018-08-16 13:31:52 --> Total execution time: 0.0495
INFO - 2018-08-16 13:32:00 --> Config Class Initialized
INFO - 2018-08-16 13:32:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:32:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:32:00 --> Utf8 Class Initialized
INFO - 2018-08-16 13:32:00 --> URI Class Initialized
DEBUG - 2018-08-16 13:32:00 --> No URI present. Default controller set.
INFO - 2018-08-16 13:32:00 --> Router Class Initialized
INFO - 2018-08-16 13:32:00 --> Output Class Initialized
INFO - 2018-08-16 13:32:00 --> Security Class Initialized
DEBUG - 2018-08-16 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:32:00 --> CSRF cookie sent
INFO - 2018-08-16 13:32:00 --> Input Class Initialized
INFO - 2018-08-16 13:32:00 --> Language Class Initialized
INFO - 2018-08-16 13:32:00 --> Loader Class Initialized
INFO - 2018-08-16 13:32:00 --> Helper loaded: url_helper
INFO - 2018-08-16 13:32:00 --> Helper loaded: form_helper
INFO - 2018-08-16 13:32:00 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:32:00 --> User Agent Class Initialized
INFO - 2018-08-16 13:32:00 --> Controller Class Initialized
INFO - 2018-08-16 13:32:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:32:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:32:00 --> Pixel_Model class loaded
INFO - 2018-08-16 13:32:00 --> Database Driver Class Initialized
INFO - 2018-08-16 13:32:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 13:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:32:00 --> Final output sent to browser
DEBUG - 2018-08-16 13:32:00 --> Total execution time: 0.0399
INFO - 2018-08-16 13:36:27 --> Config Class Initialized
INFO - 2018-08-16 13:36:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:36:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:36:27 --> Utf8 Class Initialized
INFO - 2018-08-16 13:36:27 --> URI Class Initialized
INFO - 2018-08-16 13:36:27 --> Router Class Initialized
INFO - 2018-08-16 13:36:27 --> Output Class Initialized
INFO - 2018-08-16 13:36:27 --> Security Class Initialized
DEBUG - 2018-08-16 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:36:27 --> CSRF cookie sent
INFO - 2018-08-16 13:36:27 --> CSRF token verified
INFO - 2018-08-16 13:36:27 --> Input Class Initialized
INFO - 2018-08-16 13:36:27 --> Language Class Initialized
INFO - 2018-08-16 13:36:27 --> Loader Class Initialized
INFO - 2018-08-16 13:36:27 --> Helper loaded: url_helper
INFO - 2018-08-16 13:36:27 --> Helper loaded: form_helper
INFO - 2018-08-16 13:36:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:36:27 --> User Agent Class Initialized
INFO - 2018-08-16 13:36:27 --> Controller Class Initialized
INFO - 2018-08-16 13:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:36:27 --> Pixel_Model class loaded
INFO - 2018-08-16 13:36:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:36:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:36:27 --> Config Class Initialized
INFO - 2018-08-16 13:36:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:36:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:36:27 --> Utf8 Class Initialized
INFO - 2018-08-16 13:36:27 --> URI Class Initialized
INFO - 2018-08-16 13:36:27 --> Router Class Initialized
INFO - 2018-08-16 13:36:27 --> Output Class Initialized
INFO - 2018-08-16 13:36:27 --> Security Class Initialized
DEBUG - 2018-08-16 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:36:27 --> CSRF cookie sent
INFO - 2018-08-16 13:36:27 --> Input Class Initialized
INFO - 2018-08-16 13:36:27 --> Language Class Initialized
INFO - 2018-08-16 13:36:27 --> Loader Class Initialized
INFO - 2018-08-16 13:36:27 --> Helper loaded: url_helper
INFO - 2018-08-16 13:36:27 --> Helper loaded: form_helper
INFO - 2018-08-16 13:36:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:36:27 --> User Agent Class Initialized
INFO - 2018-08-16 13:36:27 --> Controller Class Initialized
INFO - 2018-08-16 13:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:36:27 --> Pixel_Model class loaded
INFO - 2018-08-16 13:36:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:36:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 13:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:36:27 --> Final output sent to browser
DEBUG - 2018-08-16 13:36:27 --> Total execution time: 0.0430
INFO - 2018-08-16 13:36:34 --> Config Class Initialized
INFO - 2018-08-16 13:36:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:36:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:36:34 --> Utf8 Class Initialized
INFO - 2018-08-16 13:36:34 --> URI Class Initialized
DEBUG - 2018-08-16 13:36:34 --> No URI present. Default controller set.
INFO - 2018-08-16 13:36:34 --> Router Class Initialized
INFO - 2018-08-16 13:36:34 --> Output Class Initialized
INFO - 2018-08-16 13:36:34 --> Security Class Initialized
DEBUG - 2018-08-16 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:36:34 --> CSRF cookie sent
INFO - 2018-08-16 13:36:34 --> Input Class Initialized
INFO - 2018-08-16 13:36:34 --> Language Class Initialized
INFO - 2018-08-16 13:36:34 --> Loader Class Initialized
INFO - 2018-08-16 13:36:34 --> Helper loaded: url_helper
INFO - 2018-08-16 13:36:34 --> Helper loaded: form_helper
INFO - 2018-08-16 13:36:34 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:36:34 --> User Agent Class Initialized
INFO - 2018-08-16 13:36:34 --> Controller Class Initialized
INFO - 2018-08-16 13:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:36:34 --> Pixel_Model class loaded
INFO - 2018-08-16 13:36:34 --> Database Driver Class Initialized
INFO - 2018-08-16 13:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 13:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:36:34 --> Final output sent to browser
DEBUG - 2018-08-16 13:36:34 --> Total execution time: 0.0364
INFO - 2018-08-16 13:38:27 --> Config Class Initialized
INFO - 2018-08-16 13:38:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:27 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:27 --> URI Class Initialized
INFO - 2018-08-16 13:38:27 --> Router Class Initialized
INFO - 2018-08-16 13:38:27 --> Output Class Initialized
INFO - 2018-08-16 13:38:27 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:27 --> CSRF cookie sent
INFO - 2018-08-16 13:38:27 --> CSRF token verified
INFO - 2018-08-16 13:38:27 --> Input Class Initialized
INFO - 2018-08-16 13:38:27 --> Language Class Initialized
INFO - 2018-08-16 13:38:27 --> Loader Class Initialized
INFO - 2018-08-16 13:38:27 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:27 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:27 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:27 --> Controller Class Initialized
INFO - 2018-08-16 13:38:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:27 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:27 --> Config Class Initialized
INFO - 2018-08-16 13:38:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:27 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:27 --> URI Class Initialized
INFO - 2018-08-16 13:38:27 --> Router Class Initialized
INFO - 2018-08-16 13:38:27 --> Output Class Initialized
INFO - 2018-08-16 13:38:27 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:27 --> CSRF cookie sent
INFO - 2018-08-16 13:38:27 --> Input Class Initialized
INFO - 2018-08-16 13:38:27 --> Language Class Initialized
INFO - 2018-08-16 13:38:27 --> Loader Class Initialized
INFO - 2018-08-16 13:38:27 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:27 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:27 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:27 --> Controller Class Initialized
INFO - 2018-08-16 13:38:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:27 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:27 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:28 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 13:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:38:28 --> Final output sent to browser
DEBUG - 2018-08-16 13:38:28 --> Total execution time: 0.0595
INFO - 2018-08-16 13:38:30 --> Config Class Initialized
INFO - 2018-08-16 13:38:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:30 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:30 --> URI Class Initialized
INFO - 2018-08-16 13:38:30 --> Router Class Initialized
INFO - 2018-08-16 13:38:30 --> Output Class Initialized
INFO - 2018-08-16 13:38:30 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:30 --> CSRF cookie sent
INFO - 2018-08-16 13:38:30 --> CSRF token verified
INFO - 2018-08-16 13:38:30 --> Input Class Initialized
INFO - 2018-08-16 13:38:30 --> Language Class Initialized
INFO - 2018-08-16 13:38:30 --> Loader Class Initialized
INFO - 2018-08-16 13:38:30 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:30 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:30 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:30 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:30 --> Controller Class Initialized
INFO - 2018-08-16 13:38:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:30 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:30 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:30 --> Form Validation Class Initialized
INFO - 2018-08-16 13:38:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 13:38:30 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:31 --> Config Class Initialized
INFO - 2018-08-16 13:38:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:31 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:31 --> URI Class Initialized
INFO - 2018-08-16 13:38:31 --> Router Class Initialized
INFO - 2018-08-16 13:38:31 --> Output Class Initialized
INFO - 2018-08-16 13:38:31 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:31 --> CSRF cookie sent
INFO - 2018-08-16 13:38:31 --> Input Class Initialized
INFO - 2018-08-16 13:38:31 --> Language Class Initialized
INFO - 2018-08-16 13:38:31 --> Loader Class Initialized
INFO - 2018-08-16 13:38:31 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:31 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:31 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:31 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:31 --> Controller Class Initialized
INFO - 2018-08-16 13:38:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:31 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:31 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:31 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 13:38:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:38:31 --> Final output sent to browser
DEBUG - 2018-08-16 13:38:31 --> Total execution time: 0.0431
INFO - 2018-08-16 13:38:42 --> Config Class Initialized
INFO - 2018-08-16 13:38:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:42 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:42 --> URI Class Initialized
INFO - 2018-08-16 13:38:42 --> Router Class Initialized
INFO - 2018-08-16 13:38:42 --> Output Class Initialized
INFO - 2018-08-16 13:38:42 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:42 --> CSRF cookie sent
INFO - 2018-08-16 13:38:42 --> CSRF token verified
INFO - 2018-08-16 13:38:42 --> Input Class Initialized
INFO - 2018-08-16 13:38:42 --> Language Class Initialized
INFO - 2018-08-16 13:38:42 --> Loader Class Initialized
INFO - 2018-08-16 13:38:42 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:42 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:42 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:42 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:42 --> Controller Class Initialized
INFO - 2018-08-16 13:38:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:42 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:42 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:42 --> Form Validation Class Initialized
INFO - 2018-08-16 13:38:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 13:38:42 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:42 --> Config Class Initialized
INFO - 2018-08-16 13:38:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:38:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:38:42 --> Utf8 Class Initialized
INFO - 2018-08-16 13:38:42 --> URI Class Initialized
INFO - 2018-08-16 13:38:42 --> Router Class Initialized
INFO - 2018-08-16 13:38:42 --> Output Class Initialized
INFO - 2018-08-16 13:38:42 --> Security Class Initialized
DEBUG - 2018-08-16 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:38:42 --> CSRF cookie sent
INFO - 2018-08-16 13:38:42 --> Input Class Initialized
INFO - 2018-08-16 13:38:42 --> Language Class Initialized
INFO - 2018-08-16 13:38:42 --> Loader Class Initialized
INFO - 2018-08-16 13:38:42 --> Helper loaded: url_helper
INFO - 2018-08-16 13:38:42 --> Helper loaded: form_helper
INFO - 2018-08-16 13:38:42 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:38:42 --> User Agent Class Initialized
INFO - 2018-08-16 13:38:42 --> Controller Class Initialized
INFO - 2018-08-16 13:38:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:38:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:38:42 --> Pixel_Model class loaded
INFO - 2018-08-16 13:38:42 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:42 --> Database Driver Class Initialized
INFO - 2018-08-16 13:38:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 13:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:38:42 --> Final output sent to browser
DEBUG - 2018-08-16 13:38:42 --> Total execution time: 0.0447
INFO - 2018-08-16 13:40:08 --> Config Class Initialized
INFO - 2018-08-16 13:40:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:40:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:40:08 --> Utf8 Class Initialized
INFO - 2018-08-16 13:40:08 --> URI Class Initialized
INFO - 2018-08-16 13:40:08 --> Router Class Initialized
INFO - 2018-08-16 13:40:08 --> Output Class Initialized
INFO - 2018-08-16 13:40:08 --> Security Class Initialized
DEBUG - 2018-08-16 13:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:40:08 --> CSRF cookie sent
INFO - 2018-08-16 13:40:08 --> Input Class Initialized
INFO - 2018-08-16 13:40:08 --> Language Class Initialized
INFO - 2018-08-16 13:40:08 --> Loader Class Initialized
INFO - 2018-08-16 13:40:08 --> Helper loaded: url_helper
INFO - 2018-08-16 13:40:08 --> Helper loaded: form_helper
INFO - 2018-08-16 13:40:08 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:40:08 --> User Agent Class Initialized
INFO - 2018-08-16 13:40:08 --> Controller Class Initialized
INFO - 2018-08-16 13:40:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:40:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:40:08 --> Pixel_Model class loaded
INFO - 2018-08-16 13:40:08 --> Database Driver Class Initialized
INFO - 2018-08-16 13:40:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:40:08 --> Database Driver Class Initialized
INFO - 2018-08-16 13:40:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 13:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:40:08 --> Final output sent to browser
DEBUG - 2018-08-16 13:40:08 --> Total execution time: 0.0480
INFO - 2018-08-16 13:40:11 --> Config Class Initialized
INFO - 2018-08-16 13:40:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:40:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:40:11 --> Utf8 Class Initialized
INFO - 2018-08-16 13:40:11 --> URI Class Initialized
INFO - 2018-08-16 13:40:11 --> Router Class Initialized
INFO - 2018-08-16 13:40:11 --> Output Class Initialized
INFO - 2018-08-16 13:40:11 --> Security Class Initialized
DEBUG - 2018-08-16 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:40:11 --> CSRF cookie sent
INFO - 2018-08-16 13:40:11 --> Input Class Initialized
INFO - 2018-08-16 13:40:11 --> Language Class Initialized
INFO - 2018-08-16 13:40:11 --> Loader Class Initialized
INFO - 2018-08-16 13:40:11 --> Helper loaded: url_helper
INFO - 2018-08-16 13:40:11 --> Helper loaded: form_helper
INFO - 2018-08-16 13:40:11 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:40:11 --> User Agent Class Initialized
INFO - 2018-08-16 13:40:11 --> Controller Class Initialized
INFO - 2018-08-16 13:40:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:40:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:40:11 --> Pixel_Model class loaded
INFO - 2018-08-16 13:40:11 --> Database Driver Class Initialized
INFO - 2018-08-16 13:40:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:40:11 --> Database Driver Class Initialized
INFO - 2018-08-16 13:40:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 13:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:40:11 --> Final output sent to browser
DEBUG - 2018-08-16 13:40:11 --> Total execution time: 0.0379
INFO - 2018-08-16 13:40:13 --> Config Class Initialized
INFO - 2018-08-16 13:40:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:40:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:40:13 --> Utf8 Class Initialized
INFO - 2018-08-16 13:40:13 --> URI Class Initialized
DEBUG - 2018-08-16 13:40:13 --> No URI present. Default controller set.
INFO - 2018-08-16 13:40:13 --> Router Class Initialized
INFO - 2018-08-16 13:40:13 --> Output Class Initialized
INFO - 2018-08-16 13:40:13 --> Security Class Initialized
DEBUG - 2018-08-16 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:40:13 --> CSRF cookie sent
INFO - 2018-08-16 13:40:13 --> Input Class Initialized
INFO - 2018-08-16 13:40:13 --> Language Class Initialized
INFO - 2018-08-16 13:40:13 --> Loader Class Initialized
INFO - 2018-08-16 13:40:13 --> Helper loaded: url_helper
INFO - 2018-08-16 13:40:13 --> Helper loaded: form_helper
INFO - 2018-08-16 13:40:13 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:40:13 --> User Agent Class Initialized
INFO - 2018-08-16 13:40:13 --> Controller Class Initialized
INFO - 2018-08-16 13:40:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:40:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:40:13 --> Pixel_Model class loaded
INFO - 2018-08-16 13:40:13 --> Database Driver Class Initialized
INFO - 2018-08-16 13:40:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:40:13 --> Final output sent to browser
DEBUG - 2018-08-16 13:40:13 --> Total execution time: 0.0358
INFO - 2018-08-16 13:40:35 --> Config Class Initialized
INFO - 2018-08-16 13:40:35 --> Hooks Class Initialized
DEBUG - 2018-08-16 13:40:35 --> UTF-8 Support Enabled
INFO - 2018-08-16 13:40:35 --> Utf8 Class Initialized
INFO - 2018-08-16 13:40:35 --> URI Class Initialized
INFO - 2018-08-16 13:40:35 --> Router Class Initialized
INFO - 2018-08-16 13:40:35 --> Output Class Initialized
INFO - 2018-08-16 13:40:35 --> Security Class Initialized
DEBUG - 2018-08-16 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 13:40:35 --> CSRF cookie sent
INFO - 2018-08-16 13:40:35 --> Input Class Initialized
INFO - 2018-08-16 13:40:35 --> Language Class Initialized
INFO - 2018-08-16 13:40:35 --> Loader Class Initialized
INFO - 2018-08-16 13:40:35 --> Helper loaded: url_helper
INFO - 2018-08-16 13:40:35 --> Helper loaded: form_helper
INFO - 2018-08-16 13:40:35 --> Helper loaded: language_helper
DEBUG - 2018-08-16 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 13:40:35 --> User Agent Class Initialized
INFO - 2018-08-16 13:40:35 --> Controller Class Initialized
INFO - 2018-08-16 13:40:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 13:40:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-08-16 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 13:40:35 --> Final output sent to browser
DEBUG - 2018-08-16 13:40:35 --> Total execution time: 0.0370
INFO - 2018-08-16 14:10:20 --> Config Class Initialized
INFO - 2018-08-16 14:10:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:10:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:10:20 --> Utf8 Class Initialized
INFO - 2018-08-16 14:10:20 --> URI Class Initialized
INFO - 2018-08-16 14:10:20 --> Router Class Initialized
INFO - 2018-08-16 14:10:20 --> Output Class Initialized
INFO - 2018-08-16 14:10:20 --> Security Class Initialized
DEBUG - 2018-08-16 14:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:10:20 --> CSRF cookie sent
INFO - 2018-08-16 14:10:20 --> Input Class Initialized
INFO - 2018-08-16 14:10:20 --> Language Class Initialized
INFO - 2018-08-16 14:10:20 --> Loader Class Initialized
INFO - 2018-08-16 14:10:20 --> Helper loaded: url_helper
INFO - 2018-08-16 14:10:20 --> Helper loaded: form_helper
INFO - 2018-08-16 14:10:20 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:10:20 --> User Agent Class Initialized
INFO - 2018-08-16 14:10:20 --> Controller Class Initialized
INFO - 2018-08-16 14:10:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:10:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-08-16 14:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:10:20 --> Final output sent to browser
DEBUG - 2018-08-16 14:10:20 --> Total execution time: 0.0220
INFO - 2018-08-16 14:10:32 --> Config Class Initialized
INFO - 2018-08-16 14:10:32 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:10:32 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:10:32 --> Utf8 Class Initialized
INFO - 2018-08-16 14:10:32 --> URI Class Initialized
INFO - 2018-08-16 14:10:32 --> Router Class Initialized
INFO - 2018-08-16 14:10:32 --> Output Class Initialized
INFO - 2018-08-16 14:10:32 --> Security Class Initialized
DEBUG - 2018-08-16 14:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:10:32 --> CSRF cookie sent
INFO - 2018-08-16 14:10:32 --> Input Class Initialized
INFO - 2018-08-16 14:10:32 --> Language Class Initialized
INFO - 2018-08-16 14:10:32 --> Loader Class Initialized
INFO - 2018-08-16 14:10:32 --> Helper loaded: url_helper
INFO - 2018-08-16 14:10:32 --> Helper loaded: form_helper
INFO - 2018-08-16 14:10:32 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:10:32 --> User Agent Class Initialized
INFO - 2018-08-16 14:10:32 --> Controller Class Initialized
INFO - 2018-08-16 14:10:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:10:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:10:32 --> Pixel_Model class loaded
INFO - 2018-08-16 14:10:32 --> Database Driver Class Initialized
INFO - 2018-08-16 14:10:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-16 14:10:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:10:32 --> Final output sent to browser
DEBUG - 2018-08-16 14:10:32 --> Total execution time: 0.0368
INFO - 2018-08-16 14:12:53 --> Config Class Initialized
INFO - 2018-08-16 14:12:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:12:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:12:53 --> Utf8 Class Initialized
INFO - 2018-08-16 14:12:53 --> URI Class Initialized
INFO - 2018-08-16 14:12:53 --> Router Class Initialized
INFO - 2018-08-16 14:12:53 --> Output Class Initialized
INFO - 2018-08-16 14:12:53 --> Security Class Initialized
DEBUG - 2018-08-16 14:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:12:53 --> CSRF cookie sent
INFO - 2018-08-16 14:12:53 --> CSRF token verified
INFO - 2018-08-16 14:12:53 --> Input Class Initialized
INFO - 2018-08-16 14:12:53 --> Language Class Initialized
INFO - 2018-08-16 14:12:53 --> Loader Class Initialized
INFO - 2018-08-16 14:12:53 --> Helper loaded: url_helper
INFO - 2018-08-16 14:12:53 --> Helper loaded: form_helper
INFO - 2018-08-16 14:12:53 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:12:53 --> User Agent Class Initialized
INFO - 2018-08-16 14:12:53 --> Controller Class Initialized
INFO - 2018-08-16 14:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:12:53 --> Pixel_Model class loaded
INFO - 2018-08-16 14:12:53 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:53 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:53 --> Config Class Initialized
INFO - 2018-08-16 14:12:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:12:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:12:53 --> Utf8 Class Initialized
INFO - 2018-08-16 14:12:53 --> URI Class Initialized
INFO - 2018-08-16 14:12:53 --> Router Class Initialized
INFO - 2018-08-16 14:12:53 --> Output Class Initialized
INFO - 2018-08-16 14:12:53 --> Security Class Initialized
DEBUG - 2018-08-16 14:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:12:53 --> CSRF cookie sent
INFO - 2018-08-16 14:12:53 --> Input Class Initialized
INFO - 2018-08-16 14:12:53 --> Language Class Initialized
INFO - 2018-08-16 14:12:53 --> Loader Class Initialized
INFO - 2018-08-16 14:12:53 --> Helper loaded: url_helper
INFO - 2018-08-16 14:12:53 --> Helper loaded: form_helper
INFO - 2018-08-16 14:12:53 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:12:53 --> User Agent Class Initialized
INFO - 2018-08-16 14:12:53 --> Controller Class Initialized
INFO - 2018-08-16 14:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:12:53 --> Pixel_Model class loaded
INFO - 2018-08-16 14:12:53 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:53 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 14:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:12:53 --> Final output sent to browser
DEBUG - 2018-08-16 14:12:53 --> Total execution time: 0.0396
INFO - 2018-08-16 14:12:56 --> Config Class Initialized
INFO - 2018-08-16 14:12:56 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:12:56 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:12:56 --> Utf8 Class Initialized
INFO - 2018-08-16 14:12:56 --> URI Class Initialized
INFO - 2018-08-16 14:12:56 --> Router Class Initialized
INFO - 2018-08-16 14:12:56 --> Output Class Initialized
INFO - 2018-08-16 14:12:56 --> Security Class Initialized
DEBUG - 2018-08-16 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:12:56 --> CSRF cookie sent
INFO - 2018-08-16 14:12:56 --> CSRF token verified
INFO - 2018-08-16 14:12:56 --> Input Class Initialized
INFO - 2018-08-16 14:12:56 --> Language Class Initialized
INFO - 2018-08-16 14:12:56 --> Loader Class Initialized
INFO - 2018-08-16 14:12:56 --> Helper loaded: url_helper
INFO - 2018-08-16 14:12:56 --> Helper loaded: form_helper
INFO - 2018-08-16 14:12:56 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:12:56 --> User Agent Class Initialized
INFO - 2018-08-16 14:12:56 --> Controller Class Initialized
INFO - 2018-08-16 14:12:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:12:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:12:56 --> Pixel_Model class loaded
INFO - 2018-08-16 14:12:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:56 --> Form Validation Class Initialized
INFO - 2018-08-16 14:12:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:12:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:56 --> Config Class Initialized
INFO - 2018-08-16 14:12:56 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:12:56 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:12:56 --> Utf8 Class Initialized
INFO - 2018-08-16 14:12:56 --> URI Class Initialized
INFO - 2018-08-16 14:12:56 --> Router Class Initialized
INFO - 2018-08-16 14:12:56 --> Output Class Initialized
INFO - 2018-08-16 14:12:56 --> Security Class Initialized
DEBUG - 2018-08-16 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:12:56 --> CSRF cookie sent
INFO - 2018-08-16 14:12:56 --> Input Class Initialized
INFO - 2018-08-16 14:12:56 --> Language Class Initialized
INFO - 2018-08-16 14:12:56 --> Loader Class Initialized
INFO - 2018-08-16 14:12:56 --> Helper loaded: url_helper
INFO - 2018-08-16 14:12:56 --> Helper loaded: form_helper
INFO - 2018-08-16 14:12:56 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:12:56 --> User Agent Class Initialized
INFO - 2018-08-16 14:12:56 --> Controller Class Initialized
INFO - 2018-08-16 14:12:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:12:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:12:56 --> Pixel_Model class loaded
INFO - 2018-08-16 14:12:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:12:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 14:12:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:12:56 --> Final output sent to browser
DEBUG - 2018-08-16 14:12:56 --> Total execution time: 0.0426
INFO - 2018-08-16 14:13:05 --> Config Class Initialized
INFO - 2018-08-16 14:13:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:05 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:05 --> URI Class Initialized
INFO - 2018-08-16 14:13:05 --> Router Class Initialized
INFO - 2018-08-16 14:13:05 --> Output Class Initialized
INFO - 2018-08-16 14:13:05 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:05 --> CSRF cookie sent
INFO - 2018-08-16 14:13:05 --> CSRF token verified
INFO - 2018-08-16 14:13:05 --> Input Class Initialized
INFO - 2018-08-16 14:13:05 --> Language Class Initialized
INFO - 2018-08-16 14:13:05 --> Loader Class Initialized
INFO - 2018-08-16 14:13:05 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:05 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:05 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:05 --> Controller Class Initialized
INFO - 2018-08-16 14:13:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:05 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:05 --> Form Validation Class Initialized
INFO - 2018-08-16 14:13:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:13:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:05 --> Config Class Initialized
INFO - 2018-08-16 14:13:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:05 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:05 --> URI Class Initialized
INFO - 2018-08-16 14:13:05 --> Router Class Initialized
INFO - 2018-08-16 14:13:05 --> Output Class Initialized
INFO - 2018-08-16 14:13:05 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:05 --> CSRF cookie sent
INFO - 2018-08-16 14:13:05 --> Input Class Initialized
INFO - 2018-08-16 14:13:05 --> Language Class Initialized
INFO - 2018-08-16 14:13:05 --> Loader Class Initialized
INFO - 2018-08-16 14:13:05 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:05 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:05 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:05 --> Controller Class Initialized
INFO - 2018-08-16 14:13:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:05 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 14:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:05 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:05 --> Total execution time: 0.0417
INFO - 2018-08-16 14:13:08 --> Config Class Initialized
INFO - 2018-08-16 14:13:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:08 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:08 --> URI Class Initialized
INFO - 2018-08-16 14:13:08 --> Router Class Initialized
INFO - 2018-08-16 14:13:08 --> Output Class Initialized
INFO - 2018-08-16 14:13:08 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:08 --> CSRF cookie sent
INFO - 2018-08-16 14:13:08 --> CSRF token verified
INFO - 2018-08-16 14:13:08 --> Input Class Initialized
INFO - 2018-08-16 14:13:08 --> Language Class Initialized
INFO - 2018-08-16 14:13:08 --> Loader Class Initialized
INFO - 2018-08-16 14:13:08 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:08 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:08 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:08 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:08 --> Controller Class Initialized
INFO - 2018-08-16 14:13:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:08 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:08 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:08 --> Form Validation Class Initialized
INFO - 2018-08-16 14:13:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:13:08 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:08 --> Config Class Initialized
INFO - 2018-08-16 14:13:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:08 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:08 --> URI Class Initialized
INFO - 2018-08-16 14:13:08 --> Router Class Initialized
INFO - 2018-08-16 14:13:08 --> Output Class Initialized
INFO - 2018-08-16 14:13:08 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:08 --> CSRF cookie sent
INFO - 2018-08-16 14:13:08 --> Input Class Initialized
INFO - 2018-08-16 14:13:08 --> Language Class Initialized
INFO - 2018-08-16 14:13:08 --> Loader Class Initialized
INFO - 2018-08-16 14:13:08 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:08 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:08 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:08 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:08 --> Controller Class Initialized
INFO - 2018-08-16 14:13:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:08 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:08 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:08 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 14:13:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:08 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:08 --> Total execution time: 0.0469
INFO - 2018-08-16 14:13:11 --> Config Class Initialized
INFO - 2018-08-16 14:13:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:11 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:11 --> URI Class Initialized
INFO - 2018-08-16 14:13:11 --> Router Class Initialized
INFO - 2018-08-16 14:13:11 --> Output Class Initialized
INFO - 2018-08-16 14:13:11 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:11 --> CSRF cookie sent
INFO - 2018-08-16 14:13:11 --> Input Class Initialized
INFO - 2018-08-16 14:13:11 --> Language Class Initialized
INFO - 2018-08-16 14:13:11 --> Loader Class Initialized
INFO - 2018-08-16 14:13:11 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:11 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:11 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:11 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:11 --> Controller Class Initialized
INFO - 2018-08-16 14:13:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:11 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:11 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:11 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 14:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:11 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:11 --> Total execution time: 0.0369
INFO - 2018-08-16 14:13:21 --> Config Class Initialized
INFO - 2018-08-16 14:13:21 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:21 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:21 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:21 --> URI Class Initialized
INFO - 2018-08-16 14:13:21 --> Router Class Initialized
INFO - 2018-08-16 14:13:21 --> Output Class Initialized
INFO - 2018-08-16 14:13:21 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:21 --> CSRF cookie sent
INFO - 2018-08-16 14:13:21 --> CSRF token verified
INFO - 2018-08-16 14:13:21 --> Input Class Initialized
INFO - 2018-08-16 14:13:21 --> Language Class Initialized
INFO - 2018-08-16 14:13:21 --> Loader Class Initialized
INFO - 2018-08-16 14:13:21 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:21 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:21 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:21 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:21 --> Controller Class Initialized
INFO - 2018-08-16 14:13:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:21 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:21 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:21 --> Form Validation Class Initialized
INFO - 2018-08-16 14:13:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:13:21 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:21 --> Config Class Initialized
INFO - 2018-08-16 14:13:21 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:21 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:21 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:21 --> URI Class Initialized
INFO - 2018-08-16 14:13:21 --> Router Class Initialized
INFO - 2018-08-16 14:13:21 --> Output Class Initialized
INFO - 2018-08-16 14:13:21 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:21 --> CSRF cookie sent
INFO - 2018-08-16 14:13:21 --> Input Class Initialized
INFO - 2018-08-16 14:13:21 --> Language Class Initialized
INFO - 2018-08-16 14:13:21 --> Loader Class Initialized
INFO - 2018-08-16 14:13:21 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:21 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:21 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:21 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:21 --> Controller Class Initialized
INFO - 2018-08-16 14:13:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:21 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:21 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:21 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 14:13:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:21 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:21 --> Total execution time: 0.0403
INFO - 2018-08-16 14:13:41 --> Config Class Initialized
INFO - 2018-08-16 14:13:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:41 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:41 --> URI Class Initialized
INFO - 2018-08-16 14:13:41 --> Router Class Initialized
INFO - 2018-08-16 14:13:41 --> Output Class Initialized
INFO - 2018-08-16 14:13:41 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:41 --> CSRF cookie sent
INFO - 2018-08-16 14:13:41 --> CSRF token verified
INFO - 2018-08-16 14:13:41 --> Input Class Initialized
INFO - 2018-08-16 14:13:41 --> Language Class Initialized
INFO - 2018-08-16 14:13:41 --> Loader Class Initialized
INFO - 2018-08-16 14:13:41 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:41 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:41 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:41 --> Controller Class Initialized
INFO - 2018-08-16 14:13:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:41 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:41 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:41 --> Form Validation Class Initialized
INFO - 2018-08-16 14:13:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:13:41 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:41 --> Config Class Initialized
INFO - 2018-08-16 14:13:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:41 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:41 --> URI Class Initialized
INFO - 2018-08-16 14:13:41 --> Router Class Initialized
INFO - 2018-08-16 14:13:41 --> Output Class Initialized
INFO - 2018-08-16 14:13:41 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:41 --> CSRF cookie sent
INFO - 2018-08-16 14:13:41 --> Input Class Initialized
INFO - 2018-08-16 14:13:41 --> Language Class Initialized
INFO - 2018-08-16 14:13:41 --> Loader Class Initialized
INFO - 2018-08-16 14:13:41 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:41 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:41 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:41 --> Controller Class Initialized
INFO - 2018-08-16 14:13:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:41 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:41 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:41 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 14:13:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:41 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:41 --> Total execution time: 0.0456
INFO - 2018-08-16 14:13:59 --> Config Class Initialized
INFO - 2018-08-16 14:13:59 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:13:59 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:13:59 --> Utf8 Class Initialized
INFO - 2018-08-16 14:13:59 --> URI Class Initialized
INFO - 2018-08-16 14:13:59 --> Router Class Initialized
INFO - 2018-08-16 14:13:59 --> Output Class Initialized
INFO - 2018-08-16 14:13:59 --> Security Class Initialized
DEBUG - 2018-08-16 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:13:59 --> CSRF cookie sent
INFO - 2018-08-16 14:13:59 --> Input Class Initialized
INFO - 2018-08-16 14:13:59 --> Language Class Initialized
INFO - 2018-08-16 14:13:59 --> Loader Class Initialized
INFO - 2018-08-16 14:13:59 --> Helper loaded: url_helper
INFO - 2018-08-16 14:13:59 --> Helper loaded: form_helper
INFO - 2018-08-16 14:13:59 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:13:59 --> User Agent Class Initialized
INFO - 2018-08-16 14:13:59 --> Controller Class Initialized
INFO - 2018-08-16 14:13:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:13:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:13:59 --> Pixel_Model class loaded
INFO - 2018-08-16 14:13:59 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:59 --> Database Driver Class Initialized
INFO - 2018-08-16 14:13:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 14:13:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:13:59 --> Final output sent to browser
DEBUG - 2018-08-16 14:13:59 --> Total execution time: 0.0438
INFO - 2018-08-16 14:14:05 --> Config Class Initialized
INFO - 2018-08-16 14:14:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:14:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:14:05 --> Utf8 Class Initialized
INFO - 2018-08-16 14:14:05 --> URI Class Initialized
INFO - 2018-08-16 14:14:05 --> Router Class Initialized
INFO - 2018-08-16 14:14:05 --> Output Class Initialized
INFO - 2018-08-16 14:14:05 --> Security Class Initialized
DEBUG - 2018-08-16 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:14:05 --> CSRF cookie sent
INFO - 2018-08-16 14:14:05 --> Input Class Initialized
INFO - 2018-08-16 14:14:05 --> Language Class Initialized
INFO - 2018-08-16 14:14:05 --> Loader Class Initialized
INFO - 2018-08-16 14:14:05 --> Helper loaded: url_helper
INFO - 2018-08-16 14:14:05 --> Helper loaded: form_helper
INFO - 2018-08-16 14:14:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:14:05 --> User Agent Class Initialized
INFO - 2018-08-16 14:14:05 --> Controller Class Initialized
INFO - 2018-08-16 14:14:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:14:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:14:05 --> Pixel_Model class loaded
INFO - 2018-08-16 14:14:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:05 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 14:14:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:14:05 --> Final output sent to browser
DEBUG - 2018-08-16 14:14:05 --> Total execution time: 0.0592
INFO - 2018-08-16 14:14:06 --> Config Class Initialized
INFO - 2018-08-16 14:14:06 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:14:06 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:14:06 --> Utf8 Class Initialized
INFO - 2018-08-16 14:14:06 --> URI Class Initialized
INFO - 2018-08-16 14:14:06 --> Router Class Initialized
INFO - 2018-08-16 14:14:06 --> Output Class Initialized
INFO - 2018-08-16 14:14:06 --> Security Class Initialized
DEBUG - 2018-08-16 14:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:14:06 --> CSRF cookie sent
INFO - 2018-08-16 14:14:06 --> Input Class Initialized
INFO - 2018-08-16 14:14:06 --> Language Class Initialized
INFO - 2018-08-16 14:14:06 --> Loader Class Initialized
INFO - 2018-08-16 14:14:06 --> Helper loaded: url_helper
INFO - 2018-08-16 14:14:06 --> Helper loaded: form_helper
INFO - 2018-08-16 14:14:06 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:14:06 --> User Agent Class Initialized
INFO - 2018-08-16 14:14:06 --> Controller Class Initialized
INFO - 2018-08-16 14:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:14:06 --> Pixel_Model class loaded
INFO - 2018-08-16 14:14:06 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:06 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 14:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:14:06 --> Final output sent to browser
DEBUG - 2018-08-16 14:14:06 --> Total execution time: 0.0375
INFO - 2018-08-16 14:14:07 --> Config Class Initialized
INFO - 2018-08-16 14:14:07 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:14:07 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:14:07 --> Utf8 Class Initialized
INFO - 2018-08-16 14:14:07 --> URI Class Initialized
INFO - 2018-08-16 14:14:07 --> Router Class Initialized
INFO - 2018-08-16 14:14:07 --> Output Class Initialized
INFO - 2018-08-16 14:14:07 --> Security Class Initialized
DEBUG - 2018-08-16 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:14:07 --> CSRF cookie sent
INFO - 2018-08-16 14:14:07 --> Input Class Initialized
INFO - 2018-08-16 14:14:07 --> Language Class Initialized
INFO - 2018-08-16 14:14:07 --> Loader Class Initialized
INFO - 2018-08-16 14:14:07 --> Helper loaded: url_helper
INFO - 2018-08-16 14:14:07 --> Helper loaded: form_helper
INFO - 2018-08-16 14:14:07 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:14:07 --> User Agent Class Initialized
INFO - 2018-08-16 14:14:07 --> Controller Class Initialized
INFO - 2018-08-16 14:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:14:07 --> Pixel_Model class loaded
INFO - 2018-08-16 14:14:07 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:07 --> Database Driver Class Initialized
INFO - 2018-08-16 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 14:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:14:07 --> Final output sent to browser
DEBUG - 2018-08-16 14:14:07 --> Total execution time: 0.0503
INFO - 2018-08-16 14:17:01 --> Config Class Initialized
INFO - 2018-08-16 14:17:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:17:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:17:01 --> Utf8 Class Initialized
INFO - 2018-08-16 14:17:01 --> URI Class Initialized
INFO - 2018-08-16 14:17:01 --> Router Class Initialized
INFO - 2018-08-16 14:17:01 --> Output Class Initialized
INFO - 2018-08-16 14:17:01 --> Security Class Initialized
DEBUG - 2018-08-16 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:17:01 --> CSRF cookie sent
INFO - 2018-08-16 14:17:01 --> CSRF token verified
INFO - 2018-08-16 14:17:01 --> Input Class Initialized
INFO - 2018-08-16 14:17:01 --> Language Class Initialized
INFO - 2018-08-16 14:17:01 --> Loader Class Initialized
INFO - 2018-08-16 14:17:01 --> Helper loaded: url_helper
INFO - 2018-08-16 14:17:01 --> Helper loaded: form_helper
INFO - 2018-08-16 14:17:01 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:17:01 --> User Agent Class Initialized
INFO - 2018-08-16 14:17:01 --> Controller Class Initialized
INFO - 2018-08-16 14:17:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:17:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:17:01 --> Pixel_Model class loaded
INFO - 2018-08-16 14:17:01 --> Database Driver Class Initialized
INFO - 2018-08-16 14:17:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:17:01 --> Form Validation Class Initialized
INFO - 2018-08-16 14:17:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:17:01 --> Database Driver Class Initialized
INFO - 2018-08-16 14:17:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:17:01 --> Config Class Initialized
INFO - 2018-08-16 14:17:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:17:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:17:01 --> Utf8 Class Initialized
INFO - 2018-08-16 14:17:01 --> URI Class Initialized
INFO - 2018-08-16 14:17:01 --> Router Class Initialized
INFO - 2018-08-16 14:17:01 --> Output Class Initialized
INFO - 2018-08-16 14:17:01 --> Security Class Initialized
DEBUG - 2018-08-16 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:17:01 --> CSRF cookie sent
INFO - 2018-08-16 14:17:01 --> Input Class Initialized
INFO - 2018-08-16 14:17:01 --> Language Class Initialized
INFO - 2018-08-16 14:17:01 --> Loader Class Initialized
INFO - 2018-08-16 14:17:01 --> Helper loaded: url_helper
INFO - 2018-08-16 14:17:01 --> Helper loaded: form_helper
INFO - 2018-08-16 14:17:01 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:17:01 --> User Agent Class Initialized
INFO - 2018-08-16 14:17:01 --> Controller Class Initialized
INFO - 2018-08-16 14:17:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:17:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:17:01 --> Pixel_Model class loaded
INFO - 2018-08-16 14:17:01 --> Database Driver Class Initialized
INFO - 2018-08-16 14:17:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:17:01 --> Database Driver Class Initialized
INFO - 2018-08-16 14:17:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 14:17:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:17:01 --> Final output sent to browser
DEBUG - 2018-08-16 14:17:01 --> Total execution time: 0.0369
INFO - 2018-08-16 14:40:57 --> Config Class Initialized
INFO - 2018-08-16 14:40:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:40:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:40:57 --> Utf8 Class Initialized
INFO - 2018-08-16 14:40:57 --> URI Class Initialized
DEBUG - 2018-08-16 14:40:57 --> No URI present. Default controller set.
INFO - 2018-08-16 14:40:57 --> Router Class Initialized
INFO - 2018-08-16 14:40:57 --> Output Class Initialized
INFO - 2018-08-16 14:40:57 --> Security Class Initialized
DEBUG - 2018-08-16 14:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:40:57 --> CSRF cookie sent
INFO - 2018-08-16 14:40:57 --> Input Class Initialized
INFO - 2018-08-16 14:40:57 --> Language Class Initialized
INFO - 2018-08-16 14:40:57 --> Loader Class Initialized
INFO - 2018-08-16 14:40:57 --> Helper loaded: url_helper
INFO - 2018-08-16 14:40:57 --> Helper loaded: form_helper
INFO - 2018-08-16 14:40:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:40:57 --> User Agent Class Initialized
INFO - 2018-08-16 14:40:57 --> Controller Class Initialized
INFO - 2018-08-16 14:40:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:40:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:40:57 --> Pixel_Model class loaded
INFO - 2018-08-16 14:40:57 --> Database Driver Class Initialized
INFO - 2018-08-16 14:40:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:40:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:40:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:40:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 14:40:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:40:57 --> Final output sent to browser
DEBUG - 2018-08-16 14:40:57 --> Total execution time: 0.0336
INFO - 2018-08-16 14:41:47 --> Config Class Initialized
INFO - 2018-08-16 14:41:47 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:41:47 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:41:47 --> Utf8 Class Initialized
INFO - 2018-08-16 14:41:47 --> URI Class Initialized
INFO - 2018-08-16 14:41:47 --> Router Class Initialized
INFO - 2018-08-16 14:41:47 --> Output Class Initialized
INFO - 2018-08-16 14:41:47 --> Security Class Initialized
DEBUG - 2018-08-16 14:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:41:47 --> CSRF cookie sent
INFO - 2018-08-16 14:41:47 --> CSRF token verified
INFO - 2018-08-16 14:41:47 --> Input Class Initialized
INFO - 2018-08-16 14:41:47 --> Language Class Initialized
INFO - 2018-08-16 14:41:47 --> Loader Class Initialized
INFO - 2018-08-16 14:41:47 --> Helper loaded: url_helper
INFO - 2018-08-16 14:41:47 --> Helper loaded: form_helper
INFO - 2018-08-16 14:41:47 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:41:47 --> User Agent Class Initialized
INFO - 2018-08-16 14:41:47 --> Controller Class Initialized
INFO - 2018-08-16 14:41:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:41:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:41:47 --> Pixel_Model class loaded
INFO - 2018-08-16 14:41:47 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:47 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:48 --> Config Class Initialized
INFO - 2018-08-16 14:41:48 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:41:48 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:41:48 --> Utf8 Class Initialized
INFO - 2018-08-16 14:41:48 --> URI Class Initialized
INFO - 2018-08-16 14:41:48 --> Router Class Initialized
INFO - 2018-08-16 14:41:48 --> Output Class Initialized
INFO - 2018-08-16 14:41:48 --> Security Class Initialized
DEBUG - 2018-08-16 14:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:41:48 --> CSRF cookie sent
INFO - 2018-08-16 14:41:48 --> Input Class Initialized
INFO - 2018-08-16 14:41:48 --> Language Class Initialized
INFO - 2018-08-16 14:41:48 --> Loader Class Initialized
INFO - 2018-08-16 14:41:48 --> Helper loaded: url_helper
INFO - 2018-08-16 14:41:48 --> Helper loaded: form_helper
INFO - 2018-08-16 14:41:48 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:41:48 --> User Agent Class Initialized
INFO - 2018-08-16 14:41:48 --> Controller Class Initialized
INFO - 2018-08-16 14:41:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:41:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:41:48 --> Pixel_Model class loaded
INFO - 2018-08-16 14:41:48 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:48 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 14:41:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:41:48 --> Final output sent to browser
DEBUG - 2018-08-16 14:41:48 --> Total execution time: 0.0619
INFO - 2018-08-16 14:41:55 --> Config Class Initialized
INFO - 2018-08-16 14:41:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:41:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:41:55 --> Utf8 Class Initialized
INFO - 2018-08-16 14:41:55 --> URI Class Initialized
INFO - 2018-08-16 14:41:55 --> Router Class Initialized
INFO - 2018-08-16 14:41:55 --> Output Class Initialized
INFO - 2018-08-16 14:41:55 --> Security Class Initialized
DEBUG - 2018-08-16 14:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:41:55 --> CSRF cookie sent
INFO - 2018-08-16 14:41:55 --> CSRF token verified
INFO - 2018-08-16 14:41:55 --> Input Class Initialized
INFO - 2018-08-16 14:41:55 --> Language Class Initialized
INFO - 2018-08-16 14:41:55 --> Loader Class Initialized
INFO - 2018-08-16 14:41:55 --> Helper loaded: url_helper
INFO - 2018-08-16 14:41:55 --> Helper loaded: form_helper
INFO - 2018-08-16 14:41:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:41:55 --> User Agent Class Initialized
INFO - 2018-08-16 14:41:55 --> Controller Class Initialized
INFO - 2018-08-16 14:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:41:55 --> Pixel_Model class loaded
INFO - 2018-08-16 14:41:55 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:55 --> Form Validation Class Initialized
INFO - 2018-08-16 14:41:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 14:41:55 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:56 --> Config Class Initialized
INFO - 2018-08-16 14:41:56 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:41:56 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:41:56 --> Utf8 Class Initialized
INFO - 2018-08-16 14:41:56 --> URI Class Initialized
INFO - 2018-08-16 14:41:56 --> Router Class Initialized
INFO - 2018-08-16 14:41:56 --> Output Class Initialized
INFO - 2018-08-16 14:41:56 --> Security Class Initialized
DEBUG - 2018-08-16 14:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:41:56 --> CSRF cookie sent
INFO - 2018-08-16 14:41:56 --> Input Class Initialized
INFO - 2018-08-16 14:41:56 --> Language Class Initialized
INFO - 2018-08-16 14:41:56 --> Loader Class Initialized
INFO - 2018-08-16 14:41:56 --> Helper loaded: url_helper
INFO - 2018-08-16 14:41:56 --> Helper loaded: form_helper
INFO - 2018-08-16 14:41:56 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:41:56 --> User Agent Class Initialized
INFO - 2018-08-16 14:41:56 --> Controller Class Initialized
INFO - 2018-08-16 14:41:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:41:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:41:56 --> Pixel_Model class loaded
INFO - 2018-08-16 14:41:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:56 --> Database Driver Class Initialized
INFO - 2018-08-16 14:41:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 14:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:41:56 --> Final output sent to browser
DEBUG - 2018-08-16 14:41:56 --> Total execution time: 0.0416
INFO - 2018-08-16 14:54:59 --> Config Class Initialized
INFO - 2018-08-16 14:54:59 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:54:59 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:54:59 --> Utf8 Class Initialized
INFO - 2018-08-16 14:54:59 --> URI Class Initialized
INFO - 2018-08-16 14:54:59 --> Router Class Initialized
INFO - 2018-08-16 14:54:59 --> Output Class Initialized
INFO - 2018-08-16 14:54:59 --> Security Class Initialized
DEBUG - 2018-08-16 14:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:54:59 --> CSRF cookie sent
INFO - 2018-08-16 14:54:59 --> Input Class Initialized
INFO - 2018-08-16 14:54:59 --> Language Class Initialized
INFO - 2018-08-16 14:54:59 --> Loader Class Initialized
INFO - 2018-08-16 14:54:59 --> Helper loaded: url_helper
INFO - 2018-08-16 14:54:59 --> Helper loaded: form_helper
INFO - 2018-08-16 14:54:59 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:54:59 --> User Agent Class Initialized
INFO - 2018-08-16 14:54:59 --> Controller Class Initialized
INFO - 2018-08-16 14:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:54:59 --> Pixel_Model class loaded
INFO - 2018-08-16 14:54:59 --> Database Driver Class Initialized
INFO - 2018-08-16 14:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:54:59 --> Database Driver Class Initialized
INFO - 2018-08-16 14:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 14:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:54:59 --> Final output sent to browser
DEBUG - 2018-08-16 14:54:59 --> Total execution time: 0.0541
INFO - 2018-08-16 14:55:25 --> Config Class Initialized
INFO - 2018-08-16 14:55:25 --> Hooks Class Initialized
DEBUG - 2018-08-16 14:55:25 --> UTF-8 Support Enabled
INFO - 2018-08-16 14:55:25 --> Utf8 Class Initialized
INFO - 2018-08-16 14:55:25 --> URI Class Initialized
INFO - 2018-08-16 14:55:25 --> Router Class Initialized
INFO - 2018-08-16 14:55:25 --> Output Class Initialized
INFO - 2018-08-16 14:55:25 --> Security Class Initialized
DEBUG - 2018-08-16 14:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 14:55:25 --> CSRF cookie sent
INFO - 2018-08-16 14:55:25 --> Input Class Initialized
INFO - 2018-08-16 14:55:25 --> Language Class Initialized
INFO - 2018-08-16 14:55:25 --> Loader Class Initialized
INFO - 2018-08-16 14:55:25 --> Helper loaded: url_helper
INFO - 2018-08-16 14:55:25 --> Helper loaded: form_helper
INFO - 2018-08-16 14:55:25 --> Helper loaded: language_helper
DEBUG - 2018-08-16 14:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 14:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 14:55:25 --> User Agent Class Initialized
INFO - 2018-08-16 14:55:25 --> Controller Class Initialized
INFO - 2018-08-16 14:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 14:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 14:55:25 --> Pixel_Model class loaded
INFO - 2018-08-16 14:55:25 --> Database Driver Class Initialized
INFO - 2018-08-16 14:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:55:25 --> Database Driver Class Initialized
INFO - 2018-08-16 14:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 14:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 14:55:25 --> Final output sent to browser
DEBUG - 2018-08-16 14:55:25 --> Total execution time: 0.0616
INFO - 2018-08-16 15:14:34 --> Config Class Initialized
INFO - 2018-08-16 15:14:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:14:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:14:34 --> Utf8 Class Initialized
INFO - 2018-08-16 15:14:34 --> URI Class Initialized
DEBUG - 2018-08-16 15:14:34 --> No URI present. Default controller set.
INFO - 2018-08-16 15:14:34 --> Router Class Initialized
INFO - 2018-08-16 15:14:34 --> Output Class Initialized
INFO - 2018-08-16 15:14:34 --> Security Class Initialized
DEBUG - 2018-08-16 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:14:34 --> CSRF cookie sent
INFO - 2018-08-16 15:14:34 --> Input Class Initialized
INFO - 2018-08-16 15:14:34 --> Language Class Initialized
INFO - 2018-08-16 15:14:34 --> Loader Class Initialized
INFO - 2018-08-16 15:14:34 --> Helper loaded: url_helper
INFO - 2018-08-16 15:14:34 --> Helper loaded: form_helper
INFO - 2018-08-16 15:14:34 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:14:34 --> User Agent Class Initialized
INFO - 2018-08-16 15:14:34 --> Controller Class Initialized
INFO - 2018-08-16 15:14:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:14:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:14:34 --> Pixel_Model class loaded
INFO - 2018-08-16 15:14:34 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:14:34 --> Final output sent to browser
DEBUG - 2018-08-16 15:14:34 --> Total execution time: 0.0330
INFO - 2018-08-16 15:14:40 --> Config Class Initialized
INFO - 2018-08-16 15:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:14:40 --> Utf8 Class Initialized
INFO - 2018-08-16 15:14:40 --> URI Class Initialized
INFO - 2018-08-16 15:14:40 --> Router Class Initialized
INFO - 2018-08-16 15:14:40 --> Output Class Initialized
INFO - 2018-08-16 15:14:40 --> Security Class Initialized
DEBUG - 2018-08-16 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:14:40 --> CSRF cookie sent
INFO - 2018-08-16 15:14:40 --> CSRF token verified
INFO - 2018-08-16 15:14:40 --> Input Class Initialized
INFO - 2018-08-16 15:14:40 --> Language Class Initialized
INFO - 2018-08-16 15:14:40 --> Loader Class Initialized
INFO - 2018-08-16 15:14:40 --> Helper loaded: url_helper
INFO - 2018-08-16 15:14:40 --> Helper loaded: form_helper
INFO - 2018-08-16 15:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:14:40 --> User Agent Class Initialized
INFO - 2018-08-16 15:14:40 --> Controller Class Initialized
INFO - 2018-08-16 15:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:14:40 --> Pixel_Model class loaded
INFO - 2018-08-16 15:14:40 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:40 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:40 --> Config Class Initialized
INFO - 2018-08-16 15:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:14:40 --> Utf8 Class Initialized
INFO - 2018-08-16 15:14:40 --> URI Class Initialized
INFO - 2018-08-16 15:14:40 --> Router Class Initialized
INFO - 2018-08-16 15:14:40 --> Output Class Initialized
INFO - 2018-08-16 15:14:40 --> Security Class Initialized
DEBUG - 2018-08-16 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:14:40 --> CSRF cookie sent
INFO - 2018-08-16 15:14:40 --> Input Class Initialized
INFO - 2018-08-16 15:14:40 --> Language Class Initialized
INFO - 2018-08-16 15:14:40 --> Loader Class Initialized
INFO - 2018-08-16 15:14:40 --> Helper loaded: url_helper
INFO - 2018-08-16 15:14:40 --> Helper loaded: form_helper
INFO - 2018-08-16 15:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:14:40 --> User Agent Class Initialized
INFO - 2018-08-16 15:14:40 --> Controller Class Initialized
INFO - 2018-08-16 15:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:14:40 --> Pixel_Model class loaded
INFO - 2018-08-16 15:14:41 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:41 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 15:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:14:41 --> Final output sent to browser
DEBUG - 2018-08-16 15:14:41 --> Total execution time: 0.0515
INFO - 2018-08-16 15:14:49 --> Config Class Initialized
INFO - 2018-08-16 15:14:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:14:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:14:49 --> Utf8 Class Initialized
INFO - 2018-08-16 15:14:49 --> URI Class Initialized
INFO - 2018-08-16 15:14:49 --> Router Class Initialized
INFO - 2018-08-16 15:14:49 --> Output Class Initialized
INFO - 2018-08-16 15:14:49 --> Security Class Initialized
DEBUG - 2018-08-16 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:14:49 --> CSRF cookie sent
INFO - 2018-08-16 15:14:49 --> CSRF token verified
INFO - 2018-08-16 15:14:49 --> Input Class Initialized
INFO - 2018-08-16 15:14:49 --> Language Class Initialized
INFO - 2018-08-16 15:14:49 --> Loader Class Initialized
INFO - 2018-08-16 15:14:49 --> Helper loaded: url_helper
INFO - 2018-08-16 15:14:49 --> Helper loaded: form_helper
INFO - 2018-08-16 15:14:49 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:14:49 --> User Agent Class Initialized
INFO - 2018-08-16 15:14:49 --> Controller Class Initialized
INFO - 2018-08-16 15:14:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:14:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:14:49 --> Pixel_Model class loaded
INFO - 2018-08-16 15:14:49 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:49 --> Form Validation Class Initialized
INFO - 2018-08-16 15:14:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:14:49 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:50 --> Config Class Initialized
INFO - 2018-08-16 15:14:50 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:14:50 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:14:50 --> Utf8 Class Initialized
INFO - 2018-08-16 15:14:50 --> URI Class Initialized
INFO - 2018-08-16 15:14:50 --> Router Class Initialized
INFO - 2018-08-16 15:14:50 --> Output Class Initialized
INFO - 2018-08-16 15:14:50 --> Security Class Initialized
DEBUG - 2018-08-16 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:14:50 --> CSRF cookie sent
INFO - 2018-08-16 15:14:50 --> Input Class Initialized
INFO - 2018-08-16 15:14:50 --> Language Class Initialized
INFO - 2018-08-16 15:14:50 --> Loader Class Initialized
INFO - 2018-08-16 15:14:50 --> Helper loaded: url_helper
INFO - 2018-08-16 15:14:50 --> Helper loaded: form_helper
INFO - 2018-08-16 15:14:50 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:14:50 --> User Agent Class Initialized
INFO - 2018-08-16 15:14:50 --> Controller Class Initialized
INFO - 2018-08-16 15:14:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:14:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:14:50 --> Pixel_Model class loaded
INFO - 2018-08-16 15:14:50 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:50 --> Database Driver Class Initialized
INFO - 2018-08-16 15:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:14:50 --> Final output sent to browser
DEBUG - 2018-08-16 15:14:50 --> Total execution time: 0.0433
INFO - 2018-08-16 15:27:07 --> Config Class Initialized
INFO - 2018-08-16 15:27:07 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:27:07 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:27:07 --> Utf8 Class Initialized
INFO - 2018-08-16 15:27:07 --> URI Class Initialized
DEBUG - 2018-08-16 15:27:07 --> No URI present. Default controller set.
INFO - 2018-08-16 15:27:07 --> Router Class Initialized
INFO - 2018-08-16 15:27:07 --> Output Class Initialized
INFO - 2018-08-16 15:27:07 --> Security Class Initialized
DEBUG - 2018-08-16 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:27:07 --> CSRF cookie sent
INFO - 2018-08-16 15:27:07 --> Input Class Initialized
INFO - 2018-08-16 15:27:07 --> Language Class Initialized
INFO - 2018-08-16 15:27:07 --> Loader Class Initialized
INFO - 2018-08-16 15:27:07 --> Helper loaded: url_helper
INFO - 2018-08-16 15:27:07 --> Helper loaded: form_helper
INFO - 2018-08-16 15:27:07 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:27:07 --> User Agent Class Initialized
INFO - 2018-08-16 15:27:07 --> Controller Class Initialized
INFO - 2018-08-16 15:27:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:27:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:27:07 --> Pixel_Model class loaded
INFO - 2018-08-16 15:27:07 --> Database Driver Class Initialized
INFO - 2018-08-16 15:27:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:27:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:27:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:27:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:27:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:27:07 --> Final output sent to browser
DEBUG - 2018-08-16 15:27:07 --> Total execution time: 0.0476
INFO - 2018-08-16 15:27:09 --> Config Class Initialized
INFO - 2018-08-16 15:27:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:27:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:27:09 --> Utf8 Class Initialized
INFO - 2018-08-16 15:27:09 --> URI Class Initialized
DEBUG - 2018-08-16 15:27:09 --> No URI present. Default controller set.
INFO - 2018-08-16 15:27:09 --> Router Class Initialized
INFO - 2018-08-16 15:27:09 --> Output Class Initialized
INFO - 2018-08-16 15:27:09 --> Security Class Initialized
DEBUG - 2018-08-16 15:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:27:09 --> CSRF cookie sent
INFO - 2018-08-16 15:27:09 --> Input Class Initialized
INFO - 2018-08-16 15:27:09 --> Language Class Initialized
INFO - 2018-08-16 15:27:09 --> Loader Class Initialized
INFO - 2018-08-16 15:27:09 --> Helper loaded: url_helper
INFO - 2018-08-16 15:27:09 --> Helper loaded: form_helper
INFO - 2018-08-16 15:27:09 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:27:09 --> User Agent Class Initialized
INFO - 2018-08-16 15:27:09 --> Controller Class Initialized
INFO - 2018-08-16 15:27:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:27:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:27:09 --> Pixel_Model class loaded
INFO - 2018-08-16 15:27:09 --> Database Driver Class Initialized
INFO - 2018-08-16 15:27:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:27:09 --> Final output sent to browser
DEBUG - 2018-08-16 15:27:09 --> Total execution time: 0.0378
INFO - 2018-08-16 15:31:53 --> Config Class Initialized
INFO - 2018-08-16 15:31:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:31:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:31:53 --> Utf8 Class Initialized
INFO - 2018-08-16 15:31:53 --> URI Class Initialized
INFO - 2018-08-16 15:31:53 --> Router Class Initialized
INFO - 2018-08-16 15:31:53 --> Output Class Initialized
INFO - 2018-08-16 15:31:53 --> Security Class Initialized
DEBUG - 2018-08-16 15:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:31:53 --> CSRF cookie sent
INFO - 2018-08-16 15:31:53 --> Input Class Initialized
INFO - 2018-08-16 15:31:53 --> Language Class Initialized
INFO - 2018-08-16 15:31:53 --> Loader Class Initialized
INFO - 2018-08-16 15:31:53 --> Helper loaded: url_helper
INFO - 2018-08-16 15:31:53 --> Helper loaded: form_helper
INFO - 2018-08-16 15:31:53 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:31:53 --> User Agent Class Initialized
INFO - 2018-08-16 15:31:53 --> Controller Class Initialized
INFO - 2018-08-16 15:31:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:31:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:31:53 --> Pixel_Model class loaded
INFO - 2018-08-16 15:31:53 --> Database Driver Class Initialized
INFO - 2018-08-16 15:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:31:53 --> Database Driver Class Initialized
INFO - 2018-08-16 15:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:31:53 --> Final output sent to browser
DEBUG - 2018-08-16 15:31:53 --> Total execution time: 0.0466
INFO - 2018-08-16 15:32:06 --> Config Class Initialized
INFO - 2018-08-16 15:32:06 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:32:06 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:32:06 --> Utf8 Class Initialized
INFO - 2018-08-16 15:32:06 --> URI Class Initialized
INFO - 2018-08-16 15:32:06 --> Router Class Initialized
INFO - 2018-08-16 15:32:06 --> Output Class Initialized
INFO - 2018-08-16 15:32:06 --> Security Class Initialized
DEBUG - 2018-08-16 15:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:32:06 --> CSRF cookie sent
INFO - 2018-08-16 15:32:06 --> Input Class Initialized
INFO - 2018-08-16 15:32:06 --> Language Class Initialized
INFO - 2018-08-16 15:32:06 --> Loader Class Initialized
INFO - 2018-08-16 15:32:06 --> Helper loaded: url_helper
INFO - 2018-08-16 15:32:06 --> Helper loaded: form_helper
INFO - 2018-08-16 15:32:06 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:32:06 --> User Agent Class Initialized
INFO - 2018-08-16 15:32:06 --> Controller Class Initialized
INFO - 2018-08-16 15:32:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:32:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:32:06 --> Pixel_Model class loaded
INFO - 2018-08-16 15:32:06 --> Database Driver Class Initialized
INFO - 2018-08-16 15:32:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:32:06 --> Database Driver Class Initialized
INFO - 2018-08-16 15:32:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:32:06 --> Final output sent to browser
DEBUG - 2018-08-16 15:32:06 --> Total execution time: 0.0498
INFO - 2018-08-16 15:42:15 --> Config Class Initialized
INFO - 2018-08-16 15:42:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:15 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:16 --> URI Class Initialized
INFO - 2018-08-16 15:42:16 --> Router Class Initialized
INFO - 2018-08-16 15:42:16 --> Output Class Initialized
INFO - 2018-08-16 15:42:16 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:16 --> CSRF cookie sent
INFO - 2018-08-16 15:42:16 --> Input Class Initialized
INFO - 2018-08-16 15:42:16 --> Language Class Initialized
ERROR - 2018-08-16 15:42:16 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-16 15:42:16 --> Config Class Initialized
INFO - 2018-08-16 15:42:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:16 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:16 --> URI Class Initialized
INFO - 2018-08-16 15:42:16 --> Router Class Initialized
INFO - 2018-08-16 15:42:16 --> Output Class Initialized
INFO - 2018-08-16 15:42:16 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:16 --> CSRF cookie sent
INFO - 2018-08-16 15:42:16 --> Input Class Initialized
INFO - 2018-08-16 15:42:16 --> Language Class Initialized
ERROR - 2018-08-16 15:42:16 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-16 15:42:20 --> Config Class Initialized
INFO - 2018-08-16 15:42:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:20 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:20 --> URI Class Initialized
DEBUG - 2018-08-16 15:42:20 --> No URI present. Default controller set.
INFO - 2018-08-16 15:42:20 --> Router Class Initialized
INFO - 2018-08-16 15:42:20 --> Output Class Initialized
INFO - 2018-08-16 15:42:20 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:20 --> CSRF cookie sent
INFO - 2018-08-16 15:42:20 --> Input Class Initialized
INFO - 2018-08-16 15:42:20 --> Language Class Initialized
INFO - 2018-08-16 15:42:20 --> Loader Class Initialized
INFO - 2018-08-16 15:42:20 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:20 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:20 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:20 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:20 --> Controller Class Initialized
INFO - 2018-08-16 15:42:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:20 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:20 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:20 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:20 --> Total execution time: 0.0336
INFO - 2018-08-16 15:42:23 --> Config Class Initialized
INFO - 2018-08-16 15:42:23 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:23 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:23 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:23 --> URI Class Initialized
INFO - 2018-08-16 15:42:23 --> Router Class Initialized
INFO - 2018-08-16 15:42:23 --> Output Class Initialized
INFO - 2018-08-16 15:42:23 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:23 --> CSRF cookie sent
INFO - 2018-08-16 15:42:23 --> Input Class Initialized
INFO - 2018-08-16 15:42:23 --> Language Class Initialized
INFO - 2018-08-16 15:42:23 --> Loader Class Initialized
INFO - 2018-08-16 15:42:23 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:23 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:23 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:23 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:23 --> Controller Class Initialized
INFO - 2018-08-16 15:42:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-16 15:42:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-16 15:42:23 --> Could not find the language line "req_email"
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-16 15:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:23 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:23 --> Total execution time: 0.0239
INFO - 2018-08-16 15:42:26 --> Config Class Initialized
INFO - 2018-08-16 15:42:26 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:26 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:26 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:26 --> URI Class Initialized
INFO - 2018-08-16 15:42:26 --> Router Class Initialized
INFO - 2018-08-16 15:42:26 --> Output Class Initialized
INFO - 2018-08-16 15:42:26 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:26 --> CSRF cookie sent
INFO - 2018-08-16 15:42:26 --> Input Class Initialized
INFO - 2018-08-16 15:42:26 --> Language Class Initialized
INFO - 2018-08-16 15:42:26 --> Loader Class Initialized
INFO - 2018-08-16 15:42:26 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:26 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:26 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:26 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:26 --> Controller Class Initialized
INFO - 2018-08-16 15:42:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:26 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:26 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-16 15:42:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:26 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:26 --> Total execution time: 0.0380
INFO - 2018-08-16 15:42:28 --> Config Class Initialized
INFO - 2018-08-16 15:42:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:28 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:28 --> URI Class Initialized
INFO - 2018-08-16 15:42:28 --> Router Class Initialized
INFO - 2018-08-16 15:42:28 --> Output Class Initialized
INFO - 2018-08-16 15:42:28 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:28 --> CSRF cookie sent
INFO - 2018-08-16 15:42:28 --> CSRF token verified
INFO - 2018-08-16 15:42:28 --> Input Class Initialized
INFO - 2018-08-16 15:42:28 --> Language Class Initialized
INFO - 2018-08-16 15:42:28 --> Loader Class Initialized
INFO - 2018-08-16 15:42:28 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:28 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:28 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:28 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:28 --> Controller Class Initialized
INFO - 2018-08-16 15:42:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:28 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:28 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:28 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:28 --> Config Class Initialized
INFO - 2018-08-16 15:42:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:28 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:28 --> URI Class Initialized
INFO - 2018-08-16 15:42:28 --> Router Class Initialized
INFO - 2018-08-16 15:42:28 --> Output Class Initialized
INFO - 2018-08-16 15:42:28 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:28 --> CSRF cookie sent
INFO - 2018-08-16 15:42:28 --> Input Class Initialized
INFO - 2018-08-16 15:42:28 --> Language Class Initialized
INFO - 2018-08-16 15:42:28 --> Loader Class Initialized
INFO - 2018-08-16 15:42:28 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:28 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:28 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:28 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:28 --> Controller Class Initialized
INFO - 2018-08-16 15:42:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:28 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:28 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:28 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 15:42:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:28 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:28 --> Total execution time: 0.0442
INFO - 2018-08-16 15:42:31 --> Config Class Initialized
INFO - 2018-08-16 15:42:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:31 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:31 --> URI Class Initialized
INFO - 2018-08-16 15:42:31 --> Router Class Initialized
INFO - 2018-08-16 15:42:31 --> Output Class Initialized
INFO - 2018-08-16 15:42:31 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:31 --> CSRF cookie sent
INFO - 2018-08-16 15:42:31 --> CSRF token verified
INFO - 2018-08-16 15:42:31 --> Input Class Initialized
INFO - 2018-08-16 15:42:31 --> Language Class Initialized
INFO - 2018-08-16 15:42:31 --> Loader Class Initialized
INFO - 2018-08-16 15:42:31 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:31 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:31 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:31 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:31 --> Controller Class Initialized
INFO - 2018-08-16 15:42:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:31 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:31 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:31 --> Form Validation Class Initialized
INFO - 2018-08-16 15:42:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:42:31 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:31 --> Config Class Initialized
INFO - 2018-08-16 15:42:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:31 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:31 --> URI Class Initialized
INFO - 2018-08-16 15:42:31 --> Router Class Initialized
INFO - 2018-08-16 15:42:31 --> Output Class Initialized
INFO - 2018-08-16 15:42:31 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:31 --> CSRF cookie sent
INFO - 2018-08-16 15:42:31 --> Input Class Initialized
INFO - 2018-08-16 15:42:31 --> Language Class Initialized
INFO - 2018-08-16 15:42:31 --> Loader Class Initialized
INFO - 2018-08-16 15:42:31 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:31 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:31 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:31 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:31 --> Controller Class Initialized
INFO - 2018-08-16 15:42:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:31 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:31 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:31 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:42:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:31 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:31 --> Total execution time: 0.0465
INFO - 2018-08-16 15:42:34 --> Config Class Initialized
INFO - 2018-08-16 15:42:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:34 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:34 --> URI Class Initialized
INFO - 2018-08-16 15:42:34 --> Router Class Initialized
INFO - 2018-08-16 15:42:34 --> Output Class Initialized
INFO - 2018-08-16 15:42:34 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:34 --> CSRF cookie sent
INFO - 2018-08-16 15:42:34 --> Input Class Initialized
INFO - 2018-08-16 15:42:34 --> Language Class Initialized
INFO - 2018-08-16 15:42:34 --> Loader Class Initialized
INFO - 2018-08-16 15:42:34 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:34 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:34 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:34 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:34 --> Controller Class Initialized
INFO - 2018-08-16 15:42:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:34 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:35 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:35 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 15:42:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:35 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:35 --> Total execution time: 0.0541
INFO - 2018-08-16 15:42:43 --> Config Class Initialized
INFO - 2018-08-16 15:42:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:43 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:43 --> URI Class Initialized
INFO - 2018-08-16 15:42:43 --> Router Class Initialized
INFO - 2018-08-16 15:42:43 --> Output Class Initialized
INFO - 2018-08-16 15:42:43 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:43 --> CSRF cookie sent
INFO - 2018-08-16 15:42:43 --> CSRF token verified
INFO - 2018-08-16 15:42:43 --> Input Class Initialized
INFO - 2018-08-16 15:42:43 --> Language Class Initialized
INFO - 2018-08-16 15:42:43 --> Loader Class Initialized
INFO - 2018-08-16 15:42:43 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:43 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:43 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:43 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:43 --> Controller Class Initialized
INFO - 2018-08-16 15:42:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:43 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:43 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:43 --> Form Validation Class Initialized
INFO - 2018-08-16 15:42:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:42:43 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:43 --> Config Class Initialized
INFO - 2018-08-16 15:42:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:43 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:43 --> URI Class Initialized
INFO - 2018-08-16 15:42:43 --> Router Class Initialized
INFO - 2018-08-16 15:42:43 --> Output Class Initialized
INFO - 2018-08-16 15:42:43 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:43 --> CSRF cookie sent
INFO - 2018-08-16 15:42:43 --> Input Class Initialized
INFO - 2018-08-16 15:42:43 --> Language Class Initialized
INFO - 2018-08-16 15:42:43 --> Loader Class Initialized
INFO - 2018-08-16 15:42:43 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:43 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:43 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:43 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:43 --> Controller Class Initialized
INFO - 2018-08-16 15:42:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:43 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:43 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:43 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:43 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:43 --> Total execution time: 0.0582
INFO - 2018-08-16 15:42:44 --> Config Class Initialized
INFO - 2018-08-16 15:42:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:44 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:44 --> URI Class Initialized
INFO - 2018-08-16 15:42:44 --> Router Class Initialized
INFO - 2018-08-16 15:42:44 --> Output Class Initialized
INFO - 2018-08-16 15:42:44 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:44 --> CSRF cookie sent
INFO - 2018-08-16 15:42:44 --> CSRF token verified
INFO - 2018-08-16 15:42:44 --> Input Class Initialized
INFO - 2018-08-16 15:42:44 --> Language Class Initialized
INFO - 2018-08-16 15:42:44 --> Loader Class Initialized
INFO - 2018-08-16 15:42:44 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:44 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:44 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:44 --> Controller Class Initialized
INFO - 2018-08-16 15:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:44 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:44 --> Form Validation Class Initialized
INFO - 2018-08-16 15:42:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:42:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:44 --> Config Class Initialized
INFO - 2018-08-16 15:42:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:44 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:44 --> URI Class Initialized
INFO - 2018-08-16 15:42:44 --> Router Class Initialized
INFO - 2018-08-16 15:42:44 --> Output Class Initialized
INFO - 2018-08-16 15:42:44 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:44 --> CSRF cookie sent
INFO - 2018-08-16 15:42:44 --> Input Class Initialized
INFO - 2018-08-16 15:42:44 --> Language Class Initialized
INFO - 2018-08-16 15:42:44 --> Loader Class Initialized
INFO - 2018-08-16 15:42:44 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:44 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:45 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:45 --> Controller Class Initialized
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:45 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:45 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:45 --> Total execution time: 0.0545
INFO - 2018-08-16 15:42:45 --> Config Class Initialized
INFO - 2018-08-16 15:42:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:45 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:45 --> URI Class Initialized
INFO - 2018-08-16 15:42:45 --> Router Class Initialized
INFO - 2018-08-16 15:42:45 --> Output Class Initialized
INFO - 2018-08-16 15:42:45 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:45 --> CSRF cookie sent
INFO - 2018-08-16 15:42:45 --> CSRF token verified
INFO - 2018-08-16 15:42:45 --> Input Class Initialized
INFO - 2018-08-16 15:42:45 --> Language Class Initialized
INFO - 2018-08-16 15:42:45 --> Loader Class Initialized
INFO - 2018-08-16 15:42:45 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:45 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:45 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:45 --> Controller Class Initialized
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:45 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> Form Validation Class Initialized
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> Config Class Initialized
INFO - 2018-08-16 15:42:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:45 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:45 --> URI Class Initialized
INFO - 2018-08-16 15:42:45 --> Router Class Initialized
INFO - 2018-08-16 15:42:45 --> Output Class Initialized
INFO - 2018-08-16 15:42:45 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:45 --> CSRF cookie sent
INFO - 2018-08-16 15:42:45 --> Input Class Initialized
INFO - 2018-08-16 15:42:45 --> Language Class Initialized
INFO - 2018-08-16 15:42:45 --> Loader Class Initialized
INFO - 2018-08-16 15:42:45 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:45 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:45 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:45 --> Controller Class Initialized
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:45 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 15:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:45 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:45 --> Total execution time: 0.0401
INFO - 2018-08-16 15:42:52 --> Config Class Initialized
INFO - 2018-08-16 15:42:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:52 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:52 --> URI Class Initialized
INFO - 2018-08-16 15:42:52 --> Router Class Initialized
INFO - 2018-08-16 15:42:52 --> Output Class Initialized
INFO - 2018-08-16 15:42:52 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:52 --> CSRF cookie sent
INFO - 2018-08-16 15:42:52 --> CSRF token verified
INFO - 2018-08-16 15:42:52 --> Input Class Initialized
INFO - 2018-08-16 15:42:52 --> Language Class Initialized
INFO - 2018-08-16 15:42:52 --> Loader Class Initialized
INFO - 2018-08-16 15:42:52 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:52 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:52 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:52 --> Controller Class Initialized
INFO - 2018-08-16 15:42:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:52 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:52 --> Form Validation Class Initialized
INFO - 2018-08-16 15:42:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:42:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:52 --> Config Class Initialized
INFO - 2018-08-16 15:42:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:42:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:42:52 --> Utf8 Class Initialized
INFO - 2018-08-16 15:42:52 --> URI Class Initialized
INFO - 2018-08-16 15:42:52 --> Router Class Initialized
INFO - 2018-08-16 15:42:52 --> Output Class Initialized
INFO - 2018-08-16 15:42:52 --> Security Class Initialized
DEBUG - 2018-08-16 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:42:52 --> CSRF cookie sent
INFO - 2018-08-16 15:42:52 --> Input Class Initialized
INFO - 2018-08-16 15:42:52 --> Language Class Initialized
INFO - 2018-08-16 15:42:52 --> Loader Class Initialized
INFO - 2018-08-16 15:42:52 --> Helper loaded: url_helper
INFO - 2018-08-16 15:42:52 --> Helper loaded: form_helper
INFO - 2018-08-16 15:42:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:42:52 --> User Agent Class Initialized
INFO - 2018-08-16 15:42:52 --> Controller Class Initialized
INFO - 2018-08-16 15:42:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:42:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:42:52 --> Pixel_Model class loaded
INFO - 2018-08-16 15:42:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 15:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:42:52 --> Final output sent to browser
DEBUG - 2018-08-16 15:42:52 --> Total execution time: 0.0451
INFO - 2018-08-16 15:43:00 --> Config Class Initialized
INFO - 2018-08-16 15:43:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:00 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:00 --> URI Class Initialized
INFO - 2018-08-16 15:43:00 --> Router Class Initialized
INFO - 2018-08-16 15:43:00 --> Output Class Initialized
INFO - 2018-08-16 15:43:00 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:00 --> CSRF cookie sent
INFO - 2018-08-16 15:43:00 --> CSRF token verified
INFO - 2018-08-16 15:43:00 --> Input Class Initialized
INFO - 2018-08-16 15:43:00 --> Language Class Initialized
INFO - 2018-08-16 15:43:00 --> Loader Class Initialized
INFO - 2018-08-16 15:43:00 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:00 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:00 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:00 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:00 --> Controller Class Initialized
INFO - 2018-08-16 15:43:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:00 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:00 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:00 --> Config Class Initialized
INFO - 2018-08-16 15:43:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:00 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:00 --> URI Class Initialized
INFO - 2018-08-16 15:43:00 --> Router Class Initialized
INFO - 2018-08-16 15:43:00 --> Output Class Initialized
INFO - 2018-08-16 15:43:00 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:00 --> CSRF cookie sent
INFO - 2018-08-16 15:43:00 --> Input Class Initialized
INFO - 2018-08-16 15:43:00 --> Language Class Initialized
INFO - 2018-08-16 15:43:00 --> Loader Class Initialized
INFO - 2018-08-16 15:43:00 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:00 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:00 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:00 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:00 --> Controller Class Initialized
INFO - 2018-08-16 15:43:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:00 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-16 15:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:00 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:00 --> Total execution time: 0.0463
INFO - 2018-08-16 15:43:01 --> Config Class Initialized
INFO - 2018-08-16 15:43:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:01 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:01 --> URI Class Initialized
INFO - 2018-08-16 15:43:01 --> Router Class Initialized
INFO - 2018-08-16 15:43:01 --> Output Class Initialized
INFO - 2018-08-16 15:43:01 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:01 --> CSRF cookie sent
INFO - 2018-08-16 15:43:01 --> Input Class Initialized
INFO - 2018-08-16 15:43:01 --> Language Class Initialized
INFO - 2018-08-16 15:43:01 --> Loader Class Initialized
INFO - 2018-08-16 15:43:01 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:01 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:01 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:01 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:01 --> Controller Class Initialized
INFO - 2018-08-16 15:43:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:01 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:01 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:01 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 15:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:01 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:01 --> Total execution time: 0.0444
INFO - 2018-08-16 15:43:03 --> Config Class Initialized
INFO - 2018-08-16 15:43:03 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:03 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:03 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:03 --> URI Class Initialized
INFO - 2018-08-16 15:43:03 --> Router Class Initialized
INFO - 2018-08-16 15:43:03 --> Output Class Initialized
INFO - 2018-08-16 15:43:03 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:03 --> CSRF cookie sent
INFO - 2018-08-16 15:43:03 --> Input Class Initialized
INFO - 2018-08-16 15:43:03 --> Language Class Initialized
INFO - 2018-08-16 15:43:03 --> Loader Class Initialized
INFO - 2018-08-16 15:43:03 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:03 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:03 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:03 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:03 --> Controller Class Initialized
INFO - 2018-08-16 15:43:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:03 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:03 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:03 --> Model "MyAccountModel" initialized
INFO - 2018-08-16 15:43:03 --> Config Class Initialized
INFO - 2018-08-16 15:43:03 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:03 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:03 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:03 --> URI Class Initialized
INFO - 2018-08-16 15:43:03 --> Router Class Initialized
INFO - 2018-08-16 15:43:03 --> Output Class Initialized
INFO - 2018-08-16 15:43:03 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:03 --> CSRF cookie sent
INFO - 2018-08-16 15:43:03 --> Input Class Initialized
INFO - 2018-08-16 15:43:03 --> Language Class Initialized
INFO - 2018-08-16 15:43:03 --> Loader Class Initialized
INFO - 2018-08-16 15:43:03 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:03 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:03 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:03 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:03 --> Controller Class Initialized
INFO - 2018-08-16 15:43:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:03 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:03 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:03 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-16 15:43:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:03 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:03 --> Total execution time: 0.0454
INFO - 2018-08-16 15:43:10 --> Config Class Initialized
INFO - 2018-08-16 15:43:10 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:10 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:10 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:10 --> URI Class Initialized
INFO - 2018-08-16 15:43:10 --> Router Class Initialized
INFO - 2018-08-16 15:43:10 --> Output Class Initialized
INFO - 2018-08-16 15:43:10 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:10 --> CSRF cookie sent
INFO - 2018-08-16 15:43:10 --> CSRF token verified
INFO - 2018-08-16 15:43:10 --> Input Class Initialized
INFO - 2018-08-16 15:43:10 --> Language Class Initialized
INFO - 2018-08-16 15:43:10 --> Loader Class Initialized
INFO - 2018-08-16 15:43:10 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:10 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:10 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:10 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:10 --> Controller Class Initialized
INFO - 2018-08-16 15:43:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:10 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:10 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:10 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:10 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:10 --> Config Class Initialized
INFO - 2018-08-16 15:43:10 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:10 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:10 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:10 --> URI Class Initialized
INFO - 2018-08-16 15:43:10 --> Router Class Initialized
INFO - 2018-08-16 15:43:10 --> Output Class Initialized
INFO - 2018-08-16 15:43:10 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:10 --> CSRF cookie sent
INFO - 2018-08-16 15:43:10 --> Input Class Initialized
INFO - 2018-08-16 15:43:10 --> Language Class Initialized
INFO - 2018-08-16 15:43:10 --> Loader Class Initialized
INFO - 2018-08-16 15:43:10 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:10 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:10 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:10 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:10 --> Controller Class Initialized
INFO - 2018-08-16 15:43:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:10 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:10 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:10 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-16 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:10 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:10 --> Total execution time: 0.0546
INFO - 2018-08-16 15:43:11 --> Config Class Initialized
INFO - 2018-08-16 15:43:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:11 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:11 --> URI Class Initialized
INFO - 2018-08-16 15:43:11 --> Router Class Initialized
INFO - 2018-08-16 15:43:11 --> Output Class Initialized
INFO - 2018-08-16 15:43:11 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:11 --> CSRF cookie sent
INFO - 2018-08-16 15:43:11 --> Input Class Initialized
INFO - 2018-08-16 15:43:11 --> Language Class Initialized
INFO - 2018-08-16 15:43:11 --> Loader Class Initialized
INFO - 2018-08-16 15:43:11 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:11 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:11 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:11 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:11 --> Controller Class Initialized
INFO - 2018-08-16 15:43:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:11 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:11 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:11 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-16 15:43:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:11 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:11 --> Total execution time: 0.0551
INFO - 2018-08-16 15:43:13 --> Config Class Initialized
INFO - 2018-08-16 15:43:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:13 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:13 --> URI Class Initialized
INFO - 2018-08-16 15:43:13 --> Router Class Initialized
INFO - 2018-08-16 15:43:13 --> Output Class Initialized
INFO - 2018-08-16 15:43:13 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:13 --> CSRF cookie sent
INFO - 2018-08-16 15:43:13 --> Input Class Initialized
INFO - 2018-08-16 15:43:13 --> Language Class Initialized
INFO - 2018-08-16 15:43:13 --> Loader Class Initialized
INFO - 2018-08-16 15:43:13 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:13 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:13 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:13 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:13 --> Controller Class Initialized
INFO - 2018-08-16 15:43:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:13 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:13 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:13 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-16 15:43:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:13 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:13 --> Total execution time: 0.0519
INFO - 2018-08-16 15:43:14 --> Config Class Initialized
INFO - 2018-08-16 15:43:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:14 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:14 --> URI Class Initialized
INFO - 2018-08-16 15:43:14 --> Router Class Initialized
INFO - 2018-08-16 15:43:14 --> Output Class Initialized
INFO - 2018-08-16 15:43:14 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:14 --> CSRF cookie sent
INFO - 2018-08-16 15:43:14 --> Input Class Initialized
INFO - 2018-08-16 15:43:14 --> Language Class Initialized
INFO - 2018-08-16 15:43:14 --> Loader Class Initialized
INFO - 2018-08-16 15:43:14 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:14 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:14 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:14 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:14 --> Controller Class Initialized
INFO - 2018-08-16 15:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:14 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:14 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:14 --> Config Class Initialized
INFO - 2018-08-16 15:43:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:14 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:14 --> URI Class Initialized
INFO - 2018-08-16 15:43:14 --> Router Class Initialized
INFO - 2018-08-16 15:43:14 --> Output Class Initialized
INFO - 2018-08-16 15:43:14 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:14 --> CSRF cookie sent
INFO - 2018-08-16 15:43:14 --> Input Class Initialized
INFO - 2018-08-16 15:43:14 --> Language Class Initialized
INFO - 2018-08-16 15:43:14 --> Loader Class Initialized
INFO - 2018-08-16 15:43:14 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:14 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:14 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:14 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:14 --> Controller Class Initialized
INFO - 2018-08-16 15:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:14 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:14 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:14 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-16 15:43:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-16 15:43:14 --> Could not find the language line "req_email"
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-16 15:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:14 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:14 --> Total execution time: 0.0353
INFO - 2018-08-16 15:43:37 --> Config Class Initialized
INFO - 2018-08-16 15:43:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:37 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:37 --> URI Class Initialized
INFO - 2018-08-16 15:43:37 --> Router Class Initialized
INFO - 2018-08-16 15:43:37 --> Output Class Initialized
INFO - 2018-08-16 15:43:37 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:37 --> CSRF cookie sent
INFO - 2018-08-16 15:43:37 --> CSRF token verified
INFO - 2018-08-16 15:43:37 --> Input Class Initialized
INFO - 2018-08-16 15:43:37 --> Language Class Initialized
INFO - 2018-08-16 15:43:37 --> Loader Class Initialized
INFO - 2018-08-16 15:43:37 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:37 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:37 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:37 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:37 --> Controller Class Initialized
INFO - 2018-08-16 15:43:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-16 15:43:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 15:43:37 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:37 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:37 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:37 --> Model "RegistrationModel" initialized
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-08-16 15:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:37 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:37 --> Total execution time: 0.1763
INFO - 2018-08-16 15:43:43 --> Config Class Initialized
INFO - 2018-08-16 15:43:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:43 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:43 --> URI Class Initialized
INFO - 2018-08-16 15:43:43 --> Router Class Initialized
INFO - 2018-08-16 15:43:43 --> Output Class Initialized
INFO - 2018-08-16 15:43:43 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:43 --> CSRF cookie sent
INFO - 2018-08-16 15:43:43 --> CSRF token verified
INFO - 2018-08-16 15:43:43 --> Input Class Initialized
INFO - 2018-08-16 15:43:43 --> Language Class Initialized
INFO - 2018-08-16 15:43:43 --> Loader Class Initialized
INFO - 2018-08-16 15:43:44 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:44 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:44 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:44 --> Controller Class Initialized
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:44 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:44 --> Model "RegistrationModel" initialized
INFO - 2018-08-16 15:43:44 --> Helper loaded: string_helper
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-16 15:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-08-16 15:43:44 --> Email Class Initialized
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/english/email_lang.php
INFO - 2018-08-16 15:43:44 --> Config Class Initialized
INFO - 2018-08-16 15:43:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:44 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:44 --> URI Class Initialized
INFO - 2018-08-16 15:43:44 --> Router Class Initialized
INFO - 2018-08-16 15:43:44 --> Output Class Initialized
INFO - 2018-08-16 15:43:44 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:44 --> CSRF cookie sent
INFO - 2018-08-16 15:43:44 --> Input Class Initialized
INFO - 2018-08-16 15:43:44 --> Language Class Initialized
INFO - 2018-08-16 15:43:44 --> Loader Class Initialized
INFO - 2018-08-16 15:43:44 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:44 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:44 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:44 --> Controller Class Initialized
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:44 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-16 15:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:44 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:44 --> Total execution time: 0.0555
INFO - 2018-08-16 15:43:52 --> Config Class Initialized
INFO - 2018-08-16 15:43:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:52 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:52 --> URI Class Initialized
INFO - 2018-08-16 15:43:52 --> Router Class Initialized
INFO - 2018-08-16 15:43:52 --> Output Class Initialized
INFO - 2018-08-16 15:43:52 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:52 --> CSRF cookie sent
INFO - 2018-08-16 15:43:52 --> CSRF token verified
INFO - 2018-08-16 15:43:52 --> Input Class Initialized
INFO - 2018-08-16 15:43:52 --> Language Class Initialized
INFO - 2018-08-16 15:43:52 --> Loader Class Initialized
INFO - 2018-08-16 15:43:52 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:52 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:52 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:52 --> Controller Class Initialized
INFO - 2018-08-16 15:43:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:52 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:52 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:52 --> Config Class Initialized
INFO - 2018-08-16 15:43:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:52 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:52 --> URI Class Initialized
INFO - 2018-08-16 15:43:52 --> Router Class Initialized
INFO - 2018-08-16 15:43:52 --> Output Class Initialized
INFO - 2018-08-16 15:43:52 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:52 --> CSRF cookie sent
INFO - 2018-08-16 15:43:52 --> Input Class Initialized
INFO - 2018-08-16 15:43:52 --> Language Class Initialized
INFO - 2018-08-16 15:43:52 --> Loader Class Initialized
INFO - 2018-08-16 15:43:52 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:52 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:52 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:52 --> Controller Class Initialized
INFO - 2018-08-16 15:43:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:52 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:52 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-16 15:43:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:52 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:52 --> Total execution time: 0.0440
INFO - 2018-08-16 15:43:54 --> Config Class Initialized
INFO - 2018-08-16 15:43:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:54 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:54 --> URI Class Initialized
INFO - 2018-08-16 15:43:54 --> Router Class Initialized
INFO - 2018-08-16 15:43:54 --> Output Class Initialized
INFO - 2018-08-16 15:43:54 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:54 --> CSRF cookie sent
INFO - 2018-08-16 15:43:54 --> CSRF token verified
INFO - 2018-08-16 15:43:54 --> Input Class Initialized
INFO - 2018-08-16 15:43:54 --> Language Class Initialized
INFO - 2018-08-16 15:43:54 --> Loader Class Initialized
INFO - 2018-08-16 15:43:54 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:54 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:54 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:54 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:54 --> Controller Class Initialized
INFO - 2018-08-16 15:43:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:54 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:54 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:54 --> Config Class Initialized
INFO - 2018-08-16 15:43:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:54 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:54 --> URI Class Initialized
INFO - 2018-08-16 15:43:54 --> Router Class Initialized
INFO - 2018-08-16 15:43:54 --> Output Class Initialized
INFO - 2018-08-16 15:43:54 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:54 --> CSRF cookie sent
INFO - 2018-08-16 15:43:54 --> Input Class Initialized
INFO - 2018-08-16 15:43:54 --> Language Class Initialized
INFO - 2018-08-16 15:43:54 --> Loader Class Initialized
INFO - 2018-08-16 15:43:54 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:54 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:54 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:54 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:54 --> Controller Class Initialized
INFO - 2018-08-16 15:43:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:54 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-16 15:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:54 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:54 --> Total execution time: 0.0435
INFO - 2018-08-16 15:43:55 --> Config Class Initialized
INFO - 2018-08-16 15:43:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:55 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:55 --> URI Class Initialized
INFO - 2018-08-16 15:43:55 --> Router Class Initialized
INFO - 2018-08-16 15:43:55 --> Output Class Initialized
INFO - 2018-08-16 15:43:55 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:55 --> CSRF cookie sent
INFO - 2018-08-16 15:43:55 --> CSRF token verified
INFO - 2018-08-16 15:43:55 --> Input Class Initialized
INFO - 2018-08-16 15:43:55 --> Language Class Initialized
INFO - 2018-08-16 15:43:55 --> Loader Class Initialized
INFO - 2018-08-16 15:43:55 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:55 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:55 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:55 --> Controller Class Initialized
INFO - 2018-08-16 15:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:55 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:55 --> Form Validation Class Initialized
INFO - 2018-08-16 15:43:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 15:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:55 --> Config Class Initialized
INFO - 2018-08-16 15:43:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:43:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:43:55 --> Utf8 Class Initialized
INFO - 2018-08-16 15:43:55 --> URI Class Initialized
INFO - 2018-08-16 15:43:55 --> Router Class Initialized
INFO - 2018-08-16 15:43:55 --> Output Class Initialized
INFO - 2018-08-16 15:43:55 --> Security Class Initialized
DEBUG - 2018-08-16 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:43:55 --> CSRF cookie sent
INFO - 2018-08-16 15:43:55 --> Input Class Initialized
INFO - 2018-08-16 15:43:55 --> Language Class Initialized
INFO - 2018-08-16 15:43:55 --> Loader Class Initialized
INFO - 2018-08-16 15:43:55 --> Helper loaded: url_helper
INFO - 2018-08-16 15:43:55 --> Helper loaded: form_helper
INFO - 2018-08-16 15:43:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:43:55 --> User Agent Class Initialized
INFO - 2018-08-16 15:43:55 --> Controller Class Initialized
INFO - 2018-08-16 15:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:43:55 --> Pixel_Model class loaded
INFO - 2018-08-16 15:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 15:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-16 15:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:43:55 --> Final output sent to browser
DEBUG - 2018-08-16 15:43:55 --> Total execution time: 0.0375
INFO - 2018-08-16 15:44:00 --> Config Class Initialized
INFO - 2018-08-16 15:44:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:44:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:44:00 --> Utf8 Class Initialized
INFO - 2018-08-16 15:44:00 --> URI Class Initialized
INFO - 2018-08-16 15:44:00 --> Router Class Initialized
INFO - 2018-08-16 15:44:00 --> Output Class Initialized
INFO - 2018-08-16 15:44:00 --> Security Class Initialized
DEBUG - 2018-08-16 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:44:00 --> CSRF cookie sent
INFO - 2018-08-16 15:44:00 --> Input Class Initialized
INFO - 2018-08-16 15:44:00 --> Language Class Initialized
INFO - 2018-08-16 15:44:00 --> Loader Class Initialized
INFO - 2018-08-16 15:44:00 --> Helper loaded: url_helper
INFO - 2018-08-16 15:44:00 --> Helper loaded: form_helper
INFO - 2018-08-16 15:44:00 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:44:00 --> User Agent Class Initialized
INFO - 2018-08-16 15:44:00 --> Controller Class Initialized
INFO - 2018-08-16 15:44:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:44:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:44:00 --> Pixel_Model class loaded
INFO - 2018-08-16 15:44:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:44:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:44:00 --> Database Driver Class Initialized
INFO - 2018-08-16 15:44:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-08-16 15:44:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:44:00 --> Final output sent to browser
DEBUG - 2018-08-16 15:44:00 --> Total execution time: 0.0416
INFO - 2018-08-16 15:44:02 --> Config Class Initialized
INFO - 2018-08-16 15:44:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:44:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:44:02 --> Utf8 Class Initialized
INFO - 2018-08-16 15:44:02 --> URI Class Initialized
INFO - 2018-08-16 15:44:02 --> Router Class Initialized
INFO - 2018-08-16 15:44:02 --> Output Class Initialized
INFO - 2018-08-16 15:44:02 --> Security Class Initialized
DEBUG - 2018-08-16 15:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:44:02 --> CSRF cookie sent
INFO - 2018-08-16 15:44:02 --> Input Class Initialized
INFO - 2018-08-16 15:44:02 --> Language Class Initialized
INFO - 2018-08-16 15:44:02 --> Loader Class Initialized
INFO - 2018-08-16 15:44:02 --> Helper loaded: url_helper
INFO - 2018-08-16 15:44:02 --> Helper loaded: form_helper
INFO - 2018-08-16 15:44:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:44:02 --> User Agent Class Initialized
INFO - 2018-08-16 15:44:02 --> Controller Class Initialized
INFO - 2018-08-16 15:44:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:44:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:44:02 --> Pixel_Model class loaded
INFO - 2018-08-16 15:44:02 --> Database Driver Class Initialized
INFO - 2018-08-16 15:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:44:02 --> Database Driver Class Initialized
INFO - 2018-08-16 15:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-16 15:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:44:02 --> Final output sent to browser
DEBUG - 2018-08-16 15:44:02 --> Total execution time: 0.0386
INFO - 2018-08-16 15:45:23 --> Config Class Initialized
INFO - 2018-08-16 15:45:23 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:23 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:23 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:23 --> URI Class Initialized
INFO - 2018-08-16 15:45:23 --> Router Class Initialized
INFO - 2018-08-16 15:45:23 --> Output Class Initialized
INFO - 2018-08-16 15:45:23 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:23 --> CSRF cookie sent
INFO - 2018-08-16 15:45:23 --> Input Class Initialized
INFO - 2018-08-16 15:45:23 --> Language Class Initialized
INFO - 2018-08-16 15:45:23 --> Loader Class Initialized
INFO - 2018-08-16 15:45:23 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:23 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:23 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:23 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:23 --> Controller Class Initialized
INFO - 2018-08-16 15:45:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:23 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:23 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:23 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 15:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:45:23 --> Final output sent to browser
DEBUG - 2018-08-16 15:45:23 --> Total execution time: 0.0525
INFO - 2018-08-16 15:45:40 --> Config Class Initialized
INFO - 2018-08-16 15:45:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:40 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:40 --> URI Class Initialized
INFO - 2018-08-16 15:45:40 --> Router Class Initialized
INFO - 2018-08-16 15:45:40 --> Output Class Initialized
INFO - 2018-08-16 15:45:40 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:40 --> CSRF cookie sent
INFO - 2018-08-16 15:45:40 --> Input Class Initialized
INFO - 2018-08-16 15:45:40 --> Language Class Initialized
INFO - 2018-08-16 15:45:40 --> Loader Class Initialized
INFO - 2018-08-16 15:45:40 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:40 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:40 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:40 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:40 --> Controller Class Initialized
INFO - 2018-08-16 15:45:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:40 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:40 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:40 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 15:45:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:45:40 --> Final output sent to browser
DEBUG - 2018-08-16 15:45:40 --> Total execution time: 0.0479
INFO - 2018-08-16 15:45:45 --> Config Class Initialized
INFO - 2018-08-16 15:45:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:45 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:45 --> URI Class Initialized
INFO - 2018-08-16 15:45:45 --> Router Class Initialized
INFO - 2018-08-16 15:45:45 --> Output Class Initialized
INFO - 2018-08-16 15:45:45 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:45 --> CSRF cookie sent
INFO - 2018-08-16 15:45:45 --> Input Class Initialized
INFO - 2018-08-16 15:45:45 --> Language Class Initialized
INFO - 2018-08-16 15:45:45 --> Loader Class Initialized
INFO - 2018-08-16 15:45:45 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:45 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:45 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:45 --> Controller Class Initialized
INFO - 2018-08-16 15:45:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:45 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:45 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 15:45:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:45:45 --> Final output sent to browser
DEBUG - 2018-08-16 15:45:45 --> Total execution time: 0.0381
INFO - 2018-08-16 15:45:49 --> Config Class Initialized
INFO - 2018-08-16 15:45:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:49 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:49 --> URI Class Initialized
DEBUG - 2018-08-16 15:45:49 --> No URI present. Default controller set.
INFO - 2018-08-16 15:45:49 --> Router Class Initialized
INFO - 2018-08-16 15:45:49 --> Output Class Initialized
INFO - 2018-08-16 15:45:49 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:49 --> CSRF cookie sent
INFO - 2018-08-16 15:45:49 --> Input Class Initialized
INFO - 2018-08-16 15:45:49 --> Language Class Initialized
INFO - 2018-08-16 15:45:49 --> Loader Class Initialized
INFO - 2018-08-16 15:45:49 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:49 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:49 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:49 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:49 --> Controller Class Initialized
INFO - 2018-08-16 15:45:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:49 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:49 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:45:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:45:49 --> Final output sent to browser
DEBUG - 2018-08-16 15:45:49 --> Total execution time: 0.0346
INFO - 2018-08-16 15:45:57 --> Config Class Initialized
INFO - 2018-08-16 15:45:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:57 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:57 --> URI Class Initialized
INFO - 2018-08-16 15:45:57 --> Router Class Initialized
INFO - 2018-08-16 15:45:57 --> Output Class Initialized
INFO - 2018-08-16 15:45:57 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:57 --> CSRF cookie sent
INFO - 2018-08-16 15:45:57 --> CSRF token verified
INFO - 2018-08-16 15:45:57 --> Input Class Initialized
INFO - 2018-08-16 15:45:57 --> Language Class Initialized
INFO - 2018-08-16 15:45:57 --> Loader Class Initialized
INFO - 2018-08-16 15:45:57 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:57 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:57 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:57 --> Controller Class Initialized
INFO - 2018-08-16 15:45:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:57 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:57 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:57 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:58 --> Config Class Initialized
INFO - 2018-08-16 15:45:58 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:45:58 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:45:58 --> Utf8 Class Initialized
INFO - 2018-08-16 15:45:58 --> URI Class Initialized
INFO - 2018-08-16 15:45:58 --> Router Class Initialized
INFO - 2018-08-16 15:45:58 --> Output Class Initialized
INFO - 2018-08-16 15:45:58 --> Security Class Initialized
DEBUG - 2018-08-16 15:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:45:58 --> CSRF cookie sent
INFO - 2018-08-16 15:45:58 --> Input Class Initialized
INFO - 2018-08-16 15:45:58 --> Language Class Initialized
INFO - 2018-08-16 15:45:58 --> Loader Class Initialized
INFO - 2018-08-16 15:45:58 --> Helper loaded: url_helper
INFO - 2018-08-16 15:45:58 --> Helper loaded: form_helper
INFO - 2018-08-16 15:45:58 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:45:58 --> User Agent Class Initialized
INFO - 2018-08-16 15:45:58 --> Controller Class Initialized
INFO - 2018-08-16 15:45:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:45:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:45:58 --> Pixel_Model class loaded
INFO - 2018-08-16 15:45:58 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:58 --> Database Driver Class Initialized
INFO - 2018-08-16 15:45:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 15:45:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:45:58 --> Final output sent to browser
DEBUG - 2018-08-16 15:45:58 --> Total execution time: 0.0393
INFO - 2018-08-16 15:46:10 --> Config Class Initialized
INFO - 2018-08-16 15:46:10 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:46:10 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:46:10 --> Utf8 Class Initialized
INFO - 2018-08-16 15:46:10 --> URI Class Initialized
INFO - 2018-08-16 15:46:10 --> Router Class Initialized
INFO - 2018-08-16 15:46:10 --> Output Class Initialized
INFO - 2018-08-16 15:46:10 --> Security Class Initialized
DEBUG - 2018-08-16 15:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:46:10 --> CSRF cookie sent
INFO - 2018-08-16 15:46:10 --> Input Class Initialized
INFO - 2018-08-16 15:46:10 --> Language Class Initialized
INFO - 2018-08-16 15:46:10 --> Loader Class Initialized
INFO - 2018-08-16 15:46:10 --> Helper loaded: url_helper
INFO - 2018-08-16 15:46:10 --> Helper loaded: form_helper
INFO - 2018-08-16 15:46:10 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:46:10 --> User Agent Class Initialized
INFO - 2018-08-16 15:46:10 --> Controller Class Initialized
INFO - 2018-08-16 15:46:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:46:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:46:10 --> Pixel_Model class loaded
INFO - 2018-08-16 15:46:10 --> Database Driver Class Initialized
INFO - 2018-08-16 15:46:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-16 15:46:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:46:10 --> Final output sent to browser
DEBUG - 2018-08-16 15:46:10 --> Total execution time: 0.0364
INFO - 2018-08-16 15:46:16 --> Config Class Initialized
INFO - 2018-08-16 15:46:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 15:46:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 15:46:16 --> Utf8 Class Initialized
INFO - 2018-08-16 15:46:16 --> URI Class Initialized
DEBUG - 2018-08-16 15:46:16 --> No URI present. Default controller set.
INFO - 2018-08-16 15:46:16 --> Router Class Initialized
INFO - 2018-08-16 15:46:16 --> Output Class Initialized
INFO - 2018-08-16 15:46:16 --> Security Class Initialized
DEBUG - 2018-08-16 15:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 15:46:16 --> CSRF cookie sent
INFO - 2018-08-16 15:46:16 --> Input Class Initialized
INFO - 2018-08-16 15:46:16 --> Language Class Initialized
INFO - 2018-08-16 15:46:16 --> Loader Class Initialized
INFO - 2018-08-16 15:46:16 --> Helper loaded: url_helper
INFO - 2018-08-16 15:46:16 --> Helper loaded: form_helper
INFO - 2018-08-16 15:46:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 15:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 15:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 15:46:16 --> User Agent Class Initialized
INFO - 2018-08-16 15:46:16 --> Controller Class Initialized
INFO - 2018-08-16 15:46:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 15:46:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 15:46:16 --> Pixel_Model class loaded
INFO - 2018-08-16 15:46:16 --> Database Driver Class Initialized
INFO - 2018-08-16 15:46:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 15:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 15:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 15:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 15:46:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 15:46:16 --> Final output sent to browser
DEBUG - 2018-08-16 15:46:16 --> Total execution time: 0.0486
INFO - 2018-08-16 16:01:29 --> Config Class Initialized
INFO - 2018-08-16 16:01:29 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:01:29 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:01:29 --> Utf8 Class Initialized
INFO - 2018-08-16 16:01:29 --> URI Class Initialized
DEBUG - 2018-08-16 16:01:29 --> No URI present. Default controller set.
INFO - 2018-08-16 16:01:29 --> Router Class Initialized
INFO - 2018-08-16 16:01:29 --> Output Class Initialized
INFO - 2018-08-16 16:01:29 --> Security Class Initialized
DEBUG - 2018-08-16 16:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:01:29 --> CSRF cookie sent
INFO - 2018-08-16 16:01:29 --> Input Class Initialized
INFO - 2018-08-16 16:01:29 --> Language Class Initialized
INFO - 2018-08-16 16:01:29 --> Loader Class Initialized
INFO - 2018-08-16 16:01:29 --> Helper loaded: url_helper
INFO - 2018-08-16 16:01:29 --> Helper loaded: form_helper
INFO - 2018-08-16 16:01:29 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:01:29 --> User Agent Class Initialized
INFO - 2018-08-16 16:01:29 --> Controller Class Initialized
INFO - 2018-08-16 16:01:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:01:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:01:29 --> Pixel_Model class loaded
INFO - 2018-08-16 16:01:29 --> Database Driver Class Initialized
INFO - 2018-08-16 16:01:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:01:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:01:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:01:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:01:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:01:29 --> Final output sent to browser
DEBUG - 2018-08-16 16:01:29 --> Total execution time: 0.0393
INFO - 2018-08-16 16:02:52 --> Config Class Initialized
INFO - 2018-08-16 16:02:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:02:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:02:52 --> Utf8 Class Initialized
INFO - 2018-08-16 16:02:52 --> URI Class Initialized
INFO - 2018-08-16 16:02:52 --> Router Class Initialized
INFO - 2018-08-16 16:02:52 --> Output Class Initialized
INFO - 2018-08-16 16:02:52 --> Security Class Initialized
DEBUG - 2018-08-16 16:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:02:52 --> CSRF cookie sent
INFO - 2018-08-16 16:02:52 --> CSRF token verified
INFO - 2018-08-16 16:02:52 --> Input Class Initialized
INFO - 2018-08-16 16:02:52 --> Language Class Initialized
INFO - 2018-08-16 16:02:52 --> Loader Class Initialized
INFO - 2018-08-16 16:02:52 --> Helper loaded: url_helper
INFO - 2018-08-16 16:02:52 --> Helper loaded: form_helper
INFO - 2018-08-16 16:02:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:02:52 --> User Agent Class Initialized
INFO - 2018-08-16 16:02:52 --> Controller Class Initialized
INFO - 2018-08-16 16:02:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:02:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:02:52 --> Pixel_Model class loaded
INFO - 2018-08-16 16:02:52 --> Database Driver Class Initialized
INFO - 2018-08-16 16:02:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:02:52 --> Database Driver Class Initialized
INFO - 2018-08-16 16:02:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:02:53 --> Config Class Initialized
INFO - 2018-08-16 16:02:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:02:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:02:53 --> Utf8 Class Initialized
INFO - 2018-08-16 16:02:53 --> URI Class Initialized
INFO - 2018-08-16 16:02:53 --> Router Class Initialized
INFO - 2018-08-16 16:02:53 --> Output Class Initialized
INFO - 2018-08-16 16:02:53 --> Security Class Initialized
DEBUG - 2018-08-16 16:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:02:53 --> CSRF cookie sent
INFO - 2018-08-16 16:02:53 --> Input Class Initialized
INFO - 2018-08-16 16:02:53 --> Language Class Initialized
INFO - 2018-08-16 16:02:53 --> Loader Class Initialized
INFO - 2018-08-16 16:02:53 --> Helper loaded: url_helper
INFO - 2018-08-16 16:02:53 --> Helper loaded: form_helper
INFO - 2018-08-16 16:02:53 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:02:53 --> User Agent Class Initialized
INFO - 2018-08-16 16:02:53 --> Controller Class Initialized
INFO - 2018-08-16 16:02:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:02:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:02:53 --> Pixel_Model class loaded
INFO - 2018-08-16 16:02:53 --> Database Driver Class Initialized
INFO - 2018-08-16 16:02:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:02:53 --> Database Driver Class Initialized
INFO - 2018-08-16 16:02:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 16:02:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:02:53 --> Final output sent to browser
DEBUG - 2018-08-16 16:02:53 --> Total execution time: 0.0411
INFO - 2018-08-16 16:03:07 --> Config Class Initialized
INFO - 2018-08-16 16:03:07 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:03:07 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:03:07 --> Utf8 Class Initialized
INFO - 2018-08-16 16:03:07 --> URI Class Initialized
DEBUG - 2018-08-16 16:03:07 --> No URI present. Default controller set.
INFO - 2018-08-16 16:03:07 --> Router Class Initialized
INFO - 2018-08-16 16:03:07 --> Output Class Initialized
INFO - 2018-08-16 16:03:07 --> Security Class Initialized
DEBUG - 2018-08-16 16:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:03:07 --> CSRF cookie sent
INFO - 2018-08-16 16:03:07 --> Input Class Initialized
INFO - 2018-08-16 16:03:07 --> Language Class Initialized
INFO - 2018-08-16 16:03:07 --> Loader Class Initialized
INFO - 2018-08-16 16:03:07 --> Helper loaded: url_helper
INFO - 2018-08-16 16:03:07 --> Helper loaded: form_helper
INFO - 2018-08-16 16:03:07 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:03:07 --> User Agent Class Initialized
INFO - 2018-08-16 16:03:07 --> Controller Class Initialized
INFO - 2018-08-16 16:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:03:07 --> Pixel_Model class loaded
INFO - 2018-08-16 16:03:07 --> Database Driver Class Initialized
INFO - 2018-08-16 16:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:03:07 --> Final output sent to browser
DEBUG - 2018-08-16 16:03:07 --> Total execution time: 0.0338
INFO - 2018-08-16 16:05:45 --> Config Class Initialized
INFO - 2018-08-16 16:05:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:05:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:05:45 --> Utf8 Class Initialized
INFO - 2018-08-16 16:05:45 --> URI Class Initialized
INFO - 2018-08-16 16:05:45 --> Router Class Initialized
INFO - 2018-08-16 16:05:45 --> Output Class Initialized
INFO - 2018-08-16 16:05:45 --> Security Class Initialized
DEBUG - 2018-08-16 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:05:45 --> CSRF cookie sent
INFO - 2018-08-16 16:05:45 --> CSRF token verified
INFO - 2018-08-16 16:05:45 --> Input Class Initialized
INFO - 2018-08-16 16:05:45 --> Language Class Initialized
INFO - 2018-08-16 16:05:45 --> Loader Class Initialized
INFO - 2018-08-16 16:05:45 --> Helper loaded: url_helper
INFO - 2018-08-16 16:05:45 --> Helper loaded: form_helper
INFO - 2018-08-16 16:05:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:05:45 --> User Agent Class Initialized
INFO - 2018-08-16 16:05:45 --> Controller Class Initialized
INFO - 2018-08-16 16:05:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:05:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:05:45 --> Pixel_Model class loaded
INFO - 2018-08-16 16:05:45 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:45 --> Form Validation Class Initialized
INFO - 2018-08-16 16:05:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 16:05:45 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:46 --> Config Class Initialized
INFO - 2018-08-16 16:05:46 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:05:46 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:05:46 --> Utf8 Class Initialized
INFO - 2018-08-16 16:05:46 --> URI Class Initialized
INFO - 2018-08-16 16:05:46 --> Router Class Initialized
INFO - 2018-08-16 16:05:46 --> Output Class Initialized
INFO - 2018-08-16 16:05:46 --> Security Class Initialized
DEBUG - 2018-08-16 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:05:46 --> CSRF cookie sent
INFO - 2018-08-16 16:05:46 --> Input Class Initialized
INFO - 2018-08-16 16:05:46 --> Language Class Initialized
INFO - 2018-08-16 16:05:46 --> Loader Class Initialized
INFO - 2018-08-16 16:05:46 --> Helper loaded: url_helper
INFO - 2018-08-16 16:05:46 --> Helper loaded: form_helper
INFO - 2018-08-16 16:05:46 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:05:46 --> User Agent Class Initialized
INFO - 2018-08-16 16:05:46 --> Controller Class Initialized
INFO - 2018-08-16 16:05:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:05:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:05:46 --> Pixel_Model class loaded
INFO - 2018-08-16 16:05:46 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:46 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 16:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:05:46 --> Final output sent to browser
DEBUG - 2018-08-16 16:05:46 --> Total execution time: 0.0451
INFO - 2018-08-16 16:05:51 --> Config Class Initialized
INFO - 2018-08-16 16:05:51 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:05:51 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:05:51 --> Utf8 Class Initialized
INFO - 2018-08-16 16:05:51 --> URI Class Initialized
INFO - 2018-08-16 16:05:51 --> Router Class Initialized
INFO - 2018-08-16 16:05:51 --> Output Class Initialized
INFO - 2018-08-16 16:05:51 --> Security Class Initialized
DEBUG - 2018-08-16 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:05:51 --> CSRF cookie sent
INFO - 2018-08-16 16:05:51 --> CSRF token verified
INFO - 2018-08-16 16:05:51 --> Input Class Initialized
INFO - 2018-08-16 16:05:51 --> Language Class Initialized
INFO - 2018-08-16 16:05:51 --> Loader Class Initialized
INFO - 2018-08-16 16:05:52 --> Helper loaded: url_helper
INFO - 2018-08-16 16:05:52 --> Helper loaded: form_helper
INFO - 2018-08-16 16:05:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:05:52 --> User Agent Class Initialized
INFO - 2018-08-16 16:05:52 --> Controller Class Initialized
INFO - 2018-08-16 16:05:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:05:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:05:52 --> Pixel_Model class loaded
INFO - 2018-08-16 16:05:52 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:52 --> Form Validation Class Initialized
INFO - 2018-08-16 16:05:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 16:05:52 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:53 --> Config Class Initialized
INFO - 2018-08-16 16:05:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:05:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:05:53 --> Utf8 Class Initialized
INFO - 2018-08-16 16:05:53 --> URI Class Initialized
INFO - 2018-08-16 16:05:53 --> Router Class Initialized
INFO - 2018-08-16 16:05:53 --> Output Class Initialized
INFO - 2018-08-16 16:05:53 --> Security Class Initialized
DEBUG - 2018-08-16 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:05:53 --> CSRF cookie sent
INFO - 2018-08-16 16:05:53 --> Input Class Initialized
INFO - 2018-08-16 16:05:53 --> Language Class Initialized
INFO - 2018-08-16 16:05:53 --> Loader Class Initialized
INFO - 2018-08-16 16:05:53 --> Helper loaded: url_helper
INFO - 2018-08-16 16:05:53 --> Helper loaded: form_helper
INFO - 2018-08-16 16:05:53 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:05:53 --> User Agent Class Initialized
INFO - 2018-08-16 16:05:53 --> Controller Class Initialized
INFO - 2018-08-16 16:05:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:05:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:05:53 --> Pixel_Model class loaded
INFO - 2018-08-16 16:05:53 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:53 --> Database Driver Class Initialized
INFO - 2018-08-16 16:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 16:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:05:53 --> Final output sent to browser
DEBUG - 2018-08-16 16:05:53 --> Total execution time: 0.0403
INFO - 2018-08-16 16:06:11 --> Config Class Initialized
INFO - 2018-08-16 16:06:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:06:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:06:11 --> Utf8 Class Initialized
INFO - 2018-08-16 16:06:11 --> URI Class Initialized
INFO - 2018-08-16 16:06:11 --> Router Class Initialized
INFO - 2018-08-16 16:06:11 --> Output Class Initialized
INFO - 2018-08-16 16:06:11 --> Security Class Initialized
DEBUG - 2018-08-16 16:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:06:11 --> CSRF cookie sent
INFO - 2018-08-16 16:06:11 --> Input Class Initialized
INFO - 2018-08-16 16:06:11 --> Language Class Initialized
INFO - 2018-08-16 16:06:11 --> Loader Class Initialized
INFO - 2018-08-16 16:06:11 --> Helper loaded: url_helper
INFO - 2018-08-16 16:06:11 --> Helper loaded: form_helper
INFO - 2018-08-16 16:06:11 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:06:11 --> User Agent Class Initialized
INFO - 2018-08-16 16:06:11 --> Controller Class Initialized
INFO - 2018-08-16 16:06:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:06:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:06:11 --> Pixel_Model class loaded
INFO - 2018-08-16 16:06:11 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:11 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 16:06:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:06:11 --> Final output sent to browser
DEBUG - 2018-08-16 16:06:11 --> Total execution time: 0.0455
INFO - 2018-08-16 16:06:17 --> Config Class Initialized
INFO - 2018-08-16 16:06:17 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:06:17 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:06:17 --> Utf8 Class Initialized
INFO - 2018-08-16 16:06:17 --> URI Class Initialized
INFO - 2018-08-16 16:06:17 --> Router Class Initialized
INFO - 2018-08-16 16:06:17 --> Output Class Initialized
INFO - 2018-08-16 16:06:17 --> Security Class Initialized
DEBUG - 2018-08-16 16:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:06:17 --> CSRF cookie sent
INFO - 2018-08-16 16:06:17 --> Input Class Initialized
INFO - 2018-08-16 16:06:17 --> Language Class Initialized
INFO - 2018-08-16 16:06:17 --> Loader Class Initialized
INFO - 2018-08-16 16:06:17 --> Helper loaded: url_helper
INFO - 2018-08-16 16:06:17 --> Helper loaded: form_helper
INFO - 2018-08-16 16:06:17 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:06:17 --> User Agent Class Initialized
INFO - 2018-08-16 16:06:17 --> Controller Class Initialized
INFO - 2018-08-16 16:06:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:06:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:06:17 --> Pixel_Model class loaded
INFO - 2018-08-16 16:06:17 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:17 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 16:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:06:17 --> Final output sent to browser
DEBUG - 2018-08-16 16:06:17 --> Total execution time: 0.0457
INFO - 2018-08-16 16:06:27 --> Config Class Initialized
INFO - 2018-08-16 16:06:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:06:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:06:27 --> Utf8 Class Initialized
INFO - 2018-08-16 16:06:27 --> URI Class Initialized
INFO - 2018-08-16 16:06:27 --> Router Class Initialized
INFO - 2018-08-16 16:06:27 --> Output Class Initialized
INFO - 2018-08-16 16:06:27 --> Security Class Initialized
DEBUG - 2018-08-16 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:06:27 --> CSRF cookie sent
INFO - 2018-08-16 16:06:27 --> Input Class Initialized
INFO - 2018-08-16 16:06:27 --> Language Class Initialized
INFO - 2018-08-16 16:06:27 --> Loader Class Initialized
INFO - 2018-08-16 16:06:27 --> Helper loaded: url_helper
INFO - 2018-08-16 16:06:27 --> Helper loaded: form_helper
INFO - 2018-08-16 16:06:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:06:27 --> User Agent Class Initialized
INFO - 2018-08-16 16:06:27 --> Controller Class Initialized
INFO - 2018-08-16 16:06:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:06:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:06:27 --> Pixel_Model class loaded
INFO - 2018-08-16 16:06:27 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:27 --> Database Driver Class Initialized
INFO - 2018-08-16 16:06:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 16:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:06:27 --> Final output sent to browser
DEBUG - 2018-08-16 16:06:27 --> Total execution time: 0.0575
INFO - 2018-08-16 16:07:02 --> Config Class Initialized
INFO - 2018-08-16 16:07:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:07:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:07:02 --> Utf8 Class Initialized
INFO - 2018-08-16 16:07:02 --> URI Class Initialized
INFO - 2018-08-16 16:07:02 --> Router Class Initialized
INFO - 2018-08-16 16:07:02 --> Output Class Initialized
INFO - 2018-08-16 16:07:02 --> Security Class Initialized
DEBUG - 2018-08-16 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:07:02 --> CSRF cookie sent
INFO - 2018-08-16 16:07:02 --> Input Class Initialized
INFO - 2018-08-16 16:07:02 --> Language Class Initialized
INFO - 2018-08-16 16:07:02 --> Loader Class Initialized
INFO - 2018-08-16 16:07:02 --> Helper loaded: url_helper
INFO - 2018-08-16 16:07:02 --> Helper loaded: form_helper
INFO - 2018-08-16 16:07:02 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:07:02 --> User Agent Class Initialized
INFO - 2018-08-16 16:07:02 --> Controller Class Initialized
INFO - 2018-08-16 16:07:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:07:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:07:02 --> Pixel_Model class loaded
INFO - 2018-08-16 16:07:02 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:02 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-16 16:07:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:07:02 --> Final output sent to browser
DEBUG - 2018-08-16 16:07:02 --> Total execution time: 0.0438
INFO - 2018-08-16 16:07:04 --> Config Class Initialized
INFO - 2018-08-16 16:07:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:07:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:07:04 --> Utf8 Class Initialized
INFO - 2018-08-16 16:07:04 --> URI Class Initialized
INFO - 2018-08-16 16:07:04 --> Router Class Initialized
INFO - 2018-08-16 16:07:04 --> Output Class Initialized
INFO - 2018-08-16 16:07:04 --> Security Class Initialized
DEBUG - 2018-08-16 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:07:04 --> CSRF cookie sent
INFO - 2018-08-16 16:07:04 --> Input Class Initialized
INFO - 2018-08-16 16:07:04 --> Language Class Initialized
INFO - 2018-08-16 16:07:04 --> Loader Class Initialized
INFO - 2018-08-16 16:07:04 --> Helper loaded: url_helper
INFO - 2018-08-16 16:07:04 --> Helper loaded: form_helper
INFO - 2018-08-16 16:07:04 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:07:04 --> User Agent Class Initialized
INFO - 2018-08-16 16:07:04 --> Controller Class Initialized
INFO - 2018-08-16 16:07:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:07:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:07:04 --> Pixel_Model class loaded
INFO - 2018-08-16 16:07:04 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:04 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-16 16:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:07:04 --> Final output sent to browser
DEBUG - 2018-08-16 16:07:04 --> Total execution time: 0.0452
INFO - 2018-08-16 16:07:06 --> Config Class Initialized
INFO - 2018-08-16 16:07:06 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:07:06 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:07:06 --> Utf8 Class Initialized
INFO - 2018-08-16 16:07:06 --> URI Class Initialized
INFO - 2018-08-16 16:07:06 --> Router Class Initialized
INFO - 2018-08-16 16:07:06 --> Output Class Initialized
INFO - 2018-08-16 16:07:06 --> Security Class Initialized
DEBUG - 2018-08-16 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:07:06 --> CSRF cookie sent
INFO - 2018-08-16 16:07:06 --> Input Class Initialized
INFO - 2018-08-16 16:07:06 --> Language Class Initialized
INFO - 2018-08-16 16:07:06 --> Loader Class Initialized
INFO - 2018-08-16 16:07:06 --> Helper loaded: url_helper
INFO - 2018-08-16 16:07:06 --> Helper loaded: form_helper
INFO - 2018-08-16 16:07:06 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:07:06 --> User Agent Class Initialized
INFO - 2018-08-16 16:07:06 --> Controller Class Initialized
INFO - 2018-08-16 16:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:07:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:07:06 --> Pixel_Model class loaded
INFO - 2018-08-16 16:07:06 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:06 --> Database Driver Class Initialized
INFO - 2018-08-16 16:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-16 16:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:07:06 --> Final output sent to browser
DEBUG - 2018-08-16 16:07:06 --> Total execution time: 0.0440
INFO - 2018-08-16 16:15:09 --> Config Class Initialized
INFO - 2018-08-16 16:15:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:15:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:15:09 --> Utf8 Class Initialized
INFO - 2018-08-16 16:15:09 --> URI Class Initialized
INFO - 2018-08-16 16:15:09 --> Router Class Initialized
INFO - 2018-08-16 16:15:09 --> Output Class Initialized
INFO - 2018-08-16 16:15:09 --> Security Class Initialized
DEBUG - 2018-08-16 16:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:15:09 --> CSRF cookie sent
INFO - 2018-08-16 16:15:09 --> Input Class Initialized
INFO - 2018-08-16 16:15:09 --> Language Class Initialized
INFO - 2018-08-16 16:15:09 --> Loader Class Initialized
INFO - 2018-08-16 16:15:09 --> Helper loaded: url_helper
INFO - 2018-08-16 16:15:09 --> Helper loaded: form_helper
INFO - 2018-08-16 16:15:09 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:15:09 --> User Agent Class Initialized
INFO - 2018-08-16 16:15:09 --> Controller Class Initialized
INFO - 2018-08-16 16:15:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:15:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:15:09 --> Pixel_Model class loaded
INFO - 2018-08-16 16:15:09 --> Database Driver Class Initialized
INFO - 2018-08-16 16:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:15:09 --> Database Driver Class Initialized
INFO - 2018-08-16 16:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-16 16:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:15:09 --> Final output sent to browser
DEBUG - 2018-08-16 16:15:09 --> Total execution time: 0.0450
INFO - 2018-08-16 16:15:12 --> Config Class Initialized
INFO - 2018-08-16 16:15:12 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:15:12 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:15:12 --> Utf8 Class Initialized
INFO - 2018-08-16 16:15:12 --> URI Class Initialized
INFO - 2018-08-16 16:15:12 --> Router Class Initialized
INFO - 2018-08-16 16:15:12 --> Output Class Initialized
INFO - 2018-08-16 16:15:12 --> Security Class Initialized
DEBUG - 2018-08-16 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:15:12 --> CSRF cookie sent
INFO - 2018-08-16 16:15:12 --> Input Class Initialized
INFO - 2018-08-16 16:15:12 --> Language Class Initialized
INFO - 2018-08-16 16:15:12 --> Loader Class Initialized
INFO - 2018-08-16 16:15:12 --> Helper loaded: url_helper
INFO - 2018-08-16 16:15:12 --> Helper loaded: form_helper
INFO - 2018-08-16 16:15:12 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:15:12 --> User Agent Class Initialized
INFO - 2018-08-16 16:15:12 --> Controller Class Initialized
INFO - 2018-08-16 16:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:15:12 --> Pixel_Model class loaded
INFO - 2018-08-16 16:15:12 --> Database Driver Class Initialized
INFO - 2018-08-16 16:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:15:13 --> Config Class Initialized
INFO - 2018-08-16 16:15:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:15:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:15:13 --> Utf8 Class Initialized
INFO - 2018-08-16 16:15:13 --> URI Class Initialized
INFO - 2018-08-16 16:15:13 --> Router Class Initialized
INFO - 2018-08-16 16:15:13 --> Output Class Initialized
INFO - 2018-08-16 16:15:13 --> Security Class Initialized
DEBUG - 2018-08-16 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:15:13 --> CSRF cookie sent
INFO - 2018-08-16 16:15:13 --> Input Class Initialized
INFO - 2018-08-16 16:15:13 --> Language Class Initialized
INFO - 2018-08-16 16:15:13 --> Loader Class Initialized
INFO - 2018-08-16 16:15:13 --> Helper loaded: url_helper
INFO - 2018-08-16 16:15:13 --> Helper loaded: form_helper
INFO - 2018-08-16 16:15:13 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:15:13 --> User Agent Class Initialized
INFO - 2018-08-16 16:15:13 --> Controller Class Initialized
INFO - 2018-08-16 16:15:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:15:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:15:13 --> Pixel_Model class loaded
INFO - 2018-08-16 16:15:13 --> Database Driver Class Initialized
INFO - 2018-08-16 16:15:13 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-16 16:15:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-16 16:15:13 --> Could not find the language line "req_email"
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-16 16:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:15:13 --> Final output sent to browser
DEBUG - 2018-08-16 16:15:13 --> Total execution time: 0.0355
INFO - 2018-08-16 16:15:55 --> Config Class Initialized
INFO - 2018-08-16 16:15:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:15:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:15:55 --> Utf8 Class Initialized
INFO - 2018-08-16 16:15:55 --> URI Class Initialized
DEBUG - 2018-08-16 16:15:55 --> No URI present. Default controller set.
INFO - 2018-08-16 16:15:55 --> Router Class Initialized
INFO - 2018-08-16 16:15:55 --> Output Class Initialized
INFO - 2018-08-16 16:15:55 --> Security Class Initialized
DEBUG - 2018-08-16 16:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:15:55 --> CSRF cookie sent
INFO - 2018-08-16 16:15:55 --> Input Class Initialized
INFO - 2018-08-16 16:15:55 --> Language Class Initialized
INFO - 2018-08-16 16:15:55 --> Loader Class Initialized
INFO - 2018-08-16 16:15:55 --> Helper loaded: url_helper
INFO - 2018-08-16 16:15:55 --> Helper loaded: form_helper
INFO - 2018-08-16 16:15:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:15:55 --> User Agent Class Initialized
INFO - 2018-08-16 16:15:55 --> Controller Class Initialized
INFO - 2018-08-16 16:15:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:15:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:15:55 --> Pixel_Model class loaded
INFO - 2018-08-16 16:15:55 --> Database Driver Class Initialized
INFO - 2018-08-16 16:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:15:55 --> Final output sent to browser
DEBUG - 2018-08-16 16:15:55 --> Total execution time: 0.0334
INFO - 2018-08-16 16:16:13 --> Config Class Initialized
INFO - 2018-08-16 16:16:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:16:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:16:13 --> Utf8 Class Initialized
INFO - 2018-08-16 16:16:13 --> URI Class Initialized
DEBUG - 2018-08-16 16:16:13 --> No URI present. Default controller set.
INFO - 2018-08-16 16:16:13 --> Router Class Initialized
INFO - 2018-08-16 16:16:13 --> Output Class Initialized
INFO - 2018-08-16 16:16:13 --> Security Class Initialized
DEBUG - 2018-08-16 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:16:13 --> CSRF cookie sent
INFO - 2018-08-16 16:16:13 --> Input Class Initialized
INFO - 2018-08-16 16:16:13 --> Language Class Initialized
INFO - 2018-08-16 16:16:13 --> Loader Class Initialized
INFO - 2018-08-16 16:16:13 --> Helper loaded: url_helper
INFO - 2018-08-16 16:16:13 --> Helper loaded: form_helper
INFO - 2018-08-16 16:16:13 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:16:13 --> User Agent Class Initialized
INFO - 2018-08-16 16:16:13 --> Controller Class Initialized
INFO - 2018-08-16 16:16:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:16:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:16:13 --> Pixel_Model class loaded
INFO - 2018-08-16 16:16:13 --> Database Driver Class Initialized
INFO - 2018-08-16 16:16:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:16:13 --> Final output sent to browser
DEBUG - 2018-08-16 16:16:13 --> Total execution time: 0.0345
INFO - 2018-08-16 16:16:45 --> Config Class Initialized
INFO - 2018-08-16 16:16:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:16:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:16:45 --> Utf8 Class Initialized
INFO - 2018-08-16 16:16:45 --> URI Class Initialized
DEBUG - 2018-08-16 16:16:45 --> No URI present. Default controller set.
INFO - 2018-08-16 16:16:45 --> Router Class Initialized
INFO - 2018-08-16 16:16:45 --> Output Class Initialized
INFO - 2018-08-16 16:16:45 --> Security Class Initialized
DEBUG - 2018-08-16 16:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:16:45 --> CSRF cookie sent
INFO - 2018-08-16 16:16:45 --> Input Class Initialized
INFO - 2018-08-16 16:16:45 --> Language Class Initialized
INFO - 2018-08-16 16:16:45 --> Loader Class Initialized
INFO - 2018-08-16 16:16:45 --> Helper loaded: url_helper
INFO - 2018-08-16 16:16:45 --> Helper loaded: form_helper
INFO - 2018-08-16 16:16:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:16:45 --> User Agent Class Initialized
INFO - 2018-08-16 16:16:45 --> Controller Class Initialized
INFO - 2018-08-16 16:16:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:16:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:16:45 --> Pixel_Model class loaded
INFO - 2018-08-16 16:16:45 --> Database Driver Class Initialized
INFO - 2018-08-16 16:16:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:16:45 --> Final output sent to browser
DEBUG - 2018-08-16 16:16:45 --> Total execution time: 0.0380
INFO - 2018-08-16 16:17:59 --> Config Class Initialized
INFO - 2018-08-16 16:17:59 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:17:59 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:17:59 --> Utf8 Class Initialized
INFO - 2018-08-16 16:17:59 --> URI Class Initialized
DEBUG - 2018-08-16 16:17:59 --> No URI present. Default controller set.
INFO - 2018-08-16 16:17:59 --> Router Class Initialized
INFO - 2018-08-16 16:17:59 --> Output Class Initialized
INFO - 2018-08-16 16:17:59 --> Security Class Initialized
DEBUG - 2018-08-16 16:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:17:59 --> CSRF cookie sent
INFO - 2018-08-16 16:17:59 --> Input Class Initialized
INFO - 2018-08-16 16:17:59 --> Language Class Initialized
INFO - 2018-08-16 16:17:59 --> Loader Class Initialized
INFO - 2018-08-16 16:17:59 --> Helper loaded: url_helper
INFO - 2018-08-16 16:17:59 --> Helper loaded: form_helper
INFO - 2018-08-16 16:17:59 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:17:59 --> User Agent Class Initialized
INFO - 2018-08-16 16:17:59 --> Controller Class Initialized
INFO - 2018-08-16 16:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:17:59 --> Pixel_Model class loaded
INFO - 2018-08-16 16:17:59 --> Database Driver Class Initialized
INFO - 2018-08-16 16:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:17:59 --> Final output sent to browser
DEBUG - 2018-08-16 16:17:59 --> Total execution time: 0.0528
INFO - 2018-08-16 16:25:13 --> Config Class Initialized
INFO - 2018-08-16 16:25:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:13 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:13 --> URI Class Initialized
INFO - 2018-08-16 16:25:13 --> Router Class Initialized
INFO - 2018-08-16 16:25:13 --> Output Class Initialized
INFO - 2018-08-16 16:25:13 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:13 --> CSRF cookie sent
INFO - 2018-08-16 16:25:13 --> Input Class Initialized
INFO - 2018-08-16 16:25:13 --> Language Class Initialized
INFO - 2018-08-16 16:25:13 --> Loader Class Initialized
INFO - 2018-08-16 16:25:13 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:13 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:13 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:13 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:13 --> Controller Class Initialized
INFO - 2018-08-16 16:25:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:13 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:13 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:13 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 16:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:13 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:13 --> Total execution time: 0.0545
INFO - 2018-08-16 16:25:15 --> Config Class Initialized
INFO - 2018-08-16 16:25:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:15 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:15 --> URI Class Initialized
INFO - 2018-08-16 16:25:15 --> Router Class Initialized
INFO - 2018-08-16 16:25:15 --> Output Class Initialized
INFO - 2018-08-16 16:25:15 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:15 --> CSRF cookie sent
INFO - 2018-08-16 16:25:15 --> Input Class Initialized
INFO - 2018-08-16 16:25:15 --> Language Class Initialized
INFO - 2018-08-16 16:25:15 --> Loader Class Initialized
INFO - 2018-08-16 16:25:15 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:15 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:15 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:15 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:15 --> Controller Class Initialized
INFO - 2018-08-16 16:25:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:15 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:15 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:15 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 16:25:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:15 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:15 --> Total execution time: 0.0418
INFO - 2018-08-16 16:25:16 --> Config Class Initialized
INFO - 2018-08-16 16:25:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:16 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:16 --> URI Class Initialized
INFO - 2018-08-16 16:25:16 --> Router Class Initialized
INFO - 2018-08-16 16:25:16 --> Output Class Initialized
INFO - 2018-08-16 16:25:16 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:16 --> CSRF cookie sent
INFO - 2018-08-16 16:25:16 --> Input Class Initialized
INFO - 2018-08-16 16:25:16 --> Language Class Initialized
INFO - 2018-08-16 16:25:16 --> Loader Class Initialized
INFO - 2018-08-16 16:25:16 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:16 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:16 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:16 --> Controller Class Initialized
INFO - 2018-08-16 16:25:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:16 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:16 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:16 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 16:25:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:16 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:16 --> Total execution time: 0.0480
INFO - 2018-08-16 16:25:18 --> Config Class Initialized
INFO - 2018-08-16 16:25:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:18 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:18 --> URI Class Initialized
INFO - 2018-08-16 16:25:18 --> Router Class Initialized
INFO - 2018-08-16 16:25:18 --> Output Class Initialized
INFO - 2018-08-16 16:25:18 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:18 --> CSRF cookie sent
INFO - 2018-08-16 16:25:18 --> Input Class Initialized
INFO - 2018-08-16 16:25:18 --> Language Class Initialized
INFO - 2018-08-16 16:25:18 --> Loader Class Initialized
INFO - 2018-08-16 16:25:18 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:18 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:18 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:18 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:18 --> Controller Class Initialized
INFO - 2018-08-16 16:25:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:18 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:18 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:18 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 16:25:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:18 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:18 --> Total execution time: 0.0514
INFO - 2018-08-16 16:25:26 --> Config Class Initialized
INFO - 2018-08-16 16:25:26 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:26 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:26 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:26 --> URI Class Initialized
INFO - 2018-08-16 16:25:26 --> Router Class Initialized
INFO - 2018-08-16 16:25:26 --> Output Class Initialized
INFO - 2018-08-16 16:25:26 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:26 --> CSRF cookie sent
INFO - 2018-08-16 16:25:26 --> Input Class Initialized
INFO - 2018-08-16 16:25:26 --> Language Class Initialized
INFO - 2018-08-16 16:25:26 --> Loader Class Initialized
INFO - 2018-08-16 16:25:26 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:26 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:26 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:26 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:26 --> Controller Class Initialized
INFO - 2018-08-16 16:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:26 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:26 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:26 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-16 16:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:26 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:26 --> Total execution time: 0.0500
INFO - 2018-08-16 16:25:27 --> Config Class Initialized
INFO - 2018-08-16 16:25:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:27 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:27 --> URI Class Initialized
INFO - 2018-08-16 16:25:27 --> Router Class Initialized
INFO - 2018-08-16 16:25:27 --> Output Class Initialized
INFO - 2018-08-16 16:25:27 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:27 --> CSRF cookie sent
INFO - 2018-08-16 16:25:27 --> Input Class Initialized
INFO - 2018-08-16 16:25:27 --> Language Class Initialized
INFO - 2018-08-16 16:25:27 --> Loader Class Initialized
INFO - 2018-08-16 16:25:27 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:27 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:27 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:27 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:27 --> Controller Class Initialized
INFO - 2018-08-16 16:25:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:27 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:27 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:27 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-16 16:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:27 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:27 --> Total execution time: 0.0453
INFO - 2018-08-16 16:25:28 --> Config Class Initialized
INFO - 2018-08-16 16:25:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:28 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:28 --> URI Class Initialized
INFO - 2018-08-16 16:25:28 --> Router Class Initialized
INFO - 2018-08-16 16:25:28 --> Output Class Initialized
INFO - 2018-08-16 16:25:28 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:28 --> CSRF cookie sent
INFO - 2018-08-16 16:25:28 --> Input Class Initialized
INFO - 2018-08-16 16:25:28 --> Language Class Initialized
INFO - 2018-08-16 16:25:28 --> Loader Class Initialized
INFO - 2018-08-16 16:25:28 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:28 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:28 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:28 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:28 --> Controller Class Initialized
INFO - 2018-08-16 16:25:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:28 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:29 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:29 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-16 16:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:29 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:29 --> Total execution time: 0.0591
INFO - 2018-08-16 16:25:31 --> Config Class Initialized
INFO - 2018-08-16 16:25:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:31 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:31 --> URI Class Initialized
INFO - 2018-08-16 16:25:31 --> Router Class Initialized
INFO - 2018-08-16 16:25:31 --> Output Class Initialized
INFO - 2018-08-16 16:25:31 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:31 --> CSRF cookie sent
INFO - 2018-08-16 16:25:31 --> Input Class Initialized
INFO - 2018-08-16 16:25:31 --> Language Class Initialized
INFO - 2018-08-16 16:25:31 --> Loader Class Initialized
INFO - 2018-08-16 16:25:31 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:31 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:31 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:31 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:31 --> Controller Class Initialized
INFO - 2018-08-16 16:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:31 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:31 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:31 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-16 16:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:31 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:31 --> Total execution time: 0.0563
INFO - 2018-08-16 16:25:32 --> Config Class Initialized
INFO - 2018-08-16 16:25:32 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:32 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:32 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:32 --> URI Class Initialized
INFO - 2018-08-16 16:25:32 --> Router Class Initialized
INFO - 2018-08-16 16:25:32 --> Output Class Initialized
INFO - 2018-08-16 16:25:32 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:32 --> CSRF cookie sent
INFO - 2018-08-16 16:25:32 --> Input Class Initialized
INFO - 2018-08-16 16:25:32 --> Language Class Initialized
INFO - 2018-08-16 16:25:32 --> Loader Class Initialized
INFO - 2018-08-16 16:25:32 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:32 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:32 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:32 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:32 --> Controller Class Initialized
INFO - 2018-08-16 16:25:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:32 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:32 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:32 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-16 16:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:32 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:32 --> Total execution time: 0.0384
INFO - 2018-08-16 16:25:34 --> Config Class Initialized
INFO - 2018-08-16 16:25:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:34 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:34 --> URI Class Initialized
INFO - 2018-08-16 16:25:34 --> Router Class Initialized
INFO - 2018-08-16 16:25:34 --> Output Class Initialized
INFO - 2018-08-16 16:25:34 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:34 --> CSRF cookie sent
INFO - 2018-08-16 16:25:34 --> Input Class Initialized
INFO - 2018-08-16 16:25:34 --> Language Class Initialized
ERROR - 2018-08-16 16:25:34 --> 404 Page Not Found: Financial-solution/index
INFO - 2018-08-16 16:25:35 --> Config Class Initialized
INFO - 2018-08-16 16:25:35 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:35 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:35 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:35 --> URI Class Initialized
INFO - 2018-08-16 16:25:35 --> Router Class Initialized
INFO - 2018-08-16 16:25:35 --> Output Class Initialized
INFO - 2018-08-16 16:25:35 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:35 --> CSRF cookie sent
INFO - 2018-08-16 16:25:35 --> Input Class Initialized
INFO - 2018-08-16 16:25:35 --> Language Class Initialized
INFO - 2018-08-16 16:25:35 --> Loader Class Initialized
INFO - 2018-08-16 16:25:35 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:35 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:35 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:35 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:35 --> Controller Class Initialized
INFO - 2018-08-16 16:25:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:35 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:35 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:35 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-16 16:25:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:35 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:35 --> Total execution time: 0.0409
INFO - 2018-08-16 16:25:37 --> Config Class Initialized
INFO - 2018-08-16 16:25:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:37 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:37 --> URI Class Initialized
INFO - 2018-08-16 16:25:37 --> Router Class Initialized
INFO - 2018-08-16 16:25:37 --> Output Class Initialized
INFO - 2018-08-16 16:25:37 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:37 --> CSRF cookie sent
INFO - 2018-08-16 16:25:37 --> Input Class Initialized
INFO - 2018-08-16 16:25:37 --> Language Class Initialized
INFO - 2018-08-16 16:25:37 --> Loader Class Initialized
INFO - 2018-08-16 16:25:37 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:37 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:37 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:37 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:37 --> Controller Class Initialized
INFO - 2018-08-16 16:25:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:37 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:37 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:37 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_loans.php
INFO - 2018-08-16 16:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:37 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:37 --> Total execution time: 0.0438
INFO - 2018-08-16 16:25:39 --> Config Class Initialized
INFO - 2018-08-16 16:25:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:39 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:39 --> URI Class Initialized
INFO - 2018-08-16 16:25:39 --> Router Class Initialized
INFO - 2018-08-16 16:25:39 --> Output Class Initialized
INFO - 2018-08-16 16:25:39 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:39 --> CSRF cookie sent
INFO - 2018-08-16 16:25:39 --> Input Class Initialized
INFO - 2018-08-16 16:25:39 --> Language Class Initialized
INFO - 2018-08-16 16:25:39 --> Loader Class Initialized
INFO - 2018-08-16 16:25:39 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:39 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:39 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:39 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:39 --> Controller Class Initialized
INFO - 2018-08-16 16:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:39 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:39 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:39 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_credit_line.php
INFO - 2018-08-16 16:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:39 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:39 --> Total execution time: 0.0444
INFO - 2018-08-16 16:25:41 --> Config Class Initialized
INFO - 2018-08-16 16:25:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:41 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:41 --> URI Class Initialized
INFO - 2018-08-16 16:25:41 --> Router Class Initialized
INFO - 2018-08-16 16:25:41 --> Output Class Initialized
INFO - 2018-08-16 16:25:41 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:41 --> CSRF cookie sent
INFO - 2018-08-16 16:25:41 --> Input Class Initialized
INFO - 2018-08-16 16:25:41 --> Language Class Initialized
INFO - 2018-08-16 16:25:41 --> Loader Class Initialized
INFO - 2018-08-16 16:25:41 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:41 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:41 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:41 --> Controller Class Initialized
INFO - 2018-08-16 16:25:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:41 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:41 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:41 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/credit_cards.php
INFO - 2018-08-16 16:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:41 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:41 --> Total execution time: 0.0442
INFO - 2018-08-16 16:25:42 --> Config Class Initialized
INFO - 2018-08-16 16:25:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:42 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:42 --> URI Class Initialized
INFO - 2018-08-16 16:25:42 --> Router Class Initialized
INFO - 2018-08-16 16:25:42 --> Output Class Initialized
INFO - 2018-08-16 16:25:42 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:42 --> CSRF cookie sent
INFO - 2018-08-16 16:25:42 --> Input Class Initialized
INFO - 2018-08-16 16:25:42 --> Language Class Initialized
INFO - 2018-08-16 16:25:42 --> Loader Class Initialized
INFO - 2018-08-16 16:25:42 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:42 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:42 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:42 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:42 --> Controller Class Initialized
INFO - 2018-08-16 16:25:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:42 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:42 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:42 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_debt.php
INFO - 2018-08-16 16:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:42 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:42 --> Total execution time: 0.0445
INFO - 2018-08-16 16:25:44 --> Config Class Initialized
INFO - 2018-08-16 16:25:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:44 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:44 --> URI Class Initialized
INFO - 2018-08-16 16:25:44 --> Router Class Initialized
INFO - 2018-08-16 16:25:44 --> Output Class Initialized
INFO - 2018-08-16 16:25:44 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:44 --> CSRF cookie sent
INFO - 2018-08-16 16:25:44 --> Input Class Initialized
INFO - 2018-08-16 16:25:44 --> Language Class Initialized
INFO - 2018-08-16 16:25:44 --> Loader Class Initialized
INFO - 2018-08-16 16:25:44 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:44 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:44 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:44 --> Controller Class Initialized
INFO - 2018-08-16 16:25:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:44 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:44 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:44 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-08-16 16:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:44 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:44 --> Total execution time: 0.0540
INFO - 2018-08-16 16:25:45 --> Config Class Initialized
INFO - 2018-08-16 16:25:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:45 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:45 --> URI Class Initialized
INFO - 2018-08-16 16:25:45 --> Router Class Initialized
INFO - 2018-08-16 16:25:45 --> Output Class Initialized
INFO - 2018-08-16 16:25:45 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:45 --> CSRF cookie sent
INFO - 2018-08-16 16:25:45 --> Input Class Initialized
INFO - 2018-08-16 16:25:45 --> Language Class Initialized
INFO - 2018-08-16 16:25:45 --> Loader Class Initialized
INFO - 2018-08-16 16:25:45 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:45 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:45 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:45 --> Controller Class Initialized
INFO - 2018-08-16 16:25:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:45 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:45 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:45 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-16 16:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:45 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:45 --> Total execution time: 0.0470
INFO - 2018-08-16 16:25:51 --> Config Class Initialized
INFO - 2018-08-16 16:25:51 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:51 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:51 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:51 --> URI Class Initialized
INFO - 2018-08-16 16:25:51 --> Router Class Initialized
INFO - 2018-08-16 16:25:51 --> Output Class Initialized
INFO - 2018-08-16 16:25:51 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:51 --> CSRF cookie sent
INFO - 2018-08-16 16:25:51 --> Input Class Initialized
INFO - 2018-08-16 16:25:51 --> Language Class Initialized
INFO - 2018-08-16 16:25:51 --> Loader Class Initialized
INFO - 2018-08-16 16:25:51 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:51 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:51 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:51 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:51 --> Controller Class Initialized
INFO - 2018-08-16 16:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:51 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:51 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:51 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 16:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:51 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:51 --> Total execution time: 0.0439
INFO - 2018-08-16 16:25:54 --> Config Class Initialized
INFO - 2018-08-16 16:25:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:25:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:25:54 --> Utf8 Class Initialized
INFO - 2018-08-16 16:25:54 --> URI Class Initialized
INFO - 2018-08-16 16:25:54 --> Router Class Initialized
INFO - 2018-08-16 16:25:54 --> Output Class Initialized
INFO - 2018-08-16 16:25:54 --> Security Class Initialized
DEBUG - 2018-08-16 16:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:25:54 --> CSRF cookie sent
INFO - 2018-08-16 16:25:54 --> Input Class Initialized
INFO - 2018-08-16 16:25:54 --> Language Class Initialized
INFO - 2018-08-16 16:25:54 --> Loader Class Initialized
INFO - 2018-08-16 16:25:54 --> Helper loaded: url_helper
INFO - 2018-08-16 16:25:54 --> Helper loaded: form_helper
INFO - 2018-08-16 16:25:54 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:25:54 --> User Agent Class Initialized
INFO - 2018-08-16 16:25:54 --> Controller Class Initialized
INFO - 2018-08-16 16:25:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:25:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:25:54 --> Pixel_Model class loaded
INFO - 2018-08-16 16:25:54 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:54 --> Database Driver Class Initialized
INFO - 2018-08-16 16:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-16 16:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:25:54 --> Final output sent to browser
DEBUG - 2018-08-16 16:25:54 --> Total execution time: 0.0692
INFO - 2018-08-16 16:27:40 --> Config Class Initialized
INFO - 2018-08-16 16:27:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:27:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:27:40 --> Utf8 Class Initialized
INFO - 2018-08-16 16:27:40 --> URI Class Initialized
INFO - 2018-08-16 16:27:40 --> Router Class Initialized
INFO - 2018-08-16 16:27:40 --> Output Class Initialized
INFO - 2018-08-16 16:27:40 --> Security Class Initialized
DEBUG - 2018-08-16 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:27:40 --> CSRF cookie sent
INFO - 2018-08-16 16:27:40 --> Input Class Initialized
INFO - 2018-08-16 16:27:40 --> Language Class Initialized
INFO - 2018-08-16 16:27:40 --> Loader Class Initialized
INFO - 2018-08-16 16:27:40 --> Helper loaded: url_helper
INFO - 2018-08-16 16:27:40 --> Helper loaded: form_helper
INFO - 2018-08-16 16:27:40 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:27:40 --> User Agent Class Initialized
INFO - 2018-08-16 16:27:40 --> Controller Class Initialized
INFO - 2018-08-16 16:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:27:40 --> Pixel_Model class loaded
INFO - 2018-08-16 16:27:40 --> Database Driver Class Initialized
INFO - 2018-08-16 16:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:27:40 --> Database Driver Class Initialized
INFO - 2018-08-16 16:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-16 16:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:27:40 --> Final output sent to browser
DEBUG - 2018-08-16 16:27:40 --> Total execution time: 0.0535
INFO - 2018-08-16 16:27:49 --> Config Class Initialized
INFO - 2018-08-16 16:27:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:27:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:27:49 --> Utf8 Class Initialized
INFO - 2018-08-16 16:27:49 --> URI Class Initialized
INFO - 2018-08-16 16:27:49 --> Router Class Initialized
INFO - 2018-08-16 16:27:49 --> Output Class Initialized
INFO - 2018-08-16 16:27:49 --> Security Class Initialized
DEBUG - 2018-08-16 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:27:49 --> CSRF cookie sent
INFO - 2018-08-16 16:27:49 --> Input Class Initialized
INFO - 2018-08-16 16:27:49 --> Language Class Initialized
INFO - 2018-08-16 16:27:49 --> Loader Class Initialized
INFO - 2018-08-16 16:27:49 --> Helper loaded: url_helper
INFO - 2018-08-16 16:27:49 --> Helper loaded: form_helper
INFO - 2018-08-16 16:27:49 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:27:49 --> User Agent Class Initialized
INFO - 2018-08-16 16:27:49 --> Controller Class Initialized
INFO - 2018-08-16 16:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:27:49 --> Pixel_Model class loaded
INFO - 2018-08-16 16:27:49 --> Database Driver Class Initialized
INFO - 2018-08-16 16:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:27:49 --> Database Driver Class Initialized
INFO - 2018-08-16 16:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 16:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:27:49 --> Final output sent to browser
DEBUG - 2018-08-16 16:27:49 --> Total execution time: 0.0466
INFO - 2018-08-16 16:29:15 --> Config Class Initialized
INFO - 2018-08-16 16:29:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:29:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:29:15 --> Utf8 Class Initialized
INFO - 2018-08-16 16:29:15 --> URI Class Initialized
INFO - 2018-08-16 16:29:15 --> Router Class Initialized
INFO - 2018-08-16 16:29:15 --> Output Class Initialized
INFO - 2018-08-16 16:29:15 --> Security Class Initialized
DEBUG - 2018-08-16 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:29:15 --> CSRF cookie sent
INFO - 2018-08-16 16:29:15 --> Input Class Initialized
INFO - 2018-08-16 16:29:15 --> Language Class Initialized
INFO - 2018-08-16 16:29:15 --> Loader Class Initialized
INFO - 2018-08-16 16:29:15 --> Helper loaded: url_helper
INFO - 2018-08-16 16:29:15 --> Helper loaded: form_helper
INFO - 2018-08-16 16:29:15 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:29:15 --> User Agent Class Initialized
INFO - 2018-08-16 16:29:15 --> Controller Class Initialized
INFO - 2018-08-16 16:29:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:29:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:29:15 --> Pixel_Model class loaded
INFO - 2018-08-16 16:29:15 --> Database Driver Class Initialized
INFO - 2018-08-16 16:29:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:29:15 --> Database Driver Class Initialized
INFO - 2018-08-16 16:29:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-16 16:29:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:29:15 --> Final output sent to browser
DEBUG - 2018-08-16 16:29:15 --> Total execution time: 0.0635
INFO - 2018-08-16 16:29:18 --> Config Class Initialized
INFO - 2018-08-16 16:29:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:29:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:29:18 --> Utf8 Class Initialized
INFO - 2018-08-16 16:29:18 --> URI Class Initialized
DEBUG - 2018-08-16 16:29:18 --> No URI present. Default controller set.
INFO - 2018-08-16 16:29:18 --> Router Class Initialized
INFO - 2018-08-16 16:29:18 --> Output Class Initialized
INFO - 2018-08-16 16:29:18 --> Security Class Initialized
DEBUG - 2018-08-16 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:29:18 --> CSRF cookie sent
INFO - 2018-08-16 16:29:18 --> Input Class Initialized
INFO - 2018-08-16 16:29:18 --> Language Class Initialized
INFO - 2018-08-16 16:29:18 --> Loader Class Initialized
INFO - 2018-08-16 16:29:18 --> Helper loaded: url_helper
INFO - 2018-08-16 16:29:18 --> Helper loaded: form_helper
INFO - 2018-08-16 16:29:18 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:29:18 --> User Agent Class Initialized
INFO - 2018-08-16 16:29:18 --> Controller Class Initialized
INFO - 2018-08-16 16:29:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:29:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:29:18 --> Pixel_Model class loaded
INFO - 2018-08-16 16:29:18 --> Database Driver Class Initialized
INFO - 2018-08-16 16:29:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:29:18 --> Final output sent to browser
DEBUG - 2018-08-16 16:29:18 --> Total execution time: 0.0393
INFO - 2018-08-16 16:30:18 --> Config Class Initialized
INFO - 2018-08-16 16:30:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:30:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:30:18 --> Utf8 Class Initialized
INFO - 2018-08-16 16:30:18 --> URI Class Initialized
INFO - 2018-08-16 16:30:18 --> Router Class Initialized
INFO - 2018-08-16 16:30:18 --> Output Class Initialized
INFO - 2018-08-16 16:30:18 --> Security Class Initialized
DEBUG - 2018-08-16 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:30:18 --> CSRF cookie sent
INFO - 2018-08-16 16:30:18 --> Input Class Initialized
INFO - 2018-08-16 16:30:18 --> Language Class Initialized
INFO - 2018-08-16 16:30:18 --> Loader Class Initialized
INFO - 2018-08-16 16:30:18 --> Helper loaded: url_helper
INFO - 2018-08-16 16:30:18 --> Helper loaded: form_helper
INFO - 2018-08-16 16:30:18 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:30:18 --> User Agent Class Initialized
INFO - 2018-08-16 16:30:18 --> Controller Class Initialized
INFO - 2018-08-16 16:30:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:30:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:30:18 --> Pixel_Model class loaded
INFO - 2018-08-16 16:30:18 --> Database Driver Class Initialized
INFO - 2018-08-16 16:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-16 16:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:30:18 --> Final output sent to browser
DEBUG - 2018-08-16 16:30:18 --> Total execution time: 0.0406
INFO - 2018-08-16 16:30:22 --> Config Class Initialized
INFO - 2018-08-16 16:30:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:30:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:30:22 --> Utf8 Class Initialized
INFO - 2018-08-16 16:30:22 --> URI Class Initialized
INFO - 2018-08-16 16:30:22 --> Router Class Initialized
INFO - 2018-08-16 16:30:22 --> Output Class Initialized
INFO - 2018-08-16 16:30:22 --> Security Class Initialized
DEBUG - 2018-08-16 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:30:22 --> CSRF cookie sent
INFO - 2018-08-16 16:30:22 --> CSRF token verified
INFO - 2018-08-16 16:30:22 --> Input Class Initialized
INFO - 2018-08-16 16:30:22 --> Language Class Initialized
INFO - 2018-08-16 16:30:22 --> Loader Class Initialized
INFO - 2018-08-16 16:30:22 --> Helper loaded: url_helper
INFO - 2018-08-16 16:30:22 --> Helper loaded: form_helper
INFO - 2018-08-16 16:30:22 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:30:22 --> User Agent Class Initialized
INFO - 2018-08-16 16:30:22 --> Controller Class Initialized
INFO - 2018-08-16 16:30:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:30:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:30:22 --> Pixel_Model class loaded
INFO - 2018-08-16 16:30:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:30:22 --> Form Validation Class Initialized
INFO - 2018-08-16 16:30:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 16:30:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:30:22 --> Config Class Initialized
INFO - 2018-08-16 16:30:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:30:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:30:22 --> Utf8 Class Initialized
INFO - 2018-08-16 16:30:22 --> URI Class Initialized
INFO - 2018-08-16 16:30:22 --> Router Class Initialized
INFO - 2018-08-16 16:30:22 --> Output Class Initialized
INFO - 2018-08-16 16:30:22 --> Security Class Initialized
DEBUG - 2018-08-16 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:30:22 --> CSRF cookie sent
INFO - 2018-08-16 16:30:22 --> Input Class Initialized
INFO - 2018-08-16 16:30:22 --> Language Class Initialized
INFO - 2018-08-16 16:30:22 --> Loader Class Initialized
INFO - 2018-08-16 16:30:22 --> Helper loaded: url_helper
INFO - 2018-08-16 16:30:22 --> Helper loaded: form_helper
INFO - 2018-08-16 16:30:22 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:30:22 --> User Agent Class Initialized
INFO - 2018-08-16 16:30:22 --> Controller Class Initialized
INFO - 2018-08-16 16:30:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:30:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:30:22 --> Pixel_Model class loaded
INFO - 2018-08-16 16:30:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:30:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 16:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:30:22 --> Final output sent to browser
DEBUG - 2018-08-16 16:30:22 --> Total execution time: 0.0439
INFO - 2018-08-16 16:39:55 --> Config Class Initialized
INFO - 2018-08-16 16:39:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:39:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:39:55 --> Utf8 Class Initialized
INFO - 2018-08-16 16:39:55 --> URI Class Initialized
DEBUG - 2018-08-16 16:39:55 --> No URI present. Default controller set.
INFO - 2018-08-16 16:39:55 --> Router Class Initialized
INFO - 2018-08-16 16:39:55 --> Output Class Initialized
INFO - 2018-08-16 16:39:55 --> Security Class Initialized
DEBUG - 2018-08-16 16:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:39:55 --> CSRF cookie sent
INFO - 2018-08-16 16:39:55 --> Input Class Initialized
INFO - 2018-08-16 16:39:55 --> Language Class Initialized
INFO - 2018-08-16 16:39:55 --> Loader Class Initialized
INFO - 2018-08-16 16:39:55 --> Helper loaded: url_helper
INFO - 2018-08-16 16:39:55 --> Helper loaded: form_helper
INFO - 2018-08-16 16:39:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:39:55 --> User Agent Class Initialized
INFO - 2018-08-16 16:39:55 --> Controller Class Initialized
INFO - 2018-08-16 16:39:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:39:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:39:55 --> Pixel_Model class loaded
INFO - 2018-08-16 16:39:55 --> Database Driver Class Initialized
INFO - 2018-08-16 16:39:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:39:55 --> Final output sent to browser
DEBUG - 2018-08-16 16:39:55 --> Total execution time: 0.0334
INFO - 2018-08-16 16:40:10 --> Config Class Initialized
INFO - 2018-08-16 16:40:10 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:40:10 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:40:10 --> Utf8 Class Initialized
INFO - 2018-08-16 16:40:10 --> URI Class Initialized
INFO - 2018-08-16 16:40:10 --> Router Class Initialized
INFO - 2018-08-16 16:40:10 --> Output Class Initialized
INFO - 2018-08-16 16:40:10 --> Security Class Initialized
DEBUG - 2018-08-16 16:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:40:10 --> CSRF cookie sent
INFO - 2018-08-16 16:40:10 --> CSRF token verified
INFO - 2018-08-16 16:40:10 --> Input Class Initialized
INFO - 2018-08-16 16:40:10 --> Language Class Initialized
INFO - 2018-08-16 16:40:10 --> Loader Class Initialized
INFO - 2018-08-16 16:40:10 --> Helper loaded: url_helper
INFO - 2018-08-16 16:40:10 --> Helper loaded: form_helper
INFO - 2018-08-16 16:40:10 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:40:10 --> User Agent Class Initialized
INFO - 2018-08-16 16:40:10 --> Controller Class Initialized
INFO - 2018-08-16 16:40:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:40:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:40:10 --> Pixel_Model class loaded
INFO - 2018-08-16 16:40:10 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:10 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:11 --> Config Class Initialized
INFO - 2018-08-16 16:40:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:40:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:40:11 --> Utf8 Class Initialized
INFO - 2018-08-16 16:40:11 --> URI Class Initialized
INFO - 2018-08-16 16:40:11 --> Router Class Initialized
INFO - 2018-08-16 16:40:11 --> Output Class Initialized
INFO - 2018-08-16 16:40:11 --> Security Class Initialized
DEBUG - 2018-08-16 16:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:40:11 --> CSRF cookie sent
INFO - 2018-08-16 16:40:11 --> Input Class Initialized
INFO - 2018-08-16 16:40:11 --> Language Class Initialized
INFO - 2018-08-16 16:40:11 --> Loader Class Initialized
INFO - 2018-08-16 16:40:11 --> Helper loaded: url_helper
INFO - 2018-08-16 16:40:11 --> Helper loaded: form_helper
INFO - 2018-08-16 16:40:11 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:40:11 --> User Agent Class Initialized
INFO - 2018-08-16 16:40:11 --> Controller Class Initialized
INFO - 2018-08-16 16:40:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:40:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:40:11 --> Pixel_Model class loaded
INFO - 2018-08-16 16:40:11 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:11 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 16:40:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:40:11 --> Final output sent to browser
DEBUG - 2018-08-16 16:40:11 --> Total execution time: 0.0459
INFO - 2018-08-16 16:40:22 --> Config Class Initialized
INFO - 2018-08-16 16:40:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:40:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:40:22 --> Utf8 Class Initialized
INFO - 2018-08-16 16:40:22 --> URI Class Initialized
INFO - 2018-08-16 16:40:22 --> Router Class Initialized
INFO - 2018-08-16 16:40:22 --> Output Class Initialized
INFO - 2018-08-16 16:40:22 --> Security Class Initialized
DEBUG - 2018-08-16 16:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:40:22 --> CSRF cookie sent
INFO - 2018-08-16 16:40:22 --> CSRF token verified
INFO - 2018-08-16 16:40:22 --> Input Class Initialized
INFO - 2018-08-16 16:40:22 --> Language Class Initialized
INFO - 2018-08-16 16:40:22 --> Loader Class Initialized
INFO - 2018-08-16 16:40:22 --> Helper loaded: url_helper
INFO - 2018-08-16 16:40:22 --> Helper loaded: form_helper
INFO - 2018-08-16 16:40:22 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:40:22 --> User Agent Class Initialized
INFO - 2018-08-16 16:40:22 --> Controller Class Initialized
INFO - 2018-08-16 16:40:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:40:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:40:22 --> Pixel_Model class loaded
INFO - 2018-08-16 16:40:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:22 --> Form Validation Class Initialized
INFO - 2018-08-16 16:40:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-16 16:40:22 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:23 --> Config Class Initialized
INFO - 2018-08-16 16:40:23 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:40:23 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:40:23 --> Utf8 Class Initialized
INFO - 2018-08-16 16:40:23 --> URI Class Initialized
INFO - 2018-08-16 16:40:23 --> Router Class Initialized
INFO - 2018-08-16 16:40:23 --> Output Class Initialized
INFO - 2018-08-16 16:40:23 --> Security Class Initialized
DEBUG - 2018-08-16 16:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:40:23 --> CSRF cookie sent
INFO - 2018-08-16 16:40:23 --> Input Class Initialized
INFO - 2018-08-16 16:40:23 --> Language Class Initialized
INFO - 2018-08-16 16:40:23 --> Loader Class Initialized
INFO - 2018-08-16 16:40:23 --> Helper loaded: url_helper
INFO - 2018-08-16 16:40:23 --> Helper loaded: form_helper
INFO - 2018-08-16 16:40:23 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:40:23 --> User Agent Class Initialized
INFO - 2018-08-16 16:40:23 --> Controller Class Initialized
INFO - 2018-08-16 16:40:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:40:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:40:23 --> Pixel_Model class loaded
INFO - 2018-08-16 16:40:23 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:23 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 16:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:40:23 --> Final output sent to browser
DEBUG - 2018-08-16 16:40:23 --> Total execution time: 0.0618
INFO - 2018-08-16 16:40:29 --> Config Class Initialized
INFO - 2018-08-16 16:40:29 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:40:29 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:40:29 --> Utf8 Class Initialized
INFO - 2018-08-16 16:40:29 --> URI Class Initialized
INFO - 2018-08-16 16:40:29 --> Router Class Initialized
INFO - 2018-08-16 16:40:29 --> Output Class Initialized
INFO - 2018-08-16 16:40:29 --> Security Class Initialized
DEBUG - 2018-08-16 16:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:40:29 --> CSRF cookie sent
INFO - 2018-08-16 16:40:29 --> Input Class Initialized
INFO - 2018-08-16 16:40:29 --> Language Class Initialized
INFO - 2018-08-16 16:40:29 --> Loader Class Initialized
INFO - 2018-08-16 16:40:29 --> Helper loaded: url_helper
INFO - 2018-08-16 16:40:29 --> Helper loaded: form_helper
INFO - 2018-08-16 16:40:29 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:40:29 --> User Agent Class Initialized
INFO - 2018-08-16 16:40:29 --> Controller Class Initialized
INFO - 2018-08-16 16:40:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:40:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:40:29 --> Pixel_Model class loaded
INFO - 2018-08-16 16:40:29 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:29 --> Database Driver Class Initialized
INFO - 2018-08-16 16:40:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 16:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:40:29 --> Final output sent to browser
DEBUG - 2018-08-16 16:40:29 --> Total execution time: 0.0431
INFO - 2018-08-16 16:45:51 --> Config Class Initialized
INFO - 2018-08-16 16:45:51 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:45:51 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:45:51 --> Utf8 Class Initialized
INFO - 2018-08-16 16:45:51 --> URI Class Initialized
DEBUG - 2018-08-16 16:45:51 --> No URI present. Default controller set.
INFO - 2018-08-16 16:45:51 --> Router Class Initialized
INFO - 2018-08-16 16:45:51 --> Output Class Initialized
INFO - 2018-08-16 16:45:51 --> Security Class Initialized
DEBUG - 2018-08-16 16:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:45:51 --> CSRF cookie sent
INFO - 2018-08-16 16:45:51 --> Input Class Initialized
INFO - 2018-08-16 16:45:51 --> Language Class Initialized
INFO - 2018-08-16 16:45:51 --> Loader Class Initialized
INFO - 2018-08-16 16:45:51 --> Helper loaded: url_helper
INFO - 2018-08-16 16:45:51 --> Helper loaded: form_helper
INFO - 2018-08-16 16:45:51 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:45:51 --> User Agent Class Initialized
INFO - 2018-08-16 16:45:51 --> Controller Class Initialized
INFO - 2018-08-16 16:45:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:45:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:45:51 --> Pixel_Model class loaded
INFO - 2018-08-16 16:45:51 --> Database Driver Class Initialized
INFO - 2018-08-16 16:45:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:45:51 --> Final output sent to browser
DEBUG - 2018-08-16 16:45:51 --> Total execution time: 0.0434
INFO - 2018-08-16 16:45:52 --> Config Class Initialized
INFO - 2018-08-16 16:45:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 16:45:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 16:45:52 --> Utf8 Class Initialized
INFO - 2018-08-16 16:45:52 --> URI Class Initialized
DEBUG - 2018-08-16 16:45:52 --> No URI present. Default controller set.
INFO - 2018-08-16 16:45:52 --> Router Class Initialized
INFO - 2018-08-16 16:45:52 --> Output Class Initialized
INFO - 2018-08-16 16:45:52 --> Security Class Initialized
DEBUG - 2018-08-16 16:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 16:45:52 --> CSRF cookie sent
INFO - 2018-08-16 16:45:52 --> Input Class Initialized
INFO - 2018-08-16 16:45:52 --> Language Class Initialized
INFO - 2018-08-16 16:45:52 --> Loader Class Initialized
INFO - 2018-08-16 16:45:52 --> Helper loaded: url_helper
INFO - 2018-08-16 16:45:52 --> Helper loaded: form_helper
INFO - 2018-08-16 16:45:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 16:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 16:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 16:45:52 --> User Agent Class Initialized
INFO - 2018-08-16 16:45:52 --> Controller Class Initialized
INFO - 2018-08-16 16:45:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 16:45:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 16:45:52 --> Pixel_Model class loaded
INFO - 2018-08-16 16:45:52 --> Database Driver Class Initialized
INFO - 2018-08-16 16:45:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 16:45:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 16:45:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 16:45:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 16:45:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 16:45:52 --> Final output sent to browser
DEBUG - 2018-08-16 16:45:52 --> Total execution time: 0.0312
INFO - 2018-08-16 18:43:39 --> Config Class Initialized
INFO - 2018-08-16 18:43:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:39 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:39 --> URI Class Initialized
INFO - 2018-08-16 18:43:39 --> Router Class Initialized
INFO - 2018-08-16 18:43:39 --> Output Class Initialized
INFO - 2018-08-16 18:43:39 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:39 --> CSRF cookie sent
INFO - 2018-08-16 18:43:39 --> Input Class Initialized
INFO - 2018-08-16 18:43:39 --> Language Class Initialized
INFO - 2018-08-16 18:43:39 --> Loader Class Initialized
INFO - 2018-08-16 18:43:39 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:39 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:39 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:39 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:39 --> Controller Class Initialized
INFO - 2018-08-16 18:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:39 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:39 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:39 --> Config Class Initialized
INFO - 2018-08-16 18:43:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:39 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:39 --> URI Class Initialized
INFO - 2018-08-16 18:43:39 --> Router Class Initialized
INFO - 2018-08-16 18:43:39 --> Output Class Initialized
INFO - 2018-08-16 18:43:39 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:39 --> CSRF cookie sent
INFO - 2018-08-16 18:43:39 --> Input Class Initialized
INFO - 2018-08-16 18:43:39 --> Language Class Initialized
INFO - 2018-08-16 18:43:39 --> Loader Class Initialized
INFO - 2018-08-16 18:43:39 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:39 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:39 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:39 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:39 --> Controller Class Initialized
INFO - 2018-08-16 18:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:39 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:39 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-16 18:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:39 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:39 --> Total execution time: 0.0325
INFO - 2018-08-16 18:43:41 --> Config Class Initialized
INFO - 2018-08-16 18:43:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:41 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:41 --> URI Class Initialized
INFO - 2018-08-16 18:43:41 --> Router Class Initialized
INFO - 2018-08-16 18:43:41 --> Output Class Initialized
INFO - 2018-08-16 18:43:41 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:41 --> CSRF cookie sent
INFO - 2018-08-16 18:43:41 --> CSRF token verified
INFO - 2018-08-16 18:43:41 --> Input Class Initialized
INFO - 2018-08-16 18:43:41 --> Language Class Initialized
INFO - 2018-08-16 18:43:41 --> Loader Class Initialized
INFO - 2018-08-16 18:43:41 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:41 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:41 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:41 --> Controller Class Initialized
INFO - 2018-08-16 18:43:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:41 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:41 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:41 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:41 --> Config Class Initialized
INFO - 2018-08-16 18:43:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:41 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:41 --> URI Class Initialized
INFO - 2018-08-16 18:43:41 --> Router Class Initialized
INFO - 2018-08-16 18:43:41 --> Output Class Initialized
INFO - 2018-08-16 18:43:41 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:41 --> CSRF cookie sent
INFO - 2018-08-16 18:43:41 --> Input Class Initialized
INFO - 2018-08-16 18:43:41 --> Language Class Initialized
INFO - 2018-08-16 18:43:41 --> Loader Class Initialized
INFO - 2018-08-16 18:43:41 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:41 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:41 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:41 --> Controller Class Initialized
INFO - 2018-08-16 18:43:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:41 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:41 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:41 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 18:43:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:41 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:41 --> Total execution time: 0.0464
INFO - 2018-08-16 18:43:44 --> Config Class Initialized
INFO - 2018-08-16 18:43:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:44 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:44 --> URI Class Initialized
INFO - 2018-08-16 18:43:44 --> Router Class Initialized
INFO - 2018-08-16 18:43:44 --> Output Class Initialized
INFO - 2018-08-16 18:43:44 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:44 --> CSRF cookie sent
INFO - 2018-08-16 18:43:44 --> Input Class Initialized
INFO - 2018-08-16 18:43:44 --> Language Class Initialized
INFO - 2018-08-16 18:43:44 --> Loader Class Initialized
INFO - 2018-08-16 18:43:44 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:44 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:44 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:44 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:44 --> Controller Class Initialized
INFO - 2018-08-16 18:43:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:44 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:44 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 18:43:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:44 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:44 --> Total execution time: 0.0504
INFO - 2018-08-16 18:43:45 --> Config Class Initialized
INFO - 2018-08-16 18:43:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:45 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:45 --> URI Class Initialized
INFO - 2018-08-16 18:43:45 --> Router Class Initialized
INFO - 2018-08-16 18:43:45 --> Output Class Initialized
INFO - 2018-08-16 18:43:45 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:45 --> CSRF cookie sent
INFO - 2018-08-16 18:43:45 --> Input Class Initialized
INFO - 2018-08-16 18:43:45 --> Language Class Initialized
INFO - 2018-08-16 18:43:45 --> Loader Class Initialized
INFO - 2018-08-16 18:43:45 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:45 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:45 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:45 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:45 --> Controller Class Initialized
INFO - 2018-08-16 18:43:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:45 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:45 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:45 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 18:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:45 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:45 --> Total execution time: 0.0551
INFO - 2018-08-16 18:43:46 --> Config Class Initialized
INFO - 2018-08-16 18:43:46 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:46 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:46 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:46 --> URI Class Initialized
INFO - 2018-08-16 18:43:46 --> Router Class Initialized
INFO - 2018-08-16 18:43:46 --> Output Class Initialized
INFO - 2018-08-16 18:43:46 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:46 --> CSRF cookie sent
INFO - 2018-08-16 18:43:46 --> Input Class Initialized
INFO - 2018-08-16 18:43:46 --> Language Class Initialized
INFO - 2018-08-16 18:43:46 --> Loader Class Initialized
INFO - 2018-08-16 18:43:46 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:46 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:46 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:46 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:46 --> Controller Class Initialized
INFO - 2018-08-16 18:43:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:46 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:46 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:46 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 18:43:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:46 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:46 --> Total execution time: 0.0482
INFO - 2018-08-16 18:43:47 --> Config Class Initialized
INFO - 2018-08-16 18:43:47 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:47 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:47 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:47 --> URI Class Initialized
INFO - 2018-08-16 18:43:47 --> Router Class Initialized
INFO - 2018-08-16 18:43:47 --> Output Class Initialized
INFO - 2018-08-16 18:43:47 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:47 --> CSRF cookie sent
INFO - 2018-08-16 18:43:47 --> Input Class Initialized
INFO - 2018-08-16 18:43:47 --> Language Class Initialized
INFO - 2018-08-16 18:43:47 --> Loader Class Initialized
INFO - 2018-08-16 18:43:47 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:47 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:47 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:47 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:47 --> Controller Class Initialized
INFO - 2018-08-16 18:43:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:47 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:47 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:47 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 18:43:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:47 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:47 --> Total execution time: 0.0454
INFO - 2018-08-16 18:43:48 --> Config Class Initialized
INFO - 2018-08-16 18:43:48 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:48 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:48 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:48 --> URI Class Initialized
INFO - 2018-08-16 18:43:48 --> Router Class Initialized
INFO - 2018-08-16 18:43:48 --> Output Class Initialized
INFO - 2018-08-16 18:43:48 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:48 --> CSRF cookie sent
INFO - 2018-08-16 18:43:48 --> Input Class Initialized
INFO - 2018-08-16 18:43:48 --> Language Class Initialized
INFO - 2018-08-16 18:43:48 --> Loader Class Initialized
INFO - 2018-08-16 18:43:48 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:48 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:48 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:48 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:48 --> Controller Class Initialized
INFO - 2018-08-16 18:43:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:48 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:48 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:48 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-16 18:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:48 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:48 --> Total execution time: 0.0489
INFO - 2018-08-16 18:43:51 --> Config Class Initialized
INFO - 2018-08-16 18:43:51 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:51 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:51 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:51 --> URI Class Initialized
INFO - 2018-08-16 18:43:51 --> Router Class Initialized
INFO - 2018-08-16 18:43:51 --> Output Class Initialized
INFO - 2018-08-16 18:43:51 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:51 --> CSRF cookie sent
INFO - 2018-08-16 18:43:51 --> Input Class Initialized
INFO - 2018-08-16 18:43:51 --> Language Class Initialized
INFO - 2018-08-16 18:43:51 --> Loader Class Initialized
INFO - 2018-08-16 18:43:51 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:51 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:51 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:51 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:51 --> Controller Class Initialized
INFO - 2018-08-16 18:43:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:51 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:51 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:51 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 18:43:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:51 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:51 --> Total execution time: 0.0448
INFO - 2018-08-16 18:43:52 --> Config Class Initialized
INFO - 2018-08-16 18:43:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:52 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:52 --> URI Class Initialized
INFO - 2018-08-16 18:43:52 --> Router Class Initialized
INFO - 2018-08-16 18:43:52 --> Output Class Initialized
INFO - 2018-08-16 18:43:52 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:52 --> CSRF cookie sent
INFO - 2018-08-16 18:43:52 --> Input Class Initialized
INFO - 2018-08-16 18:43:52 --> Language Class Initialized
INFO - 2018-08-16 18:43:52 --> Loader Class Initialized
INFO - 2018-08-16 18:43:52 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:52 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:52 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:52 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:52 --> Controller Class Initialized
INFO - 2018-08-16 18:43:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:52 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:52 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:53 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-16 18:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:53 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:53 --> Total execution time: 0.0542
INFO - 2018-08-16 18:43:54 --> Config Class Initialized
INFO - 2018-08-16 18:43:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:54 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:54 --> URI Class Initialized
INFO - 2018-08-16 18:43:54 --> Router Class Initialized
INFO - 2018-08-16 18:43:54 --> Output Class Initialized
INFO - 2018-08-16 18:43:54 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:54 --> CSRF cookie sent
INFO - 2018-08-16 18:43:54 --> Input Class Initialized
INFO - 2018-08-16 18:43:54 --> Language Class Initialized
INFO - 2018-08-16 18:43:54 --> Loader Class Initialized
INFO - 2018-08-16 18:43:54 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:54 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:54 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:54 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:54 --> Controller Class Initialized
INFO - 2018-08-16 18:43:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:54 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:54 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-16 18:43:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:54 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:54 --> Total execution time: 0.0525
INFO - 2018-08-16 18:43:55 --> Config Class Initialized
INFO - 2018-08-16 18:43:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:55 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:55 --> URI Class Initialized
INFO - 2018-08-16 18:43:55 --> Router Class Initialized
INFO - 2018-08-16 18:43:55 --> Output Class Initialized
INFO - 2018-08-16 18:43:55 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:55 --> CSRF cookie sent
INFO - 2018-08-16 18:43:55 --> Input Class Initialized
INFO - 2018-08-16 18:43:55 --> Language Class Initialized
INFO - 2018-08-16 18:43:55 --> Loader Class Initialized
INFO - 2018-08-16 18:43:55 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:55 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:55 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:55 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:55 --> Controller Class Initialized
INFO - 2018-08-16 18:43:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:55 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:55 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-16 18:43:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:55 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:55 --> Total execution time: 0.0458
INFO - 2018-08-16 18:43:56 --> Config Class Initialized
INFO - 2018-08-16 18:43:56 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:56 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:56 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:56 --> URI Class Initialized
INFO - 2018-08-16 18:43:56 --> Router Class Initialized
INFO - 2018-08-16 18:43:56 --> Output Class Initialized
INFO - 2018-08-16 18:43:56 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:56 --> CSRF cookie sent
INFO - 2018-08-16 18:43:56 --> Input Class Initialized
INFO - 2018-08-16 18:43:56 --> Language Class Initialized
INFO - 2018-08-16 18:43:56 --> Loader Class Initialized
INFO - 2018-08-16 18:43:56 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:56 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:56 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:56 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:56 --> Controller Class Initialized
INFO - 2018-08-16 18:43:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:56 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:56 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:56 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-16 18:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:56 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:56 --> Total execution time: 0.0629
INFO - 2018-08-16 18:43:57 --> Config Class Initialized
INFO - 2018-08-16 18:43:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:57 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:57 --> URI Class Initialized
INFO - 2018-08-16 18:43:57 --> Router Class Initialized
INFO - 2018-08-16 18:43:57 --> Output Class Initialized
INFO - 2018-08-16 18:43:57 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:57 --> CSRF cookie sent
INFO - 2018-08-16 18:43:57 --> Input Class Initialized
INFO - 2018-08-16 18:43:57 --> Language Class Initialized
INFO - 2018-08-16 18:43:57 --> Loader Class Initialized
INFO - 2018-08-16 18:43:57 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:57 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:57 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:58 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:58 --> Controller Class Initialized
INFO - 2018-08-16 18:43:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:58 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:58 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:43:58 --> Config Class Initialized
INFO - 2018-08-16 18:43:58 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:43:58 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:43:58 --> Utf8 Class Initialized
INFO - 2018-08-16 18:43:58 --> URI Class Initialized
INFO - 2018-08-16 18:43:58 --> Router Class Initialized
INFO - 2018-08-16 18:43:58 --> Output Class Initialized
INFO - 2018-08-16 18:43:58 --> Security Class Initialized
DEBUG - 2018-08-16 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:43:58 --> CSRF cookie sent
INFO - 2018-08-16 18:43:58 --> Input Class Initialized
INFO - 2018-08-16 18:43:58 --> Language Class Initialized
INFO - 2018-08-16 18:43:58 --> Loader Class Initialized
INFO - 2018-08-16 18:43:58 --> Helper loaded: url_helper
INFO - 2018-08-16 18:43:58 --> Helper loaded: form_helper
INFO - 2018-08-16 18:43:58 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:43:58 --> User Agent Class Initialized
INFO - 2018-08-16 18:43:58 --> Controller Class Initialized
INFO - 2018-08-16 18:43:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:43:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:43:58 --> Pixel_Model class loaded
INFO - 2018-08-16 18:43:58 --> Database Driver Class Initialized
INFO - 2018-08-16 18:43:58 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-16 18:43:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-16 18:43:58 --> Could not find the language line "req_email"
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-16 18:43:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:43:58 --> Final output sent to browser
DEBUG - 2018-08-16 18:43:58 --> Total execution time: 0.0364
INFO - 2018-08-16 18:44:01 --> Config Class Initialized
INFO - 2018-08-16 18:44:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:01 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:01 --> URI Class Initialized
INFO - 2018-08-16 18:44:01 --> Router Class Initialized
INFO - 2018-08-16 18:44:01 --> Output Class Initialized
INFO - 2018-08-16 18:44:01 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:01 --> CSRF cookie sent
INFO - 2018-08-16 18:44:01 --> Input Class Initialized
INFO - 2018-08-16 18:44:01 --> Language Class Initialized
INFO - 2018-08-16 18:44:01 --> Loader Class Initialized
INFO - 2018-08-16 18:44:01 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:01 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:01 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:01 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:01 --> Controller Class Initialized
INFO - 2018-08-16 18:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-16 18:44:01 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-16 18:44:01 --> Could not find the language line "req_email"
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-16 18:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:01 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:01 --> Total execution time: 0.0243
INFO - 2018-08-16 18:44:05 --> Config Class Initialized
INFO - 2018-08-16 18:44:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:05 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:05 --> URI Class Initialized
INFO - 2018-08-16 18:44:05 --> Router Class Initialized
INFO - 2018-08-16 18:44:05 --> Output Class Initialized
INFO - 2018-08-16 18:44:05 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:05 --> CSRF cookie sent
INFO - 2018-08-16 18:44:05 --> CSRF token verified
INFO - 2018-08-16 18:44:05 --> Input Class Initialized
INFO - 2018-08-16 18:44:05 --> Language Class Initialized
INFO - 2018-08-16 18:44:05 --> Loader Class Initialized
INFO - 2018-08-16 18:44:05 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:05 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:05 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:05 --> Controller Class Initialized
INFO - 2018-08-16 18:44:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-16 18:44:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-16 18:44:05 --> Form Validation Class Initialized
INFO - 2018-08-16 18:44:05 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:05 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:05 --> Model "AuthenticationModel" initialized
INFO - 2018-08-16 18:44:05 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:05 --> Config Class Initialized
INFO - 2018-08-16 18:44:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:05 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:05 --> URI Class Initialized
INFO - 2018-08-16 18:44:05 --> Router Class Initialized
INFO - 2018-08-16 18:44:05 --> Output Class Initialized
INFO - 2018-08-16 18:44:05 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:05 --> CSRF cookie sent
INFO - 2018-08-16 18:44:05 --> Input Class Initialized
INFO - 2018-08-16 18:44:05 --> Language Class Initialized
INFO - 2018-08-16 18:44:05 --> Loader Class Initialized
INFO - 2018-08-16 18:44:05 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:05 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:05 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:05 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:05 --> Controller Class Initialized
INFO - 2018-08-16 18:44:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:05 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:05 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:05 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 18:44:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:05 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:05 --> Total execution time: 0.0442
INFO - 2018-08-16 18:44:08 --> Config Class Initialized
INFO - 2018-08-16 18:44:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:08 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:08 --> URI Class Initialized
INFO - 2018-08-16 18:44:08 --> Router Class Initialized
INFO - 2018-08-16 18:44:08 --> Output Class Initialized
INFO - 2018-08-16 18:44:08 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:08 --> CSRF cookie sent
INFO - 2018-08-16 18:44:08 --> Input Class Initialized
INFO - 2018-08-16 18:44:08 --> Language Class Initialized
INFO - 2018-08-16 18:44:08 --> Loader Class Initialized
INFO - 2018-08-16 18:44:08 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:08 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:08 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:08 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:08 --> Controller Class Initialized
INFO - 2018-08-16 18:44:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:08 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:08 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:08 --> Model "MyAccountModel" initialized
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-16 18:44:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:08 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:08 --> Total execution time: 0.0340
INFO - 2018-08-16 18:44:09 --> Config Class Initialized
INFO - 2018-08-16 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:09 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:09 --> URI Class Initialized
INFO - 2018-08-16 18:44:09 --> Router Class Initialized
INFO - 2018-08-16 18:44:09 --> Output Class Initialized
INFO - 2018-08-16 18:44:09 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:09 --> CSRF cookie sent
INFO - 2018-08-16 18:44:09 --> Input Class Initialized
INFO - 2018-08-16 18:44:09 --> Language Class Initialized
INFO - 2018-08-16 18:44:09 --> Loader Class Initialized
INFO - 2018-08-16 18:44:09 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:09 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:09 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:09 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:09 --> Controller Class Initialized
INFO - 2018-08-16 18:44:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:09 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:09 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:09 --> Model "MyAccountModel" initialized
INFO - 2018-08-16 18:44:09 --> Config Class Initialized
INFO - 2018-08-16 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:09 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:09 --> URI Class Initialized
INFO - 2018-08-16 18:44:09 --> Router Class Initialized
INFO - 2018-08-16 18:44:09 --> Output Class Initialized
INFO - 2018-08-16 18:44:09 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:09 --> CSRF cookie sent
INFO - 2018-08-16 18:44:09 --> Input Class Initialized
INFO - 2018-08-16 18:44:09 --> Language Class Initialized
INFO - 2018-08-16 18:44:09 --> Loader Class Initialized
INFO - 2018-08-16 18:44:09 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:09 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:09 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:09 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:09 --> Controller Class Initialized
INFO - 2018-08-16 18:44:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:09 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:09 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:09 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:44:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:44:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:44:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:44:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-16 18:44:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:10 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:10 --> Total execution time: 0.0392
INFO - 2018-08-16 18:44:14 --> Config Class Initialized
INFO - 2018-08-16 18:44:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:14 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:14 --> URI Class Initialized
INFO - 2018-08-16 18:44:14 --> Router Class Initialized
INFO - 2018-08-16 18:44:14 --> Output Class Initialized
INFO - 2018-08-16 18:44:14 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:14 --> CSRF cookie sent
INFO - 2018-08-16 18:44:14 --> Input Class Initialized
INFO - 2018-08-16 18:44:14 --> Language Class Initialized
INFO - 2018-08-16 18:44:14 --> Loader Class Initialized
INFO - 2018-08-16 18:44:14 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:14 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:14 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:14 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:14 --> Controller Class Initialized
INFO - 2018-08-16 18:44:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:14 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:14 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:14 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-08-16 18:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:14 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:14 --> Total execution time: 0.0439
INFO - 2018-08-16 18:44:16 --> Config Class Initialized
INFO - 2018-08-16 18:44:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:44:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:44:16 --> Utf8 Class Initialized
INFO - 2018-08-16 18:44:16 --> URI Class Initialized
INFO - 2018-08-16 18:44:16 --> Router Class Initialized
INFO - 2018-08-16 18:44:16 --> Output Class Initialized
INFO - 2018-08-16 18:44:16 --> Security Class Initialized
DEBUG - 2018-08-16 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:44:16 --> CSRF cookie sent
INFO - 2018-08-16 18:44:16 --> Input Class Initialized
INFO - 2018-08-16 18:44:16 --> Language Class Initialized
INFO - 2018-08-16 18:44:16 --> Loader Class Initialized
INFO - 2018-08-16 18:44:16 --> Helper loaded: url_helper
INFO - 2018-08-16 18:44:16 --> Helper loaded: form_helper
INFO - 2018-08-16 18:44:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:44:16 --> User Agent Class Initialized
INFO - 2018-08-16 18:44:16 --> Controller Class Initialized
INFO - 2018-08-16 18:44:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:44:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:44:16 --> Pixel_Model class loaded
INFO - 2018-08-16 18:44:16 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:16 --> Database Driver Class Initialized
INFO - 2018-08-16 18:44:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:44:16 --> Final output sent to browser
DEBUG - 2018-08-16 18:44:16 --> Total execution time: 0.0657
INFO - 2018-08-16 18:45:32 --> Config Class Initialized
INFO - 2018-08-16 18:45:32 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:45:32 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:45:32 --> Utf8 Class Initialized
INFO - 2018-08-16 18:45:32 --> URI Class Initialized
INFO - 2018-08-16 18:45:32 --> Router Class Initialized
INFO - 2018-08-16 18:45:32 --> Output Class Initialized
INFO - 2018-08-16 18:45:32 --> Security Class Initialized
DEBUG - 2018-08-16 18:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:45:32 --> CSRF cookie sent
INFO - 2018-08-16 18:45:32 --> Input Class Initialized
INFO - 2018-08-16 18:45:32 --> Language Class Initialized
INFO - 2018-08-16 18:45:32 --> Loader Class Initialized
INFO - 2018-08-16 18:45:32 --> Helper loaded: url_helper
INFO - 2018-08-16 18:45:32 --> Helper loaded: form_helper
INFO - 2018-08-16 18:45:32 --> Helper loaded: language_helper
DEBUG - 2018-08-16 18:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:45:32 --> User Agent Class Initialized
INFO - 2018-08-16 18:45:32 --> Controller Class Initialized
INFO - 2018-08-16 18:45:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 18:45:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 18:45:32 --> Pixel_Model class loaded
INFO - 2018-08-16 18:45:32 --> Database Driver Class Initialized
INFO - 2018-08-16 18:45:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:45:32 --> Database Driver Class Initialized
INFO - 2018-08-16 18:45:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 18:45:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 18:45:32 --> Final output sent to browser
DEBUG - 2018-08-16 18:45:32 --> Total execution time: 0.0629
INFO - 2018-08-16 19:59:12 --> Config Class Initialized
INFO - 2018-08-16 19:59:12 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:12 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:12 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:12 --> URI Class Initialized
DEBUG - 2018-08-16 19:59:12 --> No URI present. Default controller set.
INFO - 2018-08-16 19:59:12 --> Router Class Initialized
INFO - 2018-08-16 19:59:12 --> Output Class Initialized
INFO - 2018-08-16 19:59:12 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:12 --> CSRF cookie sent
INFO - 2018-08-16 19:59:12 --> Input Class Initialized
INFO - 2018-08-16 19:59:12 --> Language Class Initialized
INFO - 2018-08-16 19:59:12 --> Loader Class Initialized
INFO - 2018-08-16 19:59:12 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:12 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:12 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:12 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:12 --> Controller Class Initialized
INFO - 2018-08-16 19:59:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:12 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:12 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-16 19:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:12 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:12 --> Total execution time: 0.0389
INFO - 2018-08-16 19:59:16 --> Config Class Initialized
INFO - 2018-08-16 19:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:16 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:16 --> URI Class Initialized
INFO - 2018-08-16 19:59:16 --> Router Class Initialized
INFO - 2018-08-16 19:59:16 --> Output Class Initialized
INFO - 2018-08-16 19:59:16 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:16 --> CSRF cookie sent
INFO - 2018-08-16 19:59:16 --> CSRF token verified
INFO - 2018-08-16 19:59:16 --> Input Class Initialized
INFO - 2018-08-16 19:59:16 --> Language Class Initialized
INFO - 2018-08-16 19:59:16 --> Loader Class Initialized
INFO - 2018-08-16 19:59:16 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:16 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:16 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:16 --> Controller Class Initialized
INFO - 2018-08-16 19:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:16 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:16 --> Config Class Initialized
INFO - 2018-08-16 19:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:16 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:16 --> URI Class Initialized
INFO - 2018-08-16 19:59:16 --> Router Class Initialized
INFO - 2018-08-16 19:59:16 --> Output Class Initialized
INFO - 2018-08-16 19:59:16 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:16 --> CSRF cookie sent
INFO - 2018-08-16 19:59:16 --> Input Class Initialized
INFO - 2018-08-16 19:59:16 --> Language Class Initialized
INFO - 2018-08-16 19:59:16 --> Loader Class Initialized
INFO - 2018-08-16 19:59:16 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:16 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:16 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:16 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:16 --> Controller Class Initialized
INFO - 2018-08-16 19:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:16 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:16 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:16 --> Total execution time: 0.0523
INFO - 2018-08-16 19:59:26 --> Config Class Initialized
INFO - 2018-08-16 19:59:26 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:26 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:26 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:26 --> URI Class Initialized
INFO - 2018-08-16 19:59:26 --> Router Class Initialized
INFO - 2018-08-16 19:59:26 --> Output Class Initialized
INFO - 2018-08-16 19:59:26 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:26 --> CSRF cookie sent
INFO - 2018-08-16 19:59:26 --> Input Class Initialized
INFO - 2018-08-16 19:59:26 --> Language Class Initialized
INFO - 2018-08-16 19:59:26 --> Loader Class Initialized
INFO - 2018-08-16 19:59:26 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:26 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:26 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:26 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:26 --> Controller Class Initialized
INFO - 2018-08-16 19:59:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:26 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:26 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:26 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 19:59:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:26 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:26 --> Total execution time: 0.0468
INFO - 2018-08-16 19:59:29 --> Config Class Initialized
INFO - 2018-08-16 19:59:29 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:29 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:29 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:29 --> URI Class Initialized
INFO - 2018-08-16 19:59:29 --> Router Class Initialized
INFO - 2018-08-16 19:59:29 --> Output Class Initialized
INFO - 2018-08-16 19:59:29 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:29 --> CSRF cookie sent
INFO - 2018-08-16 19:59:29 --> Input Class Initialized
INFO - 2018-08-16 19:59:29 --> Language Class Initialized
INFO - 2018-08-16 19:59:29 --> Loader Class Initialized
INFO - 2018-08-16 19:59:29 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:29 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:29 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:29 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:29 --> Controller Class Initialized
INFO - 2018-08-16 19:59:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:29 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:29 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:29 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 19:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:29 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:29 --> Total execution time: 0.0398
INFO - 2018-08-16 19:59:31 --> Config Class Initialized
INFO - 2018-08-16 19:59:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:31 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:31 --> URI Class Initialized
INFO - 2018-08-16 19:59:31 --> Router Class Initialized
INFO - 2018-08-16 19:59:31 --> Output Class Initialized
INFO - 2018-08-16 19:59:31 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:31 --> CSRF cookie sent
INFO - 2018-08-16 19:59:31 --> Input Class Initialized
INFO - 2018-08-16 19:59:31 --> Language Class Initialized
INFO - 2018-08-16 19:59:31 --> Loader Class Initialized
INFO - 2018-08-16 19:59:31 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:31 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:31 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:31 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:31 --> Controller Class Initialized
INFO - 2018-08-16 19:59:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:31 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:31 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:31 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 19:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:31 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:31 --> Total execution time: 0.0385
INFO - 2018-08-16 19:59:37 --> Config Class Initialized
INFO - 2018-08-16 19:59:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:37 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:37 --> URI Class Initialized
INFO - 2018-08-16 19:59:37 --> Router Class Initialized
INFO - 2018-08-16 19:59:37 --> Output Class Initialized
INFO - 2018-08-16 19:59:37 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:37 --> CSRF cookie sent
INFO - 2018-08-16 19:59:37 --> Input Class Initialized
INFO - 2018-08-16 19:59:37 --> Language Class Initialized
INFO - 2018-08-16 19:59:37 --> Loader Class Initialized
INFO - 2018-08-16 19:59:37 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:37 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:37 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:37 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:37 --> Controller Class Initialized
INFO - 2018-08-16 19:59:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:37 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:37 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:37 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-16 19:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:37 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:37 --> Total execution time: 0.0427
INFO - 2018-08-16 19:59:41 --> Config Class Initialized
INFO - 2018-08-16 19:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:41 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:41 --> URI Class Initialized
INFO - 2018-08-16 19:59:41 --> Router Class Initialized
INFO - 2018-08-16 19:59:41 --> Output Class Initialized
INFO - 2018-08-16 19:59:41 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:41 --> CSRF cookie sent
INFO - 2018-08-16 19:59:41 --> Input Class Initialized
INFO - 2018-08-16 19:59:41 --> Language Class Initialized
INFO - 2018-08-16 19:59:41 --> Loader Class Initialized
INFO - 2018-08-16 19:59:41 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:41 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:41 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:41 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:41 --> Controller Class Initialized
INFO - 2018-08-16 19:59:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:41 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-16 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:41 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:41 --> Total execution time: 0.0390
INFO - 2018-08-16 19:59:42 --> Config Class Initialized
INFO - 2018-08-16 19:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:42 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:42 --> URI Class Initialized
INFO - 2018-08-16 19:59:42 --> Router Class Initialized
INFO - 2018-08-16 19:59:42 --> Output Class Initialized
INFO - 2018-08-16 19:59:42 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:42 --> CSRF cookie sent
INFO - 2018-08-16 19:59:42 --> Input Class Initialized
INFO - 2018-08-16 19:59:42 --> Language Class Initialized
INFO - 2018-08-16 19:59:42 --> Loader Class Initialized
INFO - 2018-08-16 19:59:42 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:42 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:42 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:42 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:42 --> Controller Class Initialized
INFO - 2018-08-16 19:59:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:42 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:42 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:42 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-16 19:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:42 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:42 --> Total execution time: 0.0386
INFO - 2018-08-16 19:59:43 --> Config Class Initialized
INFO - 2018-08-16 19:59:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:43 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:43 --> URI Class Initialized
INFO - 2018-08-16 19:59:43 --> Router Class Initialized
INFO - 2018-08-16 19:59:43 --> Output Class Initialized
INFO - 2018-08-16 19:59:43 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:43 --> CSRF cookie sent
INFO - 2018-08-16 19:59:43 --> Input Class Initialized
INFO - 2018-08-16 19:59:43 --> Language Class Initialized
INFO - 2018-08-16 19:59:43 --> Loader Class Initialized
INFO - 2018-08-16 19:59:43 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:43 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:43 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:43 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:43 --> Controller Class Initialized
INFO - 2018-08-16 19:59:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:43 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:43 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:43 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-16 19:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:43 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:43 --> Total execution time: 0.0472
INFO - 2018-08-16 19:59:46 --> Config Class Initialized
INFO - 2018-08-16 19:59:46 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:46 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:46 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:46 --> URI Class Initialized
INFO - 2018-08-16 19:59:46 --> Router Class Initialized
INFO - 2018-08-16 19:59:46 --> Output Class Initialized
INFO - 2018-08-16 19:59:46 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:46 --> CSRF cookie sent
INFO - 2018-08-16 19:59:46 --> Input Class Initialized
INFO - 2018-08-16 19:59:46 --> Language Class Initialized
INFO - 2018-08-16 19:59:46 --> Loader Class Initialized
INFO - 2018-08-16 19:59:46 --> Helper loaded: url_helper
INFO - 2018-08-16 19:59:46 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:46 --> Helper loaded: language_helper
DEBUG - 2018-08-16 19:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:46 --> User Agent Class Initialized
INFO - 2018-08-16 19:59:46 --> Controller Class Initialized
INFO - 2018-08-16 19:59:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-16 19:59:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-16 19:59:46 --> Pixel_Model class loaded
INFO - 2018-08-16 19:59:46 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:46 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-16 19:59:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-16 19:59:46 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:46 --> Total execution time: 0.0455

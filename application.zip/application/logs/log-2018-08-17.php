<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-17 01:02:58 --> Config Class Initialized
INFO - 2018-08-17 01:02:58 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:02:58 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:02:58 --> Utf8 Class Initialized
INFO - 2018-08-17 01:02:58 --> URI Class Initialized
DEBUG - 2018-08-17 01:02:58 --> No URI present. Default controller set.
INFO - 2018-08-17 01:02:58 --> Router Class Initialized
INFO - 2018-08-17 01:02:58 --> Output Class Initialized
INFO - 2018-08-17 01:02:58 --> Security Class Initialized
DEBUG - 2018-08-17 01:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:02:58 --> CSRF cookie sent
INFO - 2018-08-17 01:02:58 --> Input Class Initialized
INFO - 2018-08-17 01:02:58 --> Language Class Initialized
INFO - 2018-08-17 01:02:58 --> Loader Class Initialized
INFO - 2018-08-17 01:02:58 --> Helper loaded: url_helper
INFO - 2018-08-17 01:02:58 --> Helper loaded: form_helper
INFO - 2018-08-17 01:02:58 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:02:58 --> User Agent Class Initialized
INFO - 2018-08-17 01:02:58 --> Controller Class Initialized
INFO - 2018-08-17 01:02:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:02:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:02:58 --> Pixel_Model class loaded
INFO - 2018-08-17 01:02:58 --> Database Driver Class Initialized
INFO - 2018-08-17 01:02:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:02:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 01:02:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 01:02:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 01:02:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 01:02:58 --> Final output sent to browser
DEBUG - 2018-08-17 01:02:58 --> Total execution time: 0.0409
INFO - 2018-08-17 01:03:01 --> Config Class Initialized
INFO - 2018-08-17 01:03:01 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:03:01 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:03:01 --> Utf8 Class Initialized
INFO - 2018-08-17 01:03:01 --> URI Class Initialized
DEBUG - 2018-08-17 01:03:01 --> No URI present. Default controller set.
INFO - 2018-08-17 01:03:01 --> Router Class Initialized
INFO - 2018-08-17 01:03:01 --> Output Class Initialized
INFO - 2018-08-17 01:03:01 --> Security Class Initialized
DEBUG - 2018-08-17 01:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:03:01 --> CSRF cookie sent
INFO - 2018-08-17 01:03:01 --> Input Class Initialized
INFO - 2018-08-17 01:03:01 --> Language Class Initialized
INFO - 2018-08-17 01:03:01 --> Loader Class Initialized
INFO - 2018-08-17 01:03:01 --> Helper loaded: url_helper
INFO - 2018-08-17 01:03:01 --> Helper loaded: form_helper
INFO - 2018-08-17 01:03:01 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:03:01 --> User Agent Class Initialized
INFO - 2018-08-17 01:03:01 --> Controller Class Initialized
INFO - 2018-08-17 01:03:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:03:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:03:01 --> Pixel_Model class loaded
INFO - 2018-08-17 01:03:01 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 01:03:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 01:03:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 01:03:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 01:03:01 --> Final output sent to browser
DEBUG - 2018-08-17 01:03:01 --> Total execution time: 0.0463
INFO - 2018-08-17 01:03:11 --> Config Class Initialized
INFO - 2018-08-17 01:03:11 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:03:11 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:03:11 --> Utf8 Class Initialized
INFO - 2018-08-17 01:03:11 --> URI Class Initialized
DEBUG - 2018-08-17 01:03:11 --> No URI present. Default controller set.
INFO - 2018-08-17 01:03:11 --> Router Class Initialized
INFO - 2018-08-17 01:03:11 --> Output Class Initialized
INFO - 2018-08-17 01:03:11 --> Security Class Initialized
DEBUG - 2018-08-17 01:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:03:11 --> CSRF cookie sent
INFO - 2018-08-17 01:03:11 --> Input Class Initialized
INFO - 2018-08-17 01:03:11 --> Language Class Initialized
INFO - 2018-08-17 01:03:11 --> Loader Class Initialized
INFO - 2018-08-17 01:03:11 --> Helper loaded: url_helper
INFO - 2018-08-17 01:03:11 --> Helper loaded: form_helper
INFO - 2018-08-17 01:03:11 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:03:11 --> User Agent Class Initialized
INFO - 2018-08-17 01:03:11 --> Controller Class Initialized
INFO - 2018-08-17 01:03:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:03:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:03:11 --> Pixel_Model class loaded
INFO - 2018-08-17 01:03:11 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 01:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 01:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 01:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 01:03:11 --> Final output sent to browser
DEBUG - 2018-08-17 01:03:11 --> Total execution time: 0.0326
INFO - 2018-08-17 01:03:12 --> Config Class Initialized
INFO - 2018-08-17 01:03:12 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:03:12 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:03:12 --> Utf8 Class Initialized
INFO - 2018-08-17 01:03:12 --> URI Class Initialized
INFO - 2018-08-17 01:03:12 --> Router Class Initialized
INFO - 2018-08-17 01:03:12 --> Output Class Initialized
INFO - 2018-08-17 01:03:13 --> Security Class Initialized
DEBUG - 2018-08-17 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:03:13 --> CSRF cookie sent
INFO - 2018-08-17 01:03:13 --> CSRF token verified
INFO - 2018-08-17 01:03:13 --> Input Class Initialized
INFO - 2018-08-17 01:03:13 --> Language Class Initialized
INFO - 2018-08-17 01:03:13 --> Loader Class Initialized
INFO - 2018-08-17 01:03:13 --> Helper loaded: url_helper
INFO - 2018-08-17 01:03:13 --> Helper loaded: form_helper
INFO - 2018-08-17 01:03:13 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:03:13 --> User Agent Class Initialized
INFO - 2018-08-17 01:03:13 --> Controller Class Initialized
INFO - 2018-08-17 01:03:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:03:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:03:13 --> Pixel_Model class loaded
INFO - 2018-08-17 01:03:13 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:13 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:13 --> Config Class Initialized
INFO - 2018-08-17 01:03:13 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:03:13 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:03:13 --> Utf8 Class Initialized
INFO - 2018-08-17 01:03:13 --> URI Class Initialized
INFO - 2018-08-17 01:03:13 --> Router Class Initialized
INFO - 2018-08-17 01:03:13 --> Output Class Initialized
INFO - 2018-08-17 01:03:13 --> Security Class Initialized
DEBUG - 2018-08-17 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:03:13 --> CSRF cookie sent
INFO - 2018-08-17 01:03:13 --> Input Class Initialized
INFO - 2018-08-17 01:03:13 --> Language Class Initialized
INFO - 2018-08-17 01:03:13 --> Loader Class Initialized
INFO - 2018-08-17 01:03:13 --> Helper loaded: url_helper
INFO - 2018-08-17 01:03:13 --> Helper loaded: form_helper
INFO - 2018-08-17 01:03:13 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:03:13 --> User Agent Class Initialized
INFO - 2018-08-17 01:03:13 --> Controller Class Initialized
INFO - 2018-08-17 01:03:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:03:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:03:13 --> Pixel_Model class loaded
INFO - 2018-08-17 01:03:13 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:13 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-17 01:03:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 01:03:13 --> Final output sent to browser
DEBUG - 2018-08-17 01:03:13 --> Total execution time: 0.0476
INFO - 2018-08-17 01:03:16 --> Config Class Initialized
INFO - 2018-08-17 01:03:16 --> Hooks Class Initialized
DEBUG - 2018-08-17 01:03:16 --> UTF-8 Support Enabled
INFO - 2018-08-17 01:03:16 --> Utf8 Class Initialized
INFO - 2018-08-17 01:03:16 --> URI Class Initialized
INFO - 2018-08-17 01:03:16 --> Router Class Initialized
INFO - 2018-08-17 01:03:16 --> Output Class Initialized
INFO - 2018-08-17 01:03:16 --> Security Class Initialized
DEBUG - 2018-08-17 01:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 01:03:16 --> CSRF cookie sent
INFO - 2018-08-17 01:03:16 --> Input Class Initialized
INFO - 2018-08-17 01:03:16 --> Language Class Initialized
INFO - 2018-08-17 01:03:16 --> Loader Class Initialized
INFO - 2018-08-17 01:03:16 --> Helper loaded: url_helper
INFO - 2018-08-17 01:03:16 --> Helper loaded: form_helper
INFO - 2018-08-17 01:03:16 --> Helper loaded: language_helper
DEBUG - 2018-08-17 01:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 01:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 01:03:16 --> User Agent Class Initialized
INFO - 2018-08-17 01:03:16 --> Controller Class Initialized
INFO - 2018-08-17 01:03:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 01:03:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 01:03:16 --> Pixel_Model class loaded
INFO - 2018-08-17 01:03:16 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:16 --> Database Driver Class Initialized
INFO - 2018-08-17 01:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-17 01:03:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 01:03:16 --> Final output sent to browser
DEBUG - 2018-08-17 01:03:16 --> Total execution time: 0.0438
INFO - 2018-08-17 14:23:33 --> Config Class Initialized
INFO - 2018-08-17 14:23:33 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:23:33 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:23:33 --> Utf8 Class Initialized
INFO - 2018-08-17 14:23:33 --> URI Class Initialized
DEBUG - 2018-08-17 14:23:33 --> No URI present. Default controller set.
INFO - 2018-08-17 14:23:33 --> Router Class Initialized
INFO - 2018-08-17 14:23:33 --> Output Class Initialized
INFO - 2018-08-17 14:23:33 --> Security Class Initialized
DEBUG - 2018-08-17 14:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:23:33 --> CSRF cookie sent
INFO - 2018-08-17 14:23:33 --> Input Class Initialized
INFO - 2018-08-17 14:23:33 --> Language Class Initialized
INFO - 2018-08-17 14:23:33 --> Loader Class Initialized
INFO - 2018-08-17 14:23:33 --> Helper loaded: url_helper
INFO - 2018-08-17 14:23:33 --> Helper loaded: form_helper
INFO - 2018-08-17 14:23:33 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:23:33 --> User Agent Class Initialized
INFO - 2018-08-17 14:23:33 --> Controller Class Initialized
INFO - 2018-08-17 14:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:23:33 --> Pixel_Model class loaded
INFO - 2018-08-17 14:23:33 --> Database Driver Class Initialized
INFO - 2018-08-17 14:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 14:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:23:33 --> Final output sent to browser
DEBUG - 2018-08-17 14:23:33 --> Total execution time: 0.0349
INFO - 2018-08-17 14:23:34 --> Config Class Initialized
INFO - 2018-08-17 14:23:34 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:23:34 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:23:34 --> Utf8 Class Initialized
INFO - 2018-08-17 14:23:34 --> URI Class Initialized
DEBUG - 2018-08-17 14:23:34 --> No URI present. Default controller set.
INFO - 2018-08-17 14:23:34 --> Router Class Initialized
INFO - 2018-08-17 14:23:34 --> Output Class Initialized
INFO - 2018-08-17 14:23:34 --> Security Class Initialized
DEBUG - 2018-08-17 14:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:23:34 --> CSRF cookie sent
INFO - 2018-08-17 14:23:34 --> Input Class Initialized
INFO - 2018-08-17 14:23:34 --> Language Class Initialized
INFO - 2018-08-17 14:23:34 --> Loader Class Initialized
INFO - 2018-08-17 14:23:34 --> Helper loaded: url_helper
INFO - 2018-08-17 14:23:34 --> Helper loaded: form_helper
INFO - 2018-08-17 14:23:34 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:23:34 --> User Agent Class Initialized
INFO - 2018-08-17 14:23:34 --> Controller Class Initialized
INFO - 2018-08-17 14:23:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:23:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:23:34 --> Pixel_Model class loaded
INFO - 2018-08-17 14:23:34 --> Database Driver Class Initialized
INFO - 2018-08-17 14:23:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 14:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:23:34 --> Final output sent to browser
DEBUG - 2018-08-17 14:23:34 --> Total execution time: 0.0341
INFO - 2018-08-17 14:23:42 --> Config Class Initialized
INFO - 2018-08-17 14:23:42 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:23:42 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:23:42 --> Utf8 Class Initialized
INFO - 2018-08-17 14:23:42 --> URI Class Initialized
INFO - 2018-08-17 14:23:42 --> Router Class Initialized
INFO - 2018-08-17 14:23:42 --> Output Class Initialized
INFO - 2018-08-17 14:23:42 --> Security Class Initialized
DEBUG - 2018-08-17 14:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:23:42 --> CSRF cookie sent
INFO - 2018-08-17 14:23:42 --> CSRF token verified
INFO - 2018-08-17 14:23:42 --> Input Class Initialized
INFO - 2018-08-17 14:23:42 --> Language Class Initialized
INFO - 2018-08-17 14:23:42 --> Loader Class Initialized
INFO - 2018-08-17 14:23:42 --> Helper loaded: url_helper
INFO - 2018-08-17 14:23:42 --> Helper loaded: form_helper
INFO - 2018-08-17 14:23:42 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:23:42 --> User Agent Class Initialized
INFO - 2018-08-17 14:23:42 --> Controller Class Initialized
INFO - 2018-08-17 14:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:23:42 --> Pixel_Model class loaded
INFO - 2018-08-17 14:23:42 --> Database Driver Class Initialized
INFO - 2018-08-17 14:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:23:42 --> Database Driver Class Initialized
INFO - 2018-08-17 14:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:30 --> Config Class Initialized
INFO - 2018-08-17 14:25:30 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:30 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:30 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:30 --> URI Class Initialized
DEBUG - 2018-08-17 14:25:30 --> No URI present. Default controller set.
INFO - 2018-08-17 14:25:30 --> Router Class Initialized
INFO - 2018-08-17 14:25:30 --> Output Class Initialized
INFO - 2018-08-17 14:25:30 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:30 --> CSRF cookie sent
INFO - 2018-08-17 14:25:30 --> Input Class Initialized
INFO - 2018-08-17 14:25:30 --> Language Class Initialized
INFO - 2018-08-17 14:25:30 --> Loader Class Initialized
INFO - 2018-08-17 14:25:30 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:30 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:30 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:30 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:30 --> Controller Class Initialized
INFO - 2018-08-17 14:25:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:30 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:30 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 14:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:30 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:30 --> Total execution time: 0.0405
INFO - 2018-08-17 14:25:31 --> Config Class Initialized
INFO - 2018-08-17 14:25:31 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:31 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:31 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:31 --> URI Class Initialized
DEBUG - 2018-08-17 14:25:31 --> No URI present. Default controller set.
INFO - 2018-08-17 14:25:31 --> Router Class Initialized
INFO - 2018-08-17 14:25:31 --> Output Class Initialized
INFO - 2018-08-17 14:25:31 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:31 --> CSRF cookie sent
INFO - 2018-08-17 14:25:31 --> Input Class Initialized
INFO - 2018-08-17 14:25:31 --> Language Class Initialized
INFO - 2018-08-17 14:25:31 --> Loader Class Initialized
INFO - 2018-08-17 14:25:31 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:31 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:31 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:31 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:31 --> Controller Class Initialized
INFO - 2018-08-17 14:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:31 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:31 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 14:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:32 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:32 --> Total execution time: 0.0347
INFO - 2018-08-17 14:25:36 --> Config Class Initialized
INFO - 2018-08-17 14:25:36 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:36 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:36 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:36 --> URI Class Initialized
INFO - 2018-08-17 14:25:36 --> Router Class Initialized
INFO - 2018-08-17 14:25:36 --> Output Class Initialized
INFO - 2018-08-17 14:25:36 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:36 --> CSRF cookie sent
INFO - 2018-08-17 14:25:36 --> CSRF token verified
INFO - 2018-08-17 14:25:36 --> Input Class Initialized
INFO - 2018-08-17 14:25:36 --> Language Class Initialized
INFO - 2018-08-17 14:25:36 --> Loader Class Initialized
INFO - 2018-08-17 14:25:36 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:36 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:36 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:36 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:36 --> Controller Class Initialized
INFO - 2018-08-17 14:25:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:36 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:36 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:36 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:36 --> Config Class Initialized
INFO - 2018-08-17 14:25:36 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:36 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:36 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:36 --> URI Class Initialized
INFO - 2018-08-17 14:25:36 --> Router Class Initialized
INFO - 2018-08-17 14:25:36 --> Output Class Initialized
INFO - 2018-08-17 14:25:36 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:36 --> CSRF cookie sent
INFO - 2018-08-17 14:25:36 --> Input Class Initialized
INFO - 2018-08-17 14:25:36 --> Language Class Initialized
INFO - 2018-08-17 14:25:36 --> Loader Class Initialized
INFO - 2018-08-17 14:25:36 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:36 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:36 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:36 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:36 --> Controller Class Initialized
INFO - 2018-08-17 14:25:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:36 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:36 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:36 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-17 14:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:36 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:36 --> Total execution time: 0.0447
INFO - 2018-08-17 14:25:39 --> Config Class Initialized
INFO - 2018-08-17 14:25:39 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:39 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:39 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:39 --> URI Class Initialized
DEBUG - 2018-08-17 14:25:39 --> No URI present. Default controller set.
INFO - 2018-08-17 14:25:39 --> Router Class Initialized
INFO - 2018-08-17 14:25:39 --> Output Class Initialized
INFO - 2018-08-17 14:25:39 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:39 --> CSRF cookie sent
INFO - 2018-08-17 14:25:39 --> Input Class Initialized
INFO - 2018-08-17 14:25:39 --> Language Class Initialized
INFO - 2018-08-17 14:25:39 --> Loader Class Initialized
INFO - 2018-08-17 14:25:39 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:39 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:39 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:39 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:39 --> Controller Class Initialized
INFO - 2018-08-17 14:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:39 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:39 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-17 14:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:39 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:39 --> Total execution time: 0.0350
INFO - 2018-08-17 14:25:51 --> Config Class Initialized
INFO - 2018-08-17 14:25:51 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:51 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:51 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:51 --> URI Class Initialized
INFO - 2018-08-17 14:25:51 --> Router Class Initialized
INFO - 2018-08-17 14:25:51 --> Output Class Initialized
INFO - 2018-08-17 14:25:51 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:51 --> CSRF cookie sent
INFO - 2018-08-17 14:25:51 --> CSRF token verified
INFO - 2018-08-17 14:25:51 --> Input Class Initialized
INFO - 2018-08-17 14:25:51 --> Language Class Initialized
INFO - 2018-08-17 14:25:51 --> Loader Class Initialized
INFO - 2018-08-17 14:25:51 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:51 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:51 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:51 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:51 --> Controller Class Initialized
INFO - 2018-08-17 14:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:51 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:51 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:51 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:51 --> Config Class Initialized
INFO - 2018-08-17 14:25:51 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:51 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:51 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:51 --> URI Class Initialized
INFO - 2018-08-17 14:25:51 --> Router Class Initialized
INFO - 2018-08-17 14:25:51 --> Output Class Initialized
INFO - 2018-08-17 14:25:51 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:51 --> CSRF cookie sent
INFO - 2018-08-17 14:25:51 --> Input Class Initialized
INFO - 2018-08-17 14:25:51 --> Language Class Initialized
INFO - 2018-08-17 14:25:51 --> Loader Class Initialized
INFO - 2018-08-17 14:25:51 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:51 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:51 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:51 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:51 --> Controller Class Initialized
INFO - 2018-08-17 14:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:51 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:51 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:51 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-17 14:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:51 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:51 --> Total execution time: 0.0453
INFO - 2018-08-17 14:25:55 --> Config Class Initialized
INFO - 2018-08-17 14:25:55 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:55 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:55 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:55 --> URI Class Initialized
INFO - 2018-08-17 14:25:55 --> Router Class Initialized
INFO - 2018-08-17 14:25:55 --> Output Class Initialized
INFO - 2018-08-17 14:25:55 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:55 --> CSRF cookie sent
INFO - 2018-08-17 14:25:55 --> CSRF token verified
INFO - 2018-08-17 14:25:55 --> Input Class Initialized
INFO - 2018-08-17 14:25:55 --> Language Class Initialized
INFO - 2018-08-17 14:25:55 --> Loader Class Initialized
INFO - 2018-08-17 14:25:55 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:55 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:55 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:55 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:55 --> Controller Class Initialized
INFO - 2018-08-17 14:25:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:55 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:56 --> Form Validation Class Initialized
INFO - 2018-08-17 14:25:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:25:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:56 --> Config Class Initialized
INFO - 2018-08-17 14:25:56 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:25:56 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:25:56 --> Utf8 Class Initialized
INFO - 2018-08-17 14:25:56 --> URI Class Initialized
INFO - 2018-08-17 14:25:56 --> Router Class Initialized
INFO - 2018-08-17 14:25:56 --> Output Class Initialized
INFO - 2018-08-17 14:25:56 --> Security Class Initialized
DEBUG - 2018-08-17 14:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:25:56 --> CSRF cookie sent
INFO - 2018-08-17 14:25:56 --> Input Class Initialized
INFO - 2018-08-17 14:25:56 --> Language Class Initialized
INFO - 2018-08-17 14:25:56 --> Loader Class Initialized
INFO - 2018-08-17 14:25:56 --> Helper loaded: url_helper
INFO - 2018-08-17 14:25:56 --> Helper loaded: form_helper
INFO - 2018-08-17 14:25:56 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:25:56 --> User Agent Class Initialized
INFO - 2018-08-17 14:25:56 --> Controller Class Initialized
INFO - 2018-08-17 14:25:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:25:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:25:56 --> Pixel_Model class loaded
INFO - 2018-08-17 14:25:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-17 14:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:25:56 --> Final output sent to browser
DEBUG - 2018-08-17 14:25:56 --> Total execution time: 0.0375
INFO - 2018-08-17 14:26:04 --> Config Class Initialized
INFO - 2018-08-17 14:26:04 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:04 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:04 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:04 --> URI Class Initialized
INFO - 2018-08-17 14:26:04 --> Router Class Initialized
INFO - 2018-08-17 14:26:04 --> Output Class Initialized
INFO - 2018-08-17 14:26:04 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:04 --> CSRF cookie sent
INFO - 2018-08-17 14:26:04 --> CSRF token verified
INFO - 2018-08-17 14:26:04 --> Input Class Initialized
INFO - 2018-08-17 14:26:04 --> Language Class Initialized
INFO - 2018-08-17 14:26:04 --> Loader Class Initialized
INFO - 2018-08-17 14:26:04 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:04 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:04 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:04 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:04 --> Controller Class Initialized
INFO - 2018-08-17 14:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:04 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:04 --> Form Validation Class Initialized
INFO - 2018-08-17 14:26:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:26:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:04 --> Config Class Initialized
INFO - 2018-08-17 14:26:04 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:04 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:04 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:04 --> URI Class Initialized
INFO - 2018-08-17 14:26:04 --> Router Class Initialized
INFO - 2018-08-17 14:26:04 --> Output Class Initialized
INFO - 2018-08-17 14:26:04 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:04 --> CSRF cookie sent
INFO - 2018-08-17 14:26:04 --> Input Class Initialized
INFO - 2018-08-17 14:26:04 --> Language Class Initialized
INFO - 2018-08-17 14:26:04 --> Loader Class Initialized
INFO - 2018-08-17 14:26:04 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:04 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:04 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:04 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:04 --> Controller Class Initialized
INFO - 2018-08-17 14:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:04 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-17 14:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:26:04 --> Final output sent to browser
DEBUG - 2018-08-17 14:26:04 --> Total execution time: 0.0373
INFO - 2018-08-17 14:26:10 --> Config Class Initialized
INFO - 2018-08-17 14:26:10 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:10 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:10 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:10 --> URI Class Initialized
INFO - 2018-08-17 14:26:10 --> Router Class Initialized
INFO - 2018-08-17 14:26:10 --> Output Class Initialized
INFO - 2018-08-17 14:26:10 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:10 --> CSRF cookie sent
INFO - 2018-08-17 14:26:10 --> CSRF token verified
INFO - 2018-08-17 14:26:10 --> Input Class Initialized
INFO - 2018-08-17 14:26:10 --> Language Class Initialized
INFO - 2018-08-17 14:26:10 --> Loader Class Initialized
INFO - 2018-08-17 14:26:10 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:10 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:10 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:10 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:10 --> Controller Class Initialized
INFO - 2018-08-17 14:26:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:10 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:10 --> Form Validation Class Initialized
INFO - 2018-08-17 14:26:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:26:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:10 --> Config Class Initialized
INFO - 2018-08-17 14:26:10 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:10 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:10 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:10 --> URI Class Initialized
INFO - 2018-08-17 14:26:10 --> Router Class Initialized
INFO - 2018-08-17 14:26:10 --> Output Class Initialized
INFO - 2018-08-17 14:26:10 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:10 --> CSRF cookie sent
INFO - 2018-08-17 14:26:10 --> Input Class Initialized
INFO - 2018-08-17 14:26:10 --> Language Class Initialized
INFO - 2018-08-17 14:26:10 --> Loader Class Initialized
INFO - 2018-08-17 14:26:10 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:10 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:10 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:10 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:10 --> Controller Class Initialized
INFO - 2018-08-17 14:26:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:10 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-17 14:26:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:26:10 --> Final output sent to browser
DEBUG - 2018-08-17 14:26:10 --> Total execution time: 0.0321
INFO - 2018-08-17 14:26:18 --> Config Class Initialized
INFO - 2018-08-17 14:26:18 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:18 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:18 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:18 --> URI Class Initialized
INFO - 2018-08-17 14:26:18 --> Router Class Initialized
INFO - 2018-08-17 14:26:18 --> Output Class Initialized
INFO - 2018-08-17 14:26:18 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:18 --> CSRF cookie sent
INFO - 2018-08-17 14:26:18 --> CSRF token verified
INFO - 2018-08-17 14:26:18 --> Input Class Initialized
INFO - 2018-08-17 14:26:18 --> Language Class Initialized
INFO - 2018-08-17 14:26:18 --> Loader Class Initialized
INFO - 2018-08-17 14:26:18 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:18 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:18 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:18 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:18 --> Controller Class Initialized
INFO - 2018-08-17 14:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:18 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:18 --> Form Validation Class Initialized
INFO - 2018-08-17 14:26:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:26:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:18 --> Config Class Initialized
INFO - 2018-08-17 14:26:18 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:18 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:18 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:18 --> URI Class Initialized
INFO - 2018-08-17 14:26:18 --> Router Class Initialized
INFO - 2018-08-17 14:26:18 --> Output Class Initialized
INFO - 2018-08-17 14:26:18 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:18 --> CSRF cookie sent
INFO - 2018-08-17 14:26:18 --> Input Class Initialized
INFO - 2018-08-17 14:26:18 --> Language Class Initialized
INFO - 2018-08-17 14:26:18 --> Loader Class Initialized
INFO - 2018-08-17 14:26:18 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:18 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:18 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:18 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:18 --> Controller Class Initialized
INFO - 2018-08-17 14:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:18 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-17 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:26:18 --> Final output sent to browser
DEBUG - 2018-08-17 14:26:18 --> Total execution time: 0.0395
INFO - 2018-08-17 14:26:26 --> Config Class Initialized
INFO - 2018-08-17 14:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:26 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:26 --> URI Class Initialized
INFO - 2018-08-17 14:26:26 --> Router Class Initialized
INFO - 2018-08-17 14:26:26 --> Output Class Initialized
INFO - 2018-08-17 14:26:26 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:26 --> CSRF cookie sent
INFO - 2018-08-17 14:26:26 --> CSRF token verified
INFO - 2018-08-17 14:26:26 --> Input Class Initialized
INFO - 2018-08-17 14:26:26 --> Language Class Initialized
INFO - 2018-08-17 14:26:26 --> Loader Class Initialized
INFO - 2018-08-17 14:26:26 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:26 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:26 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:26 --> Controller Class Initialized
INFO - 2018-08-17 14:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:26 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:26 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:26 --> Form Validation Class Initialized
INFO - 2018-08-17 14:26:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:26:26 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:26 --> Config Class Initialized
INFO - 2018-08-17 14:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:26 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:26 --> URI Class Initialized
INFO - 2018-08-17 14:26:26 --> Router Class Initialized
INFO - 2018-08-17 14:26:26 --> Output Class Initialized
INFO - 2018-08-17 14:26:26 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:26 --> CSRF cookie sent
INFO - 2018-08-17 14:26:26 --> Input Class Initialized
INFO - 2018-08-17 14:26:26 --> Language Class Initialized
INFO - 2018-08-17 14:26:26 --> Loader Class Initialized
INFO - 2018-08-17 14:26:26 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:26 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:26 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:26 --> Controller Class Initialized
INFO - 2018-08-17 14:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:26 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:26 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:26 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-17 14:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:26:26 --> Final output sent to browser
DEBUG - 2018-08-17 14:26:26 --> Total execution time: 0.0447
INFO - 2018-08-17 14:26:53 --> Config Class Initialized
INFO - 2018-08-17 14:26:53 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:53 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:53 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:53 --> URI Class Initialized
INFO - 2018-08-17 14:26:53 --> Router Class Initialized
INFO - 2018-08-17 14:26:53 --> Output Class Initialized
INFO - 2018-08-17 14:26:53 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:53 --> CSRF cookie sent
INFO - 2018-08-17 14:26:53 --> CSRF token verified
INFO - 2018-08-17 14:26:53 --> Input Class Initialized
INFO - 2018-08-17 14:26:53 --> Language Class Initialized
INFO - 2018-08-17 14:26:53 --> Loader Class Initialized
INFO - 2018-08-17 14:26:53 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:53 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:53 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:53 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:53 --> Controller Class Initialized
INFO - 2018-08-17 14:26:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:53 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:53 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:53 --> Form Validation Class Initialized
INFO - 2018-08-17 14:26:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:26:53 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:53 --> Config Class Initialized
INFO - 2018-08-17 14:26:53 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:26:53 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:26:53 --> Utf8 Class Initialized
INFO - 2018-08-17 14:26:53 --> URI Class Initialized
INFO - 2018-08-17 14:26:53 --> Router Class Initialized
INFO - 2018-08-17 14:26:53 --> Output Class Initialized
INFO - 2018-08-17 14:26:53 --> Security Class Initialized
DEBUG - 2018-08-17 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:26:53 --> CSRF cookie sent
INFO - 2018-08-17 14:26:53 --> Input Class Initialized
INFO - 2018-08-17 14:26:53 --> Language Class Initialized
INFO - 2018-08-17 14:26:53 --> Loader Class Initialized
INFO - 2018-08-17 14:26:53 --> Helper loaded: url_helper
INFO - 2018-08-17 14:26:53 --> Helper loaded: form_helper
INFO - 2018-08-17 14:26:53 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:26:53 --> User Agent Class Initialized
INFO - 2018-08-17 14:26:53 --> Controller Class Initialized
INFO - 2018-08-17 14:26:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:26:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:26:53 --> Pixel_Model class loaded
INFO - 2018-08-17 14:26:53 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:53 --> Database Driver Class Initialized
INFO - 2018-08-17 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-17 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:26:53 --> Final output sent to browser
DEBUG - 2018-08-17 14:26:53 --> Total execution time: 0.0449
INFO - 2018-08-17 14:27:11 --> Config Class Initialized
INFO - 2018-08-17 14:27:11 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:27:11 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:27:11 --> Utf8 Class Initialized
INFO - 2018-08-17 14:27:11 --> URI Class Initialized
INFO - 2018-08-17 14:27:11 --> Router Class Initialized
INFO - 2018-08-17 14:27:11 --> Output Class Initialized
INFO - 2018-08-17 14:27:11 --> Security Class Initialized
DEBUG - 2018-08-17 14:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:27:11 --> CSRF cookie sent
INFO - 2018-08-17 14:27:11 --> CSRF token verified
INFO - 2018-08-17 14:27:11 --> Input Class Initialized
INFO - 2018-08-17 14:27:11 --> Language Class Initialized
INFO - 2018-08-17 14:27:11 --> Loader Class Initialized
INFO - 2018-08-17 14:27:11 --> Helper loaded: url_helper
INFO - 2018-08-17 14:27:11 --> Helper loaded: form_helper
INFO - 2018-08-17 14:27:11 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:27:11 --> User Agent Class Initialized
INFO - 2018-08-17 14:27:11 --> Controller Class Initialized
INFO - 2018-08-17 14:27:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:27:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:27:11 --> Pixel_Model class loaded
INFO - 2018-08-17 14:27:11 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:11 --> Form Validation Class Initialized
INFO - 2018-08-17 14:27:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:27:11 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:11 --> Config Class Initialized
INFO - 2018-08-17 14:27:11 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:27:11 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:27:11 --> Utf8 Class Initialized
INFO - 2018-08-17 14:27:11 --> URI Class Initialized
INFO - 2018-08-17 14:27:11 --> Router Class Initialized
INFO - 2018-08-17 14:27:11 --> Output Class Initialized
INFO - 2018-08-17 14:27:11 --> Security Class Initialized
DEBUG - 2018-08-17 14:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:27:11 --> CSRF cookie sent
INFO - 2018-08-17 14:27:11 --> Input Class Initialized
INFO - 2018-08-17 14:27:11 --> Language Class Initialized
INFO - 2018-08-17 14:27:11 --> Loader Class Initialized
INFO - 2018-08-17 14:27:11 --> Helper loaded: url_helper
INFO - 2018-08-17 14:27:11 --> Helper loaded: form_helper
INFO - 2018-08-17 14:27:11 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:27:11 --> User Agent Class Initialized
INFO - 2018-08-17 14:27:11 --> Controller Class Initialized
INFO - 2018-08-17 14:27:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:27:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:27:11 --> Pixel_Model class loaded
INFO - 2018-08-17 14:27:11 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:11 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-17 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:27:11 --> Final output sent to browser
DEBUG - 2018-08-17 14:27:11 --> Total execution time: 0.0610
INFO - 2018-08-17 14:27:18 --> Config Class Initialized
INFO - 2018-08-17 14:27:18 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:27:18 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:27:18 --> Utf8 Class Initialized
INFO - 2018-08-17 14:27:18 --> URI Class Initialized
INFO - 2018-08-17 14:27:18 --> Router Class Initialized
INFO - 2018-08-17 14:27:18 --> Output Class Initialized
INFO - 2018-08-17 14:27:18 --> Security Class Initialized
DEBUG - 2018-08-17 14:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:27:18 --> CSRF cookie sent
INFO - 2018-08-17 14:27:18 --> CSRF token verified
INFO - 2018-08-17 14:27:18 --> Input Class Initialized
INFO - 2018-08-17 14:27:18 --> Language Class Initialized
INFO - 2018-08-17 14:27:18 --> Loader Class Initialized
INFO - 2018-08-17 14:27:18 --> Helper loaded: url_helper
INFO - 2018-08-17 14:27:18 --> Helper loaded: form_helper
INFO - 2018-08-17 14:27:18 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:27:18 --> User Agent Class Initialized
INFO - 2018-08-17 14:27:18 --> Controller Class Initialized
INFO - 2018-08-17 14:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:27:18 --> Pixel_Model class loaded
INFO - 2018-08-17 14:27:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:18 --> Form Validation Class Initialized
INFO - 2018-08-17 14:27:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:27:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:18 --> Config Class Initialized
INFO - 2018-08-17 14:27:18 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:27:18 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:27:18 --> Utf8 Class Initialized
INFO - 2018-08-17 14:27:18 --> URI Class Initialized
INFO - 2018-08-17 14:27:18 --> Router Class Initialized
INFO - 2018-08-17 14:27:18 --> Output Class Initialized
INFO - 2018-08-17 14:27:18 --> Security Class Initialized
DEBUG - 2018-08-17 14:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:27:18 --> CSRF cookie sent
INFO - 2018-08-17 14:27:18 --> Input Class Initialized
INFO - 2018-08-17 14:27:18 --> Language Class Initialized
INFO - 2018-08-17 14:27:18 --> Loader Class Initialized
INFO - 2018-08-17 14:27:18 --> Helper loaded: url_helper
INFO - 2018-08-17 14:27:18 --> Helper loaded: form_helper
INFO - 2018-08-17 14:27:18 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:27:18 --> User Agent Class Initialized
INFO - 2018-08-17 14:27:18 --> Controller Class Initialized
INFO - 2018-08-17 14:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:27:18 --> Pixel_Model class loaded
INFO - 2018-08-17 14:27:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:18 --> Database Driver Class Initialized
INFO - 2018-08-17 14:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-17 14:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:27:18 --> Final output sent to browser
DEBUG - 2018-08-17 14:27:18 --> Total execution time: 0.0622
INFO - 2018-08-17 14:28:03 --> Config Class Initialized
INFO - 2018-08-17 14:28:03 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:28:03 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:28:03 --> Utf8 Class Initialized
INFO - 2018-08-17 14:28:03 --> URI Class Initialized
INFO - 2018-08-17 14:28:03 --> Router Class Initialized
INFO - 2018-08-17 14:28:03 --> Output Class Initialized
INFO - 2018-08-17 14:28:03 --> Security Class Initialized
DEBUG - 2018-08-17 14:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:28:03 --> CSRF cookie sent
INFO - 2018-08-17 14:28:03 --> CSRF token verified
INFO - 2018-08-17 14:28:03 --> Input Class Initialized
INFO - 2018-08-17 14:28:03 --> Language Class Initialized
INFO - 2018-08-17 14:28:04 --> Loader Class Initialized
INFO - 2018-08-17 14:28:04 --> Helper loaded: url_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: form_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:28:04 --> User Agent Class Initialized
INFO - 2018-08-17 14:28:04 --> Controller Class Initialized
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:28:04 --> Pixel_Model class loaded
INFO - 2018-08-17 14:28:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:28:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:28:04 --> Form Validation Class Initialized
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:28:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:28:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:28:04 --> Config Class Initialized
INFO - 2018-08-17 14:28:04 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:28:04 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:28:04 --> Utf8 Class Initialized
INFO - 2018-08-17 14:28:04 --> URI Class Initialized
INFO - 2018-08-17 14:28:04 --> Router Class Initialized
INFO - 2018-08-17 14:28:04 --> Output Class Initialized
INFO - 2018-08-17 14:28:04 --> Security Class Initialized
DEBUG - 2018-08-17 14:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:28:04 --> CSRF cookie sent
INFO - 2018-08-17 14:28:04 --> Input Class Initialized
INFO - 2018-08-17 14:28:04 --> Language Class Initialized
INFO - 2018-08-17 14:28:04 --> Loader Class Initialized
INFO - 2018-08-17 14:28:04 --> Helper loaded: url_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: form_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:28:04 --> User Agent Class Initialized
INFO - 2018-08-17 14:28:04 --> Controller Class Initialized
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:28:04 --> Pixel_Model class loaded
INFO - 2018-08-17 14:28:04 --> Database Driver Class Initialized
INFO - 2018-08-17 14:28:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:28:04 --> Config Class Initialized
INFO - 2018-08-17 14:28:04 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:28:04 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:28:04 --> Utf8 Class Initialized
INFO - 2018-08-17 14:28:04 --> URI Class Initialized
INFO - 2018-08-17 14:28:04 --> Router Class Initialized
INFO - 2018-08-17 14:28:04 --> Output Class Initialized
INFO - 2018-08-17 14:28:04 --> Security Class Initialized
DEBUG - 2018-08-17 14:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:28:04 --> CSRF cookie sent
INFO - 2018-08-17 14:28:04 --> Input Class Initialized
INFO - 2018-08-17 14:28:04 --> Language Class Initialized
INFO - 2018-08-17 14:28:04 --> Loader Class Initialized
INFO - 2018-08-17 14:28:04 --> Helper loaded: url_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: form_helper
INFO - 2018-08-17 14:28:04 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:28:04 --> User Agent Class Initialized
INFO - 2018-08-17 14:28:04 --> Controller Class Initialized
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:28:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-17 14:28:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-17 14:28:04 --> Could not find the language line "req_email"
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-17 14:28:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:28:04 --> Final output sent to browser
DEBUG - 2018-08-17 14:28:04 --> Total execution time: 0.0288
INFO - 2018-08-17 14:32:59 --> Config Class Initialized
INFO - 2018-08-17 14:32:59 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:32:59 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:32:59 --> Utf8 Class Initialized
INFO - 2018-08-17 14:32:59 --> URI Class Initialized
INFO - 2018-08-17 14:32:59 --> Router Class Initialized
INFO - 2018-08-17 14:32:59 --> Output Class Initialized
INFO - 2018-08-17 14:32:59 --> Security Class Initialized
DEBUG - 2018-08-17 14:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:32:59 --> CSRF cookie sent
INFO - 2018-08-17 14:32:59 --> Input Class Initialized
INFO - 2018-08-17 14:32:59 --> Language Class Initialized
INFO - 2018-08-17 14:32:59 --> Loader Class Initialized
INFO - 2018-08-17 14:32:59 --> Helper loaded: url_helper
INFO - 2018-08-17 14:32:59 --> Helper loaded: form_helper
INFO - 2018-08-17 14:32:59 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:32:59 --> User Agent Class Initialized
INFO - 2018-08-17 14:32:59 --> Controller Class Initialized
INFO - 2018-08-17 14:32:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:32:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:32:59 --> Pixel_Model class loaded
INFO - 2018-08-17 14:32:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:32:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:32:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:32:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-17 14:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:32:59 --> Final output sent to browser
DEBUG - 2018-08-17 14:32:59 --> Total execution time: 0.0489
INFO - 2018-08-17 14:33:00 --> Config Class Initialized
INFO - 2018-08-17 14:33:00 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:00 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:00 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:01 --> URI Class Initialized
INFO - 2018-08-17 14:33:01 --> Router Class Initialized
INFO - 2018-08-17 14:33:01 --> Output Class Initialized
INFO - 2018-08-17 14:33:01 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:01 --> CSRF cookie sent
INFO - 2018-08-17 14:33:01 --> Input Class Initialized
INFO - 2018-08-17 14:33:01 --> Language Class Initialized
INFO - 2018-08-17 14:33:01 --> Loader Class Initialized
INFO - 2018-08-17 14:33:01 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:01 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:01 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:01 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:01 --> Controller Class Initialized
INFO - 2018-08-17 14:33:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:01 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:01 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:01 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-17 14:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:01 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:01 --> Total execution time: 0.0496
INFO - 2018-08-17 14:33:02 --> Config Class Initialized
INFO - 2018-08-17 14:33:02 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:02 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:02 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:02 --> URI Class Initialized
INFO - 2018-08-17 14:33:02 --> Router Class Initialized
INFO - 2018-08-17 14:33:02 --> Output Class Initialized
INFO - 2018-08-17 14:33:02 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:02 --> CSRF cookie sent
INFO - 2018-08-17 14:33:02 --> Input Class Initialized
INFO - 2018-08-17 14:33:02 --> Language Class Initialized
INFO - 2018-08-17 14:33:02 --> Loader Class Initialized
INFO - 2018-08-17 14:33:02 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:02 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:02 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:02 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:02 --> Controller Class Initialized
INFO - 2018-08-17 14:33:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:02 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:02 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:02 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-17 14:33:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:02 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:02 --> Total execution time: 0.0452
INFO - 2018-08-17 14:33:03 --> Config Class Initialized
INFO - 2018-08-17 14:33:03 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:03 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:03 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:03 --> URI Class Initialized
INFO - 2018-08-17 14:33:03 --> Router Class Initialized
INFO - 2018-08-17 14:33:03 --> Output Class Initialized
INFO - 2018-08-17 14:33:03 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:03 --> CSRF cookie sent
INFO - 2018-08-17 14:33:03 --> Input Class Initialized
INFO - 2018-08-17 14:33:03 --> Language Class Initialized
INFO - 2018-08-17 14:33:03 --> Loader Class Initialized
INFO - 2018-08-17 14:33:03 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:03 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:03 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:03 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:03 --> Controller Class Initialized
INFO - 2018-08-17 14:33:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:03 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:03 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:03 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-17 14:33:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:03 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:03 --> Total execution time: 0.0437
INFO - 2018-08-17 14:33:05 --> Config Class Initialized
INFO - 2018-08-17 14:33:05 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:05 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:05 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:05 --> URI Class Initialized
INFO - 2018-08-17 14:33:05 --> Router Class Initialized
INFO - 2018-08-17 14:33:05 --> Output Class Initialized
INFO - 2018-08-17 14:33:05 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:05 --> CSRF cookie sent
INFO - 2018-08-17 14:33:05 --> Input Class Initialized
INFO - 2018-08-17 14:33:05 --> Language Class Initialized
INFO - 2018-08-17 14:33:05 --> Loader Class Initialized
INFO - 2018-08-17 14:33:05 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:05 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:05 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:05 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:05 --> Controller Class Initialized
INFO - 2018-08-17 14:33:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:05 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:05 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:05 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-17 14:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:05 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:05 --> Total execution time: 0.0423
INFO - 2018-08-17 14:33:06 --> Config Class Initialized
INFO - 2018-08-17 14:33:06 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:06 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:06 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:06 --> URI Class Initialized
INFO - 2018-08-17 14:33:06 --> Router Class Initialized
INFO - 2018-08-17 14:33:06 --> Output Class Initialized
INFO - 2018-08-17 14:33:06 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:06 --> CSRF cookie sent
INFO - 2018-08-17 14:33:06 --> Input Class Initialized
INFO - 2018-08-17 14:33:06 --> Language Class Initialized
INFO - 2018-08-17 14:33:06 --> Loader Class Initialized
INFO - 2018-08-17 14:33:06 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:06 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:06 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:06 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:06 --> Controller Class Initialized
INFO - 2018-08-17 14:33:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:06 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:06 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:06 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-17 14:33:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:06 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:06 --> Total execution time: 0.0401
INFO - 2018-08-17 14:33:10 --> Config Class Initialized
INFO - 2018-08-17 14:33:10 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:10 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:10 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:10 --> URI Class Initialized
INFO - 2018-08-17 14:33:10 --> Router Class Initialized
INFO - 2018-08-17 14:33:10 --> Output Class Initialized
INFO - 2018-08-17 14:33:10 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:10 --> CSRF cookie sent
INFO - 2018-08-17 14:33:10 --> Input Class Initialized
INFO - 2018-08-17 14:33:10 --> Language Class Initialized
INFO - 2018-08-17 14:33:10 --> Loader Class Initialized
INFO - 2018-08-17 14:33:10 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:10 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:10 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:10 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:10 --> Controller Class Initialized
INFO - 2018-08-17 14:33:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:10 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:10 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-17 14:33:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:10 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:10 --> Total execution time: 0.0561
INFO - 2018-08-17 14:33:33 --> Config Class Initialized
INFO - 2018-08-17 14:33:33 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:33 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:33 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:33 --> URI Class Initialized
INFO - 2018-08-17 14:33:33 --> Router Class Initialized
INFO - 2018-08-17 14:33:33 --> Output Class Initialized
INFO - 2018-08-17 14:33:33 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:33 --> CSRF cookie sent
INFO - 2018-08-17 14:33:33 --> Input Class Initialized
INFO - 2018-08-17 14:33:33 --> Language Class Initialized
INFO - 2018-08-17 14:33:33 --> Loader Class Initialized
INFO - 2018-08-17 14:33:33 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:33 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:33 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:33 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:33 --> Controller Class Initialized
INFO - 2018-08-17 14:33:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:33 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:33 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:33 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-17 14:33:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:33 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:33 --> Total execution time: 0.0559
INFO - 2018-08-17 14:33:48 --> Config Class Initialized
INFO - 2018-08-17 14:33:48 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:48 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:48 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:48 --> URI Class Initialized
INFO - 2018-08-17 14:33:48 --> Router Class Initialized
INFO - 2018-08-17 14:33:48 --> Output Class Initialized
INFO - 2018-08-17 14:33:48 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:48 --> CSRF cookie sent
INFO - 2018-08-17 14:33:48 --> CSRF token verified
INFO - 2018-08-17 14:33:48 --> Input Class Initialized
INFO - 2018-08-17 14:33:48 --> Language Class Initialized
INFO - 2018-08-17 14:33:48 --> Loader Class Initialized
INFO - 2018-08-17 14:33:48 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:48 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:48 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:48 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:48 --> Controller Class Initialized
INFO - 2018-08-17 14:33:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:48 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:48 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:48 --> Form Validation Class Initialized
INFO - 2018-08-17 14:33:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:33:48 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:48 --> Config Class Initialized
INFO - 2018-08-17 14:33:48 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:48 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:48 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:48 --> URI Class Initialized
INFO - 2018-08-17 14:33:48 --> Router Class Initialized
INFO - 2018-08-17 14:33:48 --> Output Class Initialized
INFO - 2018-08-17 14:33:48 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:48 --> CSRF cookie sent
INFO - 2018-08-17 14:33:48 --> Input Class Initialized
INFO - 2018-08-17 14:33:48 --> Language Class Initialized
INFO - 2018-08-17 14:33:48 --> Loader Class Initialized
INFO - 2018-08-17 14:33:48 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:48 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:48 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:48 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:48 --> Controller Class Initialized
INFO - 2018-08-17 14:33:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:48 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:48 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:48 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-17 14:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:48 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:48 --> Total execution time: 0.0544
INFO - 2018-08-17 14:33:55 --> Config Class Initialized
INFO - 2018-08-17 14:33:55 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:55 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:55 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:55 --> URI Class Initialized
INFO - 2018-08-17 14:33:55 --> Router Class Initialized
INFO - 2018-08-17 14:33:55 --> Output Class Initialized
INFO - 2018-08-17 14:33:55 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:55 --> CSRF cookie sent
INFO - 2018-08-17 14:33:55 --> CSRF token verified
INFO - 2018-08-17 14:33:55 --> Input Class Initialized
INFO - 2018-08-17 14:33:55 --> Language Class Initialized
INFO - 2018-08-17 14:33:55 --> Loader Class Initialized
INFO - 2018-08-17 14:33:55 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:55 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:55 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:56 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:56 --> Controller Class Initialized
INFO - 2018-08-17 14:33:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:56 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:56 --> Form Validation Class Initialized
INFO - 2018-08-17 14:33:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:33:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:56 --> Config Class Initialized
INFO - 2018-08-17 14:33:56 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:33:56 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:33:56 --> Utf8 Class Initialized
INFO - 2018-08-17 14:33:56 --> URI Class Initialized
INFO - 2018-08-17 14:33:56 --> Router Class Initialized
INFO - 2018-08-17 14:33:56 --> Output Class Initialized
INFO - 2018-08-17 14:33:56 --> Security Class Initialized
DEBUG - 2018-08-17 14:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:33:56 --> CSRF cookie sent
INFO - 2018-08-17 14:33:56 --> Input Class Initialized
INFO - 2018-08-17 14:33:56 --> Language Class Initialized
INFO - 2018-08-17 14:33:56 --> Loader Class Initialized
INFO - 2018-08-17 14:33:56 --> Helper loaded: url_helper
INFO - 2018-08-17 14:33:56 --> Helper loaded: form_helper
INFO - 2018-08-17 14:33:56 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:33:56 --> User Agent Class Initialized
INFO - 2018-08-17 14:33:56 --> Controller Class Initialized
INFO - 2018-08-17 14:33:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:33:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:33:56 --> Pixel_Model class loaded
INFO - 2018-08-17 14:33:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:56 --> Database Driver Class Initialized
INFO - 2018-08-17 14:33:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-17 14:33:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:33:56 --> Final output sent to browser
DEBUG - 2018-08-17 14:33:56 --> Total execution time: 0.0415
INFO - 2018-08-17 14:35:35 --> Config Class Initialized
INFO - 2018-08-17 14:35:35 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:35 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:35 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:35 --> URI Class Initialized
INFO - 2018-08-17 14:35:35 --> Router Class Initialized
INFO - 2018-08-17 14:35:35 --> Output Class Initialized
INFO - 2018-08-17 14:35:35 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:35 --> CSRF cookie sent
INFO - 2018-08-17 14:35:35 --> CSRF token verified
INFO - 2018-08-17 14:35:35 --> Input Class Initialized
INFO - 2018-08-17 14:35:35 --> Language Class Initialized
INFO - 2018-08-17 14:35:35 --> Loader Class Initialized
INFO - 2018-08-17 14:35:35 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:35 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:35 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:35 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:35 --> Controller Class Initialized
INFO - 2018-08-17 14:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:35 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:35 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:35 --> Form Validation Class Initialized
INFO - 2018-08-17 14:35:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:35:35 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:35 --> Config Class Initialized
INFO - 2018-08-17 14:35:35 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:35 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:35 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:35 --> URI Class Initialized
INFO - 2018-08-17 14:35:35 --> Router Class Initialized
INFO - 2018-08-17 14:35:35 --> Output Class Initialized
INFO - 2018-08-17 14:35:35 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:35 --> CSRF cookie sent
INFO - 2018-08-17 14:35:35 --> Input Class Initialized
INFO - 2018-08-17 14:35:35 --> Language Class Initialized
INFO - 2018-08-17 14:35:35 --> Loader Class Initialized
INFO - 2018-08-17 14:35:35 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:35 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:35 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:35 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:35 --> Controller Class Initialized
INFO - 2018-08-17 14:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:35 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:35 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:35 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-17 14:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:35:35 --> Final output sent to browser
DEBUG - 2018-08-17 14:35:35 --> Total execution time: 0.0446
INFO - 2018-08-17 14:35:54 --> Config Class Initialized
INFO - 2018-08-17 14:35:54 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:54 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:54 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:54 --> URI Class Initialized
INFO - 2018-08-17 14:35:54 --> Router Class Initialized
INFO - 2018-08-17 14:35:54 --> Output Class Initialized
INFO - 2018-08-17 14:35:54 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:54 --> CSRF cookie sent
INFO - 2018-08-17 14:35:54 --> CSRF token verified
INFO - 2018-08-17 14:35:54 --> Input Class Initialized
INFO - 2018-08-17 14:35:54 --> Language Class Initialized
INFO - 2018-08-17 14:35:54 --> Loader Class Initialized
INFO - 2018-08-17 14:35:54 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:54 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:54 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:54 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:54 --> Controller Class Initialized
INFO - 2018-08-17 14:35:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:54 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:54 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:54 --> Form Validation Class Initialized
INFO - 2018-08-17 14:35:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:35:54 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:54 --> Config Class Initialized
INFO - 2018-08-17 14:35:54 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:54 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:54 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:54 --> URI Class Initialized
INFO - 2018-08-17 14:35:54 --> Router Class Initialized
INFO - 2018-08-17 14:35:54 --> Output Class Initialized
INFO - 2018-08-17 14:35:54 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:54 --> CSRF cookie sent
INFO - 2018-08-17 14:35:54 --> Input Class Initialized
INFO - 2018-08-17 14:35:54 --> Language Class Initialized
INFO - 2018-08-17 14:35:54 --> Loader Class Initialized
INFO - 2018-08-17 14:35:54 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:54 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:54 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:54 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:54 --> Controller Class Initialized
INFO - 2018-08-17 14:35:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:54 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:54 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:54 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-17 14:35:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:35:54 --> Final output sent to browser
DEBUG - 2018-08-17 14:35:54 --> Total execution time: 0.0469
INFO - 2018-08-17 14:35:59 --> Config Class Initialized
INFO - 2018-08-17 14:35:59 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:59 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:59 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:59 --> URI Class Initialized
INFO - 2018-08-17 14:35:59 --> Router Class Initialized
INFO - 2018-08-17 14:35:59 --> Output Class Initialized
INFO - 2018-08-17 14:35:59 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:59 --> CSRF cookie sent
INFO - 2018-08-17 14:35:59 --> CSRF token verified
INFO - 2018-08-17 14:35:59 --> Input Class Initialized
INFO - 2018-08-17 14:35:59 --> Language Class Initialized
INFO - 2018-08-17 14:35:59 --> Loader Class Initialized
INFO - 2018-08-17 14:35:59 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:59 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:59 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:59 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:59 --> Controller Class Initialized
INFO - 2018-08-17 14:35:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:59 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:59 --> Form Validation Class Initialized
INFO - 2018-08-17 14:35:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:35:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:59 --> Config Class Initialized
INFO - 2018-08-17 14:35:59 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:35:59 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:35:59 --> Utf8 Class Initialized
INFO - 2018-08-17 14:35:59 --> URI Class Initialized
INFO - 2018-08-17 14:35:59 --> Router Class Initialized
INFO - 2018-08-17 14:35:59 --> Output Class Initialized
INFO - 2018-08-17 14:35:59 --> Security Class Initialized
DEBUG - 2018-08-17 14:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:35:59 --> CSRF cookie sent
INFO - 2018-08-17 14:35:59 --> Input Class Initialized
INFO - 2018-08-17 14:35:59 --> Language Class Initialized
INFO - 2018-08-17 14:35:59 --> Loader Class Initialized
INFO - 2018-08-17 14:35:59 --> Helper loaded: url_helper
INFO - 2018-08-17 14:35:59 --> Helper loaded: form_helper
INFO - 2018-08-17 14:35:59 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:35:59 --> User Agent Class Initialized
INFO - 2018-08-17 14:35:59 --> Controller Class Initialized
INFO - 2018-08-17 14:35:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:35:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:35:59 --> Pixel_Model class loaded
INFO - 2018-08-17 14:35:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:35:59 --> Database Driver Class Initialized
INFO - 2018-08-17 14:35:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-17 14:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:36:00 --> Final output sent to browser
DEBUG - 2018-08-17 14:36:00 --> Total execution time: 0.0445
INFO - 2018-08-17 14:36:03 --> Config Class Initialized
INFO - 2018-08-17 14:36:03 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:36:03 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:36:03 --> Utf8 Class Initialized
INFO - 2018-08-17 14:36:03 --> URI Class Initialized
INFO - 2018-08-17 14:36:03 --> Router Class Initialized
INFO - 2018-08-17 14:36:03 --> Output Class Initialized
INFO - 2018-08-17 14:36:03 --> Security Class Initialized
DEBUG - 2018-08-17 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:36:03 --> CSRF cookie sent
INFO - 2018-08-17 14:36:03 --> CSRF token verified
INFO - 2018-08-17 14:36:03 --> Input Class Initialized
INFO - 2018-08-17 14:36:03 --> Language Class Initialized
INFO - 2018-08-17 14:36:03 --> Loader Class Initialized
INFO - 2018-08-17 14:36:03 --> Helper loaded: url_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: form_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:36:03 --> User Agent Class Initialized
INFO - 2018-08-17 14:36:03 --> Controller Class Initialized
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:36:03 --> Pixel_Model class loaded
INFO - 2018-08-17 14:36:03 --> Database Driver Class Initialized
INFO - 2018-08-17 14:36:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:03 --> Form Validation Class Initialized
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-17 14:36:03 --> Database Driver Class Initialized
INFO - 2018-08-17 14:36:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:03 --> Config Class Initialized
INFO - 2018-08-17 14:36:03 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:36:03 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:36:03 --> Utf8 Class Initialized
INFO - 2018-08-17 14:36:03 --> URI Class Initialized
INFO - 2018-08-17 14:36:03 --> Router Class Initialized
INFO - 2018-08-17 14:36:03 --> Output Class Initialized
INFO - 2018-08-17 14:36:03 --> Security Class Initialized
DEBUG - 2018-08-17 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:36:03 --> CSRF cookie sent
INFO - 2018-08-17 14:36:03 --> Input Class Initialized
INFO - 2018-08-17 14:36:03 --> Language Class Initialized
INFO - 2018-08-17 14:36:03 --> Loader Class Initialized
INFO - 2018-08-17 14:36:03 --> Helper loaded: url_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: form_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:36:03 --> User Agent Class Initialized
INFO - 2018-08-17 14:36:03 --> Controller Class Initialized
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:36:03 --> Pixel_Model class loaded
INFO - 2018-08-17 14:36:03 --> Database Driver Class Initialized
INFO - 2018-08-17 14:36:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:03 --> Config Class Initialized
INFO - 2018-08-17 14:36:03 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:36:03 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:36:03 --> Utf8 Class Initialized
INFO - 2018-08-17 14:36:03 --> URI Class Initialized
INFO - 2018-08-17 14:36:03 --> Router Class Initialized
INFO - 2018-08-17 14:36:03 --> Output Class Initialized
INFO - 2018-08-17 14:36:03 --> Security Class Initialized
DEBUG - 2018-08-17 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:36:03 --> CSRF cookie sent
INFO - 2018-08-17 14:36:03 --> Input Class Initialized
INFO - 2018-08-17 14:36:03 --> Language Class Initialized
INFO - 2018-08-17 14:36:03 --> Loader Class Initialized
INFO - 2018-08-17 14:36:03 --> Helper loaded: url_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: form_helper
INFO - 2018-08-17 14:36:03 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:36:03 --> User Agent Class Initialized
INFO - 2018-08-17 14:36:03 --> Controller Class Initialized
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:36:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-17 14:36:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-17 14:36:03 --> Could not find the language line "req_email"
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-17 14:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:36:03 --> Final output sent to browser
DEBUG - 2018-08-17 14:36:03 --> Total execution time: 0.0224
INFO - 2018-08-17 14:36:07 --> Config Class Initialized
INFO - 2018-08-17 14:36:07 --> Hooks Class Initialized
DEBUG - 2018-08-17 14:36:07 --> UTF-8 Support Enabled
INFO - 2018-08-17 14:36:07 --> Utf8 Class Initialized
INFO - 2018-08-17 14:36:07 --> URI Class Initialized
INFO - 2018-08-17 14:36:07 --> Router Class Initialized
INFO - 2018-08-17 14:36:07 --> Output Class Initialized
INFO - 2018-08-17 14:36:07 --> Security Class Initialized
DEBUG - 2018-08-17 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-17 14:36:07 --> CSRF cookie sent
INFO - 2018-08-17 14:36:07 --> Input Class Initialized
INFO - 2018-08-17 14:36:07 --> Language Class Initialized
INFO - 2018-08-17 14:36:07 --> Loader Class Initialized
INFO - 2018-08-17 14:36:07 --> Helper loaded: url_helper
INFO - 2018-08-17 14:36:07 --> Helper loaded: form_helper
INFO - 2018-08-17 14:36:07 --> Helper loaded: language_helper
DEBUG - 2018-08-17 14:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-17 14:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-17 14:36:07 --> User Agent Class Initialized
INFO - 2018-08-17 14:36:07 --> Controller Class Initialized
INFO - 2018-08-17 14:36:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-17 14:36:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-17 14:36:07 --> Pixel_Model class loaded
INFO - 2018-08-17 14:36:07 --> Database Driver Class Initialized
INFO - 2018-08-17 14:36:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:07 --> Database Driver Class Initialized
INFO - 2018-08-17 14:36:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-17 14:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-17 14:36:07 --> Final output sent to browser
DEBUG - 2018-08-17 14:36:07 --> Total execution time: 0.0599

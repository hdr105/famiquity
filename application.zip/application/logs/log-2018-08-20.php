<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-20 22:57:29 --> Config Class Initialized
INFO - 2018-08-20 22:57:29 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:29 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:29 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:29 --> URI Class Initialized
DEBUG - 2018-08-20 22:57:29 --> No URI present. Default controller set.
INFO - 2018-08-20 22:57:29 --> Router Class Initialized
INFO - 2018-08-20 22:57:29 --> Output Class Initialized
INFO - 2018-08-20 22:57:29 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:29 --> CSRF cookie sent
INFO - 2018-08-20 22:57:29 --> Input Class Initialized
INFO - 2018-08-20 22:57:29 --> Language Class Initialized
INFO - 2018-08-20 22:57:29 --> Loader Class Initialized
INFO - 2018-08-20 22:57:29 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:29 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:29 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:29 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:29 --> Controller Class Initialized
INFO - 2018-08-20 22:57:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:29 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:29 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:57:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:57:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-20 22:57:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:57:29 --> Final output sent to browser
DEBUG - 2018-08-20 22:57:29 --> Total execution time: 0.0672
INFO - 2018-08-20 22:57:30 --> Config Class Initialized
INFO - 2018-08-20 22:57:30 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:30 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:30 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:30 --> URI Class Initialized
DEBUG - 2018-08-20 22:57:30 --> No URI present. Default controller set.
INFO - 2018-08-20 22:57:30 --> Router Class Initialized
INFO - 2018-08-20 22:57:30 --> Output Class Initialized
INFO - 2018-08-20 22:57:30 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:30 --> CSRF cookie sent
INFO - 2018-08-20 22:57:30 --> Input Class Initialized
INFO - 2018-08-20 22:57:30 --> Language Class Initialized
INFO - 2018-08-20 22:57:30 --> Loader Class Initialized
INFO - 2018-08-20 22:57:30 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:30 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:30 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:30 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:30 --> Controller Class Initialized
INFO - 2018-08-20 22:57:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:30 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:30 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:57:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:57:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-20 22:57:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:57:30 --> Final output sent to browser
DEBUG - 2018-08-20 22:57:30 --> Total execution time: 0.0529
INFO - 2018-08-20 22:57:39 --> Config Class Initialized
INFO - 2018-08-20 22:57:39 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:39 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:39 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:39 --> URI Class Initialized
INFO - 2018-08-20 22:57:39 --> Router Class Initialized
INFO - 2018-08-20 22:57:39 --> Output Class Initialized
INFO - 2018-08-20 22:57:39 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:39 --> CSRF cookie sent
INFO - 2018-08-20 22:57:39 --> CSRF token verified
INFO - 2018-08-20 22:57:39 --> Input Class Initialized
INFO - 2018-08-20 22:57:39 --> Language Class Initialized
INFO - 2018-08-20 22:57:39 --> Loader Class Initialized
INFO - 2018-08-20 22:57:39 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:39 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:39 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:39 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:39 --> Controller Class Initialized
INFO - 2018-08-20 22:57:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:39 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:39 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:39 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:39 --> Config Class Initialized
INFO - 2018-08-20 22:57:39 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:39 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:39 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:39 --> URI Class Initialized
INFO - 2018-08-20 22:57:39 --> Router Class Initialized
INFO - 2018-08-20 22:57:39 --> Output Class Initialized
INFO - 2018-08-20 22:57:39 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:39 --> CSRF cookie sent
INFO - 2018-08-20 22:57:39 --> Input Class Initialized
INFO - 2018-08-20 22:57:39 --> Language Class Initialized
INFO - 2018-08-20 22:57:39 --> Loader Class Initialized
INFO - 2018-08-20 22:57:39 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:39 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:39 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:39 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:39 --> Controller Class Initialized
INFO - 2018-08-20 22:57:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:39 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:39 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:39 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-20 22:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:57:39 --> Final output sent to browser
DEBUG - 2018-08-20 22:57:39 --> Total execution time: 0.0524
INFO - 2018-08-20 22:57:49 --> Config Class Initialized
INFO - 2018-08-20 22:57:49 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:49 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:49 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:49 --> URI Class Initialized
INFO - 2018-08-20 22:57:49 --> Router Class Initialized
INFO - 2018-08-20 22:57:49 --> Output Class Initialized
INFO - 2018-08-20 22:57:49 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:49 --> CSRF cookie sent
INFO - 2018-08-20 22:57:49 --> CSRF token verified
INFO - 2018-08-20 22:57:49 --> Input Class Initialized
INFO - 2018-08-20 22:57:49 --> Language Class Initialized
INFO - 2018-08-20 22:57:49 --> Loader Class Initialized
INFO - 2018-08-20 22:57:49 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:49 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:49 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:49 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:49 --> Controller Class Initialized
INFO - 2018-08-20 22:57:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:49 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:49 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:49 --> Form Validation Class Initialized
INFO - 2018-08-20 22:57:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-20 22:57:49 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:49 --> Config Class Initialized
INFO - 2018-08-20 22:57:49 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:49 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:49 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:49 --> URI Class Initialized
INFO - 2018-08-20 22:57:49 --> Router Class Initialized
INFO - 2018-08-20 22:57:49 --> Output Class Initialized
INFO - 2018-08-20 22:57:49 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:49 --> CSRF cookie sent
INFO - 2018-08-20 22:57:49 --> Input Class Initialized
INFO - 2018-08-20 22:57:49 --> Language Class Initialized
INFO - 2018-08-20 22:57:49 --> Loader Class Initialized
INFO - 2018-08-20 22:57:49 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:49 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:49 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:49 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:49 --> Controller Class Initialized
INFO - 2018-08-20 22:57:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:49 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:49 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:49 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-20 22:57:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:57:49 --> Final output sent to browser
DEBUG - 2018-08-20 22:57:49 --> Total execution time: 0.0470
INFO - 2018-08-20 22:57:58 --> Config Class Initialized
INFO - 2018-08-20 22:57:58 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:58 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:58 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:58 --> URI Class Initialized
INFO - 2018-08-20 22:57:58 --> Router Class Initialized
INFO - 2018-08-20 22:57:58 --> Output Class Initialized
INFO - 2018-08-20 22:57:58 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:58 --> CSRF cookie sent
INFO - 2018-08-20 22:57:58 --> CSRF token verified
INFO - 2018-08-20 22:57:58 --> Input Class Initialized
INFO - 2018-08-20 22:57:58 --> Language Class Initialized
INFO - 2018-08-20 22:57:58 --> Loader Class Initialized
INFO - 2018-08-20 22:57:58 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:58 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:58 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:58 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:58 --> Controller Class Initialized
INFO - 2018-08-20 22:57:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:58 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:58 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:58 --> Form Validation Class Initialized
INFO - 2018-08-20 22:57:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-20 22:57:58 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:58 --> Config Class Initialized
INFO - 2018-08-20 22:57:58 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:57:58 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:57:58 --> Utf8 Class Initialized
INFO - 2018-08-20 22:57:58 --> URI Class Initialized
INFO - 2018-08-20 22:57:58 --> Router Class Initialized
INFO - 2018-08-20 22:57:58 --> Output Class Initialized
INFO - 2018-08-20 22:57:58 --> Security Class Initialized
DEBUG - 2018-08-20 22:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:57:58 --> CSRF cookie sent
INFO - 2018-08-20 22:57:58 --> Input Class Initialized
INFO - 2018-08-20 22:57:58 --> Language Class Initialized
INFO - 2018-08-20 22:57:58 --> Loader Class Initialized
INFO - 2018-08-20 22:57:58 --> Helper loaded: url_helper
INFO - 2018-08-20 22:57:58 --> Helper loaded: form_helper
INFO - 2018-08-20 22:57:58 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:57:58 --> User Agent Class Initialized
INFO - 2018-08-20 22:57:58 --> Controller Class Initialized
INFO - 2018-08-20 22:57:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:57:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:57:58 --> Pixel_Model class loaded
INFO - 2018-08-20 22:57:58 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:58 --> Database Driver Class Initialized
INFO - 2018-08-20 22:57:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-20 22:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:57:58 --> Final output sent to browser
DEBUG - 2018-08-20 22:57:58 --> Total execution time: 0.0370
INFO - 2018-08-20 22:58:05 --> Config Class Initialized
INFO - 2018-08-20 22:58:05 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:58:05 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:58:05 --> Utf8 Class Initialized
INFO - 2018-08-20 22:58:05 --> URI Class Initialized
INFO - 2018-08-20 22:58:05 --> Router Class Initialized
INFO - 2018-08-20 22:58:05 --> Output Class Initialized
INFO - 2018-08-20 22:58:05 --> Security Class Initialized
DEBUG - 2018-08-20 22:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:58:05 --> CSRF cookie sent
INFO - 2018-08-20 22:58:05 --> CSRF token verified
INFO - 2018-08-20 22:58:05 --> Input Class Initialized
INFO - 2018-08-20 22:58:05 --> Language Class Initialized
INFO - 2018-08-20 22:58:05 --> Loader Class Initialized
INFO - 2018-08-20 22:58:05 --> Helper loaded: url_helper
INFO - 2018-08-20 22:58:05 --> Helper loaded: form_helper
INFO - 2018-08-20 22:58:05 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:58:05 --> User Agent Class Initialized
INFO - 2018-08-20 22:58:05 --> Controller Class Initialized
INFO - 2018-08-20 22:58:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:58:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:58:05 --> Pixel_Model class loaded
INFO - 2018-08-20 22:58:05 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:05 --> Form Validation Class Initialized
INFO - 2018-08-20 22:58:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-20 22:58:05 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:05 --> Config Class Initialized
INFO - 2018-08-20 22:58:05 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:58:05 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:58:05 --> Utf8 Class Initialized
INFO - 2018-08-20 22:58:05 --> URI Class Initialized
INFO - 2018-08-20 22:58:05 --> Router Class Initialized
INFO - 2018-08-20 22:58:05 --> Output Class Initialized
INFO - 2018-08-20 22:58:05 --> Security Class Initialized
DEBUG - 2018-08-20 22:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:58:05 --> CSRF cookie sent
INFO - 2018-08-20 22:58:05 --> Input Class Initialized
INFO - 2018-08-20 22:58:05 --> Language Class Initialized
INFO - 2018-08-20 22:58:05 --> Loader Class Initialized
INFO - 2018-08-20 22:58:05 --> Helper loaded: url_helper
INFO - 2018-08-20 22:58:05 --> Helper loaded: form_helper
INFO - 2018-08-20 22:58:05 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:58:05 --> User Agent Class Initialized
INFO - 2018-08-20 22:58:05 --> Controller Class Initialized
INFO - 2018-08-20 22:58:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:58:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:58:05 --> Pixel_Model class loaded
INFO - 2018-08-20 22:58:05 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:05 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-20 22:58:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:58:05 --> Final output sent to browser
DEBUG - 2018-08-20 22:58:05 --> Total execution time: 0.0612
INFO - 2018-08-20 22:58:13 --> Config Class Initialized
INFO - 2018-08-20 22:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:58:13 --> Utf8 Class Initialized
INFO - 2018-08-20 22:58:13 --> URI Class Initialized
INFO - 2018-08-20 22:58:13 --> Router Class Initialized
INFO - 2018-08-20 22:58:13 --> Output Class Initialized
INFO - 2018-08-20 22:58:13 --> Security Class Initialized
DEBUG - 2018-08-20 22:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:58:13 --> CSRF cookie sent
INFO - 2018-08-20 22:58:13 --> CSRF token verified
INFO - 2018-08-20 22:58:13 --> Input Class Initialized
INFO - 2018-08-20 22:58:13 --> Language Class Initialized
INFO - 2018-08-20 22:58:13 --> Loader Class Initialized
INFO - 2018-08-20 22:58:13 --> Helper loaded: url_helper
INFO - 2018-08-20 22:58:13 --> Helper loaded: form_helper
INFO - 2018-08-20 22:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:58:13 --> User Agent Class Initialized
INFO - 2018-08-20 22:58:13 --> Controller Class Initialized
INFO - 2018-08-20 22:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:58:13 --> Pixel_Model class loaded
INFO - 2018-08-20 22:58:13 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:13 --> Form Validation Class Initialized
INFO - 2018-08-20 22:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-20 22:58:13 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:13 --> Config Class Initialized
INFO - 2018-08-20 22:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-20 22:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-20 22:58:13 --> Utf8 Class Initialized
INFO - 2018-08-20 22:58:13 --> URI Class Initialized
INFO - 2018-08-20 22:58:13 --> Router Class Initialized
INFO - 2018-08-20 22:58:13 --> Output Class Initialized
INFO - 2018-08-20 22:58:13 --> Security Class Initialized
DEBUG - 2018-08-20 22:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-20 22:58:13 --> CSRF cookie sent
INFO - 2018-08-20 22:58:13 --> Input Class Initialized
INFO - 2018-08-20 22:58:13 --> Language Class Initialized
INFO - 2018-08-20 22:58:13 --> Loader Class Initialized
INFO - 2018-08-20 22:58:13 --> Helper loaded: url_helper
INFO - 2018-08-20 22:58:13 --> Helper loaded: form_helper
INFO - 2018-08-20 22:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-20 22:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-20 22:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-20 22:58:13 --> User Agent Class Initialized
INFO - 2018-08-20 22:58:13 --> Controller Class Initialized
INFO - 2018-08-20 22:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-20 22:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-20 22:58:13 --> Pixel_Model class loaded
INFO - 2018-08-20 22:58:13 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:13 --> Database Driver Class Initialized
INFO - 2018-08-20 22:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-20 22:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-20 22:58:13 --> Final output sent to browser
DEBUG - 2018-08-20 22:58:13 --> Total execution time: 0.0436

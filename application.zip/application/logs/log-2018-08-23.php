<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-23 12:47:17 --> Config Class Initialized
INFO - 2018-08-23 12:47:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:47:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:47:17 --> Utf8 Class Initialized
INFO - 2018-08-23 12:47:17 --> URI Class Initialized
DEBUG - 2018-08-23 12:47:17 --> No URI present. Default controller set.
INFO - 2018-08-23 12:47:17 --> Router Class Initialized
INFO - 2018-08-23 12:47:17 --> Output Class Initialized
INFO - 2018-08-23 12:47:17 --> Security Class Initialized
DEBUG - 2018-08-23 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:47:17 --> CSRF cookie sent
INFO - 2018-08-23 12:47:17 --> Input Class Initialized
INFO - 2018-08-23 12:47:17 --> Language Class Initialized
INFO - 2018-08-23 12:47:17 --> Loader Class Initialized
INFO - 2018-08-23 12:47:17 --> Helper loaded: url_helper
INFO - 2018-08-23 12:47:17 --> Helper loaded: form_helper
INFO - 2018-08-23 12:47:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:47:17 --> User Agent Class Initialized
INFO - 2018-08-23 12:47:17 --> Controller Class Initialized
INFO - 2018-08-23 12:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:47:17 --> Pixel_Model class loaded
INFO - 2018-08-23 12:47:17 --> Database Driver Class Initialized
INFO - 2018-08-23 12:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 12:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:47:17 --> Final output sent to browser
DEBUG - 2018-08-23 12:47:17 --> Total execution time: 0.0349
INFO - 2018-08-23 12:49:41 --> Config Class Initialized
INFO - 2018-08-23 12:49:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:49:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:49:41 --> Utf8 Class Initialized
INFO - 2018-08-23 12:49:41 --> URI Class Initialized
INFO - 2018-08-23 12:49:41 --> Router Class Initialized
INFO - 2018-08-23 12:49:41 --> Output Class Initialized
INFO - 2018-08-23 12:49:41 --> Security Class Initialized
DEBUG - 2018-08-23 12:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:49:41 --> CSRF cookie sent
INFO - 2018-08-23 12:49:41 --> Input Class Initialized
INFO - 2018-08-23 12:49:41 --> Language Class Initialized
INFO - 2018-08-23 12:49:41 --> Loader Class Initialized
INFO - 2018-08-23 12:49:41 --> Helper loaded: url_helper
INFO - 2018-08-23 12:49:41 --> Helper loaded: form_helper
INFO - 2018-08-23 12:49:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:49:41 --> User Agent Class Initialized
INFO - 2018-08-23 12:49:41 --> Controller Class Initialized
INFO - 2018-08-23 12:49:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:49:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:49:41 --> Pixel_Model class loaded
INFO - 2018-08-23 12:49:41 --> Database Driver Class Initialized
INFO - 2018-08-23 12:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-23 12:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:49:41 --> Final output sent to browser
DEBUG - 2018-08-23 12:49:41 --> Total execution time: 0.0505
INFO - 2018-08-23 12:53:17 --> Config Class Initialized
INFO - 2018-08-23 12:53:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:17 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:17 --> URI Class Initialized
INFO - 2018-08-23 12:53:17 --> Router Class Initialized
INFO - 2018-08-23 12:53:17 --> Output Class Initialized
INFO - 2018-08-23 12:53:17 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:17 --> CSRF cookie sent
INFO - 2018-08-23 12:53:17 --> CSRF token verified
INFO - 2018-08-23 12:53:17 --> Input Class Initialized
INFO - 2018-08-23 12:53:17 --> Language Class Initialized
INFO - 2018-08-23 12:53:17 --> Loader Class Initialized
INFO - 2018-08-23 12:53:17 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:17 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:17 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:17 --> Controller Class Initialized
INFO - 2018-08-23 12:53:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:17 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:17 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:17 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:17 --> Config Class Initialized
INFO - 2018-08-23 12:53:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:17 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:17 --> URI Class Initialized
INFO - 2018-08-23 12:53:17 --> Router Class Initialized
INFO - 2018-08-23 12:53:17 --> Output Class Initialized
INFO - 2018-08-23 12:53:17 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:17 --> CSRF cookie sent
INFO - 2018-08-23 12:53:17 --> Input Class Initialized
INFO - 2018-08-23 12:53:17 --> Language Class Initialized
INFO - 2018-08-23 12:53:17 --> Loader Class Initialized
INFO - 2018-08-23 12:53:17 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:17 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:17 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:17 --> Controller Class Initialized
INFO - 2018-08-23 12:53:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:17 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:17 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:17 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 12:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:53:17 --> Final output sent to browser
DEBUG - 2018-08-23 12:53:17 --> Total execution time: 0.0406
INFO - 2018-08-23 12:53:22 --> Config Class Initialized
INFO - 2018-08-23 12:53:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:22 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:22 --> URI Class Initialized
INFO - 2018-08-23 12:53:22 --> Router Class Initialized
INFO - 2018-08-23 12:53:22 --> Output Class Initialized
INFO - 2018-08-23 12:53:22 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:22 --> CSRF cookie sent
INFO - 2018-08-23 12:53:22 --> CSRF token verified
INFO - 2018-08-23 12:53:22 --> Input Class Initialized
INFO - 2018-08-23 12:53:22 --> Language Class Initialized
INFO - 2018-08-23 12:53:22 --> Loader Class Initialized
INFO - 2018-08-23 12:53:22 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:22 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:22 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:22 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:22 --> Controller Class Initialized
INFO - 2018-08-23 12:53:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:22 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:22 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:22 --> Form Validation Class Initialized
INFO - 2018-08-23 12:53:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:53:22 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:22 --> Config Class Initialized
INFO - 2018-08-23 12:53:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:22 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:22 --> URI Class Initialized
INFO - 2018-08-23 12:53:22 --> Router Class Initialized
INFO - 2018-08-23 12:53:22 --> Output Class Initialized
INFO - 2018-08-23 12:53:22 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:22 --> CSRF cookie sent
INFO - 2018-08-23 12:53:22 --> Input Class Initialized
INFO - 2018-08-23 12:53:22 --> Language Class Initialized
INFO - 2018-08-23 12:53:22 --> Loader Class Initialized
INFO - 2018-08-23 12:53:22 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:22 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:22 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:22 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:22 --> Controller Class Initialized
INFO - 2018-08-23 12:53:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:22 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:22 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:22 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-23 12:53:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:53:22 --> Final output sent to browser
DEBUG - 2018-08-23 12:53:22 --> Total execution time: 0.0451
INFO - 2018-08-23 12:53:29 --> Config Class Initialized
INFO - 2018-08-23 12:53:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:29 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:29 --> URI Class Initialized
INFO - 2018-08-23 12:53:29 --> Router Class Initialized
INFO - 2018-08-23 12:53:29 --> Output Class Initialized
INFO - 2018-08-23 12:53:29 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:29 --> CSRF cookie sent
INFO - 2018-08-23 12:53:29 --> CSRF token verified
INFO - 2018-08-23 12:53:29 --> Input Class Initialized
INFO - 2018-08-23 12:53:29 --> Language Class Initialized
INFO - 2018-08-23 12:53:29 --> Loader Class Initialized
INFO - 2018-08-23 12:53:29 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:29 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:29 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:29 --> Controller Class Initialized
INFO - 2018-08-23 12:53:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:29 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:29 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:29 --> Form Validation Class Initialized
INFO - 2018-08-23 12:53:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:53:29 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:29 --> Config Class Initialized
INFO - 2018-08-23 12:53:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:29 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:29 --> URI Class Initialized
INFO - 2018-08-23 12:53:29 --> Router Class Initialized
INFO - 2018-08-23 12:53:29 --> Output Class Initialized
INFO - 2018-08-23 12:53:29 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:29 --> CSRF cookie sent
INFO - 2018-08-23 12:53:29 --> Input Class Initialized
INFO - 2018-08-23 12:53:29 --> Language Class Initialized
INFO - 2018-08-23 12:53:29 --> Loader Class Initialized
INFO - 2018-08-23 12:53:29 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:29 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:29 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:29 --> Controller Class Initialized
INFO - 2018-08-23 12:53:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:29 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:29 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:29 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 12:53:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:53:29 --> Final output sent to browser
DEBUG - 2018-08-23 12:53:29 --> Total execution time: 0.0455
INFO - 2018-08-23 12:53:50 --> Config Class Initialized
INFO - 2018-08-23 12:53:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:50 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:50 --> URI Class Initialized
INFO - 2018-08-23 12:53:50 --> Router Class Initialized
INFO - 2018-08-23 12:53:50 --> Output Class Initialized
INFO - 2018-08-23 12:53:50 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:50 --> CSRF cookie sent
INFO - 2018-08-23 12:53:50 --> CSRF token verified
INFO - 2018-08-23 12:53:50 --> Input Class Initialized
INFO - 2018-08-23 12:53:50 --> Language Class Initialized
INFO - 2018-08-23 12:53:50 --> Loader Class Initialized
INFO - 2018-08-23 12:53:50 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:50 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:50 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:50 --> Controller Class Initialized
INFO - 2018-08-23 12:53:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:50 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:50 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:50 --> Form Validation Class Initialized
INFO - 2018-08-23 12:53:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:53:50 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:50 --> Config Class Initialized
INFO - 2018-08-23 12:53:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:50 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:50 --> URI Class Initialized
INFO - 2018-08-23 12:53:50 --> Router Class Initialized
INFO - 2018-08-23 12:53:50 --> Output Class Initialized
INFO - 2018-08-23 12:53:50 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:50 --> CSRF cookie sent
INFO - 2018-08-23 12:53:50 --> Input Class Initialized
INFO - 2018-08-23 12:53:50 --> Language Class Initialized
INFO - 2018-08-23 12:53:50 --> Loader Class Initialized
INFO - 2018-08-23 12:53:50 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:50 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:50 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:50 --> Controller Class Initialized
INFO - 2018-08-23 12:53:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:50 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:50 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:50 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 12:53:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:53:50 --> Final output sent to browser
DEBUG - 2018-08-23 12:53:50 --> Total execution time: 0.0385
INFO - 2018-08-23 12:53:57 --> Config Class Initialized
INFO - 2018-08-23 12:53:57 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:57 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:57 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:57 --> URI Class Initialized
INFO - 2018-08-23 12:53:57 --> Router Class Initialized
INFO - 2018-08-23 12:53:57 --> Output Class Initialized
INFO - 2018-08-23 12:53:57 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:57 --> CSRF cookie sent
INFO - 2018-08-23 12:53:57 --> CSRF token verified
INFO - 2018-08-23 12:53:57 --> Input Class Initialized
INFO - 2018-08-23 12:53:57 --> Language Class Initialized
INFO - 2018-08-23 12:53:57 --> Loader Class Initialized
INFO - 2018-08-23 12:53:57 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:57 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:57 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:57 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:57 --> Controller Class Initialized
INFO - 2018-08-23 12:53:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:57 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:57 --> Form Validation Class Initialized
INFO - 2018-08-23 12:53:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:57 --> Config Class Initialized
INFO - 2018-08-23 12:53:57 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:53:57 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:53:57 --> Utf8 Class Initialized
INFO - 2018-08-23 12:53:57 --> URI Class Initialized
INFO - 2018-08-23 12:53:57 --> Router Class Initialized
INFO - 2018-08-23 12:53:57 --> Output Class Initialized
INFO - 2018-08-23 12:53:57 --> Security Class Initialized
DEBUG - 2018-08-23 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:53:57 --> CSRF cookie sent
INFO - 2018-08-23 12:53:57 --> Input Class Initialized
INFO - 2018-08-23 12:53:57 --> Language Class Initialized
INFO - 2018-08-23 12:53:57 --> Loader Class Initialized
INFO - 2018-08-23 12:53:57 --> Helper loaded: url_helper
INFO - 2018-08-23 12:53:57 --> Helper loaded: form_helper
INFO - 2018-08-23 12:53:57 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:53:57 --> User Agent Class Initialized
INFO - 2018-08-23 12:53:57 --> Controller Class Initialized
INFO - 2018-08-23 12:53:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:53:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:53:57 --> Pixel_Model class loaded
INFO - 2018-08-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-08-23 12:53:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 12:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:53:57 --> Final output sent to browser
DEBUG - 2018-08-23 12:53:57 --> Total execution time: 0.0384
INFO - 2018-08-23 12:54:06 --> Config Class Initialized
INFO - 2018-08-23 12:54:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:54:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:54:06 --> Utf8 Class Initialized
INFO - 2018-08-23 12:54:06 --> URI Class Initialized
INFO - 2018-08-23 12:54:06 --> Router Class Initialized
INFO - 2018-08-23 12:54:06 --> Output Class Initialized
INFO - 2018-08-23 12:54:06 --> Security Class Initialized
DEBUG - 2018-08-23 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:54:06 --> CSRF cookie sent
INFO - 2018-08-23 12:54:06 --> CSRF token verified
INFO - 2018-08-23 12:54:06 --> Input Class Initialized
INFO - 2018-08-23 12:54:06 --> Language Class Initialized
INFO - 2018-08-23 12:54:06 --> Loader Class Initialized
INFO - 2018-08-23 12:54:06 --> Helper loaded: url_helper
INFO - 2018-08-23 12:54:06 --> Helper loaded: form_helper
INFO - 2018-08-23 12:54:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:54:06 --> User Agent Class Initialized
INFO - 2018-08-23 12:54:06 --> Controller Class Initialized
INFO - 2018-08-23 12:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:54:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:54:06 --> Pixel_Model class loaded
INFO - 2018-08-23 12:54:06 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:06 --> Form Validation Class Initialized
INFO - 2018-08-23 12:54:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:54:06 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:06 --> Config Class Initialized
INFO - 2018-08-23 12:54:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:54:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:54:06 --> Utf8 Class Initialized
INFO - 2018-08-23 12:54:06 --> URI Class Initialized
INFO - 2018-08-23 12:54:06 --> Router Class Initialized
INFO - 2018-08-23 12:54:06 --> Output Class Initialized
INFO - 2018-08-23 12:54:06 --> Security Class Initialized
DEBUG - 2018-08-23 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:54:06 --> CSRF cookie sent
INFO - 2018-08-23 12:54:06 --> Input Class Initialized
INFO - 2018-08-23 12:54:06 --> Language Class Initialized
INFO - 2018-08-23 12:54:06 --> Loader Class Initialized
INFO - 2018-08-23 12:54:06 --> Helper loaded: url_helper
INFO - 2018-08-23 12:54:06 --> Helper loaded: form_helper
INFO - 2018-08-23 12:54:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:54:06 --> User Agent Class Initialized
INFO - 2018-08-23 12:54:06 --> Controller Class Initialized
INFO - 2018-08-23 12:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:54:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:54:06 --> Pixel_Model class loaded
INFO - 2018-08-23 12:54:06 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:06 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 12:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:54:06 --> Final output sent to browser
DEBUG - 2018-08-23 12:54:06 --> Total execution time: 0.0359
INFO - 2018-08-23 12:54:44 --> Config Class Initialized
INFO - 2018-08-23 12:54:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:54:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:54:44 --> Utf8 Class Initialized
INFO - 2018-08-23 12:54:44 --> URI Class Initialized
INFO - 2018-08-23 12:54:44 --> Router Class Initialized
INFO - 2018-08-23 12:54:44 --> Output Class Initialized
INFO - 2018-08-23 12:54:44 --> Security Class Initialized
DEBUG - 2018-08-23 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:54:44 --> CSRF cookie sent
INFO - 2018-08-23 12:54:44 --> CSRF token verified
INFO - 2018-08-23 12:54:44 --> Input Class Initialized
INFO - 2018-08-23 12:54:44 --> Language Class Initialized
INFO - 2018-08-23 12:54:44 --> Loader Class Initialized
INFO - 2018-08-23 12:54:44 --> Helper loaded: url_helper
INFO - 2018-08-23 12:54:44 --> Helper loaded: form_helper
INFO - 2018-08-23 12:54:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:54:44 --> User Agent Class Initialized
INFO - 2018-08-23 12:54:44 --> Controller Class Initialized
INFO - 2018-08-23 12:54:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:54:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:54:44 --> Pixel_Model class loaded
INFO - 2018-08-23 12:54:44 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:44 --> Form Validation Class Initialized
INFO - 2018-08-23 12:54:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 12:54:44 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:44 --> Config Class Initialized
INFO - 2018-08-23 12:54:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:54:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:54:44 --> Utf8 Class Initialized
INFO - 2018-08-23 12:54:44 --> URI Class Initialized
INFO - 2018-08-23 12:54:44 --> Router Class Initialized
INFO - 2018-08-23 12:54:44 --> Output Class Initialized
INFO - 2018-08-23 12:54:44 --> Security Class Initialized
DEBUG - 2018-08-23 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:54:44 --> CSRF cookie sent
INFO - 2018-08-23 12:54:44 --> Input Class Initialized
INFO - 2018-08-23 12:54:44 --> Language Class Initialized
INFO - 2018-08-23 12:54:44 --> Loader Class Initialized
INFO - 2018-08-23 12:54:44 --> Helper loaded: url_helper
INFO - 2018-08-23 12:54:44 --> Helper loaded: form_helper
INFO - 2018-08-23 12:54:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:54:44 --> User Agent Class Initialized
INFO - 2018-08-23 12:54:44 --> Controller Class Initialized
INFO - 2018-08-23 12:54:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:54:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:54:44 --> Pixel_Model class loaded
INFO - 2018-08-23 12:54:44 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:44 --> Database Driver Class Initialized
INFO - 2018-08-23 12:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 12:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:54:44 --> Final output sent to browser
DEBUG - 2018-08-23 12:54:44 --> Total execution time: 0.0367
INFO - 2018-08-23 12:57:28 --> Config Class Initialized
INFO - 2018-08-23 12:57:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 12:57:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 12:57:28 --> Utf8 Class Initialized
INFO - 2018-08-23 12:57:28 --> URI Class Initialized
INFO - 2018-08-23 12:57:28 --> Router Class Initialized
INFO - 2018-08-23 12:57:28 --> Output Class Initialized
INFO - 2018-08-23 12:57:28 --> Security Class Initialized
DEBUG - 2018-08-23 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 12:57:28 --> CSRF cookie sent
INFO - 2018-08-23 12:57:28 --> Input Class Initialized
INFO - 2018-08-23 12:57:28 --> Language Class Initialized
INFO - 2018-08-23 12:57:28 --> Loader Class Initialized
INFO - 2018-08-23 12:57:28 --> Helper loaded: url_helper
INFO - 2018-08-23 12:57:28 --> Helper loaded: form_helper
INFO - 2018-08-23 12:57:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 12:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 12:57:28 --> User Agent Class Initialized
INFO - 2018-08-23 12:57:28 --> Controller Class Initialized
INFO - 2018-08-23 12:57:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 12:57:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 12:57:28 --> Pixel_Model class loaded
INFO - 2018-08-23 12:57:28 --> Database Driver Class Initialized
INFO - 2018-08-23 12:57:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:57:28 --> Database Driver Class Initialized
INFO - 2018-08-23 12:57:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 12:57:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 12:57:28 --> Final output sent to browser
DEBUG - 2018-08-23 12:57:28 --> Total execution time: 0.0429
INFO - 2018-08-23 13:18:07 --> Config Class Initialized
INFO - 2018-08-23 13:18:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:07 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:07 --> URI Class Initialized
INFO - 2018-08-23 13:18:07 --> Router Class Initialized
INFO - 2018-08-23 13:18:07 --> Output Class Initialized
INFO - 2018-08-23 13:18:07 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:07 --> CSRF cookie sent
INFO - 2018-08-23 13:18:07 --> CSRF token verified
INFO - 2018-08-23 13:18:07 --> Input Class Initialized
INFO - 2018-08-23 13:18:07 --> Language Class Initialized
INFO - 2018-08-23 13:18:07 --> Loader Class Initialized
INFO - 2018-08-23 13:18:07 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:07 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:07 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:07 --> Controller Class Initialized
INFO - 2018-08-23 13:18:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:07 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:07 --> Form Validation Class Initialized
INFO - 2018-08-23 13:18:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:18:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:07 --> Config Class Initialized
INFO - 2018-08-23 13:18:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:07 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:07 --> URI Class Initialized
INFO - 2018-08-23 13:18:07 --> Router Class Initialized
INFO - 2018-08-23 13:18:07 --> Output Class Initialized
INFO - 2018-08-23 13:18:07 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:07 --> CSRF cookie sent
INFO - 2018-08-23 13:18:07 --> Input Class Initialized
INFO - 2018-08-23 13:18:07 --> Language Class Initialized
INFO - 2018-08-23 13:18:07 --> Loader Class Initialized
INFO - 2018-08-23 13:18:07 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:07 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:07 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:07 --> Controller Class Initialized
INFO - 2018-08-23 13:18:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:07 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 13:18:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:07 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:07 --> Total execution time: 0.0455
INFO - 2018-08-23 13:18:15 --> Config Class Initialized
INFO - 2018-08-23 13:18:15 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:15 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:15 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:15 --> URI Class Initialized
INFO - 2018-08-23 13:18:15 --> Router Class Initialized
INFO - 2018-08-23 13:18:15 --> Output Class Initialized
INFO - 2018-08-23 13:18:15 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:15 --> CSRF cookie sent
INFO - 2018-08-23 13:18:15 --> CSRF token verified
INFO - 2018-08-23 13:18:15 --> Input Class Initialized
INFO - 2018-08-23 13:18:15 --> Language Class Initialized
INFO - 2018-08-23 13:18:15 --> Loader Class Initialized
INFO - 2018-08-23 13:18:15 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:15 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:15 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:15 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:15 --> Controller Class Initialized
INFO - 2018-08-23 13:18:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:15 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:15 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:15 --> Form Validation Class Initialized
INFO - 2018-08-23 13:18:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:18:15 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:15 --> Config Class Initialized
INFO - 2018-08-23 13:18:15 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:15 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:15 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:15 --> URI Class Initialized
INFO - 2018-08-23 13:18:15 --> Router Class Initialized
INFO - 2018-08-23 13:18:15 --> Output Class Initialized
INFO - 2018-08-23 13:18:15 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:15 --> CSRF cookie sent
INFO - 2018-08-23 13:18:15 --> Input Class Initialized
INFO - 2018-08-23 13:18:15 --> Language Class Initialized
INFO - 2018-08-23 13:18:15 --> Loader Class Initialized
INFO - 2018-08-23 13:18:15 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:15 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:15 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:15 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:15 --> Controller Class Initialized
INFO - 2018-08-23 13:18:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:15 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:15 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:15 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 13:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:15 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:15 --> Total execution time: 0.0442
INFO - 2018-08-23 13:18:34 --> Config Class Initialized
INFO - 2018-08-23 13:18:34 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:34 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:34 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:34 --> URI Class Initialized
INFO - 2018-08-23 13:18:34 --> Router Class Initialized
INFO - 2018-08-23 13:18:34 --> Output Class Initialized
INFO - 2018-08-23 13:18:34 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:34 --> CSRF cookie sent
INFO - 2018-08-23 13:18:34 --> Input Class Initialized
INFO - 2018-08-23 13:18:34 --> Language Class Initialized
INFO - 2018-08-23 13:18:34 --> Loader Class Initialized
INFO - 2018-08-23 13:18:34 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:34 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:34 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:34 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:34 --> Controller Class Initialized
INFO - 2018-08-23 13:18:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:34 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:34 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:34 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 13:18:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:34 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:34 --> Total execution time: 0.0466
INFO - 2018-08-23 13:18:37 --> Config Class Initialized
INFO - 2018-08-23 13:18:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:37 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:37 --> URI Class Initialized
INFO - 2018-08-23 13:18:37 --> Router Class Initialized
INFO - 2018-08-23 13:18:37 --> Output Class Initialized
INFO - 2018-08-23 13:18:37 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:37 --> CSRF cookie sent
INFO - 2018-08-23 13:18:37 --> CSRF token verified
INFO - 2018-08-23 13:18:37 --> Input Class Initialized
INFO - 2018-08-23 13:18:37 --> Language Class Initialized
INFO - 2018-08-23 13:18:37 --> Loader Class Initialized
INFO - 2018-08-23 13:18:37 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:37 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:37 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:37 --> Controller Class Initialized
INFO - 2018-08-23 13:18:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:37 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:37 --> Form Validation Class Initialized
INFO - 2018-08-23 13:18:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:18:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:37 --> Config Class Initialized
INFO - 2018-08-23 13:18:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:37 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:37 --> URI Class Initialized
INFO - 2018-08-23 13:18:37 --> Router Class Initialized
INFO - 2018-08-23 13:18:37 --> Output Class Initialized
INFO - 2018-08-23 13:18:37 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:37 --> CSRF cookie sent
INFO - 2018-08-23 13:18:37 --> Input Class Initialized
INFO - 2018-08-23 13:18:37 --> Language Class Initialized
INFO - 2018-08-23 13:18:37 --> Loader Class Initialized
INFO - 2018-08-23 13:18:37 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:37 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:37 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:37 --> Controller Class Initialized
INFO - 2018-08-23 13:18:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:37 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 13:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:37 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:37 --> Total execution time: 0.0436
INFO - 2018-08-23 13:18:47 --> Config Class Initialized
INFO - 2018-08-23 13:18:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:47 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:47 --> URI Class Initialized
INFO - 2018-08-23 13:18:47 --> Router Class Initialized
INFO - 2018-08-23 13:18:47 --> Output Class Initialized
INFO - 2018-08-23 13:18:47 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:47 --> CSRF cookie sent
INFO - 2018-08-23 13:18:47 --> CSRF token verified
INFO - 2018-08-23 13:18:47 --> Input Class Initialized
INFO - 2018-08-23 13:18:47 --> Language Class Initialized
INFO - 2018-08-23 13:18:47 --> Loader Class Initialized
INFO - 2018-08-23 13:18:47 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:47 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:47 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:47 --> Controller Class Initialized
INFO - 2018-08-23 13:18:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:47 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:47 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:47 --> Form Validation Class Initialized
INFO - 2018-08-23 13:18:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:18:47 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:47 --> Config Class Initialized
INFO - 2018-08-23 13:18:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:47 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:47 --> URI Class Initialized
INFO - 2018-08-23 13:18:47 --> Router Class Initialized
INFO - 2018-08-23 13:18:47 --> Output Class Initialized
INFO - 2018-08-23 13:18:47 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:47 --> CSRF cookie sent
INFO - 2018-08-23 13:18:47 --> Input Class Initialized
INFO - 2018-08-23 13:18:47 --> Language Class Initialized
INFO - 2018-08-23 13:18:47 --> Loader Class Initialized
INFO - 2018-08-23 13:18:47 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:47 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:47 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:47 --> Controller Class Initialized
INFO - 2018-08-23 13:18:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:47 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:47 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:47 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 13:18:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:47 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:47 --> Total execution time: 0.0483
INFO - 2018-08-23 13:18:50 --> Config Class Initialized
INFO - 2018-08-23 13:18:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:50 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:50 --> URI Class Initialized
INFO - 2018-08-23 13:18:50 --> Router Class Initialized
INFO - 2018-08-23 13:18:50 --> Output Class Initialized
INFO - 2018-08-23 13:18:50 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:50 --> CSRF cookie sent
INFO - 2018-08-23 13:18:50 --> CSRF token verified
INFO - 2018-08-23 13:18:50 --> Input Class Initialized
INFO - 2018-08-23 13:18:50 --> Language Class Initialized
INFO - 2018-08-23 13:18:50 --> Loader Class Initialized
INFO - 2018-08-23 13:18:50 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:50 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:50 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:50 --> Controller Class Initialized
INFO - 2018-08-23 13:18:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:50 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:50 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:50 --> Form Validation Class Initialized
INFO - 2018-08-23 13:18:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:18:50 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:50 --> Config Class Initialized
INFO - 2018-08-23 13:18:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:18:50 --> Utf8 Class Initialized
INFO - 2018-08-23 13:18:50 --> URI Class Initialized
INFO - 2018-08-23 13:18:50 --> Router Class Initialized
INFO - 2018-08-23 13:18:50 --> Output Class Initialized
INFO - 2018-08-23 13:18:50 --> Security Class Initialized
DEBUG - 2018-08-23 13:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:18:50 --> CSRF cookie sent
INFO - 2018-08-23 13:18:50 --> Input Class Initialized
INFO - 2018-08-23 13:18:50 --> Language Class Initialized
INFO - 2018-08-23 13:18:50 --> Loader Class Initialized
INFO - 2018-08-23 13:18:50 --> Helper loaded: url_helper
INFO - 2018-08-23 13:18:50 --> Helper loaded: form_helper
INFO - 2018-08-23 13:18:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:18:50 --> User Agent Class Initialized
INFO - 2018-08-23 13:18:50 --> Controller Class Initialized
INFO - 2018-08-23 13:18:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:18:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:18:50 --> Pixel_Model class loaded
INFO - 2018-08-23 13:18:50 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:50 --> Database Driver Class Initialized
INFO - 2018-08-23 13:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 13:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:18:50 --> Final output sent to browser
DEBUG - 2018-08-23 13:18:50 --> Total execution time: 0.0415
INFO - 2018-08-23 13:19:46 --> Config Class Initialized
INFO - 2018-08-23 13:19:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:19:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:19:46 --> Utf8 Class Initialized
INFO - 2018-08-23 13:19:46 --> URI Class Initialized
INFO - 2018-08-23 13:19:46 --> Router Class Initialized
INFO - 2018-08-23 13:19:46 --> Output Class Initialized
INFO - 2018-08-23 13:19:46 --> Security Class Initialized
DEBUG - 2018-08-23 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:19:46 --> CSRF cookie sent
INFO - 2018-08-23 13:19:46 --> CSRF token verified
INFO - 2018-08-23 13:19:46 --> Input Class Initialized
INFO - 2018-08-23 13:19:46 --> Language Class Initialized
INFO - 2018-08-23 13:19:46 --> Loader Class Initialized
INFO - 2018-08-23 13:19:46 --> Helper loaded: url_helper
INFO - 2018-08-23 13:19:46 --> Helper loaded: form_helper
INFO - 2018-08-23 13:19:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:19:46 --> User Agent Class Initialized
INFO - 2018-08-23 13:19:46 --> Controller Class Initialized
INFO - 2018-08-23 13:19:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:19:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:19:46 --> Pixel_Model class loaded
INFO - 2018-08-23 13:19:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:19:46 --> Form Validation Class Initialized
INFO - 2018-08-23 13:19:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:19:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:19:46 --> Config Class Initialized
INFO - 2018-08-23 13:19:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:19:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:19:46 --> Utf8 Class Initialized
INFO - 2018-08-23 13:19:46 --> URI Class Initialized
INFO - 2018-08-23 13:19:46 --> Router Class Initialized
INFO - 2018-08-23 13:19:46 --> Output Class Initialized
INFO - 2018-08-23 13:19:46 --> Security Class Initialized
DEBUG - 2018-08-23 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:19:46 --> CSRF cookie sent
INFO - 2018-08-23 13:19:46 --> Input Class Initialized
INFO - 2018-08-23 13:19:46 --> Language Class Initialized
INFO - 2018-08-23 13:19:46 --> Loader Class Initialized
INFO - 2018-08-23 13:19:46 --> Helper loaded: url_helper
INFO - 2018-08-23 13:19:46 --> Helper loaded: form_helper
INFO - 2018-08-23 13:19:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:19:46 --> User Agent Class Initialized
INFO - 2018-08-23 13:19:46 --> Controller Class Initialized
INFO - 2018-08-23 13:19:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:19:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:19:46 --> Pixel_Model class loaded
INFO - 2018-08-23 13:19:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:19:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:19:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 13:19:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:19:46 --> Final output sent to browser
DEBUG - 2018-08-23 13:19:46 --> Total execution time: 0.0492
INFO - 2018-08-23 13:20:53 --> Config Class Initialized
INFO - 2018-08-23 13:20:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:20:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:20:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:20:53 --> URI Class Initialized
INFO - 2018-08-23 13:20:53 --> Router Class Initialized
INFO - 2018-08-23 13:20:53 --> Output Class Initialized
INFO - 2018-08-23 13:20:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:20:53 --> CSRF cookie sent
INFO - 2018-08-23 13:20:53 --> CSRF token verified
INFO - 2018-08-23 13:20:53 --> Input Class Initialized
INFO - 2018-08-23 13:20:53 --> Language Class Initialized
INFO - 2018-08-23 13:20:53 --> Loader Class Initialized
INFO - 2018-08-23 13:20:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:20:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:20:53 --> Controller Class Initialized
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:20:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:20:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:20:53 --> Form Validation Class Initialized
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:20:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:20:53 --> Config Class Initialized
INFO - 2018-08-23 13:20:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:20:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:20:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:20:53 --> URI Class Initialized
INFO - 2018-08-23 13:20:53 --> Router Class Initialized
INFO - 2018-08-23 13:20:53 --> Output Class Initialized
INFO - 2018-08-23 13:20:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:20:53 --> CSRF cookie sent
INFO - 2018-08-23 13:20:53 --> Input Class Initialized
INFO - 2018-08-23 13:20:53 --> Language Class Initialized
INFO - 2018-08-23 13:20:53 --> Loader Class Initialized
INFO - 2018-08-23 13:20:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:20:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:20:53 --> Controller Class Initialized
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:20:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:20:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:20:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:20:53 --> Config Class Initialized
INFO - 2018-08-23 13:20:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:20:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:20:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:20:53 --> URI Class Initialized
INFO - 2018-08-23 13:20:53 --> Router Class Initialized
INFO - 2018-08-23 13:20:53 --> Output Class Initialized
INFO - 2018-08-23 13:20:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:20:53 --> CSRF cookie sent
INFO - 2018-08-23 13:20:53 --> Input Class Initialized
INFO - 2018-08-23 13:20:53 --> Language Class Initialized
INFO - 2018-08-23 13:20:53 --> Loader Class Initialized
INFO - 2018-08-23 13:20:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:20:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:20:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:20:53 --> Controller Class Initialized
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:20:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:20:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:20:53 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-23 13:20:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 13:20:53 --> Could not find the language line "req_email"
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-23 13:20:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:20:53 --> Final output sent to browser
DEBUG - 2018-08-23 13:20:53 --> Total execution time: 0.0349
INFO - 2018-08-23 13:21:53 --> Config Class Initialized
INFO - 2018-08-23 13:21:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:21:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:21:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:21:53 --> URI Class Initialized
INFO - 2018-08-23 13:21:53 --> Router Class Initialized
INFO - 2018-08-23 13:21:53 --> Output Class Initialized
INFO - 2018-08-23 13:21:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:21:53 --> CSRF cookie sent
INFO - 2018-08-23 13:21:53 --> Input Class Initialized
INFO - 2018-08-23 13:21:53 --> Language Class Initialized
INFO - 2018-08-23 13:21:53 --> Loader Class Initialized
INFO - 2018-08-23 13:21:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:21:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:21:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:21:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:21:53 --> Controller Class Initialized
INFO - 2018-08-23 13:21:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:21:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:21:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:21:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:21:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-23 13:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:21:53 --> Final output sent to browser
DEBUG - 2018-08-23 13:21:53 --> Total execution time: 0.0391
INFO - 2018-08-23 13:22:11 --> Config Class Initialized
INFO - 2018-08-23 13:22:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:11 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:11 --> URI Class Initialized
INFO - 2018-08-23 13:22:11 --> Router Class Initialized
INFO - 2018-08-23 13:22:11 --> Output Class Initialized
INFO - 2018-08-23 13:22:11 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:11 --> CSRF cookie sent
INFO - 2018-08-23 13:22:11 --> CSRF token verified
INFO - 2018-08-23 13:22:11 --> Input Class Initialized
INFO - 2018-08-23 13:22:11 --> Language Class Initialized
INFO - 2018-08-23 13:22:11 --> Loader Class Initialized
INFO - 2018-08-23 13:22:11 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:11 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:11 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:11 --> Controller Class Initialized
INFO - 2018-08-23 13:22:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:11 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:11 --> Config Class Initialized
INFO - 2018-08-23 13:22:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:11 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:11 --> URI Class Initialized
INFO - 2018-08-23 13:22:11 --> Router Class Initialized
INFO - 2018-08-23 13:22:11 --> Output Class Initialized
INFO - 2018-08-23 13:22:11 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:11 --> CSRF cookie sent
INFO - 2018-08-23 13:22:11 --> Input Class Initialized
INFO - 2018-08-23 13:22:11 --> Language Class Initialized
INFO - 2018-08-23 13:22:11 --> Loader Class Initialized
INFO - 2018-08-23 13:22:11 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:11 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:11 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:11 --> Controller Class Initialized
INFO - 2018-08-23 13:22:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:11 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 13:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:22:11 --> Final output sent to browser
DEBUG - 2018-08-23 13:22:11 --> Total execution time: 0.0579
INFO - 2018-08-23 13:22:14 --> Config Class Initialized
INFO - 2018-08-23 13:22:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:14 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:14 --> URI Class Initialized
INFO - 2018-08-23 13:22:14 --> Router Class Initialized
INFO - 2018-08-23 13:22:14 --> Output Class Initialized
INFO - 2018-08-23 13:22:14 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:14 --> CSRF cookie sent
INFO - 2018-08-23 13:22:14 --> CSRF token verified
INFO - 2018-08-23 13:22:14 --> Input Class Initialized
INFO - 2018-08-23 13:22:14 --> Language Class Initialized
INFO - 2018-08-23 13:22:14 --> Loader Class Initialized
INFO - 2018-08-23 13:22:14 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:14 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:14 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:14 --> Controller Class Initialized
INFO - 2018-08-23 13:22:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:14 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:14 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:14 --> Form Validation Class Initialized
INFO - 2018-08-23 13:22:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:22:14 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:14 --> Config Class Initialized
INFO - 2018-08-23 13:22:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:14 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:14 --> URI Class Initialized
INFO - 2018-08-23 13:22:14 --> Router Class Initialized
INFO - 2018-08-23 13:22:14 --> Output Class Initialized
INFO - 2018-08-23 13:22:14 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:14 --> CSRF cookie sent
INFO - 2018-08-23 13:22:14 --> Input Class Initialized
INFO - 2018-08-23 13:22:14 --> Language Class Initialized
INFO - 2018-08-23 13:22:14 --> Loader Class Initialized
INFO - 2018-08-23 13:22:14 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:14 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:14 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:14 --> Controller Class Initialized
INFO - 2018-08-23 13:22:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:14 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:14 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:14 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-23 13:22:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:22:14 --> Final output sent to browser
DEBUG - 2018-08-23 13:22:14 --> Total execution time: 0.0469
INFO - 2018-08-23 13:22:18 --> Config Class Initialized
INFO - 2018-08-23 13:22:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:18 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:18 --> URI Class Initialized
INFO - 2018-08-23 13:22:18 --> Router Class Initialized
INFO - 2018-08-23 13:22:18 --> Output Class Initialized
INFO - 2018-08-23 13:22:18 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:18 --> CSRF cookie sent
INFO - 2018-08-23 13:22:18 --> CSRF token verified
INFO - 2018-08-23 13:22:18 --> Input Class Initialized
INFO - 2018-08-23 13:22:18 --> Language Class Initialized
INFO - 2018-08-23 13:22:18 --> Loader Class Initialized
INFO - 2018-08-23 13:22:18 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:18 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:18 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:18 --> Controller Class Initialized
INFO - 2018-08-23 13:22:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:18 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:18 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:19 --> Form Validation Class Initialized
INFO - 2018-08-23 13:22:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:22:19 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:19 --> Config Class Initialized
INFO - 2018-08-23 13:22:19 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:19 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:19 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:19 --> URI Class Initialized
INFO - 2018-08-23 13:22:19 --> Router Class Initialized
INFO - 2018-08-23 13:22:19 --> Output Class Initialized
INFO - 2018-08-23 13:22:19 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:19 --> CSRF cookie sent
INFO - 2018-08-23 13:22:19 --> Input Class Initialized
INFO - 2018-08-23 13:22:19 --> Language Class Initialized
INFO - 2018-08-23 13:22:19 --> Loader Class Initialized
INFO - 2018-08-23 13:22:19 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:19 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:19 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:19 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:19 --> Controller Class Initialized
INFO - 2018-08-23 13:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:19 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:19 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:19 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 13:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:22:19 --> Final output sent to browser
DEBUG - 2018-08-23 13:22:19 --> Total execution time: 0.0389
INFO - 2018-08-23 13:22:22 --> Config Class Initialized
INFO - 2018-08-23 13:22:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:22 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:22 --> URI Class Initialized
INFO - 2018-08-23 13:22:22 --> Router Class Initialized
INFO - 2018-08-23 13:22:22 --> Output Class Initialized
INFO - 2018-08-23 13:22:22 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:22 --> CSRF cookie sent
INFO - 2018-08-23 13:22:22 --> CSRF token verified
INFO - 2018-08-23 13:22:22 --> Input Class Initialized
INFO - 2018-08-23 13:22:22 --> Language Class Initialized
INFO - 2018-08-23 13:22:22 --> Loader Class Initialized
INFO - 2018-08-23 13:22:22 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:22 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:22 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:22 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:22 --> Controller Class Initialized
INFO - 2018-08-23 13:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:22 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:22 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:22 --> Form Validation Class Initialized
INFO - 2018-08-23 13:22:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:22:22 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:22 --> Config Class Initialized
INFO - 2018-08-23 13:22:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:22 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:22 --> URI Class Initialized
INFO - 2018-08-23 13:22:22 --> Router Class Initialized
INFO - 2018-08-23 13:22:22 --> Output Class Initialized
INFO - 2018-08-23 13:22:22 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:22 --> CSRF cookie sent
INFO - 2018-08-23 13:22:22 --> Input Class Initialized
INFO - 2018-08-23 13:22:22 --> Language Class Initialized
INFO - 2018-08-23 13:22:22 --> Loader Class Initialized
INFO - 2018-08-23 13:22:22 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:22 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:22 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:22 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:22 --> Controller Class Initialized
INFO - 2018-08-23 13:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:22 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:22 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:22 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:22:22 --> Final output sent to browser
DEBUG - 2018-08-23 13:22:22 --> Total execution time: 0.0386
INFO - 2018-08-23 13:22:53 --> Config Class Initialized
INFO - 2018-08-23 13:22:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:53 --> URI Class Initialized
INFO - 2018-08-23 13:22:53 --> Router Class Initialized
INFO - 2018-08-23 13:22:53 --> Output Class Initialized
INFO - 2018-08-23 13:22:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:53 --> CSRF cookie sent
INFO - 2018-08-23 13:22:53 --> CSRF token verified
INFO - 2018-08-23 13:22:53 --> Input Class Initialized
INFO - 2018-08-23 13:22:53 --> Language Class Initialized
INFO - 2018-08-23 13:22:53 --> Loader Class Initialized
INFO - 2018-08-23 13:22:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:53 --> Controller Class Initialized
INFO - 2018-08-23 13:22:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:53 --> Form Validation Class Initialized
INFO - 2018-08-23 13:22:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:22:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:53 --> Config Class Initialized
INFO - 2018-08-23 13:22:53 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:22:53 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:22:53 --> Utf8 Class Initialized
INFO - 2018-08-23 13:22:53 --> URI Class Initialized
INFO - 2018-08-23 13:22:53 --> Router Class Initialized
INFO - 2018-08-23 13:22:53 --> Output Class Initialized
INFO - 2018-08-23 13:22:53 --> Security Class Initialized
DEBUG - 2018-08-23 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:22:53 --> CSRF cookie sent
INFO - 2018-08-23 13:22:53 --> Input Class Initialized
INFO - 2018-08-23 13:22:53 --> Language Class Initialized
INFO - 2018-08-23 13:22:53 --> Loader Class Initialized
INFO - 2018-08-23 13:22:53 --> Helper loaded: url_helper
INFO - 2018-08-23 13:22:53 --> Helper loaded: form_helper
INFO - 2018-08-23 13:22:53 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:22:53 --> User Agent Class Initialized
INFO - 2018-08-23 13:22:53 --> Controller Class Initialized
INFO - 2018-08-23 13:22:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:22:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:22:53 --> Pixel_Model class loaded
INFO - 2018-08-23 13:22:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:53 --> Database Driver Class Initialized
INFO - 2018-08-23 13:22:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 13:22:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:22:53 --> Final output sent to browser
DEBUG - 2018-08-23 13:22:53 --> Total execution time: 0.0415
INFO - 2018-08-23 13:23:07 --> Config Class Initialized
INFO - 2018-08-23 13:23:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:23:07 --> Utf8 Class Initialized
INFO - 2018-08-23 13:23:07 --> URI Class Initialized
INFO - 2018-08-23 13:23:07 --> Router Class Initialized
INFO - 2018-08-23 13:23:07 --> Output Class Initialized
INFO - 2018-08-23 13:23:07 --> Security Class Initialized
DEBUG - 2018-08-23 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:23:07 --> CSRF cookie sent
INFO - 2018-08-23 13:23:07 --> CSRF token verified
INFO - 2018-08-23 13:23:07 --> Input Class Initialized
INFO - 2018-08-23 13:23:07 --> Language Class Initialized
INFO - 2018-08-23 13:23:07 --> Loader Class Initialized
INFO - 2018-08-23 13:23:07 --> Helper loaded: url_helper
INFO - 2018-08-23 13:23:07 --> Helper loaded: form_helper
INFO - 2018-08-23 13:23:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:23:07 --> User Agent Class Initialized
INFO - 2018-08-23 13:23:07 --> Controller Class Initialized
INFO - 2018-08-23 13:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:23:07 --> Pixel_Model class loaded
INFO - 2018-08-23 13:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:07 --> Form Validation Class Initialized
INFO - 2018-08-23 13:23:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:07 --> Config Class Initialized
INFO - 2018-08-23 13:23:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:23:07 --> Utf8 Class Initialized
INFO - 2018-08-23 13:23:07 --> URI Class Initialized
INFO - 2018-08-23 13:23:07 --> Router Class Initialized
INFO - 2018-08-23 13:23:07 --> Output Class Initialized
INFO - 2018-08-23 13:23:07 --> Security Class Initialized
DEBUG - 2018-08-23 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:23:07 --> CSRF cookie sent
INFO - 2018-08-23 13:23:07 --> Input Class Initialized
INFO - 2018-08-23 13:23:07 --> Language Class Initialized
INFO - 2018-08-23 13:23:07 --> Loader Class Initialized
INFO - 2018-08-23 13:23:07 --> Helper loaded: url_helper
INFO - 2018-08-23 13:23:07 --> Helper loaded: form_helper
INFO - 2018-08-23 13:23:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:23:07 --> User Agent Class Initialized
INFO - 2018-08-23 13:23:07 --> Controller Class Initialized
INFO - 2018-08-23 13:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:23:07 --> Pixel_Model class loaded
INFO - 2018-08-23 13:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:23:07 --> Final output sent to browser
DEBUG - 2018-08-23 13:23:07 --> Total execution time: 0.0458
INFO - 2018-08-23 13:23:24 --> Config Class Initialized
INFO - 2018-08-23 13:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:23:24 --> Utf8 Class Initialized
INFO - 2018-08-23 13:23:24 --> URI Class Initialized
INFO - 2018-08-23 13:23:24 --> Router Class Initialized
INFO - 2018-08-23 13:23:24 --> Output Class Initialized
INFO - 2018-08-23 13:23:24 --> Security Class Initialized
DEBUG - 2018-08-23 13:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:23:24 --> CSRF cookie sent
INFO - 2018-08-23 13:23:24 --> CSRF token verified
INFO - 2018-08-23 13:23:24 --> Input Class Initialized
INFO - 2018-08-23 13:23:24 --> Language Class Initialized
INFO - 2018-08-23 13:23:24 --> Loader Class Initialized
INFO - 2018-08-23 13:23:24 --> Helper loaded: url_helper
INFO - 2018-08-23 13:23:24 --> Helper loaded: form_helper
INFO - 2018-08-23 13:23:24 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:23:24 --> User Agent Class Initialized
INFO - 2018-08-23 13:23:24 --> Controller Class Initialized
INFO - 2018-08-23 13:23:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:23:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:23:24 --> Pixel_Model class loaded
INFO - 2018-08-23 13:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:24 --> Form Validation Class Initialized
INFO - 2018-08-23 13:23:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:24 --> Config Class Initialized
INFO - 2018-08-23 13:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:23:25 --> Utf8 Class Initialized
INFO - 2018-08-23 13:23:25 --> URI Class Initialized
INFO - 2018-08-23 13:23:25 --> Router Class Initialized
INFO - 2018-08-23 13:23:25 --> Output Class Initialized
INFO - 2018-08-23 13:23:25 --> Security Class Initialized
DEBUG - 2018-08-23 13:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:23:25 --> CSRF cookie sent
INFO - 2018-08-23 13:23:25 --> Input Class Initialized
INFO - 2018-08-23 13:23:25 --> Language Class Initialized
INFO - 2018-08-23 13:23:25 --> Loader Class Initialized
INFO - 2018-08-23 13:23:25 --> Helper loaded: url_helper
INFO - 2018-08-23 13:23:25 --> Helper loaded: form_helper
INFO - 2018-08-23 13:23:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:23:25 --> User Agent Class Initialized
INFO - 2018-08-23 13:23:25 --> Controller Class Initialized
INFO - 2018-08-23 13:23:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:23:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:23:25 --> Pixel_Model class loaded
INFO - 2018-08-23 13:23:25 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:25 --> Database Driver Class Initialized
INFO - 2018-08-23 13:23:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 13:23:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:23:25 --> Final output sent to browser
DEBUG - 2018-08-23 13:23:25 --> Total execution time: 0.0486
INFO - 2018-08-23 13:25:02 --> Config Class Initialized
INFO - 2018-08-23 13:25:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:25:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:25:02 --> Utf8 Class Initialized
INFO - 2018-08-23 13:25:02 --> URI Class Initialized
INFO - 2018-08-23 13:25:02 --> Router Class Initialized
INFO - 2018-08-23 13:25:02 --> Output Class Initialized
INFO - 2018-08-23 13:25:02 --> Security Class Initialized
DEBUG - 2018-08-23 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:25:02 --> CSRF cookie sent
INFO - 2018-08-23 13:25:02 --> CSRF token verified
INFO - 2018-08-23 13:25:02 --> Input Class Initialized
INFO - 2018-08-23 13:25:02 --> Language Class Initialized
INFO - 2018-08-23 13:25:02 --> Loader Class Initialized
INFO - 2018-08-23 13:25:02 --> Helper loaded: url_helper
INFO - 2018-08-23 13:25:02 --> Helper loaded: form_helper
INFO - 2018-08-23 13:25:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:25:02 --> User Agent Class Initialized
INFO - 2018-08-23 13:25:02 --> Controller Class Initialized
INFO - 2018-08-23 13:25:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:25:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:25:02 --> Pixel_Model class loaded
INFO - 2018-08-23 13:25:02 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:02 --> Form Validation Class Initialized
INFO - 2018-08-23 13:25:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:25:02 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:02 --> Config Class Initialized
INFO - 2018-08-23 13:25:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:25:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:25:02 --> Utf8 Class Initialized
INFO - 2018-08-23 13:25:02 --> URI Class Initialized
INFO - 2018-08-23 13:25:02 --> Router Class Initialized
INFO - 2018-08-23 13:25:02 --> Output Class Initialized
INFO - 2018-08-23 13:25:02 --> Security Class Initialized
DEBUG - 2018-08-23 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:25:02 --> CSRF cookie sent
INFO - 2018-08-23 13:25:02 --> Input Class Initialized
INFO - 2018-08-23 13:25:02 --> Language Class Initialized
INFO - 2018-08-23 13:25:02 --> Loader Class Initialized
INFO - 2018-08-23 13:25:02 --> Helper loaded: url_helper
INFO - 2018-08-23 13:25:02 --> Helper loaded: form_helper
INFO - 2018-08-23 13:25:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:25:02 --> User Agent Class Initialized
INFO - 2018-08-23 13:25:02 --> Controller Class Initialized
INFO - 2018-08-23 13:25:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:25:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:25:02 --> Pixel_Model class loaded
INFO - 2018-08-23 13:25:02 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:02 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 13:25:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:25:02 --> Final output sent to browser
DEBUG - 2018-08-23 13:25:02 --> Total execution time: 0.0445
INFO - 2018-08-23 13:25:42 --> Config Class Initialized
INFO - 2018-08-23 13:25:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:25:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:25:42 --> Utf8 Class Initialized
INFO - 2018-08-23 13:25:42 --> URI Class Initialized
INFO - 2018-08-23 13:25:42 --> Router Class Initialized
INFO - 2018-08-23 13:25:42 --> Output Class Initialized
INFO - 2018-08-23 13:25:42 --> Security Class Initialized
DEBUG - 2018-08-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:25:42 --> CSRF cookie sent
INFO - 2018-08-23 13:25:42 --> Input Class Initialized
INFO - 2018-08-23 13:25:42 --> Language Class Initialized
INFO - 2018-08-23 13:25:42 --> Loader Class Initialized
INFO - 2018-08-23 13:25:42 --> Helper loaded: url_helper
INFO - 2018-08-23 13:25:42 --> Helper loaded: form_helper
INFO - 2018-08-23 13:25:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:25:42 --> User Agent Class Initialized
INFO - 2018-08-23 13:25:42 --> Controller Class Initialized
INFO - 2018-08-23 13:25:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:25:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:25:42 --> Pixel_Model class loaded
INFO - 2018-08-23 13:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 13:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:25:42 --> Final output sent to browser
DEBUG - 2018-08-23 13:25:42 --> Total execution time: 0.0581
INFO - 2018-08-23 13:26:05 --> Config Class Initialized
INFO - 2018-08-23 13:26:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:26:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:26:05 --> Utf8 Class Initialized
INFO - 2018-08-23 13:26:05 --> URI Class Initialized
INFO - 2018-08-23 13:26:05 --> Router Class Initialized
INFO - 2018-08-23 13:26:05 --> Output Class Initialized
INFO - 2018-08-23 13:26:05 --> Security Class Initialized
DEBUG - 2018-08-23 13:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:26:05 --> CSRF cookie sent
INFO - 2018-08-23 13:26:05 --> CSRF token verified
INFO - 2018-08-23 13:26:05 --> Input Class Initialized
INFO - 2018-08-23 13:26:05 --> Language Class Initialized
INFO - 2018-08-23 13:26:05 --> Loader Class Initialized
INFO - 2018-08-23 13:26:05 --> Helper loaded: url_helper
INFO - 2018-08-23 13:26:05 --> Helper loaded: form_helper
INFO - 2018-08-23 13:26:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:26:05 --> User Agent Class Initialized
INFO - 2018-08-23 13:26:05 --> Controller Class Initialized
INFO - 2018-08-23 13:26:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:26:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:26:05 --> Pixel_Model class loaded
INFO - 2018-08-23 13:26:05 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:05 --> Form Validation Class Initialized
INFO - 2018-08-23 13:26:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:26:05 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:05 --> Config Class Initialized
INFO - 2018-08-23 13:26:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:26:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:26:05 --> Utf8 Class Initialized
INFO - 2018-08-23 13:26:05 --> URI Class Initialized
INFO - 2018-08-23 13:26:05 --> Router Class Initialized
INFO - 2018-08-23 13:26:05 --> Output Class Initialized
INFO - 2018-08-23 13:26:05 --> Security Class Initialized
DEBUG - 2018-08-23 13:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:26:05 --> CSRF cookie sent
INFO - 2018-08-23 13:26:05 --> Input Class Initialized
INFO - 2018-08-23 13:26:05 --> Language Class Initialized
INFO - 2018-08-23 13:26:05 --> Loader Class Initialized
INFO - 2018-08-23 13:26:05 --> Helper loaded: url_helper
INFO - 2018-08-23 13:26:05 --> Helper loaded: form_helper
INFO - 2018-08-23 13:26:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:26:05 --> User Agent Class Initialized
INFO - 2018-08-23 13:26:05 --> Controller Class Initialized
INFO - 2018-08-23 13:26:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:26:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:26:05 --> Pixel_Model class loaded
INFO - 2018-08-23 13:26:05 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:05 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 13:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:26:05 --> Final output sent to browser
DEBUG - 2018-08-23 13:26:05 --> Total execution time: 0.0553
INFO - 2018-08-23 13:26:39 --> Config Class Initialized
INFO - 2018-08-23 13:26:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:26:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:26:39 --> Utf8 Class Initialized
INFO - 2018-08-23 13:26:39 --> URI Class Initialized
INFO - 2018-08-23 13:26:39 --> Router Class Initialized
INFO - 2018-08-23 13:26:39 --> Output Class Initialized
INFO - 2018-08-23 13:26:39 --> Security Class Initialized
DEBUG - 2018-08-23 13:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:26:39 --> CSRF cookie sent
INFO - 2018-08-23 13:26:39 --> CSRF token verified
INFO - 2018-08-23 13:26:39 --> Input Class Initialized
INFO - 2018-08-23 13:26:39 --> Language Class Initialized
INFO - 2018-08-23 13:26:39 --> Loader Class Initialized
INFO - 2018-08-23 13:26:39 --> Helper loaded: url_helper
INFO - 2018-08-23 13:26:39 --> Helper loaded: form_helper
INFO - 2018-08-23 13:26:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:26:39 --> User Agent Class Initialized
INFO - 2018-08-23 13:26:39 --> Controller Class Initialized
INFO - 2018-08-23 13:26:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:26:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:26:39 --> Pixel_Model class loaded
INFO - 2018-08-23 13:26:39 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:39 --> Form Validation Class Initialized
INFO - 2018-08-23 13:26:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:26:39 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:39 --> Config Class Initialized
INFO - 2018-08-23 13:26:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:26:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:26:39 --> Utf8 Class Initialized
INFO - 2018-08-23 13:26:39 --> URI Class Initialized
INFO - 2018-08-23 13:26:39 --> Router Class Initialized
INFO - 2018-08-23 13:26:39 --> Output Class Initialized
INFO - 2018-08-23 13:26:39 --> Security Class Initialized
DEBUG - 2018-08-23 13:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:26:39 --> CSRF cookie sent
INFO - 2018-08-23 13:26:39 --> Input Class Initialized
INFO - 2018-08-23 13:26:39 --> Language Class Initialized
INFO - 2018-08-23 13:26:39 --> Loader Class Initialized
INFO - 2018-08-23 13:26:39 --> Helper loaded: url_helper
INFO - 2018-08-23 13:26:39 --> Helper loaded: form_helper
INFO - 2018-08-23 13:26:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:26:39 --> User Agent Class Initialized
INFO - 2018-08-23 13:26:39 --> Controller Class Initialized
INFO - 2018-08-23 13:26:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:26:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:26:39 --> Pixel_Model class loaded
INFO - 2018-08-23 13:26:39 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:39 --> Database Driver Class Initialized
INFO - 2018-08-23 13:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 13:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:26:39 --> Final output sent to browser
DEBUG - 2018-08-23 13:26:39 --> Total execution time: 0.0469
INFO - 2018-08-23 13:27:00 --> Config Class Initialized
INFO - 2018-08-23 13:27:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:00 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:00 --> URI Class Initialized
INFO - 2018-08-23 13:27:00 --> Router Class Initialized
INFO - 2018-08-23 13:27:00 --> Output Class Initialized
INFO - 2018-08-23 13:27:00 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:00 --> CSRF cookie sent
INFO - 2018-08-23 13:27:00 --> CSRF token verified
INFO - 2018-08-23 13:27:00 --> Input Class Initialized
INFO - 2018-08-23 13:27:00 --> Language Class Initialized
INFO - 2018-08-23 13:27:00 --> Loader Class Initialized
INFO - 2018-08-23 13:27:00 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:00 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:00 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:00 --> Controller Class Initialized
INFO - 2018-08-23 13:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:00 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:00 --> Form Validation Class Initialized
INFO - 2018-08-23 13:27:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:00 --> Config Class Initialized
INFO - 2018-08-23 13:27:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:00 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:00 --> URI Class Initialized
INFO - 2018-08-23 13:27:00 --> Router Class Initialized
INFO - 2018-08-23 13:27:00 --> Output Class Initialized
INFO - 2018-08-23 13:27:00 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:00 --> CSRF cookie sent
INFO - 2018-08-23 13:27:00 --> Input Class Initialized
INFO - 2018-08-23 13:27:00 --> Language Class Initialized
INFO - 2018-08-23 13:27:00 --> Loader Class Initialized
INFO - 2018-08-23 13:27:00 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:00 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:00 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:00 --> Controller Class Initialized
INFO - 2018-08-23 13:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:00 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 13:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:27:00 --> Final output sent to browser
DEBUG - 2018-08-23 13:27:00 --> Total execution time: 0.0462
INFO - 2018-08-23 13:27:08 --> Config Class Initialized
INFO - 2018-08-23 13:27:08 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:08 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:08 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:08 --> URI Class Initialized
INFO - 2018-08-23 13:27:08 --> Router Class Initialized
INFO - 2018-08-23 13:27:08 --> Output Class Initialized
INFO - 2018-08-23 13:27:08 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:08 --> CSRF cookie sent
INFO - 2018-08-23 13:27:08 --> CSRF token verified
INFO - 2018-08-23 13:27:08 --> Input Class Initialized
INFO - 2018-08-23 13:27:08 --> Language Class Initialized
INFO - 2018-08-23 13:27:08 --> Loader Class Initialized
INFO - 2018-08-23 13:27:08 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:08 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:08 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:08 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:08 --> Controller Class Initialized
INFO - 2018-08-23 13:27:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:08 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:08 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:08 --> Form Validation Class Initialized
INFO - 2018-08-23 13:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:27:08 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:08 --> Config Class Initialized
INFO - 2018-08-23 13:27:08 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:08 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:08 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:08 --> URI Class Initialized
INFO - 2018-08-23 13:27:08 --> Router Class Initialized
INFO - 2018-08-23 13:27:08 --> Output Class Initialized
INFO - 2018-08-23 13:27:08 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:08 --> CSRF cookie sent
INFO - 2018-08-23 13:27:08 --> Input Class Initialized
INFO - 2018-08-23 13:27:08 --> Language Class Initialized
INFO - 2018-08-23 13:27:08 --> Loader Class Initialized
INFO - 2018-08-23 13:27:08 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:08 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:08 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:08 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:08 --> Controller Class Initialized
INFO - 2018-08-23 13:27:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:08 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:08 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:08 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/coh_home_title.php
INFO - 2018-08-23 13:27:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:27:08 --> Final output sent to browser
DEBUG - 2018-08-23 13:27:08 --> Total execution time: 0.0453
INFO - 2018-08-23 13:27:41 --> Config Class Initialized
INFO - 2018-08-23 13:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:41 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:41 --> URI Class Initialized
INFO - 2018-08-23 13:27:41 --> Router Class Initialized
INFO - 2018-08-23 13:27:41 --> Output Class Initialized
INFO - 2018-08-23 13:27:41 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:41 --> CSRF cookie sent
INFO - 2018-08-23 13:27:41 --> CSRF token verified
INFO - 2018-08-23 13:27:41 --> Input Class Initialized
INFO - 2018-08-23 13:27:41 --> Language Class Initialized
INFO - 2018-08-23 13:27:41 --> Loader Class Initialized
INFO - 2018-08-23 13:27:41 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:41 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:41 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:41 --> Controller Class Initialized
INFO - 2018-08-23 13:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:41 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:41 --> Form Validation Class Initialized
INFO - 2018-08-23 13:27:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:41 --> Config Class Initialized
INFO - 2018-08-23 13:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:41 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:41 --> URI Class Initialized
INFO - 2018-08-23 13:27:41 --> Router Class Initialized
INFO - 2018-08-23 13:27:41 --> Output Class Initialized
INFO - 2018-08-23 13:27:41 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:41 --> CSRF cookie sent
INFO - 2018-08-23 13:27:41 --> Input Class Initialized
INFO - 2018-08-23 13:27:41 --> Language Class Initialized
INFO - 2018-08-23 13:27:41 --> Loader Class Initialized
INFO - 2018-08-23 13:27:41 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:41 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:41 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:41 --> Controller Class Initialized
INFO - 2018-08-23 13:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:41 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 13:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:27:41 --> Final output sent to browser
DEBUG - 2018-08-23 13:27:41 --> Total execution time: 0.0622
INFO - 2018-08-23 13:27:55 --> Config Class Initialized
INFO - 2018-08-23 13:27:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:55 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:55 --> URI Class Initialized
INFO - 2018-08-23 13:27:55 --> Router Class Initialized
INFO - 2018-08-23 13:27:55 --> Output Class Initialized
INFO - 2018-08-23 13:27:55 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:55 --> CSRF cookie sent
INFO - 2018-08-23 13:27:55 --> CSRF token verified
INFO - 2018-08-23 13:27:55 --> Input Class Initialized
INFO - 2018-08-23 13:27:55 --> Language Class Initialized
INFO - 2018-08-23 13:27:55 --> Loader Class Initialized
INFO - 2018-08-23 13:27:55 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:55 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:55 --> Controller Class Initialized
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:55 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:55 --> Form Validation Class Initialized
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:27:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:55 --> Config Class Initialized
INFO - 2018-08-23 13:27:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:55 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:55 --> URI Class Initialized
INFO - 2018-08-23 13:27:55 --> Router Class Initialized
INFO - 2018-08-23 13:27:55 --> Output Class Initialized
INFO - 2018-08-23 13:27:55 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:55 --> CSRF cookie sent
INFO - 2018-08-23 13:27:55 --> Input Class Initialized
INFO - 2018-08-23 13:27:55 --> Language Class Initialized
INFO - 2018-08-23 13:27:55 --> Loader Class Initialized
INFO - 2018-08-23 13:27:55 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:55 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:55 --> Controller Class Initialized
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:55 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:27:55 --> Config Class Initialized
INFO - 2018-08-23 13:27:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:27:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:27:55 --> Utf8 Class Initialized
INFO - 2018-08-23 13:27:55 --> URI Class Initialized
INFO - 2018-08-23 13:27:55 --> Router Class Initialized
INFO - 2018-08-23 13:27:55 --> Output Class Initialized
INFO - 2018-08-23 13:27:55 --> Security Class Initialized
DEBUG - 2018-08-23 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:27:55 --> CSRF cookie sent
INFO - 2018-08-23 13:27:55 --> Input Class Initialized
INFO - 2018-08-23 13:27:55 --> Language Class Initialized
INFO - 2018-08-23 13:27:55 --> Loader Class Initialized
INFO - 2018-08-23 13:27:55 --> Helper loaded: url_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: form_helper
INFO - 2018-08-23 13:27:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:27:55 --> User Agent Class Initialized
INFO - 2018-08-23 13:27:55 --> Controller Class Initialized
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:27:55 --> Pixel_Model class loaded
INFO - 2018-08-23 13:27:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:27:55 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-23 13:27:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 13:27:55 --> Could not find the language line "req_email"
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-23 13:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:27:55 --> Final output sent to browser
DEBUG - 2018-08-23 13:27:55 --> Total execution time: 0.0356
INFO - 2018-08-23 13:29:37 --> Config Class Initialized
INFO - 2018-08-23 13:29:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:37 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:37 --> URI Class Initialized
INFO - 2018-08-23 13:29:37 --> Router Class Initialized
INFO - 2018-08-23 13:29:37 --> Output Class Initialized
INFO - 2018-08-23 13:29:37 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:37 --> CSRF cookie sent
INFO - 2018-08-23 13:29:37 --> Input Class Initialized
INFO - 2018-08-23 13:29:37 --> Language Class Initialized
INFO - 2018-08-23 13:29:37 --> Loader Class Initialized
INFO - 2018-08-23 13:29:37 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:37 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:37 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:37 --> Controller Class Initialized
INFO - 2018-08-23 13:29:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:37 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-23 13:29:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:37 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:37 --> Total execution time: 0.0400
INFO - 2018-08-23 13:29:44 --> Config Class Initialized
INFO - 2018-08-23 13:29:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:44 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:44 --> URI Class Initialized
INFO - 2018-08-23 13:29:44 --> Router Class Initialized
INFO - 2018-08-23 13:29:44 --> Output Class Initialized
INFO - 2018-08-23 13:29:44 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:44 --> CSRF cookie sent
INFO - 2018-08-23 13:29:44 --> CSRF token verified
INFO - 2018-08-23 13:29:44 --> Input Class Initialized
INFO - 2018-08-23 13:29:44 --> Language Class Initialized
INFO - 2018-08-23 13:29:44 --> Loader Class Initialized
INFO - 2018-08-23 13:29:44 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:44 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:44 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:44 --> Controller Class Initialized
INFO - 2018-08-23 13:29:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:44 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:44 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:44 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:44 --> Config Class Initialized
INFO - 2018-08-23 13:29:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:44 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:44 --> URI Class Initialized
INFO - 2018-08-23 13:29:44 --> Router Class Initialized
INFO - 2018-08-23 13:29:44 --> Output Class Initialized
INFO - 2018-08-23 13:29:44 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:44 --> CSRF cookie sent
INFO - 2018-08-23 13:29:44 --> Input Class Initialized
INFO - 2018-08-23 13:29:44 --> Language Class Initialized
INFO - 2018-08-23 13:29:44 --> Loader Class Initialized
INFO - 2018-08-23 13:29:44 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:44 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:44 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:44 --> Controller Class Initialized
INFO - 2018-08-23 13:29:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:44 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:44 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:44 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 13:29:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:44 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:44 --> Total execution time: 0.0452
INFO - 2018-08-23 13:29:46 --> Config Class Initialized
INFO - 2018-08-23 13:29:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:46 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:46 --> URI Class Initialized
INFO - 2018-08-23 13:29:46 --> Router Class Initialized
INFO - 2018-08-23 13:29:46 --> Output Class Initialized
INFO - 2018-08-23 13:29:46 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:46 --> CSRF cookie sent
INFO - 2018-08-23 13:29:46 --> CSRF token verified
INFO - 2018-08-23 13:29:46 --> Input Class Initialized
INFO - 2018-08-23 13:29:46 --> Language Class Initialized
INFO - 2018-08-23 13:29:46 --> Loader Class Initialized
INFO - 2018-08-23 13:29:46 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:46 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:46 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:46 --> Controller Class Initialized
INFO - 2018-08-23 13:29:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:46 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:46 --> Form Validation Class Initialized
INFO - 2018-08-23 13:29:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:29:46 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 13:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:46 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:46 --> Total execution time: 0.0517
INFO - 2018-08-23 13:29:48 --> Config Class Initialized
INFO - 2018-08-23 13:29:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:48 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:48 --> URI Class Initialized
INFO - 2018-08-23 13:29:48 --> Router Class Initialized
INFO - 2018-08-23 13:29:48 --> Output Class Initialized
INFO - 2018-08-23 13:29:48 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:48 --> CSRF cookie sent
INFO - 2018-08-23 13:29:48 --> CSRF token verified
INFO - 2018-08-23 13:29:48 --> Input Class Initialized
INFO - 2018-08-23 13:29:48 --> Language Class Initialized
INFO - 2018-08-23 13:29:48 --> Loader Class Initialized
INFO - 2018-08-23 13:29:48 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:48 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:48 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:48 --> Controller Class Initialized
INFO - 2018-08-23 13:29:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:48 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:48 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:48 --> Form Validation Class Initialized
INFO - 2018-08-23 13:29:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:29:48 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:48 --> Config Class Initialized
INFO - 2018-08-23 13:29:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:48 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:48 --> URI Class Initialized
INFO - 2018-08-23 13:29:48 --> Router Class Initialized
INFO - 2018-08-23 13:29:48 --> Output Class Initialized
INFO - 2018-08-23 13:29:48 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:48 --> CSRF cookie sent
INFO - 2018-08-23 13:29:48 --> Input Class Initialized
INFO - 2018-08-23 13:29:48 --> Language Class Initialized
INFO - 2018-08-23 13:29:48 --> Loader Class Initialized
INFO - 2018-08-23 13:29:48 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:48 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:48 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:48 --> Controller Class Initialized
INFO - 2018-08-23 13:29:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:48 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:48 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:48 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-23 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:48 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:48 --> Total execution time: 0.0476
INFO - 2018-08-23 13:29:51 --> Config Class Initialized
INFO - 2018-08-23 13:29:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:51 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:51 --> URI Class Initialized
INFO - 2018-08-23 13:29:51 --> Router Class Initialized
INFO - 2018-08-23 13:29:51 --> Output Class Initialized
INFO - 2018-08-23 13:29:51 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:51 --> CSRF cookie sent
INFO - 2018-08-23 13:29:51 --> CSRF token verified
INFO - 2018-08-23 13:29:51 --> Input Class Initialized
INFO - 2018-08-23 13:29:51 --> Language Class Initialized
INFO - 2018-08-23 13:29:51 --> Loader Class Initialized
INFO - 2018-08-23 13:29:51 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:51 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:51 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:51 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:51 --> Controller Class Initialized
INFO - 2018-08-23 13:29:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:51 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:51 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:51 --> Form Validation Class Initialized
INFO - 2018-08-23 13:29:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:29:51 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:51 --> Config Class Initialized
INFO - 2018-08-23 13:29:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:51 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:51 --> URI Class Initialized
INFO - 2018-08-23 13:29:51 --> Router Class Initialized
INFO - 2018-08-23 13:29:51 --> Output Class Initialized
INFO - 2018-08-23 13:29:51 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:51 --> CSRF cookie sent
INFO - 2018-08-23 13:29:51 --> Input Class Initialized
INFO - 2018-08-23 13:29:51 --> Language Class Initialized
INFO - 2018-08-23 13:29:51 --> Loader Class Initialized
INFO - 2018-08-23 13:29:52 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:52 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:52 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:52 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:52 --> Controller Class Initialized
INFO - 2018-08-23 13:29:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:52 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:52 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:52 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 13:29:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:52 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:52 --> Total execution time: 0.0403
INFO - 2018-08-23 13:29:55 --> Config Class Initialized
INFO - 2018-08-23 13:29:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:55 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:55 --> URI Class Initialized
INFO - 2018-08-23 13:29:55 --> Router Class Initialized
INFO - 2018-08-23 13:29:55 --> Output Class Initialized
INFO - 2018-08-23 13:29:55 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:55 --> CSRF cookie sent
INFO - 2018-08-23 13:29:55 --> CSRF token verified
INFO - 2018-08-23 13:29:55 --> Input Class Initialized
INFO - 2018-08-23 13:29:55 --> Language Class Initialized
INFO - 2018-08-23 13:29:55 --> Loader Class Initialized
INFO - 2018-08-23 13:29:55 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:55 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:55 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:55 --> Controller Class Initialized
INFO - 2018-08-23 13:29:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:55 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:55 --> Form Validation Class Initialized
INFO - 2018-08-23 13:29:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:29:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:55 --> Config Class Initialized
INFO - 2018-08-23 13:29:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:29:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:29:55 --> Utf8 Class Initialized
INFO - 2018-08-23 13:29:55 --> URI Class Initialized
INFO - 2018-08-23 13:29:55 --> Router Class Initialized
INFO - 2018-08-23 13:29:55 --> Output Class Initialized
INFO - 2018-08-23 13:29:55 --> Security Class Initialized
DEBUG - 2018-08-23 13:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:29:55 --> CSRF cookie sent
INFO - 2018-08-23 13:29:55 --> Input Class Initialized
INFO - 2018-08-23 13:29:55 --> Language Class Initialized
INFO - 2018-08-23 13:29:55 --> Loader Class Initialized
INFO - 2018-08-23 13:29:55 --> Helper loaded: url_helper
INFO - 2018-08-23 13:29:55 --> Helper loaded: form_helper
INFO - 2018-08-23 13:29:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:29:55 --> User Agent Class Initialized
INFO - 2018-08-23 13:29:55 --> Controller Class Initialized
INFO - 2018-08-23 13:29:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:29:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:29:55 --> Pixel_Model class loaded
INFO - 2018-08-23 13:29:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:55 --> Database Driver Class Initialized
INFO - 2018-08-23 13:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 13:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:29:55 --> Final output sent to browser
DEBUG - 2018-08-23 13:29:55 --> Total execution time: 0.0379
INFO - 2018-08-23 13:30:00 --> Config Class Initialized
INFO - 2018-08-23 13:30:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:00 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:00 --> URI Class Initialized
INFO - 2018-08-23 13:30:00 --> Router Class Initialized
INFO - 2018-08-23 13:30:00 --> Output Class Initialized
INFO - 2018-08-23 13:30:00 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:00 --> CSRF cookie sent
INFO - 2018-08-23 13:30:00 --> CSRF token verified
INFO - 2018-08-23 13:30:00 --> Input Class Initialized
INFO - 2018-08-23 13:30:00 --> Language Class Initialized
INFO - 2018-08-23 13:30:00 --> Loader Class Initialized
INFO - 2018-08-23 13:30:00 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:00 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:00 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:00 --> Controller Class Initialized
INFO - 2018-08-23 13:30:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:00 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:00 --> Form Validation Class Initialized
INFO - 2018-08-23 13:30:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:30:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:00 --> Config Class Initialized
INFO - 2018-08-23 13:30:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:00 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:00 --> URI Class Initialized
INFO - 2018-08-23 13:30:00 --> Router Class Initialized
INFO - 2018-08-23 13:30:00 --> Output Class Initialized
INFO - 2018-08-23 13:30:00 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:00 --> CSRF cookie sent
INFO - 2018-08-23 13:30:00 --> Input Class Initialized
INFO - 2018-08-23 13:30:00 --> Language Class Initialized
INFO - 2018-08-23 13:30:00 --> Loader Class Initialized
INFO - 2018-08-23 13:30:00 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:00 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:00 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:00 --> Controller Class Initialized
INFO - 2018-08-23 13:30:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:00 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:00 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 13:30:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:30:00 --> Final output sent to browser
DEBUG - 2018-08-23 13:30:00 --> Total execution time: 0.0440
INFO - 2018-08-23 13:30:35 --> Config Class Initialized
INFO - 2018-08-23 13:30:35 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:35 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:35 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:35 --> URI Class Initialized
INFO - 2018-08-23 13:30:35 --> Router Class Initialized
INFO - 2018-08-23 13:30:35 --> Output Class Initialized
INFO - 2018-08-23 13:30:35 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:35 --> CSRF cookie sent
INFO - 2018-08-23 13:30:35 --> Input Class Initialized
INFO - 2018-08-23 13:30:35 --> Language Class Initialized
INFO - 2018-08-23 13:30:35 --> Loader Class Initialized
INFO - 2018-08-23 13:30:35 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:35 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:35 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:35 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:35 --> Controller Class Initialized
INFO - 2018-08-23 13:30:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:35 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:35 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:35 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 13:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:30:35 --> Final output sent to browser
DEBUG - 2018-08-23 13:30:35 --> Total execution time: 0.0570
INFO - 2018-08-23 13:30:37 --> Config Class Initialized
INFO - 2018-08-23 13:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:37 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:37 --> URI Class Initialized
INFO - 2018-08-23 13:30:37 --> Router Class Initialized
INFO - 2018-08-23 13:30:37 --> Output Class Initialized
INFO - 2018-08-23 13:30:37 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:37 --> CSRF cookie sent
INFO - 2018-08-23 13:30:37 --> Input Class Initialized
INFO - 2018-08-23 13:30:37 --> Language Class Initialized
INFO - 2018-08-23 13:30:37 --> Loader Class Initialized
INFO - 2018-08-23 13:30:37 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:37 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:37 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:37 --> Controller Class Initialized
INFO - 2018-08-23 13:30:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:37 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:37 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 13:30:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:30:37 --> Final output sent to browser
DEBUG - 2018-08-23 13:30:37 --> Total execution time: 0.0443
INFO - 2018-08-23 13:30:42 --> Config Class Initialized
INFO - 2018-08-23 13:30:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:42 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:42 --> URI Class Initialized
INFO - 2018-08-23 13:30:42 --> Router Class Initialized
INFO - 2018-08-23 13:30:42 --> Output Class Initialized
INFO - 2018-08-23 13:30:42 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:42 --> CSRF cookie sent
INFO - 2018-08-23 13:30:42 --> CSRF token verified
INFO - 2018-08-23 13:30:42 --> Input Class Initialized
INFO - 2018-08-23 13:30:42 --> Language Class Initialized
INFO - 2018-08-23 13:30:42 --> Loader Class Initialized
INFO - 2018-08-23 13:30:42 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:42 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:42 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:42 --> Controller Class Initialized
INFO - 2018-08-23 13:30:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:42 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:42 --> Form Validation Class Initialized
INFO - 2018-08-23 13:30:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:30:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:42 --> Config Class Initialized
INFO - 2018-08-23 13:30:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:42 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:42 --> URI Class Initialized
INFO - 2018-08-23 13:30:42 --> Router Class Initialized
INFO - 2018-08-23 13:30:42 --> Output Class Initialized
INFO - 2018-08-23 13:30:42 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:42 --> CSRF cookie sent
INFO - 2018-08-23 13:30:42 --> Input Class Initialized
INFO - 2018-08-23 13:30:42 --> Language Class Initialized
INFO - 2018-08-23 13:30:42 --> Loader Class Initialized
INFO - 2018-08-23 13:30:42 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:42 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:42 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:42 --> Controller Class Initialized
INFO - 2018-08-23 13:30:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:42 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:42 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 13:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:30:42 --> Final output sent to browser
DEBUG - 2018-08-23 13:30:42 --> Total execution time: 0.0392
INFO - 2018-08-23 13:30:43 --> Config Class Initialized
INFO - 2018-08-23 13:30:43 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:43 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:43 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:43 --> URI Class Initialized
INFO - 2018-08-23 13:30:43 --> Router Class Initialized
INFO - 2018-08-23 13:30:43 --> Output Class Initialized
INFO - 2018-08-23 13:30:43 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:43 --> CSRF cookie sent
INFO - 2018-08-23 13:30:43 --> CSRF token verified
INFO - 2018-08-23 13:30:43 --> Input Class Initialized
INFO - 2018-08-23 13:30:43 --> Language Class Initialized
INFO - 2018-08-23 13:30:43 --> Loader Class Initialized
INFO - 2018-08-23 13:30:43 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:43 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:43 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:43 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:43 --> Controller Class Initialized
INFO - 2018-08-23 13:30:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:43 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:43 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:43 --> Form Validation Class Initialized
INFO - 2018-08-23 13:30:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 13:30:43 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:43 --> Config Class Initialized
INFO - 2018-08-23 13:30:43 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:30:43 --> UTF-8 Support Enabled
INFO - 2018-08-23 13:30:43 --> Utf8 Class Initialized
INFO - 2018-08-23 13:30:43 --> URI Class Initialized
INFO - 2018-08-23 13:30:43 --> Router Class Initialized
INFO - 2018-08-23 13:30:43 --> Output Class Initialized
INFO - 2018-08-23 13:30:43 --> Security Class Initialized
DEBUG - 2018-08-23 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 13:30:43 --> CSRF cookie sent
INFO - 2018-08-23 13:30:43 --> Input Class Initialized
INFO - 2018-08-23 13:30:43 --> Language Class Initialized
INFO - 2018-08-23 13:30:43 --> Loader Class Initialized
INFO - 2018-08-23 13:30:43 --> Helper loaded: url_helper
INFO - 2018-08-23 13:30:43 --> Helper loaded: form_helper
INFO - 2018-08-23 13:30:43 --> Helper loaded: language_helper
DEBUG - 2018-08-23 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 13:30:43 --> User Agent Class Initialized
INFO - 2018-08-23 13:30:43 --> Controller Class Initialized
INFO - 2018-08-23 13:30:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 13:30:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 13:30:43 --> Pixel_Model class loaded
INFO - 2018-08-23 13:30:43 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:43 --> Database Driver Class Initialized
INFO - 2018-08-23 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 13:30:43 --> Final output sent to browser
DEBUG - 2018-08-23 13:30:43 --> Total execution time: 0.0405
INFO - 2018-08-23 14:58:22 --> Config Class Initialized
INFO - 2018-08-23 14:58:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:22 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:22 --> URI Class Initialized
INFO - 2018-08-23 14:58:22 --> Router Class Initialized
INFO - 2018-08-23 14:58:22 --> Output Class Initialized
INFO - 2018-08-23 14:58:22 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:22 --> CSRF cookie sent
INFO - 2018-08-23 14:58:22 --> Input Class Initialized
INFO - 2018-08-23 14:58:22 --> Language Class Initialized
ERROR - 2018-08-23 14:58:22 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-23 14:58:23 --> Config Class Initialized
INFO - 2018-08-23 14:58:23 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:23 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:23 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:23 --> URI Class Initialized
INFO - 2018-08-23 14:58:23 --> Router Class Initialized
INFO - 2018-08-23 14:58:23 --> Output Class Initialized
INFO - 2018-08-23 14:58:23 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:23 --> CSRF cookie sent
INFO - 2018-08-23 14:58:23 --> Input Class Initialized
INFO - 2018-08-23 14:58:23 --> Language Class Initialized
ERROR - 2018-08-23 14:58:23 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-23 14:58:26 --> Config Class Initialized
INFO - 2018-08-23 14:58:26 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:26 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:26 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:26 --> URI Class Initialized
DEBUG - 2018-08-23 14:58:26 --> No URI present. Default controller set.
INFO - 2018-08-23 14:58:26 --> Router Class Initialized
INFO - 2018-08-23 14:58:26 --> Output Class Initialized
INFO - 2018-08-23 14:58:26 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:26 --> CSRF cookie sent
INFO - 2018-08-23 14:58:26 --> Input Class Initialized
INFO - 2018-08-23 14:58:26 --> Language Class Initialized
INFO - 2018-08-23 14:58:26 --> Loader Class Initialized
INFO - 2018-08-23 14:58:26 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:26 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:26 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:26 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:26 --> Controller Class Initialized
INFO - 2018-08-23 14:58:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:26 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:26 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 14:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:26 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:26 --> Total execution time: 0.0425
INFO - 2018-08-23 14:58:28 --> Config Class Initialized
INFO - 2018-08-23 14:58:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:28 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:28 --> URI Class Initialized
INFO - 2018-08-23 14:58:28 --> Router Class Initialized
INFO - 2018-08-23 14:58:28 --> Output Class Initialized
INFO - 2018-08-23 14:58:28 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:28 --> CSRF cookie sent
INFO - 2018-08-23 14:58:28 --> Input Class Initialized
INFO - 2018-08-23 14:58:28 --> Language Class Initialized
INFO - 2018-08-23 14:58:28 --> Loader Class Initialized
INFO - 2018-08-23 14:58:28 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:28 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:28 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:28 --> Controller Class Initialized
INFO - 2018-08-23 14:58:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 14:58:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 14:58:28 --> Could not find the language line "req_email"
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-23 14:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:28 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:28 --> Total execution time: 0.0222
INFO - 2018-08-23 14:58:32 --> Config Class Initialized
INFO - 2018-08-23 14:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:32 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:32 --> URI Class Initialized
INFO - 2018-08-23 14:58:32 --> Router Class Initialized
INFO - 2018-08-23 14:58:32 --> Output Class Initialized
INFO - 2018-08-23 14:58:32 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:32 --> CSRF cookie sent
INFO - 2018-08-23 14:58:32 --> CSRF token verified
INFO - 2018-08-23 14:58:32 --> Input Class Initialized
INFO - 2018-08-23 14:58:32 --> Language Class Initialized
INFO - 2018-08-23 14:58:32 --> Loader Class Initialized
INFO - 2018-08-23 14:58:32 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:32 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:32 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:32 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:32 --> Controller Class Initialized
INFO - 2018-08-23 14:58:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 14:58:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 14:58:32 --> Form Validation Class Initialized
INFO - 2018-08-23 14:58:32 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:32 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:32 --> Model "AuthenticationModel" initialized
INFO - 2018-08-23 14:58:33 --> Config Class Initialized
INFO - 2018-08-23 14:58:33 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:33 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:33 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:33 --> URI Class Initialized
DEBUG - 2018-08-23 14:58:33 --> No URI present. Default controller set.
INFO - 2018-08-23 14:58:33 --> Router Class Initialized
INFO - 2018-08-23 14:58:33 --> Output Class Initialized
INFO - 2018-08-23 14:58:33 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:33 --> CSRF cookie sent
INFO - 2018-08-23 14:58:33 --> Input Class Initialized
INFO - 2018-08-23 14:58:33 --> Language Class Initialized
INFO - 2018-08-23 14:58:33 --> Loader Class Initialized
INFO - 2018-08-23 14:58:33 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:33 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:33 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:33 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:33 --> Controller Class Initialized
INFO - 2018-08-23 14:58:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:33 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:33 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:33 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:33 --> Total execution time: 0.0472
INFO - 2018-08-23 14:58:36 --> Config Class Initialized
INFO - 2018-08-23 14:58:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:36 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:36 --> URI Class Initialized
INFO - 2018-08-23 14:58:36 --> Router Class Initialized
INFO - 2018-08-23 14:58:36 --> Output Class Initialized
INFO - 2018-08-23 14:58:36 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:36 --> CSRF cookie sent
INFO - 2018-08-23 14:58:36 --> Input Class Initialized
INFO - 2018-08-23 14:58:36 --> Language Class Initialized
INFO - 2018-08-23 14:58:36 --> Loader Class Initialized
INFO - 2018-08-23 14:58:36 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:36 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:36 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:36 --> Controller Class Initialized
INFO - 2018-08-23 14:58:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:36 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:36 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:36 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-23 14:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:36 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:36 --> Total execution time: 0.0389
INFO - 2018-08-23 14:58:45 --> Config Class Initialized
INFO - 2018-08-23 14:58:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:45 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:45 --> URI Class Initialized
INFO - 2018-08-23 14:58:45 --> Router Class Initialized
INFO - 2018-08-23 14:58:45 --> Output Class Initialized
INFO - 2018-08-23 14:58:45 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:45 --> CSRF cookie sent
INFO - 2018-08-23 14:58:45 --> Input Class Initialized
INFO - 2018-08-23 14:58:45 --> Language Class Initialized
INFO - 2018-08-23 14:58:45 --> Loader Class Initialized
INFO - 2018-08-23 14:58:45 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:45 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:45 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:45 --> Controller Class Initialized
INFO - 2018-08-23 14:58:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:45 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:45 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:45 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 14:58:45 --> Config Class Initialized
INFO - 2018-08-23 14:58:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:45 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:45 --> URI Class Initialized
INFO - 2018-08-23 14:58:45 --> Router Class Initialized
INFO - 2018-08-23 14:58:45 --> Output Class Initialized
INFO - 2018-08-23 14:58:45 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:45 --> CSRF cookie sent
INFO - 2018-08-23 14:58:45 --> Input Class Initialized
INFO - 2018-08-23 14:58:45 --> Language Class Initialized
INFO - 2018-08-23 14:58:45 --> Loader Class Initialized
INFO - 2018-08-23 14:58:45 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:45 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:45 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:45 --> Controller Class Initialized
INFO - 2018-08-23 14:58:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:45 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:45 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:45 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-23 14:58:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:45 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:45 --> Total execution time: 0.0443
INFO - 2018-08-23 14:58:54 --> Config Class Initialized
INFO - 2018-08-23 14:58:54 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:54 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:54 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:54 --> URI Class Initialized
INFO - 2018-08-23 14:58:54 --> Router Class Initialized
INFO - 2018-08-23 14:58:54 --> Output Class Initialized
INFO - 2018-08-23 14:58:54 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:54 --> CSRF cookie sent
INFO - 2018-08-23 14:58:54 --> Input Class Initialized
INFO - 2018-08-23 14:58:54 --> Language Class Initialized
INFO - 2018-08-23 14:58:54 --> Loader Class Initialized
INFO - 2018-08-23 14:58:54 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:54 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:54 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:54 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:54 --> Controller Class Initialized
INFO - 2018-08-23 14:58:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:54 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:54 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:54 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 14:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:54 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:54 --> Total execution time: 0.0477
INFO - 2018-08-23 14:58:58 --> Config Class Initialized
INFO - 2018-08-23 14:58:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:58 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:58 --> URI Class Initialized
INFO - 2018-08-23 14:58:58 --> Router Class Initialized
INFO - 2018-08-23 14:58:58 --> Output Class Initialized
INFO - 2018-08-23 14:58:58 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:58 --> CSRF cookie sent
INFO - 2018-08-23 14:58:58 --> CSRF token verified
INFO - 2018-08-23 14:58:58 --> Input Class Initialized
INFO - 2018-08-23 14:58:58 --> Language Class Initialized
INFO - 2018-08-23 14:58:58 --> Loader Class Initialized
INFO - 2018-08-23 14:58:58 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:58 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:58 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:58 --> Controller Class Initialized
INFO - 2018-08-23 14:58:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:58 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:58 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:58 --> Form Validation Class Initialized
INFO - 2018-08-23 14:58:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:58:58 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:58 --> Config Class Initialized
INFO - 2018-08-23 14:58:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:58:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:58:58 --> Utf8 Class Initialized
INFO - 2018-08-23 14:58:58 --> URI Class Initialized
INFO - 2018-08-23 14:58:58 --> Router Class Initialized
INFO - 2018-08-23 14:58:58 --> Output Class Initialized
INFO - 2018-08-23 14:58:58 --> Security Class Initialized
DEBUG - 2018-08-23 14:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:58:58 --> CSRF cookie sent
INFO - 2018-08-23 14:58:58 --> Input Class Initialized
INFO - 2018-08-23 14:58:58 --> Language Class Initialized
INFO - 2018-08-23 14:58:58 --> Loader Class Initialized
INFO - 2018-08-23 14:58:58 --> Helper loaded: url_helper
INFO - 2018-08-23 14:58:58 --> Helper loaded: form_helper
INFO - 2018-08-23 14:58:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:58:58 --> User Agent Class Initialized
INFO - 2018-08-23 14:58:58 --> Controller Class Initialized
INFO - 2018-08-23 14:58:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:58:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:58:58 --> Pixel_Model class loaded
INFO - 2018-08-23 14:58:58 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:58 --> Database Driver Class Initialized
INFO - 2018-08-23 14:58:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 14:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:58:58 --> Final output sent to browser
DEBUG - 2018-08-23 14:58:58 --> Total execution time: 0.0390
INFO - 2018-08-23 14:59:00 --> Config Class Initialized
INFO - 2018-08-23 14:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:00 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:00 --> URI Class Initialized
INFO - 2018-08-23 14:59:00 --> Router Class Initialized
INFO - 2018-08-23 14:59:00 --> Output Class Initialized
INFO - 2018-08-23 14:59:00 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:00 --> CSRF cookie sent
INFO - 2018-08-23 14:59:00 --> CSRF token verified
INFO - 2018-08-23 14:59:00 --> Input Class Initialized
INFO - 2018-08-23 14:59:00 --> Language Class Initialized
INFO - 2018-08-23 14:59:00 --> Loader Class Initialized
INFO - 2018-08-23 14:59:00 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:00 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:00 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:00 --> Controller Class Initialized
INFO - 2018-08-23 14:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:00 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:00 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:00 --> Config Class Initialized
INFO - 2018-08-23 14:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:00 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:00 --> URI Class Initialized
INFO - 2018-08-23 14:59:00 --> Router Class Initialized
INFO - 2018-08-23 14:59:00 --> Output Class Initialized
INFO - 2018-08-23 14:59:00 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:00 --> CSRF cookie sent
INFO - 2018-08-23 14:59:00 --> Input Class Initialized
INFO - 2018-08-23 14:59:00 --> Language Class Initialized
INFO - 2018-08-23 14:59:00 --> Loader Class Initialized
INFO - 2018-08-23 14:59:00 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:00 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:00 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:00 --> Controller Class Initialized
INFO - 2018-08-23 14:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:00 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 14:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:00 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:00 --> Total execution time: 0.0523
INFO - 2018-08-23 14:59:12 --> Config Class Initialized
INFO - 2018-08-23 14:59:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:12 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:12 --> URI Class Initialized
INFO - 2018-08-23 14:59:12 --> Router Class Initialized
INFO - 2018-08-23 14:59:12 --> Output Class Initialized
INFO - 2018-08-23 14:59:12 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:12 --> CSRF cookie sent
INFO - 2018-08-23 14:59:12 --> CSRF token verified
INFO - 2018-08-23 14:59:12 --> Input Class Initialized
INFO - 2018-08-23 14:59:12 --> Language Class Initialized
INFO - 2018-08-23 14:59:12 --> Loader Class Initialized
INFO - 2018-08-23 14:59:12 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:12 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:12 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:12 --> Controller Class Initialized
INFO - 2018-08-23 14:59:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:12 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:12 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:12 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:12 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:12 --> Config Class Initialized
INFO - 2018-08-23 14:59:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:12 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:12 --> URI Class Initialized
INFO - 2018-08-23 14:59:12 --> Router Class Initialized
INFO - 2018-08-23 14:59:12 --> Output Class Initialized
INFO - 2018-08-23 14:59:12 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:12 --> CSRF cookie sent
INFO - 2018-08-23 14:59:12 --> Input Class Initialized
INFO - 2018-08-23 14:59:12 --> Language Class Initialized
INFO - 2018-08-23 14:59:12 --> Loader Class Initialized
INFO - 2018-08-23 14:59:12 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:12 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:12 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:12 --> Controller Class Initialized
INFO - 2018-08-23 14:59:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:12 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:12 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:12 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 14:59:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:12 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:12 --> Total execution time: 0.0454
INFO - 2018-08-23 14:59:14 --> Config Class Initialized
INFO - 2018-08-23 14:59:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:14 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:14 --> URI Class Initialized
INFO - 2018-08-23 14:59:14 --> Router Class Initialized
INFO - 2018-08-23 14:59:14 --> Output Class Initialized
INFO - 2018-08-23 14:59:14 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:14 --> CSRF cookie sent
INFO - 2018-08-23 14:59:14 --> CSRF token verified
INFO - 2018-08-23 14:59:14 --> Input Class Initialized
INFO - 2018-08-23 14:59:14 --> Language Class Initialized
INFO - 2018-08-23 14:59:14 --> Loader Class Initialized
INFO - 2018-08-23 14:59:14 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:14 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:14 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:14 --> Controller Class Initialized
INFO - 2018-08-23 14:59:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:14 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:14 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:14 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:14 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:14 --> Config Class Initialized
INFO - 2018-08-23 14:59:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:14 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:14 --> URI Class Initialized
INFO - 2018-08-23 14:59:14 --> Router Class Initialized
INFO - 2018-08-23 14:59:14 --> Output Class Initialized
INFO - 2018-08-23 14:59:14 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:14 --> CSRF cookie sent
INFO - 2018-08-23 14:59:14 --> Input Class Initialized
INFO - 2018-08-23 14:59:14 --> Language Class Initialized
INFO - 2018-08-23 14:59:14 --> Loader Class Initialized
INFO - 2018-08-23 14:59:14 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:14 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:14 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:14 --> Controller Class Initialized
INFO - 2018-08-23 14:59:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:14 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:14 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:14 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 14:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:14 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:14 --> Total execution time: 0.0462
INFO - 2018-08-23 14:59:16 --> Config Class Initialized
INFO - 2018-08-23 14:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:16 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:16 --> URI Class Initialized
INFO - 2018-08-23 14:59:16 --> Router Class Initialized
INFO - 2018-08-23 14:59:16 --> Output Class Initialized
INFO - 2018-08-23 14:59:16 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:16 --> CSRF cookie sent
INFO - 2018-08-23 14:59:16 --> CSRF token verified
INFO - 2018-08-23 14:59:16 --> Input Class Initialized
INFO - 2018-08-23 14:59:16 --> Language Class Initialized
INFO - 2018-08-23 14:59:16 --> Loader Class Initialized
INFO - 2018-08-23 14:59:16 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:16 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:16 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:16 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:16 --> Controller Class Initialized
INFO - 2018-08-23 14:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:16 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:16 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:16 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:16 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:16 --> Config Class Initialized
INFO - 2018-08-23 14:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:16 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:16 --> URI Class Initialized
INFO - 2018-08-23 14:59:16 --> Router Class Initialized
INFO - 2018-08-23 14:59:16 --> Output Class Initialized
INFO - 2018-08-23 14:59:16 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:16 --> CSRF cookie sent
INFO - 2018-08-23 14:59:16 --> Input Class Initialized
INFO - 2018-08-23 14:59:16 --> Language Class Initialized
INFO - 2018-08-23 14:59:16 --> Loader Class Initialized
INFO - 2018-08-23 14:59:16 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:16 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:16 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:16 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:16 --> Controller Class Initialized
INFO - 2018-08-23 14:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:16 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:16 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:16 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 14:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:16 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:16 --> Total execution time: 0.0468
INFO - 2018-08-23 14:59:21 --> Config Class Initialized
INFO - 2018-08-23 14:59:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:21 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:21 --> URI Class Initialized
INFO - 2018-08-23 14:59:21 --> Router Class Initialized
INFO - 2018-08-23 14:59:21 --> Output Class Initialized
INFO - 2018-08-23 14:59:21 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:21 --> CSRF cookie sent
INFO - 2018-08-23 14:59:21 --> CSRF token verified
INFO - 2018-08-23 14:59:21 --> Input Class Initialized
INFO - 2018-08-23 14:59:21 --> Language Class Initialized
INFO - 2018-08-23 14:59:21 --> Loader Class Initialized
INFO - 2018-08-23 14:59:21 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:21 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:21 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:21 --> Controller Class Initialized
INFO - 2018-08-23 14:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:21 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:21 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:21 --> Config Class Initialized
INFO - 2018-08-23 14:59:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:21 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:21 --> URI Class Initialized
INFO - 2018-08-23 14:59:21 --> Router Class Initialized
INFO - 2018-08-23 14:59:21 --> Output Class Initialized
INFO - 2018-08-23 14:59:21 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:21 --> CSRF cookie sent
INFO - 2018-08-23 14:59:21 --> Input Class Initialized
INFO - 2018-08-23 14:59:21 --> Language Class Initialized
INFO - 2018-08-23 14:59:21 --> Loader Class Initialized
INFO - 2018-08-23 14:59:21 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:21 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:21 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:21 --> Controller Class Initialized
INFO - 2018-08-23 14:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:21 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:21 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 14:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:21 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:21 --> Total execution time: 0.0582
INFO - 2018-08-23 14:59:24 --> Config Class Initialized
INFO - 2018-08-23 14:59:24 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:24 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:24 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:24 --> URI Class Initialized
INFO - 2018-08-23 14:59:24 --> Router Class Initialized
INFO - 2018-08-23 14:59:24 --> Output Class Initialized
INFO - 2018-08-23 14:59:24 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:24 --> CSRF cookie sent
INFO - 2018-08-23 14:59:24 --> Input Class Initialized
INFO - 2018-08-23 14:59:24 --> Language Class Initialized
INFO - 2018-08-23 14:59:24 --> Loader Class Initialized
INFO - 2018-08-23 14:59:24 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:24 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:24 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:24 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:24 --> Controller Class Initialized
INFO - 2018-08-23 14:59:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:24 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:24 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:24 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 14:59:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:24 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:24 --> Total execution time: 0.0633
INFO - 2018-08-23 14:59:25 --> Config Class Initialized
INFO - 2018-08-23 14:59:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:25 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:25 --> URI Class Initialized
INFO - 2018-08-23 14:59:25 --> Router Class Initialized
INFO - 2018-08-23 14:59:25 --> Output Class Initialized
INFO - 2018-08-23 14:59:25 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:25 --> CSRF cookie sent
INFO - 2018-08-23 14:59:25 --> Input Class Initialized
INFO - 2018-08-23 14:59:25 --> Language Class Initialized
INFO - 2018-08-23 14:59:25 --> Loader Class Initialized
INFO - 2018-08-23 14:59:25 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:25 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:25 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:25 --> Controller Class Initialized
INFO - 2018-08-23 14:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:25 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:25 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 14:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:25 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:25 --> Total execution time: 0.0449
INFO - 2018-08-23 14:59:38 --> Config Class Initialized
INFO - 2018-08-23 14:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:38 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:38 --> URI Class Initialized
INFO - 2018-08-23 14:59:38 --> Router Class Initialized
INFO - 2018-08-23 14:59:38 --> Output Class Initialized
INFO - 2018-08-23 14:59:38 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:38 --> CSRF cookie sent
INFO - 2018-08-23 14:59:38 --> CSRF token verified
INFO - 2018-08-23 14:59:38 --> Input Class Initialized
INFO - 2018-08-23 14:59:38 --> Language Class Initialized
INFO - 2018-08-23 14:59:38 --> Loader Class Initialized
INFO - 2018-08-23 14:59:38 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:38 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:38 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:38 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:38 --> Controller Class Initialized
INFO - 2018-08-23 14:59:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:38 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:38 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:38 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:38 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:38 --> Config Class Initialized
INFO - 2018-08-23 14:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:38 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:38 --> URI Class Initialized
INFO - 2018-08-23 14:59:38 --> Router Class Initialized
INFO - 2018-08-23 14:59:38 --> Output Class Initialized
INFO - 2018-08-23 14:59:38 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:38 --> CSRF cookie sent
INFO - 2018-08-23 14:59:38 --> Input Class Initialized
INFO - 2018-08-23 14:59:38 --> Language Class Initialized
INFO - 2018-08-23 14:59:38 --> Loader Class Initialized
INFO - 2018-08-23 14:59:38 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:38 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:38 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:38 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:38 --> Controller Class Initialized
INFO - 2018-08-23 14:59:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:38 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:38 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:38 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 14:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:38 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:38 --> Total execution time: 0.0454
INFO - 2018-08-23 14:59:40 --> Config Class Initialized
INFO - 2018-08-23 14:59:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:40 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:40 --> URI Class Initialized
INFO - 2018-08-23 14:59:40 --> Router Class Initialized
INFO - 2018-08-23 14:59:40 --> Output Class Initialized
INFO - 2018-08-23 14:59:40 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:40 --> CSRF cookie sent
INFO - 2018-08-23 14:59:40 --> CSRF token verified
INFO - 2018-08-23 14:59:40 --> Input Class Initialized
INFO - 2018-08-23 14:59:40 --> Language Class Initialized
INFO - 2018-08-23 14:59:40 --> Loader Class Initialized
INFO - 2018-08-23 14:59:40 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:40 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:40 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:40 --> Controller Class Initialized
INFO - 2018-08-23 14:59:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:40 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:40 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:40 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:40 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:40 --> Config Class Initialized
INFO - 2018-08-23 14:59:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:40 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:40 --> URI Class Initialized
INFO - 2018-08-23 14:59:40 --> Router Class Initialized
INFO - 2018-08-23 14:59:40 --> Output Class Initialized
INFO - 2018-08-23 14:59:40 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:40 --> CSRF cookie sent
INFO - 2018-08-23 14:59:40 --> Input Class Initialized
INFO - 2018-08-23 14:59:40 --> Language Class Initialized
INFO - 2018-08-23 14:59:40 --> Loader Class Initialized
INFO - 2018-08-23 14:59:40 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:40 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:40 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:40 --> Controller Class Initialized
INFO - 2018-08-23 14:59:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:40 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:40 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:40 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 14:59:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:40 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:40 --> Total execution time: 0.0434
INFO - 2018-08-23 14:59:45 --> Config Class Initialized
INFO - 2018-08-23 14:59:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:45 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:45 --> URI Class Initialized
INFO - 2018-08-23 14:59:45 --> Router Class Initialized
INFO - 2018-08-23 14:59:45 --> Output Class Initialized
INFO - 2018-08-23 14:59:45 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:45 --> CSRF cookie sent
INFO - 2018-08-23 14:59:45 --> Input Class Initialized
INFO - 2018-08-23 14:59:45 --> Language Class Initialized
INFO - 2018-08-23 14:59:45 --> Loader Class Initialized
INFO - 2018-08-23 14:59:45 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:45 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:45 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:45 --> Controller Class Initialized
INFO - 2018-08-23 14:59:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:45 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:45 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:45 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 14:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:45 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:45 --> Total execution time: 0.0537
INFO - 2018-08-23 14:59:49 --> Config Class Initialized
INFO - 2018-08-23 14:59:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:49 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:49 --> URI Class Initialized
INFO - 2018-08-23 14:59:49 --> Router Class Initialized
INFO - 2018-08-23 14:59:49 --> Output Class Initialized
INFO - 2018-08-23 14:59:49 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:49 --> CSRF cookie sent
INFO - 2018-08-23 14:59:49 --> CSRF token verified
INFO - 2018-08-23 14:59:49 --> Input Class Initialized
INFO - 2018-08-23 14:59:49 --> Language Class Initialized
INFO - 2018-08-23 14:59:49 --> Loader Class Initialized
INFO - 2018-08-23 14:59:49 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:49 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:49 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:49 --> Controller Class Initialized
INFO - 2018-08-23 14:59:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:49 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:49 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:49 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:49 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:49 --> Config Class Initialized
INFO - 2018-08-23 14:59:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:49 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:49 --> URI Class Initialized
INFO - 2018-08-23 14:59:49 --> Router Class Initialized
INFO - 2018-08-23 14:59:49 --> Output Class Initialized
INFO - 2018-08-23 14:59:49 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:49 --> CSRF cookie sent
INFO - 2018-08-23 14:59:49 --> Input Class Initialized
INFO - 2018-08-23 14:59:49 --> Language Class Initialized
INFO - 2018-08-23 14:59:49 --> Loader Class Initialized
INFO - 2018-08-23 14:59:49 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:49 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:49 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:49 --> Controller Class Initialized
INFO - 2018-08-23 14:59:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:49 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:49 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:49 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 14:59:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:49 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:49 --> Total execution time: 0.0478
INFO - 2018-08-23 14:59:51 --> Config Class Initialized
INFO - 2018-08-23 14:59:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:51 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:51 --> URI Class Initialized
INFO - 2018-08-23 14:59:51 --> Router Class Initialized
INFO - 2018-08-23 14:59:51 --> Output Class Initialized
INFO - 2018-08-23 14:59:51 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:51 --> CSRF cookie sent
INFO - 2018-08-23 14:59:51 --> CSRF token verified
INFO - 2018-08-23 14:59:51 --> Input Class Initialized
INFO - 2018-08-23 14:59:51 --> Language Class Initialized
INFO - 2018-08-23 14:59:51 --> Loader Class Initialized
INFO - 2018-08-23 14:59:51 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:51 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:51 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:51 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:51 --> Controller Class Initialized
INFO - 2018-08-23 14:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:51 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:51 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:51 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:51 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:51 --> Config Class Initialized
INFO - 2018-08-23 14:59:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:51 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:51 --> URI Class Initialized
INFO - 2018-08-23 14:59:51 --> Router Class Initialized
INFO - 2018-08-23 14:59:51 --> Output Class Initialized
INFO - 2018-08-23 14:59:51 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:51 --> CSRF cookie sent
INFO - 2018-08-23 14:59:51 --> Input Class Initialized
INFO - 2018-08-23 14:59:51 --> Language Class Initialized
INFO - 2018-08-23 14:59:51 --> Loader Class Initialized
INFO - 2018-08-23 14:59:51 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:51 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:51 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:51 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:51 --> Controller Class Initialized
INFO - 2018-08-23 14:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:51 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:51 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:51 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 14:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:51 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:51 --> Total execution time: 0.0444
INFO - 2018-08-23 14:59:57 --> Config Class Initialized
INFO - 2018-08-23 14:59:57 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:57 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:57 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:57 --> URI Class Initialized
INFO - 2018-08-23 14:59:57 --> Router Class Initialized
INFO - 2018-08-23 14:59:57 --> Output Class Initialized
INFO - 2018-08-23 14:59:57 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:57 --> CSRF cookie sent
INFO - 2018-08-23 14:59:57 --> CSRF token verified
INFO - 2018-08-23 14:59:57 --> Input Class Initialized
INFO - 2018-08-23 14:59:57 --> Language Class Initialized
INFO - 2018-08-23 14:59:57 --> Loader Class Initialized
INFO - 2018-08-23 14:59:57 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:57 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:57 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:57 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:57 --> Controller Class Initialized
INFO - 2018-08-23 14:59:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:57 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:57 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:57 --> Form Validation Class Initialized
INFO - 2018-08-23 14:59:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 14:59:57 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:57 --> Config Class Initialized
INFO - 2018-08-23 14:59:57 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:59:57 --> UTF-8 Support Enabled
INFO - 2018-08-23 14:59:57 --> Utf8 Class Initialized
INFO - 2018-08-23 14:59:57 --> URI Class Initialized
INFO - 2018-08-23 14:59:57 --> Router Class Initialized
INFO - 2018-08-23 14:59:57 --> Output Class Initialized
INFO - 2018-08-23 14:59:57 --> Security Class Initialized
DEBUG - 2018-08-23 14:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 14:59:57 --> CSRF cookie sent
INFO - 2018-08-23 14:59:57 --> Input Class Initialized
INFO - 2018-08-23 14:59:57 --> Language Class Initialized
INFO - 2018-08-23 14:59:57 --> Loader Class Initialized
INFO - 2018-08-23 14:59:57 --> Helper loaded: url_helper
INFO - 2018-08-23 14:59:57 --> Helper loaded: form_helper
INFO - 2018-08-23 14:59:57 --> Helper loaded: language_helper
DEBUG - 2018-08-23 14:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 14:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 14:59:57 --> User Agent Class Initialized
INFO - 2018-08-23 14:59:57 --> Controller Class Initialized
INFO - 2018-08-23 14:59:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 14:59:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 14:59:57 --> Pixel_Model class loaded
INFO - 2018-08-23 14:59:57 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:57 --> Database Driver Class Initialized
INFO - 2018-08-23 14:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 14:59:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 14:59:57 --> Final output sent to browser
DEBUG - 2018-08-23 14:59:57 --> Total execution time: 0.0459
INFO - 2018-08-23 15:00:00 --> Config Class Initialized
INFO - 2018-08-23 15:00:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:00 --> URI Class Initialized
INFO - 2018-08-23 15:00:00 --> Router Class Initialized
INFO - 2018-08-23 15:00:00 --> Output Class Initialized
INFO - 2018-08-23 15:00:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:00 --> CSRF cookie sent
INFO - 2018-08-23 15:00:00 --> CSRF token verified
INFO - 2018-08-23 15:00:00 --> Input Class Initialized
INFO - 2018-08-23 15:00:00 --> Language Class Initialized
INFO - 2018-08-23 15:00:00 --> Loader Class Initialized
INFO - 2018-08-23 15:00:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:00 --> Controller Class Initialized
INFO - 2018-08-23 15:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:00 --> Form Validation Class Initialized
INFO - 2018-08-23 15:00:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:00:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:00 --> Config Class Initialized
INFO - 2018-08-23 15:00:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:00 --> URI Class Initialized
INFO - 2018-08-23 15:00:00 --> Router Class Initialized
INFO - 2018-08-23 15:00:00 --> Output Class Initialized
INFO - 2018-08-23 15:00:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:00 --> CSRF cookie sent
INFO - 2018-08-23 15:00:00 --> Input Class Initialized
INFO - 2018-08-23 15:00:00 --> Language Class Initialized
INFO - 2018-08-23 15:00:00 --> Loader Class Initialized
INFO - 2018-08-23 15:00:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:00 --> Controller Class Initialized
INFO - 2018-08-23 15:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-23 15:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:00:00 --> Final output sent to browser
DEBUG - 2018-08-23 15:00:00 --> Total execution time: 0.0375
INFO - 2018-08-23 15:00:31 --> Config Class Initialized
INFO - 2018-08-23 15:00:31 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:31 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:31 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:31 --> URI Class Initialized
INFO - 2018-08-23 15:00:31 --> Router Class Initialized
INFO - 2018-08-23 15:00:31 --> Output Class Initialized
INFO - 2018-08-23 15:00:31 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:31 --> CSRF cookie sent
INFO - 2018-08-23 15:00:31 --> Input Class Initialized
INFO - 2018-08-23 15:00:31 --> Language Class Initialized
INFO - 2018-08-23 15:00:31 --> Loader Class Initialized
INFO - 2018-08-23 15:00:31 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:31 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:31 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:31 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:31 --> Controller Class Initialized
INFO - 2018-08-23 15:00:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:31 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:31 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:31 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 15:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:00:31 --> Final output sent to browser
DEBUG - 2018-08-23 15:00:31 --> Total execution time: 0.0682
INFO - 2018-08-23 15:00:36 --> Config Class Initialized
INFO - 2018-08-23 15:00:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:36 --> URI Class Initialized
INFO - 2018-08-23 15:00:36 --> Router Class Initialized
INFO - 2018-08-23 15:00:36 --> Output Class Initialized
INFO - 2018-08-23 15:00:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:36 --> CSRF cookie sent
INFO - 2018-08-23 15:00:36 --> CSRF token verified
INFO - 2018-08-23 15:00:36 --> Input Class Initialized
INFO - 2018-08-23 15:00:36 --> Language Class Initialized
INFO - 2018-08-23 15:00:36 --> Loader Class Initialized
INFO - 2018-08-23 15:00:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:36 --> Controller Class Initialized
INFO - 2018-08-23 15:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:36 --> Form Validation Class Initialized
INFO - 2018-08-23 15:00:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:00:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:36 --> Config Class Initialized
INFO - 2018-08-23 15:00:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:36 --> URI Class Initialized
INFO - 2018-08-23 15:00:36 --> Router Class Initialized
INFO - 2018-08-23 15:00:36 --> Output Class Initialized
INFO - 2018-08-23 15:00:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:36 --> CSRF cookie sent
INFO - 2018-08-23 15:00:36 --> Input Class Initialized
INFO - 2018-08-23 15:00:36 --> Language Class Initialized
INFO - 2018-08-23 15:00:36 --> Loader Class Initialized
INFO - 2018-08-23 15:00:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:36 --> Controller Class Initialized
INFO - 2018-08-23 15:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:00:36 --> Final output sent to browser
DEBUG - 2018-08-23 15:00:36 --> Total execution time: 0.0460
INFO - 2018-08-23 15:00:37 --> Config Class Initialized
INFO - 2018-08-23 15:00:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:37 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:37 --> URI Class Initialized
INFO - 2018-08-23 15:00:37 --> Router Class Initialized
INFO - 2018-08-23 15:00:37 --> Output Class Initialized
INFO - 2018-08-23 15:00:37 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:37 --> CSRF cookie sent
INFO - 2018-08-23 15:00:37 --> CSRF token verified
INFO - 2018-08-23 15:00:37 --> Input Class Initialized
INFO - 2018-08-23 15:00:37 --> Language Class Initialized
INFO - 2018-08-23 15:00:37 --> Loader Class Initialized
INFO - 2018-08-23 15:00:37 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:37 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:37 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:37 --> Controller Class Initialized
INFO - 2018-08-23 15:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:37 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:37 --> Form Validation Class Initialized
INFO - 2018-08-23 15:00:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:00:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:37 --> Config Class Initialized
INFO - 2018-08-23 15:00:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:37 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:37 --> URI Class Initialized
INFO - 2018-08-23 15:00:37 --> Router Class Initialized
INFO - 2018-08-23 15:00:37 --> Output Class Initialized
INFO - 2018-08-23 15:00:37 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:37 --> CSRF cookie sent
INFO - 2018-08-23 15:00:37 --> Input Class Initialized
INFO - 2018-08-23 15:00:37 --> Language Class Initialized
INFO - 2018-08-23 15:00:37 --> Loader Class Initialized
INFO - 2018-08-23 15:00:37 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:37 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:37 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:37 --> Controller Class Initialized
INFO - 2018-08-23 15:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:37 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 15:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:00:37 --> Final output sent to browser
DEBUG - 2018-08-23 15:00:37 --> Total execution time: 0.0587
INFO - 2018-08-23 15:00:41 --> Config Class Initialized
INFO - 2018-08-23 15:00:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:41 --> URI Class Initialized
INFO - 2018-08-23 15:00:41 --> Router Class Initialized
INFO - 2018-08-23 15:00:41 --> Output Class Initialized
INFO - 2018-08-23 15:00:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:41 --> CSRF cookie sent
INFO - 2018-08-23 15:00:41 --> CSRF token verified
INFO - 2018-08-23 15:00:41 --> Input Class Initialized
INFO - 2018-08-23 15:00:41 --> Language Class Initialized
INFO - 2018-08-23 15:00:41 --> Loader Class Initialized
INFO - 2018-08-23 15:00:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:41 --> Controller Class Initialized
INFO - 2018-08-23 15:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:41 --> Form Validation Class Initialized
INFO - 2018-08-23 15:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:00:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:41 --> Config Class Initialized
INFO - 2018-08-23 15:00:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:00:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:00:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:00:41 --> URI Class Initialized
INFO - 2018-08-23 15:00:41 --> Router Class Initialized
INFO - 2018-08-23 15:00:41 --> Output Class Initialized
INFO - 2018-08-23 15:00:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:00:41 --> CSRF cookie sent
INFO - 2018-08-23 15:00:41 --> Input Class Initialized
INFO - 2018-08-23 15:00:41 --> Language Class Initialized
INFO - 2018-08-23 15:00:41 --> Loader Class Initialized
INFO - 2018-08-23 15:00:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:00:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:00:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:00:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:00:41 --> Controller Class Initialized
INFO - 2018-08-23 15:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:00:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:00:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 15:00:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:00:41 --> Final output sent to browser
DEBUG - 2018-08-23 15:00:41 --> Total execution time: 0.0454
INFO - 2018-08-23 15:01:05 --> Config Class Initialized
INFO - 2018-08-23 15:01:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:01:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:01:05 --> Utf8 Class Initialized
INFO - 2018-08-23 15:01:05 --> URI Class Initialized
INFO - 2018-08-23 15:01:05 --> Router Class Initialized
INFO - 2018-08-23 15:01:05 --> Output Class Initialized
INFO - 2018-08-23 15:01:05 --> Security Class Initialized
DEBUG - 2018-08-23 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:01:05 --> CSRF cookie sent
INFO - 2018-08-23 15:01:05 --> Input Class Initialized
INFO - 2018-08-23 15:01:05 --> Language Class Initialized
INFO - 2018-08-23 15:01:05 --> Loader Class Initialized
INFO - 2018-08-23 15:01:05 --> Helper loaded: url_helper
INFO - 2018-08-23 15:01:05 --> Helper loaded: form_helper
INFO - 2018-08-23 15:01:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:01:05 --> User Agent Class Initialized
INFO - 2018-08-23 15:01:05 --> Controller Class Initialized
INFO - 2018-08-23 15:01:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:01:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:01:05 --> Pixel_Model class loaded
INFO - 2018-08-23 15:01:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:01:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:01:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:01:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 15:01:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:01:05 --> Final output sent to browser
DEBUG - 2018-08-23 15:01:05 --> Total execution time: 0.0459
INFO - 2018-08-23 15:02:46 --> Config Class Initialized
INFO - 2018-08-23 15:02:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:02:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:02:46 --> Utf8 Class Initialized
INFO - 2018-08-23 15:02:46 --> URI Class Initialized
INFO - 2018-08-23 15:02:46 --> Router Class Initialized
INFO - 2018-08-23 15:02:46 --> Output Class Initialized
INFO - 2018-08-23 15:02:46 --> Security Class Initialized
DEBUG - 2018-08-23 15:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:02:46 --> CSRF cookie sent
INFO - 2018-08-23 15:02:46 --> CSRF token verified
INFO - 2018-08-23 15:02:46 --> Input Class Initialized
INFO - 2018-08-23 15:02:46 --> Language Class Initialized
INFO - 2018-08-23 15:02:46 --> Loader Class Initialized
INFO - 2018-08-23 15:02:46 --> Helper loaded: url_helper
INFO - 2018-08-23 15:02:46 --> Helper loaded: form_helper
INFO - 2018-08-23 15:02:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:02:46 --> User Agent Class Initialized
INFO - 2018-08-23 15:02:46 --> Controller Class Initialized
INFO - 2018-08-23 15:02:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:02:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:02:46 --> Pixel_Model class loaded
INFO - 2018-08-23 15:02:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:02:46 --> Form Validation Class Initialized
INFO - 2018-08-23 15:02:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:02:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:02:48 --> Config Class Initialized
INFO - 2018-08-23 15:02:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:02:48 --> Utf8 Class Initialized
INFO - 2018-08-23 15:02:48 --> URI Class Initialized
INFO - 2018-08-23 15:02:48 --> Router Class Initialized
INFO - 2018-08-23 15:02:48 --> Output Class Initialized
INFO - 2018-08-23 15:02:48 --> Security Class Initialized
DEBUG - 2018-08-23 15:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:02:48 --> CSRF cookie sent
INFO - 2018-08-23 15:02:48 --> Input Class Initialized
INFO - 2018-08-23 15:02:48 --> Language Class Initialized
INFO - 2018-08-23 15:02:48 --> Loader Class Initialized
INFO - 2018-08-23 15:02:48 --> Helper loaded: url_helper
INFO - 2018-08-23 15:02:48 --> Helper loaded: form_helper
INFO - 2018-08-23 15:02:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:02:48 --> User Agent Class Initialized
INFO - 2018-08-23 15:02:48 --> Controller Class Initialized
INFO - 2018-08-23 15:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:02:48 --> Pixel_Model class loaded
INFO - 2018-08-23 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:02:48 --> Final output sent to browser
DEBUG - 2018-08-23 15:02:48 --> Total execution time: 0.0470
INFO - 2018-08-23 15:03:32 --> Config Class Initialized
INFO - 2018-08-23 15:03:32 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:32 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:32 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:32 --> URI Class Initialized
DEBUG - 2018-08-23 15:03:32 --> No URI present. Default controller set.
INFO - 2018-08-23 15:03:32 --> Router Class Initialized
INFO - 2018-08-23 15:03:32 --> Output Class Initialized
INFO - 2018-08-23 15:03:32 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:32 --> CSRF cookie sent
INFO - 2018-08-23 15:03:32 --> Input Class Initialized
INFO - 2018-08-23 15:03:32 --> Language Class Initialized
INFO - 2018-08-23 15:03:32 --> Loader Class Initialized
INFO - 2018-08-23 15:03:32 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:32 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:32 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:32 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:32 --> Controller Class Initialized
INFO - 2018-08-23 15:03:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:03:32 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:32 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:03:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:03:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:03:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 15:03:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:03:32 --> Final output sent to browser
DEBUG - 2018-08-23 15:03:32 --> Total execution time: 0.0355
INFO - 2018-08-23 15:03:36 --> Config Class Initialized
INFO - 2018-08-23 15:03:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:36 --> URI Class Initialized
INFO - 2018-08-23 15:03:36 --> Router Class Initialized
INFO - 2018-08-23 15:03:36 --> Output Class Initialized
INFO - 2018-08-23 15:03:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:36 --> CSRF cookie sent
INFO - 2018-08-23 15:03:36 --> Input Class Initialized
INFO - 2018-08-23 15:03:36 --> Language Class Initialized
INFO - 2018-08-23 15:03:36 --> Loader Class Initialized
INFO - 2018-08-23 15:03:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:36 --> Controller Class Initialized
INFO - 2018-08-23 15:03:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 15:03:36 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 15:03:36 --> Could not find the language line "req_email"
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-23 15:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:03:36 --> Final output sent to browser
DEBUG - 2018-08-23 15:03:36 --> Total execution time: 0.0346
INFO - 2018-08-23 15:03:40 --> Config Class Initialized
INFO - 2018-08-23 15:03:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:40 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:40 --> URI Class Initialized
INFO - 2018-08-23 15:03:40 --> Router Class Initialized
INFO - 2018-08-23 15:03:40 --> Output Class Initialized
INFO - 2018-08-23 15:03:40 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:40 --> CSRF cookie sent
INFO - 2018-08-23 15:03:40 --> CSRF token verified
INFO - 2018-08-23 15:03:40 --> Input Class Initialized
INFO - 2018-08-23 15:03:40 --> Language Class Initialized
INFO - 2018-08-23 15:03:40 --> Loader Class Initialized
INFO - 2018-08-23 15:03:40 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:40 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:40 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:40 --> Controller Class Initialized
INFO - 2018-08-23 15:03:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 15:03:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 15:03:40 --> Form Validation Class Initialized
INFO - 2018-08-23 15:03:40 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:40 --> Model "AuthenticationModel" initialized
INFO - 2018-08-23 15:03:40 --> Config Class Initialized
INFO - 2018-08-23 15:03:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:40 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:40 --> URI Class Initialized
DEBUG - 2018-08-23 15:03:40 --> No URI present. Default controller set.
INFO - 2018-08-23 15:03:40 --> Router Class Initialized
INFO - 2018-08-23 15:03:40 --> Output Class Initialized
INFO - 2018-08-23 15:03:40 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:40 --> CSRF cookie sent
INFO - 2018-08-23 15:03:40 --> Input Class Initialized
INFO - 2018-08-23 15:03:40 --> Language Class Initialized
INFO - 2018-08-23 15:03:40 --> Loader Class Initialized
INFO - 2018-08-23 15:03:40 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:40 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:40 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:40 --> Controller Class Initialized
INFO - 2018-08-23 15:03:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:03:40 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 15:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:03:40 --> Final output sent to browser
DEBUG - 2018-08-23 15:03:40 --> Total execution time: 0.0330
INFO - 2018-08-23 15:03:46 --> Config Class Initialized
INFO - 2018-08-23 15:03:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:46 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:46 --> URI Class Initialized
INFO - 2018-08-23 15:03:46 --> Router Class Initialized
INFO - 2018-08-23 15:03:46 --> Output Class Initialized
INFO - 2018-08-23 15:03:46 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:46 --> CSRF cookie sent
INFO - 2018-08-23 15:03:46 --> Input Class Initialized
INFO - 2018-08-23 15:03:46 --> Language Class Initialized
INFO - 2018-08-23 15:03:46 --> Loader Class Initialized
INFO - 2018-08-23 15:03:46 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:46 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:46 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:46 --> Controller Class Initialized
INFO - 2018-08-23 15:03:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:03:46 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:46 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-23 15:03:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:03:46 --> Final output sent to browser
DEBUG - 2018-08-23 15:03:46 --> Total execution time: 0.0350
INFO - 2018-08-23 15:03:48 --> Config Class Initialized
INFO - 2018-08-23 15:03:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:48 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:48 --> URI Class Initialized
INFO - 2018-08-23 15:03:48 --> Router Class Initialized
INFO - 2018-08-23 15:03:48 --> Output Class Initialized
INFO - 2018-08-23 15:03:48 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:48 --> CSRF cookie sent
INFO - 2018-08-23 15:03:48 --> Input Class Initialized
INFO - 2018-08-23 15:03:48 --> Language Class Initialized
INFO - 2018-08-23 15:03:48 --> Loader Class Initialized
INFO - 2018-08-23 15:03:48 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:48 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:48 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:48 --> Controller Class Initialized
INFO - 2018-08-23 15:03:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:03:48 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:48 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:48 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 15:03:48 --> Config Class Initialized
INFO - 2018-08-23 15:03:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:03:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:03:48 --> Utf8 Class Initialized
INFO - 2018-08-23 15:03:48 --> URI Class Initialized
INFO - 2018-08-23 15:03:48 --> Router Class Initialized
INFO - 2018-08-23 15:03:48 --> Output Class Initialized
INFO - 2018-08-23 15:03:48 --> Security Class Initialized
DEBUG - 2018-08-23 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:03:48 --> CSRF cookie sent
INFO - 2018-08-23 15:03:48 --> Input Class Initialized
INFO - 2018-08-23 15:03:48 --> Language Class Initialized
INFO - 2018-08-23 15:03:48 --> Loader Class Initialized
INFO - 2018-08-23 15:03:48 --> Helper loaded: url_helper
INFO - 2018-08-23 15:03:48 --> Helper loaded: form_helper
INFO - 2018-08-23 15:03:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:03:48 --> User Agent Class Initialized
INFO - 2018-08-23 15:03:48 --> Controller Class Initialized
INFO - 2018-08-23 15:03:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:03:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:03:48 --> Pixel_Model class loaded
INFO - 2018-08-23 15:03:48 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:03:48 --> Database Driver Class Initialized
INFO - 2018-08-23 15:03:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 15:03:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:03:48 --> Final output sent to browser
DEBUG - 2018-08-23 15:03:48 --> Total execution time: 0.0430
INFO - 2018-08-23 15:04:04 --> Config Class Initialized
INFO - 2018-08-23 15:04:04 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:04:04 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:04:04 --> Utf8 Class Initialized
INFO - 2018-08-23 15:04:04 --> URI Class Initialized
INFO - 2018-08-23 15:04:04 --> Router Class Initialized
INFO - 2018-08-23 15:04:04 --> Output Class Initialized
INFO - 2018-08-23 15:04:04 --> Security Class Initialized
DEBUG - 2018-08-23 15:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:04:04 --> CSRF cookie sent
INFO - 2018-08-23 15:04:04 --> Input Class Initialized
INFO - 2018-08-23 15:04:04 --> Language Class Initialized
INFO - 2018-08-23 15:04:04 --> Loader Class Initialized
INFO - 2018-08-23 15:04:04 --> Helper loaded: url_helper
INFO - 2018-08-23 15:04:04 --> Helper loaded: form_helper
INFO - 2018-08-23 15:04:04 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:04:04 --> User Agent Class Initialized
INFO - 2018-08-23 15:04:04 --> Controller Class Initialized
INFO - 2018-08-23 15:04:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:04:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:04:04 --> Pixel_Model class loaded
INFO - 2018-08-23 15:04:04 --> Database Driver Class Initialized
INFO - 2018-08-23 15:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:04:04 --> Database Driver Class Initialized
INFO - 2018-08-23 15:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 15:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:04:04 --> Final output sent to browser
DEBUG - 2018-08-23 15:04:04 --> Total execution time: 0.0453
INFO - 2018-08-23 15:18:02 --> Config Class Initialized
INFO - 2018-08-23 15:18:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:02 --> URI Class Initialized
INFO - 2018-08-23 15:18:02 --> Router Class Initialized
INFO - 2018-08-23 15:18:02 --> Output Class Initialized
INFO - 2018-08-23 15:18:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:02 --> CSRF cookie sent
INFO - 2018-08-23 15:18:02 --> CSRF token verified
INFO - 2018-08-23 15:18:02 --> Input Class Initialized
INFO - 2018-08-23 15:18:02 --> Language Class Initialized
INFO - 2018-08-23 15:18:02 --> Loader Class Initialized
INFO - 2018-08-23 15:18:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:02 --> Controller Class Initialized
INFO - 2018-08-23 15:18:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:02 --> Form Validation Class Initialized
INFO - 2018-08-23 15:18:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:18:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:02 --> Config Class Initialized
INFO - 2018-08-23 15:18:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:02 --> URI Class Initialized
INFO - 2018-08-23 15:18:02 --> Router Class Initialized
INFO - 2018-08-23 15:18:02 --> Output Class Initialized
INFO - 2018-08-23 15:18:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:02 --> CSRF cookie sent
INFO - 2018-08-23 15:18:02 --> Input Class Initialized
INFO - 2018-08-23 15:18:02 --> Language Class Initialized
INFO - 2018-08-23 15:18:02 --> Loader Class Initialized
INFO - 2018-08-23 15:18:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:02 --> Controller Class Initialized
INFO - 2018-08-23 15:18:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 15:18:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:18:02 --> Final output sent to browser
DEBUG - 2018-08-23 15:18:02 --> Total execution time: 0.0481
INFO - 2018-08-23 15:18:18 --> Config Class Initialized
INFO - 2018-08-23 15:18:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:18 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:18 --> URI Class Initialized
INFO - 2018-08-23 15:18:18 --> Router Class Initialized
INFO - 2018-08-23 15:18:18 --> Output Class Initialized
INFO - 2018-08-23 15:18:18 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:18 --> CSRF cookie sent
INFO - 2018-08-23 15:18:18 --> CSRF token verified
INFO - 2018-08-23 15:18:18 --> Input Class Initialized
INFO - 2018-08-23 15:18:18 --> Language Class Initialized
INFO - 2018-08-23 15:18:18 --> Loader Class Initialized
INFO - 2018-08-23 15:18:18 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:18 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:18 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:18 --> Controller Class Initialized
INFO - 2018-08-23 15:18:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:18 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:18 --> Form Validation Class Initialized
INFO - 2018-08-23 15:18:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:18:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:18 --> Config Class Initialized
INFO - 2018-08-23 15:18:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:18 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:18 --> URI Class Initialized
INFO - 2018-08-23 15:18:18 --> Router Class Initialized
INFO - 2018-08-23 15:18:18 --> Output Class Initialized
INFO - 2018-08-23 15:18:18 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:18 --> CSRF cookie sent
INFO - 2018-08-23 15:18:18 --> Input Class Initialized
INFO - 2018-08-23 15:18:18 --> Language Class Initialized
INFO - 2018-08-23 15:18:18 --> Loader Class Initialized
INFO - 2018-08-23 15:18:18 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:18 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:18 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:18 --> Controller Class Initialized
INFO - 2018-08-23 15:18:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:18 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 15:18:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:18:18 --> Final output sent to browser
DEBUG - 2018-08-23 15:18:18 --> Total execution time: 0.0441
INFO - 2018-08-23 15:18:28 --> Config Class Initialized
INFO - 2018-08-23 15:18:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:28 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:28 --> URI Class Initialized
INFO - 2018-08-23 15:18:28 --> Router Class Initialized
INFO - 2018-08-23 15:18:28 --> Output Class Initialized
INFO - 2018-08-23 15:18:28 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:28 --> CSRF cookie sent
INFO - 2018-08-23 15:18:28 --> CSRF token verified
INFO - 2018-08-23 15:18:28 --> Input Class Initialized
INFO - 2018-08-23 15:18:28 --> Language Class Initialized
INFO - 2018-08-23 15:18:28 --> Loader Class Initialized
INFO - 2018-08-23 15:18:28 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:28 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:28 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:28 --> Controller Class Initialized
INFO - 2018-08-23 15:18:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:28 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:28 --> Form Validation Class Initialized
INFO - 2018-08-23 15:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:18:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:28 --> Config Class Initialized
INFO - 2018-08-23 15:18:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:28 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:28 --> URI Class Initialized
INFO - 2018-08-23 15:18:28 --> Router Class Initialized
INFO - 2018-08-23 15:18:28 --> Output Class Initialized
INFO - 2018-08-23 15:18:28 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:28 --> CSRF cookie sent
INFO - 2018-08-23 15:18:28 --> Input Class Initialized
INFO - 2018-08-23 15:18:28 --> Language Class Initialized
INFO - 2018-08-23 15:18:28 --> Loader Class Initialized
INFO - 2018-08-23 15:18:28 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:28 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:28 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:28 --> Controller Class Initialized
INFO - 2018-08-23 15:18:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:28 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 15:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:18:28 --> Final output sent to browser
DEBUG - 2018-08-23 15:18:28 --> Total execution time: 0.0433
INFO - 2018-08-23 15:18:42 --> Config Class Initialized
INFO - 2018-08-23 15:18:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:42 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:42 --> URI Class Initialized
INFO - 2018-08-23 15:18:42 --> Router Class Initialized
INFO - 2018-08-23 15:18:42 --> Output Class Initialized
INFO - 2018-08-23 15:18:42 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:42 --> CSRF cookie sent
INFO - 2018-08-23 15:18:42 --> CSRF token verified
INFO - 2018-08-23 15:18:42 --> Input Class Initialized
INFO - 2018-08-23 15:18:42 --> Language Class Initialized
INFO - 2018-08-23 15:18:42 --> Loader Class Initialized
INFO - 2018-08-23 15:18:42 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:42 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:42 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:42 --> Controller Class Initialized
INFO - 2018-08-23 15:18:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:42 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:42 --> Form Validation Class Initialized
INFO - 2018-08-23 15:18:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:18:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:42 --> Config Class Initialized
INFO - 2018-08-23 15:18:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:42 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:42 --> URI Class Initialized
INFO - 2018-08-23 15:18:42 --> Router Class Initialized
INFO - 2018-08-23 15:18:42 --> Output Class Initialized
INFO - 2018-08-23 15:18:42 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:42 --> CSRF cookie sent
INFO - 2018-08-23 15:18:42 --> Input Class Initialized
INFO - 2018-08-23 15:18:42 --> Language Class Initialized
INFO - 2018-08-23 15:18:42 --> Loader Class Initialized
INFO - 2018-08-23 15:18:42 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:42 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:42 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:42 --> Controller Class Initialized
INFO - 2018-08-23 15:18:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:42 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 15:18:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:18:42 --> Final output sent to browser
DEBUG - 2018-08-23 15:18:42 --> Total execution time: 0.0552
INFO - 2018-08-23 15:18:56 --> Config Class Initialized
INFO - 2018-08-23 15:18:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:56 --> URI Class Initialized
INFO - 2018-08-23 15:18:56 --> Router Class Initialized
INFO - 2018-08-23 15:18:56 --> Output Class Initialized
INFO - 2018-08-23 15:18:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:56 --> CSRF cookie sent
INFO - 2018-08-23 15:18:56 --> CSRF token verified
INFO - 2018-08-23 15:18:56 --> Input Class Initialized
INFO - 2018-08-23 15:18:56 --> Language Class Initialized
INFO - 2018-08-23 15:18:56 --> Loader Class Initialized
INFO - 2018-08-23 15:18:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:56 --> Controller Class Initialized
INFO - 2018-08-23 15:18:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:56 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:56 --> Form Validation Class Initialized
INFO - 2018-08-23 15:18:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:18:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:56 --> Config Class Initialized
INFO - 2018-08-23 15:18:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:18:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:18:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:18:56 --> URI Class Initialized
INFO - 2018-08-23 15:18:56 --> Router Class Initialized
INFO - 2018-08-23 15:18:56 --> Output Class Initialized
INFO - 2018-08-23 15:18:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:18:56 --> CSRF cookie sent
INFO - 2018-08-23 15:18:56 --> Input Class Initialized
INFO - 2018-08-23 15:18:56 --> Language Class Initialized
INFO - 2018-08-23 15:18:56 --> Loader Class Initialized
INFO - 2018-08-23 15:18:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:18:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:18:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:18:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:18:56 --> Controller Class Initialized
INFO - 2018-08-23 15:18:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:18:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:18:57 --> Pixel_Model class loaded
INFO - 2018-08-23 15:18:57 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:57 --> Database Driver Class Initialized
INFO - 2018-08-23 15:18:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-23 15:18:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:18:57 --> Final output sent to browser
DEBUG - 2018-08-23 15:18:57 --> Total execution time: 0.0544
INFO - 2018-08-23 15:19:02 --> Config Class Initialized
INFO - 2018-08-23 15:19:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:02 --> URI Class Initialized
INFO - 2018-08-23 15:19:02 --> Router Class Initialized
INFO - 2018-08-23 15:19:02 --> Output Class Initialized
INFO - 2018-08-23 15:19:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:02 --> CSRF cookie sent
INFO - 2018-08-23 15:19:02 --> CSRF token verified
INFO - 2018-08-23 15:19:02 --> Input Class Initialized
INFO - 2018-08-23 15:19:02 --> Language Class Initialized
INFO - 2018-08-23 15:19:02 --> Loader Class Initialized
INFO - 2018-08-23 15:19:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:02 --> Controller Class Initialized
INFO - 2018-08-23 15:19:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:02 --> Form Validation Class Initialized
INFO - 2018-08-23 15:19:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:19:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:02 --> Config Class Initialized
INFO - 2018-08-23 15:19:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:02 --> URI Class Initialized
INFO - 2018-08-23 15:19:02 --> Router Class Initialized
INFO - 2018-08-23 15:19:02 --> Output Class Initialized
INFO - 2018-08-23 15:19:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:02 --> CSRF cookie sent
INFO - 2018-08-23 15:19:02 --> Input Class Initialized
INFO - 2018-08-23 15:19:02 --> Language Class Initialized
INFO - 2018-08-23 15:19:02 --> Loader Class Initialized
INFO - 2018-08-23 15:19:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:02 --> Controller Class Initialized
INFO - 2018-08-23 15:19:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 15:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:19:02 --> Final output sent to browser
DEBUG - 2018-08-23 15:19:02 --> Total execution time: 0.0446
INFO - 2018-08-23 15:19:12 --> Config Class Initialized
INFO - 2018-08-23 15:19:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:12 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:12 --> URI Class Initialized
INFO - 2018-08-23 15:19:12 --> Router Class Initialized
INFO - 2018-08-23 15:19:12 --> Output Class Initialized
INFO - 2018-08-23 15:19:12 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:12 --> CSRF cookie sent
INFO - 2018-08-23 15:19:12 --> CSRF token verified
INFO - 2018-08-23 15:19:12 --> Input Class Initialized
INFO - 2018-08-23 15:19:12 --> Language Class Initialized
INFO - 2018-08-23 15:19:12 --> Loader Class Initialized
INFO - 2018-08-23 15:19:12 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:12 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:12 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:12 --> Controller Class Initialized
INFO - 2018-08-23 15:19:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:12 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:12 --> Form Validation Class Initialized
INFO - 2018-08-23 15:19:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:19:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:12 --> Config Class Initialized
INFO - 2018-08-23 15:19:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:12 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:12 --> URI Class Initialized
INFO - 2018-08-23 15:19:12 --> Router Class Initialized
INFO - 2018-08-23 15:19:12 --> Output Class Initialized
INFO - 2018-08-23 15:19:12 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:12 --> CSRF cookie sent
INFO - 2018-08-23 15:19:12 --> Input Class Initialized
INFO - 2018-08-23 15:19:12 --> Language Class Initialized
INFO - 2018-08-23 15:19:12 --> Loader Class Initialized
INFO - 2018-08-23 15:19:12 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:12 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:12 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:12 --> Controller Class Initialized
INFO - 2018-08-23 15:19:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:12 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-23 15:19:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:19:12 --> Final output sent to browser
DEBUG - 2018-08-23 15:19:12 --> Total execution time: 0.0324
INFO - 2018-08-23 15:19:39 --> Config Class Initialized
INFO - 2018-08-23 15:19:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:39 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:39 --> URI Class Initialized
INFO - 2018-08-23 15:19:39 --> Router Class Initialized
INFO - 2018-08-23 15:19:39 --> Output Class Initialized
INFO - 2018-08-23 15:19:39 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:39 --> CSRF cookie sent
INFO - 2018-08-23 15:19:39 --> CSRF token verified
INFO - 2018-08-23 15:19:39 --> Input Class Initialized
INFO - 2018-08-23 15:19:39 --> Language Class Initialized
INFO - 2018-08-23 15:19:39 --> Loader Class Initialized
INFO - 2018-08-23 15:19:39 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:39 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:39 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:39 --> Controller Class Initialized
INFO - 2018-08-23 15:19:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:39 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:39 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:39 --> Form Validation Class Initialized
INFO - 2018-08-23 15:19:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:19:39 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:39 --> Config Class Initialized
INFO - 2018-08-23 15:19:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:39 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:39 --> URI Class Initialized
INFO - 2018-08-23 15:19:39 --> Router Class Initialized
INFO - 2018-08-23 15:19:39 --> Output Class Initialized
INFO - 2018-08-23 15:19:39 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:39 --> CSRF cookie sent
INFO - 2018-08-23 15:19:39 --> Input Class Initialized
INFO - 2018-08-23 15:19:39 --> Language Class Initialized
INFO - 2018-08-23 15:19:39 --> Loader Class Initialized
INFO - 2018-08-23 15:19:39 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:39 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:39 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:39 --> Controller Class Initialized
INFO - 2018-08-23 15:19:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:39 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:39 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:39 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-23 15:19:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:19:39 --> Final output sent to browser
DEBUG - 2018-08-23 15:19:39 --> Total execution time: 0.0378
INFO - 2018-08-23 15:19:49 --> Config Class Initialized
INFO - 2018-08-23 15:19:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:49 --> URI Class Initialized
INFO - 2018-08-23 15:19:49 --> Router Class Initialized
INFO - 2018-08-23 15:19:49 --> Output Class Initialized
INFO - 2018-08-23 15:19:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:49 --> CSRF cookie sent
INFO - 2018-08-23 15:19:49 --> CSRF token verified
INFO - 2018-08-23 15:19:49 --> Input Class Initialized
INFO - 2018-08-23 15:19:49 --> Language Class Initialized
INFO - 2018-08-23 15:19:49 --> Loader Class Initialized
INFO - 2018-08-23 15:19:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:49 --> Controller Class Initialized
INFO - 2018-08-23 15:19:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:49 --> Form Validation Class Initialized
INFO - 2018-08-23 15:19:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:19:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:49 --> Config Class Initialized
INFO - 2018-08-23 15:19:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:49 --> URI Class Initialized
INFO - 2018-08-23 15:19:49 --> Router Class Initialized
INFO - 2018-08-23 15:19:49 --> Output Class Initialized
INFO - 2018-08-23 15:19:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:49 --> CSRF cookie sent
INFO - 2018-08-23 15:19:49 --> Input Class Initialized
INFO - 2018-08-23 15:19:49 --> Language Class Initialized
INFO - 2018-08-23 15:19:49 --> Loader Class Initialized
INFO - 2018-08-23 15:19:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:49 --> Controller Class Initialized
INFO - 2018-08-23 15:19:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-23 15:19:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:19:49 --> Final output sent to browser
DEBUG - 2018-08-23 15:19:49 --> Total execution time: 0.0441
INFO - 2018-08-23 15:19:58 --> Config Class Initialized
INFO - 2018-08-23 15:19:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:58 --> URI Class Initialized
INFO - 2018-08-23 15:19:58 --> Router Class Initialized
INFO - 2018-08-23 15:19:58 --> Output Class Initialized
INFO - 2018-08-23 15:19:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:58 --> CSRF cookie sent
INFO - 2018-08-23 15:19:58 --> CSRF token verified
INFO - 2018-08-23 15:19:58 --> Input Class Initialized
INFO - 2018-08-23 15:19:58 --> Language Class Initialized
INFO - 2018-08-23 15:19:58 --> Loader Class Initialized
INFO - 2018-08-23 15:19:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:58 --> Controller Class Initialized
INFO - 2018-08-23 15:19:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:58 --> Form Validation Class Initialized
INFO - 2018-08-23 15:19:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:19:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:58 --> Config Class Initialized
INFO - 2018-08-23 15:19:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:19:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:19:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:19:58 --> URI Class Initialized
INFO - 2018-08-23 15:19:58 --> Router Class Initialized
INFO - 2018-08-23 15:19:58 --> Output Class Initialized
INFO - 2018-08-23 15:19:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:19:58 --> CSRF cookie sent
INFO - 2018-08-23 15:19:58 --> Input Class Initialized
INFO - 2018-08-23 15:19:58 --> Language Class Initialized
INFO - 2018-08-23 15:19:58 --> Loader Class Initialized
INFO - 2018-08-23 15:19:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:19:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:19:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:19:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:19:58 --> Controller Class Initialized
INFO - 2018-08-23 15:19:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:19:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:19:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:19:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-08-23 15:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:19:58 --> Final output sent to browser
DEBUG - 2018-08-23 15:19:58 --> Total execution time: 0.0430
INFO - 2018-08-23 15:20:06 --> Config Class Initialized
INFO - 2018-08-23 15:20:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:06 --> URI Class Initialized
INFO - 2018-08-23 15:20:06 --> Router Class Initialized
INFO - 2018-08-23 15:20:06 --> Output Class Initialized
INFO - 2018-08-23 15:20:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:06 --> CSRF cookie sent
INFO - 2018-08-23 15:20:06 --> CSRF token verified
INFO - 2018-08-23 15:20:06 --> Input Class Initialized
INFO - 2018-08-23 15:20:06 --> Language Class Initialized
INFO - 2018-08-23 15:20:06 --> Loader Class Initialized
INFO - 2018-08-23 15:20:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:06 --> Controller Class Initialized
INFO - 2018-08-23 15:20:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:06 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:06 --> Config Class Initialized
INFO - 2018-08-23 15:20:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:06 --> URI Class Initialized
INFO - 2018-08-23 15:20:06 --> Router Class Initialized
INFO - 2018-08-23 15:20:06 --> Output Class Initialized
INFO - 2018-08-23 15:20:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:06 --> CSRF cookie sent
INFO - 2018-08-23 15:20:06 --> Input Class Initialized
INFO - 2018-08-23 15:20:06 --> Language Class Initialized
INFO - 2018-08-23 15:20:06 --> Loader Class Initialized
INFO - 2018-08-23 15:20:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:06 --> Controller Class Initialized
INFO - 2018-08-23 15:20:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-08-23 15:20:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:06 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:06 --> Total execution time: 0.0439
INFO - 2018-08-23 15:20:14 --> Config Class Initialized
INFO - 2018-08-23 15:20:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:14 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:14 --> URI Class Initialized
INFO - 2018-08-23 15:20:14 --> Router Class Initialized
INFO - 2018-08-23 15:20:14 --> Output Class Initialized
INFO - 2018-08-23 15:20:14 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:14 --> CSRF cookie sent
INFO - 2018-08-23 15:20:14 --> CSRF token verified
INFO - 2018-08-23 15:20:14 --> Input Class Initialized
INFO - 2018-08-23 15:20:14 --> Language Class Initialized
INFO - 2018-08-23 15:20:15 --> Loader Class Initialized
INFO - 2018-08-23 15:20:15 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:15 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:15 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:15 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:15 --> Controller Class Initialized
INFO - 2018-08-23 15:20:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:15 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:15 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:15 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:15 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:15 --> Config Class Initialized
INFO - 2018-08-23 15:20:15 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:15 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:15 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:15 --> URI Class Initialized
INFO - 2018-08-23 15:20:15 --> Router Class Initialized
INFO - 2018-08-23 15:20:15 --> Output Class Initialized
INFO - 2018-08-23 15:20:15 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:15 --> CSRF cookie sent
INFO - 2018-08-23 15:20:15 --> Input Class Initialized
INFO - 2018-08-23 15:20:15 --> Language Class Initialized
INFO - 2018-08-23 15:20:15 --> Loader Class Initialized
INFO - 2018-08-23 15:20:15 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:15 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:15 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:15 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:15 --> Controller Class Initialized
INFO - 2018-08-23 15:20:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:15 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:15 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:15 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-08-23 15:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:15 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:15 --> Total execution time: 0.0519
INFO - 2018-08-23 15:20:21 --> Config Class Initialized
INFO - 2018-08-23 15:20:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:21 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:21 --> URI Class Initialized
INFO - 2018-08-23 15:20:21 --> Router Class Initialized
INFO - 2018-08-23 15:20:21 --> Output Class Initialized
INFO - 2018-08-23 15:20:21 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:21 --> CSRF cookie sent
INFO - 2018-08-23 15:20:21 --> CSRF token verified
INFO - 2018-08-23 15:20:21 --> Input Class Initialized
INFO - 2018-08-23 15:20:21 --> Language Class Initialized
INFO - 2018-08-23 15:20:21 --> Loader Class Initialized
INFO - 2018-08-23 15:20:21 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:21 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:21 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:21 --> Controller Class Initialized
INFO - 2018-08-23 15:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:21 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:21 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:21 --> Config Class Initialized
INFO - 2018-08-23 15:20:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:21 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:21 --> URI Class Initialized
INFO - 2018-08-23 15:20:21 --> Router Class Initialized
INFO - 2018-08-23 15:20:21 --> Output Class Initialized
INFO - 2018-08-23 15:20:21 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:21 --> CSRF cookie sent
INFO - 2018-08-23 15:20:21 --> Input Class Initialized
INFO - 2018-08-23 15:20:21 --> Language Class Initialized
INFO - 2018-08-23 15:20:21 --> Loader Class Initialized
INFO - 2018-08-23 15:20:21 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:21 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:21 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:21 --> Controller Class Initialized
INFO - 2018-08-23 15:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:21 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-08-23 15:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:21 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:21 --> Total execution time: 0.0424
INFO - 2018-08-23 15:20:27 --> Config Class Initialized
INFO - 2018-08-23 15:20:27 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:27 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:27 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:27 --> URI Class Initialized
INFO - 2018-08-23 15:20:27 --> Router Class Initialized
INFO - 2018-08-23 15:20:27 --> Output Class Initialized
INFO - 2018-08-23 15:20:27 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:27 --> CSRF cookie sent
INFO - 2018-08-23 15:20:27 --> CSRF token verified
INFO - 2018-08-23 15:20:27 --> Input Class Initialized
INFO - 2018-08-23 15:20:27 --> Language Class Initialized
INFO - 2018-08-23 15:20:27 --> Loader Class Initialized
INFO - 2018-08-23 15:20:27 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:27 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:27 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:27 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:27 --> Controller Class Initialized
INFO - 2018-08-23 15:20:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:27 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:27 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:27 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:27 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:27 --> Config Class Initialized
INFO - 2018-08-23 15:20:27 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:27 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:27 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:27 --> URI Class Initialized
INFO - 2018-08-23 15:20:27 --> Router Class Initialized
INFO - 2018-08-23 15:20:27 --> Output Class Initialized
INFO - 2018-08-23 15:20:27 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:27 --> CSRF cookie sent
INFO - 2018-08-23 15:20:27 --> Input Class Initialized
INFO - 2018-08-23 15:20:27 --> Language Class Initialized
INFO - 2018-08-23 15:20:27 --> Loader Class Initialized
INFO - 2018-08-23 15:20:27 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:27 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:27 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:27 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:27 --> Controller Class Initialized
INFO - 2018-08-23 15:20:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:27 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:27 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:27 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-08-23 15:20:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:27 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:27 --> Total execution time: 0.0463
INFO - 2018-08-23 15:20:36 --> Config Class Initialized
INFO - 2018-08-23 15:20:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:36 --> URI Class Initialized
INFO - 2018-08-23 15:20:36 --> Router Class Initialized
INFO - 2018-08-23 15:20:36 --> Output Class Initialized
INFO - 2018-08-23 15:20:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:36 --> CSRF cookie sent
INFO - 2018-08-23 15:20:36 --> CSRF token verified
INFO - 2018-08-23 15:20:36 --> Input Class Initialized
INFO - 2018-08-23 15:20:36 --> Language Class Initialized
INFO - 2018-08-23 15:20:36 --> Loader Class Initialized
INFO - 2018-08-23 15:20:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:36 --> Controller Class Initialized
INFO - 2018-08-23 15:20:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:36 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:37 --> Config Class Initialized
INFO - 2018-08-23 15:20:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:37 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:37 --> URI Class Initialized
INFO - 2018-08-23 15:20:37 --> Router Class Initialized
INFO - 2018-08-23 15:20:37 --> Output Class Initialized
INFO - 2018-08-23 15:20:37 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:37 --> CSRF cookie sent
INFO - 2018-08-23 15:20:37 --> Input Class Initialized
INFO - 2018-08-23 15:20:37 --> Language Class Initialized
INFO - 2018-08-23 15:20:37 --> Loader Class Initialized
INFO - 2018-08-23 15:20:37 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:37 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:37 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:37 --> Controller Class Initialized
INFO - 2018-08-23 15:20:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:37 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-08-23 15:20:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:37 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:37 --> Total execution time: 0.0457
INFO - 2018-08-23 15:20:50 --> Config Class Initialized
INFO - 2018-08-23 15:20:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:50 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:50 --> URI Class Initialized
INFO - 2018-08-23 15:20:50 --> Router Class Initialized
INFO - 2018-08-23 15:20:50 --> Output Class Initialized
INFO - 2018-08-23 15:20:50 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:50 --> CSRF cookie sent
INFO - 2018-08-23 15:20:50 --> CSRF token verified
INFO - 2018-08-23 15:20:50 --> Input Class Initialized
INFO - 2018-08-23 15:20:50 --> Language Class Initialized
INFO - 2018-08-23 15:20:50 --> Loader Class Initialized
INFO - 2018-08-23 15:20:50 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:50 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:50 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:50 --> Controller Class Initialized
INFO - 2018-08-23 15:20:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:50 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:50 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:50 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:50 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:50 --> Config Class Initialized
INFO - 2018-08-23 15:20:50 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:50 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:50 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:50 --> URI Class Initialized
INFO - 2018-08-23 15:20:50 --> Router Class Initialized
INFO - 2018-08-23 15:20:50 --> Output Class Initialized
INFO - 2018-08-23 15:20:50 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:50 --> CSRF cookie sent
INFO - 2018-08-23 15:20:50 --> Input Class Initialized
INFO - 2018-08-23 15:20:50 --> Language Class Initialized
INFO - 2018-08-23 15:20:50 --> Loader Class Initialized
INFO - 2018-08-23 15:20:50 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:50 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:50 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:50 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:50 --> Controller Class Initialized
INFO - 2018-08-23 15:20:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:50 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:50 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:50 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-23 15:20:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:50 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:50 --> Total execution time: 0.0382
INFO - 2018-08-23 15:20:56 --> Config Class Initialized
INFO - 2018-08-23 15:20:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:56 --> URI Class Initialized
INFO - 2018-08-23 15:20:56 --> Router Class Initialized
INFO - 2018-08-23 15:20:56 --> Output Class Initialized
INFO - 2018-08-23 15:20:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:56 --> CSRF cookie sent
INFO - 2018-08-23 15:20:56 --> CSRF token verified
INFO - 2018-08-23 15:20:56 --> Input Class Initialized
INFO - 2018-08-23 15:20:56 --> Language Class Initialized
INFO - 2018-08-23 15:20:56 --> Loader Class Initialized
INFO - 2018-08-23 15:20:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:56 --> Controller Class Initialized
INFO - 2018-08-23 15:20:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:56 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:56 --> Form Validation Class Initialized
INFO - 2018-08-23 15:20:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:20:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:56 --> Config Class Initialized
INFO - 2018-08-23 15:20:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:20:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:20:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:20:56 --> URI Class Initialized
INFO - 2018-08-23 15:20:56 --> Router Class Initialized
INFO - 2018-08-23 15:20:56 --> Output Class Initialized
INFO - 2018-08-23 15:20:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:20:56 --> CSRF cookie sent
INFO - 2018-08-23 15:20:56 --> Input Class Initialized
INFO - 2018-08-23 15:20:56 --> Language Class Initialized
INFO - 2018-08-23 15:20:56 --> Loader Class Initialized
INFO - 2018-08-23 15:20:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:20:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:20:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:20:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:20:56 --> Controller Class Initialized
INFO - 2018-08-23 15:20:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:20:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:20:56 --> Pixel_Model class loaded
INFO - 2018-08-23 15:20:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:20:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-23 15:20:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:20:56 --> Final output sent to browser
DEBUG - 2018-08-23 15:20:56 --> Total execution time: 0.0503
INFO - 2018-08-23 15:21:02 --> Config Class Initialized
INFO - 2018-08-23 15:21:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:02 --> URI Class Initialized
INFO - 2018-08-23 15:21:02 --> Router Class Initialized
INFO - 2018-08-23 15:21:02 --> Output Class Initialized
INFO - 2018-08-23 15:21:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:02 --> CSRF cookie sent
INFO - 2018-08-23 15:21:02 --> CSRF token verified
INFO - 2018-08-23 15:21:02 --> Input Class Initialized
INFO - 2018-08-23 15:21:02 --> Language Class Initialized
INFO - 2018-08-23 15:21:02 --> Loader Class Initialized
INFO - 2018-08-23 15:21:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:02 --> Controller Class Initialized
INFO - 2018-08-23 15:21:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:02 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:02 --> Config Class Initialized
INFO - 2018-08-23 15:21:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:02 --> URI Class Initialized
INFO - 2018-08-23 15:21:02 --> Router Class Initialized
INFO - 2018-08-23 15:21:02 --> Output Class Initialized
INFO - 2018-08-23 15:21:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:02 --> CSRF cookie sent
INFO - 2018-08-23 15:21:02 --> Input Class Initialized
INFO - 2018-08-23 15:21:02 --> Language Class Initialized
INFO - 2018-08-23 15:21:02 --> Loader Class Initialized
INFO - 2018-08-23 15:21:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:02 --> Controller Class Initialized
INFO - 2018-08-23 15:21:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-23 15:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:02 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:02 --> Total execution time: 0.0426
INFO - 2018-08-23 15:21:07 --> Config Class Initialized
INFO - 2018-08-23 15:21:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:07 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:07 --> URI Class Initialized
INFO - 2018-08-23 15:21:07 --> Router Class Initialized
INFO - 2018-08-23 15:21:07 --> Output Class Initialized
INFO - 2018-08-23 15:21:07 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:07 --> CSRF cookie sent
INFO - 2018-08-23 15:21:07 --> CSRF token verified
INFO - 2018-08-23 15:21:07 --> Input Class Initialized
INFO - 2018-08-23 15:21:07 --> Language Class Initialized
INFO - 2018-08-23 15:21:07 --> Loader Class Initialized
INFO - 2018-08-23 15:21:07 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:07 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:07 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:07 --> Controller Class Initialized
INFO - 2018-08-23 15:21:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:07 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:07 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:07 --> Config Class Initialized
INFO - 2018-08-23 15:21:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:07 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:07 --> URI Class Initialized
INFO - 2018-08-23 15:21:07 --> Router Class Initialized
INFO - 2018-08-23 15:21:07 --> Output Class Initialized
INFO - 2018-08-23 15:21:07 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:07 --> CSRF cookie sent
INFO - 2018-08-23 15:21:07 --> Input Class Initialized
INFO - 2018-08-23 15:21:07 --> Language Class Initialized
INFO - 2018-08-23 15:21:07 --> Loader Class Initialized
INFO - 2018-08-23 15:21:07 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:07 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:07 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:07 --> Controller Class Initialized
INFO - 2018-08-23 15:21:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:07 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-23 15:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:07 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:07 --> Total execution time: 0.0649
INFO - 2018-08-23 15:21:19 --> Config Class Initialized
INFO - 2018-08-23 15:21:19 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:19 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:19 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:19 --> URI Class Initialized
INFO - 2018-08-23 15:21:19 --> Router Class Initialized
INFO - 2018-08-23 15:21:19 --> Output Class Initialized
INFO - 2018-08-23 15:21:19 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:19 --> CSRF cookie sent
INFO - 2018-08-23 15:21:19 --> CSRF token verified
INFO - 2018-08-23 15:21:19 --> Input Class Initialized
INFO - 2018-08-23 15:21:19 --> Language Class Initialized
INFO - 2018-08-23 15:21:19 --> Loader Class Initialized
INFO - 2018-08-23 15:21:19 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:19 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:19 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:19 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:19 --> Controller Class Initialized
INFO - 2018-08-23 15:21:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:19 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:19 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:20 --> Config Class Initialized
INFO - 2018-08-23 15:21:20 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:20 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:20 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:20 --> URI Class Initialized
INFO - 2018-08-23 15:21:20 --> Router Class Initialized
INFO - 2018-08-23 15:21:20 --> Output Class Initialized
INFO - 2018-08-23 15:21:20 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:20 --> CSRF cookie sent
INFO - 2018-08-23 15:21:20 --> Input Class Initialized
INFO - 2018-08-23 15:21:20 --> Language Class Initialized
INFO - 2018-08-23 15:21:20 --> Loader Class Initialized
INFO - 2018-08-23 15:21:20 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:20 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:20 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:20 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:20 --> Controller Class Initialized
INFO - 2018-08-23 15:21:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:20 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-23 15:21:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:20 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:20 --> Total execution time: 0.0487
INFO - 2018-08-23 15:21:29 --> Config Class Initialized
INFO - 2018-08-23 15:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:29 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:29 --> URI Class Initialized
INFO - 2018-08-23 15:21:29 --> Router Class Initialized
INFO - 2018-08-23 15:21:29 --> Output Class Initialized
INFO - 2018-08-23 15:21:29 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:29 --> CSRF cookie sent
INFO - 2018-08-23 15:21:29 --> CSRF token verified
INFO - 2018-08-23 15:21:29 --> Input Class Initialized
INFO - 2018-08-23 15:21:29 --> Language Class Initialized
INFO - 2018-08-23 15:21:29 --> Loader Class Initialized
INFO - 2018-08-23 15:21:29 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:29 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:29 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:29 --> Controller Class Initialized
INFO - 2018-08-23 15:21:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:29 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:29 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:29 --> Config Class Initialized
INFO - 2018-08-23 15:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:29 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:29 --> URI Class Initialized
INFO - 2018-08-23 15:21:29 --> Router Class Initialized
INFO - 2018-08-23 15:21:29 --> Output Class Initialized
INFO - 2018-08-23 15:21:29 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:29 --> CSRF cookie sent
INFO - 2018-08-23 15:21:29 --> Input Class Initialized
INFO - 2018-08-23 15:21:29 --> Language Class Initialized
INFO - 2018-08-23 15:21:29 --> Loader Class Initialized
INFO - 2018-08-23 15:21:29 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:29 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:29 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:29 --> Controller Class Initialized
INFO - 2018-08-23 15:21:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:29 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-08-23 15:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:29 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:29 --> Total execution time: 0.0406
INFO - 2018-08-23 15:21:36 --> Config Class Initialized
INFO - 2018-08-23 15:21:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:36 --> URI Class Initialized
INFO - 2018-08-23 15:21:36 --> Router Class Initialized
INFO - 2018-08-23 15:21:36 --> Output Class Initialized
INFO - 2018-08-23 15:21:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:36 --> CSRF cookie sent
INFO - 2018-08-23 15:21:36 --> CSRF token verified
INFO - 2018-08-23 15:21:36 --> Input Class Initialized
INFO - 2018-08-23 15:21:36 --> Language Class Initialized
INFO - 2018-08-23 15:21:36 --> Loader Class Initialized
INFO - 2018-08-23 15:21:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:36 --> Controller Class Initialized
INFO - 2018-08-23 15:21:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:36 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:36 --> Config Class Initialized
INFO - 2018-08-23 15:21:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:36 --> URI Class Initialized
INFO - 2018-08-23 15:21:36 --> Router Class Initialized
INFO - 2018-08-23 15:21:36 --> Output Class Initialized
INFO - 2018-08-23 15:21:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:36 --> CSRF cookie sent
INFO - 2018-08-23 15:21:36 --> Input Class Initialized
INFO - 2018-08-23 15:21:36 --> Language Class Initialized
INFO - 2018-08-23 15:21:36 --> Loader Class Initialized
INFO - 2018-08-23 15:21:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:36 --> Controller Class Initialized
INFO - 2018-08-23 15:21:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-23 15:21:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:36 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:36 --> Total execution time: 0.0461
INFO - 2018-08-23 15:21:40 --> Config Class Initialized
INFO - 2018-08-23 15:21:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:40 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:40 --> URI Class Initialized
INFO - 2018-08-23 15:21:40 --> Router Class Initialized
INFO - 2018-08-23 15:21:40 --> Output Class Initialized
INFO - 2018-08-23 15:21:40 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:40 --> CSRF cookie sent
INFO - 2018-08-23 15:21:40 --> CSRF token verified
INFO - 2018-08-23 15:21:40 --> Input Class Initialized
INFO - 2018-08-23 15:21:40 --> Language Class Initialized
INFO - 2018-08-23 15:21:40 --> Loader Class Initialized
INFO - 2018-08-23 15:21:40 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:40 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:40 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:40 --> Controller Class Initialized
INFO - 2018-08-23 15:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:40 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:40 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:40 --> Config Class Initialized
INFO - 2018-08-23 15:21:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:40 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:40 --> URI Class Initialized
INFO - 2018-08-23 15:21:40 --> Router Class Initialized
INFO - 2018-08-23 15:21:40 --> Output Class Initialized
INFO - 2018-08-23 15:21:40 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:40 --> CSRF cookie sent
INFO - 2018-08-23 15:21:40 --> Input Class Initialized
INFO - 2018-08-23 15:21:40 --> Language Class Initialized
INFO - 2018-08-23 15:21:40 --> Loader Class Initialized
INFO - 2018-08-23 15:21:40 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:40 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:40 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:40 --> Controller Class Initialized
INFO - 2018-08-23 15:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:40 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:40 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-08-23 15:21:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:40 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:40 --> Total execution time: 0.0515
INFO - 2018-08-23 15:21:45 --> Config Class Initialized
INFO - 2018-08-23 15:21:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:45 --> URI Class Initialized
INFO - 2018-08-23 15:21:45 --> Router Class Initialized
INFO - 2018-08-23 15:21:45 --> Output Class Initialized
INFO - 2018-08-23 15:21:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:45 --> CSRF cookie sent
INFO - 2018-08-23 15:21:45 --> CSRF token verified
INFO - 2018-08-23 15:21:45 --> Input Class Initialized
INFO - 2018-08-23 15:21:45 --> Language Class Initialized
INFO - 2018-08-23 15:21:45 --> Loader Class Initialized
INFO - 2018-08-23 15:21:45 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:45 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:45 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:45 --> Controller Class Initialized
INFO - 2018-08-23 15:21:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:45 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:45 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:45 --> Config Class Initialized
INFO - 2018-08-23 15:21:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:45 --> URI Class Initialized
INFO - 2018-08-23 15:21:45 --> Router Class Initialized
INFO - 2018-08-23 15:21:45 --> Output Class Initialized
INFO - 2018-08-23 15:21:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:45 --> CSRF cookie sent
INFO - 2018-08-23 15:21:45 --> Input Class Initialized
INFO - 2018-08-23 15:21:45 --> Language Class Initialized
INFO - 2018-08-23 15:21:46 --> Loader Class Initialized
INFO - 2018-08-23 15:21:46 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:46 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:46 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:46 --> Controller Class Initialized
INFO - 2018-08-23 15:21:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:46 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-08-23 15:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:46 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:46 --> Total execution time: 0.0717
INFO - 2018-08-23 15:21:52 --> Config Class Initialized
INFO - 2018-08-23 15:21:52 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:52 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:52 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:52 --> URI Class Initialized
INFO - 2018-08-23 15:21:52 --> Router Class Initialized
INFO - 2018-08-23 15:21:52 --> Output Class Initialized
INFO - 2018-08-23 15:21:52 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:52 --> CSRF cookie sent
INFO - 2018-08-23 15:21:52 --> CSRF token verified
INFO - 2018-08-23 15:21:52 --> Input Class Initialized
INFO - 2018-08-23 15:21:52 --> Language Class Initialized
INFO - 2018-08-23 15:21:52 --> Loader Class Initialized
INFO - 2018-08-23 15:21:52 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:52 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:52 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:52 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:52 --> Controller Class Initialized
INFO - 2018-08-23 15:21:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:52 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:52 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:52 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:52 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:52 --> Config Class Initialized
INFO - 2018-08-23 15:21:52 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:52 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:52 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:52 --> URI Class Initialized
INFO - 2018-08-23 15:21:52 --> Router Class Initialized
INFO - 2018-08-23 15:21:52 --> Output Class Initialized
INFO - 2018-08-23 15:21:52 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:52 --> CSRF cookie sent
INFO - 2018-08-23 15:21:52 --> Input Class Initialized
INFO - 2018-08-23 15:21:52 --> Language Class Initialized
INFO - 2018-08-23 15:21:52 --> Loader Class Initialized
INFO - 2018-08-23 15:21:52 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:52 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:52 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:52 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:52 --> Controller Class Initialized
INFO - 2018-08-23 15:21:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:52 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:52 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:52 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-08-23 15:21:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:52 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:52 --> Total execution time: 0.0474
INFO - 2018-08-23 15:21:58 --> Config Class Initialized
INFO - 2018-08-23 15:21:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:58 --> URI Class Initialized
INFO - 2018-08-23 15:21:58 --> Router Class Initialized
INFO - 2018-08-23 15:21:58 --> Output Class Initialized
INFO - 2018-08-23 15:21:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:58 --> CSRF cookie sent
INFO - 2018-08-23 15:21:58 --> CSRF token verified
INFO - 2018-08-23 15:21:58 --> Input Class Initialized
INFO - 2018-08-23 15:21:58 --> Language Class Initialized
INFO - 2018-08-23 15:21:58 --> Loader Class Initialized
INFO - 2018-08-23 15:21:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:58 --> Controller Class Initialized
INFO - 2018-08-23 15:21:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:58 --> Form Validation Class Initialized
INFO - 2018-08-23 15:21:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:21:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:58 --> Config Class Initialized
INFO - 2018-08-23 15:21:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:21:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:21:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:21:58 --> URI Class Initialized
INFO - 2018-08-23 15:21:58 --> Router Class Initialized
INFO - 2018-08-23 15:21:58 --> Output Class Initialized
INFO - 2018-08-23 15:21:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:21:58 --> CSRF cookie sent
INFO - 2018-08-23 15:21:58 --> Input Class Initialized
INFO - 2018-08-23 15:21:58 --> Language Class Initialized
INFO - 2018-08-23 15:21:58 --> Loader Class Initialized
INFO - 2018-08-23 15:21:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:21:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:21:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:21:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:21:58 --> Controller Class Initialized
INFO - 2018-08-23 15:21:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:21:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:21:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:21:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-08-23 15:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:21:58 --> Final output sent to browser
DEBUG - 2018-08-23 15:21:58 --> Total execution time: 0.0450
INFO - 2018-08-23 15:22:05 --> Config Class Initialized
INFO - 2018-08-23 15:22:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:05 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:05 --> URI Class Initialized
INFO - 2018-08-23 15:22:05 --> Router Class Initialized
INFO - 2018-08-23 15:22:05 --> Output Class Initialized
INFO - 2018-08-23 15:22:05 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:05 --> CSRF cookie sent
INFO - 2018-08-23 15:22:05 --> CSRF token verified
INFO - 2018-08-23 15:22:05 --> Input Class Initialized
INFO - 2018-08-23 15:22:05 --> Language Class Initialized
INFO - 2018-08-23 15:22:05 --> Loader Class Initialized
INFO - 2018-08-23 15:22:05 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:05 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:05 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:05 --> Controller Class Initialized
INFO - 2018-08-23 15:22:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:05 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:05 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:05 --> Config Class Initialized
INFO - 2018-08-23 15:22:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:05 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:05 --> URI Class Initialized
INFO - 2018-08-23 15:22:05 --> Router Class Initialized
INFO - 2018-08-23 15:22:05 --> Output Class Initialized
INFO - 2018-08-23 15:22:05 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:05 --> CSRF cookie sent
INFO - 2018-08-23 15:22:05 --> Input Class Initialized
INFO - 2018-08-23 15:22:05 --> Language Class Initialized
INFO - 2018-08-23 15:22:05 --> Loader Class Initialized
INFO - 2018-08-23 15:22:05 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:05 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:05 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:05 --> Controller Class Initialized
INFO - 2018-08-23 15:22:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:05 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-08-23 15:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:05 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:05 --> Total execution time: 0.0439
INFO - 2018-08-23 15:22:11 --> Config Class Initialized
INFO - 2018-08-23 15:22:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:11 --> URI Class Initialized
INFO - 2018-08-23 15:22:11 --> Router Class Initialized
INFO - 2018-08-23 15:22:11 --> Output Class Initialized
INFO - 2018-08-23 15:22:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:11 --> CSRF cookie sent
INFO - 2018-08-23 15:22:11 --> CSRF token verified
INFO - 2018-08-23 15:22:11 --> Input Class Initialized
INFO - 2018-08-23 15:22:11 --> Language Class Initialized
INFO - 2018-08-23 15:22:11 --> Loader Class Initialized
INFO - 2018-08-23 15:22:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:11 --> Controller Class Initialized
INFO - 2018-08-23 15:22:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:11 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:11 --> Config Class Initialized
INFO - 2018-08-23 15:22:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:11 --> URI Class Initialized
INFO - 2018-08-23 15:22:11 --> Router Class Initialized
INFO - 2018-08-23 15:22:11 --> Output Class Initialized
INFO - 2018-08-23 15:22:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:11 --> CSRF cookie sent
INFO - 2018-08-23 15:22:11 --> Input Class Initialized
INFO - 2018-08-23 15:22:11 --> Language Class Initialized
INFO - 2018-08-23 15:22:11 --> Loader Class Initialized
INFO - 2018-08-23 15:22:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:11 --> Controller Class Initialized
INFO - 2018-08-23 15:22:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-08-23 15:22:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:11 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:11 --> Total execution time: 0.0500
INFO - 2018-08-23 15:22:12 --> Config Class Initialized
INFO - 2018-08-23 15:22:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:12 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:12 --> URI Class Initialized
INFO - 2018-08-23 15:22:12 --> Router Class Initialized
INFO - 2018-08-23 15:22:12 --> Output Class Initialized
INFO - 2018-08-23 15:22:12 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:12 --> CSRF cookie sent
INFO - 2018-08-23 15:22:12 --> CSRF token verified
INFO - 2018-08-23 15:22:12 --> Input Class Initialized
INFO - 2018-08-23 15:22:12 --> Language Class Initialized
INFO - 2018-08-23 15:22:12 --> Loader Class Initialized
INFO - 2018-08-23 15:22:12 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:12 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:12 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:12 --> Controller Class Initialized
INFO - 2018-08-23 15:22:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:12 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:12 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:12 --> Config Class Initialized
INFO - 2018-08-23 15:22:12 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:12 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:12 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:12 --> URI Class Initialized
INFO - 2018-08-23 15:22:12 --> Router Class Initialized
INFO - 2018-08-23 15:22:12 --> Output Class Initialized
INFO - 2018-08-23 15:22:12 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:12 --> CSRF cookie sent
INFO - 2018-08-23 15:22:12 --> Input Class Initialized
INFO - 2018-08-23 15:22:12 --> Language Class Initialized
INFO - 2018-08-23 15:22:12 --> Loader Class Initialized
INFO - 2018-08-23 15:22:12 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:12 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:12 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:12 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:12 --> Controller Class Initialized
INFO - 2018-08-23 15:22:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:12 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:12 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-08-23 15:22:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:12 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:12 --> Total execution time: 0.0358
INFO - 2018-08-23 15:22:16 --> Config Class Initialized
INFO - 2018-08-23 15:22:16 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:16 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:16 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:16 --> URI Class Initialized
INFO - 2018-08-23 15:22:16 --> Router Class Initialized
INFO - 2018-08-23 15:22:16 --> Output Class Initialized
INFO - 2018-08-23 15:22:16 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:16 --> CSRF cookie sent
INFO - 2018-08-23 15:22:16 --> CSRF token verified
INFO - 2018-08-23 15:22:16 --> Input Class Initialized
INFO - 2018-08-23 15:22:16 --> Language Class Initialized
INFO - 2018-08-23 15:22:16 --> Loader Class Initialized
INFO - 2018-08-23 15:22:16 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:16 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:16 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:16 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:16 --> Controller Class Initialized
INFO - 2018-08-23 15:22:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:16 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:16 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:16 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:16 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:17 --> Config Class Initialized
INFO - 2018-08-23 15:22:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:17 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:17 --> URI Class Initialized
INFO - 2018-08-23 15:22:17 --> Router Class Initialized
INFO - 2018-08-23 15:22:17 --> Output Class Initialized
INFO - 2018-08-23 15:22:17 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:17 --> CSRF cookie sent
INFO - 2018-08-23 15:22:17 --> Input Class Initialized
INFO - 2018-08-23 15:22:17 --> Language Class Initialized
INFO - 2018-08-23 15:22:17 --> Loader Class Initialized
INFO - 2018-08-23 15:22:17 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:17 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:17 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:17 --> Controller Class Initialized
INFO - 2018-08-23 15:22:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:17 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-08-23 15:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:17 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:17 --> Total execution time: 0.0474
INFO - 2018-08-23 15:22:21 --> Config Class Initialized
INFO - 2018-08-23 15:22:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:21 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:21 --> URI Class Initialized
INFO - 2018-08-23 15:22:21 --> Router Class Initialized
INFO - 2018-08-23 15:22:21 --> Output Class Initialized
INFO - 2018-08-23 15:22:21 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:21 --> CSRF cookie sent
INFO - 2018-08-23 15:22:21 --> CSRF token verified
INFO - 2018-08-23 15:22:21 --> Input Class Initialized
INFO - 2018-08-23 15:22:21 --> Language Class Initialized
INFO - 2018-08-23 15:22:21 --> Loader Class Initialized
INFO - 2018-08-23 15:22:21 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:21 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:21 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:21 --> Controller Class Initialized
INFO - 2018-08-23 15:22:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:21 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:21 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:21 --> Config Class Initialized
INFO - 2018-08-23 15:22:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:21 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:21 --> URI Class Initialized
INFO - 2018-08-23 15:22:21 --> Router Class Initialized
INFO - 2018-08-23 15:22:21 --> Output Class Initialized
INFO - 2018-08-23 15:22:21 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:21 --> CSRF cookie sent
INFO - 2018-08-23 15:22:21 --> Input Class Initialized
INFO - 2018-08-23 15:22:21 --> Language Class Initialized
INFO - 2018-08-23 15:22:21 --> Loader Class Initialized
INFO - 2018-08-23 15:22:21 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:21 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:21 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:21 --> Controller Class Initialized
INFO - 2018-08-23 15:22:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:21 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-08-23 15:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:21 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:21 --> Total execution time: 0.0483
INFO - 2018-08-23 15:22:37 --> Config Class Initialized
INFO - 2018-08-23 15:22:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:37 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:37 --> URI Class Initialized
INFO - 2018-08-23 15:22:37 --> Router Class Initialized
INFO - 2018-08-23 15:22:37 --> Output Class Initialized
INFO - 2018-08-23 15:22:37 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:37 --> CSRF cookie sent
INFO - 2018-08-23 15:22:37 --> CSRF token verified
INFO - 2018-08-23 15:22:37 --> Input Class Initialized
INFO - 2018-08-23 15:22:37 --> Language Class Initialized
INFO - 2018-08-23 15:22:37 --> Loader Class Initialized
INFO - 2018-08-23 15:22:37 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:37 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:37 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:37 --> Controller Class Initialized
INFO - 2018-08-23 15:22:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:37 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:37 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:37 --> Config Class Initialized
INFO - 2018-08-23 15:22:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:37 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:37 --> URI Class Initialized
INFO - 2018-08-23 15:22:37 --> Router Class Initialized
INFO - 2018-08-23 15:22:37 --> Output Class Initialized
INFO - 2018-08-23 15:22:37 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:37 --> CSRF cookie sent
INFO - 2018-08-23 15:22:37 --> Input Class Initialized
INFO - 2018-08-23 15:22:37 --> Language Class Initialized
INFO - 2018-08-23 15:22:37 --> Loader Class Initialized
INFO - 2018-08-23 15:22:37 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:37 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:37 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:37 --> Controller Class Initialized
INFO - 2018-08-23 15:22:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:37 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:37 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-08-23 15:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:37 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:37 --> Total execution time: 0.0672
INFO - 2018-08-23 15:22:45 --> Config Class Initialized
INFO - 2018-08-23 15:22:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:45 --> URI Class Initialized
INFO - 2018-08-23 15:22:45 --> Router Class Initialized
INFO - 2018-08-23 15:22:45 --> Output Class Initialized
INFO - 2018-08-23 15:22:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:45 --> CSRF cookie sent
INFO - 2018-08-23 15:22:45 --> CSRF token verified
INFO - 2018-08-23 15:22:45 --> Input Class Initialized
INFO - 2018-08-23 15:22:45 --> Language Class Initialized
INFO - 2018-08-23 15:22:45 --> Loader Class Initialized
INFO - 2018-08-23 15:22:45 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:45 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:45 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:45 --> Controller Class Initialized
INFO - 2018-08-23 15:22:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:45 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:45 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:45 --> Config Class Initialized
INFO - 2018-08-23 15:22:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:45 --> URI Class Initialized
INFO - 2018-08-23 15:22:45 --> Router Class Initialized
INFO - 2018-08-23 15:22:45 --> Output Class Initialized
INFO - 2018-08-23 15:22:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:45 --> CSRF cookie sent
INFO - 2018-08-23 15:22:45 --> Input Class Initialized
INFO - 2018-08-23 15:22:45 --> Language Class Initialized
INFO - 2018-08-23 15:22:45 --> Loader Class Initialized
INFO - 2018-08-23 15:22:45 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:45 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:45 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:45 --> Controller Class Initialized
INFO - 2018-08-23 15:22:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:45 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-08-23 15:22:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:45 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:45 --> Total execution time: 0.0492
INFO - 2018-08-23 15:22:49 --> Config Class Initialized
INFO - 2018-08-23 15:22:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:49 --> URI Class Initialized
INFO - 2018-08-23 15:22:49 --> Router Class Initialized
INFO - 2018-08-23 15:22:49 --> Output Class Initialized
INFO - 2018-08-23 15:22:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:49 --> CSRF cookie sent
INFO - 2018-08-23 15:22:49 --> CSRF token verified
INFO - 2018-08-23 15:22:49 --> Input Class Initialized
INFO - 2018-08-23 15:22:49 --> Language Class Initialized
INFO - 2018-08-23 15:22:49 --> Loader Class Initialized
INFO - 2018-08-23 15:22:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:49 --> Controller Class Initialized
INFO - 2018-08-23 15:22:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:49 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:49 --> Config Class Initialized
INFO - 2018-08-23 15:22:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:49 --> URI Class Initialized
INFO - 2018-08-23 15:22:49 --> Router Class Initialized
INFO - 2018-08-23 15:22:49 --> Output Class Initialized
INFO - 2018-08-23 15:22:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:49 --> CSRF cookie sent
INFO - 2018-08-23 15:22:49 --> Input Class Initialized
INFO - 2018-08-23 15:22:49 --> Language Class Initialized
INFO - 2018-08-23 15:22:49 --> Loader Class Initialized
INFO - 2018-08-23 15:22:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:49 --> Controller Class Initialized
INFO - 2018-08-23 15:22:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-08-23 15:22:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:49 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:49 --> Total execution time: 0.0493
INFO - 2018-08-23 15:22:54 --> Config Class Initialized
INFO - 2018-08-23 15:22:54 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:54 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:54 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:54 --> URI Class Initialized
INFO - 2018-08-23 15:22:54 --> Router Class Initialized
INFO - 2018-08-23 15:22:54 --> Output Class Initialized
INFO - 2018-08-23 15:22:54 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:54 --> CSRF cookie sent
INFO - 2018-08-23 15:22:54 --> CSRF token verified
INFO - 2018-08-23 15:22:54 --> Input Class Initialized
INFO - 2018-08-23 15:22:54 --> Language Class Initialized
INFO - 2018-08-23 15:22:54 --> Loader Class Initialized
INFO - 2018-08-23 15:22:54 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:54 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:54 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:54 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:54 --> Controller Class Initialized
INFO - 2018-08-23 15:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:54 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:54 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:54 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:54 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:54 --> Config Class Initialized
INFO - 2018-08-23 15:22:54 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:54 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:54 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:54 --> URI Class Initialized
INFO - 2018-08-23 15:22:54 --> Router Class Initialized
INFO - 2018-08-23 15:22:54 --> Output Class Initialized
INFO - 2018-08-23 15:22:54 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:54 --> CSRF cookie sent
INFO - 2018-08-23 15:22:54 --> Input Class Initialized
INFO - 2018-08-23 15:22:54 --> Language Class Initialized
INFO - 2018-08-23 15:22:54 --> Loader Class Initialized
INFO - 2018-08-23 15:22:54 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:54 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:54 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:54 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:54 --> Controller Class Initialized
INFO - 2018-08-23 15:22:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:54 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:54 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:54 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-08-23 15:22:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:54 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:54 --> Total execution time: 0.0446
INFO - 2018-08-23 15:22:58 --> Config Class Initialized
INFO - 2018-08-23 15:22:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:58 --> URI Class Initialized
INFO - 2018-08-23 15:22:58 --> Router Class Initialized
INFO - 2018-08-23 15:22:58 --> Output Class Initialized
INFO - 2018-08-23 15:22:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:58 --> CSRF cookie sent
INFO - 2018-08-23 15:22:58 --> CSRF token verified
INFO - 2018-08-23 15:22:58 --> Input Class Initialized
INFO - 2018-08-23 15:22:58 --> Language Class Initialized
INFO - 2018-08-23 15:22:58 --> Loader Class Initialized
INFO - 2018-08-23 15:22:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:58 --> Controller Class Initialized
INFO - 2018-08-23 15:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:58 --> Form Validation Class Initialized
INFO - 2018-08-23 15:22:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:22:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:58 --> Config Class Initialized
INFO - 2018-08-23 15:22:58 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:22:58 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:22:58 --> Utf8 Class Initialized
INFO - 2018-08-23 15:22:58 --> URI Class Initialized
INFO - 2018-08-23 15:22:58 --> Router Class Initialized
INFO - 2018-08-23 15:22:58 --> Output Class Initialized
INFO - 2018-08-23 15:22:58 --> Security Class Initialized
DEBUG - 2018-08-23 15:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:22:58 --> CSRF cookie sent
INFO - 2018-08-23 15:22:58 --> Input Class Initialized
INFO - 2018-08-23 15:22:58 --> Language Class Initialized
INFO - 2018-08-23 15:22:58 --> Loader Class Initialized
INFO - 2018-08-23 15:22:58 --> Helper loaded: url_helper
INFO - 2018-08-23 15:22:58 --> Helper loaded: form_helper
INFO - 2018-08-23 15:22:58 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:22:58 --> User Agent Class Initialized
INFO - 2018-08-23 15:22:58 --> Controller Class Initialized
INFO - 2018-08-23 15:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:22:58 --> Pixel_Model class loaded
INFO - 2018-08-23 15:22:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:58 --> Database Driver Class Initialized
INFO - 2018-08-23 15:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-08-23 15:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:22:58 --> Final output sent to browser
DEBUG - 2018-08-23 15:22:58 --> Total execution time: 0.0627
INFO - 2018-08-23 15:23:01 --> Config Class Initialized
INFO - 2018-08-23 15:23:01 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:01 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:01 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:01 --> URI Class Initialized
INFO - 2018-08-23 15:23:01 --> Router Class Initialized
INFO - 2018-08-23 15:23:01 --> Output Class Initialized
INFO - 2018-08-23 15:23:01 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:01 --> CSRF cookie sent
INFO - 2018-08-23 15:23:01 --> CSRF token verified
INFO - 2018-08-23 15:23:01 --> Input Class Initialized
INFO - 2018-08-23 15:23:01 --> Language Class Initialized
INFO - 2018-08-23 15:23:01 --> Loader Class Initialized
INFO - 2018-08-23 15:23:01 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:01 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:01 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:01 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:01 --> Controller Class Initialized
INFO - 2018-08-23 15:23:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:01 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:01 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:01 --> Config Class Initialized
INFO - 2018-08-23 15:23:01 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:01 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:01 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:01 --> URI Class Initialized
INFO - 2018-08-23 15:23:01 --> Router Class Initialized
INFO - 2018-08-23 15:23:01 --> Output Class Initialized
INFO - 2018-08-23 15:23:01 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:01 --> CSRF cookie sent
INFO - 2018-08-23 15:23:01 --> Input Class Initialized
INFO - 2018-08-23 15:23:01 --> Language Class Initialized
INFO - 2018-08-23 15:23:01 --> Loader Class Initialized
INFO - 2018-08-23 15:23:01 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:01 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:01 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:01 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:01 --> Controller Class Initialized
INFO - 2018-08-23 15:23:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:01 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-08-23 15:23:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:01 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:01 --> Total execution time: 0.0435
INFO - 2018-08-23 15:23:06 --> Config Class Initialized
INFO - 2018-08-23 15:23:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:06 --> URI Class Initialized
INFO - 2018-08-23 15:23:06 --> Router Class Initialized
INFO - 2018-08-23 15:23:06 --> Output Class Initialized
INFO - 2018-08-23 15:23:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:06 --> CSRF cookie sent
INFO - 2018-08-23 15:23:06 --> CSRF token verified
INFO - 2018-08-23 15:23:06 --> Input Class Initialized
INFO - 2018-08-23 15:23:06 --> Language Class Initialized
INFO - 2018-08-23 15:23:07 --> Loader Class Initialized
INFO - 2018-08-23 15:23:07 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:07 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:07 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:07 --> Controller Class Initialized
INFO - 2018-08-23 15:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:07 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:07 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:07 --> Config Class Initialized
INFO - 2018-08-23 15:23:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:07 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:07 --> URI Class Initialized
INFO - 2018-08-23 15:23:07 --> Router Class Initialized
INFO - 2018-08-23 15:23:07 --> Output Class Initialized
INFO - 2018-08-23 15:23:07 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:07 --> CSRF cookie sent
INFO - 2018-08-23 15:23:07 --> Input Class Initialized
INFO - 2018-08-23 15:23:07 --> Language Class Initialized
INFO - 2018-08-23 15:23:07 --> Loader Class Initialized
INFO - 2018-08-23 15:23:07 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:07 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:07 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:07 --> Controller Class Initialized
INFO - 2018-08-23 15:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:07 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:07 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-08-23 15:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:07 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:07 --> Total execution time: 0.0646
INFO - 2018-08-23 15:23:20 --> Config Class Initialized
INFO - 2018-08-23 15:23:20 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:20 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:20 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:20 --> URI Class Initialized
INFO - 2018-08-23 15:23:20 --> Router Class Initialized
INFO - 2018-08-23 15:23:20 --> Output Class Initialized
INFO - 2018-08-23 15:23:20 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:20 --> CSRF cookie sent
INFO - 2018-08-23 15:23:20 --> CSRF token verified
INFO - 2018-08-23 15:23:20 --> Input Class Initialized
INFO - 2018-08-23 15:23:20 --> Language Class Initialized
INFO - 2018-08-23 15:23:20 --> Loader Class Initialized
INFO - 2018-08-23 15:23:20 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:20 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:20 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:20 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:20 --> Controller Class Initialized
INFO - 2018-08-23 15:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:20 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:20 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:20 --> Config Class Initialized
INFO - 2018-08-23 15:23:20 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:20 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:20 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:20 --> URI Class Initialized
INFO - 2018-08-23 15:23:20 --> Router Class Initialized
INFO - 2018-08-23 15:23:20 --> Output Class Initialized
INFO - 2018-08-23 15:23:20 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:20 --> CSRF cookie sent
INFO - 2018-08-23 15:23:20 --> Input Class Initialized
INFO - 2018-08-23 15:23:20 --> Language Class Initialized
INFO - 2018-08-23 15:23:20 --> Loader Class Initialized
INFO - 2018-08-23 15:23:20 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:20 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:20 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:20 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:20 --> Controller Class Initialized
INFO - 2018-08-23 15:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:20 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-08-23 15:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:20 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:20 --> Total execution time: 0.0632
INFO - 2018-08-23 15:23:24 --> Config Class Initialized
INFO - 2018-08-23 15:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:24 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:24 --> URI Class Initialized
INFO - 2018-08-23 15:23:24 --> Router Class Initialized
INFO - 2018-08-23 15:23:24 --> Output Class Initialized
INFO - 2018-08-23 15:23:24 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:24 --> CSRF cookie sent
INFO - 2018-08-23 15:23:24 --> CSRF token verified
INFO - 2018-08-23 15:23:24 --> Input Class Initialized
INFO - 2018-08-23 15:23:24 --> Language Class Initialized
INFO - 2018-08-23 15:23:24 --> Loader Class Initialized
INFO - 2018-08-23 15:23:24 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:24 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:24 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:24 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:24 --> Controller Class Initialized
INFO - 2018-08-23 15:23:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:24 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:24 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:24 --> Config Class Initialized
INFO - 2018-08-23 15:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:24 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:24 --> URI Class Initialized
INFO - 2018-08-23 15:23:24 --> Router Class Initialized
INFO - 2018-08-23 15:23:24 --> Output Class Initialized
INFO - 2018-08-23 15:23:24 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:24 --> CSRF cookie sent
INFO - 2018-08-23 15:23:24 --> Input Class Initialized
INFO - 2018-08-23 15:23:24 --> Language Class Initialized
INFO - 2018-08-23 15:23:24 --> Loader Class Initialized
INFO - 2018-08-23 15:23:24 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:24 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:24 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:24 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:24 --> Controller Class Initialized
INFO - 2018-08-23 15:23:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:24 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:24 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-08-23 15:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:24 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:24 --> Total execution time: 0.0459
INFO - 2018-08-23 15:23:29 --> Config Class Initialized
INFO - 2018-08-23 15:23:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:29 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:29 --> URI Class Initialized
INFO - 2018-08-23 15:23:29 --> Router Class Initialized
INFO - 2018-08-23 15:23:29 --> Output Class Initialized
INFO - 2018-08-23 15:23:29 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:29 --> CSRF cookie sent
INFO - 2018-08-23 15:23:29 --> CSRF token verified
INFO - 2018-08-23 15:23:29 --> Input Class Initialized
INFO - 2018-08-23 15:23:29 --> Language Class Initialized
INFO - 2018-08-23 15:23:29 --> Loader Class Initialized
INFO - 2018-08-23 15:23:29 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:29 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:29 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:29 --> Controller Class Initialized
INFO - 2018-08-23 15:23:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:29 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:29 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:29 --> Config Class Initialized
INFO - 2018-08-23 15:23:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:29 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:29 --> URI Class Initialized
INFO - 2018-08-23 15:23:29 --> Router Class Initialized
INFO - 2018-08-23 15:23:29 --> Output Class Initialized
INFO - 2018-08-23 15:23:29 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:29 --> CSRF cookie sent
INFO - 2018-08-23 15:23:29 --> Input Class Initialized
INFO - 2018-08-23 15:23:29 --> Language Class Initialized
INFO - 2018-08-23 15:23:29 --> Loader Class Initialized
INFO - 2018-08-23 15:23:29 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:29 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:29 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:29 --> Controller Class Initialized
INFO - 2018-08-23 15:23:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:29 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/social_class.php
INFO - 2018-08-23 15:23:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:29 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:29 --> Total execution time: 0.0460
INFO - 2018-08-23 15:23:33 --> Config Class Initialized
INFO - 2018-08-23 15:23:33 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:33 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:33 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:33 --> URI Class Initialized
INFO - 2018-08-23 15:23:33 --> Router Class Initialized
INFO - 2018-08-23 15:23:33 --> Output Class Initialized
INFO - 2018-08-23 15:23:33 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:33 --> CSRF cookie sent
INFO - 2018-08-23 15:23:33 --> CSRF token verified
INFO - 2018-08-23 15:23:33 --> Input Class Initialized
INFO - 2018-08-23 15:23:33 --> Language Class Initialized
INFO - 2018-08-23 15:23:33 --> Loader Class Initialized
INFO - 2018-08-23 15:23:33 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:33 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:33 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:33 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:33 --> Controller Class Initialized
INFO - 2018-08-23 15:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:33 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:33 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:33 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:33 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:33 --> Config Class Initialized
INFO - 2018-08-23 15:23:33 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:33 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:33 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:33 --> URI Class Initialized
INFO - 2018-08-23 15:23:33 --> Router Class Initialized
INFO - 2018-08-23 15:23:33 --> Output Class Initialized
INFO - 2018-08-23 15:23:33 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:33 --> CSRF cookie sent
INFO - 2018-08-23 15:23:33 --> Input Class Initialized
INFO - 2018-08-23 15:23:33 --> Language Class Initialized
INFO - 2018-08-23 15:23:33 --> Loader Class Initialized
INFO - 2018-08-23 15:23:33 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:33 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:33 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:33 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:33 --> Controller Class Initialized
INFO - 2018-08-23 15:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:33 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:33 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:33 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_social_class.php
INFO - 2018-08-23 15:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:33 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:33 --> Total execution time: 0.0434
INFO - 2018-08-23 15:23:36 --> Config Class Initialized
INFO - 2018-08-23 15:23:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:36 --> URI Class Initialized
INFO - 2018-08-23 15:23:36 --> Router Class Initialized
INFO - 2018-08-23 15:23:36 --> Output Class Initialized
INFO - 2018-08-23 15:23:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:36 --> CSRF cookie sent
INFO - 2018-08-23 15:23:36 --> CSRF token verified
INFO - 2018-08-23 15:23:36 --> Input Class Initialized
INFO - 2018-08-23 15:23:36 --> Language Class Initialized
INFO - 2018-08-23 15:23:36 --> Loader Class Initialized
INFO - 2018-08-23 15:23:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:36 --> Controller Class Initialized
INFO - 2018-08-23 15:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:36 --> Form Validation Class Initialized
INFO - 2018-08-23 15:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:23:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:36 --> Config Class Initialized
INFO - 2018-08-23 15:23:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:23:36 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:23:36 --> Utf8 Class Initialized
INFO - 2018-08-23 15:23:36 --> URI Class Initialized
INFO - 2018-08-23 15:23:36 --> Router Class Initialized
INFO - 2018-08-23 15:23:36 --> Output Class Initialized
INFO - 2018-08-23 15:23:36 --> Security Class Initialized
DEBUG - 2018-08-23 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:23:36 --> CSRF cookie sent
INFO - 2018-08-23 15:23:36 --> Input Class Initialized
INFO - 2018-08-23 15:23:36 --> Language Class Initialized
INFO - 2018-08-23 15:23:36 --> Loader Class Initialized
INFO - 2018-08-23 15:23:36 --> Helper loaded: url_helper
INFO - 2018-08-23 15:23:36 --> Helper loaded: form_helper
INFO - 2018-08-23 15:23:36 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:23:36 --> User Agent Class Initialized
INFO - 2018-08-23 15:23:36 --> Controller Class Initialized
INFO - 2018-08-23 15:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:23:36 --> Pixel_Model class loaded
INFO - 2018-08-23 15:23:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:36 --> Database Driver Class Initialized
INFO - 2018-08-23 15:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/ethnic_background.php
INFO - 2018-08-23 15:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:23:36 --> Final output sent to browser
DEBUG - 2018-08-23 15:23:36 --> Total execution time: 0.0449
INFO - 2018-08-23 15:24:01 --> Config Class Initialized
INFO - 2018-08-23 15:24:01 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:01 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:01 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:01 --> URI Class Initialized
INFO - 2018-08-23 15:24:01 --> Router Class Initialized
INFO - 2018-08-23 15:24:01 --> Output Class Initialized
INFO - 2018-08-23 15:24:01 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:01 --> CSRF cookie sent
INFO - 2018-08-23 15:24:01 --> CSRF token verified
INFO - 2018-08-23 15:24:01 --> Input Class Initialized
INFO - 2018-08-23 15:24:01 --> Language Class Initialized
INFO - 2018-08-23 15:24:01 --> Loader Class Initialized
INFO - 2018-08-23 15:24:01 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:01 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:01 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:01 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:01 --> Controller Class Initialized
INFO - 2018-08-23 15:24:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:01 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:01 --> Form Validation Class Initialized
INFO - 2018-08-23 15:24:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:24:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:01 --> Config Class Initialized
INFO - 2018-08-23 15:24:01 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:01 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:01 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:01 --> URI Class Initialized
INFO - 2018-08-23 15:24:01 --> Router Class Initialized
INFO - 2018-08-23 15:24:01 --> Output Class Initialized
INFO - 2018-08-23 15:24:01 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:01 --> CSRF cookie sent
INFO - 2018-08-23 15:24:01 --> Input Class Initialized
INFO - 2018-08-23 15:24:01 --> Language Class Initialized
INFO - 2018-08-23 15:24:01 --> Loader Class Initialized
INFO - 2018-08-23 15:24:01 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:01 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:01 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:01 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:01 --> Controller Class Initialized
INFO - 2018-08-23 15:24:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:01 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:01 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-08-23 15:24:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:24:01 --> Final output sent to browser
DEBUG - 2018-08-23 15:24:01 --> Total execution time: 0.0578
INFO - 2018-08-23 15:24:06 --> Config Class Initialized
INFO - 2018-08-23 15:24:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:06 --> URI Class Initialized
INFO - 2018-08-23 15:24:06 --> Router Class Initialized
INFO - 2018-08-23 15:24:06 --> Output Class Initialized
INFO - 2018-08-23 15:24:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:06 --> CSRF cookie sent
INFO - 2018-08-23 15:24:06 --> CSRF token verified
INFO - 2018-08-23 15:24:06 --> Input Class Initialized
INFO - 2018-08-23 15:24:06 --> Language Class Initialized
INFO - 2018-08-23 15:24:06 --> Loader Class Initialized
INFO - 2018-08-23 15:24:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:06 --> Controller Class Initialized
INFO - 2018-08-23 15:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:06 --> Form Validation Class Initialized
INFO - 2018-08-23 15:24:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:24:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:06 --> Config Class Initialized
INFO - 2018-08-23 15:24:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:06 --> URI Class Initialized
INFO - 2018-08-23 15:24:06 --> Router Class Initialized
INFO - 2018-08-23 15:24:06 --> Output Class Initialized
INFO - 2018-08-23 15:24:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:06 --> CSRF cookie sent
INFO - 2018-08-23 15:24:06 --> Input Class Initialized
INFO - 2018-08-23 15:24:06 --> Language Class Initialized
INFO - 2018-08-23 15:24:06 --> Loader Class Initialized
INFO - 2018-08-23 15:24:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:06 --> Controller Class Initialized
INFO - 2018-08-23 15:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_details.php
INFO - 2018-08-23 15:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:24:06 --> Final output sent to browser
DEBUG - 2018-08-23 15:24:06 --> Total execution time: 0.0469
INFO - 2018-08-23 15:24:41 --> Config Class Initialized
INFO - 2018-08-23 15:24:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:41 --> URI Class Initialized
INFO - 2018-08-23 15:24:41 --> Router Class Initialized
INFO - 2018-08-23 15:24:41 --> Output Class Initialized
INFO - 2018-08-23 15:24:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:41 --> CSRF cookie sent
INFO - 2018-08-23 15:24:41 --> CSRF token verified
INFO - 2018-08-23 15:24:41 --> Input Class Initialized
INFO - 2018-08-23 15:24:41 --> Language Class Initialized
INFO - 2018-08-23 15:24:41 --> Loader Class Initialized
INFO - 2018-08-23 15:24:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:41 --> Controller Class Initialized
INFO - 2018-08-23 15:24:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:41 --> Form Validation Class Initialized
INFO - 2018-08-23 15:24:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:24:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:41 --> Config Class Initialized
INFO - 2018-08-23 15:24:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:41 --> URI Class Initialized
INFO - 2018-08-23 15:24:41 --> Router Class Initialized
INFO - 2018-08-23 15:24:41 --> Output Class Initialized
INFO - 2018-08-23 15:24:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:41 --> CSRF cookie sent
INFO - 2018-08-23 15:24:41 --> Input Class Initialized
INFO - 2018-08-23 15:24:41 --> Language Class Initialized
INFO - 2018-08-23 15:24:41 --> Loader Class Initialized
INFO - 2018-08-23 15:24:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:41 --> Controller Class Initialized
INFO - 2018-08-23 15:24:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gifts_info.php
INFO - 2018-08-23 15:24:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:24:41 --> Final output sent to browser
DEBUG - 2018-08-23 15:24:41 --> Total execution time: 0.0704
INFO - 2018-08-23 15:24:47 --> Config Class Initialized
INFO - 2018-08-23 15:24:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:47 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:47 --> URI Class Initialized
INFO - 2018-08-23 15:24:47 --> Router Class Initialized
INFO - 2018-08-23 15:24:47 --> Output Class Initialized
INFO - 2018-08-23 15:24:47 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:47 --> CSRF cookie sent
INFO - 2018-08-23 15:24:47 --> CSRF token verified
INFO - 2018-08-23 15:24:47 --> Input Class Initialized
INFO - 2018-08-23 15:24:47 --> Language Class Initialized
INFO - 2018-08-23 15:24:47 --> Loader Class Initialized
INFO - 2018-08-23 15:24:47 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:47 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:47 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:47 --> Controller Class Initialized
INFO - 2018-08-23 15:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:47 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:47 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:47 --> Form Validation Class Initialized
INFO - 2018-08-23 15:24:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:24:47 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:47 --> Config Class Initialized
INFO - 2018-08-23 15:24:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:24:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:24:47 --> Utf8 Class Initialized
INFO - 2018-08-23 15:24:47 --> URI Class Initialized
INFO - 2018-08-23 15:24:47 --> Router Class Initialized
INFO - 2018-08-23 15:24:47 --> Output Class Initialized
INFO - 2018-08-23 15:24:47 --> Security Class Initialized
DEBUG - 2018-08-23 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:24:47 --> CSRF cookie sent
INFO - 2018-08-23 15:24:47 --> Input Class Initialized
INFO - 2018-08-23 15:24:47 --> Language Class Initialized
INFO - 2018-08-23 15:24:47 --> Loader Class Initialized
INFO - 2018-08-23 15:24:47 --> Helper loaded: url_helper
INFO - 2018-08-23 15:24:47 --> Helper loaded: form_helper
INFO - 2018-08-23 15:24:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:24:47 --> User Agent Class Initialized
INFO - 2018-08-23 15:24:47 --> Controller Class Initialized
INFO - 2018-08-23 15:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:24:47 --> Pixel_Model class loaded
INFO - 2018-08-23 15:24:47 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:47 --> Database Driver Class Initialized
INFO - 2018-08-23 15:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gift_details.php
INFO - 2018-08-23 15:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:24:47 --> Final output sent to browser
DEBUG - 2018-08-23 15:24:47 --> Total execution time: 0.0469
INFO - 2018-08-23 15:25:00 --> Config Class Initialized
INFO - 2018-08-23 15:25:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:00 --> URI Class Initialized
INFO - 2018-08-23 15:25:00 --> Router Class Initialized
INFO - 2018-08-23 15:25:00 --> Output Class Initialized
INFO - 2018-08-23 15:25:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:00 --> CSRF cookie sent
INFO - 2018-08-23 15:25:00 --> CSRF token verified
INFO - 2018-08-23 15:25:00 --> Input Class Initialized
INFO - 2018-08-23 15:25:00 --> Language Class Initialized
INFO - 2018-08-23 15:25:00 --> Loader Class Initialized
INFO - 2018-08-23 15:25:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:00 --> Controller Class Initialized
INFO - 2018-08-23 15:25:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:00 --> Form Validation Class Initialized
INFO - 2018-08-23 15:25:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:25:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:00 --> Config Class Initialized
INFO - 2018-08-23 15:25:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:00 --> URI Class Initialized
INFO - 2018-08-23 15:25:00 --> Router Class Initialized
INFO - 2018-08-23 15:25:00 --> Output Class Initialized
INFO - 2018-08-23 15:25:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:00 --> CSRF cookie sent
INFO - 2018-08-23 15:25:00 --> Input Class Initialized
INFO - 2018-08-23 15:25:00 --> Language Class Initialized
INFO - 2018-08-23 15:25:00 --> Loader Class Initialized
INFO - 2018-08-23 15:25:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:00 --> Controller Class Initialized
INFO - 2018-08-23 15:25:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/automobile.php
INFO - 2018-08-23 15:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:25:00 --> Final output sent to browser
DEBUG - 2018-08-23 15:25:00 --> Total execution time: 0.0495
INFO - 2018-08-23 15:25:17 --> Config Class Initialized
INFO - 2018-08-23 15:25:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:17 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:17 --> URI Class Initialized
INFO - 2018-08-23 15:25:17 --> Router Class Initialized
INFO - 2018-08-23 15:25:17 --> Output Class Initialized
INFO - 2018-08-23 15:25:17 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:17 --> CSRF cookie sent
INFO - 2018-08-23 15:25:17 --> CSRF token verified
INFO - 2018-08-23 15:25:17 --> Input Class Initialized
INFO - 2018-08-23 15:25:17 --> Language Class Initialized
INFO - 2018-08-23 15:25:17 --> Loader Class Initialized
INFO - 2018-08-23 15:25:17 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:17 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:17 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:17 --> Controller Class Initialized
INFO - 2018-08-23 15:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:17 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:17 --> Form Validation Class Initialized
INFO - 2018-08-23 15:25:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:25:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:17 --> Config Class Initialized
INFO - 2018-08-23 15:25:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:17 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:17 --> URI Class Initialized
INFO - 2018-08-23 15:25:17 --> Router Class Initialized
INFO - 2018-08-23 15:25:17 --> Output Class Initialized
INFO - 2018-08-23 15:25:17 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:17 --> CSRF cookie sent
INFO - 2018-08-23 15:25:17 --> Input Class Initialized
INFO - 2018-08-23 15:25:17 --> Language Class Initialized
INFO - 2018-08-23 15:25:17 --> Loader Class Initialized
INFO - 2018-08-23 15:25:17 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:17 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:17 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:17 --> Controller Class Initialized
INFO - 2018-08-23 15:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:17 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:17 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_autos.php
INFO - 2018-08-23 15:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:25:17 --> Final output sent to browser
DEBUG - 2018-08-23 15:25:17 --> Total execution time: 0.0439
INFO - 2018-08-23 15:25:42 --> Config Class Initialized
INFO - 2018-08-23 15:25:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:42 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:42 --> URI Class Initialized
INFO - 2018-08-23 15:25:42 --> Router Class Initialized
INFO - 2018-08-23 15:25:42 --> Output Class Initialized
INFO - 2018-08-23 15:25:42 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:42 --> CSRF cookie sent
INFO - 2018-08-23 15:25:42 --> CSRF token verified
INFO - 2018-08-23 15:25:42 --> Input Class Initialized
INFO - 2018-08-23 15:25:42 --> Language Class Initialized
INFO - 2018-08-23 15:25:42 --> Loader Class Initialized
INFO - 2018-08-23 15:25:42 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:42 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:42 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:42 --> Controller Class Initialized
INFO - 2018-08-23 15:25:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:42 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:42 --> Form Validation Class Initialized
INFO - 2018-08-23 15:25:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:42 --> Config Class Initialized
INFO - 2018-08-23 15:25:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:42 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:42 --> URI Class Initialized
INFO - 2018-08-23 15:25:42 --> Router Class Initialized
INFO - 2018-08-23 15:25:42 --> Output Class Initialized
INFO - 2018-08-23 15:25:42 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:42 --> CSRF cookie sent
INFO - 2018-08-23 15:25:42 --> Input Class Initialized
INFO - 2018-08-23 15:25:42 --> Language Class Initialized
INFO - 2018-08-23 15:25:42 --> Loader Class Initialized
INFO - 2018-08-23 15:25:42 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:42 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:42 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:42 --> Controller Class Initialized
INFO - 2018-08-23 15:25:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:42 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:42 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/collectables.php
INFO - 2018-08-23 15:25:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:25:42 --> Final output sent to browser
DEBUG - 2018-08-23 15:25:42 --> Total execution time: 0.0470
INFO - 2018-08-23 15:25:44 --> Config Class Initialized
INFO - 2018-08-23 15:25:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:44 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:44 --> URI Class Initialized
INFO - 2018-08-23 15:25:44 --> Router Class Initialized
INFO - 2018-08-23 15:25:44 --> Output Class Initialized
INFO - 2018-08-23 15:25:44 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:44 --> CSRF cookie sent
INFO - 2018-08-23 15:25:44 --> Input Class Initialized
INFO - 2018-08-23 15:25:44 --> Language Class Initialized
INFO - 2018-08-23 15:25:44 --> Loader Class Initialized
INFO - 2018-08-23 15:25:44 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:44 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:44 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:44 --> Controller Class Initialized
INFO - 2018-08-23 15:25:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:44 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:44 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:44 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_autos.php
INFO - 2018-08-23 15:25:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:25:44 --> Final output sent to browser
DEBUG - 2018-08-23 15:25:44 --> Total execution time: 0.0443
INFO - 2018-08-23 15:25:46 --> Config Class Initialized
INFO - 2018-08-23 15:25:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:46 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:46 --> URI Class Initialized
INFO - 2018-08-23 15:25:46 --> Router Class Initialized
INFO - 2018-08-23 15:25:46 --> Output Class Initialized
INFO - 2018-08-23 15:25:46 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:46 --> CSRF cookie sent
INFO - 2018-08-23 15:25:46 --> CSRF token verified
INFO - 2018-08-23 15:25:46 --> Input Class Initialized
INFO - 2018-08-23 15:25:46 --> Language Class Initialized
INFO - 2018-08-23 15:25:46 --> Loader Class Initialized
INFO - 2018-08-23 15:25:46 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:46 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:46 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:46 --> Controller Class Initialized
INFO - 2018-08-23 15:25:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:46 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:46 --> Form Validation Class Initialized
INFO - 2018-08-23 15:25:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:25:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:46 --> Config Class Initialized
INFO - 2018-08-23 15:25:46 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:25:46 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:25:46 --> Utf8 Class Initialized
INFO - 2018-08-23 15:25:46 --> URI Class Initialized
INFO - 2018-08-23 15:25:46 --> Router Class Initialized
INFO - 2018-08-23 15:25:46 --> Output Class Initialized
INFO - 2018-08-23 15:25:46 --> Security Class Initialized
DEBUG - 2018-08-23 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:25:46 --> CSRF cookie sent
INFO - 2018-08-23 15:25:46 --> Input Class Initialized
INFO - 2018-08-23 15:25:46 --> Language Class Initialized
INFO - 2018-08-23 15:25:46 --> Loader Class Initialized
INFO - 2018-08-23 15:25:46 --> Helper loaded: url_helper
INFO - 2018-08-23 15:25:46 --> Helper loaded: form_helper
INFO - 2018-08-23 15:25:46 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:25:46 --> User Agent Class Initialized
INFO - 2018-08-23 15:25:46 --> Controller Class Initialized
INFO - 2018-08-23 15:25:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:25:46 --> Pixel_Model class loaded
INFO - 2018-08-23 15:25:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:46 --> Database Driver Class Initialized
INFO - 2018-08-23 15:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/collectables.php
INFO - 2018-08-23 15:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:25:46 --> Final output sent to browser
DEBUG - 2018-08-23 15:25:46 --> Total execution time: 0.0471
INFO - 2018-08-23 15:26:02 --> Config Class Initialized
INFO - 2018-08-23 15:26:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:26:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:26:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:26:02 --> URI Class Initialized
INFO - 2018-08-23 15:26:02 --> Router Class Initialized
INFO - 2018-08-23 15:26:02 --> Output Class Initialized
INFO - 2018-08-23 15:26:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:26:02 --> CSRF cookie sent
INFO - 2018-08-23 15:26:02 --> CSRF token verified
INFO - 2018-08-23 15:26:02 --> Input Class Initialized
INFO - 2018-08-23 15:26:02 --> Language Class Initialized
INFO - 2018-08-23 15:26:02 --> Loader Class Initialized
INFO - 2018-08-23 15:26:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:26:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:26:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:26:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:26:02 --> Controller Class Initialized
INFO - 2018-08-23 15:26:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:26:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:26:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:26:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:02 --> Form Validation Class Initialized
INFO - 2018-08-23 15:26:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:26:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:02 --> Config Class Initialized
INFO - 2018-08-23 15:26:02 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:26:02 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:26:02 --> Utf8 Class Initialized
INFO - 2018-08-23 15:26:02 --> URI Class Initialized
INFO - 2018-08-23 15:26:02 --> Router Class Initialized
INFO - 2018-08-23 15:26:02 --> Output Class Initialized
INFO - 2018-08-23 15:26:02 --> Security Class Initialized
DEBUG - 2018-08-23 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:26:02 --> CSRF cookie sent
INFO - 2018-08-23 15:26:02 --> Input Class Initialized
INFO - 2018-08-23 15:26:02 --> Language Class Initialized
INFO - 2018-08-23 15:26:02 --> Loader Class Initialized
INFO - 2018-08-23 15:26:02 --> Helper loaded: url_helper
INFO - 2018-08-23 15:26:02 --> Helper loaded: form_helper
INFO - 2018-08-23 15:26:02 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:26:02 --> User Agent Class Initialized
INFO - 2018-08-23 15:26:02 --> Controller Class Initialized
INFO - 2018-08-23 15:26:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:26:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:26:02 --> Pixel_Model class loaded
INFO - 2018-08-23 15:26:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:02 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gadgets.php
INFO - 2018-08-23 15:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:26:02 --> Final output sent to browser
DEBUG - 2018-08-23 15:26:02 --> Total execution time: 0.0425
INFO - 2018-08-23 15:26:10 --> Config Class Initialized
INFO - 2018-08-23 15:26:10 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:26:10 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:26:10 --> Utf8 Class Initialized
INFO - 2018-08-23 15:26:10 --> URI Class Initialized
INFO - 2018-08-23 15:26:10 --> Router Class Initialized
INFO - 2018-08-23 15:26:10 --> Output Class Initialized
INFO - 2018-08-23 15:26:10 --> Security Class Initialized
DEBUG - 2018-08-23 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:26:10 --> CSRF cookie sent
INFO - 2018-08-23 15:26:10 --> CSRF token verified
INFO - 2018-08-23 15:26:10 --> Input Class Initialized
INFO - 2018-08-23 15:26:10 --> Language Class Initialized
INFO - 2018-08-23 15:26:10 --> Loader Class Initialized
INFO - 2018-08-23 15:26:10 --> Helper loaded: url_helper
INFO - 2018-08-23 15:26:10 --> Helper loaded: form_helper
INFO - 2018-08-23 15:26:10 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:26:10 --> User Agent Class Initialized
INFO - 2018-08-23 15:26:10 --> Controller Class Initialized
INFO - 2018-08-23 15:26:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:26:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:26:10 --> Pixel_Model class loaded
INFO - 2018-08-23 15:26:10 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:10 --> Form Validation Class Initialized
INFO - 2018-08-23 15:26:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:26:10 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:11 --> Config Class Initialized
INFO - 2018-08-23 15:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:26:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:26:11 --> URI Class Initialized
INFO - 2018-08-23 15:26:11 --> Router Class Initialized
INFO - 2018-08-23 15:26:11 --> Output Class Initialized
INFO - 2018-08-23 15:26:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:26:11 --> CSRF cookie sent
INFO - 2018-08-23 15:26:11 --> Input Class Initialized
INFO - 2018-08-23 15:26:11 --> Language Class Initialized
INFO - 2018-08-23 15:26:11 --> Loader Class Initialized
INFO - 2018-08-23 15:26:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:26:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:26:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:26:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:26:11 --> Controller Class Initialized
INFO - 2018-08-23 15:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:26:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:26:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/bank_accounts.php
INFO - 2018-08-23 15:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:26:11 --> Final output sent to browser
DEBUG - 2018-08-23 15:26:11 --> Total execution time: 0.0442
INFO - 2018-08-23 15:27:00 --> Config Class Initialized
INFO - 2018-08-23 15:27:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:00 --> URI Class Initialized
INFO - 2018-08-23 15:27:00 --> Router Class Initialized
INFO - 2018-08-23 15:27:00 --> Output Class Initialized
INFO - 2018-08-23 15:27:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:00 --> CSRF cookie sent
INFO - 2018-08-23 15:27:00 --> CSRF token verified
INFO - 2018-08-23 15:27:00 --> Input Class Initialized
INFO - 2018-08-23 15:27:00 --> Language Class Initialized
INFO - 2018-08-23 15:27:00 --> Loader Class Initialized
INFO - 2018-08-23 15:27:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:00 --> Controller Class Initialized
INFO - 2018-08-23 15:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:00 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:00 --> Config Class Initialized
INFO - 2018-08-23 15:27:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:00 --> URI Class Initialized
INFO - 2018-08-23 15:27:00 --> Router Class Initialized
INFO - 2018-08-23 15:27:00 --> Output Class Initialized
INFO - 2018-08-23 15:27:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:00 --> CSRF cookie sent
INFO - 2018-08-23 15:27:00 --> Input Class Initialized
INFO - 2018-08-23 15:27:00 --> Language Class Initialized
INFO - 2018-08-23 15:27:00 --> Loader Class Initialized
INFO - 2018-08-23 15:27:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:00 --> Controller Class Initialized
INFO - 2018-08-23 15:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/crypto_currencies.php
INFO - 2018-08-23 15:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:00 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:00 --> Total execution time: 0.0438
INFO - 2018-08-23 15:27:06 --> Config Class Initialized
INFO - 2018-08-23 15:27:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:06 --> URI Class Initialized
INFO - 2018-08-23 15:27:06 --> Router Class Initialized
INFO - 2018-08-23 15:27:06 --> Output Class Initialized
INFO - 2018-08-23 15:27:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:06 --> CSRF cookie sent
INFO - 2018-08-23 15:27:06 --> CSRF token verified
INFO - 2018-08-23 15:27:06 --> Input Class Initialized
INFO - 2018-08-23 15:27:06 --> Language Class Initialized
INFO - 2018-08-23 15:27:06 --> Loader Class Initialized
INFO - 2018-08-23 15:27:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:06 --> Controller Class Initialized
INFO - 2018-08-23 15:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:06 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:06 --> Config Class Initialized
INFO - 2018-08-23 15:27:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:06 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:06 --> URI Class Initialized
INFO - 2018-08-23 15:27:06 --> Router Class Initialized
INFO - 2018-08-23 15:27:06 --> Output Class Initialized
INFO - 2018-08-23 15:27:06 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:06 --> CSRF cookie sent
INFO - 2018-08-23 15:27:06 --> Input Class Initialized
INFO - 2018-08-23 15:27:06 --> Language Class Initialized
INFO - 2018-08-23 15:27:06 --> Loader Class Initialized
INFO - 2018-08-23 15:27:06 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:06 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:06 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:06 --> Controller Class Initialized
INFO - 2018-08-23 15:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:06 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:06 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/money_owed_you.php
INFO - 2018-08-23 15:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:06 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:06 --> Total execution time: 0.0441
INFO - 2018-08-23 15:27:18 --> Config Class Initialized
INFO - 2018-08-23 15:27:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:18 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:18 --> URI Class Initialized
INFO - 2018-08-23 15:27:18 --> Router Class Initialized
INFO - 2018-08-23 15:27:18 --> Output Class Initialized
INFO - 2018-08-23 15:27:18 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:18 --> CSRF cookie sent
INFO - 2018-08-23 15:27:18 --> CSRF token verified
INFO - 2018-08-23 15:27:18 --> Input Class Initialized
INFO - 2018-08-23 15:27:18 --> Language Class Initialized
INFO - 2018-08-23 15:27:18 --> Loader Class Initialized
INFO - 2018-08-23 15:27:18 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:18 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:18 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:18 --> Controller Class Initialized
INFO - 2018-08-23 15:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:18 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:18 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:18 --> Config Class Initialized
INFO - 2018-08-23 15:27:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:18 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:18 --> URI Class Initialized
INFO - 2018-08-23 15:27:18 --> Router Class Initialized
INFO - 2018-08-23 15:27:18 --> Output Class Initialized
INFO - 2018-08-23 15:27:18 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:18 --> CSRF cookie sent
INFO - 2018-08-23 15:27:18 --> Input Class Initialized
INFO - 2018-08-23 15:27:18 --> Language Class Initialized
INFO - 2018-08-23 15:27:18 --> Loader Class Initialized
INFO - 2018-08-23 15:27:18 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:18 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:18 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:18 --> Controller Class Initialized
INFO - 2018-08-23 15:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:18 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:18 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/investments_stocks.php
INFO - 2018-08-23 15:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:18 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:18 --> Total execution time: 0.0463
INFO - 2018-08-23 15:27:28 --> Config Class Initialized
INFO - 2018-08-23 15:27:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:28 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:28 --> URI Class Initialized
INFO - 2018-08-23 15:27:28 --> Router Class Initialized
INFO - 2018-08-23 15:27:28 --> Output Class Initialized
INFO - 2018-08-23 15:27:28 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:28 --> CSRF cookie sent
INFO - 2018-08-23 15:27:28 --> CSRF token verified
INFO - 2018-08-23 15:27:28 --> Input Class Initialized
INFO - 2018-08-23 15:27:28 --> Language Class Initialized
INFO - 2018-08-23 15:27:28 --> Loader Class Initialized
INFO - 2018-08-23 15:27:28 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:28 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:28 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:28 --> Controller Class Initialized
INFO - 2018-08-23 15:27:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:28 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:28 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:28 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:29 --> Config Class Initialized
INFO - 2018-08-23 15:27:29 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:29 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:29 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:29 --> URI Class Initialized
INFO - 2018-08-23 15:27:29 --> Router Class Initialized
INFO - 2018-08-23 15:27:29 --> Output Class Initialized
INFO - 2018-08-23 15:27:29 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:29 --> CSRF cookie sent
INFO - 2018-08-23 15:27:29 --> Input Class Initialized
INFO - 2018-08-23 15:27:29 --> Language Class Initialized
INFO - 2018-08-23 15:27:29 --> Loader Class Initialized
INFO - 2018-08-23 15:27:29 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:29 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:29 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:29 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:29 --> Controller Class Initialized
INFO - 2018-08-23 15:27:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:29 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:29 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_value_assets.php
INFO - 2018-08-23 15:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:29 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:29 --> Total execution time: 0.0537
INFO - 2018-08-23 15:27:41 --> Config Class Initialized
INFO - 2018-08-23 15:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:41 --> URI Class Initialized
INFO - 2018-08-23 15:27:41 --> Router Class Initialized
INFO - 2018-08-23 15:27:41 --> Output Class Initialized
INFO - 2018-08-23 15:27:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:41 --> CSRF cookie sent
INFO - 2018-08-23 15:27:41 --> CSRF token verified
INFO - 2018-08-23 15:27:41 --> Input Class Initialized
INFO - 2018-08-23 15:27:41 --> Language Class Initialized
INFO - 2018-08-23 15:27:41 --> Loader Class Initialized
INFO - 2018-08-23 15:27:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:41 --> Controller Class Initialized
INFO - 2018-08-23 15:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:41 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:41 --> Config Class Initialized
INFO - 2018-08-23 15:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:41 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:41 --> URI Class Initialized
INFO - 2018-08-23 15:27:41 --> Router Class Initialized
INFO - 2018-08-23 15:27:41 --> Output Class Initialized
INFO - 2018-08-23 15:27:41 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:41 --> CSRF cookie sent
INFO - 2018-08-23 15:27:41 --> Input Class Initialized
INFO - 2018-08-23 15:27:41 --> Language Class Initialized
INFO - 2018-08-23 15:27:41 --> Loader Class Initialized
INFO - 2018-08-23 15:27:41 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:41 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:41 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:41 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:41 --> Controller Class Initialized
INFO - 2018-08-23 15:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:41 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:41 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/disability_insurance.php
INFO - 2018-08-23 15:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:41 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:41 --> Total execution time: 0.0432
INFO - 2018-08-23 15:27:49 --> Config Class Initialized
INFO - 2018-08-23 15:27:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:49 --> URI Class Initialized
INFO - 2018-08-23 15:27:49 --> Router Class Initialized
INFO - 2018-08-23 15:27:49 --> Output Class Initialized
INFO - 2018-08-23 15:27:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:49 --> CSRF cookie sent
INFO - 2018-08-23 15:27:49 --> CSRF token verified
INFO - 2018-08-23 15:27:49 --> Input Class Initialized
INFO - 2018-08-23 15:27:49 --> Language Class Initialized
INFO - 2018-08-23 15:27:49 --> Loader Class Initialized
INFO - 2018-08-23 15:27:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:49 --> Controller Class Initialized
INFO - 2018-08-23 15:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:49 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:49 --> Config Class Initialized
INFO - 2018-08-23 15:27:49 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:49 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:49 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:49 --> URI Class Initialized
INFO - 2018-08-23 15:27:49 --> Router Class Initialized
INFO - 2018-08-23 15:27:49 --> Output Class Initialized
INFO - 2018-08-23 15:27:49 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:49 --> CSRF cookie sent
INFO - 2018-08-23 15:27:49 --> Input Class Initialized
INFO - 2018-08-23 15:27:49 --> Language Class Initialized
INFO - 2018-08-23 15:27:49 --> Loader Class Initialized
INFO - 2018-08-23 15:27:49 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:49 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:49 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:49 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:49 --> Controller Class Initialized
INFO - 2018-08-23 15:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:49 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:49 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_loans.php
INFO - 2018-08-23 15:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:49 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:49 --> Total execution time: 0.0588
INFO - 2018-08-23 15:27:56 --> Config Class Initialized
INFO - 2018-08-23 15:27:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:56 --> URI Class Initialized
INFO - 2018-08-23 15:27:56 --> Router Class Initialized
INFO - 2018-08-23 15:27:56 --> Output Class Initialized
INFO - 2018-08-23 15:27:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:56 --> CSRF cookie sent
INFO - 2018-08-23 15:27:56 --> CSRF token verified
INFO - 2018-08-23 15:27:56 --> Input Class Initialized
INFO - 2018-08-23 15:27:56 --> Language Class Initialized
INFO - 2018-08-23 15:27:56 --> Loader Class Initialized
INFO - 2018-08-23 15:27:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:56 --> Controller Class Initialized
INFO - 2018-08-23 15:27:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:56 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:56 --> Form Validation Class Initialized
INFO - 2018-08-23 15:27:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:27:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:56 --> Config Class Initialized
INFO - 2018-08-23 15:27:56 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:27:56 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:27:56 --> Utf8 Class Initialized
INFO - 2018-08-23 15:27:56 --> URI Class Initialized
INFO - 2018-08-23 15:27:56 --> Router Class Initialized
INFO - 2018-08-23 15:27:56 --> Output Class Initialized
INFO - 2018-08-23 15:27:56 --> Security Class Initialized
DEBUG - 2018-08-23 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:27:56 --> CSRF cookie sent
INFO - 2018-08-23 15:27:56 --> Input Class Initialized
INFO - 2018-08-23 15:27:56 --> Language Class Initialized
INFO - 2018-08-23 15:27:56 --> Loader Class Initialized
INFO - 2018-08-23 15:27:56 --> Helper loaded: url_helper
INFO - 2018-08-23 15:27:56 --> Helper loaded: form_helper
INFO - 2018-08-23 15:27:56 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:27:56 --> User Agent Class Initialized
INFO - 2018-08-23 15:27:56 --> Controller Class Initialized
INFO - 2018-08-23 15:27:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:27:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:27:56 --> Pixel_Model class loaded
INFO - 2018-08-23 15:27:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:56 --> Database Driver Class Initialized
INFO - 2018-08-23 15:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_credit_line.php
INFO - 2018-08-23 15:27:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:27:56 --> Final output sent to browser
DEBUG - 2018-08-23 15:27:56 --> Total execution time: 0.0346
INFO - 2018-08-23 15:28:05 --> Config Class Initialized
INFO - 2018-08-23 15:28:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:05 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:05 --> URI Class Initialized
INFO - 2018-08-23 15:28:05 --> Router Class Initialized
INFO - 2018-08-23 15:28:05 --> Output Class Initialized
INFO - 2018-08-23 15:28:05 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:05 --> CSRF cookie sent
INFO - 2018-08-23 15:28:05 --> CSRF token verified
INFO - 2018-08-23 15:28:05 --> Input Class Initialized
INFO - 2018-08-23 15:28:05 --> Language Class Initialized
INFO - 2018-08-23 15:28:05 --> Loader Class Initialized
INFO - 2018-08-23 15:28:05 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:05 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:05 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:05 --> Controller Class Initialized
INFO - 2018-08-23 15:28:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:05 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:05 --> Form Validation Class Initialized
INFO - 2018-08-23 15:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:28:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:05 --> Config Class Initialized
INFO - 2018-08-23 15:28:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:05 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:05 --> URI Class Initialized
INFO - 2018-08-23 15:28:05 --> Router Class Initialized
INFO - 2018-08-23 15:28:05 --> Output Class Initialized
INFO - 2018-08-23 15:28:05 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:05 --> CSRF cookie sent
INFO - 2018-08-23 15:28:05 --> Input Class Initialized
INFO - 2018-08-23 15:28:05 --> Language Class Initialized
INFO - 2018-08-23 15:28:05 --> Loader Class Initialized
INFO - 2018-08-23 15:28:05 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:05 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:05 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:05 --> Controller Class Initialized
INFO - 2018-08-23 15:28:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:05 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:05 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/credit_cards.php
INFO - 2018-08-23 15:28:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:28:05 --> Final output sent to browser
DEBUG - 2018-08-23 15:28:05 --> Total execution time: 0.0440
INFO - 2018-08-23 15:28:11 --> Config Class Initialized
INFO - 2018-08-23 15:28:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:11 --> URI Class Initialized
INFO - 2018-08-23 15:28:11 --> Router Class Initialized
INFO - 2018-08-23 15:28:11 --> Output Class Initialized
INFO - 2018-08-23 15:28:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:11 --> CSRF cookie sent
INFO - 2018-08-23 15:28:11 --> CSRF token verified
INFO - 2018-08-23 15:28:11 --> Input Class Initialized
INFO - 2018-08-23 15:28:11 --> Language Class Initialized
INFO - 2018-08-23 15:28:11 --> Loader Class Initialized
INFO - 2018-08-23 15:28:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:11 --> Controller Class Initialized
INFO - 2018-08-23 15:28:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:11 --> Form Validation Class Initialized
INFO - 2018-08-23 15:28:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:28:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:11 --> Config Class Initialized
INFO - 2018-08-23 15:28:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:11 --> URI Class Initialized
INFO - 2018-08-23 15:28:11 --> Router Class Initialized
INFO - 2018-08-23 15:28:11 --> Output Class Initialized
INFO - 2018-08-23 15:28:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:11 --> CSRF cookie sent
INFO - 2018-08-23 15:28:11 --> Input Class Initialized
INFO - 2018-08-23 15:28:11 --> Language Class Initialized
INFO - 2018-08-23 15:28:11 --> Loader Class Initialized
INFO - 2018-08-23 15:28:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:11 --> Controller Class Initialized
INFO - 2018-08-23 15:28:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_debt.php
INFO - 2018-08-23 15:28:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:28:11 --> Final output sent to browser
DEBUG - 2018-08-23 15:28:11 --> Total execution time: 0.0368
INFO - 2018-08-23 15:28:19 --> Config Class Initialized
INFO - 2018-08-23 15:28:19 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:19 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:19 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:19 --> URI Class Initialized
INFO - 2018-08-23 15:28:19 --> Router Class Initialized
INFO - 2018-08-23 15:28:19 --> Output Class Initialized
INFO - 2018-08-23 15:28:19 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:19 --> CSRF cookie sent
INFO - 2018-08-23 15:28:19 --> CSRF token verified
INFO - 2018-08-23 15:28:19 --> Input Class Initialized
INFO - 2018-08-23 15:28:19 --> Language Class Initialized
INFO - 2018-08-23 15:28:19 --> Loader Class Initialized
INFO - 2018-08-23 15:28:19 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:19 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:19 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:19 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:19 --> Controller Class Initialized
INFO - 2018-08-23 15:28:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:19 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:19 --> Form Validation Class Initialized
INFO - 2018-08-23 15:28:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:28:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:19 --> Config Class Initialized
INFO - 2018-08-23 15:28:19 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:19 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:19 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:19 --> URI Class Initialized
INFO - 2018-08-23 15:28:19 --> Router Class Initialized
INFO - 2018-08-23 15:28:19 --> Output Class Initialized
INFO - 2018-08-23 15:28:19 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:19 --> CSRF cookie sent
INFO - 2018-08-23 15:28:19 --> Input Class Initialized
INFO - 2018-08-23 15:28:19 --> Language Class Initialized
INFO - 2018-08-23 15:28:19 --> Loader Class Initialized
INFO - 2018-08-23 15:28:19 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:19 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:19 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:19 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:19 --> Controller Class Initialized
INFO - 2018-08-23 15:28:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:19 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:19 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-08-23 15:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:28:19 --> Final output sent to browser
DEBUG - 2018-08-23 15:28:19 --> Total execution time: 0.0457
INFO - 2018-08-23 15:28:25 --> Config Class Initialized
INFO - 2018-08-23 15:28:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:25 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:25 --> URI Class Initialized
INFO - 2018-08-23 15:28:25 --> Router Class Initialized
INFO - 2018-08-23 15:28:25 --> Output Class Initialized
INFO - 2018-08-23 15:28:25 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:25 --> CSRF cookie sent
INFO - 2018-08-23 15:28:25 --> CSRF token verified
INFO - 2018-08-23 15:28:25 --> Input Class Initialized
INFO - 2018-08-23 15:28:25 --> Language Class Initialized
INFO - 2018-08-23 15:28:25 --> Loader Class Initialized
INFO - 2018-08-23 15:28:25 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:25 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:25 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:25 --> Controller Class Initialized
INFO - 2018-08-23 15:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:25 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:25 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:25 --> Form Validation Class Initialized
INFO - 2018-08-23 15:28:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:28:25 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:25 --> Config Class Initialized
INFO - 2018-08-23 15:28:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:25 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:25 --> URI Class Initialized
INFO - 2018-08-23 15:28:25 --> Router Class Initialized
INFO - 2018-08-23 15:28:25 --> Output Class Initialized
INFO - 2018-08-23 15:28:25 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:25 --> CSRF cookie sent
INFO - 2018-08-23 15:28:25 --> Input Class Initialized
INFO - 2018-08-23 15:28:25 --> Language Class Initialized
INFO - 2018-08-23 15:28:25 --> Loader Class Initialized
INFO - 2018-08-23 15:28:25 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:25 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:25 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:25 --> Controller Class Initialized
INFO - 2018-08-23 15:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:25 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:25 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:25 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-23 15:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:28:25 --> Final output sent to browser
DEBUG - 2018-08-23 15:28:25 --> Total execution time: 0.0504
INFO - 2018-08-23 15:28:45 --> Config Class Initialized
INFO - 2018-08-23 15:28:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:45 --> URI Class Initialized
INFO - 2018-08-23 15:28:45 --> Router Class Initialized
INFO - 2018-08-23 15:28:45 --> Output Class Initialized
INFO - 2018-08-23 15:28:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:45 --> CSRF cookie sent
INFO - 2018-08-23 15:28:45 --> CSRF token verified
INFO - 2018-08-23 15:28:45 --> Input Class Initialized
INFO - 2018-08-23 15:28:45 --> Language Class Initialized
INFO - 2018-08-23 15:28:45 --> Loader Class Initialized
INFO - 2018-08-23 15:28:45 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:45 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:45 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:45 --> Controller Class Initialized
INFO - 2018-08-23 15:28:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:45 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:45 --> Form Validation Class Initialized
INFO - 2018-08-23 15:28:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:28:45 --> Config Class Initialized
INFO - 2018-08-23 15:28:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:28:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:28:45 --> Utf8 Class Initialized
INFO - 2018-08-23 15:28:45 --> URI Class Initialized
INFO - 2018-08-23 15:28:45 --> Router Class Initialized
INFO - 2018-08-23 15:28:45 --> Output Class Initialized
INFO - 2018-08-23 15:28:45 --> Security Class Initialized
DEBUG - 2018-08-23 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:28:45 --> CSRF cookie sent
INFO - 2018-08-23 15:28:45 --> Input Class Initialized
INFO - 2018-08-23 15:28:45 --> Language Class Initialized
INFO - 2018-08-23 15:28:45 --> Loader Class Initialized
INFO - 2018-08-23 15:28:45 --> Helper loaded: url_helper
INFO - 2018-08-23 15:28:45 --> Helper loaded: form_helper
INFO - 2018-08-23 15:28:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:28:45 --> User Agent Class Initialized
INFO - 2018-08-23 15:28:45 --> Controller Class Initialized
INFO - 2018-08-23 15:28:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:28:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:28:45 --> Pixel_Model class loaded
INFO - 2018-08-23 15:28:45 --> Database Driver Class Initialized
INFO - 2018-08-23 15:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/finish.php
INFO - 2018-08-23 15:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:28:45 --> Final output sent to browser
DEBUG - 2018-08-23 15:28:45 --> Total execution time: 0.0413
INFO - 2018-08-23 15:29:21 --> Config Class Initialized
INFO - 2018-08-23 15:29:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:29:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:29:21 --> Utf8 Class Initialized
INFO - 2018-08-23 15:29:21 --> URI Class Initialized
INFO - 2018-08-23 15:29:21 --> Router Class Initialized
INFO - 2018-08-23 15:29:21 --> Output Class Initialized
INFO - 2018-08-23 15:29:21 --> Security Class Initialized
DEBUG - 2018-08-23 15:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:29:21 --> CSRF cookie sent
INFO - 2018-08-23 15:29:21 --> Input Class Initialized
INFO - 2018-08-23 15:29:21 --> Language Class Initialized
INFO - 2018-08-23 15:29:21 --> Loader Class Initialized
INFO - 2018-08-23 15:29:21 --> Helper loaded: url_helper
INFO - 2018-08-23 15:29:21 --> Helper loaded: form_helper
INFO - 2018-08-23 15:29:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:29:21 --> User Agent Class Initialized
INFO - 2018-08-23 15:29:21 --> Controller Class Initialized
INFO - 2018-08-23 15:29:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:29:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:29:21 --> Pixel_Model class loaded
INFO - 2018-08-23 15:29:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:29:21 --> Database Driver Class Initialized
INFO - 2018-08-23 15:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 15:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:29:21 --> Final output sent to browser
DEBUG - 2018-08-23 15:29:21 --> Total execution time: 0.0420
INFO - 2018-08-23 15:31:00 --> Config Class Initialized
INFO - 2018-08-23 15:31:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:00 --> URI Class Initialized
INFO - 2018-08-23 15:31:00 --> Router Class Initialized
INFO - 2018-08-23 15:31:00 --> Output Class Initialized
INFO - 2018-08-23 15:31:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:00 --> CSRF cookie sent
INFO - 2018-08-23 15:31:00 --> CSRF token verified
INFO - 2018-08-23 15:31:00 --> Input Class Initialized
INFO - 2018-08-23 15:31:00 --> Language Class Initialized
INFO - 2018-08-23 15:31:00 --> Loader Class Initialized
INFO - 2018-08-23 15:31:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:00 --> Controller Class Initialized
INFO - 2018-08-23 15:31:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:00 --> Form Validation Class Initialized
INFO - 2018-08-23 15:31:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:31:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:00 --> Config Class Initialized
INFO - 2018-08-23 15:31:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:00 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:00 --> URI Class Initialized
INFO - 2018-08-23 15:31:00 --> Router Class Initialized
INFO - 2018-08-23 15:31:00 --> Output Class Initialized
INFO - 2018-08-23 15:31:00 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:00 --> CSRF cookie sent
INFO - 2018-08-23 15:31:00 --> Input Class Initialized
INFO - 2018-08-23 15:31:00 --> Language Class Initialized
INFO - 2018-08-23 15:31:00 --> Loader Class Initialized
INFO - 2018-08-23 15:31:00 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:00 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:00 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:00 --> Controller Class Initialized
INFO - 2018-08-23 15:31:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:00 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:00 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 15:31:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:31:00 --> Final output sent to browser
DEBUG - 2018-08-23 15:31:00 --> Total execution time: 0.0459
INFO - 2018-08-23 15:31:11 --> Config Class Initialized
INFO - 2018-08-23 15:31:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:11 --> URI Class Initialized
INFO - 2018-08-23 15:31:11 --> Router Class Initialized
INFO - 2018-08-23 15:31:11 --> Output Class Initialized
INFO - 2018-08-23 15:31:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:11 --> CSRF cookie sent
INFO - 2018-08-23 15:31:11 --> CSRF token verified
INFO - 2018-08-23 15:31:11 --> Input Class Initialized
INFO - 2018-08-23 15:31:11 --> Language Class Initialized
INFO - 2018-08-23 15:31:11 --> Loader Class Initialized
INFO - 2018-08-23 15:31:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:11 --> Controller Class Initialized
INFO - 2018-08-23 15:31:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:11 --> Form Validation Class Initialized
INFO - 2018-08-23 15:31:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:31:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:11 --> Config Class Initialized
INFO - 2018-08-23 15:31:11 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:11 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:11 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:11 --> URI Class Initialized
INFO - 2018-08-23 15:31:11 --> Router Class Initialized
INFO - 2018-08-23 15:31:11 --> Output Class Initialized
INFO - 2018-08-23 15:31:11 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:11 --> CSRF cookie sent
INFO - 2018-08-23 15:31:11 --> Input Class Initialized
INFO - 2018-08-23 15:31:11 --> Language Class Initialized
INFO - 2018-08-23 15:31:11 --> Loader Class Initialized
INFO - 2018-08-23 15:31:11 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:11 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:11 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:11 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:11 --> Controller Class Initialized
INFO - 2018-08-23 15:31:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:11 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:11 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 15:31:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:31:11 --> Final output sent to browser
DEBUG - 2018-08-23 15:31:11 --> Total execution time: 0.0428
INFO - 2018-08-23 15:31:20 --> Config Class Initialized
INFO - 2018-08-23 15:31:20 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:20 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:20 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:20 --> URI Class Initialized
INFO - 2018-08-23 15:31:20 --> Router Class Initialized
INFO - 2018-08-23 15:31:20 --> Output Class Initialized
INFO - 2018-08-23 15:31:20 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:20 --> CSRF cookie sent
INFO - 2018-08-23 15:31:20 --> CSRF token verified
INFO - 2018-08-23 15:31:20 --> Input Class Initialized
INFO - 2018-08-23 15:31:20 --> Language Class Initialized
INFO - 2018-08-23 15:31:20 --> Loader Class Initialized
INFO - 2018-08-23 15:31:20 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:20 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:20 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:20 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:20 --> Controller Class Initialized
INFO - 2018-08-23 15:31:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:20 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:20 --> Form Validation Class Initialized
INFO - 2018-08-23 15:31:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:31:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:20 --> Config Class Initialized
INFO - 2018-08-23 15:31:20 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:20 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:20 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:20 --> URI Class Initialized
INFO - 2018-08-23 15:31:20 --> Router Class Initialized
INFO - 2018-08-23 15:31:20 --> Output Class Initialized
INFO - 2018-08-23 15:31:20 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:20 --> CSRF cookie sent
INFO - 2018-08-23 15:31:20 --> Input Class Initialized
INFO - 2018-08-23 15:31:20 --> Language Class Initialized
INFO - 2018-08-23 15:31:20 --> Loader Class Initialized
INFO - 2018-08-23 15:31:20 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:20 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:20 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:20 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:20 --> Controller Class Initialized
INFO - 2018-08-23 15:31:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:20 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:20 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 15:31:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:31:20 --> Final output sent to browser
DEBUG - 2018-08-23 15:31:20 --> Total execution time: 0.0530
INFO - 2018-08-23 15:31:30 --> Config Class Initialized
INFO - 2018-08-23 15:31:30 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:30 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:30 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:30 --> URI Class Initialized
INFO - 2018-08-23 15:31:30 --> Router Class Initialized
INFO - 2018-08-23 15:31:30 --> Output Class Initialized
INFO - 2018-08-23 15:31:30 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:30 --> CSRF cookie sent
INFO - 2018-08-23 15:31:30 --> CSRF token verified
INFO - 2018-08-23 15:31:30 --> Input Class Initialized
INFO - 2018-08-23 15:31:30 --> Language Class Initialized
INFO - 2018-08-23 15:31:30 --> Loader Class Initialized
INFO - 2018-08-23 15:31:30 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:30 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:30 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:30 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:30 --> Controller Class Initialized
INFO - 2018-08-23 15:31:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:30 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:30 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:30 --> Form Validation Class Initialized
INFO - 2018-08-23 15:31:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 15:31:30 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:30 --> Config Class Initialized
INFO - 2018-08-23 15:31:30 --> Hooks Class Initialized
DEBUG - 2018-08-23 15:31:30 --> UTF-8 Support Enabled
INFO - 2018-08-23 15:31:30 --> Utf8 Class Initialized
INFO - 2018-08-23 15:31:30 --> URI Class Initialized
INFO - 2018-08-23 15:31:30 --> Router Class Initialized
INFO - 2018-08-23 15:31:30 --> Output Class Initialized
INFO - 2018-08-23 15:31:30 --> Security Class Initialized
DEBUG - 2018-08-23 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 15:31:30 --> CSRF cookie sent
INFO - 2018-08-23 15:31:30 --> Input Class Initialized
INFO - 2018-08-23 15:31:30 --> Language Class Initialized
INFO - 2018-08-23 15:31:30 --> Loader Class Initialized
INFO - 2018-08-23 15:31:30 --> Helper loaded: url_helper
INFO - 2018-08-23 15:31:30 --> Helper loaded: form_helper
INFO - 2018-08-23 15:31:30 --> Helper loaded: language_helper
DEBUG - 2018-08-23 15:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 15:31:30 --> User Agent Class Initialized
INFO - 2018-08-23 15:31:30 --> Controller Class Initialized
INFO - 2018-08-23 15:31:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 15:31:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 15:31:30 --> Pixel_Model class loaded
INFO - 2018-08-23 15:31:30 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:30 --> Database Driver Class Initialized
INFO - 2018-08-23 15:31:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 15:31:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 15:31:30 --> Final output sent to browser
DEBUG - 2018-08-23 15:31:30 --> Total execution time: 0.0446
INFO - 2018-08-23 19:01:03 --> Config Class Initialized
INFO - 2018-08-23 19:01:03 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:01:03 --> Utf8 Class Initialized
INFO - 2018-08-23 19:01:03 --> URI Class Initialized
INFO - 2018-08-23 19:01:03 --> Router Class Initialized
INFO - 2018-08-23 19:01:03 --> Output Class Initialized
INFO - 2018-08-23 19:01:03 --> Security Class Initialized
DEBUG - 2018-08-23 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:01:03 --> CSRF cookie sent
INFO - 2018-08-23 19:01:03 --> Input Class Initialized
INFO - 2018-08-23 19:01:03 --> Language Class Initialized
ERROR - 2018-08-23 19:01:03 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-23 19:01:06 --> Config Class Initialized
INFO - 2018-08-23 19:01:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:01:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:01:06 --> Utf8 Class Initialized
INFO - 2018-08-23 19:01:06 --> URI Class Initialized
DEBUG - 2018-08-23 19:01:06 --> No URI present. Default controller set.
INFO - 2018-08-23 19:01:06 --> Router Class Initialized
INFO - 2018-08-23 19:01:06 --> Output Class Initialized
INFO - 2018-08-23 19:01:06 --> Security Class Initialized
DEBUG - 2018-08-23 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:01:06 --> CSRF cookie sent
INFO - 2018-08-23 19:01:06 --> Input Class Initialized
INFO - 2018-08-23 19:01:06 --> Language Class Initialized
INFO - 2018-08-23 19:01:06 --> Loader Class Initialized
INFO - 2018-08-23 19:01:06 --> Helper loaded: url_helper
INFO - 2018-08-23 19:01:06 --> Helper loaded: form_helper
INFO - 2018-08-23 19:01:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:01:06 --> User Agent Class Initialized
INFO - 2018-08-23 19:01:06 --> Controller Class Initialized
INFO - 2018-08-23 19:01:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:01:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:01:06 --> Pixel_Model class loaded
INFO - 2018-08-23 19:01:06 --> Database Driver Class Initialized
INFO - 2018-08-23 19:01:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 19:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:01:06 --> Final output sent to browser
DEBUG - 2018-08-23 19:01:06 --> Total execution time: 0.0479
INFO - 2018-08-23 19:01:09 --> Config Class Initialized
INFO - 2018-08-23 19:01:09 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:01:09 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:01:09 --> Utf8 Class Initialized
INFO - 2018-08-23 19:01:09 --> URI Class Initialized
INFO - 2018-08-23 19:01:09 --> Router Class Initialized
INFO - 2018-08-23 19:01:09 --> Output Class Initialized
INFO - 2018-08-23 19:01:09 --> Security Class Initialized
DEBUG - 2018-08-23 19:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:01:09 --> CSRF cookie sent
INFO - 2018-08-23 19:01:09 --> Input Class Initialized
INFO - 2018-08-23 19:01:09 --> Language Class Initialized
INFO - 2018-08-23 19:01:09 --> Loader Class Initialized
INFO - 2018-08-23 19:01:09 --> Helper loaded: url_helper
INFO - 2018-08-23 19:01:09 --> Helper loaded: form_helper
INFO - 2018-08-23 19:01:09 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:01:09 --> User Agent Class Initialized
INFO - 2018-08-23 19:01:09 --> Controller Class Initialized
INFO - 2018-08-23 19:01:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:01:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:01:09 --> Pixel_Model class loaded
INFO - 2018-08-23 19:01:09 --> Database Driver Class Initialized
INFO - 2018-08-23 19:01:09 --> Model "QuestionsModel" initialized
ERROR - 2018-08-23 19:01:09 --> Query error: Table 'famiquity.questions' doesn't exist - Invalid query: SELECT *
FROM `questions`
WHERE `status` = 1
ERROR - 2018-08-23 19:01:09 --> Severity: Error --> Call to a member function num_rows() on boolean /home/fxp6bn7rqemh/public_html/application/models/QuestionsModel.php 25
INFO - 2018-08-23 19:02:32 --> Config Class Initialized
INFO - 2018-08-23 19:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:32 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:32 --> URI Class Initialized
INFO - 2018-08-23 19:02:32 --> Router Class Initialized
INFO - 2018-08-23 19:02:32 --> Output Class Initialized
INFO - 2018-08-23 19:02:32 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:32 --> CSRF cookie sent
INFO - 2018-08-23 19:02:32 --> Input Class Initialized
INFO - 2018-08-23 19:02:32 --> Language Class Initialized
INFO - 2018-08-23 19:02:32 --> Loader Class Initialized
INFO - 2018-08-23 19:02:32 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:32 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:32 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:32 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:32 --> Controller Class Initialized
INFO - 2018-08-23 19:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:32 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:32 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-23 19:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:32 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:32 --> Total execution time: 0.0470
INFO - 2018-08-23 19:02:39 --> Config Class Initialized
INFO - 2018-08-23 19:02:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:39 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:39 --> URI Class Initialized
INFO - 2018-08-23 19:02:39 --> Router Class Initialized
INFO - 2018-08-23 19:02:39 --> Output Class Initialized
INFO - 2018-08-23 19:02:39 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:39 --> CSRF cookie sent
INFO - 2018-08-23 19:02:39 --> CSRF token verified
INFO - 2018-08-23 19:02:39 --> Input Class Initialized
INFO - 2018-08-23 19:02:39 --> Language Class Initialized
INFO - 2018-08-23 19:02:39 --> Loader Class Initialized
INFO - 2018-08-23 19:02:39 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:39 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:39 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:39 --> Controller Class Initialized
INFO - 2018-08-23 19:02:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:39 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:39 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:39 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:39 --> Config Class Initialized
INFO - 2018-08-23 19:02:39 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:39 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:39 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:39 --> URI Class Initialized
INFO - 2018-08-23 19:02:39 --> Router Class Initialized
INFO - 2018-08-23 19:02:39 --> Output Class Initialized
INFO - 2018-08-23 19:02:39 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:39 --> CSRF cookie sent
INFO - 2018-08-23 19:02:39 --> Input Class Initialized
INFO - 2018-08-23 19:02:39 --> Language Class Initialized
INFO - 2018-08-23 19:02:39 --> Loader Class Initialized
INFO - 2018-08-23 19:02:39 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:39 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:39 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:39 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:39 --> Controller Class Initialized
INFO - 2018-08-23 19:02:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:39 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:39 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:39 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 19:02:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:39 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:39 --> Total execution time: 0.0474
INFO - 2018-08-23 19:02:42 --> Config Class Initialized
INFO - 2018-08-23 19:02:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:42 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:42 --> URI Class Initialized
INFO - 2018-08-23 19:02:42 --> Router Class Initialized
INFO - 2018-08-23 19:02:42 --> Output Class Initialized
INFO - 2018-08-23 19:02:42 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:42 --> CSRF cookie sent
INFO - 2018-08-23 19:02:42 --> CSRF token verified
INFO - 2018-08-23 19:02:42 --> Input Class Initialized
INFO - 2018-08-23 19:02:42 --> Language Class Initialized
INFO - 2018-08-23 19:02:42 --> Loader Class Initialized
INFO - 2018-08-23 19:02:42 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:42 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:42 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:42 --> Controller Class Initialized
INFO - 2018-08-23 19:02:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:42 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:42 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:42 --> Form Validation Class Initialized
INFO - 2018-08-23 19:02:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:02:42 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:42 --> Config Class Initialized
INFO - 2018-08-23 19:02:42 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:42 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:42 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:42 --> URI Class Initialized
INFO - 2018-08-23 19:02:42 --> Router Class Initialized
INFO - 2018-08-23 19:02:42 --> Output Class Initialized
INFO - 2018-08-23 19:02:42 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:42 --> CSRF cookie sent
INFO - 2018-08-23 19:02:42 --> Input Class Initialized
INFO - 2018-08-23 19:02:42 --> Language Class Initialized
INFO - 2018-08-23 19:02:42 --> Loader Class Initialized
INFO - 2018-08-23 19:02:42 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:42 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:42 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:42 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:42 --> Controller Class Initialized
INFO - 2018-08-23 19:02:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:42 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:42 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:42 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-23 19:02:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:42 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:42 --> Total execution time: 0.0485
INFO - 2018-08-23 19:02:45 --> Config Class Initialized
INFO - 2018-08-23 19:02:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:45 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:45 --> URI Class Initialized
INFO - 2018-08-23 19:02:45 --> Router Class Initialized
INFO - 2018-08-23 19:02:45 --> Output Class Initialized
INFO - 2018-08-23 19:02:45 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:45 --> CSRF cookie sent
INFO - 2018-08-23 19:02:45 --> CSRF token verified
INFO - 2018-08-23 19:02:45 --> Input Class Initialized
INFO - 2018-08-23 19:02:45 --> Language Class Initialized
INFO - 2018-08-23 19:02:45 --> Loader Class Initialized
INFO - 2018-08-23 19:02:45 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:45 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:45 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:45 --> Controller Class Initialized
INFO - 2018-08-23 19:02:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:45 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:45 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:45 --> Form Validation Class Initialized
INFO - 2018-08-23 19:02:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:02:45 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:45 --> Config Class Initialized
INFO - 2018-08-23 19:02:45 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:45 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:45 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:45 --> URI Class Initialized
INFO - 2018-08-23 19:02:45 --> Router Class Initialized
INFO - 2018-08-23 19:02:45 --> Output Class Initialized
INFO - 2018-08-23 19:02:45 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:45 --> CSRF cookie sent
INFO - 2018-08-23 19:02:45 --> Input Class Initialized
INFO - 2018-08-23 19:02:45 --> Language Class Initialized
INFO - 2018-08-23 19:02:45 --> Loader Class Initialized
INFO - 2018-08-23 19:02:45 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:45 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:45 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:45 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:45 --> Controller Class Initialized
INFO - 2018-08-23 19:02:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:45 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:45 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:45 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 19:02:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:45 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:45 --> Total execution time: 0.0464
INFO - 2018-08-23 19:02:48 --> Config Class Initialized
INFO - 2018-08-23 19:02:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:48 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:48 --> URI Class Initialized
INFO - 2018-08-23 19:02:48 --> Router Class Initialized
INFO - 2018-08-23 19:02:48 --> Output Class Initialized
INFO - 2018-08-23 19:02:48 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:48 --> CSRF cookie sent
INFO - 2018-08-23 19:02:48 --> CSRF token verified
INFO - 2018-08-23 19:02:48 --> Input Class Initialized
INFO - 2018-08-23 19:02:48 --> Language Class Initialized
INFO - 2018-08-23 19:02:48 --> Loader Class Initialized
INFO - 2018-08-23 19:02:48 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:48 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:48 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:48 --> Controller Class Initialized
INFO - 2018-08-23 19:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:48 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:48 --> Form Validation Class Initialized
INFO - 2018-08-23 19:02:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:48 --> Config Class Initialized
INFO - 2018-08-23 19:02:48 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:48 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:48 --> URI Class Initialized
INFO - 2018-08-23 19:02:48 --> Router Class Initialized
INFO - 2018-08-23 19:02:48 --> Output Class Initialized
INFO - 2018-08-23 19:02:48 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:48 --> CSRF cookie sent
INFO - 2018-08-23 19:02:48 --> Input Class Initialized
INFO - 2018-08-23 19:02:48 --> Language Class Initialized
INFO - 2018-08-23 19:02:48 --> Loader Class Initialized
INFO - 2018-08-23 19:02:48 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:48 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:48 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:48 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:48 --> Controller Class Initialized
INFO - 2018-08-23 19:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:48 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:48 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 19:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:48 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:48 --> Total execution time: 0.0433
INFO - 2018-08-23 19:02:55 --> Config Class Initialized
INFO - 2018-08-23 19:02:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:55 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:55 --> URI Class Initialized
INFO - 2018-08-23 19:02:55 --> Router Class Initialized
INFO - 2018-08-23 19:02:55 --> Output Class Initialized
INFO - 2018-08-23 19:02:55 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:55 --> CSRF cookie sent
INFO - 2018-08-23 19:02:55 --> CSRF token verified
INFO - 2018-08-23 19:02:55 --> Input Class Initialized
INFO - 2018-08-23 19:02:55 --> Language Class Initialized
INFO - 2018-08-23 19:02:55 --> Loader Class Initialized
INFO - 2018-08-23 19:02:55 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:55 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:55 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:55 --> Controller Class Initialized
INFO - 2018-08-23 19:02:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:55 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:55 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:55 --> Form Validation Class Initialized
INFO - 2018-08-23 19:02:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:02:55 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:55 --> Config Class Initialized
INFO - 2018-08-23 19:02:55 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:02:55 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:02:55 --> Utf8 Class Initialized
INFO - 2018-08-23 19:02:55 --> URI Class Initialized
INFO - 2018-08-23 19:02:55 --> Router Class Initialized
INFO - 2018-08-23 19:02:55 --> Output Class Initialized
INFO - 2018-08-23 19:02:55 --> Security Class Initialized
DEBUG - 2018-08-23 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:02:55 --> CSRF cookie sent
INFO - 2018-08-23 19:02:55 --> Input Class Initialized
INFO - 2018-08-23 19:02:55 --> Language Class Initialized
INFO - 2018-08-23 19:02:55 --> Loader Class Initialized
INFO - 2018-08-23 19:02:55 --> Helper loaded: url_helper
INFO - 2018-08-23 19:02:55 --> Helper loaded: form_helper
INFO - 2018-08-23 19:02:55 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:02:55 --> User Agent Class Initialized
INFO - 2018-08-23 19:02:55 --> Controller Class Initialized
INFO - 2018-08-23 19:02:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:02:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:02:55 --> Pixel_Model class loaded
INFO - 2018-08-23 19:02:55 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:55 --> Database Driver Class Initialized
INFO - 2018-08-23 19:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-23 19:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:02:55 --> Final output sent to browser
DEBUG - 2018-08-23 19:02:55 --> Total execution time: 0.0442
INFO - 2018-08-23 19:03:03 --> Config Class Initialized
INFO - 2018-08-23 19:03:03 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:03 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:03 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:03 --> URI Class Initialized
INFO - 2018-08-23 19:03:03 --> Router Class Initialized
INFO - 2018-08-23 19:03:03 --> Output Class Initialized
INFO - 2018-08-23 19:03:03 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:03 --> CSRF cookie sent
INFO - 2018-08-23 19:03:03 --> CSRF token verified
INFO - 2018-08-23 19:03:03 --> Input Class Initialized
INFO - 2018-08-23 19:03:03 --> Language Class Initialized
INFO - 2018-08-23 19:03:03 --> Loader Class Initialized
INFO - 2018-08-23 19:03:03 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:03 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:03 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:03 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:03 --> Controller Class Initialized
INFO - 2018-08-23 19:03:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:03 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:03 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:03 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:03 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:03 --> Config Class Initialized
INFO - 2018-08-23 19:03:03 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:03 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:03 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:03 --> URI Class Initialized
INFO - 2018-08-23 19:03:03 --> Router Class Initialized
INFO - 2018-08-23 19:03:03 --> Output Class Initialized
INFO - 2018-08-23 19:03:03 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:03 --> CSRF cookie sent
INFO - 2018-08-23 19:03:03 --> Input Class Initialized
INFO - 2018-08-23 19:03:03 --> Language Class Initialized
INFO - 2018-08-23 19:03:03 --> Loader Class Initialized
INFO - 2018-08-23 19:03:03 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:03 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:03 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:03 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:03 --> Controller Class Initialized
INFO - 2018-08-23 19:03:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:03 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:03 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:03 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 19:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:03 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:03 --> Total execution time: 0.0443
INFO - 2018-08-23 19:03:10 --> Config Class Initialized
INFO - 2018-08-23 19:03:10 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:10 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:10 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:10 --> URI Class Initialized
INFO - 2018-08-23 19:03:10 --> Router Class Initialized
INFO - 2018-08-23 19:03:10 --> Output Class Initialized
INFO - 2018-08-23 19:03:10 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:10 --> CSRF cookie sent
INFO - 2018-08-23 19:03:10 --> CSRF token verified
INFO - 2018-08-23 19:03:10 --> Input Class Initialized
INFO - 2018-08-23 19:03:10 --> Language Class Initialized
INFO - 2018-08-23 19:03:10 --> Loader Class Initialized
INFO - 2018-08-23 19:03:10 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:10 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:10 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:10 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:10 --> Controller Class Initialized
INFO - 2018-08-23 19:03:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:10 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:10 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:10 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:10 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:10 --> Config Class Initialized
INFO - 2018-08-23 19:03:10 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:10 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:10 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:10 --> URI Class Initialized
INFO - 2018-08-23 19:03:10 --> Router Class Initialized
INFO - 2018-08-23 19:03:10 --> Output Class Initialized
INFO - 2018-08-23 19:03:10 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:10 --> CSRF cookie sent
INFO - 2018-08-23 19:03:10 --> Input Class Initialized
INFO - 2018-08-23 19:03:10 --> Language Class Initialized
INFO - 2018-08-23 19:03:10 --> Loader Class Initialized
INFO - 2018-08-23 19:03:10 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:10 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:10 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:10 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:10 --> Controller Class Initialized
INFO - 2018-08-23 19:03:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:10 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:10 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:10 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 19:03:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:10 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:10 --> Total execution time: 0.0471
INFO - 2018-08-23 19:03:14 --> Config Class Initialized
INFO - 2018-08-23 19:03:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:14 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:14 --> URI Class Initialized
INFO - 2018-08-23 19:03:14 --> Router Class Initialized
INFO - 2018-08-23 19:03:14 --> Output Class Initialized
INFO - 2018-08-23 19:03:14 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:14 --> CSRF cookie sent
INFO - 2018-08-23 19:03:14 --> CSRF token verified
INFO - 2018-08-23 19:03:14 --> Input Class Initialized
INFO - 2018-08-23 19:03:14 --> Language Class Initialized
INFO - 2018-08-23 19:03:14 --> Loader Class Initialized
INFO - 2018-08-23 19:03:14 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:14 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:14 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:14 --> Controller Class Initialized
INFO - 2018-08-23 19:03:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:14 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:14 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:14 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:14 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:14 --> Config Class Initialized
INFO - 2018-08-23 19:03:14 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:14 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:14 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:14 --> URI Class Initialized
INFO - 2018-08-23 19:03:14 --> Router Class Initialized
INFO - 2018-08-23 19:03:14 --> Output Class Initialized
INFO - 2018-08-23 19:03:14 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:14 --> CSRF cookie sent
INFO - 2018-08-23 19:03:14 --> Input Class Initialized
INFO - 2018-08-23 19:03:14 --> Language Class Initialized
INFO - 2018-08-23 19:03:14 --> Loader Class Initialized
INFO - 2018-08-23 19:03:14 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:14 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:14 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:14 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:14 --> Controller Class Initialized
INFO - 2018-08-23 19:03:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:14 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:14 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:14 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 19:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:14 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:14 --> Total execution time: 0.0474
INFO - 2018-08-23 19:03:17 --> Config Class Initialized
INFO - 2018-08-23 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:17 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:17 --> URI Class Initialized
INFO - 2018-08-23 19:03:17 --> Router Class Initialized
INFO - 2018-08-23 19:03:17 --> Output Class Initialized
INFO - 2018-08-23 19:03:17 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:17 --> CSRF cookie sent
INFO - 2018-08-23 19:03:17 --> CSRF token verified
INFO - 2018-08-23 19:03:17 --> Input Class Initialized
INFO - 2018-08-23 19:03:17 --> Language Class Initialized
INFO - 2018-08-23 19:03:17 --> Loader Class Initialized
INFO - 2018-08-23 19:03:17 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:17 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:17 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:17 --> Controller Class Initialized
INFO - 2018-08-23 19:03:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:17 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:17 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:17 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:17 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:17 --> Config Class Initialized
INFO - 2018-08-23 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:17 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:17 --> URI Class Initialized
INFO - 2018-08-23 19:03:17 --> Router Class Initialized
INFO - 2018-08-23 19:03:17 --> Output Class Initialized
INFO - 2018-08-23 19:03:17 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:17 --> CSRF cookie sent
INFO - 2018-08-23 19:03:17 --> Input Class Initialized
INFO - 2018-08-23 19:03:17 --> Language Class Initialized
INFO - 2018-08-23 19:03:17 --> Loader Class Initialized
INFO - 2018-08-23 19:03:17 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:17 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:17 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:17 --> Controller Class Initialized
INFO - 2018-08-23 19:03:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:17 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:17 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:17 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-23 19:03:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:17 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:17 --> Total execution time: 0.0539
INFO - 2018-08-23 19:03:18 --> Config Class Initialized
INFO - 2018-08-23 19:03:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:18 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:18 --> URI Class Initialized
INFO - 2018-08-23 19:03:18 --> Router Class Initialized
INFO - 2018-08-23 19:03:18 --> Output Class Initialized
INFO - 2018-08-23 19:03:18 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:18 --> CSRF cookie sent
INFO - 2018-08-23 19:03:18 --> CSRF token verified
INFO - 2018-08-23 19:03:18 --> Input Class Initialized
INFO - 2018-08-23 19:03:18 --> Language Class Initialized
INFO - 2018-08-23 19:03:18 --> Loader Class Initialized
INFO - 2018-08-23 19:03:18 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:18 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:18 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:18 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:18 --> Controller Class Initialized
INFO - 2018-08-23 19:03:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:18 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:18 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:18 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:18 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:18 --> Config Class Initialized
INFO - 2018-08-23 19:03:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:18 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:18 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:18 --> URI Class Initialized
INFO - 2018-08-23 19:03:18 --> Router Class Initialized
INFO - 2018-08-23 19:03:19 --> Output Class Initialized
INFO - 2018-08-23 19:03:19 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:19 --> CSRF cookie sent
INFO - 2018-08-23 19:03:19 --> Input Class Initialized
INFO - 2018-08-23 19:03:19 --> Language Class Initialized
INFO - 2018-08-23 19:03:19 --> Loader Class Initialized
INFO - 2018-08-23 19:03:19 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:19 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:19 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:19 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:19 --> Controller Class Initialized
INFO - 2018-08-23 19:03:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:19 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:19 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:19 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-23 19:03:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:19 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:19 --> Total execution time: 0.0671
INFO - 2018-08-23 19:03:25 --> Config Class Initialized
INFO - 2018-08-23 19:03:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:25 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:25 --> URI Class Initialized
INFO - 2018-08-23 19:03:25 --> Router Class Initialized
INFO - 2018-08-23 19:03:25 --> Output Class Initialized
INFO - 2018-08-23 19:03:25 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:25 --> CSRF cookie sent
INFO - 2018-08-23 19:03:25 --> CSRF token verified
INFO - 2018-08-23 19:03:25 --> Input Class Initialized
INFO - 2018-08-23 19:03:25 --> Language Class Initialized
INFO - 2018-08-23 19:03:25 --> Loader Class Initialized
INFO - 2018-08-23 19:03:25 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:25 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:25 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:25 --> Controller Class Initialized
INFO - 2018-08-23 19:03:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:25 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:25 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:25 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:25 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:26 --> Config Class Initialized
INFO - 2018-08-23 19:03:26 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:26 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:26 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:26 --> URI Class Initialized
INFO - 2018-08-23 19:03:26 --> Router Class Initialized
INFO - 2018-08-23 19:03:26 --> Output Class Initialized
INFO - 2018-08-23 19:03:26 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:26 --> CSRF cookie sent
INFO - 2018-08-23 19:03:26 --> Input Class Initialized
INFO - 2018-08-23 19:03:26 --> Language Class Initialized
INFO - 2018-08-23 19:03:26 --> Loader Class Initialized
INFO - 2018-08-23 19:03:26 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:26 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:26 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:26 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:26 --> Controller Class Initialized
INFO - 2018-08-23 19:03:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:26 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:26 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:26 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 19:03:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:26 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:26 --> Total execution time: 0.0475
INFO - 2018-08-23 19:03:28 --> Config Class Initialized
INFO - 2018-08-23 19:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:28 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:28 --> URI Class Initialized
INFO - 2018-08-23 19:03:28 --> Router Class Initialized
INFO - 2018-08-23 19:03:28 --> Output Class Initialized
INFO - 2018-08-23 19:03:28 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:28 --> CSRF cookie sent
INFO - 2018-08-23 19:03:28 --> CSRF token verified
INFO - 2018-08-23 19:03:28 --> Input Class Initialized
INFO - 2018-08-23 19:03:28 --> Language Class Initialized
INFO - 2018-08-23 19:03:28 --> Loader Class Initialized
INFO - 2018-08-23 19:03:28 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:28 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:28 --> Controller Class Initialized
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:28 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:28 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:28 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:03:28 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:28 --> Config Class Initialized
INFO - 2018-08-23 19:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:28 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:28 --> URI Class Initialized
INFO - 2018-08-23 19:03:28 --> Router Class Initialized
INFO - 2018-08-23 19:03:28 --> Output Class Initialized
INFO - 2018-08-23 19:03:28 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:28 --> CSRF cookie sent
INFO - 2018-08-23 19:03:28 --> Input Class Initialized
INFO - 2018-08-23 19:03:28 --> Language Class Initialized
INFO - 2018-08-23 19:03:28 --> Loader Class Initialized
INFO - 2018-08-23 19:03:28 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:28 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:28 --> Controller Class Initialized
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:28 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:28 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:28 --> Config Class Initialized
INFO - 2018-08-23 19:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:28 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:28 --> URI Class Initialized
INFO - 2018-08-23 19:03:28 --> Router Class Initialized
INFO - 2018-08-23 19:03:28 --> Output Class Initialized
INFO - 2018-08-23 19:03:28 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:28 --> CSRF cookie sent
INFO - 2018-08-23 19:03:28 --> Input Class Initialized
INFO - 2018-08-23 19:03:28 --> Language Class Initialized
INFO - 2018-08-23 19:03:28 --> Loader Class Initialized
INFO - 2018-08-23 19:03:28 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:28 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:28 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:28 --> Controller Class Initialized
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:28 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:28 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:28 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-23 19:03:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 19:03:28 --> Could not find the language line "req_email"
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-23 19:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:28 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:28 --> Total execution time: 0.0362
INFO - 2018-08-23 19:03:35 --> Config Class Initialized
INFO - 2018-08-23 19:03:35 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:35 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:35 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:35 --> URI Class Initialized
INFO - 2018-08-23 19:03:35 --> Router Class Initialized
INFO - 2018-08-23 19:03:35 --> Output Class Initialized
INFO - 2018-08-23 19:03:35 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:35 --> CSRF cookie sent
INFO - 2018-08-23 19:03:35 --> Input Class Initialized
INFO - 2018-08-23 19:03:35 --> Language Class Initialized
INFO - 2018-08-23 19:03:35 --> Loader Class Initialized
INFO - 2018-08-23 19:03:35 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:35 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:35 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:35 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:35 --> Controller Class Initialized
INFO - 2018-08-23 19:03:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 19:03:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 19:03:35 --> Could not find the language line "req_email"
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-23 19:03:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:35 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:35 --> Total execution time: 0.0236
INFO - 2018-08-23 19:03:43 --> Config Class Initialized
INFO - 2018-08-23 19:03:43 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:43 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:43 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:43 --> URI Class Initialized
INFO - 2018-08-23 19:03:43 --> Router Class Initialized
INFO - 2018-08-23 19:03:43 --> Output Class Initialized
INFO - 2018-08-23 19:03:43 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:43 --> CSRF cookie sent
INFO - 2018-08-23 19:03:43 --> CSRF token verified
INFO - 2018-08-23 19:03:43 --> Input Class Initialized
INFO - 2018-08-23 19:03:43 --> Language Class Initialized
INFO - 2018-08-23 19:03:43 --> Loader Class Initialized
INFO - 2018-08-23 19:03:43 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:43 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:43 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:43 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:43 --> Controller Class Initialized
INFO - 2018-08-23 19:03:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-23 19:03:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 19:03:44 --> Form Validation Class Initialized
INFO - 2018-08-23 19:03:44 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:44 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:44 --> Model "AuthenticationModel" initialized
INFO - 2018-08-23 19:03:44 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:44 --> Config Class Initialized
INFO - 2018-08-23 19:03:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:44 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:44 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:44 --> URI Class Initialized
INFO - 2018-08-23 19:03:44 --> Router Class Initialized
INFO - 2018-08-23 19:03:44 --> Output Class Initialized
INFO - 2018-08-23 19:03:44 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:44 --> CSRF cookie sent
INFO - 2018-08-23 19:03:44 --> Input Class Initialized
INFO - 2018-08-23 19:03:44 --> Language Class Initialized
INFO - 2018-08-23 19:03:44 --> Loader Class Initialized
INFO - 2018-08-23 19:03:44 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:44 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:44 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:44 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:44 --> Controller Class Initialized
INFO - 2018-08-23 19:03:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:44 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:44 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:44 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-23 19:03:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:44 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:44 --> Total execution time: 0.0415
INFO - 2018-08-23 19:03:47 --> Config Class Initialized
INFO - 2018-08-23 19:03:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:03:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:03:47 --> Utf8 Class Initialized
INFO - 2018-08-23 19:03:47 --> URI Class Initialized
INFO - 2018-08-23 19:03:47 --> Router Class Initialized
INFO - 2018-08-23 19:03:47 --> Output Class Initialized
INFO - 2018-08-23 19:03:47 --> Security Class Initialized
DEBUG - 2018-08-23 19:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:03:47 --> CSRF cookie sent
INFO - 2018-08-23 19:03:47 --> Input Class Initialized
INFO - 2018-08-23 19:03:47 --> Language Class Initialized
INFO - 2018-08-23 19:03:47 --> Loader Class Initialized
INFO - 2018-08-23 19:03:47 --> Helper loaded: url_helper
INFO - 2018-08-23 19:03:47 --> Helper loaded: form_helper
INFO - 2018-08-23 19:03:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:03:47 --> User Agent Class Initialized
INFO - 2018-08-23 19:03:47 --> Controller Class Initialized
INFO - 2018-08-23 19:03:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:03:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:03:47 --> Pixel_Model class loaded
INFO - 2018-08-23 19:03:47 --> Database Driver Class Initialized
INFO - 2018-08-23 19:03:47 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 19:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-08-23 19:03:47 --> Pagination Class Initialized
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/question_list.php
INFO - 2018-08-23 19:03:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:03:47 --> Final output sent to browser
DEBUG - 2018-08-23 19:03:47 --> Total execution time: 0.0378
INFO - 2018-08-23 19:04:35 --> Config Class Initialized
INFO - 2018-08-23 19:04:35 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:04:35 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:04:35 --> Utf8 Class Initialized
INFO - 2018-08-23 19:04:35 --> URI Class Initialized
INFO - 2018-08-23 19:04:35 --> Router Class Initialized
INFO - 2018-08-23 19:04:35 --> Output Class Initialized
INFO - 2018-08-23 19:04:35 --> Security Class Initialized
DEBUG - 2018-08-23 19:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:04:35 --> CSRF cookie sent
INFO - 2018-08-23 19:04:35 --> Input Class Initialized
INFO - 2018-08-23 19:04:35 --> Language Class Initialized
INFO - 2018-08-23 19:04:35 --> Loader Class Initialized
INFO - 2018-08-23 19:04:35 --> Helper loaded: url_helper
INFO - 2018-08-23 19:04:35 --> Helper loaded: form_helper
INFO - 2018-08-23 19:04:35 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:04:35 --> User Agent Class Initialized
INFO - 2018-08-23 19:04:35 --> Controller Class Initialized
INFO - 2018-08-23 19:04:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:04:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:04:35 --> Pixel_Model class loaded
INFO - 2018-08-23 19:04:35 --> Database Driver Class Initialized
INFO - 2018-08-23 19:04:35 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/edit_question.php
INFO - 2018-08-23 19:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:04:35 --> Final output sent to browser
DEBUG - 2018-08-23 19:04:35 --> Total execution time: 0.0392
INFO - 2018-08-23 19:04:37 --> Config Class Initialized
INFO - 2018-08-23 19:04:37 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:04:37 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:04:37 --> Utf8 Class Initialized
INFO - 2018-08-23 19:04:37 --> URI Class Initialized
INFO - 2018-08-23 19:04:37 --> Router Class Initialized
INFO - 2018-08-23 19:04:37 --> Output Class Initialized
INFO - 2018-08-23 19:04:37 --> Security Class Initialized
DEBUG - 2018-08-23 19:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:04:37 --> CSRF cookie sent
INFO - 2018-08-23 19:04:37 --> Input Class Initialized
INFO - 2018-08-23 19:04:37 --> Language Class Initialized
INFO - 2018-08-23 19:04:37 --> Loader Class Initialized
INFO - 2018-08-23 19:04:37 --> Helper loaded: url_helper
INFO - 2018-08-23 19:04:37 --> Helper loaded: form_helper
INFO - 2018-08-23 19:04:37 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:04:37 --> User Agent Class Initialized
INFO - 2018-08-23 19:04:37 --> Controller Class Initialized
INFO - 2018-08-23 19:04:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:04:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:04:37 --> Pixel_Model class loaded
INFO - 2018-08-23 19:04:37 --> Database Driver Class Initialized
INFO - 2018-08-23 19:04:37 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 19:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-08-23 19:04:37 --> Pagination Class Initialized
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/question_list.php
INFO - 2018-08-23 19:04:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:04:37 --> Final output sent to browser
DEBUG - 2018-08-23 19:04:37 --> Total execution time: 0.0392
INFO - 2018-08-23 19:04:47 --> Config Class Initialized
INFO - 2018-08-23 19:04:47 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:04:47 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:04:47 --> Utf8 Class Initialized
INFO - 2018-08-23 19:04:47 --> URI Class Initialized
INFO - 2018-08-23 19:04:47 --> Router Class Initialized
INFO - 2018-08-23 19:04:47 --> Output Class Initialized
INFO - 2018-08-23 19:04:47 --> Security Class Initialized
DEBUG - 2018-08-23 19:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:04:47 --> CSRF cookie sent
INFO - 2018-08-23 19:04:47 --> Input Class Initialized
INFO - 2018-08-23 19:04:47 --> Language Class Initialized
INFO - 2018-08-23 19:04:47 --> Loader Class Initialized
INFO - 2018-08-23 19:04:47 --> Helper loaded: url_helper
INFO - 2018-08-23 19:04:47 --> Helper loaded: form_helper
INFO - 2018-08-23 19:04:47 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:04:47 --> User Agent Class Initialized
INFO - 2018-08-23 19:04:47 --> Controller Class Initialized
INFO - 2018-08-23 19:04:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:04:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:04:47 --> Pixel_Model class loaded
INFO - 2018-08-23 19:04:47 --> Database Driver Class Initialized
INFO - 2018-08-23 19:04:47 --> Model "MyAccountModel" initialized
INFO - 2018-08-23 19:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-08-23 19:04:47 --> Pagination Class Initialized
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/question_list.php
INFO - 2018-08-23 19:04:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:04:47 --> Final output sent to browser
DEBUG - 2018-08-23 19:04:47 --> Total execution time: 0.0446
INFO - 2018-08-23 19:06:22 --> Config Class Initialized
INFO - 2018-08-23 19:06:22 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:06:22 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:06:22 --> Utf8 Class Initialized
INFO - 2018-08-23 19:06:22 --> URI Class Initialized
DEBUG - 2018-08-23 19:06:22 --> No URI present. Default controller set.
INFO - 2018-08-23 19:06:22 --> Router Class Initialized
INFO - 2018-08-23 19:06:22 --> Output Class Initialized
INFO - 2018-08-23 19:06:22 --> Security Class Initialized
DEBUG - 2018-08-23 19:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:06:22 --> CSRF cookie sent
INFO - 2018-08-23 19:06:22 --> Input Class Initialized
INFO - 2018-08-23 19:06:22 --> Language Class Initialized
INFO - 2018-08-23 19:06:22 --> Loader Class Initialized
INFO - 2018-08-23 19:06:22 --> Helper loaded: url_helper
INFO - 2018-08-23 19:06:22 --> Helper loaded: form_helper
INFO - 2018-08-23 19:06:22 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:06:22 --> User Agent Class Initialized
INFO - 2018-08-23 19:06:22 --> Controller Class Initialized
INFO - 2018-08-23 19:06:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:06:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:06:22 --> Pixel_Model class loaded
INFO - 2018-08-23 19:06:22 --> Database Driver Class Initialized
INFO - 2018-08-23 19:06:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:06:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:06:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:06:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:06:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 19:06:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:06:22 --> Final output sent to browser
DEBUG - 2018-08-23 19:06:22 --> Total execution time: 0.0368
INFO - 2018-08-23 19:10:00 --> Config Class Initialized
INFO - 2018-08-23 19:10:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:10:00 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:10:00 --> Utf8 Class Initialized
INFO - 2018-08-23 19:10:00 --> URI Class Initialized
DEBUG - 2018-08-23 19:10:00 --> No URI present. Default controller set.
INFO - 2018-08-23 19:10:00 --> Router Class Initialized
INFO - 2018-08-23 19:10:00 --> Output Class Initialized
INFO - 2018-08-23 19:10:00 --> Security Class Initialized
DEBUG - 2018-08-23 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:10:00 --> CSRF cookie sent
INFO - 2018-08-23 19:10:00 --> Input Class Initialized
INFO - 2018-08-23 19:10:00 --> Language Class Initialized
INFO - 2018-08-23 19:10:00 --> Loader Class Initialized
INFO - 2018-08-23 19:10:00 --> Helper loaded: url_helper
INFO - 2018-08-23 19:10:00 --> Helper loaded: form_helper
INFO - 2018-08-23 19:10:00 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:10:00 --> User Agent Class Initialized
INFO - 2018-08-23 19:10:00 --> Controller Class Initialized
INFO - 2018-08-23 19:10:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:10:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:10:00 --> Pixel_Model class loaded
INFO - 2018-08-23 19:10:00 --> Database Driver Class Initialized
INFO - 2018-08-23 19:10:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 19:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:10:00 --> Final output sent to browser
DEBUG - 2018-08-23 19:10:00 --> Total execution time: 0.0449
INFO - 2018-08-23 19:10:06 --> Config Class Initialized
INFO - 2018-08-23 19:10:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:10:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:10:06 --> Utf8 Class Initialized
INFO - 2018-08-23 19:10:06 --> URI Class Initialized
INFO - 2018-08-23 19:10:06 --> Router Class Initialized
INFO - 2018-08-23 19:10:06 --> Output Class Initialized
INFO - 2018-08-23 19:10:06 --> Security Class Initialized
DEBUG - 2018-08-23 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:10:06 --> CSRF cookie sent
INFO - 2018-08-23 19:10:06 --> CSRF token verified
INFO - 2018-08-23 19:10:06 --> Input Class Initialized
INFO - 2018-08-23 19:10:06 --> Language Class Initialized
INFO - 2018-08-23 19:10:06 --> Loader Class Initialized
INFO - 2018-08-23 19:10:06 --> Helper loaded: url_helper
INFO - 2018-08-23 19:10:06 --> Helper loaded: form_helper
INFO - 2018-08-23 19:10:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:10:06 --> User Agent Class Initialized
INFO - 2018-08-23 19:10:06 --> Controller Class Initialized
INFO - 2018-08-23 19:10:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:10:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:10:06 --> Pixel_Model class loaded
INFO - 2018-08-23 19:10:06 --> Database Driver Class Initialized
INFO - 2018-08-23 19:10:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:10:06 --> Form Validation Class Initialized
INFO - 2018-08-23 19:10:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 19:10:06 --> Database Driver Class Initialized
INFO - 2018-08-23 19:10:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:10:06 --> Config Class Initialized
INFO - 2018-08-23 19:10:06 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:10:06 --> UTF-8 Support Enabled
INFO - 2018-08-23 19:10:06 --> Utf8 Class Initialized
INFO - 2018-08-23 19:10:06 --> URI Class Initialized
INFO - 2018-08-23 19:10:06 --> Router Class Initialized
INFO - 2018-08-23 19:10:06 --> Output Class Initialized
INFO - 2018-08-23 19:10:06 --> Security Class Initialized
DEBUG - 2018-08-23 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 19:10:06 --> CSRF cookie sent
INFO - 2018-08-23 19:10:06 --> Input Class Initialized
INFO - 2018-08-23 19:10:06 --> Language Class Initialized
INFO - 2018-08-23 19:10:06 --> Loader Class Initialized
INFO - 2018-08-23 19:10:06 --> Helper loaded: url_helper
INFO - 2018-08-23 19:10:06 --> Helper loaded: form_helper
INFO - 2018-08-23 19:10:06 --> Helper loaded: language_helper
DEBUG - 2018-08-23 19:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 19:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 19:10:06 --> User Agent Class Initialized
INFO - 2018-08-23 19:10:06 --> Controller Class Initialized
INFO - 2018-08-23 19:10:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 19:10:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 19:10:07 --> Pixel_Model class loaded
INFO - 2018-08-23 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-23 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-23 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 19:10:07 --> Final output sent to browser
DEBUG - 2018-08-23 19:10:07 --> Total execution time: 0.0460
INFO - 2018-08-23 20:57:05 --> Config Class Initialized
INFO - 2018-08-23 20:57:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:05 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:05 --> URI Class Initialized
DEBUG - 2018-08-23 20:57:05 --> No URI present. Default controller set.
INFO - 2018-08-23 20:57:05 --> Router Class Initialized
INFO - 2018-08-23 20:57:05 --> Output Class Initialized
INFO - 2018-08-23 20:57:05 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:05 --> CSRF cookie sent
INFO - 2018-08-23 20:57:05 --> Input Class Initialized
INFO - 2018-08-23 20:57:05 --> Language Class Initialized
INFO - 2018-08-23 20:57:05 --> Loader Class Initialized
INFO - 2018-08-23 20:57:05 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:05 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:05 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:05 --> Controller Class Initialized
INFO - 2018-08-23 20:57:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:05 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:05 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:05 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:05 --> Total execution time: 0.0361
INFO - 2018-08-23 20:57:05 --> Config Class Initialized
INFO - 2018-08-23 20:57:05 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:05 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:05 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:05 --> URI Class Initialized
DEBUG - 2018-08-23 20:57:05 --> No URI present. Default controller set.
INFO - 2018-08-23 20:57:05 --> Router Class Initialized
INFO - 2018-08-23 20:57:05 --> Output Class Initialized
INFO - 2018-08-23 20:57:05 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:05 --> CSRF cookie sent
INFO - 2018-08-23 20:57:05 --> Input Class Initialized
INFO - 2018-08-23 20:57:05 --> Language Class Initialized
INFO - 2018-08-23 20:57:05 --> Loader Class Initialized
INFO - 2018-08-23 20:57:05 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:05 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:05 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:05 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:05 --> Controller Class Initialized
INFO - 2018-08-23 20:57:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:05 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:05 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-23 20:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:05 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:05 --> Total execution time: 0.0419
INFO - 2018-08-23 20:57:13 --> Config Class Initialized
INFO - 2018-08-23 20:57:13 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:13 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:13 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:13 --> URI Class Initialized
INFO - 2018-08-23 20:57:13 --> Router Class Initialized
INFO - 2018-08-23 20:57:13 --> Output Class Initialized
INFO - 2018-08-23 20:57:13 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:13 --> CSRF cookie sent
INFO - 2018-08-23 20:57:13 --> CSRF token verified
INFO - 2018-08-23 20:57:13 --> Input Class Initialized
INFO - 2018-08-23 20:57:13 --> Language Class Initialized
INFO - 2018-08-23 20:57:13 --> Loader Class Initialized
INFO - 2018-08-23 20:57:13 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:13 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:13 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:13 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:13 --> Controller Class Initialized
INFO - 2018-08-23 20:57:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:13 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:13 --> Config Class Initialized
INFO - 2018-08-23 20:57:13 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:13 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:13 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:13 --> URI Class Initialized
INFO - 2018-08-23 20:57:13 --> Router Class Initialized
INFO - 2018-08-23 20:57:13 --> Output Class Initialized
INFO - 2018-08-23 20:57:13 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:13 --> CSRF cookie sent
INFO - 2018-08-23 20:57:13 --> Input Class Initialized
INFO - 2018-08-23 20:57:13 --> Language Class Initialized
INFO - 2018-08-23 20:57:13 --> Loader Class Initialized
INFO - 2018-08-23 20:57:13 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:13 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:13 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:13 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:13 --> Controller Class Initialized
INFO - 2018-08-23 20:57:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:13 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-23 20:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:13 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:13 --> Total execution time: 0.0494
INFO - 2018-08-23 20:57:17 --> Config Class Initialized
INFO - 2018-08-23 20:57:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:17 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:17 --> URI Class Initialized
INFO - 2018-08-23 20:57:17 --> Router Class Initialized
INFO - 2018-08-23 20:57:17 --> Output Class Initialized
INFO - 2018-08-23 20:57:17 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:17 --> CSRF cookie sent
INFO - 2018-08-23 20:57:17 --> CSRF token verified
INFO - 2018-08-23 20:57:17 --> Input Class Initialized
INFO - 2018-08-23 20:57:17 --> Language Class Initialized
INFO - 2018-08-23 20:57:17 --> Loader Class Initialized
INFO - 2018-08-23 20:57:17 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:17 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:17 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:17 --> Controller Class Initialized
INFO - 2018-08-23 20:57:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:17 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:17 --> Form Validation Class Initialized
INFO - 2018-08-23 20:57:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:57:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:17 --> Config Class Initialized
INFO - 2018-08-23 20:57:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:17 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:17 --> URI Class Initialized
INFO - 2018-08-23 20:57:17 --> Router Class Initialized
INFO - 2018-08-23 20:57:17 --> Output Class Initialized
INFO - 2018-08-23 20:57:17 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:17 --> CSRF cookie sent
INFO - 2018-08-23 20:57:17 --> Input Class Initialized
INFO - 2018-08-23 20:57:17 --> Language Class Initialized
INFO - 2018-08-23 20:57:17 --> Loader Class Initialized
INFO - 2018-08-23 20:57:17 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:17 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:17 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:17 --> Controller Class Initialized
INFO - 2018-08-23 20:57:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:17 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-23 20:57:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:17 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:17 --> Total execution time: 0.0477
INFO - 2018-08-23 20:57:21 --> Config Class Initialized
INFO - 2018-08-23 20:57:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:21 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:21 --> URI Class Initialized
INFO - 2018-08-23 20:57:21 --> Router Class Initialized
INFO - 2018-08-23 20:57:21 --> Output Class Initialized
INFO - 2018-08-23 20:57:21 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:21 --> CSRF cookie sent
INFO - 2018-08-23 20:57:21 --> CSRF token verified
INFO - 2018-08-23 20:57:21 --> Input Class Initialized
INFO - 2018-08-23 20:57:21 --> Language Class Initialized
INFO - 2018-08-23 20:57:21 --> Loader Class Initialized
INFO - 2018-08-23 20:57:21 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:21 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:21 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:21 --> Controller Class Initialized
INFO - 2018-08-23 20:57:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:21 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:21 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:21 --> Form Validation Class Initialized
INFO - 2018-08-23 20:57:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:57:21 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:21 --> Config Class Initialized
INFO - 2018-08-23 20:57:21 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:21 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:21 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:21 --> URI Class Initialized
INFO - 2018-08-23 20:57:21 --> Router Class Initialized
INFO - 2018-08-23 20:57:21 --> Output Class Initialized
INFO - 2018-08-23 20:57:21 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:21 --> CSRF cookie sent
INFO - 2018-08-23 20:57:21 --> Input Class Initialized
INFO - 2018-08-23 20:57:21 --> Language Class Initialized
INFO - 2018-08-23 20:57:21 --> Loader Class Initialized
INFO - 2018-08-23 20:57:21 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:21 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:21 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:21 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:21 --> Controller Class Initialized
INFO - 2018-08-23 20:57:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:21 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:21 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:21 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-23 20:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:21 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:21 --> Total execution time: 0.0325
INFO - 2018-08-23 20:57:25 --> Config Class Initialized
INFO - 2018-08-23 20:57:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:25 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:25 --> URI Class Initialized
INFO - 2018-08-23 20:57:25 --> Router Class Initialized
INFO - 2018-08-23 20:57:25 --> Output Class Initialized
INFO - 2018-08-23 20:57:25 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:25 --> CSRF cookie sent
INFO - 2018-08-23 20:57:25 --> CSRF token verified
INFO - 2018-08-23 20:57:25 --> Input Class Initialized
INFO - 2018-08-23 20:57:25 --> Language Class Initialized
INFO - 2018-08-23 20:57:25 --> Loader Class Initialized
INFO - 2018-08-23 20:57:25 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:25 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:25 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:25 --> Controller Class Initialized
INFO - 2018-08-23 20:57:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:25 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:25 --> Form Validation Class Initialized
INFO - 2018-08-23 20:57:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:57:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:25 --> Config Class Initialized
INFO - 2018-08-23 20:57:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:25 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:25 --> URI Class Initialized
INFO - 2018-08-23 20:57:25 --> Router Class Initialized
INFO - 2018-08-23 20:57:25 --> Output Class Initialized
INFO - 2018-08-23 20:57:25 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:25 --> CSRF cookie sent
INFO - 2018-08-23 20:57:25 --> Input Class Initialized
INFO - 2018-08-23 20:57:25 --> Language Class Initialized
INFO - 2018-08-23 20:57:25 --> Loader Class Initialized
INFO - 2018-08-23 20:57:25 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:25 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:25 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:25 --> Controller Class Initialized
INFO - 2018-08-23 20:57:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:25 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-23 20:57:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:25 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:25 --> Total execution time: 0.0400
INFO - 2018-08-23 20:57:40 --> Config Class Initialized
INFO - 2018-08-23 20:57:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:40 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:40 --> URI Class Initialized
INFO - 2018-08-23 20:57:40 --> Router Class Initialized
INFO - 2018-08-23 20:57:40 --> Output Class Initialized
INFO - 2018-08-23 20:57:40 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:40 --> CSRF cookie sent
INFO - 2018-08-23 20:57:40 --> CSRF token verified
INFO - 2018-08-23 20:57:40 --> Input Class Initialized
INFO - 2018-08-23 20:57:40 --> Language Class Initialized
INFO - 2018-08-23 20:57:40 --> Loader Class Initialized
INFO - 2018-08-23 20:57:40 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:40 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:40 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:40 --> Controller Class Initialized
INFO - 2018-08-23 20:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:40 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:40 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:40 --> Form Validation Class Initialized
INFO - 2018-08-23 20:57:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:57:40 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:40 --> Config Class Initialized
INFO - 2018-08-23 20:57:40 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:40 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:40 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:40 --> URI Class Initialized
INFO - 2018-08-23 20:57:40 --> Router Class Initialized
INFO - 2018-08-23 20:57:40 --> Output Class Initialized
INFO - 2018-08-23 20:57:40 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:40 --> CSRF cookie sent
INFO - 2018-08-23 20:57:40 --> Input Class Initialized
INFO - 2018-08-23 20:57:40 --> Language Class Initialized
INFO - 2018-08-23 20:57:40 --> Loader Class Initialized
INFO - 2018-08-23 20:57:40 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:40 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:40 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:40 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:40 --> Controller Class Initialized
INFO - 2018-08-23 20:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:40 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:40 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:40 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-23 20:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:40 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:40 --> Total execution time: 0.0764
INFO - 2018-08-23 20:57:51 --> Config Class Initialized
INFO - 2018-08-23 20:57:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:51 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:51 --> URI Class Initialized
INFO - 2018-08-23 20:57:51 --> Router Class Initialized
INFO - 2018-08-23 20:57:51 --> Output Class Initialized
INFO - 2018-08-23 20:57:51 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:51 --> CSRF cookie sent
INFO - 2018-08-23 20:57:51 --> CSRF token verified
INFO - 2018-08-23 20:57:51 --> Input Class Initialized
INFO - 2018-08-23 20:57:51 --> Language Class Initialized
INFO - 2018-08-23 20:57:51 --> Loader Class Initialized
INFO - 2018-08-23 20:57:51 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:51 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:51 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:51 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:51 --> Controller Class Initialized
INFO - 2018-08-23 20:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:51 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:51 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:51 --> Form Validation Class Initialized
INFO - 2018-08-23 20:57:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:57:51 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:51 --> Config Class Initialized
INFO - 2018-08-23 20:57:51 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:57:51 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:57:51 --> Utf8 Class Initialized
INFO - 2018-08-23 20:57:51 --> URI Class Initialized
INFO - 2018-08-23 20:57:51 --> Router Class Initialized
INFO - 2018-08-23 20:57:51 --> Output Class Initialized
INFO - 2018-08-23 20:57:51 --> Security Class Initialized
DEBUG - 2018-08-23 20:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:57:51 --> CSRF cookie sent
INFO - 2018-08-23 20:57:51 --> Input Class Initialized
INFO - 2018-08-23 20:57:51 --> Language Class Initialized
INFO - 2018-08-23 20:57:51 --> Loader Class Initialized
INFO - 2018-08-23 20:57:51 --> Helper loaded: url_helper
INFO - 2018-08-23 20:57:51 --> Helper loaded: form_helper
INFO - 2018-08-23 20:57:51 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:57:51 --> User Agent Class Initialized
INFO - 2018-08-23 20:57:51 --> Controller Class Initialized
INFO - 2018-08-23 20:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:57:51 --> Pixel_Model class loaded
INFO - 2018-08-23 20:57:51 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:51 --> Database Driver Class Initialized
INFO - 2018-08-23 20:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-23 20:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:57:51 --> Final output sent to browser
DEBUG - 2018-08-23 20:57:51 --> Total execution time: 0.0475
INFO - 2018-08-23 20:58:07 --> Config Class Initialized
INFO - 2018-08-23 20:58:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:07 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:07 --> URI Class Initialized
INFO - 2018-08-23 20:58:07 --> Router Class Initialized
INFO - 2018-08-23 20:58:07 --> Output Class Initialized
INFO - 2018-08-23 20:58:07 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:07 --> CSRF cookie sent
INFO - 2018-08-23 20:58:07 --> CSRF token verified
INFO - 2018-08-23 20:58:07 --> Input Class Initialized
INFO - 2018-08-23 20:58:07 --> Language Class Initialized
INFO - 2018-08-23 20:58:07 --> Loader Class Initialized
INFO - 2018-08-23 20:58:07 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:07 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:07 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:07 --> Controller Class Initialized
INFO - 2018-08-23 20:58:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:07 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:07 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:07 --> Form Validation Class Initialized
INFO - 2018-08-23 20:58:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:58:07 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:07 --> Config Class Initialized
INFO - 2018-08-23 20:58:07 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:07 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:07 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:07 --> URI Class Initialized
INFO - 2018-08-23 20:58:07 --> Router Class Initialized
INFO - 2018-08-23 20:58:07 --> Output Class Initialized
INFO - 2018-08-23 20:58:07 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:07 --> CSRF cookie sent
INFO - 2018-08-23 20:58:07 --> Input Class Initialized
INFO - 2018-08-23 20:58:07 --> Language Class Initialized
INFO - 2018-08-23 20:58:07 --> Loader Class Initialized
INFO - 2018-08-23 20:58:07 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:07 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:07 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:07 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:07 --> Controller Class Initialized
INFO - 2018-08-23 20:58:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:07 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:07 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:07 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-23 20:58:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:58:07 --> Final output sent to browser
DEBUG - 2018-08-23 20:58:07 --> Total execution time: 0.0492
INFO - 2018-08-23 20:58:13 --> Config Class Initialized
INFO - 2018-08-23 20:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:13 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:13 --> URI Class Initialized
INFO - 2018-08-23 20:58:13 --> Router Class Initialized
INFO - 2018-08-23 20:58:13 --> Output Class Initialized
INFO - 2018-08-23 20:58:13 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:13 --> CSRF cookie sent
INFO - 2018-08-23 20:58:13 --> CSRF token verified
INFO - 2018-08-23 20:58:13 --> Input Class Initialized
INFO - 2018-08-23 20:58:13 --> Language Class Initialized
INFO - 2018-08-23 20:58:13 --> Loader Class Initialized
INFO - 2018-08-23 20:58:13 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:13 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:13 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:13 --> Controller Class Initialized
INFO - 2018-08-23 20:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:13 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:13 --> Form Validation Class Initialized
INFO - 2018-08-23 20:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:58:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:13 --> Config Class Initialized
INFO - 2018-08-23 20:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:13 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:13 --> URI Class Initialized
INFO - 2018-08-23 20:58:13 --> Router Class Initialized
INFO - 2018-08-23 20:58:13 --> Output Class Initialized
INFO - 2018-08-23 20:58:13 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:13 --> CSRF cookie sent
INFO - 2018-08-23 20:58:13 --> Input Class Initialized
INFO - 2018-08-23 20:58:13 --> Language Class Initialized
INFO - 2018-08-23 20:58:13 --> Loader Class Initialized
INFO - 2018-08-23 20:58:13 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:13 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:13 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:13 --> Controller Class Initialized
INFO - 2018-08-23 20:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:13 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:13 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-23 20:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:58:13 --> Final output sent to browser
DEBUG - 2018-08-23 20:58:13 --> Total execution time: 0.0537
INFO - 2018-08-23 20:58:17 --> Config Class Initialized
INFO - 2018-08-23 20:58:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:17 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:17 --> URI Class Initialized
INFO - 2018-08-23 20:58:17 --> Router Class Initialized
INFO - 2018-08-23 20:58:17 --> Output Class Initialized
INFO - 2018-08-23 20:58:17 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:17 --> CSRF cookie sent
INFO - 2018-08-23 20:58:17 --> CSRF token verified
INFO - 2018-08-23 20:58:17 --> Input Class Initialized
INFO - 2018-08-23 20:58:17 --> Language Class Initialized
INFO - 2018-08-23 20:58:17 --> Loader Class Initialized
INFO - 2018-08-23 20:58:17 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:17 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:17 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:17 --> Controller Class Initialized
INFO - 2018-08-23 20:58:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:17 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:17 --> Form Validation Class Initialized
INFO - 2018-08-23 20:58:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:58:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:17 --> Config Class Initialized
INFO - 2018-08-23 20:58:17 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:17 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:17 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:17 --> URI Class Initialized
INFO - 2018-08-23 20:58:17 --> Router Class Initialized
INFO - 2018-08-23 20:58:17 --> Output Class Initialized
INFO - 2018-08-23 20:58:17 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:17 --> CSRF cookie sent
INFO - 2018-08-23 20:58:17 --> Input Class Initialized
INFO - 2018-08-23 20:58:17 --> Language Class Initialized
INFO - 2018-08-23 20:58:17 --> Loader Class Initialized
INFO - 2018-08-23 20:58:17 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:17 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:17 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:17 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:17 --> Controller Class Initialized
INFO - 2018-08-23 20:58:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:17 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:17 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 20:58:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:58:17 --> Final output sent to browser
DEBUG - 2018-08-23 20:58:17 --> Total execution time: 0.0455
INFO - 2018-08-23 20:58:25 --> Config Class Initialized
INFO - 2018-08-23 20:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:25 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:25 --> URI Class Initialized
INFO - 2018-08-23 20:58:25 --> Router Class Initialized
INFO - 2018-08-23 20:58:25 --> Output Class Initialized
INFO - 2018-08-23 20:58:25 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:25 --> CSRF cookie sent
INFO - 2018-08-23 20:58:25 --> CSRF token verified
INFO - 2018-08-23 20:58:25 --> Input Class Initialized
INFO - 2018-08-23 20:58:25 --> Language Class Initialized
INFO - 2018-08-23 20:58:25 --> Loader Class Initialized
INFO - 2018-08-23 20:58:25 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:25 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:25 --> Controller Class Initialized
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:25 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:25 --> Form Validation Class Initialized
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-23 20:58:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:25 --> Config Class Initialized
INFO - 2018-08-23 20:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:25 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:25 --> URI Class Initialized
INFO - 2018-08-23 20:58:25 --> Router Class Initialized
INFO - 2018-08-23 20:58:25 --> Output Class Initialized
INFO - 2018-08-23 20:58:25 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:25 --> CSRF cookie sent
INFO - 2018-08-23 20:58:25 --> Input Class Initialized
INFO - 2018-08-23 20:58:25 --> Language Class Initialized
INFO - 2018-08-23 20:58:25 --> Loader Class Initialized
INFO - 2018-08-23 20:58:25 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:25 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:25 --> Controller Class Initialized
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:25 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:25 --> Config Class Initialized
INFO - 2018-08-23 20:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:25 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:25 --> URI Class Initialized
INFO - 2018-08-23 20:58:25 --> Router Class Initialized
INFO - 2018-08-23 20:58:25 --> Output Class Initialized
INFO - 2018-08-23 20:58:25 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:25 --> CSRF cookie sent
INFO - 2018-08-23 20:58:25 --> Input Class Initialized
INFO - 2018-08-23 20:58:25 --> Language Class Initialized
INFO - 2018-08-23 20:58:25 --> Loader Class Initialized
INFO - 2018-08-23 20:58:25 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:25 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:25 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:25 --> Controller Class Initialized
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:25 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:25 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:25 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-23 20:58:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-23 20:58:25 --> Could not find the language line "req_email"
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-23 20:58:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:58:25 --> Final output sent to browser
DEBUG - 2018-08-23 20:58:25 --> Total execution time: 0.0378
INFO - 2018-08-23 20:58:30 --> Config Class Initialized
INFO - 2018-08-23 20:58:30 --> Hooks Class Initialized
DEBUG - 2018-08-23 20:58:30 --> UTF-8 Support Enabled
INFO - 2018-08-23 20:58:30 --> Utf8 Class Initialized
INFO - 2018-08-23 20:58:30 --> URI Class Initialized
INFO - 2018-08-23 20:58:30 --> Router Class Initialized
INFO - 2018-08-23 20:58:30 --> Output Class Initialized
INFO - 2018-08-23 20:58:30 --> Security Class Initialized
DEBUG - 2018-08-23 20:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-23 20:58:30 --> CSRF cookie sent
INFO - 2018-08-23 20:58:30 --> Input Class Initialized
INFO - 2018-08-23 20:58:30 --> Language Class Initialized
INFO - 2018-08-23 20:58:30 --> Loader Class Initialized
INFO - 2018-08-23 20:58:30 --> Helper loaded: url_helper
INFO - 2018-08-23 20:58:30 --> Helper loaded: form_helper
INFO - 2018-08-23 20:58:30 --> Helper loaded: language_helper
DEBUG - 2018-08-23 20:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-23 20:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-23 20:58:30 --> User Agent Class Initialized
INFO - 2018-08-23 20:58:30 --> Controller Class Initialized
INFO - 2018-08-23 20:58:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-23 20:58:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-23 20:58:30 --> Pixel_Model class loaded
INFO - 2018-08-23 20:58:31 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:31 --> Database Driver Class Initialized
INFO - 2018-08-23 20:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-23 20:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-23 20:58:31 --> Final output sent to browser
DEBUG - 2018-08-23 20:58:31 --> Total execution time: 0.0469

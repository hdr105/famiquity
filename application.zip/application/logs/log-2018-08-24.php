<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-24 11:15:43 --> Config Class Initialized
INFO - 2018-08-24 11:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:15:43 --> Utf8 Class Initialized
INFO - 2018-08-24 11:15:43 --> URI Class Initialized
DEBUG - 2018-08-24 11:15:43 --> No URI present. Default controller set.
INFO - 2018-08-24 11:15:43 --> Router Class Initialized
INFO - 2018-08-24 11:15:43 --> Output Class Initialized
INFO - 2018-08-24 11:15:43 --> Security Class Initialized
DEBUG - 2018-08-24 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:15:43 --> CSRF cookie sent
INFO - 2018-08-24 11:15:43 --> Input Class Initialized
INFO - 2018-08-24 11:15:43 --> Language Class Initialized
INFO - 2018-08-24 11:15:43 --> Loader Class Initialized
INFO - 2018-08-24 11:15:43 --> Helper loaded: url_helper
INFO - 2018-08-24 11:15:43 --> Helper loaded: form_helper
INFO - 2018-08-24 11:15:43 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:15:43 --> User Agent Class Initialized
INFO - 2018-08-24 11:15:43 --> Controller Class Initialized
INFO - 2018-08-24 11:15:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:15:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:15:43 --> Pixel_Model class loaded
INFO - 2018-08-24 11:15:43 --> Database Driver Class Initialized
INFO - 2018-08-24 11:15:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:15:43 --> Final output sent to browser
DEBUG - 2018-08-24 11:15:43 --> Total execution time: 0.0511
INFO - 2018-08-24 11:15:43 --> Config Class Initialized
INFO - 2018-08-24 11:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:15:43 --> Utf8 Class Initialized
INFO - 2018-08-24 11:15:43 --> URI Class Initialized
DEBUG - 2018-08-24 11:15:43 --> No URI present. Default controller set.
INFO - 2018-08-24 11:15:43 --> Router Class Initialized
INFO - 2018-08-24 11:15:43 --> Output Class Initialized
INFO - 2018-08-24 11:15:43 --> Security Class Initialized
DEBUG - 2018-08-24 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:15:43 --> CSRF cookie sent
INFO - 2018-08-24 11:15:43 --> Input Class Initialized
INFO - 2018-08-24 11:15:43 --> Language Class Initialized
INFO - 2018-08-24 11:15:43 --> Loader Class Initialized
INFO - 2018-08-24 11:15:43 --> Helper loaded: url_helper
INFO - 2018-08-24 11:15:43 --> Helper loaded: form_helper
INFO - 2018-08-24 11:15:43 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:15:43 --> User Agent Class Initialized
INFO - 2018-08-24 11:15:43 --> Controller Class Initialized
INFO - 2018-08-24 11:15:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:15:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:15:43 --> Pixel_Model class loaded
INFO - 2018-08-24 11:15:43 --> Database Driver Class Initialized
INFO - 2018-08-24 11:15:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-24 11:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:15:43 --> Final output sent to browser
DEBUG - 2018-08-24 11:15:43 --> Total execution time: 0.0280
INFO - 2018-08-24 11:15:46 --> Config Class Initialized
INFO - 2018-08-24 11:15:46 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:15:46 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:15:46 --> Utf8 Class Initialized
INFO - 2018-08-24 11:15:46 --> URI Class Initialized
INFO - 2018-08-24 11:15:46 --> Router Class Initialized
INFO - 2018-08-24 11:15:46 --> Output Class Initialized
INFO - 2018-08-24 11:15:46 --> Security Class Initialized
DEBUG - 2018-08-24 11:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:15:46 --> CSRF cookie sent
INFO - 2018-08-24 11:15:46 --> Input Class Initialized
INFO - 2018-08-24 11:15:46 --> Language Class Initialized
INFO - 2018-08-24 11:15:46 --> Loader Class Initialized
INFO - 2018-08-24 11:15:46 --> Helper loaded: url_helper
INFO - 2018-08-24 11:15:46 --> Helper loaded: form_helper
INFO - 2018-08-24 11:15:46 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:15:46 --> User Agent Class Initialized
INFO - 2018-08-24 11:15:46 --> Controller Class Initialized
INFO - 2018-08-24 11:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-24 11:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:15:46 --> Final output sent to browser
DEBUG - 2018-08-24 11:15:46 --> Total execution time: 0.0284
INFO - 2018-08-24 11:16:03 --> Config Class Initialized
INFO - 2018-08-24 11:16:03 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:16:03 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:16:03 --> Utf8 Class Initialized
INFO - 2018-08-24 11:16:03 --> URI Class Initialized
INFO - 2018-08-24 11:16:03 --> Router Class Initialized
INFO - 2018-08-24 11:16:03 --> Output Class Initialized
INFO - 2018-08-24 11:16:03 --> Security Class Initialized
DEBUG - 2018-08-24 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:16:03 --> CSRF cookie sent
INFO - 2018-08-24 11:16:03 --> Input Class Initialized
INFO - 2018-08-24 11:16:03 --> Language Class Initialized
INFO - 2018-08-24 11:16:03 --> Loader Class Initialized
INFO - 2018-08-24 11:16:03 --> Helper loaded: url_helper
INFO - 2018-08-24 11:16:03 --> Helper loaded: form_helper
INFO - 2018-08-24 11:16:03 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:16:03 --> User Agent Class Initialized
INFO - 2018-08-24 11:16:03 --> Controller Class Initialized
INFO - 2018-08-24 11:16:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:16:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:16:03 --> Pixel_Model class loaded
INFO - 2018-08-24 11:16:03 --> Database Driver Class Initialized
INFO - 2018-08-24 11:16:03 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-24 11:16:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-24 11:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:16:03 --> Final output sent to browser
DEBUG - 2018-08-24 11:16:03 --> Total execution time: 0.0393
INFO - 2018-08-24 11:16:08 --> Config Class Initialized
INFO - 2018-08-24 11:16:08 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:16:08 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:16:08 --> Utf8 Class Initialized
INFO - 2018-08-24 11:16:08 --> URI Class Initialized
INFO - 2018-08-24 11:16:08 --> Router Class Initialized
INFO - 2018-08-24 11:16:08 --> Output Class Initialized
INFO - 2018-08-24 11:16:08 --> Security Class Initialized
DEBUG - 2018-08-24 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:16:08 --> CSRF cookie sent
INFO - 2018-08-24 11:16:08 --> Input Class Initialized
INFO - 2018-08-24 11:16:08 --> Language Class Initialized
INFO - 2018-08-24 11:16:08 --> Loader Class Initialized
INFO - 2018-08-24 11:16:08 --> Helper loaded: url_helper
INFO - 2018-08-24 11:16:08 --> Helper loaded: form_helper
INFO - 2018-08-24 11:16:08 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:16:08 --> User Agent Class Initialized
INFO - 2018-08-24 11:16:08 --> Controller Class Initialized
INFO - 2018-08-24 11:16:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:16:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-24 11:16:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:16:08 --> Final output sent to browser
DEBUG - 2018-08-24 11:16:08 --> Total execution time: 0.0233
INFO - 2018-08-24 11:16:11 --> Config Class Initialized
INFO - 2018-08-24 11:16:11 --> Hooks Class Initialized
DEBUG - 2018-08-24 11:16:11 --> UTF-8 Support Enabled
INFO - 2018-08-24 11:16:11 --> Utf8 Class Initialized
INFO - 2018-08-24 11:16:11 --> URI Class Initialized
DEBUG - 2018-08-24 11:16:11 --> No URI present. Default controller set.
INFO - 2018-08-24 11:16:11 --> Router Class Initialized
INFO - 2018-08-24 11:16:11 --> Output Class Initialized
INFO - 2018-08-24 11:16:11 --> Security Class Initialized
DEBUG - 2018-08-24 11:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-24 11:16:11 --> CSRF cookie sent
INFO - 2018-08-24 11:16:11 --> Input Class Initialized
INFO - 2018-08-24 11:16:11 --> Language Class Initialized
INFO - 2018-08-24 11:16:11 --> Loader Class Initialized
INFO - 2018-08-24 11:16:11 --> Helper loaded: url_helper
INFO - 2018-08-24 11:16:11 --> Helper loaded: form_helper
INFO - 2018-08-24 11:16:11 --> Helper loaded: language_helper
DEBUG - 2018-08-24 11:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-24 11:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-24 11:16:11 --> User Agent Class Initialized
INFO - 2018-08-24 11:16:11 --> Controller Class Initialized
INFO - 2018-08-24 11:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-24 11:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-24 11:16:11 --> Pixel_Model class loaded
INFO - 2018-08-24 11:16:11 --> Database Driver Class Initialized
INFO - 2018-08-24 11:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-24 11:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-24 11:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-24 11:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-24 11:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-24 11:16:11 --> Final output sent to browser
DEBUG - 2018-08-24 11:16:11 --> Total execution time: 0.0360

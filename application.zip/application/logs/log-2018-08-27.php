<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-27 04:25:46 --> Config Class Initialized
INFO - 2018-08-27 04:25:46 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:46 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:46 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:46 --> URI Class Initialized
DEBUG - 2018-08-27 04:25:46 --> No URI present. Default controller set.
INFO - 2018-08-27 04:25:46 --> Router Class Initialized
INFO - 2018-08-27 04:25:46 --> Output Class Initialized
INFO - 2018-08-27 04:25:46 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:46 --> CSRF cookie sent
INFO - 2018-08-27 04:25:46 --> Input Class Initialized
INFO - 2018-08-27 04:25:46 --> Language Class Initialized
INFO - 2018-08-27 04:25:46 --> Loader Class Initialized
INFO - 2018-08-27 04:25:46 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:46 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:46 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:46 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:46 --> Controller Class Initialized
INFO - 2018-08-27 04:25:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:46 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:46 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:25:46 --> Final output sent to browser
DEBUG - 2018-08-27 04:25:46 --> Total execution time: 0.0569
INFO - 2018-08-27 04:25:46 --> Config Class Initialized
INFO - 2018-08-27 04:25:46 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:46 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:46 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:46 --> URI Class Initialized
DEBUG - 2018-08-27 04:25:46 --> No URI present. Default controller set.
INFO - 2018-08-27 04:25:46 --> Router Class Initialized
INFO - 2018-08-27 04:25:46 --> Output Class Initialized
INFO - 2018-08-27 04:25:46 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:46 --> CSRF cookie sent
INFO - 2018-08-27 04:25:46 --> Input Class Initialized
INFO - 2018-08-27 04:25:46 --> Language Class Initialized
INFO - 2018-08-27 04:25:46 --> Loader Class Initialized
INFO - 2018-08-27 04:25:46 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:46 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:46 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:46 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:46 --> Controller Class Initialized
INFO - 2018-08-27 04:25:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:46 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:46 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 04:25:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:25:46 --> Final output sent to browser
DEBUG - 2018-08-27 04:25:46 --> Total execution time: 0.0344
INFO - 2018-08-27 04:25:50 --> Config Class Initialized
INFO - 2018-08-27 04:25:50 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:50 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:50 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:50 --> URI Class Initialized
INFO - 2018-08-27 04:25:50 --> Router Class Initialized
INFO - 2018-08-27 04:25:50 --> Output Class Initialized
INFO - 2018-08-27 04:25:50 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:50 --> CSRF cookie sent
INFO - 2018-08-27 04:25:50 --> CSRF token verified
INFO - 2018-08-27 04:25:50 --> Input Class Initialized
INFO - 2018-08-27 04:25:50 --> Language Class Initialized
INFO - 2018-08-27 04:25:50 --> Loader Class Initialized
INFO - 2018-08-27 04:25:50 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:50 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:50 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:50 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:50 --> Controller Class Initialized
INFO - 2018-08-27 04:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:50 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:50 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:50 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:50 --> Config Class Initialized
INFO - 2018-08-27 04:25:50 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:50 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:50 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:50 --> URI Class Initialized
INFO - 2018-08-27 04:25:50 --> Router Class Initialized
INFO - 2018-08-27 04:25:50 --> Output Class Initialized
INFO - 2018-08-27 04:25:50 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:50 --> CSRF cookie sent
INFO - 2018-08-27 04:25:50 --> Input Class Initialized
INFO - 2018-08-27 04:25:50 --> Language Class Initialized
INFO - 2018-08-27 04:25:50 --> Loader Class Initialized
INFO - 2018-08-27 04:25:50 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:50 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:50 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:50 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:50 --> Controller Class Initialized
INFO - 2018-08-27 04:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:50 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:50 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:50 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-27 04:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:25:50 --> Final output sent to browser
DEBUG - 2018-08-27 04:25:50 --> Total execution time: 0.0665
INFO - 2018-08-27 04:25:53 --> Config Class Initialized
INFO - 2018-08-27 04:25:53 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:53 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:53 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:53 --> URI Class Initialized
INFO - 2018-08-27 04:25:53 --> Router Class Initialized
INFO - 2018-08-27 04:25:53 --> Output Class Initialized
INFO - 2018-08-27 04:25:53 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:53 --> CSRF cookie sent
INFO - 2018-08-27 04:25:53 --> CSRF token verified
INFO - 2018-08-27 04:25:53 --> Input Class Initialized
INFO - 2018-08-27 04:25:53 --> Language Class Initialized
INFO - 2018-08-27 04:25:53 --> Loader Class Initialized
INFO - 2018-08-27 04:25:53 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:53 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:53 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:53 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:53 --> Controller Class Initialized
INFO - 2018-08-27 04:25:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:53 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:53 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:53 --> Form Validation Class Initialized
INFO - 2018-08-27 04:25:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 04:25:53 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-27 04:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:25:53 --> Final output sent to browser
DEBUG - 2018-08-27 04:25:53 --> Total execution time: 0.0472
INFO - 2018-08-27 04:25:58 --> Config Class Initialized
INFO - 2018-08-27 04:25:58 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:58 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:58 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:58 --> URI Class Initialized
INFO - 2018-08-27 04:25:58 --> Router Class Initialized
INFO - 2018-08-27 04:25:58 --> Output Class Initialized
INFO - 2018-08-27 04:25:58 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:58 --> CSRF cookie sent
INFO - 2018-08-27 04:25:58 --> CSRF token verified
INFO - 2018-08-27 04:25:58 --> Input Class Initialized
INFO - 2018-08-27 04:25:58 --> Language Class Initialized
INFO - 2018-08-27 04:25:58 --> Loader Class Initialized
INFO - 2018-08-27 04:25:58 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:58 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:58 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:58 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:58 --> Controller Class Initialized
INFO - 2018-08-27 04:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:58 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:58 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:58 --> Form Validation Class Initialized
INFO - 2018-08-27 04:25:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 04:25:58 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:58 --> Config Class Initialized
INFO - 2018-08-27 04:25:58 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:25:58 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:25:58 --> Utf8 Class Initialized
INFO - 2018-08-27 04:25:58 --> URI Class Initialized
INFO - 2018-08-27 04:25:58 --> Router Class Initialized
INFO - 2018-08-27 04:25:58 --> Output Class Initialized
INFO - 2018-08-27 04:25:58 --> Security Class Initialized
DEBUG - 2018-08-27 04:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:25:58 --> CSRF cookie sent
INFO - 2018-08-27 04:25:58 --> Input Class Initialized
INFO - 2018-08-27 04:25:58 --> Language Class Initialized
INFO - 2018-08-27 04:25:58 --> Loader Class Initialized
INFO - 2018-08-27 04:25:58 --> Helper loaded: url_helper
INFO - 2018-08-27 04:25:58 --> Helper loaded: form_helper
INFO - 2018-08-27 04:25:58 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:25:58 --> User Agent Class Initialized
INFO - 2018-08-27 04:25:58 --> Controller Class Initialized
INFO - 2018-08-27 04:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:25:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:25:58 --> Pixel_Model class loaded
INFO - 2018-08-27 04:25:58 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:58 --> Database Driver Class Initialized
INFO - 2018-08-27 04:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-27 04:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:25:58 --> Final output sent to browser
DEBUG - 2018-08-27 04:25:58 --> Total execution time: 0.0472
INFO - 2018-08-27 04:29:00 --> Config Class Initialized
INFO - 2018-08-27 04:29:00 --> Hooks Class Initialized
DEBUG - 2018-08-27 04:29:00 --> UTF-8 Support Enabled
INFO - 2018-08-27 04:29:00 --> Utf8 Class Initialized
INFO - 2018-08-27 04:29:00 --> URI Class Initialized
DEBUG - 2018-08-27 04:29:00 --> No URI present. Default controller set.
INFO - 2018-08-27 04:29:00 --> Router Class Initialized
INFO - 2018-08-27 04:29:00 --> Output Class Initialized
INFO - 2018-08-27 04:29:00 --> Security Class Initialized
DEBUG - 2018-08-27 04:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 04:29:00 --> CSRF cookie sent
INFO - 2018-08-27 04:29:00 --> Input Class Initialized
INFO - 2018-08-27 04:29:00 --> Language Class Initialized
INFO - 2018-08-27 04:29:00 --> Loader Class Initialized
INFO - 2018-08-27 04:29:00 --> Helper loaded: url_helper
INFO - 2018-08-27 04:29:00 --> Helper loaded: form_helper
INFO - 2018-08-27 04:29:00 --> Helper loaded: language_helper
DEBUG - 2018-08-27 04:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 04:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 04:29:00 --> User Agent Class Initialized
INFO - 2018-08-27 04:29:00 --> Controller Class Initialized
INFO - 2018-08-27 04:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 04:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 04:29:00 --> Pixel_Model class loaded
INFO - 2018-08-27 04:29:00 --> Database Driver Class Initialized
INFO - 2018-08-27 04:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 04:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 04:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 04:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 04:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 04:29:00 --> Final output sent to browser
DEBUG - 2018-08-27 04:29:00 --> Total execution time: 0.0479
INFO - 2018-08-27 16:12:20 --> Config Class Initialized
INFO - 2018-08-27 16:12:20 --> Hooks Class Initialized
DEBUG - 2018-08-27 16:12:20 --> UTF-8 Support Enabled
INFO - 2018-08-27 16:12:20 --> Utf8 Class Initialized
INFO - 2018-08-27 16:12:20 --> URI Class Initialized
DEBUG - 2018-08-27 16:12:20 --> No URI present. Default controller set.
INFO - 2018-08-27 16:12:20 --> Router Class Initialized
INFO - 2018-08-27 16:12:20 --> Output Class Initialized
INFO - 2018-08-27 16:12:20 --> Security Class Initialized
DEBUG - 2018-08-27 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 16:12:20 --> CSRF cookie sent
INFO - 2018-08-27 16:12:20 --> Input Class Initialized
INFO - 2018-08-27 16:12:20 --> Language Class Initialized
INFO - 2018-08-27 16:12:20 --> Loader Class Initialized
INFO - 2018-08-27 16:12:20 --> Helper loaded: url_helper
INFO - 2018-08-27 16:12:20 --> Helper loaded: form_helper
INFO - 2018-08-27 16:12:20 --> Helper loaded: language_helper
DEBUG - 2018-08-27 16:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 16:12:20 --> User Agent Class Initialized
INFO - 2018-08-27 16:12:20 --> Controller Class Initialized
INFO - 2018-08-27 16:12:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 16:12:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 16:12:20 --> Pixel_Model class loaded
INFO - 2018-08-27 16:12:20 --> Database Driver Class Initialized
INFO - 2018-08-27 16:12:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 16:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 16:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 16:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 16:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 16:12:20 --> Final output sent to browser
DEBUG - 2018-08-27 16:12:20 --> Total execution time: 0.0367
INFO - 2018-08-27 16:12:41 --> Config Class Initialized
INFO - 2018-08-27 16:12:41 --> Hooks Class Initialized
DEBUG - 2018-08-27 16:12:41 --> UTF-8 Support Enabled
INFO - 2018-08-27 16:12:41 --> Utf8 Class Initialized
INFO - 2018-08-27 16:12:41 --> URI Class Initialized
INFO - 2018-08-27 16:12:41 --> Router Class Initialized
INFO - 2018-08-27 16:12:41 --> Output Class Initialized
INFO - 2018-08-27 16:12:41 --> Security Class Initialized
DEBUG - 2018-08-27 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 16:12:41 --> CSRF cookie sent
INFO - 2018-08-27 16:12:41 --> CSRF token verified
INFO - 2018-08-27 16:12:41 --> Input Class Initialized
INFO - 2018-08-27 16:12:41 --> Language Class Initialized
INFO - 2018-08-27 16:12:41 --> Loader Class Initialized
INFO - 2018-08-27 16:12:41 --> Helper loaded: url_helper
INFO - 2018-08-27 16:12:41 --> Helper loaded: form_helper
INFO - 2018-08-27 16:12:41 --> Helper loaded: language_helper
DEBUG - 2018-08-27 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 16:12:41 --> User Agent Class Initialized
INFO - 2018-08-27 16:12:41 --> Controller Class Initialized
INFO - 2018-08-27 16:12:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 16:12:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 16:12:41 --> Pixel_Model class loaded
INFO - 2018-08-27 16:12:41 --> Database Driver Class Initialized
INFO - 2018-08-27 16:12:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 16:12:41 --> Database Driver Class Initialized
INFO - 2018-08-27 16:12:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 16:12:41 --> Config Class Initialized
INFO - 2018-08-27 16:12:41 --> Hooks Class Initialized
DEBUG - 2018-08-27 16:12:41 --> UTF-8 Support Enabled
INFO - 2018-08-27 16:12:41 --> Utf8 Class Initialized
INFO - 2018-08-27 16:12:41 --> URI Class Initialized
INFO - 2018-08-27 16:12:41 --> Router Class Initialized
INFO - 2018-08-27 16:12:41 --> Output Class Initialized
INFO - 2018-08-27 16:12:41 --> Security Class Initialized
DEBUG - 2018-08-27 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 16:12:41 --> CSRF cookie sent
INFO - 2018-08-27 16:12:41 --> Input Class Initialized
INFO - 2018-08-27 16:12:41 --> Language Class Initialized
INFO - 2018-08-27 16:12:41 --> Loader Class Initialized
INFO - 2018-08-27 16:12:41 --> Helper loaded: url_helper
INFO - 2018-08-27 16:12:41 --> Helper loaded: form_helper
INFO - 2018-08-27 16:12:41 --> Helper loaded: language_helper
DEBUG - 2018-08-27 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 16:12:41 --> User Agent Class Initialized
INFO - 2018-08-27 16:12:41 --> Controller Class Initialized
INFO - 2018-08-27 16:12:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 16:12:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 16:12:41 --> Pixel_Model class loaded
INFO - 2018-08-27 16:12:41 --> Database Driver Class Initialized
INFO - 2018-08-27 16:12:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 16:12:41 --> Database Driver Class Initialized
INFO - 2018-08-27 16:12:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-27 16:12:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 16:12:41 --> Final output sent to browser
DEBUG - 2018-08-27 16:12:41 --> Total execution time: 0.0514
INFO - 2018-08-27 23:18:00 --> Config Class Initialized
INFO - 2018-08-27 23:18:00 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:00 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:00 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:00 --> URI Class Initialized
INFO - 2018-08-27 23:18:00 --> Router Class Initialized
INFO - 2018-08-27 23:18:00 --> Output Class Initialized
INFO - 2018-08-27 23:18:00 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:00 --> CSRF cookie sent
INFO - 2018-08-27 23:18:00 --> Input Class Initialized
INFO - 2018-08-27 23:18:00 --> Language Class Initialized
ERROR - 2018-08-27 23:18:00 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-27 23:18:01 --> Config Class Initialized
INFO - 2018-08-27 23:18:01 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:01 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:01 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:01 --> URI Class Initialized
INFO - 2018-08-27 23:18:01 --> Router Class Initialized
INFO - 2018-08-27 23:18:01 --> Output Class Initialized
INFO - 2018-08-27 23:18:01 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:01 --> CSRF cookie sent
INFO - 2018-08-27 23:18:01 --> Input Class Initialized
INFO - 2018-08-27 23:18:01 --> Language Class Initialized
ERROR - 2018-08-27 23:18:01 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-27 23:18:03 --> Config Class Initialized
INFO - 2018-08-27 23:18:03 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:03 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:03 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:03 --> URI Class Initialized
DEBUG - 2018-08-27 23:18:03 --> No URI present. Default controller set.
INFO - 2018-08-27 23:18:03 --> Router Class Initialized
INFO - 2018-08-27 23:18:03 --> Output Class Initialized
INFO - 2018-08-27 23:18:03 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:03 --> CSRF cookie sent
INFO - 2018-08-27 23:18:03 --> Input Class Initialized
INFO - 2018-08-27 23:18:03 --> Language Class Initialized
INFO - 2018-08-27 23:18:03 --> Loader Class Initialized
INFO - 2018-08-27 23:18:03 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:03 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:03 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:03 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:03 --> Controller Class Initialized
INFO - 2018-08-27 23:18:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:03 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:03 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 23:18:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:03 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:03 --> Total execution time: 0.0350
INFO - 2018-08-27 23:18:06 --> Config Class Initialized
INFO - 2018-08-27 23:18:06 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:06 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:06 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:06 --> URI Class Initialized
INFO - 2018-08-27 23:18:06 --> Router Class Initialized
INFO - 2018-08-27 23:18:06 --> Output Class Initialized
INFO - 2018-08-27 23:18:06 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:06 --> CSRF cookie sent
INFO - 2018-08-27 23:18:06 --> Input Class Initialized
INFO - 2018-08-27 23:18:06 --> Language Class Initialized
INFO - 2018-08-27 23:18:06 --> Loader Class Initialized
INFO - 2018-08-27 23:18:06 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:06 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:06 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:06 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:06 --> Controller Class Initialized
INFO - 2018-08-27 23:18:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:06 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:06 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-27 23:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:06 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:06 --> Total execution time: 0.0523
INFO - 2018-08-27 23:18:08 --> Config Class Initialized
INFO - 2018-08-27 23:18:08 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:08 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:08 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:08 --> URI Class Initialized
INFO - 2018-08-27 23:18:08 --> Router Class Initialized
INFO - 2018-08-27 23:18:08 --> Output Class Initialized
INFO - 2018-08-27 23:18:08 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:08 --> CSRF cookie sent
INFO - 2018-08-27 23:18:08 --> CSRF token verified
INFO - 2018-08-27 23:18:08 --> Input Class Initialized
INFO - 2018-08-27 23:18:08 --> Language Class Initialized
INFO - 2018-08-27 23:18:08 --> Loader Class Initialized
INFO - 2018-08-27 23:18:08 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:08 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:08 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:08 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:08 --> Controller Class Initialized
INFO - 2018-08-27 23:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:08 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:08 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:08 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:08 --> Config Class Initialized
INFO - 2018-08-27 23:18:08 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:08 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:08 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:08 --> URI Class Initialized
INFO - 2018-08-27 23:18:08 --> Router Class Initialized
INFO - 2018-08-27 23:18:08 --> Output Class Initialized
INFO - 2018-08-27 23:18:08 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:08 --> CSRF cookie sent
INFO - 2018-08-27 23:18:08 --> Input Class Initialized
INFO - 2018-08-27 23:18:08 --> Language Class Initialized
INFO - 2018-08-27 23:18:08 --> Loader Class Initialized
INFO - 2018-08-27 23:18:08 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:08 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:08 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:08 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:08 --> Controller Class Initialized
INFO - 2018-08-27 23:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:08 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:08 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:08 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-27 23:18:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:08 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:08 --> Total execution time: 0.0462
INFO - 2018-08-27 23:18:11 --> Config Class Initialized
INFO - 2018-08-27 23:18:11 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:11 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:11 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:11 --> URI Class Initialized
INFO - 2018-08-27 23:18:11 --> Router Class Initialized
INFO - 2018-08-27 23:18:11 --> Output Class Initialized
INFO - 2018-08-27 23:18:11 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:11 --> CSRF cookie sent
INFO - 2018-08-27 23:18:11 --> CSRF token verified
INFO - 2018-08-27 23:18:11 --> Input Class Initialized
INFO - 2018-08-27 23:18:11 --> Language Class Initialized
INFO - 2018-08-27 23:18:11 --> Loader Class Initialized
INFO - 2018-08-27 23:18:11 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:11 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:11 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:11 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:11 --> Controller Class Initialized
INFO - 2018-08-27 23:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:11 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:11 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:11 --> Config Class Initialized
INFO - 2018-08-27 23:18:11 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:11 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:11 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:11 --> URI Class Initialized
INFO - 2018-08-27 23:18:11 --> Router Class Initialized
INFO - 2018-08-27 23:18:11 --> Output Class Initialized
INFO - 2018-08-27 23:18:11 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:11 --> CSRF cookie sent
INFO - 2018-08-27 23:18:11 --> Input Class Initialized
INFO - 2018-08-27 23:18:11 --> Language Class Initialized
INFO - 2018-08-27 23:18:11 --> Loader Class Initialized
INFO - 2018-08-27 23:18:11 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:11 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:11 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:11 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:11 --> Controller Class Initialized
INFO - 2018-08-27 23:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:11 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-27 23:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:11 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:11 --> Total execution time: 0.0460
INFO - 2018-08-27 23:18:12 --> Config Class Initialized
INFO - 2018-08-27 23:18:12 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:12 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:12 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:12 --> URI Class Initialized
INFO - 2018-08-27 23:18:12 --> Router Class Initialized
INFO - 2018-08-27 23:18:12 --> Output Class Initialized
INFO - 2018-08-27 23:18:12 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:12 --> CSRF cookie sent
INFO - 2018-08-27 23:18:12 --> Input Class Initialized
INFO - 2018-08-27 23:18:12 --> Language Class Initialized
INFO - 2018-08-27 23:18:13 --> Loader Class Initialized
INFO - 2018-08-27 23:18:13 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:13 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:13 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:13 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:13 --> Controller Class Initialized
INFO - 2018-08-27 23:18:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:13 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-08-27 23:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:13 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:13 --> Total execution time: 0.0774
INFO - 2018-08-27 23:18:14 --> Config Class Initialized
INFO - 2018-08-27 23:18:14 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:14 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:14 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:14 --> URI Class Initialized
INFO - 2018-08-27 23:18:14 --> Router Class Initialized
INFO - 2018-08-27 23:18:14 --> Output Class Initialized
INFO - 2018-08-27 23:18:14 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:14 --> CSRF cookie sent
INFO - 2018-08-27 23:18:14 --> Input Class Initialized
INFO - 2018-08-27 23:18:14 --> Language Class Initialized
INFO - 2018-08-27 23:18:14 --> Loader Class Initialized
INFO - 2018-08-27 23:18:14 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:14 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:14 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:14 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:14 --> Controller Class Initialized
INFO - 2018-08-27 23:18:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:14 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:14 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:14 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-27 23:18:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-27 23:18:14 --> Could not find the language line "req_email"
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-27 23:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:14 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:14 --> Total execution time: 0.0355
INFO - 2018-08-27 23:18:35 --> Config Class Initialized
INFO - 2018-08-27 23:18:35 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:35 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:35 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:35 --> URI Class Initialized
INFO - 2018-08-27 23:18:35 --> Router Class Initialized
INFO - 2018-08-27 23:18:35 --> Output Class Initialized
INFO - 2018-08-27 23:18:35 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:35 --> CSRF cookie sent
INFO - 2018-08-27 23:18:35 --> CSRF token verified
INFO - 2018-08-27 23:18:35 --> Input Class Initialized
INFO - 2018-08-27 23:18:35 --> Language Class Initialized
INFO - 2018-08-27 23:18:35 --> Loader Class Initialized
INFO - 2018-08-27 23:18:35 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:35 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:35 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:35 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:35 --> Controller Class Initialized
INFO - 2018-08-27 23:18:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-27 23:18:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-27 23:18:36 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:36 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:36 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:36 --> Model "RegistrationModel" initialized
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-08-27 23:18:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:36 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:36 --> Total execution time: 0.2269
INFO - 2018-08-27 23:18:40 --> Config Class Initialized
INFO - 2018-08-27 23:18:40 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:40 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:40 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:40 --> URI Class Initialized
INFO - 2018-08-27 23:18:40 --> Router Class Initialized
INFO - 2018-08-27 23:18:40 --> Output Class Initialized
INFO - 2018-08-27 23:18:40 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:40 --> CSRF cookie sent
INFO - 2018-08-27 23:18:40 --> CSRF token verified
INFO - 2018-08-27 23:18:40 --> Input Class Initialized
INFO - 2018-08-27 23:18:40 --> Language Class Initialized
INFO - 2018-08-27 23:18:40 --> Loader Class Initialized
INFO - 2018-08-27 23:18:40 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:40 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:40 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:40 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:40 --> Controller Class Initialized
INFO - 2018-08-27 23:18:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:40 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:40 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:40 --> Model "RegistrationModel" initialized
INFO - 2018-08-27 23:18:40 --> Helper loaded: string_helper
INFO - 2018-08-27 23:18:40 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-27 23:18:40 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-08-27 23:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-08-27 23:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-08-27 23:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-08-27 23:18:40 --> Email Class Initialized
INFO - 2018-08-27 23:18:41 --> Language file loaded: language/english/email_lang.php
INFO - 2018-08-27 23:18:41 --> Config Class Initialized
INFO - 2018-08-27 23:18:41 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:41 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:41 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:41 --> URI Class Initialized
INFO - 2018-08-27 23:18:41 --> Router Class Initialized
INFO - 2018-08-27 23:18:41 --> Output Class Initialized
INFO - 2018-08-27 23:18:41 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:41 --> CSRF cookie sent
INFO - 2018-08-27 23:18:41 --> Input Class Initialized
INFO - 2018-08-27 23:18:41 --> Language Class Initialized
INFO - 2018-08-27 23:18:41 --> Loader Class Initialized
INFO - 2018-08-27 23:18:41 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:41 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:41 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:41 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:41 --> Controller Class Initialized
INFO - 2018-08-27 23:18:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:41 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:41 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:41 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-27 23:18:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:41 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:41 --> Total execution time: 0.0455
INFO - 2018-08-27 23:18:44 --> Config Class Initialized
INFO - 2018-08-27 23:18:44 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:44 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:44 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:44 --> URI Class Initialized
INFO - 2018-08-27 23:18:44 --> Router Class Initialized
INFO - 2018-08-27 23:18:44 --> Output Class Initialized
INFO - 2018-08-27 23:18:44 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:44 --> CSRF cookie sent
INFO - 2018-08-27 23:18:44 --> CSRF token verified
INFO - 2018-08-27 23:18:44 --> Input Class Initialized
INFO - 2018-08-27 23:18:44 --> Language Class Initialized
INFO - 2018-08-27 23:18:44 --> Loader Class Initialized
INFO - 2018-08-27 23:18:44 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:44 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:44 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:44 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:44 --> Controller Class Initialized
INFO - 2018-08-27 23:18:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:44 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:44 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:44 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:44 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:44 --> Config Class Initialized
INFO - 2018-08-27 23:18:44 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:44 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:44 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:44 --> URI Class Initialized
INFO - 2018-08-27 23:18:44 --> Router Class Initialized
INFO - 2018-08-27 23:18:44 --> Output Class Initialized
INFO - 2018-08-27 23:18:44 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:44 --> CSRF cookie sent
INFO - 2018-08-27 23:18:44 --> Input Class Initialized
INFO - 2018-08-27 23:18:44 --> Language Class Initialized
INFO - 2018-08-27 23:18:44 --> Loader Class Initialized
INFO - 2018-08-27 23:18:44 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:44 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:44 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:44 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:44 --> Controller Class Initialized
INFO - 2018-08-27 23:18:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:44 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:44 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:44 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-27 23:18:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:44 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:44 --> Total execution time: 0.0453
INFO - 2018-08-27 23:18:45 --> Config Class Initialized
INFO - 2018-08-27 23:18:45 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:45 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:45 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:45 --> URI Class Initialized
INFO - 2018-08-27 23:18:45 --> Router Class Initialized
INFO - 2018-08-27 23:18:45 --> Output Class Initialized
INFO - 2018-08-27 23:18:45 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:45 --> CSRF cookie sent
INFO - 2018-08-27 23:18:45 --> CSRF token verified
INFO - 2018-08-27 23:18:45 --> Input Class Initialized
INFO - 2018-08-27 23:18:45 --> Language Class Initialized
INFO - 2018-08-27 23:18:45 --> Loader Class Initialized
INFO - 2018-08-27 23:18:45 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:45 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:45 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:45 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:45 --> Controller Class Initialized
INFO - 2018-08-27 23:18:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:45 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:45 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:45 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:45 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:45 --> Config Class Initialized
INFO - 2018-08-27 23:18:45 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:45 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:45 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:45 --> URI Class Initialized
INFO - 2018-08-27 23:18:45 --> Router Class Initialized
INFO - 2018-08-27 23:18:45 --> Output Class Initialized
INFO - 2018-08-27 23:18:45 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:45 --> CSRF cookie sent
INFO - 2018-08-27 23:18:45 --> Input Class Initialized
INFO - 2018-08-27 23:18:45 --> Language Class Initialized
INFO - 2018-08-27 23:18:45 --> Loader Class Initialized
INFO - 2018-08-27 23:18:45 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:45 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:45 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:45 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:45 --> Controller Class Initialized
INFO - 2018-08-27 23:18:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:45 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:45 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:45 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-27 23:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:45 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:45 --> Total execution time: 0.0362
INFO - 2018-08-27 23:18:50 --> Config Class Initialized
INFO - 2018-08-27 23:18:50 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:50 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:50 --> URI Class Initialized
INFO - 2018-08-27 23:18:50 --> Router Class Initialized
INFO - 2018-08-27 23:18:50 --> Output Class Initialized
INFO - 2018-08-27 23:18:50 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:50 --> CSRF cookie sent
INFO - 2018-08-27 23:18:50 --> CSRF token verified
INFO - 2018-08-27 23:18:50 --> Input Class Initialized
INFO - 2018-08-27 23:18:50 --> Language Class Initialized
INFO - 2018-08-27 23:18:50 --> Loader Class Initialized
INFO - 2018-08-27 23:18:50 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:50 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:50 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:50 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:50 --> Controller Class Initialized
INFO - 2018-08-27 23:18:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:50 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:50 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:50 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:50 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:50 --> Config Class Initialized
INFO - 2018-08-27 23:18:50 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:50 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:50 --> URI Class Initialized
INFO - 2018-08-27 23:18:50 --> Router Class Initialized
INFO - 2018-08-27 23:18:50 --> Output Class Initialized
INFO - 2018-08-27 23:18:50 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:50 --> CSRF cookie sent
INFO - 2018-08-27 23:18:50 --> Input Class Initialized
INFO - 2018-08-27 23:18:50 --> Language Class Initialized
INFO - 2018-08-27 23:18:50 --> Loader Class Initialized
INFO - 2018-08-27 23:18:50 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:50 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:50 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:50 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:50 --> Controller Class Initialized
INFO - 2018-08-27 23:18:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:50 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:50 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:50 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-27 23:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:50 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:50 --> Total execution time: 0.0476
INFO - 2018-08-27 23:18:54 --> Config Class Initialized
INFO - 2018-08-27 23:18:54 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:54 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:54 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:54 --> URI Class Initialized
INFO - 2018-08-27 23:18:54 --> Router Class Initialized
INFO - 2018-08-27 23:18:54 --> Output Class Initialized
INFO - 2018-08-27 23:18:54 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:54 --> CSRF cookie sent
INFO - 2018-08-27 23:18:54 --> CSRF token verified
INFO - 2018-08-27 23:18:54 --> Input Class Initialized
INFO - 2018-08-27 23:18:54 --> Language Class Initialized
INFO - 2018-08-27 23:18:54 --> Loader Class Initialized
INFO - 2018-08-27 23:18:54 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:54 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:54 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:54 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:54 --> Controller Class Initialized
INFO - 2018-08-27 23:18:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:54 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:54 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:54 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:54 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:55 --> Config Class Initialized
INFO - 2018-08-27 23:18:55 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:55 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:55 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:55 --> URI Class Initialized
INFO - 2018-08-27 23:18:55 --> Router Class Initialized
INFO - 2018-08-27 23:18:55 --> Output Class Initialized
INFO - 2018-08-27 23:18:55 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:55 --> CSRF cookie sent
INFO - 2018-08-27 23:18:55 --> Input Class Initialized
INFO - 2018-08-27 23:18:55 --> Language Class Initialized
INFO - 2018-08-27 23:18:55 --> Loader Class Initialized
INFO - 2018-08-27 23:18:55 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:55 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:55 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:55 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:55 --> Controller Class Initialized
INFO - 2018-08-27 23:18:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:55 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:55 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:55 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-27 23:18:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:55 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:55 --> Total execution time: 0.0575
INFO - 2018-08-27 23:18:58 --> Config Class Initialized
INFO - 2018-08-27 23:18:58 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:58 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:58 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:58 --> URI Class Initialized
INFO - 2018-08-27 23:18:58 --> Router Class Initialized
INFO - 2018-08-27 23:18:58 --> Output Class Initialized
INFO - 2018-08-27 23:18:58 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:58 --> CSRF cookie sent
INFO - 2018-08-27 23:18:58 --> CSRF token verified
INFO - 2018-08-27 23:18:58 --> Input Class Initialized
INFO - 2018-08-27 23:18:58 --> Language Class Initialized
INFO - 2018-08-27 23:18:58 --> Loader Class Initialized
INFO - 2018-08-27 23:18:58 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:58 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:58 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:58 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:58 --> Controller Class Initialized
INFO - 2018-08-27 23:18:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:58 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:58 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:58 --> Form Validation Class Initialized
INFO - 2018-08-27 23:18:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:18:58 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:59 --> Config Class Initialized
INFO - 2018-08-27 23:18:59 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:18:59 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:18:59 --> Utf8 Class Initialized
INFO - 2018-08-27 23:18:59 --> URI Class Initialized
INFO - 2018-08-27 23:18:59 --> Router Class Initialized
INFO - 2018-08-27 23:18:59 --> Output Class Initialized
INFO - 2018-08-27 23:18:59 --> Security Class Initialized
DEBUG - 2018-08-27 23:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:18:59 --> CSRF cookie sent
INFO - 2018-08-27 23:18:59 --> Input Class Initialized
INFO - 2018-08-27 23:18:59 --> Language Class Initialized
INFO - 2018-08-27 23:18:59 --> Loader Class Initialized
INFO - 2018-08-27 23:18:59 --> Helper loaded: url_helper
INFO - 2018-08-27 23:18:59 --> Helper loaded: form_helper
INFO - 2018-08-27 23:18:59 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:18:59 --> User Agent Class Initialized
INFO - 2018-08-27 23:18:59 --> Controller Class Initialized
INFO - 2018-08-27 23:18:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:18:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:18:59 --> Pixel_Model class loaded
INFO - 2018-08-27 23:18:59 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:59 --> Database Driver Class Initialized
INFO - 2018-08-27 23:18:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-27 23:18:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:18:59 --> Final output sent to browser
DEBUG - 2018-08-27 23:18:59 --> Total execution time: 0.0518
INFO - 2018-08-27 23:19:00 --> Config Class Initialized
INFO - 2018-08-27 23:19:00 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:00 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:00 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:00 --> URI Class Initialized
INFO - 2018-08-27 23:19:00 --> Router Class Initialized
INFO - 2018-08-27 23:19:00 --> Output Class Initialized
INFO - 2018-08-27 23:19:00 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:00 --> CSRF cookie sent
INFO - 2018-08-27 23:19:00 --> CSRF token verified
INFO - 2018-08-27 23:19:00 --> Input Class Initialized
INFO - 2018-08-27 23:19:00 --> Language Class Initialized
INFO - 2018-08-27 23:19:00 --> Loader Class Initialized
INFO - 2018-08-27 23:19:00 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:00 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:00 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:00 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:00 --> Controller Class Initialized
INFO - 2018-08-27 23:19:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:00 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:00 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:00 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:00 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:01 --> Config Class Initialized
INFO - 2018-08-27 23:19:01 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:01 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:01 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:01 --> URI Class Initialized
INFO - 2018-08-27 23:19:01 --> Router Class Initialized
INFO - 2018-08-27 23:19:01 --> Output Class Initialized
INFO - 2018-08-27 23:19:01 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:01 --> CSRF cookie sent
INFO - 2018-08-27 23:19:01 --> Input Class Initialized
INFO - 2018-08-27 23:19:01 --> Language Class Initialized
INFO - 2018-08-27 23:19:01 --> Loader Class Initialized
INFO - 2018-08-27 23:19:01 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:01 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:01 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:01 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:01 --> Controller Class Initialized
INFO - 2018-08-27 23:19:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:01 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:01 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:01 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-27 23:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:01 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:01 --> Total execution time: 0.0410
INFO - 2018-08-27 23:19:02 --> Config Class Initialized
INFO - 2018-08-27 23:19:02 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:02 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:02 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:02 --> URI Class Initialized
INFO - 2018-08-27 23:19:02 --> Router Class Initialized
INFO - 2018-08-27 23:19:02 --> Output Class Initialized
INFO - 2018-08-27 23:19:02 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:02 --> CSRF cookie sent
INFO - 2018-08-27 23:19:02 --> CSRF token verified
INFO - 2018-08-27 23:19:02 --> Input Class Initialized
INFO - 2018-08-27 23:19:02 --> Language Class Initialized
INFO - 2018-08-27 23:19:02 --> Loader Class Initialized
INFO - 2018-08-27 23:19:02 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:02 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:02 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:02 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:02 --> Controller Class Initialized
INFO - 2018-08-27 23:19:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:02 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:02 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:02 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:02 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:02 --> Config Class Initialized
INFO - 2018-08-27 23:19:02 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:02 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:02 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:02 --> URI Class Initialized
INFO - 2018-08-27 23:19:02 --> Router Class Initialized
INFO - 2018-08-27 23:19:02 --> Output Class Initialized
INFO - 2018-08-27 23:19:02 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:02 --> CSRF cookie sent
INFO - 2018-08-27 23:19:02 --> Input Class Initialized
INFO - 2018-08-27 23:19:02 --> Language Class Initialized
INFO - 2018-08-27 23:19:02 --> Loader Class Initialized
INFO - 2018-08-27 23:19:02 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:02 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:02 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:02 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:02 --> Controller Class Initialized
INFO - 2018-08-27 23:19:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:02 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:02 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:02 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-27 23:19:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:02 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:02 --> Total execution time: 0.0456
INFO - 2018-08-27 23:19:04 --> Config Class Initialized
INFO - 2018-08-27 23:19:04 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:04 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:04 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:04 --> URI Class Initialized
INFO - 2018-08-27 23:19:04 --> Router Class Initialized
INFO - 2018-08-27 23:19:04 --> Output Class Initialized
INFO - 2018-08-27 23:19:04 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:04 --> CSRF cookie sent
INFO - 2018-08-27 23:19:04 --> CSRF token verified
INFO - 2018-08-27 23:19:04 --> Input Class Initialized
INFO - 2018-08-27 23:19:04 --> Language Class Initialized
INFO - 2018-08-27 23:19:04 --> Loader Class Initialized
INFO - 2018-08-27 23:19:04 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:04 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:04 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:04 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:04 --> Controller Class Initialized
INFO - 2018-08-27 23:19:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:04 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:04 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:04 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:04 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:04 --> Config Class Initialized
INFO - 2018-08-27 23:19:04 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:04 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:04 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:04 --> URI Class Initialized
INFO - 2018-08-27 23:19:04 --> Router Class Initialized
INFO - 2018-08-27 23:19:04 --> Output Class Initialized
INFO - 2018-08-27 23:19:04 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:04 --> CSRF cookie sent
INFO - 2018-08-27 23:19:04 --> Input Class Initialized
INFO - 2018-08-27 23:19:04 --> Language Class Initialized
INFO - 2018-08-27 23:19:04 --> Loader Class Initialized
INFO - 2018-08-27 23:19:04 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:04 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:04 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:04 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:04 --> Controller Class Initialized
INFO - 2018-08-27 23:19:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:04 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:04 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:04 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-27 23:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:04 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:04 --> Total execution time: 0.0445
INFO - 2018-08-27 23:19:09 --> Config Class Initialized
INFO - 2018-08-27 23:19:09 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:09 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:09 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:09 --> URI Class Initialized
INFO - 2018-08-27 23:19:09 --> Router Class Initialized
INFO - 2018-08-27 23:19:09 --> Output Class Initialized
INFO - 2018-08-27 23:19:09 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:09 --> CSRF cookie sent
INFO - 2018-08-27 23:19:09 --> CSRF token verified
INFO - 2018-08-27 23:19:09 --> Input Class Initialized
INFO - 2018-08-27 23:19:09 --> Language Class Initialized
INFO - 2018-08-27 23:19:09 --> Loader Class Initialized
INFO - 2018-08-27 23:19:09 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:09 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:09 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:09 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:09 --> Controller Class Initialized
INFO - 2018-08-27 23:19:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:09 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:09 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:09 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:09 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:09 --> Config Class Initialized
INFO - 2018-08-27 23:19:09 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:09 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:09 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:09 --> URI Class Initialized
INFO - 2018-08-27 23:19:09 --> Router Class Initialized
INFO - 2018-08-27 23:19:09 --> Output Class Initialized
INFO - 2018-08-27 23:19:09 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:09 --> CSRF cookie sent
INFO - 2018-08-27 23:19:09 --> Input Class Initialized
INFO - 2018-08-27 23:19:09 --> Language Class Initialized
INFO - 2018-08-27 23:19:09 --> Loader Class Initialized
INFO - 2018-08-27 23:19:09 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:09 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:09 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:09 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:09 --> Controller Class Initialized
INFO - 2018-08-27 23:19:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:09 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:09 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:09 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-27 23:19:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:09 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:09 --> Total execution time: 0.0630
INFO - 2018-08-27 23:19:11 --> Config Class Initialized
INFO - 2018-08-27 23:19:11 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:11 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:11 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:11 --> URI Class Initialized
INFO - 2018-08-27 23:19:11 --> Router Class Initialized
INFO - 2018-08-27 23:19:11 --> Output Class Initialized
INFO - 2018-08-27 23:19:11 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:11 --> CSRF cookie sent
INFO - 2018-08-27 23:19:11 --> Input Class Initialized
INFO - 2018-08-27 23:19:11 --> Language Class Initialized
INFO - 2018-08-27 23:19:11 --> Loader Class Initialized
INFO - 2018-08-27 23:19:11 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:11 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:11 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:11 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:11 --> Controller Class Initialized
INFO - 2018-08-27 23:19:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:11 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:11 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-27 23:19:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:11 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:11 --> Total execution time: 0.0403
INFO - 2018-08-27 23:19:13 --> Config Class Initialized
INFO - 2018-08-27 23:19:13 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:13 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:13 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:13 --> URI Class Initialized
INFO - 2018-08-27 23:19:13 --> Router Class Initialized
INFO - 2018-08-27 23:19:13 --> Output Class Initialized
INFO - 2018-08-27 23:19:13 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:13 --> CSRF cookie sent
INFO - 2018-08-27 23:19:13 --> CSRF token verified
INFO - 2018-08-27 23:19:13 --> Input Class Initialized
INFO - 2018-08-27 23:19:13 --> Language Class Initialized
INFO - 2018-08-27 23:19:13 --> Loader Class Initialized
INFO - 2018-08-27 23:19:13 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:13 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:13 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:13 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:13 --> Controller Class Initialized
INFO - 2018-08-27 23:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:13 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:13 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:13 --> Config Class Initialized
INFO - 2018-08-27 23:19:13 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:13 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:13 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:13 --> URI Class Initialized
INFO - 2018-08-27 23:19:13 --> Router Class Initialized
INFO - 2018-08-27 23:19:13 --> Output Class Initialized
INFO - 2018-08-27 23:19:13 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:13 --> CSRF cookie sent
INFO - 2018-08-27 23:19:13 --> Input Class Initialized
INFO - 2018-08-27 23:19:13 --> Language Class Initialized
INFO - 2018-08-27 23:19:13 --> Loader Class Initialized
INFO - 2018-08-27 23:19:13 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:13 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:13 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:13 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:13 --> Controller Class Initialized
INFO - 2018-08-27 23:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:13 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:13 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-27 23:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:13 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:13 --> Total execution time: 0.0534
INFO - 2018-08-27 23:19:15 --> Config Class Initialized
INFO - 2018-08-27 23:19:15 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:15 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:15 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:15 --> URI Class Initialized
INFO - 2018-08-27 23:19:15 --> Router Class Initialized
INFO - 2018-08-27 23:19:15 --> Output Class Initialized
INFO - 2018-08-27 23:19:15 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:15 --> CSRF cookie sent
INFO - 2018-08-27 23:19:15 --> Input Class Initialized
INFO - 2018-08-27 23:19:15 --> Language Class Initialized
INFO - 2018-08-27 23:19:15 --> Loader Class Initialized
INFO - 2018-08-27 23:19:15 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:15 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:15 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:15 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:15 --> Controller Class Initialized
INFO - 2018-08-27 23:19:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:15 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:15 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:15 --> Config Class Initialized
INFO - 2018-08-27 23:19:15 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:15 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:15 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:15 --> URI Class Initialized
INFO - 2018-08-27 23:19:15 --> Router Class Initialized
INFO - 2018-08-27 23:19:15 --> Output Class Initialized
INFO - 2018-08-27 23:19:15 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:15 --> CSRF cookie sent
INFO - 2018-08-27 23:19:15 --> Input Class Initialized
INFO - 2018-08-27 23:19:15 --> Language Class Initialized
INFO - 2018-08-27 23:19:15 --> Loader Class Initialized
INFO - 2018-08-27 23:19:15 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:15 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:15 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:15 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:15 --> Controller Class Initialized
INFO - 2018-08-27 23:19:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:15 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:15 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:15 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-27 23:19:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:15 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:15 --> Total execution time: 0.0431
INFO - 2018-08-27 23:19:24 --> Config Class Initialized
INFO - 2018-08-27 23:19:24 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:24 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:24 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:24 --> URI Class Initialized
INFO - 2018-08-27 23:19:24 --> Router Class Initialized
INFO - 2018-08-27 23:19:24 --> Output Class Initialized
INFO - 2018-08-27 23:19:24 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:24 --> CSRF cookie sent
INFO - 2018-08-27 23:19:24 --> CSRF token verified
INFO - 2018-08-27 23:19:24 --> Input Class Initialized
INFO - 2018-08-27 23:19:24 --> Language Class Initialized
INFO - 2018-08-27 23:19:24 --> Loader Class Initialized
INFO - 2018-08-27 23:19:24 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:24 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:24 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:24 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:24 --> Controller Class Initialized
INFO - 2018-08-27 23:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:24 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:24 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:24 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:24 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-27 23:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:24 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:24 --> Total execution time: 0.0411
INFO - 2018-08-27 23:19:29 --> Config Class Initialized
INFO - 2018-08-27 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:29 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:29 --> URI Class Initialized
INFO - 2018-08-27 23:19:29 --> Router Class Initialized
INFO - 2018-08-27 23:19:29 --> Output Class Initialized
INFO - 2018-08-27 23:19:29 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:29 --> CSRF cookie sent
INFO - 2018-08-27 23:19:29 --> CSRF token verified
INFO - 2018-08-27 23:19:29 --> Input Class Initialized
INFO - 2018-08-27 23:19:29 --> Language Class Initialized
INFO - 2018-08-27 23:19:29 --> Loader Class Initialized
INFO - 2018-08-27 23:19:29 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:29 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:29 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:29 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:29 --> Controller Class Initialized
INFO - 2018-08-27 23:19:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:29 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:29 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:29 --> Form Validation Class Initialized
INFO - 2018-08-27 23:19:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-27 23:19:29 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:29 --> Config Class Initialized
INFO - 2018-08-27 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:29 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:29 --> URI Class Initialized
INFO - 2018-08-27 23:19:29 --> Router Class Initialized
INFO - 2018-08-27 23:19:29 --> Output Class Initialized
INFO - 2018-08-27 23:19:29 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:29 --> CSRF cookie sent
INFO - 2018-08-27 23:19:29 --> Input Class Initialized
INFO - 2018-08-27 23:19:29 --> Language Class Initialized
INFO - 2018-08-27 23:19:29 --> Loader Class Initialized
INFO - 2018-08-27 23:19:29 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:29 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:29 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:29 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:29 --> Controller Class Initialized
INFO - 2018-08-27 23:19:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:29 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:29 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:29 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-27 23:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:29 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:29 --> Total execution time: 0.0475
INFO - 2018-08-27 23:19:35 --> Config Class Initialized
INFO - 2018-08-27 23:19:35 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:35 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:35 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:35 --> URI Class Initialized
INFO - 2018-08-27 23:19:35 --> Router Class Initialized
INFO - 2018-08-27 23:19:35 --> Output Class Initialized
INFO - 2018-08-27 23:19:35 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:35 --> CSRF cookie sent
INFO - 2018-08-27 23:19:35 --> Input Class Initialized
INFO - 2018-08-27 23:19:35 --> Language Class Initialized
INFO - 2018-08-27 23:19:35 --> Loader Class Initialized
INFO - 2018-08-27 23:19:35 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:35 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:35 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:35 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:35 --> Controller Class Initialized
INFO - 2018-08-27 23:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:35 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:35 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:35 --> Model "MyAccountModel" initialized
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-27 23:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:35 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:35 --> Total execution time: 0.0367
INFO - 2018-08-27 23:19:38 --> Config Class Initialized
INFO - 2018-08-27 23:19:38 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:38 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:38 --> URI Class Initialized
INFO - 2018-08-27 23:19:38 --> Router Class Initialized
INFO - 2018-08-27 23:19:38 --> Output Class Initialized
INFO - 2018-08-27 23:19:38 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:38 --> CSRF cookie sent
INFO - 2018-08-27 23:19:38 --> Input Class Initialized
INFO - 2018-08-27 23:19:38 --> Language Class Initialized
INFO - 2018-08-27 23:19:38 --> Loader Class Initialized
INFO - 2018-08-27 23:19:38 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:38 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:38 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:38 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:38 --> Controller Class Initialized
INFO - 2018-08-27 23:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:38 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:38 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:38 --> Model "MyAccountModel" initialized
INFO - 2018-08-27 23:19:38 --> Config Class Initialized
INFO - 2018-08-27 23:19:38 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:38 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:38 --> URI Class Initialized
INFO - 2018-08-27 23:19:38 --> Router Class Initialized
INFO - 2018-08-27 23:19:38 --> Output Class Initialized
INFO - 2018-08-27 23:19:38 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:38 --> CSRF cookie sent
INFO - 2018-08-27 23:19:38 --> Input Class Initialized
INFO - 2018-08-27 23:19:38 --> Language Class Initialized
INFO - 2018-08-27 23:19:38 --> Loader Class Initialized
INFO - 2018-08-27 23:19:38 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:38 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:38 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:38 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:38 --> Controller Class Initialized
INFO - 2018-08-27 23:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:38 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:38 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:38 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-27 23:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:38 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:38 --> Total execution time: 0.0462
INFO - 2018-08-27 23:19:43 --> Config Class Initialized
INFO - 2018-08-27 23:19:43 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:43 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:43 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:43 --> URI Class Initialized
INFO - 2018-08-27 23:19:43 --> Router Class Initialized
INFO - 2018-08-27 23:19:43 --> Output Class Initialized
INFO - 2018-08-27 23:19:43 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:43 --> CSRF cookie sent
INFO - 2018-08-27 23:19:43 --> Input Class Initialized
INFO - 2018-08-27 23:19:43 --> Language Class Initialized
INFO - 2018-08-27 23:19:43 --> Loader Class Initialized
INFO - 2018-08-27 23:19:43 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:43 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:43 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:43 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:43 --> Controller Class Initialized
INFO - 2018-08-27 23:19:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:43 --> CSRF cookie sent
INFO - 2018-08-27 23:19:43 --> Config Class Initialized
INFO - 2018-08-27 23:19:43 --> Hooks Class Initialized
DEBUG - 2018-08-27 23:19:43 --> UTF-8 Support Enabled
INFO - 2018-08-27 23:19:43 --> Utf8 Class Initialized
INFO - 2018-08-27 23:19:43 --> URI Class Initialized
DEBUG - 2018-08-27 23:19:43 --> No URI present. Default controller set.
INFO - 2018-08-27 23:19:43 --> Router Class Initialized
INFO - 2018-08-27 23:19:43 --> Output Class Initialized
INFO - 2018-08-27 23:19:43 --> Security Class Initialized
DEBUG - 2018-08-27 23:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-27 23:19:43 --> CSRF cookie sent
INFO - 2018-08-27 23:19:43 --> Input Class Initialized
INFO - 2018-08-27 23:19:43 --> Language Class Initialized
INFO - 2018-08-27 23:19:43 --> Loader Class Initialized
INFO - 2018-08-27 23:19:43 --> Helper loaded: url_helper
INFO - 2018-08-27 23:19:43 --> Helper loaded: form_helper
INFO - 2018-08-27 23:19:43 --> Helper loaded: language_helper
DEBUG - 2018-08-27 23:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-27 23:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-27 23:19:43 --> User Agent Class Initialized
INFO - 2018-08-27 23:19:43 --> Controller Class Initialized
INFO - 2018-08-27 23:19:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-27 23:19:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-27 23:19:43 --> Pixel_Model class loaded
INFO - 2018-08-27 23:19:43 --> Database Driver Class Initialized
INFO - 2018-08-27 23:19:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-27 23:19:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-27 23:19:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-27 23:19:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-27 23:19:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-27 23:19:43 --> Final output sent to browser
DEBUG - 2018-08-27 23:19:43 --> Total execution time: 0.0373

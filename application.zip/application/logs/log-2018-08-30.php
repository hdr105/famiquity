<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-30 01:27:53 --> Config Class Initialized
INFO - 2018-08-30 01:27:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:27:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:27:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:27:53 --> URI Class Initialized
INFO - 2018-08-30 01:27:53 --> Router Class Initialized
INFO - 2018-08-30 01:27:53 --> Output Class Initialized
INFO - 2018-08-30 01:27:53 --> Security Class Initialized
DEBUG - 2018-08-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:27:53 --> CSRF cookie sent
INFO - 2018-08-30 01:27:53 --> Input Class Initialized
INFO - 2018-08-30 01:27:53 --> Language Class Initialized
INFO - 2018-08-30 01:27:53 --> Loader Class Initialized
INFO - 2018-08-30 01:27:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:27:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:27:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:27:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:27:53 --> Controller Class Initialized
INFO - 2018-08-30 01:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:27:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:27:53 --> Database Driver Class Initialized
INFO - 2018-08-30 01:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:27:53 --> Config Class Initialized
INFO - 2018-08-30 01:27:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:27:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:27:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:27:53 --> URI Class Initialized
INFO - 2018-08-30 01:27:53 --> Router Class Initialized
INFO - 2018-08-30 01:27:53 --> Output Class Initialized
INFO - 2018-08-30 01:27:53 --> Security Class Initialized
DEBUG - 2018-08-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:27:53 --> CSRF cookie sent
INFO - 2018-08-30 01:27:53 --> Input Class Initialized
INFO - 2018-08-30 01:27:53 --> Language Class Initialized
INFO - 2018-08-30 01:27:53 --> Loader Class Initialized
INFO - 2018-08-30 01:27:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:27:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:27:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:27:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:27:53 --> Controller Class Initialized
INFO - 2018-08-30 01:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:27:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:27:53 --> Database Driver Class Initialized
INFO - 2018-08-30 01:27:53 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-30 01:27:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 01:27:53 --> Could not find the language line "req_email"
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-30 01:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:27:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:27:53 --> Total execution time: 0.0376
INFO - 2018-08-30 01:27:59 --> Config Class Initialized
INFO - 2018-08-30 01:27:59 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:27:59 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:27:59 --> Utf8 Class Initialized
INFO - 2018-08-30 01:27:59 --> URI Class Initialized
DEBUG - 2018-08-30 01:27:59 --> No URI present. Default controller set.
INFO - 2018-08-30 01:27:59 --> Router Class Initialized
INFO - 2018-08-30 01:27:59 --> Output Class Initialized
INFO - 2018-08-30 01:27:59 --> Security Class Initialized
DEBUG - 2018-08-30 01:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:27:59 --> CSRF cookie sent
INFO - 2018-08-30 01:27:59 --> Input Class Initialized
INFO - 2018-08-30 01:27:59 --> Language Class Initialized
INFO - 2018-08-30 01:27:59 --> Loader Class Initialized
INFO - 2018-08-30 01:27:59 --> Helper loaded: url_helper
INFO - 2018-08-30 01:27:59 --> Helper loaded: form_helper
INFO - 2018-08-30 01:27:59 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:27:59 --> User Agent Class Initialized
INFO - 2018-08-30 01:27:59 --> Controller Class Initialized
INFO - 2018-08-30 01:27:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:27:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:27:59 --> Pixel_Model class loaded
INFO - 2018-08-30 01:27:59 --> Database Driver Class Initialized
INFO - 2018-08-30 01:27:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:27:59 --> Final output sent to browser
DEBUG - 2018-08-30 01:27:59 --> Total execution time: 0.0359
INFO - 2018-08-30 01:28:02 --> Config Class Initialized
INFO - 2018-08-30 01:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:02 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:02 --> URI Class Initialized
INFO - 2018-08-30 01:28:02 --> Router Class Initialized
INFO - 2018-08-30 01:28:02 --> Output Class Initialized
INFO - 2018-08-30 01:28:02 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:02 --> CSRF cookie sent
INFO - 2018-08-30 01:28:02 --> Input Class Initialized
INFO - 2018-08-30 01:28:02 --> Language Class Initialized
INFO - 2018-08-30 01:28:02 --> Loader Class Initialized
INFO - 2018-08-30 01:28:02 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:02 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:02 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:02 --> Controller Class Initialized
INFO - 2018-08-30 01:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:02 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:02 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:28:02 --> Final output sent to browser
DEBUG - 2018-08-30 01:28:02 --> Total execution time: 0.0430
INFO - 2018-08-30 01:28:15 --> Config Class Initialized
INFO - 2018-08-30 01:28:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:15 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:15 --> URI Class Initialized
INFO - 2018-08-30 01:28:15 --> Router Class Initialized
INFO - 2018-08-30 01:28:15 --> Output Class Initialized
INFO - 2018-08-30 01:28:15 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:15 --> CSRF cookie sent
INFO - 2018-08-30 01:28:15 --> CSRF token verified
INFO - 2018-08-30 01:28:15 --> Input Class Initialized
INFO - 2018-08-30 01:28:15 --> Language Class Initialized
INFO - 2018-08-30 01:28:15 --> Loader Class Initialized
INFO - 2018-08-30 01:28:15 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:15 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:15 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:15 --> Controller Class Initialized
INFO - 2018-08-30 01:28:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:15 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:15 --> Config Class Initialized
INFO - 2018-08-30 01:28:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:15 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:15 --> URI Class Initialized
INFO - 2018-08-30 01:28:15 --> Router Class Initialized
INFO - 2018-08-30 01:28:15 --> Output Class Initialized
INFO - 2018-08-30 01:28:15 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:15 --> CSRF cookie sent
INFO - 2018-08-30 01:28:15 --> Input Class Initialized
INFO - 2018-08-30 01:28:15 --> Language Class Initialized
INFO - 2018-08-30 01:28:15 --> Loader Class Initialized
INFO - 2018-08-30 01:28:15 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:15 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:15 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:15 --> Controller Class Initialized
INFO - 2018-08-30 01:28:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:15 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 01:28:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:28:15 --> Final output sent to browser
DEBUG - 2018-08-30 01:28:15 --> Total execution time: 0.0398
INFO - 2018-08-30 01:28:19 --> Config Class Initialized
INFO - 2018-08-30 01:28:19 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:19 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:19 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:19 --> URI Class Initialized
INFO - 2018-08-30 01:28:19 --> Router Class Initialized
INFO - 2018-08-30 01:28:19 --> Output Class Initialized
INFO - 2018-08-30 01:28:19 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:19 --> CSRF cookie sent
INFO - 2018-08-30 01:28:19 --> CSRF token verified
INFO - 2018-08-30 01:28:19 --> Input Class Initialized
INFO - 2018-08-30 01:28:19 --> Language Class Initialized
INFO - 2018-08-30 01:28:19 --> Loader Class Initialized
INFO - 2018-08-30 01:28:19 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:19 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:19 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:19 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:19 --> Controller Class Initialized
INFO - 2018-08-30 01:28:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:19 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:19 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:19 --> Form Validation Class Initialized
INFO - 2018-08-30 01:28:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:28:19 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:19 --> Config Class Initialized
INFO - 2018-08-30 01:28:19 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:19 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:19 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:19 --> URI Class Initialized
INFO - 2018-08-30 01:28:19 --> Router Class Initialized
INFO - 2018-08-30 01:28:19 --> Output Class Initialized
INFO - 2018-08-30 01:28:19 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:19 --> CSRF cookie sent
INFO - 2018-08-30 01:28:19 --> Input Class Initialized
INFO - 2018-08-30 01:28:19 --> Language Class Initialized
INFO - 2018-08-30 01:28:19 --> Loader Class Initialized
INFO - 2018-08-30 01:28:19 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:19 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:19 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:19 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:19 --> Controller Class Initialized
INFO - 2018-08-30 01:28:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:19 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:19 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:19 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 01:28:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:28:19 --> Final output sent to browser
DEBUG - 2018-08-30 01:28:19 --> Total execution time: 0.0420
INFO - 2018-08-30 01:28:22 --> Config Class Initialized
INFO - 2018-08-30 01:28:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:22 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:22 --> URI Class Initialized
INFO - 2018-08-30 01:28:22 --> Router Class Initialized
INFO - 2018-08-30 01:28:22 --> Output Class Initialized
INFO - 2018-08-30 01:28:22 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:22 --> CSRF cookie sent
INFO - 2018-08-30 01:28:22 --> CSRF token verified
INFO - 2018-08-30 01:28:22 --> Input Class Initialized
INFO - 2018-08-30 01:28:22 --> Language Class Initialized
INFO - 2018-08-30 01:28:22 --> Loader Class Initialized
INFO - 2018-08-30 01:28:22 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:22 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:22 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:22 --> Controller Class Initialized
INFO - 2018-08-30 01:28:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:22 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:22 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:22 --> Form Validation Class Initialized
INFO - 2018-08-30 01:28:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:28:22 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:22 --> Config Class Initialized
INFO - 2018-08-30 01:28:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:22 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:22 --> URI Class Initialized
INFO - 2018-08-30 01:28:22 --> Router Class Initialized
INFO - 2018-08-30 01:28:22 --> Output Class Initialized
INFO - 2018-08-30 01:28:22 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:22 --> CSRF cookie sent
INFO - 2018-08-30 01:28:22 --> Input Class Initialized
INFO - 2018-08-30 01:28:22 --> Language Class Initialized
INFO - 2018-08-30 01:28:22 --> Loader Class Initialized
INFO - 2018-08-30 01:28:22 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:22 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:22 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:22 --> Controller Class Initialized
INFO - 2018-08-30 01:28:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:22 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:22 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:22 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 01:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:28:22 --> Final output sent to browser
DEBUG - 2018-08-30 01:28:22 --> Total execution time: 0.0391
INFO - 2018-08-30 01:28:49 --> Config Class Initialized
INFO - 2018-08-30 01:28:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:28:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:28:49 --> Utf8 Class Initialized
INFO - 2018-08-30 01:28:49 --> URI Class Initialized
INFO - 2018-08-30 01:28:49 --> Router Class Initialized
INFO - 2018-08-30 01:28:49 --> Output Class Initialized
INFO - 2018-08-30 01:28:49 --> Security Class Initialized
DEBUG - 2018-08-30 01:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:28:49 --> CSRF cookie sent
INFO - 2018-08-30 01:28:49 --> Input Class Initialized
INFO - 2018-08-30 01:28:49 --> Language Class Initialized
INFO - 2018-08-30 01:28:49 --> Loader Class Initialized
INFO - 2018-08-30 01:28:49 --> Helper loaded: url_helper
INFO - 2018-08-30 01:28:49 --> Helper loaded: form_helper
INFO - 2018-08-30 01:28:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:28:49 --> User Agent Class Initialized
INFO - 2018-08-30 01:28:49 --> Controller Class Initialized
INFO - 2018-08-30 01:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:28:49 --> Pixel_Model class loaded
INFO - 2018-08-30 01:28:49 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:49 --> Database Driver Class Initialized
INFO - 2018-08-30 01:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 01:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:28:49 --> Final output sent to browser
DEBUG - 2018-08-30 01:28:49 --> Total execution time: 0.0451
INFO - 2018-08-30 01:29:30 --> Config Class Initialized
INFO - 2018-08-30 01:29:30 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:29:30 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:29:30 --> Utf8 Class Initialized
INFO - 2018-08-30 01:29:30 --> URI Class Initialized
INFO - 2018-08-30 01:29:30 --> Router Class Initialized
INFO - 2018-08-30 01:29:30 --> Output Class Initialized
INFO - 2018-08-30 01:29:30 --> Security Class Initialized
DEBUG - 2018-08-30 01:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:29:30 --> CSRF cookie sent
INFO - 2018-08-30 01:29:30 --> Input Class Initialized
INFO - 2018-08-30 01:29:30 --> Language Class Initialized
INFO - 2018-08-30 01:29:30 --> Loader Class Initialized
INFO - 2018-08-30 01:29:30 --> Helper loaded: url_helper
INFO - 2018-08-30 01:29:30 --> Helper loaded: form_helper
INFO - 2018-08-30 01:29:30 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:29:30 --> User Agent Class Initialized
INFO - 2018-08-30 01:29:30 --> Controller Class Initialized
INFO - 2018-08-30 01:29:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:29:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:29:30 --> Pixel_Model class loaded
INFO - 2018-08-30 01:29:30 --> Database Driver Class Initialized
INFO - 2018-08-30 01:29:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:29:30 --> Final output sent to browser
DEBUG - 2018-08-30 01:29:30 --> Total execution time: 0.0421
INFO - 2018-08-30 01:30:52 --> Config Class Initialized
INFO - 2018-08-30 01:30:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:30:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:30:52 --> Utf8 Class Initialized
INFO - 2018-08-30 01:30:52 --> URI Class Initialized
INFO - 2018-08-30 01:30:52 --> Router Class Initialized
INFO - 2018-08-30 01:30:52 --> Output Class Initialized
INFO - 2018-08-30 01:30:52 --> Security Class Initialized
DEBUG - 2018-08-30 01:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:30:52 --> CSRF cookie sent
INFO - 2018-08-30 01:30:52 --> CSRF token verified
INFO - 2018-08-30 01:30:52 --> Input Class Initialized
INFO - 2018-08-30 01:30:52 --> Language Class Initialized
INFO - 2018-08-30 01:30:52 --> Loader Class Initialized
INFO - 2018-08-30 01:30:52 --> Helper loaded: url_helper
INFO - 2018-08-30 01:30:52 --> Helper loaded: form_helper
INFO - 2018-08-30 01:30:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:30:52 --> User Agent Class Initialized
INFO - 2018-08-30 01:30:52 --> Controller Class Initialized
INFO - 2018-08-30 01:30:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:30:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:30:52 --> Pixel_Model class loaded
INFO - 2018-08-30 01:30:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:30:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:30:52 --> Config Class Initialized
INFO - 2018-08-30 01:30:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:30:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:30:52 --> Utf8 Class Initialized
INFO - 2018-08-30 01:30:52 --> URI Class Initialized
INFO - 2018-08-30 01:30:52 --> Router Class Initialized
INFO - 2018-08-30 01:30:52 --> Output Class Initialized
INFO - 2018-08-30 01:30:52 --> Security Class Initialized
DEBUG - 2018-08-30 01:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:30:52 --> CSRF cookie sent
INFO - 2018-08-30 01:30:52 --> Input Class Initialized
INFO - 2018-08-30 01:30:52 --> Language Class Initialized
INFO - 2018-08-30 01:30:52 --> Loader Class Initialized
INFO - 2018-08-30 01:30:52 --> Helper loaded: url_helper
INFO - 2018-08-30 01:30:52 --> Helper loaded: form_helper
INFO - 2018-08-30 01:30:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:30:52 --> User Agent Class Initialized
INFO - 2018-08-30 01:30:52 --> Controller Class Initialized
INFO - 2018-08-30 01:30:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:30:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:30:52 --> Pixel_Model class loaded
INFO - 2018-08-30 01:30:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:30:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 01:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:30:52 --> Final output sent to browser
DEBUG - 2018-08-30 01:30:52 --> Total execution time: 0.0406
INFO - 2018-08-30 01:31:23 --> Config Class Initialized
INFO - 2018-08-30 01:31:23 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:23 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:23 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:23 --> URI Class Initialized
INFO - 2018-08-30 01:31:23 --> Router Class Initialized
INFO - 2018-08-30 01:31:23 --> Output Class Initialized
INFO - 2018-08-30 01:31:23 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:23 --> CSRF cookie sent
INFO - 2018-08-30 01:31:23 --> CSRF token verified
INFO - 2018-08-30 01:31:23 --> Input Class Initialized
INFO - 2018-08-30 01:31:23 --> Language Class Initialized
INFO - 2018-08-30 01:31:23 --> Loader Class Initialized
INFO - 2018-08-30 01:31:23 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:23 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:23 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:23 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:23 --> Controller Class Initialized
INFO - 2018-08-30 01:31:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:23 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:23 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:23 --> Form Validation Class Initialized
INFO - 2018-08-30 01:31:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:31:23 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:24 --> Config Class Initialized
INFO - 2018-08-30 01:31:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:24 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:24 --> URI Class Initialized
INFO - 2018-08-30 01:31:24 --> Router Class Initialized
INFO - 2018-08-30 01:31:24 --> Output Class Initialized
INFO - 2018-08-30 01:31:24 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:24 --> CSRF cookie sent
INFO - 2018-08-30 01:31:24 --> Input Class Initialized
INFO - 2018-08-30 01:31:24 --> Language Class Initialized
INFO - 2018-08-30 01:31:24 --> Loader Class Initialized
INFO - 2018-08-30 01:31:24 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:24 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:24 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:24 --> Controller Class Initialized
INFO - 2018-08-30 01:31:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:24 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:31:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:24 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:24 --> Total execution time: 0.0382
INFO - 2018-08-30 01:31:37 --> Config Class Initialized
INFO - 2018-08-30 01:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:37 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:37 --> URI Class Initialized
INFO - 2018-08-30 01:31:37 --> Router Class Initialized
INFO - 2018-08-30 01:31:37 --> Output Class Initialized
INFO - 2018-08-30 01:31:37 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:37 --> CSRF cookie sent
INFO - 2018-08-30 01:31:37 --> Input Class Initialized
INFO - 2018-08-30 01:31:37 --> Language Class Initialized
INFO - 2018-08-30 01:31:37 --> Loader Class Initialized
INFO - 2018-08-30 01:31:37 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:37 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:37 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:37 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:37 --> Controller Class Initialized
INFO - 2018-08-30 01:31:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:37 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:37 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:37 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:37 --> Total execution time: 0.0408
INFO - 2018-08-30 01:31:39 --> Config Class Initialized
INFO - 2018-08-30 01:31:39 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:39 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:39 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:39 --> URI Class Initialized
INFO - 2018-08-30 01:31:39 --> Router Class Initialized
INFO - 2018-08-30 01:31:39 --> Output Class Initialized
INFO - 2018-08-30 01:31:39 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:39 --> CSRF cookie sent
INFO - 2018-08-30 01:31:39 --> Input Class Initialized
INFO - 2018-08-30 01:31:39 --> Language Class Initialized
INFO - 2018-08-30 01:31:39 --> Loader Class Initialized
INFO - 2018-08-30 01:31:39 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:39 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:39 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:39 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:39 --> Controller Class Initialized
INFO - 2018-08-30 01:31:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:39 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:39 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:31:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:39 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:39 --> Total execution time: 0.0442
INFO - 2018-08-30 01:31:42 --> Config Class Initialized
INFO - 2018-08-30 01:31:42 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:42 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:42 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:42 --> URI Class Initialized
DEBUG - 2018-08-30 01:31:42 --> No URI present. Default controller set.
INFO - 2018-08-30 01:31:42 --> Router Class Initialized
INFO - 2018-08-30 01:31:42 --> Output Class Initialized
INFO - 2018-08-30 01:31:42 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:42 --> CSRF cookie sent
INFO - 2018-08-30 01:31:42 --> Input Class Initialized
INFO - 2018-08-30 01:31:42 --> Language Class Initialized
INFO - 2018-08-30 01:31:42 --> Loader Class Initialized
INFO - 2018-08-30 01:31:42 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:42 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:42 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:42 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:42 --> Controller Class Initialized
INFO - 2018-08-30 01:31:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:42 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:42 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:42 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:42 --> Total execution time: 0.0579
INFO - 2018-08-30 01:31:45 --> Config Class Initialized
INFO - 2018-08-30 01:31:45 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:45 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:45 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:45 --> URI Class Initialized
INFO - 2018-08-30 01:31:45 --> Router Class Initialized
INFO - 2018-08-30 01:31:45 --> Output Class Initialized
INFO - 2018-08-30 01:31:45 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:45 --> CSRF cookie sent
INFO - 2018-08-30 01:31:45 --> Input Class Initialized
INFO - 2018-08-30 01:31:45 --> Language Class Initialized
INFO - 2018-08-30 01:31:45 --> Loader Class Initialized
INFO - 2018-08-30 01:31:45 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:45 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:45 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:45 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:45 --> Controller Class Initialized
INFO - 2018-08-30 01:31:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:45 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:45 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:31:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:45 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:45 --> Total execution time: 0.0408
INFO - 2018-08-30 01:31:57 --> Config Class Initialized
INFO - 2018-08-30 01:31:57 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:57 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:57 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:57 --> URI Class Initialized
INFO - 2018-08-30 01:31:57 --> Router Class Initialized
INFO - 2018-08-30 01:31:57 --> Output Class Initialized
INFO - 2018-08-30 01:31:57 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:57 --> CSRF cookie sent
INFO - 2018-08-30 01:31:57 --> CSRF token verified
INFO - 2018-08-30 01:31:57 --> Input Class Initialized
INFO - 2018-08-30 01:31:57 --> Language Class Initialized
INFO - 2018-08-30 01:31:57 --> Loader Class Initialized
INFO - 2018-08-30 01:31:57 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:57 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:57 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:57 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:57 --> Controller Class Initialized
INFO - 2018-08-30 01:31:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:57 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:57 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:57 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:57 --> Config Class Initialized
INFO - 2018-08-30 01:31:57 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:31:57 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:31:57 --> Utf8 Class Initialized
INFO - 2018-08-30 01:31:57 --> URI Class Initialized
INFO - 2018-08-30 01:31:57 --> Router Class Initialized
INFO - 2018-08-30 01:31:57 --> Output Class Initialized
INFO - 2018-08-30 01:31:57 --> Security Class Initialized
DEBUG - 2018-08-30 01:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:31:57 --> CSRF cookie sent
INFO - 2018-08-30 01:31:57 --> Input Class Initialized
INFO - 2018-08-30 01:31:57 --> Language Class Initialized
INFO - 2018-08-30 01:31:57 --> Loader Class Initialized
INFO - 2018-08-30 01:31:57 --> Helper loaded: url_helper
INFO - 2018-08-30 01:31:57 --> Helper loaded: form_helper
INFO - 2018-08-30 01:31:57 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:31:57 --> User Agent Class Initialized
INFO - 2018-08-30 01:31:57 --> Controller Class Initialized
INFO - 2018-08-30 01:31:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:31:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:31:57 --> Pixel_Model class loaded
INFO - 2018-08-30 01:31:57 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:57 --> Database Driver Class Initialized
INFO - 2018-08-30 01:31:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:31:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:31:57 --> Final output sent to browser
DEBUG - 2018-08-30 01:31:57 --> Total execution time: 0.0436
INFO - 2018-08-30 01:32:06 --> Config Class Initialized
INFO - 2018-08-30 01:32:06 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:06 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:06 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:06 --> URI Class Initialized
INFO - 2018-08-30 01:32:06 --> Router Class Initialized
INFO - 2018-08-30 01:32:06 --> Output Class Initialized
INFO - 2018-08-30 01:32:06 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:06 --> CSRF cookie sent
INFO - 2018-08-30 01:32:06 --> Input Class Initialized
INFO - 2018-08-30 01:32:06 --> Language Class Initialized
INFO - 2018-08-30 01:32:06 --> Loader Class Initialized
INFO - 2018-08-30 01:32:06 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:06 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:06 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:06 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:06 --> Controller Class Initialized
INFO - 2018-08-30 01:32:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:06 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:06 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:06 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:32:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:06 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:06 --> Total execution time: 0.0580
INFO - 2018-08-30 01:32:10 --> Config Class Initialized
INFO - 2018-08-30 01:32:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:10 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:10 --> URI Class Initialized
INFO - 2018-08-30 01:32:10 --> Router Class Initialized
INFO - 2018-08-30 01:32:10 --> Output Class Initialized
INFO - 2018-08-30 01:32:10 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:10 --> CSRF cookie sent
INFO - 2018-08-30 01:32:10 --> Input Class Initialized
INFO - 2018-08-30 01:32:10 --> Language Class Initialized
INFO - 2018-08-30 01:32:10 --> Loader Class Initialized
INFO - 2018-08-30 01:32:10 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:10 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:10 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:10 --> Controller Class Initialized
INFO - 2018-08-30 01:32:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:10 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:10 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:10 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:10 --> Total execution time: 0.0508
INFO - 2018-08-30 01:32:13 --> Config Class Initialized
INFO - 2018-08-30 01:32:13 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:13 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:13 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:13 --> URI Class Initialized
INFO - 2018-08-30 01:32:13 --> Router Class Initialized
INFO - 2018-08-30 01:32:13 --> Output Class Initialized
INFO - 2018-08-30 01:32:13 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:13 --> CSRF cookie sent
INFO - 2018-08-30 01:32:13 --> Input Class Initialized
INFO - 2018-08-30 01:32:13 --> Language Class Initialized
INFO - 2018-08-30 01:32:13 --> Loader Class Initialized
INFO - 2018-08-30 01:32:13 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:13 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:13 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:13 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:13 --> Controller Class Initialized
INFO - 2018-08-30 01:32:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:13 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:13 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:13 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:13 --> Total execution time: 0.0400
INFO - 2018-08-30 01:32:13 --> Config Class Initialized
INFO - 2018-08-30 01:32:13 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:13 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:13 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:13 --> URI Class Initialized
INFO - 2018-08-30 01:32:13 --> Router Class Initialized
INFO - 2018-08-30 01:32:13 --> Output Class Initialized
INFO - 2018-08-30 01:32:13 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:13 --> CSRF cookie sent
INFO - 2018-08-30 01:32:13 --> Input Class Initialized
INFO - 2018-08-30 01:32:13 --> Language Class Initialized
INFO - 2018-08-30 01:32:13 --> Loader Class Initialized
INFO - 2018-08-30 01:32:13 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:13 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:13 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:13 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:13 --> Controller Class Initialized
INFO - 2018-08-30 01:32:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:13 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:13 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:13 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:13 --> Total execution time: 0.0431
INFO - 2018-08-30 01:32:14 --> Config Class Initialized
INFO - 2018-08-30 01:32:14 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:14 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:14 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:14 --> URI Class Initialized
INFO - 2018-08-30 01:32:14 --> Router Class Initialized
INFO - 2018-08-30 01:32:14 --> Output Class Initialized
INFO - 2018-08-30 01:32:14 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:14 --> CSRF cookie sent
INFO - 2018-08-30 01:32:14 --> Input Class Initialized
INFO - 2018-08-30 01:32:14 --> Language Class Initialized
INFO - 2018-08-30 01:32:14 --> Loader Class Initialized
INFO - 2018-08-30 01:32:14 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:14 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:14 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:14 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:14 --> Controller Class Initialized
INFO - 2018-08-30 01:32:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:14 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:14 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:14 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:14 --> Total execution time: 0.0363
INFO - 2018-08-30 01:32:17 --> Config Class Initialized
INFO - 2018-08-30 01:32:17 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:17 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:17 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:17 --> URI Class Initialized
INFO - 2018-08-30 01:32:17 --> Router Class Initialized
INFO - 2018-08-30 01:32:17 --> Output Class Initialized
INFO - 2018-08-30 01:32:17 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:17 --> CSRF cookie sent
INFO - 2018-08-30 01:32:17 --> CSRF token verified
INFO - 2018-08-30 01:32:17 --> Input Class Initialized
INFO - 2018-08-30 01:32:17 --> Language Class Initialized
INFO - 2018-08-30 01:32:17 --> Loader Class Initialized
INFO - 2018-08-30 01:32:17 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:17 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:17 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:17 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:17 --> Controller Class Initialized
INFO - 2018-08-30 01:32:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:17 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:17 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:17 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:17 --> Config Class Initialized
INFO - 2018-08-30 01:32:17 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:17 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:17 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:17 --> URI Class Initialized
INFO - 2018-08-30 01:32:17 --> Router Class Initialized
INFO - 2018-08-30 01:32:17 --> Output Class Initialized
INFO - 2018-08-30 01:32:17 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:17 --> CSRF cookie sent
INFO - 2018-08-30 01:32:17 --> Input Class Initialized
INFO - 2018-08-30 01:32:17 --> Language Class Initialized
INFO - 2018-08-30 01:32:17 --> Loader Class Initialized
INFO - 2018-08-30 01:32:17 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:17 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:17 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:17 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:17 --> Controller Class Initialized
INFO - 2018-08-30 01:32:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:17 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:17 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:17 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:32:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:17 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:17 --> Total execution time: 0.0545
INFO - 2018-08-30 01:32:29 --> Config Class Initialized
INFO - 2018-08-30 01:32:29 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:29 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:29 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:29 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:29 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:29 --> Router Class Initialized
INFO - 2018-08-30 01:32:29 --> Output Class Initialized
INFO - 2018-08-30 01:32:29 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:29 --> CSRF cookie sent
INFO - 2018-08-30 01:32:29 --> Input Class Initialized
INFO - 2018-08-30 01:32:29 --> Language Class Initialized
INFO - 2018-08-30 01:32:29 --> Loader Class Initialized
INFO - 2018-08-30 01:32:29 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:29 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:29 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:29 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:29 --> Controller Class Initialized
INFO - 2018-08-30 01:32:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:29 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:29 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:29 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:29 --> Total execution time: 0.0410
INFO - 2018-08-30 01:32:36 --> Config Class Initialized
INFO - 2018-08-30 01:32:36 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:36 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:36 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:36 --> URI Class Initialized
INFO - 2018-08-30 01:32:36 --> Router Class Initialized
INFO - 2018-08-30 01:32:36 --> Output Class Initialized
INFO - 2018-08-30 01:32:36 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:36 --> CSRF cookie sent
INFO - 2018-08-30 01:32:36 --> CSRF token verified
INFO - 2018-08-30 01:32:36 --> Input Class Initialized
INFO - 2018-08-30 01:32:36 --> Language Class Initialized
INFO - 2018-08-30 01:32:36 --> Loader Class Initialized
INFO - 2018-08-30 01:32:36 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:36 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:36 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:36 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:36 --> Controller Class Initialized
INFO - 2018-08-30 01:32:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:36 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:36 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:36 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:36 --> Config Class Initialized
INFO - 2018-08-30 01:32:36 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:36 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:36 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:36 --> URI Class Initialized
INFO - 2018-08-30 01:32:36 --> Router Class Initialized
INFO - 2018-08-30 01:32:36 --> Output Class Initialized
INFO - 2018-08-30 01:32:36 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:36 --> CSRF cookie sent
INFO - 2018-08-30 01:32:36 --> Input Class Initialized
INFO - 2018-08-30 01:32:36 --> Language Class Initialized
INFO - 2018-08-30 01:32:36 --> Loader Class Initialized
INFO - 2018-08-30 01:32:36 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:36 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:36 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:36 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:36 --> Controller Class Initialized
INFO - 2018-08-30 01:32:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:36 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:36 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:36 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:36 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:36 --> Total execution time: 0.0538
INFO - 2018-08-30 01:32:45 --> Config Class Initialized
INFO - 2018-08-30 01:32:45 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:45 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:45 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:45 --> URI Class Initialized
INFO - 2018-08-30 01:32:45 --> Router Class Initialized
INFO - 2018-08-30 01:32:45 --> Output Class Initialized
INFO - 2018-08-30 01:32:45 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:45 --> CSRF cookie sent
INFO - 2018-08-30 01:32:45 --> Input Class Initialized
INFO - 2018-08-30 01:32:45 --> Language Class Initialized
INFO - 2018-08-30 01:32:45 --> Loader Class Initialized
INFO - 2018-08-30 01:32:45 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:45 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:45 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:45 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:45 --> Controller Class Initialized
INFO - 2018-08-30 01:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:45 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:45 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:45 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:45 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:45 --> Total execution time: 0.0462
INFO - 2018-08-30 01:32:48 --> Config Class Initialized
INFO - 2018-08-30 01:32:48 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:48 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:48 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:48 --> URI Class Initialized
INFO - 2018-08-30 01:32:48 --> Router Class Initialized
INFO - 2018-08-30 01:32:48 --> Output Class Initialized
INFO - 2018-08-30 01:32:48 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:48 --> CSRF cookie sent
INFO - 2018-08-30 01:32:48 --> Input Class Initialized
INFO - 2018-08-30 01:32:48 --> Language Class Initialized
INFO - 2018-08-30 01:32:48 --> Loader Class Initialized
INFO - 2018-08-30 01:32:48 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:48 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:48 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:48 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:48 --> Controller Class Initialized
INFO - 2018-08-30 01:32:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:48 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:48 --> Total execution time: 0.0339
INFO - 2018-08-30 01:32:49 --> Config Class Initialized
INFO - 2018-08-30 01:32:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:49 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:49 --> URI Class Initialized
INFO - 2018-08-30 01:32:49 --> Router Class Initialized
INFO - 2018-08-30 01:32:49 --> Output Class Initialized
INFO - 2018-08-30 01:32:49 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:49 --> CSRF cookie sent
INFO - 2018-08-30 01:32:49 --> Input Class Initialized
INFO - 2018-08-30 01:32:49 --> Language Class Initialized
INFO - 2018-08-30 01:32:49 --> Loader Class Initialized
INFO - 2018-08-30 01:32:49 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:49 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:49 --> Controller Class Initialized
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:49 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:49 --> Total execution time: 0.0329
INFO - 2018-08-30 01:32:49 --> Config Class Initialized
INFO - 2018-08-30 01:32:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:49 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:49 --> URI Class Initialized
INFO - 2018-08-30 01:32:49 --> Router Class Initialized
INFO - 2018-08-30 01:32:49 --> Output Class Initialized
INFO - 2018-08-30 01:32:49 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:49 --> CSRF cookie sent
INFO - 2018-08-30 01:32:49 --> Input Class Initialized
INFO - 2018-08-30 01:32:49 --> Language Class Initialized
INFO - 2018-08-30 01:32:49 --> Loader Class Initialized
INFO - 2018-08-30 01:32:49 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:49 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:49 --> Controller Class Initialized
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:49 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:49 --> Total execution time: 0.0303
INFO - 2018-08-30 01:32:49 --> Config Class Initialized
INFO - 2018-08-30 01:32:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:49 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:49 --> URI Class Initialized
INFO - 2018-08-30 01:32:49 --> Router Class Initialized
INFO - 2018-08-30 01:32:49 --> Output Class Initialized
INFO - 2018-08-30 01:32:49 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:49 --> CSRF cookie sent
INFO - 2018-08-30 01:32:49 --> Input Class Initialized
INFO - 2018-08-30 01:32:49 --> Language Class Initialized
INFO - 2018-08-30 01:32:49 --> Loader Class Initialized
INFO - 2018-08-30 01:32:49 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:49 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:49 --> Controller Class Initialized
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:49 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:49 --> Total execution time: 0.0193
INFO - 2018-08-30 01:32:49 --> Config Class Initialized
INFO - 2018-08-30 01:32:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:49 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:49 --> URI Class Initialized
INFO - 2018-08-30 01:32:49 --> Router Class Initialized
INFO - 2018-08-30 01:32:49 --> Output Class Initialized
INFO - 2018-08-30 01:32:49 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:49 --> CSRF cookie sent
INFO - 2018-08-30 01:32:49 --> Input Class Initialized
INFO - 2018-08-30 01:32:49 --> Language Class Initialized
INFO - 2018-08-30 01:32:49 --> Loader Class Initialized
INFO - 2018-08-30 01:32:49 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:49 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:49 --> Controller Class Initialized
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:49 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:49 --> Total execution time: 0.0230
INFO - 2018-08-30 01:32:50 --> Config Class Initialized
INFO - 2018-08-30 01:32:50 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:50 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:50 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:50 --> URI Class Initialized
INFO - 2018-08-30 01:32:50 --> Router Class Initialized
INFO - 2018-08-30 01:32:50 --> Output Class Initialized
INFO - 2018-08-30 01:32:50 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:50 --> CSRF cookie sent
INFO - 2018-08-30 01:32:50 --> Input Class Initialized
INFO - 2018-08-30 01:32:50 --> Language Class Initialized
INFO - 2018-08-30 01:32:50 --> Loader Class Initialized
INFO - 2018-08-30 01:32:50 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:50 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:50 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:50 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:50 --> Controller Class Initialized
INFO - 2018-08-30 01:32:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-08-30 01:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:50 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:50 --> Total execution time: 0.0307
INFO - 2018-08-30 01:32:51 --> Config Class Initialized
INFO - 2018-08-30 01:32:51 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:51 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:51 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:51 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:51 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:51 --> Router Class Initialized
INFO - 2018-08-30 01:32:51 --> Output Class Initialized
INFO - 2018-08-30 01:32:51 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:51 --> CSRF cookie sent
INFO - 2018-08-30 01:32:51 --> Input Class Initialized
INFO - 2018-08-30 01:32:51 --> Language Class Initialized
INFO - 2018-08-30 01:32:51 --> Loader Class Initialized
INFO - 2018-08-30 01:32:51 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:51 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:51 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:51 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:51 --> Controller Class Initialized
INFO - 2018-08-30 01:32:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:51 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:51 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:51 --> Total execution time: 0.0340
INFO - 2018-08-30 01:32:52 --> Config Class Initialized
INFO - 2018-08-30 01:32:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:52 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:52 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:52 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:52 --> Router Class Initialized
INFO - 2018-08-30 01:32:52 --> Output Class Initialized
INFO - 2018-08-30 01:32:52 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:52 --> CSRF cookie sent
INFO - 2018-08-30 01:32:52 --> Input Class Initialized
INFO - 2018-08-30 01:32:52 --> Language Class Initialized
INFO - 2018-08-30 01:32:52 --> Loader Class Initialized
INFO - 2018-08-30 01:32:52 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:52 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:52 --> Controller Class Initialized
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:52 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:52 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:52 --> Total execution time: 0.0362
INFO - 2018-08-30 01:32:52 --> Config Class Initialized
INFO - 2018-08-30 01:32:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:52 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:52 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:52 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:52 --> Router Class Initialized
INFO - 2018-08-30 01:32:52 --> Output Class Initialized
INFO - 2018-08-30 01:32:52 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:52 --> CSRF cookie sent
INFO - 2018-08-30 01:32:52 --> Input Class Initialized
INFO - 2018-08-30 01:32:52 --> Language Class Initialized
INFO - 2018-08-30 01:32:52 --> Loader Class Initialized
INFO - 2018-08-30 01:32:52 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:52 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:52 --> Controller Class Initialized
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:52 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:52 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:52 --> Total execution time: 0.0353
INFO - 2018-08-30 01:32:52 --> Config Class Initialized
INFO - 2018-08-30 01:32:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:52 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:52 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:52 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:52 --> Router Class Initialized
INFO - 2018-08-30 01:32:52 --> Output Class Initialized
INFO - 2018-08-30 01:32:52 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:52 --> CSRF cookie sent
INFO - 2018-08-30 01:32:52 --> Input Class Initialized
INFO - 2018-08-30 01:32:52 --> Language Class Initialized
INFO - 2018-08-30 01:32:52 --> Loader Class Initialized
INFO - 2018-08-30 01:32:52 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:52 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:52 --> Controller Class Initialized
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:52 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:52 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:53 --> Total execution time: 0.0413
INFO - 2018-08-30 01:32:53 --> Config Class Initialized
INFO - 2018-08-30 01:32:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:53 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:53 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:53 --> Router Class Initialized
INFO - 2018-08-30 01:32:53 --> Output Class Initialized
INFO - 2018-08-30 01:32:53 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:53 --> CSRF cookie sent
INFO - 2018-08-30 01:32:53 --> Input Class Initialized
INFO - 2018-08-30 01:32:53 --> Language Class Initialized
INFO - 2018-08-30 01:32:53 --> Loader Class Initialized
INFO - 2018-08-30 01:32:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:53 --> Controller Class Initialized
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:53 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:53 --> Total execution time: 0.0294
INFO - 2018-08-30 01:32:53 --> Config Class Initialized
INFO - 2018-08-30 01:32:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:53 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:53 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:53 --> Router Class Initialized
INFO - 2018-08-30 01:32:53 --> Output Class Initialized
INFO - 2018-08-30 01:32:53 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:53 --> CSRF cookie sent
INFO - 2018-08-30 01:32:53 --> Input Class Initialized
INFO - 2018-08-30 01:32:53 --> Language Class Initialized
INFO - 2018-08-30 01:32:53 --> Loader Class Initialized
INFO - 2018-08-30 01:32:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:53 --> Controller Class Initialized
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:53 --> Config Class Initialized
INFO - 2018-08-30 01:32:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:53 --> URI Class Initialized
INFO - 2018-08-30 01:32:53 --> Database Driver Class Initialized
DEBUG - 2018-08-30 01:32:53 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:53 --> Router Class Initialized
INFO - 2018-08-30 01:32:53 --> Output Class Initialized
INFO - 2018-08-30 01:32:53 --> Security Class Initialized
INFO - 2018-08-30 01:32:53 --> Model "QuestionsModel" initialized
DEBUG - 2018-08-30 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:53 --> CSRF cookie sent
INFO - 2018-08-30 01:32:53 --> Input Class Initialized
INFO - 2018-08-30 01:32:53 --> Language Class Initialized
INFO - 2018-08-30 01:32:53 --> Loader Class Initialized
INFO - 2018-08-30 01:32:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: language_helper
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
DEBUG - 2018-08-30 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:53 --> Total execution time: 0.0480
INFO - 2018-08-30 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:53 --> Controller Class Initialized
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:53 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:53 --> Total execution time: 0.0410
INFO - 2018-08-30 01:32:53 --> Config Class Initialized
INFO - 2018-08-30 01:32:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:53 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:53 --> URI Class Initialized
DEBUG - 2018-08-30 01:32:53 --> No URI present. Default controller set.
INFO - 2018-08-30 01:32:53 --> Router Class Initialized
INFO - 2018-08-30 01:32:53 --> Output Class Initialized
INFO - 2018-08-30 01:32:53 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:53 --> CSRF cookie sent
INFO - 2018-08-30 01:32:53 --> Input Class Initialized
INFO - 2018-08-30 01:32:53 --> Language Class Initialized
INFO - 2018-08-30 01:32:53 --> Loader Class Initialized
INFO - 2018-08-30 01:32:53 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:53 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:53 --> Controller Class Initialized
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:53 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:53 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:53 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:53 --> Total execution time: 0.0461
INFO - 2018-08-30 01:32:56 --> Config Class Initialized
INFO - 2018-08-30 01:32:56 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:56 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:56 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:56 --> URI Class Initialized
INFO - 2018-08-30 01:32:56 --> Router Class Initialized
INFO - 2018-08-30 01:32:56 --> Output Class Initialized
INFO - 2018-08-30 01:32:56 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:56 --> CSRF cookie sent
INFO - 2018-08-30 01:32:56 --> Input Class Initialized
INFO - 2018-08-30 01:32:56 --> Language Class Initialized
INFO - 2018-08-30 01:32:56 --> Loader Class Initialized
INFO - 2018-08-30 01:32:56 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:56 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:56 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:56 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:56 --> Controller Class Initialized
INFO - 2018-08-30 01:32:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:56 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:56 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:56 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:56 --> Total execution time: 0.0401
INFO - 2018-08-30 01:32:58 --> Config Class Initialized
INFO - 2018-08-30 01:32:58 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:58 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:58 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:58 --> URI Class Initialized
INFO - 2018-08-30 01:32:58 --> Router Class Initialized
INFO - 2018-08-30 01:32:58 --> Output Class Initialized
INFO - 2018-08-30 01:32:58 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:58 --> CSRF cookie sent
INFO - 2018-08-30 01:32:58 --> Input Class Initialized
INFO - 2018-08-30 01:32:58 --> Language Class Initialized
INFO - 2018-08-30 01:32:58 --> Loader Class Initialized
INFO - 2018-08-30 01:32:58 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:58 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:58 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:58 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:58 --> Controller Class Initialized
INFO - 2018-08-30 01:32:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:58 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:58 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:58 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:58 --> Total execution time: 0.0452
INFO - 2018-08-30 01:32:59 --> Config Class Initialized
INFO - 2018-08-30 01:32:59 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:32:59 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:32:59 --> Utf8 Class Initialized
INFO - 2018-08-30 01:32:59 --> URI Class Initialized
INFO - 2018-08-30 01:32:59 --> Router Class Initialized
INFO - 2018-08-30 01:32:59 --> Output Class Initialized
INFO - 2018-08-30 01:32:59 --> Security Class Initialized
DEBUG - 2018-08-30 01:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:32:59 --> CSRF cookie sent
INFO - 2018-08-30 01:32:59 --> Input Class Initialized
INFO - 2018-08-30 01:32:59 --> Language Class Initialized
INFO - 2018-08-30 01:32:59 --> Loader Class Initialized
INFO - 2018-08-30 01:32:59 --> Helper loaded: url_helper
INFO - 2018-08-30 01:32:59 --> Helper loaded: form_helper
INFO - 2018-08-30 01:32:59 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:32:59 --> User Agent Class Initialized
INFO - 2018-08-30 01:32:59 --> Controller Class Initialized
INFO - 2018-08-30 01:32:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:32:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:32:59 --> Pixel_Model class loaded
INFO - 2018-08-30 01:32:59 --> Database Driver Class Initialized
INFO - 2018-08-30 01:32:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:32:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:32:59 --> Final output sent to browser
DEBUG - 2018-08-30 01:32:59 --> Total execution time: 0.0379
INFO - 2018-08-30 01:33:00 --> Config Class Initialized
INFO - 2018-08-30 01:33:00 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:00 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:00 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:00 --> URI Class Initialized
INFO - 2018-08-30 01:33:00 --> Router Class Initialized
INFO - 2018-08-30 01:33:00 --> Output Class Initialized
INFO - 2018-08-30 01:33:00 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:00 --> CSRF cookie sent
INFO - 2018-08-30 01:33:00 --> Input Class Initialized
INFO - 2018-08-30 01:33:00 --> Language Class Initialized
INFO - 2018-08-30 01:33:00 --> Loader Class Initialized
INFO - 2018-08-30 01:33:00 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:00 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:00 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:00 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:00 --> Controller Class Initialized
INFO - 2018-08-30 01:33:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:00 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:00 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:33:00 --> Final output sent to browser
DEBUG - 2018-08-30 01:33:00 --> Total execution time: 0.0418
INFO - 2018-08-30 01:33:00 --> Config Class Initialized
INFO - 2018-08-30 01:33:00 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:00 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:00 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:00 --> URI Class Initialized
INFO - 2018-08-30 01:33:00 --> Router Class Initialized
INFO - 2018-08-30 01:33:00 --> Output Class Initialized
INFO - 2018-08-30 01:33:00 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:00 --> CSRF cookie sent
INFO - 2018-08-30 01:33:00 --> Input Class Initialized
INFO - 2018-08-30 01:33:00 --> Language Class Initialized
INFO - 2018-08-30 01:33:00 --> Loader Class Initialized
INFO - 2018-08-30 01:33:00 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:00 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:00 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:00 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:00 --> Controller Class Initialized
INFO - 2018-08-30 01:33:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:00 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:00 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:33:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:33:00 --> Final output sent to browser
DEBUG - 2018-08-30 01:33:00 --> Total execution time: 0.0378
INFO - 2018-08-30 01:33:01 --> Config Class Initialized
INFO - 2018-08-30 01:33:01 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:01 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:01 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:01 --> URI Class Initialized
INFO - 2018-08-30 01:33:01 --> Router Class Initialized
INFO - 2018-08-30 01:33:01 --> Output Class Initialized
INFO - 2018-08-30 01:33:01 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:01 --> CSRF cookie sent
INFO - 2018-08-30 01:33:01 --> Input Class Initialized
INFO - 2018-08-30 01:33:01 --> Language Class Initialized
INFO - 2018-08-30 01:33:01 --> Loader Class Initialized
INFO - 2018-08-30 01:33:01 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:01 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:01 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:01 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:01 --> Controller Class Initialized
INFO - 2018-08-30 01:33:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:01 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:01 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:33:01 --> Final output sent to browser
DEBUG - 2018-08-30 01:33:01 --> Total execution time: 0.0440
INFO - 2018-08-30 01:33:01 --> Config Class Initialized
INFO - 2018-08-30 01:33:01 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:01 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:01 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:01 --> URI Class Initialized
INFO - 2018-08-30 01:33:01 --> Router Class Initialized
INFO - 2018-08-30 01:33:01 --> Output Class Initialized
INFO - 2018-08-30 01:33:01 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:01 --> CSRF cookie sent
INFO - 2018-08-30 01:33:01 --> Input Class Initialized
INFO - 2018-08-30 01:33:01 --> Language Class Initialized
INFO - 2018-08-30 01:33:01 --> Loader Class Initialized
INFO - 2018-08-30 01:33:01 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:01 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:01 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:01 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:01 --> Controller Class Initialized
INFO - 2018-08-30 01:33:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:01 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:01 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:33:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:33:01 --> Final output sent to browser
DEBUG - 2018-08-30 01:33:01 --> Total execution time: 0.0411
INFO - 2018-08-30 01:33:07 --> Config Class Initialized
INFO - 2018-08-30 01:33:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:07 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:07 --> URI Class Initialized
INFO - 2018-08-30 01:33:07 --> Router Class Initialized
INFO - 2018-08-30 01:33:07 --> Output Class Initialized
INFO - 2018-08-30 01:33:07 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:07 --> CSRF cookie sent
INFO - 2018-08-30 01:33:07 --> CSRF token verified
INFO - 2018-08-30 01:33:07 --> Input Class Initialized
INFO - 2018-08-30 01:33:07 --> Language Class Initialized
INFO - 2018-08-30 01:33:07 --> Loader Class Initialized
INFO - 2018-08-30 01:33:07 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:07 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:07 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:07 --> Controller Class Initialized
INFO - 2018-08-30 01:33:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:07 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:07 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:07 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:07 --> Config Class Initialized
INFO - 2018-08-30 01:33:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:33:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:33:07 --> Utf8 Class Initialized
INFO - 2018-08-30 01:33:07 --> URI Class Initialized
INFO - 2018-08-30 01:33:07 --> Router Class Initialized
INFO - 2018-08-30 01:33:07 --> Output Class Initialized
INFO - 2018-08-30 01:33:07 --> Security Class Initialized
DEBUG - 2018-08-30 01:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:33:07 --> CSRF cookie sent
INFO - 2018-08-30 01:33:07 --> Input Class Initialized
INFO - 2018-08-30 01:33:07 --> Language Class Initialized
INFO - 2018-08-30 01:33:07 --> Loader Class Initialized
INFO - 2018-08-30 01:33:07 --> Helper loaded: url_helper
INFO - 2018-08-30 01:33:07 --> Helper loaded: form_helper
INFO - 2018-08-30 01:33:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:33:07 --> User Agent Class Initialized
INFO - 2018-08-30 01:33:07 --> Controller Class Initialized
INFO - 2018-08-30 01:33:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:33:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:33:07 --> Pixel_Model class loaded
INFO - 2018-08-30 01:33:07 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:07 --> Database Driver Class Initialized
INFO - 2018-08-30 01:33:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:33:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:33:07 --> Final output sent to browser
DEBUG - 2018-08-30 01:33:07 --> Total execution time: 0.0404
INFO - 2018-08-30 01:36:46 --> Config Class Initialized
INFO - 2018-08-30 01:36:46 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:36:46 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:36:46 --> Utf8 Class Initialized
INFO - 2018-08-30 01:36:46 --> URI Class Initialized
DEBUG - 2018-08-30 01:36:46 --> No URI present. Default controller set.
INFO - 2018-08-30 01:36:46 --> Router Class Initialized
INFO - 2018-08-30 01:36:46 --> Output Class Initialized
INFO - 2018-08-30 01:36:46 --> Security Class Initialized
DEBUG - 2018-08-30 01:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:36:46 --> CSRF cookie sent
INFO - 2018-08-30 01:36:46 --> Input Class Initialized
INFO - 2018-08-30 01:36:46 --> Language Class Initialized
INFO - 2018-08-30 01:36:46 --> Loader Class Initialized
INFO - 2018-08-30 01:36:46 --> Helper loaded: url_helper
INFO - 2018-08-30 01:36:46 --> Helper loaded: form_helper
INFO - 2018-08-30 01:36:46 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:36:46 --> User Agent Class Initialized
INFO - 2018-08-30 01:36:46 --> Controller Class Initialized
INFO - 2018-08-30 01:36:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:36:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:36:46 --> Pixel_Model class loaded
INFO - 2018-08-30 01:36:46 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:36:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:36:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 01:36:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:36:46 --> Final output sent to browser
DEBUG - 2018-08-30 01:36:46 --> Total execution time: 0.0545
INFO - 2018-08-30 01:36:51 --> Config Class Initialized
INFO - 2018-08-30 01:36:51 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:36:51 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:36:51 --> Utf8 Class Initialized
INFO - 2018-08-30 01:36:51 --> URI Class Initialized
INFO - 2018-08-30 01:36:51 --> Router Class Initialized
INFO - 2018-08-30 01:36:51 --> Output Class Initialized
INFO - 2018-08-30 01:36:51 --> Security Class Initialized
DEBUG - 2018-08-30 01:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:36:51 --> CSRF cookie sent
INFO - 2018-08-30 01:36:51 --> Input Class Initialized
INFO - 2018-08-30 01:36:51 --> Language Class Initialized
INFO - 2018-08-30 01:36:51 --> Loader Class Initialized
INFO - 2018-08-30 01:36:51 --> Helper loaded: url_helper
INFO - 2018-08-30 01:36:51 --> Helper loaded: form_helper
INFO - 2018-08-30 01:36:51 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:36:51 --> User Agent Class Initialized
INFO - 2018-08-30 01:36:51 --> Controller Class Initialized
INFO - 2018-08-30 01:36:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:36:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:36:51 --> Pixel_Model class loaded
INFO - 2018-08-30 01:36:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:36:51 --> Final output sent to browser
DEBUG - 2018-08-30 01:36:51 --> Total execution time: 0.0484
INFO - 2018-08-30 01:36:54 --> Config Class Initialized
INFO - 2018-08-30 01:36:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:36:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:36:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:36:54 --> URI Class Initialized
INFO - 2018-08-30 01:36:54 --> Router Class Initialized
INFO - 2018-08-30 01:36:54 --> Output Class Initialized
INFO - 2018-08-30 01:36:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:36:54 --> CSRF cookie sent
INFO - 2018-08-30 01:36:54 --> CSRF token verified
INFO - 2018-08-30 01:36:54 --> Input Class Initialized
INFO - 2018-08-30 01:36:54 --> Language Class Initialized
INFO - 2018-08-30 01:36:54 --> Loader Class Initialized
INFO - 2018-08-30 01:36:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:36:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:36:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:36:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:36:54 --> Controller Class Initialized
INFO - 2018-08-30 01:36:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:36:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:36:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:36:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:54 --> Config Class Initialized
INFO - 2018-08-30 01:36:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:36:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:36:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:36:54 --> URI Class Initialized
INFO - 2018-08-30 01:36:54 --> Router Class Initialized
INFO - 2018-08-30 01:36:54 --> Output Class Initialized
INFO - 2018-08-30 01:36:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:36:54 --> CSRF cookie sent
INFO - 2018-08-30 01:36:54 --> Input Class Initialized
INFO - 2018-08-30 01:36:54 --> Language Class Initialized
INFO - 2018-08-30 01:36:54 --> Loader Class Initialized
INFO - 2018-08-30 01:36:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:36:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:36:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:36:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:36:54 --> Controller Class Initialized
INFO - 2018-08-30 01:36:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:36:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:36:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:36:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:36:54 --> Final output sent to browser
DEBUG - 2018-08-30 01:36:54 --> Total execution time: 0.0352
INFO - 2018-08-30 01:41:11 --> Config Class Initialized
INFO - 2018-08-30 01:41:11 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:11 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:11 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:11 --> URI Class Initialized
INFO - 2018-08-30 01:41:11 --> Router Class Initialized
INFO - 2018-08-30 01:41:11 --> Output Class Initialized
INFO - 2018-08-30 01:41:11 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:11 --> CSRF cookie sent
INFO - 2018-08-30 01:41:11 --> Input Class Initialized
INFO - 2018-08-30 01:41:11 --> Language Class Initialized
INFO - 2018-08-30 01:41:11 --> Loader Class Initialized
INFO - 2018-08-30 01:41:11 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:11 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:11 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:11 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:11 --> Controller Class Initialized
INFO - 2018-08-30 01:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:11 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 01:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:41:11 --> Final output sent to browser
DEBUG - 2018-08-30 01:41:11 --> Total execution time: 0.0439
INFO - 2018-08-30 01:41:13 --> Config Class Initialized
INFO - 2018-08-30 01:41:13 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:13 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:13 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:13 --> URI Class Initialized
INFO - 2018-08-30 01:41:13 --> Router Class Initialized
INFO - 2018-08-30 01:41:13 --> Output Class Initialized
INFO - 2018-08-30 01:41:13 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:13 --> CSRF cookie sent
INFO - 2018-08-30 01:41:13 --> Input Class Initialized
INFO - 2018-08-30 01:41:13 --> Language Class Initialized
INFO - 2018-08-30 01:41:13 --> Loader Class Initialized
INFO - 2018-08-30 01:41:13 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:13 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:13 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:13 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:13 --> Controller Class Initialized
INFO - 2018-08-30 01:41:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:13 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:13 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:13 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 01:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:41:13 --> Final output sent to browser
DEBUG - 2018-08-30 01:41:13 --> Total execution time: 0.0445
INFO - 2018-08-30 01:41:14 --> Config Class Initialized
INFO - 2018-08-30 01:41:14 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:15 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:15 --> URI Class Initialized
INFO - 2018-08-30 01:41:15 --> Router Class Initialized
INFO - 2018-08-30 01:41:15 --> Output Class Initialized
INFO - 2018-08-30 01:41:15 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:15 --> CSRF cookie sent
INFO - 2018-08-30 01:41:15 --> Input Class Initialized
INFO - 2018-08-30 01:41:15 --> Language Class Initialized
INFO - 2018-08-30 01:41:15 --> Loader Class Initialized
INFO - 2018-08-30 01:41:15 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:15 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:15 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:15 --> Controller Class Initialized
INFO - 2018-08-30 01:41:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:15 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:15 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 01:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:41:15 --> Final output sent to browser
DEBUG - 2018-08-30 01:41:15 --> Total execution time: 0.0608
INFO - 2018-08-30 01:41:17 --> Config Class Initialized
INFO - 2018-08-30 01:41:17 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:17 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:17 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:17 --> URI Class Initialized
INFO - 2018-08-30 01:41:17 --> Router Class Initialized
INFO - 2018-08-30 01:41:17 --> Output Class Initialized
INFO - 2018-08-30 01:41:17 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:17 --> CSRF cookie sent
INFO - 2018-08-30 01:41:17 --> Input Class Initialized
INFO - 2018-08-30 01:41:17 --> Language Class Initialized
INFO - 2018-08-30 01:41:17 --> Loader Class Initialized
INFO - 2018-08-30 01:41:17 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:17 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:17 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:17 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:17 --> Controller Class Initialized
INFO - 2018-08-30 01:41:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:17 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:17 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 01:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:41:17 --> Final output sent to browser
DEBUG - 2018-08-30 01:41:17 --> Total execution time: 0.0376
INFO - 2018-08-30 01:41:24 --> Config Class Initialized
INFO - 2018-08-30 01:41:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:24 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:24 --> URI Class Initialized
INFO - 2018-08-30 01:41:24 --> Router Class Initialized
INFO - 2018-08-30 01:41:24 --> Output Class Initialized
INFO - 2018-08-30 01:41:24 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:24 --> CSRF cookie sent
INFO - 2018-08-30 01:41:24 --> CSRF token verified
INFO - 2018-08-30 01:41:24 --> Input Class Initialized
INFO - 2018-08-30 01:41:24 --> Language Class Initialized
INFO - 2018-08-30 01:41:24 --> Loader Class Initialized
INFO - 2018-08-30 01:41:24 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:24 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:24 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:24 --> Controller Class Initialized
INFO - 2018-08-30 01:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:24 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:24 --> Config Class Initialized
INFO - 2018-08-30 01:41:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:41:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:41:24 --> Utf8 Class Initialized
INFO - 2018-08-30 01:41:24 --> URI Class Initialized
INFO - 2018-08-30 01:41:24 --> Router Class Initialized
INFO - 2018-08-30 01:41:24 --> Output Class Initialized
INFO - 2018-08-30 01:41:24 --> Security Class Initialized
DEBUG - 2018-08-30 01:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:41:24 --> CSRF cookie sent
INFO - 2018-08-30 01:41:24 --> Input Class Initialized
INFO - 2018-08-30 01:41:24 --> Language Class Initialized
INFO - 2018-08-30 01:41:24 --> Loader Class Initialized
INFO - 2018-08-30 01:41:24 --> Helper loaded: url_helper
INFO - 2018-08-30 01:41:24 --> Helper loaded: form_helper
INFO - 2018-08-30 01:41:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:41:24 --> User Agent Class Initialized
INFO - 2018-08-30 01:41:24 --> Controller Class Initialized
INFO - 2018-08-30 01:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:41:24 --> Pixel_Model class loaded
INFO - 2018-08-30 01:41:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:24 --> Database Driver Class Initialized
INFO - 2018-08-30 01:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 01:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:41:24 --> Final output sent to browser
DEBUG - 2018-08-30 01:41:24 --> Total execution time: 0.0561
INFO - 2018-08-30 01:43:10 --> Config Class Initialized
INFO - 2018-08-30 01:43:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:43:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:43:10 --> Utf8 Class Initialized
INFO - 2018-08-30 01:43:10 --> URI Class Initialized
INFO - 2018-08-30 01:43:10 --> Router Class Initialized
INFO - 2018-08-30 01:43:10 --> Output Class Initialized
INFO - 2018-08-30 01:43:10 --> Security Class Initialized
DEBUG - 2018-08-30 01:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:43:10 --> CSRF cookie sent
INFO - 2018-08-30 01:43:10 --> CSRF token verified
INFO - 2018-08-30 01:43:10 --> Input Class Initialized
INFO - 2018-08-30 01:43:10 --> Language Class Initialized
INFO - 2018-08-30 01:43:10 --> Loader Class Initialized
INFO - 2018-08-30 01:43:10 --> Helper loaded: url_helper
INFO - 2018-08-30 01:43:10 --> Helper loaded: form_helper
INFO - 2018-08-30 01:43:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:43:10 --> User Agent Class Initialized
INFO - 2018-08-30 01:43:10 --> Controller Class Initialized
INFO - 2018-08-30 01:43:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:43:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:43:10 --> Pixel_Model class loaded
INFO - 2018-08-30 01:43:10 --> Database Driver Class Initialized
INFO - 2018-08-30 01:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:43:10 --> Form Validation Class Initialized
INFO - 2018-08-30 01:43:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:43:10 --> Database Driver Class Initialized
INFO - 2018-08-30 01:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:43:10 --> Config Class Initialized
INFO - 2018-08-30 01:43:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:43:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:43:10 --> Utf8 Class Initialized
INFO - 2018-08-30 01:43:10 --> URI Class Initialized
INFO - 2018-08-30 01:43:10 --> Router Class Initialized
INFO - 2018-08-30 01:43:10 --> Output Class Initialized
INFO - 2018-08-30 01:43:10 --> Security Class Initialized
DEBUG - 2018-08-30 01:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:43:10 --> CSRF cookie sent
INFO - 2018-08-30 01:43:10 --> Input Class Initialized
INFO - 2018-08-30 01:43:10 --> Language Class Initialized
INFO - 2018-08-30 01:43:10 --> Loader Class Initialized
INFO - 2018-08-30 01:43:10 --> Helper loaded: url_helper
INFO - 2018-08-30 01:43:10 --> Helper loaded: form_helper
INFO - 2018-08-30 01:43:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:43:10 --> User Agent Class Initialized
INFO - 2018-08-30 01:43:10 --> Controller Class Initialized
INFO - 2018-08-30 01:43:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:43:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:43:10 --> Pixel_Model class loaded
INFO - 2018-08-30 01:43:10 --> Database Driver Class Initialized
INFO - 2018-08-30 01:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:43:10 --> Database Driver Class Initialized
INFO - 2018-08-30 01:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 01:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:43:10 --> Final output sent to browser
DEBUG - 2018-08-30 01:43:10 --> Total execution time: 0.0660
INFO - 2018-08-30 01:44:26 --> Config Class Initialized
INFO - 2018-08-30 01:44:26 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:44:26 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:44:26 --> Utf8 Class Initialized
INFO - 2018-08-30 01:44:26 --> URI Class Initialized
INFO - 2018-08-30 01:44:26 --> Router Class Initialized
INFO - 2018-08-30 01:44:26 --> Output Class Initialized
INFO - 2018-08-30 01:44:26 --> Security Class Initialized
DEBUG - 2018-08-30 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:44:26 --> CSRF cookie sent
INFO - 2018-08-30 01:44:26 --> CSRF token verified
INFO - 2018-08-30 01:44:26 --> Input Class Initialized
INFO - 2018-08-30 01:44:26 --> Language Class Initialized
INFO - 2018-08-30 01:44:26 --> Loader Class Initialized
INFO - 2018-08-30 01:44:26 --> Helper loaded: url_helper
INFO - 2018-08-30 01:44:26 --> Helper loaded: form_helper
INFO - 2018-08-30 01:44:26 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:44:26 --> User Agent Class Initialized
INFO - 2018-08-30 01:44:26 --> Controller Class Initialized
INFO - 2018-08-30 01:44:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:44:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:44:26 --> Pixel_Model class loaded
INFO - 2018-08-30 01:44:26 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:26 --> Form Validation Class Initialized
INFO - 2018-08-30 01:44:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:44:26 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:26 --> Config Class Initialized
INFO - 2018-08-30 01:44:26 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:44:26 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:44:26 --> Utf8 Class Initialized
INFO - 2018-08-30 01:44:26 --> URI Class Initialized
INFO - 2018-08-30 01:44:26 --> Router Class Initialized
INFO - 2018-08-30 01:44:26 --> Output Class Initialized
INFO - 2018-08-30 01:44:26 --> Security Class Initialized
DEBUG - 2018-08-30 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:44:26 --> CSRF cookie sent
INFO - 2018-08-30 01:44:26 --> Input Class Initialized
INFO - 2018-08-30 01:44:26 --> Language Class Initialized
INFO - 2018-08-30 01:44:26 --> Loader Class Initialized
INFO - 2018-08-30 01:44:26 --> Helper loaded: url_helper
INFO - 2018-08-30 01:44:26 --> Helper loaded: form_helper
INFO - 2018-08-30 01:44:26 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:44:26 --> User Agent Class Initialized
INFO - 2018-08-30 01:44:26 --> Controller Class Initialized
INFO - 2018-08-30 01:44:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:44:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:44:26 --> Pixel_Model class loaded
INFO - 2018-08-30 01:44:26 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:26 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 01:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:44:26 --> Final output sent to browser
DEBUG - 2018-08-30 01:44:26 --> Total execution time: 0.0402
INFO - 2018-08-30 01:44:38 --> Config Class Initialized
INFO - 2018-08-30 01:44:38 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:44:38 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:44:38 --> Utf8 Class Initialized
INFO - 2018-08-30 01:44:38 --> URI Class Initialized
INFO - 2018-08-30 01:44:38 --> Router Class Initialized
INFO - 2018-08-30 01:44:38 --> Output Class Initialized
INFO - 2018-08-30 01:44:38 --> Security Class Initialized
DEBUG - 2018-08-30 01:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:44:38 --> CSRF cookie sent
INFO - 2018-08-30 01:44:38 --> CSRF token verified
INFO - 2018-08-30 01:44:38 --> Input Class Initialized
INFO - 2018-08-30 01:44:38 --> Language Class Initialized
INFO - 2018-08-30 01:44:38 --> Loader Class Initialized
INFO - 2018-08-30 01:44:38 --> Helper loaded: url_helper
INFO - 2018-08-30 01:44:38 --> Helper loaded: form_helper
INFO - 2018-08-30 01:44:38 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:44:38 --> User Agent Class Initialized
INFO - 2018-08-30 01:44:38 --> Controller Class Initialized
INFO - 2018-08-30 01:44:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:44:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:44:38 --> Pixel_Model class loaded
INFO - 2018-08-30 01:44:38 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:38 --> Form Validation Class Initialized
INFO - 2018-08-30 01:44:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:44:38 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:38 --> Config Class Initialized
INFO - 2018-08-30 01:44:38 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:44:38 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:44:38 --> Utf8 Class Initialized
INFO - 2018-08-30 01:44:38 --> URI Class Initialized
INFO - 2018-08-30 01:44:38 --> Router Class Initialized
INFO - 2018-08-30 01:44:38 --> Output Class Initialized
INFO - 2018-08-30 01:44:38 --> Security Class Initialized
DEBUG - 2018-08-30 01:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:44:38 --> CSRF cookie sent
INFO - 2018-08-30 01:44:38 --> Input Class Initialized
INFO - 2018-08-30 01:44:38 --> Language Class Initialized
INFO - 2018-08-30 01:44:38 --> Loader Class Initialized
INFO - 2018-08-30 01:44:38 --> Helper loaded: url_helper
INFO - 2018-08-30 01:44:38 --> Helper loaded: form_helper
INFO - 2018-08-30 01:44:38 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:44:38 --> User Agent Class Initialized
INFO - 2018-08-30 01:44:38 --> Controller Class Initialized
INFO - 2018-08-30 01:44:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:44:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:44:38 --> Pixel_Model class loaded
INFO - 2018-08-30 01:44:38 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:38 --> Database Driver Class Initialized
INFO - 2018-08-30 01:44:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 01:44:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:44:38 --> Final output sent to browser
DEBUG - 2018-08-30 01:44:38 --> Total execution time: 0.0350
INFO - 2018-08-30 01:45:21 --> Config Class Initialized
INFO - 2018-08-30 01:45:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:45:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:45:21 --> Utf8 Class Initialized
INFO - 2018-08-30 01:45:21 --> URI Class Initialized
INFO - 2018-08-30 01:45:21 --> Router Class Initialized
INFO - 2018-08-30 01:45:21 --> Output Class Initialized
INFO - 2018-08-30 01:45:21 --> Security Class Initialized
DEBUG - 2018-08-30 01:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:45:21 --> CSRF cookie sent
INFO - 2018-08-30 01:45:21 --> CSRF token verified
INFO - 2018-08-30 01:45:21 --> Input Class Initialized
INFO - 2018-08-30 01:45:21 --> Language Class Initialized
INFO - 2018-08-30 01:45:21 --> Loader Class Initialized
INFO - 2018-08-30 01:45:21 --> Helper loaded: url_helper
INFO - 2018-08-30 01:45:21 --> Helper loaded: form_helper
INFO - 2018-08-30 01:45:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:45:21 --> User Agent Class Initialized
INFO - 2018-08-30 01:45:21 --> Controller Class Initialized
INFO - 2018-08-30 01:45:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:45:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:45:21 --> Pixel_Model class loaded
INFO - 2018-08-30 01:45:21 --> Database Driver Class Initialized
INFO - 2018-08-30 01:45:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:45:21 --> Form Validation Class Initialized
INFO - 2018-08-30 01:45:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:45:21 --> Database Driver Class Initialized
INFO - 2018-08-30 01:45:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:45:21 --> Config Class Initialized
INFO - 2018-08-30 01:45:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:45:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:45:21 --> Utf8 Class Initialized
INFO - 2018-08-30 01:45:21 --> URI Class Initialized
INFO - 2018-08-30 01:45:21 --> Router Class Initialized
INFO - 2018-08-30 01:45:21 --> Output Class Initialized
INFO - 2018-08-30 01:45:21 --> Security Class Initialized
DEBUG - 2018-08-30 01:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:45:21 --> CSRF cookie sent
INFO - 2018-08-30 01:45:21 --> Input Class Initialized
INFO - 2018-08-30 01:45:21 --> Language Class Initialized
INFO - 2018-08-30 01:45:21 --> Loader Class Initialized
INFO - 2018-08-30 01:45:21 --> Helper loaded: url_helper
INFO - 2018-08-30 01:45:21 --> Helper loaded: form_helper
INFO - 2018-08-30 01:45:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:45:21 --> User Agent Class Initialized
INFO - 2018-08-30 01:45:21 --> Controller Class Initialized
INFO - 2018-08-30 01:45:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:45:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:45:21 --> Pixel_Model class loaded
INFO - 2018-08-30 01:45:21 --> Database Driver Class Initialized
INFO - 2018-08-30 01:45:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:45:21 --> Database Driver Class Initialized
INFO - 2018-08-30 01:45:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-30 01:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:45:21 --> Final output sent to browser
DEBUG - 2018-08-30 01:45:21 --> Total execution time: 0.0457
INFO - 2018-08-30 01:46:51 --> Config Class Initialized
INFO - 2018-08-30 01:46:51 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:46:51 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:46:51 --> Utf8 Class Initialized
INFO - 2018-08-30 01:46:51 --> URI Class Initialized
INFO - 2018-08-30 01:46:51 --> Router Class Initialized
INFO - 2018-08-30 01:46:51 --> Output Class Initialized
INFO - 2018-08-30 01:46:51 --> Security Class Initialized
DEBUG - 2018-08-30 01:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:46:51 --> CSRF cookie sent
INFO - 2018-08-30 01:46:51 --> CSRF token verified
INFO - 2018-08-30 01:46:51 --> Input Class Initialized
INFO - 2018-08-30 01:46:51 --> Language Class Initialized
INFO - 2018-08-30 01:46:51 --> Loader Class Initialized
INFO - 2018-08-30 01:46:51 --> Helper loaded: url_helper
INFO - 2018-08-30 01:46:51 --> Helper loaded: form_helper
INFO - 2018-08-30 01:46:51 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:46:51 --> User Agent Class Initialized
INFO - 2018-08-30 01:46:51 --> Controller Class Initialized
INFO - 2018-08-30 01:46:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:46:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:46:51 --> Pixel_Model class loaded
INFO - 2018-08-30 01:46:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:46:51 --> Form Validation Class Initialized
INFO - 2018-08-30 01:46:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:46:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:46:51 --> Config Class Initialized
INFO - 2018-08-30 01:46:51 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:46:51 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:46:51 --> Utf8 Class Initialized
INFO - 2018-08-30 01:46:51 --> URI Class Initialized
INFO - 2018-08-30 01:46:51 --> Router Class Initialized
INFO - 2018-08-30 01:46:51 --> Output Class Initialized
INFO - 2018-08-30 01:46:51 --> Security Class Initialized
DEBUG - 2018-08-30 01:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:46:51 --> CSRF cookie sent
INFO - 2018-08-30 01:46:51 --> Input Class Initialized
INFO - 2018-08-30 01:46:51 --> Language Class Initialized
INFO - 2018-08-30 01:46:51 --> Loader Class Initialized
INFO - 2018-08-30 01:46:51 --> Helper loaded: url_helper
INFO - 2018-08-30 01:46:51 --> Helper loaded: form_helper
INFO - 2018-08-30 01:46:51 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:46:51 --> User Agent Class Initialized
INFO - 2018-08-30 01:46:51 --> Controller Class Initialized
INFO - 2018-08-30 01:46:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:46:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:46:51 --> Pixel_Model class loaded
INFO - 2018-08-30 01:46:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:46:51 --> Database Driver Class Initialized
INFO - 2018-08-30 01:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 01:46:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:46:51 --> Final output sent to browser
DEBUG - 2018-08-30 01:46:51 --> Total execution time: 0.0508
INFO - 2018-08-30 01:47:33 --> Config Class Initialized
INFO - 2018-08-30 01:47:33 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:47:33 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:47:33 --> Utf8 Class Initialized
INFO - 2018-08-30 01:47:33 --> URI Class Initialized
INFO - 2018-08-30 01:47:33 --> Router Class Initialized
INFO - 2018-08-30 01:47:33 --> Output Class Initialized
INFO - 2018-08-30 01:47:33 --> Security Class Initialized
DEBUG - 2018-08-30 01:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:47:33 --> CSRF cookie sent
INFO - 2018-08-30 01:47:33 --> CSRF token verified
INFO - 2018-08-30 01:47:33 --> Input Class Initialized
INFO - 2018-08-30 01:47:33 --> Language Class Initialized
INFO - 2018-08-30 01:47:33 --> Loader Class Initialized
INFO - 2018-08-30 01:47:33 --> Helper loaded: url_helper
INFO - 2018-08-30 01:47:33 --> Helper loaded: form_helper
INFO - 2018-08-30 01:47:33 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:47:33 --> User Agent Class Initialized
INFO - 2018-08-30 01:47:33 --> Controller Class Initialized
INFO - 2018-08-30 01:47:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:47:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:47:33 --> Pixel_Model class loaded
INFO - 2018-08-30 01:47:33 --> Database Driver Class Initialized
INFO - 2018-08-30 01:47:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:47:33 --> Form Validation Class Initialized
INFO - 2018-08-30 01:47:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:47:33 --> Database Driver Class Initialized
INFO - 2018-08-30 01:47:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:47:34 --> Config Class Initialized
INFO - 2018-08-30 01:47:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:47:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:47:34 --> Utf8 Class Initialized
INFO - 2018-08-30 01:47:34 --> URI Class Initialized
INFO - 2018-08-30 01:47:34 --> Router Class Initialized
INFO - 2018-08-30 01:47:34 --> Output Class Initialized
INFO - 2018-08-30 01:47:34 --> Security Class Initialized
DEBUG - 2018-08-30 01:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:47:34 --> CSRF cookie sent
INFO - 2018-08-30 01:47:34 --> Input Class Initialized
INFO - 2018-08-30 01:47:34 --> Language Class Initialized
INFO - 2018-08-30 01:47:34 --> Loader Class Initialized
INFO - 2018-08-30 01:47:34 --> Helper loaded: url_helper
INFO - 2018-08-30 01:47:34 --> Helper loaded: form_helper
INFO - 2018-08-30 01:47:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:47:34 --> User Agent Class Initialized
INFO - 2018-08-30 01:47:34 --> Controller Class Initialized
INFO - 2018-08-30 01:47:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:47:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:47:34 --> Pixel_Model class loaded
INFO - 2018-08-30 01:47:34 --> Database Driver Class Initialized
INFO - 2018-08-30 01:47:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:47:34 --> Database Driver Class Initialized
INFO - 2018-08-30 01:47:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 01:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:47:34 --> Final output sent to browser
DEBUG - 2018-08-30 01:47:34 --> Total execution time: 0.0422
INFO - 2018-08-30 01:49:00 --> Config Class Initialized
INFO - 2018-08-30 01:49:00 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:00 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:00 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:00 --> URI Class Initialized
INFO - 2018-08-30 01:49:00 --> Router Class Initialized
INFO - 2018-08-30 01:49:00 --> Output Class Initialized
INFO - 2018-08-30 01:49:00 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:00 --> CSRF cookie sent
INFO - 2018-08-30 01:49:00 --> Input Class Initialized
INFO - 2018-08-30 01:49:00 --> Language Class Initialized
INFO - 2018-08-30 01:49:00 --> Loader Class Initialized
INFO - 2018-08-30 01:49:00 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:00 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:00 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:00 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:00 --> Controller Class Initialized
INFO - 2018-08-30 01:49:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:00 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:00 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:00 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 01:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:49:00 --> Final output sent to browser
DEBUG - 2018-08-30 01:49:00 --> Total execution time: 0.0451
INFO - 2018-08-30 01:49:11 --> Config Class Initialized
INFO - 2018-08-30 01:49:11 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:11 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:11 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:11 --> URI Class Initialized
INFO - 2018-08-30 01:49:11 --> Router Class Initialized
INFO - 2018-08-30 01:49:11 --> Output Class Initialized
INFO - 2018-08-30 01:49:11 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:11 --> CSRF cookie sent
INFO - 2018-08-30 01:49:11 --> CSRF token verified
INFO - 2018-08-30 01:49:11 --> Input Class Initialized
INFO - 2018-08-30 01:49:11 --> Language Class Initialized
INFO - 2018-08-30 01:49:11 --> Loader Class Initialized
INFO - 2018-08-30 01:49:11 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:11 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:11 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:11 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:11 --> Controller Class Initialized
INFO - 2018-08-30 01:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:11 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:11 --> Form Validation Class Initialized
INFO - 2018-08-30 01:49:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:49:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:11 --> Config Class Initialized
INFO - 2018-08-30 01:49:11 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:11 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:11 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:11 --> URI Class Initialized
INFO - 2018-08-30 01:49:11 --> Router Class Initialized
INFO - 2018-08-30 01:49:11 --> Output Class Initialized
INFO - 2018-08-30 01:49:11 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:11 --> CSRF cookie sent
INFO - 2018-08-30 01:49:11 --> Input Class Initialized
INFO - 2018-08-30 01:49:11 --> Language Class Initialized
INFO - 2018-08-30 01:49:11 --> Loader Class Initialized
INFO - 2018-08-30 01:49:11 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:11 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:11 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:11 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:11 --> Controller Class Initialized
INFO - 2018-08-30 01:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:11 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:11 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 01:49:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:49:11 --> Final output sent to browser
DEBUG - 2018-08-30 01:49:11 --> Total execution time: 0.0486
INFO - 2018-08-30 01:49:33 --> Config Class Initialized
INFO - 2018-08-30 01:49:33 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:33 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:33 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:33 --> URI Class Initialized
INFO - 2018-08-30 01:49:33 --> Router Class Initialized
INFO - 2018-08-30 01:49:33 --> Output Class Initialized
INFO - 2018-08-30 01:49:33 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:33 --> CSRF cookie sent
INFO - 2018-08-30 01:49:33 --> Input Class Initialized
INFO - 2018-08-30 01:49:33 --> Language Class Initialized
INFO - 2018-08-30 01:49:33 --> Loader Class Initialized
INFO - 2018-08-30 01:49:33 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:33 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:33 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:33 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:33 --> Controller Class Initialized
INFO - 2018-08-30 01:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:33 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:33 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:33 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 01:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:49:33 --> Final output sent to browser
DEBUG - 2018-08-30 01:49:33 --> Total execution time: 0.0445
INFO - 2018-08-30 01:49:43 --> Config Class Initialized
INFO - 2018-08-30 01:49:43 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:43 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:43 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:43 --> URI Class Initialized
INFO - 2018-08-30 01:49:43 --> Router Class Initialized
INFO - 2018-08-30 01:49:43 --> Output Class Initialized
INFO - 2018-08-30 01:49:43 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:43 --> CSRF cookie sent
INFO - 2018-08-30 01:49:43 --> Input Class Initialized
INFO - 2018-08-30 01:49:43 --> Language Class Initialized
INFO - 2018-08-30 01:49:43 --> Loader Class Initialized
INFO - 2018-08-30 01:49:43 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:43 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:43 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:43 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:43 --> Controller Class Initialized
INFO - 2018-08-30 01:49:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:43 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:43 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:43 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-30 01:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:49:43 --> Final output sent to browser
DEBUG - 2018-08-30 01:49:43 --> Total execution time: 0.0438
INFO - 2018-08-30 01:49:54 --> Config Class Initialized
INFO - 2018-08-30 01:49:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:54 --> URI Class Initialized
INFO - 2018-08-30 01:49:54 --> Router Class Initialized
INFO - 2018-08-30 01:49:54 --> Output Class Initialized
INFO - 2018-08-30 01:49:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:54 --> CSRF cookie sent
INFO - 2018-08-30 01:49:54 --> CSRF token verified
INFO - 2018-08-30 01:49:54 --> Input Class Initialized
INFO - 2018-08-30 01:49:54 --> Language Class Initialized
INFO - 2018-08-30 01:49:54 --> Loader Class Initialized
INFO - 2018-08-30 01:49:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:54 --> Controller Class Initialized
INFO - 2018-08-30 01:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:54 --> Form Validation Class Initialized
INFO - 2018-08-30 01:49:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:49:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:54 --> Config Class Initialized
INFO - 2018-08-30 01:49:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:49:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:49:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:49:54 --> URI Class Initialized
INFO - 2018-08-30 01:49:54 --> Router Class Initialized
INFO - 2018-08-30 01:49:54 --> Output Class Initialized
INFO - 2018-08-30 01:49:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:49:54 --> CSRF cookie sent
INFO - 2018-08-30 01:49:54 --> Input Class Initialized
INFO - 2018-08-30 01:49:54 --> Language Class Initialized
INFO - 2018-08-30 01:49:54 --> Loader Class Initialized
INFO - 2018-08-30 01:49:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:49:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:49:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:49:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:49:54 --> Controller Class Initialized
INFO - 2018-08-30 01:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:49:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:49:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 01:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:49:54 --> Final output sent to browser
DEBUG - 2018-08-30 01:49:54 --> Total execution time: 0.0458
INFO - 2018-08-30 01:58:54 --> Config Class Initialized
INFO - 2018-08-30 01:58:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:58:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:58:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:58:54 --> URI Class Initialized
INFO - 2018-08-30 01:58:54 --> Router Class Initialized
INFO - 2018-08-30 01:58:54 --> Output Class Initialized
INFO - 2018-08-30 01:58:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:58:54 --> CSRF cookie sent
INFO - 2018-08-30 01:58:54 --> CSRF token verified
INFO - 2018-08-30 01:58:54 --> Input Class Initialized
INFO - 2018-08-30 01:58:54 --> Language Class Initialized
INFO - 2018-08-30 01:58:54 --> Loader Class Initialized
INFO - 2018-08-30 01:58:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:58:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:58:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:58:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:58:54 --> Controller Class Initialized
INFO - 2018-08-30 01:58:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:58:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:58:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:58:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:58:54 --> Form Validation Class Initialized
INFO - 2018-08-30 01:58:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 01:58:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:58:54 --> Config Class Initialized
INFO - 2018-08-30 01:58:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 01:58:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 01:58:54 --> Utf8 Class Initialized
INFO - 2018-08-30 01:58:54 --> URI Class Initialized
INFO - 2018-08-30 01:58:54 --> Router Class Initialized
INFO - 2018-08-30 01:58:54 --> Output Class Initialized
INFO - 2018-08-30 01:58:54 --> Security Class Initialized
DEBUG - 2018-08-30 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 01:58:54 --> CSRF cookie sent
INFO - 2018-08-30 01:58:54 --> Input Class Initialized
INFO - 2018-08-30 01:58:54 --> Language Class Initialized
INFO - 2018-08-30 01:58:54 --> Loader Class Initialized
INFO - 2018-08-30 01:58:54 --> Helper loaded: url_helper
INFO - 2018-08-30 01:58:54 --> Helper loaded: form_helper
INFO - 2018-08-30 01:58:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 01:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 01:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 01:58:54 --> User Agent Class Initialized
INFO - 2018-08-30 01:58:54 --> Controller Class Initialized
INFO - 2018-08-30 01:58:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 01:58:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 01:58:54 --> Pixel_Model class loaded
INFO - 2018-08-30 01:58:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:58:54 --> Database Driver Class Initialized
INFO - 2018-08-30 01:58:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 01:58:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 01:58:54 --> Final output sent to browser
DEBUG - 2018-08-30 01:58:54 --> Total execution time: 0.0454
INFO - 2018-08-30 02:00:20 --> Config Class Initialized
INFO - 2018-08-30 02:00:20 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:00:20 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:00:20 --> Utf8 Class Initialized
INFO - 2018-08-30 02:00:20 --> URI Class Initialized
INFO - 2018-08-30 02:00:20 --> Router Class Initialized
INFO - 2018-08-30 02:00:20 --> Output Class Initialized
INFO - 2018-08-30 02:00:20 --> Security Class Initialized
DEBUG - 2018-08-30 02:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:00:20 --> CSRF cookie sent
INFO - 2018-08-30 02:00:20 --> Input Class Initialized
INFO - 2018-08-30 02:00:20 --> Language Class Initialized
INFO - 2018-08-30 02:00:20 --> Loader Class Initialized
INFO - 2018-08-30 02:00:20 --> Helper loaded: url_helper
INFO - 2018-08-30 02:00:20 --> Helper loaded: form_helper
INFO - 2018-08-30 02:00:20 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:00:20 --> User Agent Class Initialized
INFO - 2018-08-30 02:00:20 --> Controller Class Initialized
INFO - 2018-08-30 02:00:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:00:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:00:20 --> Pixel_Model class loaded
INFO - 2018-08-30 02:00:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:00:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:00:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:00:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 02:00:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 02:00:20 --> Final output sent to browser
DEBUG - 2018-08-30 02:00:20 --> Total execution time: 0.0589
INFO - 2018-08-30 02:02:05 --> Config Class Initialized
INFO - 2018-08-30 02:02:05 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:02:05 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:02:05 --> Utf8 Class Initialized
INFO - 2018-08-30 02:02:05 --> URI Class Initialized
INFO - 2018-08-30 02:02:05 --> Router Class Initialized
INFO - 2018-08-30 02:02:05 --> Output Class Initialized
INFO - 2018-08-30 02:02:05 --> Security Class Initialized
DEBUG - 2018-08-30 02:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:02:05 --> CSRF cookie sent
INFO - 2018-08-30 02:02:05 --> CSRF token verified
INFO - 2018-08-30 02:02:05 --> Input Class Initialized
INFO - 2018-08-30 02:02:05 --> Language Class Initialized
INFO - 2018-08-30 02:02:05 --> Loader Class Initialized
INFO - 2018-08-30 02:02:05 --> Helper loaded: url_helper
INFO - 2018-08-30 02:02:05 --> Helper loaded: form_helper
INFO - 2018-08-30 02:02:05 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:02:05 --> User Agent Class Initialized
INFO - 2018-08-30 02:02:05 --> Controller Class Initialized
INFO - 2018-08-30 02:02:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:02:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:02:05 --> Pixel_Model class loaded
INFO - 2018-08-30 02:02:05 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:05 --> Form Validation Class Initialized
INFO - 2018-08-30 02:02:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 02:02:05 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:05 --> Config Class Initialized
INFO - 2018-08-30 02:02:05 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:02:05 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:02:05 --> Utf8 Class Initialized
INFO - 2018-08-30 02:02:05 --> URI Class Initialized
INFO - 2018-08-30 02:02:05 --> Router Class Initialized
INFO - 2018-08-30 02:02:05 --> Output Class Initialized
INFO - 2018-08-30 02:02:05 --> Security Class Initialized
DEBUG - 2018-08-30 02:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:02:05 --> CSRF cookie sent
INFO - 2018-08-30 02:02:05 --> Input Class Initialized
INFO - 2018-08-30 02:02:05 --> Language Class Initialized
INFO - 2018-08-30 02:02:05 --> Loader Class Initialized
INFO - 2018-08-30 02:02:05 --> Helper loaded: url_helper
INFO - 2018-08-30 02:02:05 --> Helper loaded: form_helper
INFO - 2018-08-30 02:02:05 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:02:05 --> User Agent Class Initialized
INFO - 2018-08-30 02:02:05 --> Controller Class Initialized
INFO - 2018-08-30 02:02:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:02:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:02:05 --> Pixel_Model class loaded
INFO - 2018-08-30 02:02:05 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:05 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 02:02:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 02:02:05 --> Final output sent to browser
DEBUG - 2018-08-30 02:02:05 --> Total execution time: 0.0628
INFO - 2018-08-30 02:02:19 --> Config Class Initialized
INFO - 2018-08-30 02:02:19 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:02:19 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:02:19 --> Utf8 Class Initialized
INFO - 2018-08-30 02:02:19 --> URI Class Initialized
INFO - 2018-08-30 02:02:19 --> Router Class Initialized
INFO - 2018-08-30 02:02:19 --> Output Class Initialized
INFO - 2018-08-30 02:02:19 --> Security Class Initialized
DEBUG - 2018-08-30 02:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:02:19 --> CSRF cookie sent
INFO - 2018-08-30 02:02:19 --> CSRF token verified
INFO - 2018-08-30 02:02:19 --> Input Class Initialized
INFO - 2018-08-30 02:02:19 --> Language Class Initialized
INFO - 2018-08-30 02:02:19 --> Loader Class Initialized
INFO - 2018-08-30 02:02:19 --> Helper loaded: url_helper
INFO - 2018-08-30 02:02:19 --> Helper loaded: form_helper
INFO - 2018-08-30 02:02:19 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:02:20 --> User Agent Class Initialized
INFO - 2018-08-30 02:02:20 --> Controller Class Initialized
INFO - 2018-08-30 02:02:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:02:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:02:20 --> Pixel_Model class loaded
INFO - 2018-08-30 02:02:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:20 --> Form Validation Class Initialized
INFO - 2018-08-30 02:02:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 02:02:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:20 --> Config Class Initialized
INFO - 2018-08-30 02:02:20 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:02:20 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:02:20 --> Utf8 Class Initialized
INFO - 2018-08-30 02:02:20 --> URI Class Initialized
INFO - 2018-08-30 02:02:20 --> Router Class Initialized
INFO - 2018-08-30 02:02:20 --> Output Class Initialized
INFO - 2018-08-30 02:02:20 --> Security Class Initialized
DEBUG - 2018-08-30 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:02:20 --> CSRF cookie sent
INFO - 2018-08-30 02:02:20 --> Input Class Initialized
INFO - 2018-08-30 02:02:20 --> Language Class Initialized
INFO - 2018-08-30 02:02:20 --> Loader Class Initialized
INFO - 2018-08-30 02:02:20 --> Helper loaded: url_helper
INFO - 2018-08-30 02:02:20 --> Helper loaded: form_helper
INFO - 2018-08-30 02:02:20 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:02:20 --> User Agent Class Initialized
INFO - 2018-08-30 02:02:20 --> Controller Class Initialized
INFO - 2018-08-30 02:02:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:02:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:02:20 --> Pixel_Model class loaded
INFO - 2018-08-30 02:02:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:20 --> Database Driver Class Initialized
INFO - 2018-08-30 02:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-30 02:02:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 02:02:20 --> Final output sent to browser
DEBUG - 2018-08-30 02:02:20 --> Total execution time: 0.0536
INFO - 2018-08-30 02:03:07 --> Config Class Initialized
INFO - 2018-08-30 02:03:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:03:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:03:07 --> Utf8 Class Initialized
INFO - 2018-08-30 02:03:07 --> URI Class Initialized
INFO - 2018-08-30 02:03:07 --> Router Class Initialized
INFO - 2018-08-30 02:03:07 --> Output Class Initialized
INFO - 2018-08-30 02:03:07 --> Security Class Initialized
DEBUG - 2018-08-30 02:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:03:07 --> CSRF cookie sent
INFO - 2018-08-30 02:03:07 --> CSRF token verified
INFO - 2018-08-30 02:03:07 --> Input Class Initialized
INFO - 2018-08-30 02:03:07 --> Language Class Initialized
INFO - 2018-08-30 02:03:07 --> Loader Class Initialized
INFO - 2018-08-30 02:03:07 --> Helper loaded: url_helper
INFO - 2018-08-30 02:03:07 --> Helper loaded: form_helper
INFO - 2018-08-30 02:03:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:03:07 --> User Agent Class Initialized
INFO - 2018-08-30 02:03:07 --> Controller Class Initialized
INFO - 2018-08-30 02:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:03:07 --> Pixel_Model class loaded
INFO - 2018-08-30 02:03:07 --> Database Driver Class Initialized
INFO - 2018-08-30 02:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:03:07 --> Form Validation Class Initialized
INFO - 2018-08-30 02:03:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 02:03:07 --> Database Driver Class Initialized
INFO - 2018-08-30 02:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:03:07 --> Config Class Initialized
INFO - 2018-08-30 02:03:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 02:03:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 02:03:07 --> Utf8 Class Initialized
INFO - 2018-08-30 02:03:07 --> URI Class Initialized
INFO - 2018-08-30 02:03:07 --> Router Class Initialized
INFO - 2018-08-30 02:03:07 --> Output Class Initialized
INFO - 2018-08-30 02:03:07 --> Security Class Initialized
DEBUG - 2018-08-30 02:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 02:03:07 --> CSRF cookie sent
INFO - 2018-08-30 02:03:07 --> Input Class Initialized
INFO - 2018-08-30 02:03:07 --> Language Class Initialized
INFO - 2018-08-30 02:03:07 --> Loader Class Initialized
INFO - 2018-08-30 02:03:07 --> Helper loaded: url_helper
INFO - 2018-08-30 02:03:07 --> Helper loaded: form_helper
INFO - 2018-08-30 02:03:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 02:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 02:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 02:03:07 --> User Agent Class Initialized
INFO - 2018-08-30 02:03:07 --> Controller Class Initialized
INFO - 2018-08-30 02:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 02:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 02:03:07 --> Pixel_Model class loaded
INFO - 2018-08-30 02:03:07 --> Database Driver Class Initialized
INFO - 2018-08-30 02:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:03:07 --> Database Driver Class Initialized
INFO - 2018-08-30 02:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-30 02:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 02:03:07 --> Final output sent to browser
DEBUG - 2018-08-30 02:03:07 --> Total execution time: 0.0466
INFO - 2018-08-30 11:56:06 --> Config Class Initialized
INFO - 2018-08-30 11:56:06 --> Hooks Class Initialized
DEBUG - 2018-08-30 11:56:06 --> UTF-8 Support Enabled
INFO - 2018-08-30 11:56:06 --> Utf8 Class Initialized
INFO - 2018-08-30 11:56:06 --> URI Class Initialized
DEBUG - 2018-08-30 11:56:06 --> No URI present. Default controller set.
INFO - 2018-08-30 11:56:06 --> Router Class Initialized
INFO - 2018-08-30 11:56:06 --> Output Class Initialized
INFO - 2018-08-30 11:56:06 --> Security Class Initialized
DEBUG - 2018-08-30 11:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 11:56:06 --> CSRF cookie sent
INFO - 2018-08-30 11:56:06 --> Input Class Initialized
INFO - 2018-08-30 11:56:06 --> Language Class Initialized
INFO - 2018-08-30 11:56:06 --> Loader Class Initialized
INFO - 2018-08-30 11:56:06 --> Helper loaded: url_helper
INFO - 2018-08-30 11:56:06 --> Helper loaded: form_helper
INFO - 2018-08-30 11:56:06 --> Helper loaded: language_helper
DEBUG - 2018-08-30 11:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 11:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 11:56:06 --> User Agent Class Initialized
INFO - 2018-08-30 11:56:06 --> Controller Class Initialized
INFO - 2018-08-30 11:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 11:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 11:56:06 --> Pixel_Model class loaded
INFO - 2018-08-30 11:56:06 --> Database Driver Class Initialized
INFO - 2018-08-30 11:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 11:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 11:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 11:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 11:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 11:56:06 --> Final output sent to browser
DEBUG - 2018-08-30 11:56:06 --> Total execution time: 0.0366
INFO - 2018-08-30 11:57:44 --> Config Class Initialized
INFO - 2018-08-30 11:57:44 --> Hooks Class Initialized
DEBUG - 2018-08-30 11:57:44 --> UTF-8 Support Enabled
INFO - 2018-08-30 11:57:44 --> Utf8 Class Initialized
INFO - 2018-08-30 11:57:44 --> URI Class Initialized
DEBUG - 2018-08-30 11:57:44 --> No URI present. Default controller set.
INFO - 2018-08-30 11:57:44 --> Router Class Initialized
INFO - 2018-08-30 11:57:44 --> Output Class Initialized
INFO - 2018-08-30 11:57:44 --> Security Class Initialized
DEBUG - 2018-08-30 11:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 11:57:44 --> CSRF cookie sent
INFO - 2018-08-30 11:57:44 --> Input Class Initialized
INFO - 2018-08-30 11:57:44 --> Language Class Initialized
INFO - 2018-08-30 11:57:44 --> Loader Class Initialized
INFO - 2018-08-30 11:57:44 --> Helper loaded: url_helper
INFO - 2018-08-30 11:57:44 --> Helper loaded: form_helper
INFO - 2018-08-30 11:57:44 --> Helper loaded: language_helper
DEBUG - 2018-08-30 11:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 11:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 11:57:44 --> User Agent Class Initialized
INFO - 2018-08-30 11:57:44 --> Controller Class Initialized
INFO - 2018-08-30 11:57:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 11:57:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 11:57:44 --> Pixel_Model class loaded
INFO - 2018-08-30 11:57:44 --> Database Driver Class Initialized
INFO - 2018-08-30 11:57:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 11:57:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 11:57:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 11:57:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 11:57:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 11:57:44 --> Final output sent to browser
DEBUG - 2018-08-30 11:57:44 --> Total execution time: 0.0428
INFO - 2018-08-30 11:57:48 --> Config Class Initialized
INFO - 2018-08-30 11:57:48 --> Hooks Class Initialized
DEBUG - 2018-08-30 11:57:48 --> UTF-8 Support Enabled
INFO - 2018-08-30 11:57:48 --> Utf8 Class Initialized
INFO - 2018-08-30 11:57:48 --> URI Class Initialized
INFO - 2018-08-30 11:57:48 --> Router Class Initialized
INFO - 2018-08-30 11:57:48 --> Output Class Initialized
INFO - 2018-08-30 11:57:48 --> Security Class Initialized
DEBUG - 2018-08-30 11:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 11:57:48 --> CSRF cookie sent
INFO - 2018-08-30 11:57:48 --> Input Class Initialized
INFO - 2018-08-30 11:57:48 --> Language Class Initialized
INFO - 2018-08-30 11:57:48 --> Loader Class Initialized
INFO - 2018-08-30 11:57:48 --> Helper loaded: url_helper
INFO - 2018-08-30 11:57:48 --> Helper loaded: form_helper
INFO - 2018-08-30 11:57:48 --> Helper loaded: language_helper
DEBUG - 2018-08-30 11:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 11:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 11:57:48 --> User Agent Class Initialized
INFO - 2018-08-30 11:57:48 --> Controller Class Initialized
INFO - 2018-08-30 11:57:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 11:57:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 11:57:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 11:57:48 --> Could not find the language line "req_email"
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 11:57:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 11:57:48 --> Final output sent to browser
DEBUG - 2018-08-30 11:57:48 --> Total execution time: 0.0241
INFO - 2018-08-30 11:57:52 --> Config Class Initialized
INFO - 2018-08-30 11:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-30 11:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-30 11:57:52 --> Utf8 Class Initialized
INFO - 2018-08-30 11:57:52 --> URI Class Initialized
DEBUG - 2018-08-30 11:57:52 --> No URI present. Default controller set.
INFO - 2018-08-30 11:57:52 --> Router Class Initialized
INFO - 2018-08-30 11:57:52 --> Output Class Initialized
INFO - 2018-08-30 11:57:52 --> Security Class Initialized
DEBUG - 2018-08-30 11:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 11:57:52 --> CSRF cookie sent
INFO - 2018-08-30 11:57:52 --> Input Class Initialized
INFO - 2018-08-30 11:57:52 --> Language Class Initialized
INFO - 2018-08-30 11:57:52 --> Loader Class Initialized
INFO - 2018-08-30 11:57:52 --> Helper loaded: url_helper
INFO - 2018-08-30 11:57:52 --> Helper loaded: form_helper
INFO - 2018-08-30 11:57:52 --> Helper loaded: language_helper
DEBUG - 2018-08-30 11:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 11:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 11:57:52 --> User Agent Class Initialized
INFO - 2018-08-30 11:57:52 --> Controller Class Initialized
INFO - 2018-08-30 11:57:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 11:57:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 11:57:52 --> Pixel_Model class loaded
INFO - 2018-08-30 11:57:52 --> Database Driver Class Initialized
INFO - 2018-08-30 11:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 11:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 11:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 11:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 11:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 11:57:52 --> Final output sent to browser
DEBUG - 2018-08-30 11:57:52 --> Total execution time: 0.0431
INFO - 2018-08-30 12:01:32 --> Config Class Initialized
INFO - 2018-08-30 12:01:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:01:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:01:32 --> Utf8 Class Initialized
INFO - 2018-08-30 12:01:32 --> URI Class Initialized
INFO - 2018-08-30 12:01:32 --> Router Class Initialized
INFO - 2018-08-30 12:01:32 --> Output Class Initialized
INFO - 2018-08-30 12:01:32 --> Security Class Initialized
DEBUG - 2018-08-30 12:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:01:32 --> CSRF cookie sent
INFO - 2018-08-30 12:01:32 --> Input Class Initialized
INFO - 2018-08-30 12:01:32 --> Language Class Initialized
INFO - 2018-08-30 12:01:32 --> Loader Class Initialized
INFO - 2018-08-30 12:01:32 --> Helper loaded: url_helper
INFO - 2018-08-30 12:01:32 --> Helper loaded: form_helper
INFO - 2018-08-30 12:01:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:01:32 --> User Agent Class Initialized
INFO - 2018-08-30 12:01:32 --> Controller Class Initialized
INFO - 2018-08-30 12:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:01:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:01:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:01:32 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:01:32 --> Final output sent to browser
DEBUG - 2018-08-30 12:01:32 --> Total execution time: 0.0347
INFO - 2018-08-30 12:01:41 --> Config Class Initialized
INFO - 2018-08-30 12:01:41 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:01:41 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:01:41 --> Utf8 Class Initialized
INFO - 2018-08-30 12:01:41 --> URI Class Initialized
INFO - 2018-08-30 12:01:41 --> Router Class Initialized
INFO - 2018-08-30 12:01:41 --> Output Class Initialized
INFO - 2018-08-30 12:01:41 --> Security Class Initialized
DEBUG - 2018-08-30 12:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:01:41 --> CSRF cookie sent
INFO - 2018-08-30 12:01:41 --> Input Class Initialized
INFO - 2018-08-30 12:01:41 --> Language Class Initialized
INFO - 2018-08-30 12:01:41 --> Loader Class Initialized
INFO - 2018-08-30 12:01:41 --> Helper loaded: url_helper
INFO - 2018-08-30 12:01:41 --> Helper loaded: form_helper
INFO - 2018-08-30 12:01:41 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:01:41 --> User Agent Class Initialized
INFO - 2018-08-30 12:01:41 --> Controller Class Initialized
INFO - 2018-08-30 12:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:01:41 --> Pixel_Model class loaded
INFO - 2018-08-30 12:01:41 --> Database Driver Class Initialized
INFO - 2018-08-30 12:01:41 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-30 12:01:41 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:01:41 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-30 12:01:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:01:41 --> Final output sent to browser
DEBUG - 2018-08-30 12:01:41 --> Total execution time: 0.0546
INFO - 2018-08-30 12:02:07 --> Config Class Initialized
INFO - 2018-08-30 12:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:07 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:07 --> URI Class Initialized
INFO - 2018-08-30 12:02:07 --> Router Class Initialized
INFO - 2018-08-30 12:02:07 --> Output Class Initialized
INFO - 2018-08-30 12:02:07 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:07 --> CSRF cookie sent
INFO - 2018-08-30 12:02:07 --> CSRF token verified
INFO - 2018-08-30 12:02:07 --> Input Class Initialized
INFO - 2018-08-30 12:02:07 --> Language Class Initialized
INFO - 2018-08-30 12:02:07 --> Loader Class Initialized
INFO - 2018-08-30 12:02:07 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:07 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:07 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:07 --> Controller Class Initialized
INFO - 2018-08-30 12:02:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:02:07 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:07 --> Form Validation Class Initialized
INFO - 2018-08-30 12:02:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:02:07 --> Pixel_Model class loaded
INFO - 2018-08-30 12:02:07 --> Database Driver Class Initialized
INFO - 2018-08-30 12:02:07 --> Model "RegistrationModel" initialized
INFO - 2018-08-30 12:02:07 --> Config Class Initialized
INFO - 2018-08-30 12:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:07 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:07 --> URI Class Initialized
INFO - 2018-08-30 12:02:07 --> Router Class Initialized
INFO - 2018-08-30 12:02:07 --> Output Class Initialized
INFO - 2018-08-30 12:02:07 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:07 --> CSRF cookie sent
INFO - 2018-08-30 12:02:07 --> Input Class Initialized
INFO - 2018-08-30 12:02:07 --> Language Class Initialized
INFO - 2018-08-30 12:02:07 --> Loader Class Initialized
INFO - 2018-08-30 12:02:07 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:07 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:07 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:07 --> Controller Class Initialized
INFO - 2018-08-30 12:02:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:02:07 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-08-30 12:02:07 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-08-30 12:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:02:07 --> Final output sent to browser
DEBUG - 2018-08-30 12:02:07 --> Total execution time: 0.0318
INFO - 2018-08-30 12:02:21 --> Config Class Initialized
INFO - 2018-08-30 12:02:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:21 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:21 --> URI Class Initialized
INFO - 2018-08-30 12:02:21 --> Router Class Initialized
INFO - 2018-08-30 12:02:21 --> Output Class Initialized
INFO - 2018-08-30 12:02:21 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:21 --> CSRF cookie sent
INFO - 2018-08-30 12:02:21 --> CSRF token verified
INFO - 2018-08-30 12:02:21 --> Input Class Initialized
INFO - 2018-08-30 12:02:21 --> Language Class Initialized
INFO - 2018-08-30 12:02:21 --> Loader Class Initialized
INFO - 2018-08-30 12:02:21 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:21 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:21 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:21 --> Controller Class Initialized
INFO - 2018-08-30 12:02:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:02:21 --> Form Validation Class Initialized
INFO - 2018-08-30 12:02:21 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-30 12:02:21 --> Pixel_Model class loaded
INFO - 2018-08-30 12:02:21 --> Database Driver Class Initialized
INFO - 2018-08-30 12:02:21 --> Model "AuthenticationModel" initialized
INFO - 2018-08-30 12:02:21 --> Config Class Initialized
INFO - 2018-08-30 12:02:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:21 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:21 --> URI Class Initialized
INFO - 2018-08-30 12:02:21 --> Router Class Initialized
INFO - 2018-08-30 12:02:21 --> Output Class Initialized
INFO - 2018-08-30 12:02:21 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:21 --> CSRF cookie sent
INFO - 2018-08-30 12:02:21 --> Input Class Initialized
INFO - 2018-08-30 12:02:21 --> Language Class Initialized
INFO - 2018-08-30 12:02:21 --> Loader Class Initialized
INFO - 2018-08-30 12:02:21 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:21 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:21 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:21 --> Controller Class Initialized
INFO - 2018-08-30 12:02:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:02:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-08-30 12:02:21 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-08-30 12:02:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:02:21 --> Final output sent to browser
DEBUG - 2018-08-30 12:02:21 --> Total execution time: 0.0228
INFO - 2018-08-30 12:02:30 --> Config Class Initialized
INFO - 2018-08-30 12:02:30 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:30 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:30 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:30 --> URI Class Initialized
INFO - 2018-08-30 12:02:30 --> Router Class Initialized
INFO - 2018-08-30 12:02:30 --> Output Class Initialized
INFO - 2018-08-30 12:02:30 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:30 --> CSRF cookie sent
INFO - 2018-08-30 12:02:30 --> Input Class Initialized
INFO - 2018-08-30 12:02:30 --> Language Class Initialized
INFO - 2018-08-30 12:02:30 --> Loader Class Initialized
INFO - 2018-08-30 12:02:30 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:30 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:30 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:30 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:30 --> Controller Class Initialized
INFO - 2018-08-30 12:02:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:02:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:02:30 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:02:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:02:30 --> Final output sent to browser
DEBUG - 2018-08-30 12:02:30 --> Total execution time: 0.0301
INFO - 2018-08-30 12:02:36 --> Config Class Initialized
INFO - 2018-08-30 12:02:36 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:36 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:36 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:36 --> URI Class Initialized
INFO - 2018-08-30 12:02:36 --> Router Class Initialized
INFO - 2018-08-30 12:02:36 --> Output Class Initialized
INFO - 2018-08-30 12:02:36 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:36 --> CSRF cookie sent
INFO - 2018-08-30 12:02:36 --> Input Class Initialized
INFO - 2018-08-30 12:02:36 --> Language Class Initialized
INFO - 2018-08-30 12:02:36 --> Loader Class Initialized
INFO - 2018-08-30 12:02:36 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:36 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:36 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:36 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:36 --> Controller Class Initialized
INFO - 2018-08-30 12:02:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:02:36 --> Pixel_Model class loaded
INFO - 2018-08-30 12:02:36 --> Database Driver Class Initialized
INFO - 2018-08-30 12:02:36 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-30 12:02:36 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:02:36 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-30 12:02:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:02:36 --> Final output sent to browser
DEBUG - 2018-08-30 12:02:36 --> Total execution time: 0.0572
INFO - 2018-08-30 12:02:53 --> Config Class Initialized
INFO - 2018-08-30 12:02:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:02:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:02:53 --> Utf8 Class Initialized
INFO - 2018-08-30 12:02:53 --> URI Class Initialized
INFO - 2018-08-30 12:02:53 --> Router Class Initialized
INFO - 2018-08-30 12:02:53 --> Output Class Initialized
INFO - 2018-08-30 12:02:53 --> Security Class Initialized
DEBUG - 2018-08-30 12:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:02:53 --> CSRF cookie sent
INFO - 2018-08-30 12:02:53 --> CSRF token verified
INFO - 2018-08-30 12:02:53 --> Input Class Initialized
INFO - 2018-08-30 12:02:53 --> Language Class Initialized
INFO - 2018-08-30 12:02:53 --> Loader Class Initialized
INFO - 2018-08-30 12:02:53 --> Helper loaded: url_helper
INFO - 2018-08-30 12:02:53 --> Helper loaded: form_helper
INFO - 2018-08-30 12:02:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:02:53 --> User Agent Class Initialized
INFO - 2018-08-30 12:02:53 --> Controller Class Initialized
INFO - 2018-08-30 12:02:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:02:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:02:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:02:54 --> Form Validation Class Initialized
INFO - 2018-08-30 12:02:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:02:54 --> Pixel_Model class loaded
INFO - 2018-08-30 12:02:54 --> Database Driver Class Initialized
INFO - 2018-08-30 12:02:54 --> Model "RegistrationModel" initialized
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-08-30 12:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:02:54 --> Final output sent to browser
DEBUG - 2018-08-30 12:02:54 --> Total execution time: 0.1916
INFO - 2018-08-30 12:03:10 --> Config Class Initialized
INFO - 2018-08-30 12:03:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:03:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:03:10 --> Utf8 Class Initialized
INFO - 2018-08-30 12:03:10 --> URI Class Initialized
INFO - 2018-08-30 12:03:10 --> Router Class Initialized
INFO - 2018-08-30 12:03:10 --> Output Class Initialized
INFO - 2018-08-30 12:03:10 --> Security Class Initialized
DEBUG - 2018-08-30 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:03:10 --> CSRF cookie sent
INFO - 2018-08-30 12:03:10 --> CSRF token verified
INFO - 2018-08-30 12:03:10 --> Input Class Initialized
INFO - 2018-08-30 12:03:10 --> Language Class Initialized
INFO - 2018-08-30 12:03:10 --> Loader Class Initialized
INFO - 2018-08-30 12:03:10 --> Helper loaded: url_helper
INFO - 2018-08-30 12:03:10 --> Helper loaded: form_helper
INFO - 2018-08-30 12:03:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:03:10 --> User Agent Class Initialized
INFO - 2018-08-30 12:03:10 --> Controller Class Initialized
INFO - 2018-08-30 12:03:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:03:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:03:10 --> Pixel_Model class loaded
INFO - 2018-08-30 12:03:10 --> Database Driver Class Initialized
INFO - 2018-08-30 12:03:10 --> Model "RegistrationModel" initialized
INFO - 2018-08-30 12:03:10 --> Helper loaded: string_helper
INFO - 2018-08-30 12:03:10 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-08-30 12:03:11 --> Email Class Initialized
INFO - 2018-08-30 12:03:11 --> Language file loaded: language/english/email_lang.php
INFO - 2018-08-30 12:03:11 --> Config Class Initialized
INFO - 2018-08-30 12:03:11 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:03:11 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:03:11 --> Utf8 Class Initialized
INFO - 2018-08-30 12:03:11 --> URI Class Initialized
INFO - 2018-08-30 12:03:11 --> Router Class Initialized
INFO - 2018-08-30 12:03:11 --> Output Class Initialized
INFO - 2018-08-30 12:03:11 --> Security Class Initialized
DEBUG - 2018-08-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:03:11 --> CSRF cookie sent
INFO - 2018-08-30 12:03:11 --> Input Class Initialized
INFO - 2018-08-30 12:03:11 --> Language Class Initialized
INFO - 2018-08-30 12:03:11 --> Loader Class Initialized
INFO - 2018-08-30 12:03:11 --> Helper loaded: url_helper
INFO - 2018-08-30 12:03:11 --> Helper loaded: form_helper
INFO - 2018-08-30 12:03:11 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:03:11 --> User Agent Class Initialized
INFO - 2018-08-30 12:03:11 --> Controller Class Initialized
INFO - 2018-08-30 12:03:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:03:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:03:11 --> Config Class Initialized
INFO - 2018-08-30 12:03:11 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:03:11 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:03:11 --> Utf8 Class Initialized
INFO - 2018-08-30 12:03:11 --> URI Class Initialized
INFO - 2018-08-30 12:03:11 --> Router Class Initialized
INFO - 2018-08-30 12:03:11 --> Output Class Initialized
INFO - 2018-08-30 12:03:11 --> Security Class Initialized
DEBUG - 2018-08-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:03:11 --> CSRF cookie sent
INFO - 2018-08-30 12:03:11 --> Input Class Initialized
INFO - 2018-08-30 12:03:11 --> Language Class Initialized
INFO - 2018-08-30 12:03:11 --> Loader Class Initialized
INFO - 2018-08-30 12:03:11 --> Helper loaded: url_helper
INFO - 2018-08-30 12:03:11 --> Helper loaded: form_helper
INFO - 2018-08-30 12:03:11 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:03:11 --> User Agent Class Initialized
INFO - 2018-08-30 12:03:11 --> Controller Class Initialized
INFO - 2018-08-30 12:03:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:03:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:03:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:03:11 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:03:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:03:11 --> Final output sent to browser
DEBUG - 2018-08-30 12:03:11 --> Total execution time: 0.0193
INFO - 2018-08-30 12:04:24 --> Config Class Initialized
INFO - 2018-08-30 12:04:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:24 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:24 --> URI Class Initialized
INFO - 2018-08-30 12:04:24 --> Router Class Initialized
INFO - 2018-08-30 12:04:24 --> Output Class Initialized
INFO - 2018-08-30 12:04:24 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:24 --> CSRF cookie sent
INFO - 2018-08-30 12:04:24 --> Input Class Initialized
INFO - 2018-08-30 12:04:24 --> Language Class Initialized
INFO - 2018-08-30 12:04:24 --> Loader Class Initialized
INFO - 2018-08-30 12:04:24 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:24 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:24 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:24 --> Controller Class Initialized
INFO - 2018-08-30 12:04:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:24 --> Config Class Initialized
INFO - 2018-08-30 12:04:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:24 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:24 --> URI Class Initialized
INFO - 2018-08-30 12:04:24 --> Router Class Initialized
INFO - 2018-08-30 12:04:24 --> Output Class Initialized
INFO - 2018-08-30 12:04:24 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:24 --> CSRF cookie sent
INFO - 2018-08-30 12:04:24 --> Input Class Initialized
INFO - 2018-08-30 12:04:24 --> Language Class Initialized
INFO - 2018-08-30 12:04:24 --> Loader Class Initialized
INFO - 2018-08-30 12:04:24 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:24 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:24 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:24 --> Controller Class Initialized
INFO - 2018-08-30 12:04:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:04:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:04:24 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:04:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:24 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:24 --> Total execution time: 0.0252
INFO - 2018-08-30 12:04:27 --> Config Class Initialized
INFO - 2018-08-30 12:04:27 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:27 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:27 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:27 --> URI Class Initialized
INFO - 2018-08-30 12:04:27 --> Router Class Initialized
INFO - 2018-08-30 12:04:27 --> Output Class Initialized
INFO - 2018-08-30 12:04:27 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:27 --> CSRF cookie sent
INFO - 2018-08-30 12:04:27 --> Input Class Initialized
INFO - 2018-08-30 12:04:27 --> Language Class Initialized
INFO - 2018-08-30 12:04:27 --> Loader Class Initialized
INFO - 2018-08-30 12:04:27 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:27 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:27 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:27 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:27 --> Controller Class Initialized
INFO - 2018-08-30 12:04:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:27 --> Config Class Initialized
INFO - 2018-08-30 12:04:27 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:27 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:27 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:27 --> URI Class Initialized
INFO - 2018-08-30 12:04:27 --> Router Class Initialized
INFO - 2018-08-30 12:04:27 --> Output Class Initialized
INFO - 2018-08-30 12:04:27 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:27 --> CSRF cookie sent
INFO - 2018-08-30 12:04:27 --> Input Class Initialized
INFO - 2018-08-30 12:04:27 --> Language Class Initialized
INFO - 2018-08-30 12:04:27 --> Loader Class Initialized
INFO - 2018-08-30 12:04:27 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:27 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:27 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:27 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:27 --> Controller Class Initialized
INFO - 2018-08-30 12:04:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:04:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:04:27 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:04:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:27 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:27 --> Total execution time: 0.0204
INFO - 2018-08-30 12:04:32 --> Config Class Initialized
INFO - 2018-08-30 12:04:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:32 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:32 --> URI Class Initialized
INFO - 2018-08-30 12:04:32 --> Router Class Initialized
INFO - 2018-08-30 12:04:32 --> Output Class Initialized
INFO - 2018-08-30 12:04:32 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:32 --> CSRF cookie sent
INFO - 2018-08-30 12:04:32 --> Input Class Initialized
INFO - 2018-08-30 12:04:32 --> Language Class Initialized
INFO - 2018-08-30 12:04:32 --> Loader Class Initialized
INFO - 2018-08-30 12:04:32 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:32 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:32 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:32 --> Controller Class Initialized
INFO - 2018-08-30 12:04:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:32 --> Config Class Initialized
INFO - 2018-08-30 12:04:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:32 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:32 --> URI Class Initialized
INFO - 2018-08-30 12:04:32 --> Router Class Initialized
INFO - 2018-08-30 12:04:32 --> Output Class Initialized
INFO - 2018-08-30 12:04:32 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:32 --> CSRF cookie sent
INFO - 2018-08-30 12:04:32 --> Input Class Initialized
INFO - 2018-08-30 12:04:32 --> Language Class Initialized
INFO - 2018-08-30 12:04:32 --> Loader Class Initialized
INFO - 2018-08-30 12:04:32 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:32 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:32 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:32 --> Controller Class Initialized
INFO - 2018-08-30 12:04:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:04:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:04:32 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:32 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:32 --> Total execution time: 0.0231
INFO - 2018-08-30 12:04:35 --> Config Class Initialized
INFO - 2018-08-30 12:04:35 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:35 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:35 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:35 --> URI Class Initialized
INFO - 2018-08-30 12:04:35 --> Router Class Initialized
INFO - 2018-08-30 12:04:35 --> Output Class Initialized
INFO - 2018-08-30 12:04:35 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:35 --> CSRF cookie sent
INFO - 2018-08-30 12:04:35 --> Input Class Initialized
INFO - 2018-08-30 12:04:35 --> Language Class Initialized
INFO - 2018-08-30 12:04:35 --> Loader Class Initialized
INFO - 2018-08-30 12:04:35 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:35 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:35 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:35 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:36 --> Controller Class Initialized
INFO - 2018-08-30 12:04:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:36 --> CSRF cookie sent
INFO - 2018-08-30 12:04:36 --> Config Class Initialized
INFO - 2018-08-30 12:04:36 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:36 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:36 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:36 --> URI Class Initialized
DEBUG - 2018-08-30 12:04:36 --> No URI present. Default controller set.
INFO - 2018-08-30 12:04:36 --> Router Class Initialized
INFO - 2018-08-30 12:04:36 --> Output Class Initialized
INFO - 2018-08-30 12:04:36 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:36 --> CSRF cookie sent
INFO - 2018-08-30 12:04:36 --> Input Class Initialized
INFO - 2018-08-30 12:04:36 --> Language Class Initialized
INFO - 2018-08-30 12:04:36 --> Loader Class Initialized
INFO - 2018-08-30 12:04:36 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:36 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:36 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:36 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:36 --> Controller Class Initialized
INFO - 2018-08-30 12:04:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:36 --> Pixel_Model class loaded
INFO - 2018-08-30 12:04:36 --> Database Driver Class Initialized
INFO - 2018-08-30 12:04:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:04:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 12:04:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:36 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:36 --> Total execution time: 0.0415
INFO - 2018-08-30 12:04:40 --> Config Class Initialized
INFO - 2018-08-30 12:04:40 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:40 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:40 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:40 --> URI Class Initialized
INFO - 2018-08-30 12:04:40 --> Router Class Initialized
INFO - 2018-08-30 12:04:40 --> Output Class Initialized
INFO - 2018-08-30 12:04:40 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:40 --> CSRF cookie sent
INFO - 2018-08-30 12:04:40 --> Input Class Initialized
INFO - 2018-08-30 12:04:40 --> Language Class Initialized
INFO - 2018-08-30 12:04:40 --> Loader Class Initialized
INFO - 2018-08-30 12:04:40 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:40 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:40 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:40 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:40 --> Controller Class Initialized
INFO - 2018-08-30 12:04:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 12:04:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:04:40 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 12:04:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:40 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:40 --> Total execution time: 0.0286
INFO - 2018-08-30 12:04:42 --> Config Class Initialized
INFO - 2018-08-30 12:04:42 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:04:42 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:04:42 --> Utf8 Class Initialized
INFO - 2018-08-30 12:04:42 --> URI Class Initialized
INFO - 2018-08-30 12:04:42 --> Router Class Initialized
INFO - 2018-08-30 12:04:42 --> Output Class Initialized
INFO - 2018-08-30 12:04:42 --> Security Class Initialized
DEBUG - 2018-08-30 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:04:42 --> CSRF cookie sent
INFO - 2018-08-30 12:04:42 --> Input Class Initialized
INFO - 2018-08-30 12:04:42 --> Language Class Initialized
INFO - 2018-08-30 12:04:42 --> Loader Class Initialized
INFO - 2018-08-30 12:04:42 --> Helper loaded: url_helper
INFO - 2018-08-30 12:04:42 --> Helper loaded: form_helper
INFO - 2018-08-30 12:04:42 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:04:42 --> User Agent Class Initialized
INFO - 2018-08-30 12:04:42 --> Controller Class Initialized
INFO - 2018-08-30 12:04:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:04:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:04:42 --> Pixel_Model class loaded
INFO - 2018-08-30 12:04:42 --> Database Driver Class Initialized
INFO - 2018-08-30 12:04:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-30 12:04:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:04:42 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-30 12:04:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:04:42 --> Final output sent to browser
DEBUG - 2018-08-30 12:04:42 --> Total execution time: 0.0367
INFO - 2018-08-30 12:06:39 --> Config Class Initialized
INFO - 2018-08-30 12:06:39 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:06:39 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:06:39 --> Utf8 Class Initialized
INFO - 2018-08-30 12:06:39 --> URI Class Initialized
DEBUG - 2018-08-30 12:06:39 --> No URI present. Default controller set.
INFO - 2018-08-30 12:06:39 --> Router Class Initialized
INFO - 2018-08-30 12:06:39 --> Output Class Initialized
INFO - 2018-08-30 12:06:39 --> Security Class Initialized
DEBUG - 2018-08-30 12:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:06:39 --> CSRF cookie sent
INFO - 2018-08-30 12:06:39 --> Input Class Initialized
INFO - 2018-08-30 12:06:39 --> Language Class Initialized
INFO - 2018-08-30 12:06:39 --> Loader Class Initialized
INFO - 2018-08-30 12:06:39 --> Helper loaded: url_helper
INFO - 2018-08-30 12:06:39 --> Helper loaded: form_helper
INFO - 2018-08-30 12:06:39 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:06:39 --> User Agent Class Initialized
INFO - 2018-08-30 12:06:39 --> Controller Class Initialized
INFO - 2018-08-30 12:06:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:06:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:06:39 --> Pixel_Model class loaded
INFO - 2018-08-30 12:06:39 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:06:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:06:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 12:06:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:06:39 --> Final output sent to browser
DEBUG - 2018-08-30 12:06:39 --> Total execution time: 0.0379
INFO - 2018-08-30 12:06:43 --> Config Class Initialized
INFO - 2018-08-30 12:06:43 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:06:43 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:06:43 --> Utf8 Class Initialized
INFO - 2018-08-30 12:06:43 --> URI Class Initialized
INFO - 2018-08-30 12:06:43 --> Router Class Initialized
INFO - 2018-08-30 12:06:43 --> Output Class Initialized
INFO - 2018-08-30 12:06:43 --> Security Class Initialized
DEBUG - 2018-08-30 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:06:43 --> CSRF cookie sent
INFO - 2018-08-30 12:06:43 --> CSRF token verified
INFO - 2018-08-30 12:06:43 --> Input Class Initialized
INFO - 2018-08-30 12:06:43 --> Language Class Initialized
INFO - 2018-08-30 12:06:43 --> Loader Class Initialized
INFO - 2018-08-30 12:06:43 --> Helper loaded: url_helper
INFO - 2018-08-30 12:06:43 --> Helper loaded: form_helper
INFO - 2018-08-30 12:06:43 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:06:43 --> User Agent Class Initialized
INFO - 2018-08-30 12:06:43 --> Controller Class Initialized
INFO - 2018-08-30 12:06:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:06:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:06:43 --> Pixel_Model class loaded
INFO - 2018-08-30 12:06:43 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:43 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:43 --> Config Class Initialized
INFO - 2018-08-30 12:06:43 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:06:43 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:06:43 --> Utf8 Class Initialized
INFO - 2018-08-30 12:06:43 --> URI Class Initialized
INFO - 2018-08-30 12:06:43 --> Router Class Initialized
INFO - 2018-08-30 12:06:43 --> Output Class Initialized
INFO - 2018-08-30 12:06:43 --> Security Class Initialized
DEBUG - 2018-08-30 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:06:43 --> CSRF cookie sent
INFO - 2018-08-30 12:06:43 --> Input Class Initialized
INFO - 2018-08-30 12:06:43 --> Language Class Initialized
INFO - 2018-08-30 12:06:43 --> Loader Class Initialized
INFO - 2018-08-30 12:06:43 --> Helper loaded: url_helper
INFO - 2018-08-30 12:06:43 --> Helper loaded: form_helper
INFO - 2018-08-30 12:06:43 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:06:43 --> User Agent Class Initialized
INFO - 2018-08-30 12:06:43 --> Controller Class Initialized
INFO - 2018-08-30 12:06:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:06:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:06:43 --> Pixel_Model class loaded
INFO - 2018-08-30 12:06:43 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:43 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 12:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:06:43 --> Final output sent to browser
DEBUG - 2018-08-30 12:06:43 --> Total execution time: 0.0506
INFO - 2018-08-30 12:06:44 --> Config Class Initialized
INFO - 2018-08-30 12:06:44 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:06:44 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:06:44 --> Utf8 Class Initialized
INFO - 2018-08-30 12:06:44 --> URI Class Initialized
INFO - 2018-08-30 12:06:44 --> Router Class Initialized
INFO - 2018-08-30 12:06:44 --> Output Class Initialized
INFO - 2018-08-30 12:06:44 --> Security Class Initialized
DEBUG - 2018-08-30 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:06:44 --> CSRF cookie sent
INFO - 2018-08-30 12:06:44 --> Input Class Initialized
INFO - 2018-08-30 12:06:44 --> Language Class Initialized
INFO - 2018-08-30 12:06:44 --> Loader Class Initialized
INFO - 2018-08-30 12:06:44 --> Helper loaded: url_helper
INFO - 2018-08-30 12:06:44 --> Helper loaded: form_helper
INFO - 2018-08-30 12:06:44 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:06:44 --> User Agent Class Initialized
INFO - 2018-08-30 12:06:44 --> Controller Class Initialized
INFO - 2018-08-30 12:06:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:06:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:06:44 --> Pixel_Model class loaded
INFO - 2018-08-30 12:06:44 --> Database Driver Class Initialized
INFO - 2018-08-30 12:06:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 12:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:06:44 --> Final output sent to browser
DEBUG - 2018-08-30 12:06:44 --> Total execution time: 0.0393
INFO - 2018-08-30 12:13:02 --> Config Class Initialized
INFO - 2018-08-30 12:13:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:13:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:13:02 --> Utf8 Class Initialized
INFO - 2018-08-30 12:13:02 --> URI Class Initialized
INFO - 2018-08-30 12:13:02 --> Router Class Initialized
INFO - 2018-08-30 12:13:02 --> Output Class Initialized
INFO - 2018-08-30 12:13:02 --> Security Class Initialized
DEBUG - 2018-08-30 12:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:13:02 --> CSRF cookie sent
INFO - 2018-08-30 12:13:02 --> CSRF token verified
INFO - 2018-08-30 12:13:02 --> Input Class Initialized
INFO - 2018-08-30 12:13:02 --> Language Class Initialized
INFO - 2018-08-30 12:13:02 --> Loader Class Initialized
INFO - 2018-08-30 12:13:02 --> Helper loaded: url_helper
INFO - 2018-08-30 12:13:02 --> Helper loaded: form_helper
INFO - 2018-08-30 12:13:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:13:02 --> User Agent Class Initialized
INFO - 2018-08-30 12:13:02 --> Controller Class Initialized
INFO - 2018-08-30 12:13:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:13:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:13:02 --> Pixel_Model class loaded
INFO - 2018-08-30 12:13:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:13:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:13:02 --> Config Class Initialized
INFO - 2018-08-30 12:13:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:13:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:13:02 --> Utf8 Class Initialized
INFO - 2018-08-30 12:13:02 --> URI Class Initialized
INFO - 2018-08-30 12:13:02 --> Router Class Initialized
INFO - 2018-08-30 12:13:02 --> Output Class Initialized
INFO - 2018-08-30 12:13:02 --> Security Class Initialized
DEBUG - 2018-08-30 12:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:13:02 --> CSRF cookie sent
INFO - 2018-08-30 12:13:02 --> Input Class Initialized
INFO - 2018-08-30 12:13:02 --> Language Class Initialized
INFO - 2018-08-30 12:13:02 --> Loader Class Initialized
INFO - 2018-08-30 12:13:02 --> Helper loaded: url_helper
INFO - 2018-08-30 12:13:02 --> Helper loaded: form_helper
INFO - 2018-08-30 12:13:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:13:02 --> User Agent Class Initialized
INFO - 2018-08-30 12:13:02 --> Controller Class Initialized
INFO - 2018-08-30 12:13:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:13:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:13:02 --> Pixel_Model class loaded
INFO - 2018-08-30 12:13:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:13:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 12:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:13:02 --> Final output sent to browser
DEBUG - 2018-08-30 12:13:02 --> Total execution time: 0.0520
INFO - 2018-08-30 12:22:02 --> Config Class Initialized
INFO - 2018-08-30 12:22:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:02 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:02 --> URI Class Initialized
INFO - 2018-08-30 12:22:02 --> Router Class Initialized
INFO - 2018-08-30 12:22:02 --> Output Class Initialized
INFO - 2018-08-30 12:22:02 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:02 --> CSRF cookie sent
INFO - 2018-08-30 12:22:02 --> CSRF token verified
INFO - 2018-08-30 12:22:02 --> Input Class Initialized
INFO - 2018-08-30 12:22:02 --> Language Class Initialized
INFO - 2018-08-30 12:22:02 --> Loader Class Initialized
INFO - 2018-08-30 12:22:02 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:02 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:02 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:02 --> Controller Class Initialized
INFO - 2018-08-30 12:22:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:02 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:02 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:02 --> Config Class Initialized
INFO - 2018-08-30 12:22:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:02 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:02 --> URI Class Initialized
INFO - 2018-08-30 12:22:02 --> Router Class Initialized
INFO - 2018-08-30 12:22:02 --> Output Class Initialized
INFO - 2018-08-30 12:22:02 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:02 --> CSRF cookie sent
INFO - 2018-08-30 12:22:02 --> Input Class Initialized
INFO - 2018-08-30 12:22:02 --> Language Class Initialized
INFO - 2018-08-30 12:22:02 --> Loader Class Initialized
INFO - 2018-08-30 12:22:02 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:02 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:02 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:02 --> Controller Class Initialized
INFO - 2018-08-30 12:22:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:02 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:02 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 12:22:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:02 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:02 --> Total execution time: 0.0655
INFO - 2018-08-30 12:22:03 --> Config Class Initialized
INFO - 2018-08-30 12:22:03 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:03 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:03 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:03 --> URI Class Initialized
INFO - 2018-08-30 12:22:03 --> Router Class Initialized
INFO - 2018-08-30 12:22:03 --> Output Class Initialized
INFO - 2018-08-30 12:22:03 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:03 --> CSRF cookie sent
INFO - 2018-08-30 12:22:03 --> CSRF token verified
INFO - 2018-08-30 12:22:03 --> Input Class Initialized
INFO - 2018-08-30 12:22:03 --> Language Class Initialized
INFO - 2018-08-30 12:22:03 --> Loader Class Initialized
INFO - 2018-08-30 12:22:03 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:03 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:03 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:03 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:03 --> Controller Class Initialized
INFO - 2018-08-30 12:22:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:03 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:03 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:03 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:03 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:03 --> Config Class Initialized
INFO - 2018-08-30 12:22:03 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:03 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:03 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:03 --> URI Class Initialized
INFO - 2018-08-30 12:22:03 --> Router Class Initialized
INFO - 2018-08-30 12:22:03 --> Output Class Initialized
INFO - 2018-08-30 12:22:03 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:03 --> CSRF cookie sent
INFO - 2018-08-30 12:22:03 --> Input Class Initialized
INFO - 2018-08-30 12:22:03 --> Language Class Initialized
INFO - 2018-08-30 12:22:03 --> Loader Class Initialized
INFO - 2018-08-30 12:22:03 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:03 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:03 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:03 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:03 --> Controller Class Initialized
INFO - 2018-08-30 12:22:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:03 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:03 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:03 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 12:22:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:03 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:03 --> Total execution time: 0.0380
INFO - 2018-08-30 12:22:04 --> Config Class Initialized
INFO - 2018-08-30 12:22:04 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:04 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:04 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:04 --> URI Class Initialized
INFO - 2018-08-30 12:22:04 --> Router Class Initialized
INFO - 2018-08-30 12:22:04 --> Output Class Initialized
INFO - 2018-08-30 12:22:04 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:04 --> CSRF cookie sent
INFO - 2018-08-30 12:22:04 --> CSRF token verified
INFO - 2018-08-30 12:22:04 --> Input Class Initialized
INFO - 2018-08-30 12:22:04 --> Language Class Initialized
INFO - 2018-08-30 12:22:04 --> Loader Class Initialized
INFO - 2018-08-30 12:22:04 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:04 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:04 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:04 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:04 --> Controller Class Initialized
INFO - 2018-08-30 12:22:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:04 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:04 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:04 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:04 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:04 --> Config Class Initialized
INFO - 2018-08-30 12:22:04 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:04 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:04 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:04 --> URI Class Initialized
INFO - 2018-08-30 12:22:04 --> Router Class Initialized
INFO - 2018-08-30 12:22:04 --> Output Class Initialized
INFO - 2018-08-30 12:22:04 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:04 --> CSRF cookie sent
INFO - 2018-08-30 12:22:04 --> Input Class Initialized
INFO - 2018-08-30 12:22:04 --> Language Class Initialized
INFO - 2018-08-30 12:22:04 --> Loader Class Initialized
INFO - 2018-08-30 12:22:04 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:04 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:04 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:04 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:04 --> Controller Class Initialized
INFO - 2018-08-30 12:22:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:04 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:04 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:04 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 12:22:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:04 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:04 --> Total execution time: 0.0410
INFO - 2018-08-30 12:22:10 --> Config Class Initialized
INFO - 2018-08-30 12:22:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:10 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:10 --> URI Class Initialized
INFO - 2018-08-30 12:22:10 --> Router Class Initialized
INFO - 2018-08-30 12:22:10 --> Output Class Initialized
INFO - 2018-08-30 12:22:10 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:10 --> CSRF cookie sent
INFO - 2018-08-30 12:22:10 --> CSRF token verified
INFO - 2018-08-30 12:22:10 --> Input Class Initialized
INFO - 2018-08-30 12:22:10 --> Language Class Initialized
INFO - 2018-08-30 12:22:10 --> Loader Class Initialized
INFO - 2018-08-30 12:22:10 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:10 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:10 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:10 --> Controller Class Initialized
INFO - 2018-08-30 12:22:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:10 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:10 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:10 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:10 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:10 --> Config Class Initialized
INFO - 2018-08-30 12:22:10 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:10 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:10 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:10 --> URI Class Initialized
INFO - 2018-08-30 12:22:10 --> Router Class Initialized
INFO - 2018-08-30 12:22:10 --> Output Class Initialized
INFO - 2018-08-30 12:22:10 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:10 --> CSRF cookie sent
INFO - 2018-08-30 12:22:10 --> Input Class Initialized
INFO - 2018-08-30 12:22:10 --> Language Class Initialized
INFO - 2018-08-30 12:22:10 --> Loader Class Initialized
INFO - 2018-08-30 12:22:10 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:10 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:10 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:10 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:10 --> Controller Class Initialized
INFO - 2018-08-30 12:22:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:10 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:10 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:10 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-30 12:22:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:10 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:10 --> Total execution time: 0.0458
INFO - 2018-08-30 12:22:15 --> Config Class Initialized
INFO - 2018-08-30 12:22:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:15 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:15 --> URI Class Initialized
INFO - 2018-08-30 12:22:15 --> Router Class Initialized
INFO - 2018-08-30 12:22:15 --> Output Class Initialized
INFO - 2018-08-30 12:22:15 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:15 --> CSRF cookie sent
INFO - 2018-08-30 12:22:15 --> CSRF token verified
INFO - 2018-08-30 12:22:15 --> Input Class Initialized
INFO - 2018-08-30 12:22:15 --> Language Class Initialized
INFO - 2018-08-30 12:22:15 --> Loader Class Initialized
INFO - 2018-08-30 12:22:15 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:15 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:15 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:15 --> Controller Class Initialized
INFO - 2018-08-30 12:22:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:15 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:15 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:15 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:15 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:16 --> Config Class Initialized
INFO - 2018-08-30 12:22:16 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:16 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:16 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:16 --> URI Class Initialized
INFO - 2018-08-30 12:22:16 --> Router Class Initialized
INFO - 2018-08-30 12:22:16 --> Output Class Initialized
INFO - 2018-08-30 12:22:16 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:16 --> CSRF cookie sent
INFO - 2018-08-30 12:22:16 --> Input Class Initialized
INFO - 2018-08-30 12:22:16 --> Language Class Initialized
INFO - 2018-08-30 12:22:16 --> Loader Class Initialized
INFO - 2018-08-30 12:22:16 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:16 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:16 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:16 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:16 --> Controller Class Initialized
INFO - 2018-08-30 12:22:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:16 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:16 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:16 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 12:22:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:16 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:16 --> Total execution time: 0.0455
INFO - 2018-08-30 12:22:27 --> Config Class Initialized
INFO - 2018-08-30 12:22:27 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:27 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:27 --> URI Class Initialized
INFO - 2018-08-30 12:22:27 --> Router Class Initialized
INFO - 2018-08-30 12:22:27 --> Output Class Initialized
INFO - 2018-08-30 12:22:27 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:27 --> CSRF cookie sent
INFO - 2018-08-30 12:22:27 --> CSRF token verified
INFO - 2018-08-30 12:22:27 --> Input Class Initialized
INFO - 2018-08-30 12:22:27 --> Language Class Initialized
INFO - 2018-08-30 12:22:27 --> Loader Class Initialized
INFO - 2018-08-30 12:22:27 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:27 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:27 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:27 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:27 --> Controller Class Initialized
INFO - 2018-08-30 12:22:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:27 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:27 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:27 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:27 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:27 --> Config Class Initialized
INFO - 2018-08-30 12:22:27 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:27 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:27 --> URI Class Initialized
INFO - 2018-08-30 12:22:27 --> Router Class Initialized
INFO - 2018-08-30 12:22:27 --> Output Class Initialized
INFO - 2018-08-30 12:22:27 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:28 --> CSRF cookie sent
INFO - 2018-08-30 12:22:28 --> Input Class Initialized
INFO - 2018-08-30 12:22:28 --> Language Class Initialized
INFO - 2018-08-30 12:22:28 --> Loader Class Initialized
INFO - 2018-08-30 12:22:28 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:28 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:28 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:28 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:28 --> Controller Class Initialized
INFO - 2018-08-30 12:22:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:28 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:28 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:28 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 12:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:28 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:28 --> Total execution time: 0.0483
INFO - 2018-08-30 12:22:29 --> Config Class Initialized
INFO - 2018-08-30 12:22:29 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:29 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:29 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:29 --> URI Class Initialized
INFO - 2018-08-30 12:22:29 --> Router Class Initialized
INFO - 2018-08-30 12:22:29 --> Output Class Initialized
INFO - 2018-08-30 12:22:29 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:29 --> CSRF cookie sent
INFO - 2018-08-30 12:22:29 --> CSRF token verified
INFO - 2018-08-30 12:22:29 --> Input Class Initialized
INFO - 2018-08-30 12:22:29 --> Language Class Initialized
INFO - 2018-08-30 12:22:29 --> Loader Class Initialized
INFO - 2018-08-30 12:22:29 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:29 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:29 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:29 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:29 --> Controller Class Initialized
INFO - 2018-08-30 12:22:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:29 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:29 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:29 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:29 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:29 --> Config Class Initialized
INFO - 2018-08-30 12:22:29 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:29 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:29 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:29 --> URI Class Initialized
INFO - 2018-08-30 12:22:29 --> Router Class Initialized
INFO - 2018-08-30 12:22:29 --> Output Class Initialized
INFO - 2018-08-30 12:22:29 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:29 --> CSRF cookie sent
INFO - 2018-08-30 12:22:29 --> Input Class Initialized
INFO - 2018-08-30 12:22:29 --> Language Class Initialized
INFO - 2018-08-30 12:22:29 --> Loader Class Initialized
INFO - 2018-08-30 12:22:29 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:29 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:29 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:29 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:29 --> Controller Class Initialized
INFO - 2018-08-30 12:22:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:29 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:29 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:29 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-30 12:22:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:29 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:29 --> Total execution time: 0.0554
INFO - 2018-08-30 12:22:32 --> Config Class Initialized
INFO - 2018-08-30 12:22:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:32 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:32 --> URI Class Initialized
INFO - 2018-08-30 12:22:32 --> Router Class Initialized
INFO - 2018-08-30 12:22:32 --> Output Class Initialized
INFO - 2018-08-30 12:22:32 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:32 --> CSRF cookie sent
INFO - 2018-08-30 12:22:32 --> CSRF token verified
INFO - 2018-08-30 12:22:32 --> Input Class Initialized
INFO - 2018-08-30 12:22:32 --> Language Class Initialized
INFO - 2018-08-30 12:22:32 --> Loader Class Initialized
INFO - 2018-08-30 12:22:32 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:32 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:32 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:32 --> Controller Class Initialized
INFO - 2018-08-30 12:22:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:32 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:32 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:32 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:32 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:32 --> Config Class Initialized
INFO - 2018-08-30 12:22:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:32 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:32 --> URI Class Initialized
INFO - 2018-08-30 12:22:32 --> Router Class Initialized
INFO - 2018-08-30 12:22:32 --> Output Class Initialized
INFO - 2018-08-30 12:22:32 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:32 --> CSRF cookie sent
INFO - 2018-08-30 12:22:32 --> Input Class Initialized
INFO - 2018-08-30 12:22:32 --> Language Class Initialized
INFO - 2018-08-30 12:22:32 --> Loader Class Initialized
INFO - 2018-08-30 12:22:32 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:32 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:32 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:32 --> Controller Class Initialized
INFO - 2018-08-30 12:22:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:32 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:32 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:32 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-30 12:22:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:32 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:32 --> Total execution time: 0.0452
INFO - 2018-08-30 12:22:34 --> Config Class Initialized
INFO - 2018-08-30 12:22:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:34 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:34 --> URI Class Initialized
INFO - 2018-08-30 12:22:34 --> Router Class Initialized
INFO - 2018-08-30 12:22:34 --> Output Class Initialized
INFO - 2018-08-30 12:22:34 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:34 --> CSRF cookie sent
INFO - 2018-08-30 12:22:34 --> CSRF token verified
INFO - 2018-08-30 12:22:34 --> Input Class Initialized
INFO - 2018-08-30 12:22:34 --> Language Class Initialized
INFO - 2018-08-30 12:22:34 --> Loader Class Initialized
INFO - 2018-08-30 12:22:34 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:34 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:34 --> Controller Class Initialized
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:34 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:34 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:34 --> Form Validation Class Initialized
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 12:22:34 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:34 --> Config Class Initialized
INFO - 2018-08-30 12:22:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:34 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:34 --> URI Class Initialized
INFO - 2018-08-30 12:22:34 --> Router Class Initialized
INFO - 2018-08-30 12:22:34 --> Output Class Initialized
INFO - 2018-08-30 12:22:34 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:34 --> CSRF cookie sent
INFO - 2018-08-30 12:22:34 --> Input Class Initialized
INFO - 2018-08-30 12:22:34 --> Language Class Initialized
INFO - 2018-08-30 12:22:34 --> Loader Class Initialized
INFO - 2018-08-30 12:22:34 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:34 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:34 --> Controller Class Initialized
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:34 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:34 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:22:34 --> Config Class Initialized
INFO - 2018-08-30 12:22:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:22:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:22:34 --> Utf8 Class Initialized
INFO - 2018-08-30 12:22:34 --> URI Class Initialized
INFO - 2018-08-30 12:22:34 --> Router Class Initialized
INFO - 2018-08-30 12:22:34 --> Output Class Initialized
INFO - 2018-08-30 12:22:34 --> Security Class Initialized
DEBUG - 2018-08-30 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:22:34 --> CSRF cookie sent
INFO - 2018-08-30 12:22:34 --> Input Class Initialized
INFO - 2018-08-30 12:22:34 --> Language Class Initialized
INFO - 2018-08-30 12:22:34 --> Loader Class Initialized
INFO - 2018-08-30 12:22:34 --> Helper loaded: url_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: form_helper
INFO - 2018-08-30 12:22:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:22:34 --> User Agent Class Initialized
INFO - 2018-08-30 12:22:34 --> Controller Class Initialized
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:22:34 --> Pixel_Model class loaded
INFO - 2018-08-30 12:22:34 --> Database Driver Class Initialized
INFO - 2018-08-30 12:22:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-30 12:22:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 12:22:34 --> Could not find the language line "req_email"
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-30 12:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:22:34 --> Final output sent to browser
DEBUG - 2018-08-30 12:22:34 --> Total execution time: 0.0399
INFO - 2018-08-30 12:49:23 --> Config Class Initialized
INFO - 2018-08-30 12:49:23 --> Hooks Class Initialized
DEBUG - 2018-08-30 12:49:23 --> UTF-8 Support Enabled
INFO - 2018-08-30 12:49:23 --> Utf8 Class Initialized
INFO - 2018-08-30 12:49:23 --> URI Class Initialized
DEBUG - 2018-08-30 12:49:23 --> No URI present. Default controller set.
INFO - 2018-08-30 12:49:23 --> Router Class Initialized
INFO - 2018-08-30 12:49:23 --> Output Class Initialized
INFO - 2018-08-30 12:49:23 --> Security Class Initialized
DEBUG - 2018-08-30 12:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 12:49:23 --> CSRF cookie sent
INFO - 2018-08-30 12:49:23 --> Input Class Initialized
INFO - 2018-08-30 12:49:23 --> Language Class Initialized
INFO - 2018-08-30 12:49:23 --> Loader Class Initialized
INFO - 2018-08-30 12:49:23 --> Helper loaded: url_helper
INFO - 2018-08-30 12:49:23 --> Helper loaded: form_helper
INFO - 2018-08-30 12:49:23 --> Helper loaded: language_helper
DEBUG - 2018-08-30 12:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 12:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 12:49:23 --> User Agent Class Initialized
INFO - 2018-08-30 12:49:23 --> Controller Class Initialized
INFO - 2018-08-30 12:49:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 12:49:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 12:49:23 --> Pixel_Model class loaded
INFO - 2018-08-30 12:49:23 --> Database Driver Class Initialized
INFO - 2018-08-30 12:49:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 12:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 12:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 12:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-30 12:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 12:49:23 --> Final output sent to browser
DEBUG - 2018-08-30 12:49:23 --> Total execution time: 0.0381
INFO - 2018-08-30 14:38:53 --> Config Class Initialized
INFO - 2018-08-30 14:38:53 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:38:53 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:38:53 --> Utf8 Class Initialized
INFO - 2018-08-30 14:38:53 --> URI Class Initialized
INFO - 2018-08-30 14:38:53 --> Router Class Initialized
INFO - 2018-08-30 14:38:53 --> Output Class Initialized
INFO - 2018-08-30 14:38:53 --> Security Class Initialized
DEBUG - 2018-08-30 14:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:38:53 --> CSRF cookie sent
INFO - 2018-08-30 14:38:53 --> Input Class Initialized
INFO - 2018-08-30 14:38:53 --> Language Class Initialized
INFO - 2018-08-30 14:38:53 --> Loader Class Initialized
INFO - 2018-08-30 14:38:53 --> Helper loaded: url_helper
INFO - 2018-08-30 14:38:53 --> Helper loaded: form_helper
INFO - 2018-08-30 14:38:53 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:38:53 --> User Agent Class Initialized
INFO - 2018-08-30 14:38:53 --> Controller Class Initialized
INFO - 2018-08-30 14:38:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:38:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:38:53 --> Pixel_Model class loaded
INFO - 2018-08-30 14:38:53 --> Database Driver Class Initialized
INFO - 2018-08-30 14:38:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:38:54 --> Config Class Initialized
INFO - 2018-08-30 14:38:54 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:38:54 --> Utf8 Class Initialized
INFO - 2018-08-30 14:38:54 --> URI Class Initialized
INFO - 2018-08-30 14:38:54 --> Router Class Initialized
INFO - 2018-08-30 14:38:54 --> Output Class Initialized
INFO - 2018-08-30 14:38:54 --> Security Class Initialized
DEBUG - 2018-08-30 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:38:54 --> CSRF cookie sent
INFO - 2018-08-30 14:38:54 --> Input Class Initialized
INFO - 2018-08-30 14:38:54 --> Language Class Initialized
INFO - 2018-08-30 14:38:54 --> Loader Class Initialized
INFO - 2018-08-30 14:38:54 --> Helper loaded: url_helper
INFO - 2018-08-30 14:38:54 --> Helper loaded: form_helper
INFO - 2018-08-30 14:38:54 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:38:54 --> User Agent Class Initialized
INFO - 2018-08-30 14:38:54 --> Controller Class Initialized
INFO - 2018-08-30 14:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:38:54 --> Pixel_Model class loaded
INFO - 2018-08-30 14:38:54 --> Database Driver Class Initialized
INFO - 2018-08-30 14:38:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 14:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:38:54 --> Final output sent to browser
DEBUG - 2018-08-30 14:38:54 --> Total execution time: 0.0876
INFO - 2018-08-30 14:39:01 --> Config Class Initialized
INFO - 2018-08-30 14:39:01 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:01 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:01 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:01 --> URI Class Initialized
INFO - 2018-08-30 14:39:01 --> Router Class Initialized
INFO - 2018-08-30 14:39:01 --> Output Class Initialized
INFO - 2018-08-30 14:39:01 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:01 --> CSRF cookie sent
INFO - 2018-08-30 14:39:01 --> CSRF token verified
INFO - 2018-08-30 14:39:01 --> Input Class Initialized
INFO - 2018-08-30 14:39:01 --> Language Class Initialized
INFO - 2018-08-30 14:39:01 --> Loader Class Initialized
INFO - 2018-08-30 14:39:01 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:01 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:01 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:01 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:01 --> Controller Class Initialized
INFO - 2018-08-30 14:39:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:01 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:01 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:01 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:02 --> Config Class Initialized
INFO - 2018-08-30 14:39:02 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:02 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:02 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:02 --> URI Class Initialized
INFO - 2018-08-30 14:39:02 --> Router Class Initialized
INFO - 2018-08-30 14:39:02 --> Output Class Initialized
INFO - 2018-08-30 14:39:02 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:02 --> CSRF cookie sent
INFO - 2018-08-30 14:39:02 --> Input Class Initialized
INFO - 2018-08-30 14:39:02 --> Language Class Initialized
INFO - 2018-08-30 14:39:02 --> Loader Class Initialized
INFO - 2018-08-30 14:39:02 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:02 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:02 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:02 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:02 --> Controller Class Initialized
INFO - 2018-08-30 14:39:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:02 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:02 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:02 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 14:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:39:02 --> Final output sent to browser
DEBUG - 2018-08-30 14:39:02 --> Total execution time: 0.0498
INFO - 2018-08-30 14:39:18 --> Config Class Initialized
INFO - 2018-08-30 14:39:18 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:18 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:18 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:18 --> URI Class Initialized
INFO - 2018-08-30 14:39:18 --> Router Class Initialized
INFO - 2018-08-30 14:39:18 --> Output Class Initialized
INFO - 2018-08-30 14:39:18 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:18 --> CSRF cookie sent
INFO - 2018-08-30 14:39:18 --> CSRF token verified
INFO - 2018-08-30 14:39:18 --> Input Class Initialized
INFO - 2018-08-30 14:39:18 --> Language Class Initialized
INFO - 2018-08-30 14:39:18 --> Loader Class Initialized
INFO - 2018-08-30 14:39:18 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:18 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:18 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:18 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:18 --> Controller Class Initialized
INFO - 2018-08-30 14:39:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:18 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:18 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:18 --> Form Validation Class Initialized
INFO - 2018-08-30 14:39:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:39:18 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:19 --> Config Class Initialized
INFO - 2018-08-30 14:39:19 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:19 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:19 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:19 --> URI Class Initialized
INFO - 2018-08-30 14:39:19 --> Router Class Initialized
INFO - 2018-08-30 14:39:19 --> Output Class Initialized
INFO - 2018-08-30 14:39:19 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:19 --> CSRF cookie sent
INFO - 2018-08-30 14:39:19 --> Input Class Initialized
INFO - 2018-08-30 14:39:19 --> Language Class Initialized
INFO - 2018-08-30 14:39:19 --> Loader Class Initialized
INFO - 2018-08-30 14:39:19 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:19 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:19 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:19 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:19 --> Controller Class Initialized
INFO - 2018-08-30 14:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:19 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:19 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:19 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 14:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:39:19 --> Final output sent to browser
DEBUG - 2018-08-30 14:39:19 --> Total execution time: 0.0717
INFO - 2018-08-30 14:39:56 --> Config Class Initialized
INFO - 2018-08-30 14:39:56 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:56 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:56 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:56 --> URI Class Initialized
INFO - 2018-08-30 14:39:56 --> Router Class Initialized
INFO - 2018-08-30 14:39:56 --> Output Class Initialized
INFO - 2018-08-30 14:39:56 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:56 --> CSRF cookie sent
INFO - 2018-08-30 14:39:56 --> CSRF token verified
INFO - 2018-08-30 14:39:56 --> Input Class Initialized
INFO - 2018-08-30 14:39:56 --> Language Class Initialized
INFO - 2018-08-30 14:39:56 --> Loader Class Initialized
INFO - 2018-08-30 14:39:56 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:56 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:56 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:56 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:56 --> Controller Class Initialized
INFO - 2018-08-30 14:39:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:56 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:56 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:56 --> Form Validation Class Initialized
INFO - 2018-08-30 14:39:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:39:56 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:57 --> Config Class Initialized
INFO - 2018-08-30 14:39:57 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:39:57 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:39:57 --> Utf8 Class Initialized
INFO - 2018-08-30 14:39:57 --> URI Class Initialized
INFO - 2018-08-30 14:39:57 --> Router Class Initialized
INFO - 2018-08-30 14:39:57 --> Output Class Initialized
INFO - 2018-08-30 14:39:57 --> Security Class Initialized
DEBUG - 2018-08-30 14:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:39:57 --> CSRF cookie sent
INFO - 2018-08-30 14:39:57 --> Input Class Initialized
INFO - 2018-08-30 14:39:57 --> Language Class Initialized
INFO - 2018-08-30 14:39:57 --> Loader Class Initialized
INFO - 2018-08-30 14:39:57 --> Helper loaded: url_helper
INFO - 2018-08-30 14:39:57 --> Helper loaded: form_helper
INFO - 2018-08-30 14:39:57 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:39:57 --> User Agent Class Initialized
INFO - 2018-08-30 14:39:57 --> Controller Class Initialized
INFO - 2018-08-30 14:39:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:39:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:39:57 --> Pixel_Model class loaded
INFO - 2018-08-30 14:39:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:39:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 14:39:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:39:57 --> Final output sent to browser
DEBUG - 2018-08-30 14:39:57 --> Total execution time: 0.0389
INFO - 2018-08-30 14:41:34 --> Config Class Initialized
INFO - 2018-08-30 14:41:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:41:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:41:34 --> Utf8 Class Initialized
INFO - 2018-08-30 14:41:34 --> URI Class Initialized
INFO - 2018-08-30 14:41:34 --> Router Class Initialized
INFO - 2018-08-30 14:41:34 --> Output Class Initialized
INFO - 2018-08-30 14:41:34 --> Security Class Initialized
DEBUG - 2018-08-30 14:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:41:34 --> CSRF cookie sent
INFO - 2018-08-30 14:41:34 --> CSRF token verified
INFO - 2018-08-30 14:41:34 --> Input Class Initialized
INFO - 2018-08-30 14:41:34 --> Language Class Initialized
INFO - 2018-08-30 14:41:34 --> Loader Class Initialized
INFO - 2018-08-30 14:41:34 --> Helper loaded: url_helper
INFO - 2018-08-30 14:41:34 --> Helper loaded: form_helper
INFO - 2018-08-30 14:41:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:41:34 --> User Agent Class Initialized
INFO - 2018-08-30 14:41:34 --> Controller Class Initialized
INFO - 2018-08-30 14:41:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:41:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:41:34 --> Pixel_Model class loaded
INFO - 2018-08-30 14:41:34 --> Database Driver Class Initialized
INFO - 2018-08-30 14:41:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:41:34 --> Form Validation Class Initialized
INFO - 2018-08-30 14:41:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:41:34 --> Database Driver Class Initialized
INFO - 2018-08-30 14:41:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:41:35 --> Config Class Initialized
INFO - 2018-08-30 14:41:35 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:41:35 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:41:35 --> Utf8 Class Initialized
INFO - 2018-08-30 14:41:35 --> URI Class Initialized
INFO - 2018-08-30 14:41:35 --> Router Class Initialized
INFO - 2018-08-30 14:41:35 --> Output Class Initialized
INFO - 2018-08-30 14:41:35 --> Security Class Initialized
DEBUG - 2018-08-30 14:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:41:35 --> CSRF cookie sent
INFO - 2018-08-30 14:41:35 --> Input Class Initialized
INFO - 2018-08-30 14:41:35 --> Language Class Initialized
INFO - 2018-08-30 14:41:35 --> Loader Class Initialized
INFO - 2018-08-30 14:41:35 --> Helper loaded: url_helper
INFO - 2018-08-30 14:41:35 --> Helper loaded: form_helper
INFO - 2018-08-30 14:41:35 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:41:35 --> User Agent Class Initialized
INFO - 2018-08-30 14:41:35 --> Controller Class Initialized
INFO - 2018-08-30 14:41:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:41:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:41:35 --> Pixel_Model class loaded
INFO - 2018-08-30 14:41:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:41:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:41:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:41:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 14:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:41:35 --> Final output sent to browser
DEBUG - 2018-08-30 14:41:35 --> Total execution time: 0.0665
INFO - 2018-08-30 14:54:12 --> Config Class Initialized
INFO - 2018-08-30 14:54:12 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:54:12 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:54:12 --> Utf8 Class Initialized
INFO - 2018-08-30 14:54:12 --> URI Class Initialized
INFO - 2018-08-30 14:54:12 --> Router Class Initialized
INFO - 2018-08-30 14:54:12 --> Output Class Initialized
INFO - 2018-08-30 14:54:12 --> Security Class Initialized
DEBUG - 2018-08-30 14:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:54:12 --> CSRF cookie sent
INFO - 2018-08-30 14:54:12 --> Input Class Initialized
INFO - 2018-08-30 14:54:12 --> Language Class Initialized
INFO - 2018-08-30 14:54:12 --> Loader Class Initialized
INFO - 2018-08-30 14:54:12 --> Helper loaded: url_helper
INFO - 2018-08-30 14:54:12 --> Helper loaded: form_helper
INFO - 2018-08-30 14:54:12 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:54:12 --> User Agent Class Initialized
INFO - 2018-08-30 14:54:12 --> Controller Class Initialized
INFO - 2018-08-30 14:54:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:54:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:54:12 --> Pixel_Model class loaded
INFO - 2018-08-30 14:54:12 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:12 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 14:54:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:54:12 --> Final output sent to browser
DEBUG - 2018-08-30 14:54:12 --> Total execution time: 0.0528
INFO - 2018-08-30 14:54:15 --> Config Class Initialized
INFO - 2018-08-30 14:54:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:54:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:54:15 --> Utf8 Class Initialized
INFO - 2018-08-30 14:54:15 --> URI Class Initialized
INFO - 2018-08-30 14:54:15 --> Router Class Initialized
INFO - 2018-08-30 14:54:15 --> Output Class Initialized
INFO - 2018-08-30 14:54:15 --> Security Class Initialized
DEBUG - 2018-08-30 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:54:15 --> CSRF cookie sent
INFO - 2018-08-30 14:54:15 --> Input Class Initialized
INFO - 2018-08-30 14:54:15 --> Language Class Initialized
INFO - 2018-08-30 14:54:15 --> Loader Class Initialized
INFO - 2018-08-30 14:54:15 --> Helper loaded: url_helper
INFO - 2018-08-30 14:54:15 --> Helper loaded: form_helper
INFO - 2018-08-30 14:54:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:54:15 --> User Agent Class Initialized
INFO - 2018-08-30 14:54:15 --> Controller Class Initialized
INFO - 2018-08-30 14:54:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:54:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:54:15 --> Pixel_Model class loaded
INFO - 2018-08-30 14:54:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 14:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:54:15 --> Final output sent to browser
DEBUG - 2018-08-30 14:54:15 --> Total execution time: 0.0486
INFO - 2018-08-30 14:54:17 --> Config Class Initialized
INFO - 2018-08-30 14:54:17 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:54:17 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:54:17 --> Utf8 Class Initialized
INFO - 2018-08-30 14:54:17 --> URI Class Initialized
INFO - 2018-08-30 14:54:17 --> Router Class Initialized
INFO - 2018-08-30 14:54:17 --> Output Class Initialized
INFO - 2018-08-30 14:54:17 --> Security Class Initialized
DEBUG - 2018-08-30 14:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:54:17 --> CSRF cookie sent
INFO - 2018-08-30 14:54:17 --> Input Class Initialized
INFO - 2018-08-30 14:54:17 --> Language Class Initialized
INFO - 2018-08-30 14:54:17 --> Loader Class Initialized
INFO - 2018-08-30 14:54:17 --> Helper loaded: url_helper
INFO - 2018-08-30 14:54:17 --> Helper loaded: form_helper
INFO - 2018-08-30 14:54:17 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:54:17 --> User Agent Class Initialized
INFO - 2018-08-30 14:54:17 --> Controller Class Initialized
INFO - 2018-08-30 14:54:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:54:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:54:17 --> Pixel_Model class loaded
INFO - 2018-08-30 14:54:17 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:17 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 14:54:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:54:17 --> Final output sent to browser
DEBUG - 2018-08-30 14:54:17 --> Total execution time: 0.0651
INFO - 2018-08-30 14:54:20 --> Config Class Initialized
INFO - 2018-08-30 14:54:20 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:54:20 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:54:20 --> Utf8 Class Initialized
INFO - 2018-08-30 14:54:20 --> URI Class Initialized
INFO - 2018-08-30 14:54:20 --> Router Class Initialized
INFO - 2018-08-30 14:54:20 --> Output Class Initialized
INFO - 2018-08-30 14:54:20 --> Security Class Initialized
DEBUG - 2018-08-30 14:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:54:20 --> CSRF cookie sent
INFO - 2018-08-30 14:54:20 --> Input Class Initialized
INFO - 2018-08-30 14:54:20 --> Language Class Initialized
INFO - 2018-08-30 14:54:20 --> Loader Class Initialized
INFO - 2018-08-30 14:54:20 --> Helper loaded: url_helper
INFO - 2018-08-30 14:54:20 --> Helper loaded: form_helper
INFO - 2018-08-30 14:54:20 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:54:20 --> User Agent Class Initialized
INFO - 2018-08-30 14:54:20 --> Controller Class Initialized
INFO - 2018-08-30 14:54:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:54:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:54:20 --> Pixel_Model class loaded
INFO - 2018-08-30 14:54:20 --> Database Driver Class Initialized
INFO - 2018-08-30 14:54:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-30 14:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:54:20 --> Final output sent to browser
DEBUG - 2018-08-30 14:54:20 --> Total execution time: 0.0530
INFO - 2018-08-30 14:55:41 --> Config Class Initialized
INFO - 2018-08-30 14:55:41 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:55:41 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:55:41 --> Utf8 Class Initialized
INFO - 2018-08-30 14:55:41 --> URI Class Initialized
INFO - 2018-08-30 14:55:41 --> Router Class Initialized
INFO - 2018-08-30 14:55:41 --> Output Class Initialized
INFO - 2018-08-30 14:55:41 --> Security Class Initialized
DEBUG - 2018-08-30 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:55:41 --> CSRF cookie sent
INFO - 2018-08-30 14:55:41 --> CSRF token verified
INFO - 2018-08-30 14:55:41 --> Input Class Initialized
INFO - 2018-08-30 14:55:41 --> Language Class Initialized
INFO - 2018-08-30 14:55:41 --> Loader Class Initialized
INFO - 2018-08-30 14:55:41 --> Helper loaded: url_helper
INFO - 2018-08-30 14:55:41 --> Helper loaded: form_helper
INFO - 2018-08-30 14:55:41 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:55:41 --> User Agent Class Initialized
INFO - 2018-08-30 14:55:41 --> Controller Class Initialized
INFO - 2018-08-30 14:55:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:55:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:55:41 --> Pixel_Model class loaded
INFO - 2018-08-30 14:55:41 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:41 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:43 --> Config Class Initialized
INFO - 2018-08-30 14:55:43 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:55:43 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:55:43 --> Utf8 Class Initialized
INFO - 2018-08-30 14:55:43 --> URI Class Initialized
INFO - 2018-08-30 14:55:43 --> Router Class Initialized
INFO - 2018-08-30 14:55:43 --> Output Class Initialized
INFO - 2018-08-30 14:55:43 --> Security Class Initialized
DEBUG - 2018-08-30 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:55:43 --> CSRF cookie sent
INFO - 2018-08-30 14:55:43 --> Input Class Initialized
INFO - 2018-08-30 14:55:43 --> Language Class Initialized
INFO - 2018-08-30 14:55:43 --> Loader Class Initialized
INFO - 2018-08-30 14:55:43 --> Helper loaded: url_helper
INFO - 2018-08-30 14:55:43 --> Helper loaded: form_helper
INFO - 2018-08-30 14:55:43 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:55:43 --> User Agent Class Initialized
INFO - 2018-08-30 14:55:43 --> Controller Class Initialized
INFO - 2018-08-30 14:55:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:55:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:55:43 --> Pixel_Model class loaded
INFO - 2018-08-30 14:55:43 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:43 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-30 14:55:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:55:43 --> Final output sent to browser
DEBUG - 2018-08-30 14:55:43 --> Total execution time: 0.0693
INFO - 2018-08-30 14:55:57 --> Config Class Initialized
INFO - 2018-08-30 14:55:57 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:55:57 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:55:57 --> Utf8 Class Initialized
INFO - 2018-08-30 14:55:57 --> URI Class Initialized
INFO - 2018-08-30 14:55:57 --> Router Class Initialized
INFO - 2018-08-30 14:55:57 --> Output Class Initialized
INFO - 2018-08-30 14:55:57 --> Security Class Initialized
DEBUG - 2018-08-30 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:55:57 --> CSRF cookie sent
INFO - 2018-08-30 14:55:57 --> CSRF token verified
INFO - 2018-08-30 14:55:57 --> Input Class Initialized
INFO - 2018-08-30 14:55:57 --> Language Class Initialized
INFO - 2018-08-30 14:55:57 --> Loader Class Initialized
INFO - 2018-08-30 14:55:57 --> Helper loaded: url_helper
INFO - 2018-08-30 14:55:57 --> Helper loaded: form_helper
INFO - 2018-08-30 14:55:57 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:55:57 --> User Agent Class Initialized
INFO - 2018-08-30 14:55:57 --> Controller Class Initialized
INFO - 2018-08-30 14:55:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:55:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:55:57 --> Pixel_Model class loaded
INFO - 2018-08-30 14:55:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:57 --> Form Validation Class Initialized
INFO - 2018-08-30 14:55:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:55:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:57 --> Config Class Initialized
INFO - 2018-08-30 14:55:57 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:55:57 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:55:57 --> Utf8 Class Initialized
INFO - 2018-08-30 14:55:57 --> URI Class Initialized
INFO - 2018-08-30 14:55:57 --> Router Class Initialized
INFO - 2018-08-30 14:55:57 --> Output Class Initialized
INFO - 2018-08-30 14:55:57 --> Security Class Initialized
DEBUG - 2018-08-30 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:55:57 --> CSRF cookie sent
INFO - 2018-08-30 14:55:57 --> Input Class Initialized
INFO - 2018-08-30 14:55:57 --> Language Class Initialized
INFO - 2018-08-30 14:55:57 --> Loader Class Initialized
INFO - 2018-08-30 14:55:57 --> Helper loaded: url_helper
INFO - 2018-08-30 14:55:57 --> Helper loaded: form_helper
INFO - 2018-08-30 14:55:57 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:55:57 --> User Agent Class Initialized
INFO - 2018-08-30 14:55:57 --> Controller Class Initialized
INFO - 2018-08-30 14:55:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:55:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:55:57 --> Pixel_Model class loaded
INFO - 2018-08-30 14:55:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:57 --> Database Driver Class Initialized
INFO - 2018-08-30 14:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-30 14:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:55:58 --> Final output sent to browser
DEBUG - 2018-08-30 14:55:58 --> Total execution time: 0.0484
INFO - 2018-08-30 14:56:06 --> Config Class Initialized
INFO - 2018-08-30 14:56:06 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:06 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:06 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:06 --> URI Class Initialized
INFO - 2018-08-30 14:56:06 --> Router Class Initialized
INFO - 2018-08-30 14:56:06 --> Output Class Initialized
INFO - 2018-08-30 14:56:06 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:06 --> CSRF cookie sent
INFO - 2018-08-30 14:56:06 --> CSRF token verified
INFO - 2018-08-30 14:56:06 --> Input Class Initialized
INFO - 2018-08-30 14:56:06 --> Language Class Initialized
INFO - 2018-08-30 14:56:06 --> Loader Class Initialized
INFO - 2018-08-30 14:56:06 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:06 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:06 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:06 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:06 --> Controller Class Initialized
INFO - 2018-08-30 14:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:06 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:06 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:06 --> Form Validation Class Initialized
INFO - 2018-08-30 14:56:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:56:06 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:07 --> Config Class Initialized
INFO - 2018-08-30 14:56:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:07 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:07 --> URI Class Initialized
INFO - 2018-08-30 14:56:07 --> Router Class Initialized
INFO - 2018-08-30 14:56:07 --> Output Class Initialized
INFO - 2018-08-30 14:56:07 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:07 --> CSRF cookie sent
INFO - 2018-08-30 14:56:07 --> Input Class Initialized
INFO - 2018-08-30 14:56:07 --> Language Class Initialized
INFO - 2018-08-30 14:56:07 --> Loader Class Initialized
INFO - 2018-08-30 14:56:07 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:07 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:07 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:07 --> Controller Class Initialized
INFO - 2018-08-30 14:56:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:07 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:07 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:07 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-30 14:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:56:07 --> Final output sent to browser
DEBUG - 2018-08-30 14:56:07 --> Total execution time: 0.0381
INFO - 2018-08-30 14:56:22 --> Config Class Initialized
INFO - 2018-08-30 14:56:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:22 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:22 --> URI Class Initialized
INFO - 2018-08-30 14:56:22 --> Router Class Initialized
INFO - 2018-08-30 14:56:22 --> Output Class Initialized
INFO - 2018-08-30 14:56:22 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:22 --> CSRF cookie sent
INFO - 2018-08-30 14:56:22 --> CSRF token verified
INFO - 2018-08-30 14:56:22 --> Input Class Initialized
INFO - 2018-08-30 14:56:22 --> Language Class Initialized
INFO - 2018-08-30 14:56:22 --> Loader Class Initialized
INFO - 2018-08-30 14:56:22 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:22 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:22 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:22 --> Controller Class Initialized
INFO - 2018-08-30 14:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:22 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:22 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:22 --> Form Validation Class Initialized
INFO - 2018-08-30 14:56:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:56:22 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:23 --> Config Class Initialized
INFO - 2018-08-30 14:56:23 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:23 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:23 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:23 --> URI Class Initialized
INFO - 2018-08-30 14:56:23 --> Router Class Initialized
INFO - 2018-08-30 14:56:23 --> Output Class Initialized
INFO - 2018-08-30 14:56:23 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:23 --> CSRF cookie sent
INFO - 2018-08-30 14:56:23 --> Input Class Initialized
INFO - 2018-08-30 14:56:23 --> Language Class Initialized
INFO - 2018-08-30 14:56:23 --> Loader Class Initialized
INFO - 2018-08-30 14:56:23 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:23 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:23 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:23 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:23 --> Controller Class Initialized
INFO - 2018-08-30 14:56:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:23 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:23 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:23 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-30 14:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:56:23 --> Final output sent to browser
DEBUG - 2018-08-30 14:56:23 --> Total execution time: 0.0425
INFO - 2018-08-30 14:56:32 --> Config Class Initialized
INFO - 2018-08-30 14:56:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:32 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:32 --> URI Class Initialized
INFO - 2018-08-30 14:56:32 --> Router Class Initialized
INFO - 2018-08-30 14:56:32 --> Output Class Initialized
INFO - 2018-08-30 14:56:32 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:32 --> CSRF cookie sent
INFO - 2018-08-30 14:56:32 --> CSRF token verified
INFO - 2018-08-30 14:56:32 --> Input Class Initialized
INFO - 2018-08-30 14:56:32 --> Language Class Initialized
INFO - 2018-08-30 14:56:32 --> Loader Class Initialized
INFO - 2018-08-30 14:56:32 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:32 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:32 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:32 --> Controller Class Initialized
INFO - 2018-08-30 14:56:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:32 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:32 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:32 --> Form Validation Class Initialized
INFO - 2018-08-30 14:56:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:56:32 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:33 --> Config Class Initialized
INFO - 2018-08-30 14:56:33 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:33 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:33 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:33 --> URI Class Initialized
INFO - 2018-08-30 14:56:33 --> Router Class Initialized
INFO - 2018-08-30 14:56:33 --> Output Class Initialized
INFO - 2018-08-30 14:56:33 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:33 --> CSRF cookie sent
INFO - 2018-08-30 14:56:33 --> Input Class Initialized
INFO - 2018-08-30 14:56:33 --> Language Class Initialized
INFO - 2018-08-30 14:56:33 --> Loader Class Initialized
INFO - 2018-08-30 14:56:33 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:33 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:33 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:33 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:33 --> Controller Class Initialized
INFO - 2018-08-30 14:56:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:33 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:33 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:33 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-30 14:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:56:33 --> Final output sent to browser
DEBUG - 2018-08-30 14:56:33 --> Total execution time: 0.0376
INFO - 2018-08-30 14:56:50 --> Config Class Initialized
INFO - 2018-08-30 14:56:50 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:50 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:50 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:50 --> URI Class Initialized
INFO - 2018-08-30 14:56:50 --> Router Class Initialized
INFO - 2018-08-30 14:56:50 --> Output Class Initialized
INFO - 2018-08-30 14:56:50 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:50 --> CSRF cookie sent
INFO - 2018-08-30 14:56:50 --> CSRF token verified
INFO - 2018-08-30 14:56:50 --> Input Class Initialized
INFO - 2018-08-30 14:56:50 --> Language Class Initialized
INFO - 2018-08-30 14:56:50 --> Loader Class Initialized
INFO - 2018-08-30 14:56:50 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:50 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:50 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:50 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:50 --> Controller Class Initialized
INFO - 2018-08-30 14:56:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:50 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:50 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:50 --> Form Validation Class Initialized
INFO - 2018-08-30 14:56:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:56:50 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:51 --> Config Class Initialized
INFO - 2018-08-30 14:56:51 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:56:51 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:56:51 --> Utf8 Class Initialized
INFO - 2018-08-30 14:56:51 --> URI Class Initialized
INFO - 2018-08-30 14:56:51 --> Router Class Initialized
INFO - 2018-08-30 14:56:51 --> Output Class Initialized
INFO - 2018-08-30 14:56:51 --> Security Class Initialized
DEBUG - 2018-08-30 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:56:51 --> CSRF cookie sent
INFO - 2018-08-30 14:56:51 --> Input Class Initialized
INFO - 2018-08-30 14:56:51 --> Language Class Initialized
INFO - 2018-08-30 14:56:51 --> Loader Class Initialized
INFO - 2018-08-30 14:56:51 --> Helper loaded: url_helper
INFO - 2018-08-30 14:56:51 --> Helper loaded: form_helper
INFO - 2018-08-30 14:56:51 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:56:51 --> User Agent Class Initialized
INFO - 2018-08-30 14:56:51 --> Controller Class Initialized
INFO - 2018-08-30 14:56:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:56:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:56:51 --> Pixel_Model class loaded
INFO - 2018-08-30 14:56:51 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:51 --> Database Driver Class Initialized
INFO - 2018-08-30 14:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-30 14:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:56:51 --> Final output sent to browser
DEBUG - 2018-08-30 14:56:51 --> Total execution time: 0.0889
INFO - 2018-08-30 14:57:06 --> Config Class Initialized
INFO - 2018-08-30 14:57:06 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:06 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:06 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:06 --> URI Class Initialized
INFO - 2018-08-30 14:57:06 --> Router Class Initialized
INFO - 2018-08-30 14:57:06 --> Output Class Initialized
INFO - 2018-08-30 14:57:06 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:06 --> CSRF cookie sent
INFO - 2018-08-30 14:57:06 --> CSRF token verified
INFO - 2018-08-30 14:57:06 --> Input Class Initialized
INFO - 2018-08-30 14:57:06 --> Language Class Initialized
INFO - 2018-08-30 14:57:06 --> Loader Class Initialized
INFO - 2018-08-30 14:57:06 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:06 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:06 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:06 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:06 --> Controller Class Initialized
INFO - 2018-08-30 14:57:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:06 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:06 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:06 --> Form Validation Class Initialized
INFO - 2018-08-30 14:57:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:57:06 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:07 --> Config Class Initialized
INFO - 2018-08-30 14:57:07 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:07 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:07 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:07 --> URI Class Initialized
INFO - 2018-08-30 14:57:07 --> Router Class Initialized
INFO - 2018-08-30 14:57:07 --> Output Class Initialized
INFO - 2018-08-30 14:57:07 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:07 --> CSRF cookie sent
INFO - 2018-08-30 14:57:07 --> Input Class Initialized
INFO - 2018-08-30 14:57:07 --> Language Class Initialized
INFO - 2018-08-30 14:57:07 --> Loader Class Initialized
INFO - 2018-08-30 14:57:07 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:07 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:07 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:07 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:07 --> Controller Class Initialized
INFO - 2018-08-30 14:57:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:07 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:07 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:07 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-30 14:57:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:57:07 --> Final output sent to browser
DEBUG - 2018-08-30 14:57:07 --> Total execution time: 0.0389
INFO - 2018-08-30 14:57:14 --> Config Class Initialized
INFO - 2018-08-30 14:57:14 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:14 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:14 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:14 --> URI Class Initialized
INFO - 2018-08-30 14:57:14 --> Router Class Initialized
INFO - 2018-08-30 14:57:14 --> Output Class Initialized
INFO - 2018-08-30 14:57:14 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:14 --> CSRF cookie sent
INFO - 2018-08-30 14:57:14 --> CSRF token verified
INFO - 2018-08-30 14:57:14 --> Input Class Initialized
INFO - 2018-08-30 14:57:14 --> Language Class Initialized
INFO - 2018-08-30 14:57:14 --> Loader Class Initialized
INFO - 2018-08-30 14:57:14 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:14 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:14 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:14 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:14 --> Controller Class Initialized
INFO - 2018-08-30 14:57:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:14 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:14 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:14 --> Form Validation Class Initialized
INFO - 2018-08-30 14:57:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:57:14 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:15 --> Config Class Initialized
INFO - 2018-08-30 14:57:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:15 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:15 --> URI Class Initialized
INFO - 2018-08-30 14:57:15 --> Router Class Initialized
INFO - 2018-08-30 14:57:15 --> Output Class Initialized
INFO - 2018-08-30 14:57:15 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:15 --> CSRF cookie sent
INFO - 2018-08-30 14:57:15 --> Input Class Initialized
INFO - 2018-08-30 14:57:15 --> Language Class Initialized
INFO - 2018-08-30 14:57:15 --> Loader Class Initialized
INFO - 2018-08-30 14:57:15 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:15 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:15 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:15 --> Controller Class Initialized
INFO - 2018-08-30 14:57:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:15 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-30 14:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:57:15 --> Final output sent to browser
DEBUG - 2018-08-30 14:57:15 --> Total execution time: 0.0400
INFO - 2018-08-30 14:57:21 --> Config Class Initialized
INFO - 2018-08-30 14:57:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:21 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:21 --> URI Class Initialized
INFO - 2018-08-30 14:57:21 --> Router Class Initialized
INFO - 2018-08-30 14:57:21 --> Output Class Initialized
INFO - 2018-08-30 14:57:21 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:21 --> CSRF cookie sent
INFO - 2018-08-30 14:57:21 --> CSRF token verified
INFO - 2018-08-30 14:57:21 --> Input Class Initialized
INFO - 2018-08-30 14:57:21 --> Language Class Initialized
INFO - 2018-08-30 14:57:21 --> Loader Class Initialized
INFO - 2018-08-30 14:57:21 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:21 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:21 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:21 --> Controller Class Initialized
INFO - 2018-08-30 14:57:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:21 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:21 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:21 --> Form Validation Class Initialized
INFO - 2018-08-30 14:57:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:57:21 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:22 --> Config Class Initialized
INFO - 2018-08-30 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:22 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:22 --> URI Class Initialized
INFO - 2018-08-30 14:57:22 --> Router Class Initialized
INFO - 2018-08-30 14:57:22 --> Output Class Initialized
INFO - 2018-08-30 14:57:22 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:22 --> CSRF cookie sent
INFO - 2018-08-30 14:57:22 --> Input Class Initialized
INFO - 2018-08-30 14:57:22 --> Language Class Initialized
INFO - 2018-08-30 14:57:22 --> Loader Class Initialized
INFO - 2018-08-30 14:57:22 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:22 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:22 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:22 --> Controller Class Initialized
INFO - 2018-08-30 14:57:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:22 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:22 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:22 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-30 14:57:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:57:22 --> Final output sent to browser
DEBUG - 2018-08-30 14:57:22 --> Total execution time: 0.0703
INFO - 2018-08-30 14:57:40 --> Config Class Initialized
INFO - 2018-08-30 14:57:40 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:40 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:40 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:40 --> URI Class Initialized
INFO - 2018-08-30 14:57:40 --> Router Class Initialized
INFO - 2018-08-30 14:57:40 --> Output Class Initialized
INFO - 2018-08-30 14:57:40 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:40 --> CSRF cookie sent
INFO - 2018-08-30 14:57:40 --> CSRF token verified
INFO - 2018-08-30 14:57:40 --> Input Class Initialized
INFO - 2018-08-30 14:57:40 --> Language Class Initialized
INFO - 2018-08-30 14:57:40 --> Loader Class Initialized
INFO - 2018-08-30 14:57:40 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:40 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:40 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:40 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:40 --> Controller Class Initialized
INFO - 2018-08-30 14:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:40 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:40 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:40 --> Form Validation Class Initialized
INFO - 2018-08-30 14:57:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:57:40 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:41 --> Config Class Initialized
INFO - 2018-08-30 14:57:41 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:41 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:41 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:41 --> URI Class Initialized
INFO - 2018-08-30 14:57:41 --> Router Class Initialized
INFO - 2018-08-30 14:57:41 --> Output Class Initialized
INFO - 2018-08-30 14:57:41 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:41 --> CSRF cookie sent
INFO - 2018-08-30 14:57:41 --> Input Class Initialized
INFO - 2018-08-30 14:57:41 --> Language Class Initialized
INFO - 2018-08-30 14:57:41 --> Loader Class Initialized
INFO - 2018-08-30 14:57:41 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:41 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:41 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:41 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:41 --> Controller Class Initialized
INFO - 2018-08-30 14:57:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:57:41 --> Pixel_Model class loaded
INFO - 2018-08-30 14:57:41 --> Database Driver Class Initialized
INFO - 2018-08-30 14:57:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:57:42 --> Config Class Initialized
INFO - 2018-08-30 14:57:42 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:57:42 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:57:42 --> Utf8 Class Initialized
INFO - 2018-08-30 14:57:42 --> URI Class Initialized
INFO - 2018-08-30 14:57:42 --> Router Class Initialized
INFO - 2018-08-30 14:57:42 --> Output Class Initialized
INFO - 2018-08-30 14:57:42 --> Security Class Initialized
DEBUG - 2018-08-30 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:57:42 --> CSRF cookie sent
INFO - 2018-08-30 14:57:42 --> Input Class Initialized
INFO - 2018-08-30 14:57:42 --> Language Class Initialized
INFO - 2018-08-30 14:57:42 --> Loader Class Initialized
INFO - 2018-08-30 14:57:42 --> Helper loaded: url_helper
INFO - 2018-08-30 14:57:42 --> Helper loaded: form_helper
INFO - 2018-08-30 14:57:42 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:57:42 --> User Agent Class Initialized
INFO - 2018-08-30 14:57:42 --> Controller Class Initialized
INFO - 2018-08-30 14:57:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:57:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 14:57:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-30 14:57:42 --> Could not find the language line "req_email"
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-30 14:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:57:42 --> Final output sent to browser
DEBUG - 2018-08-30 14:57:42 --> Total execution time: 0.0257
INFO - 2018-08-30 14:58:14 --> Config Class Initialized
INFO - 2018-08-30 14:58:14 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:14 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:14 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:14 --> URI Class Initialized
INFO - 2018-08-30 14:58:14 --> Router Class Initialized
INFO - 2018-08-30 14:58:14 --> Output Class Initialized
INFO - 2018-08-30 14:58:14 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:14 --> CSRF cookie sent
INFO - 2018-08-30 14:58:14 --> CSRF token verified
INFO - 2018-08-30 14:58:14 --> Input Class Initialized
INFO - 2018-08-30 14:58:14 --> Language Class Initialized
INFO - 2018-08-30 14:58:14 --> Loader Class Initialized
INFO - 2018-08-30 14:58:14 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:14 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:14 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:14 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:14 --> Controller Class Initialized
INFO - 2018-08-30 14:58:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-30 14:58:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-30 14:58:14 --> Form Validation Class Initialized
INFO - 2018-08-30 14:58:14 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:14 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:14 --> Model "AuthenticationModel" initialized
INFO - 2018-08-30 14:58:14 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:15 --> Config Class Initialized
INFO - 2018-08-30 14:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:15 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:15 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:15 --> URI Class Initialized
INFO - 2018-08-30 14:58:15 --> Router Class Initialized
INFO - 2018-08-30 14:58:15 --> Output Class Initialized
INFO - 2018-08-30 14:58:15 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:15 --> CSRF cookie sent
INFO - 2018-08-30 14:58:15 --> Input Class Initialized
INFO - 2018-08-30 14:58:15 --> Language Class Initialized
INFO - 2018-08-30 14:58:15 --> Loader Class Initialized
INFO - 2018-08-30 14:58:15 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:15 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:15 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:15 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:15 --> Controller Class Initialized
INFO - 2018-08-30 14:58:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:58:15 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:15 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-08-30 14:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:58:15 --> Final output sent to browser
DEBUG - 2018-08-30 14:58:15 --> Total execution time: 0.0414
INFO - 2018-08-30 14:58:32 --> Config Class Initialized
INFO - 2018-08-30 14:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:32 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:32 --> URI Class Initialized
INFO - 2018-08-30 14:58:32 --> Router Class Initialized
INFO - 2018-08-30 14:58:32 --> Output Class Initialized
INFO - 2018-08-30 14:58:32 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:32 --> CSRF cookie sent
INFO - 2018-08-30 14:58:32 --> CSRF token verified
INFO - 2018-08-30 14:58:32 --> Input Class Initialized
INFO - 2018-08-30 14:58:32 --> Language Class Initialized
INFO - 2018-08-30 14:58:32 --> Loader Class Initialized
INFO - 2018-08-30 14:58:32 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:32 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:32 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:32 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:32 --> Controller Class Initialized
INFO - 2018-08-30 14:58:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:58:32 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:32 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:32 --> Form Validation Class Initialized
INFO - 2018-08-30 14:58:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:58:32 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:33 --> Config Class Initialized
INFO - 2018-08-30 14:58:33 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:33 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:33 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:33 --> URI Class Initialized
INFO - 2018-08-30 14:58:33 --> Router Class Initialized
INFO - 2018-08-30 14:58:33 --> Output Class Initialized
INFO - 2018-08-30 14:58:33 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:33 --> CSRF cookie sent
INFO - 2018-08-30 14:58:33 --> Input Class Initialized
INFO - 2018-08-30 14:58:33 --> Language Class Initialized
INFO - 2018-08-30 14:58:33 --> Loader Class Initialized
INFO - 2018-08-30 14:58:33 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:33 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:33 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:33 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:33 --> Controller Class Initialized
INFO - 2018-08-30 14:58:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:58:33 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:33 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:33 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-08-30 14:58:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:58:33 --> Final output sent to browser
DEBUG - 2018-08-30 14:58:33 --> Total execution time: 0.0543
INFO - 2018-08-30 14:58:46 --> Config Class Initialized
INFO - 2018-08-30 14:58:46 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:46 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:46 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:46 --> URI Class Initialized
INFO - 2018-08-30 14:58:46 --> Router Class Initialized
INFO - 2018-08-30 14:58:46 --> Output Class Initialized
INFO - 2018-08-30 14:58:46 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:46 --> CSRF cookie sent
INFO - 2018-08-30 14:58:46 --> CSRF token verified
INFO - 2018-08-30 14:58:46 --> Input Class Initialized
INFO - 2018-08-30 14:58:46 --> Language Class Initialized
INFO - 2018-08-30 14:58:46 --> Loader Class Initialized
INFO - 2018-08-30 14:58:46 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:46 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:46 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:46 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:46 --> Controller Class Initialized
INFO - 2018-08-30 14:58:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:58:46 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:46 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:46 --> Form Validation Class Initialized
INFO - 2018-08-30 14:58:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:58:46 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:46 --> Config Class Initialized
INFO - 2018-08-30 14:58:46 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:58:46 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:58:46 --> Utf8 Class Initialized
INFO - 2018-08-30 14:58:46 --> URI Class Initialized
INFO - 2018-08-30 14:58:46 --> Router Class Initialized
INFO - 2018-08-30 14:58:46 --> Output Class Initialized
INFO - 2018-08-30 14:58:46 --> Security Class Initialized
DEBUG - 2018-08-30 14:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:58:46 --> CSRF cookie sent
INFO - 2018-08-30 14:58:46 --> Input Class Initialized
INFO - 2018-08-30 14:58:46 --> Language Class Initialized
INFO - 2018-08-30 14:58:46 --> Loader Class Initialized
INFO - 2018-08-30 14:58:46 --> Helper loaded: url_helper
INFO - 2018-08-30 14:58:46 --> Helper loaded: form_helper
INFO - 2018-08-30 14:58:46 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:58:46 --> User Agent Class Initialized
INFO - 2018-08-30 14:58:46 --> Controller Class Initialized
INFO - 2018-08-30 14:58:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:58:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:58:46 --> Pixel_Model class loaded
INFO - 2018-08-30 14:58:46 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:47 --> Database Driver Class Initialized
INFO - 2018-08-30 14:58:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-30 14:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:58:47 --> Final output sent to browser
DEBUG - 2018-08-30 14:58:47 --> Total execution time: 0.0491
INFO - 2018-08-30 14:59:00 --> Config Class Initialized
INFO - 2018-08-30 14:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:59:00 --> Utf8 Class Initialized
INFO - 2018-08-30 14:59:00 --> URI Class Initialized
INFO - 2018-08-30 14:59:00 --> Router Class Initialized
INFO - 2018-08-30 14:59:00 --> Output Class Initialized
INFO - 2018-08-30 14:59:00 --> Security Class Initialized
DEBUG - 2018-08-30 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:59:00 --> CSRF cookie sent
INFO - 2018-08-30 14:59:00 --> CSRF token verified
INFO - 2018-08-30 14:59:00 --> Input Class Initialized
INFO - 2018-08-30 14:59:00 --> Language Class Initialized
INFO - 2018-08-30 14:59:00 --> Loader Class Initialized
INFO - 2018-08-30 14:59:00 --> Helper loaded: url_helper
INFO - 2018-08-30 14:59:00 --> Helper loaded: form_helper
INFO - 2018-08-30 14:59:00 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:59:00 --> User Agent Class Initialized
INFO - 2018-08-30 14:59:00 --> Controller Class Initialized
INFO - 2018-08-30 14:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:59:00 --> Pixel_Model class loaded
INFO - 2018-08-30 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:00 --> Form Validation Class Initialized
INFO - 2018-08-30 14:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:59:00 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:01 --> Config Class Initialized
INFO - 2018-08-30 14:59:01 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:59:01 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:59:01 --> Utf8 Class Initialized
INFO - 2018-08-30 14:59:01 --> URI Class Initialized
INFO - 2018-08-30 14:59:01 --> Router Class Initialized
INFO - 2018-08-30 14:59:01 --> Output Class Initialized
INFO - 2018-08-30 14:59:01 --> Security Class Initialized
DEBUG - 2018-08-30 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:59:01 --> CSRF cookie sent
INFO - 2018-08-30 14:59:01 --> Input Class Initialized
INFO - 2018-08-30 14:59:01 --> Language Class Initialized
INFO - 2018-08-30 14:59:01 --> Loader Class Initialized
INFO - 2018-08-30 14:59:01 --> Helper loaded: url_helper
INFO - 2018-08-30 14:59:01 --> Helper loaded: form_helper
INFO - 2018-08-30 14:59:01 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:59:01 --> User Agent Class Initialized
INFO - 2018-08-30 14:59:01 --> Controller Class Initialized
INFO - 2018-08-30 14:59:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:59:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:59:01 --> Pixel_Model class loaded
INFO - 2018-08-30 14:59:01 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:01 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-30 14:59:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:59:01 --> Final output sent to browser
DEBUG - 2018-08-30 14:59:01 --> Total execution time: 0.0340
INFO - 2018-08-30 14:59:35 --> Config Class Initialized
INFO - 2018-08-30 14:59:35 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:59:35 --> Utf8 Class Initialized
INFO - 2018-08-30 14:59:35 --> URI Class Initialized
INFO - 2018-08-30 14:59:35 --> Router Class Initialized
INFO - 2018-08-30 14:59:35 --> Output Class Initialized
INFO - 2018-08-30 14:59:35 --> Security Class Initialized
DEBUG - 2018-08-30 14:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:59:35 --> CSRF cookie sent
INFO - 2018-08-30 14:59:35 --> CSRF token verified
INFO - 2018-08-30 14:59:35 --> Input Class Initialized
INFO - 2018-08-30 14:59:35 --> Language Class Initialized
INFO - 2018-08-30 14:59:35 --> Loader Class Initialized
INFO - 2018-08-30 14:59:35 --> Helper loaded: url_helper
INFO - 2018-08-30 14:59:35 --> Helper loaded: form_helper
INFO - 2018-08-30 14:59:35 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:59:35 --> User Agent Class Initialized
INFO - 2018-08-30 14:59:35 --> Controller Class Initialized
INFO - 2018-08-30 14:59:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:59:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:59:35 --> Pixel_Model class loaded
INFO - 2018-08-30 14:59:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:35 --> Form Validation Class Initialized
INFO - 2018-08-30 14:59:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 14:59:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:35 --> Config Class Initialized
INFO - 2018-08-30 14:59:35 --> Hooks Class Initialized
DEBUG - 2018-08-30 14:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-30 14:59:35 --> Utf8 Class Initialized
INFO - 2018-08-30 14:59:35 --> URI Class Initialized
INFO - 2018-08-30 14:59:35 --> Router Class Initialized
INFO - 2018-08-30 14:59:35 --> Output Class Initialized
INFO - 2018-08-30 14:59:35 --> Security Class Initialized
DEBUG - 2018-08-30 14:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 14:59:35 --> CSRF cookie sent
INFO - 2018-08-30 14:59:35 --> Input Class Initialized
INFO - 2018-08-30 14:59:35 --> Language Class Initialized
INFO - 2018-08-30 14:59:35 --> Loader Class Initialized
INFO - 2018-08-30 14:59:35 --> Helper loaded: url_helper
INFO - 2018-08-30 14:59:35 --> Helper loaded: form_helper
INFO - 2018-08-30 14:59:35 --> Helper loaded: language_helper
DEBUG - 2018-08-30 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 14:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 14:59:35 --> User Agent Class Initialized
INFO - 2018-08-30 14:59:35 --> Controller Class Initialized
INFO - 2018-08-30 14:59:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 14:59:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 14:59:35 --> Pixel_Model class loaded
INFO - 2018-08-30 14:59:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:35 --> Database Driver Class Initialized
INFO - 2018-08-30 14:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-30 14:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 14:59:36 --> Final output sent to browser
DEBUG - 2018-08-30 14:59:36 --> Total execution time: 0.0490
INFO - 2018-08-30 15:00:24 --> Config Class Initialized
INFO - 2018-08-30 15:00:24 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:00:24 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:00:24 --> Utf8 Class Initialized
INFO - 2018-08-30 15:00:24 --> URI Class Initialized
INFO - 2018-08-30 15:00:24 --> Router Class Initialized
INFO - 2018-08-30 15:00:24 --> Output Class Initialized
INFO - 2018-08-30 15:00:24 --> Security Class Initialized
DEBUG - 2018-08-30 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:00:24 --> CSRF cookie sent
INFO - 2018-08-30 15:00:24 --> CSRF token verified
INFO - 2018-08-30 15:00:24 --> Input Class Initialized
INFO - 2018-08-30 15:00:24 --> Language Class Initialized
INFO - 2018-08-30 15:00:24 --> Loader Class Initialized
INFO - 2018-08-30 15:00:24 --> Helper loaded: url_helper
INFO - 2018-08-30 15:00:24 --> Helper loaded: form_helper
INFO - 2018-08-30 15:00:24 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:00:24 --> User Agent Class Initialized
INFO - 2018-08-30 15:00:24 --> Controller Class Initialized
INFO - 2018-08-30 15:00:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:00:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:00:24 --> Pixel_Model class loaded
INFO - 2018-08-30 15:00:24 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:24 --> Form Validation Class Initialized
INFO - 2018-08-30 15:00:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:00:24 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:25 --> Config Class Initialized
INFO - 2018-08-30 15:00:25 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:00:25 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:00:25 --> Utf8 Class Initialized
INFO - 2018-08-30 15:00:25 --> URI Class Initialized
INFO - 2018-08-30 15:00:25 --> Router Class Initialized
INFO - 2018-08-30 15:00:25 --> Output Class Initialized
INFO - 2018-08-30 15:00:25 --> Security Class Initialized
DEBUG - 2018-08-30 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:00:25 --> CSRF cookie sent
INFO - 2018-08-30 15:00:25 --> Input Class Initialized
INFO - 2018-08-30 15:00:25 --> Language Class Initialized
INFO - 2018-08-30 15:00:25 --> Loader Class Initialized
INFO - 2018-08-30 15:00:25 --> Helper loaded: url_helper
INFO - 2018-08-30 15:00:25 --> Helper loaded: form_helper
INFO - 2018-08-30 15:00:25 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:00:25 --> User Agent Class Initialized
INFO - 2018-08-30 15:00:25 --> Controller Class Initialized
INFO - 2018-08-30 15:00:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:00:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:00:25 --> Pixel_Model class loaded
INFO - 2018-08-30 15:00:25 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:25 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-30 15:00:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:00:25 --> Final output sent to browser
DEBUG - 2018-08-30 15:00:25 --> Total execution time: 0.0413
INFO - 2018-08-30 15:00:33 --> Config Class Initialized
INFO - 2018-08-30 15:00:33 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:00:33 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:00:33 --> Utf8 Class Initialized
INFO - 2018-08-30 15:00:33 --> URI Class Initialized
INFO - 2018-08-30 15:00:33 --> Router Class Initialized
INFO - 2018-08-30 15:00:33 --> Output Class Initialized
INFO - 2018-08-30 15:00:33 --> Security Class Initialized
DEBUG - 2018-08-30 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:00:33 --> CSRF cookie sent
INFO - 2018-08-30 15:00:33 --> CSRF token verified
INFO - 2018-08-30 15:00:33 --> Input Class Initialized
INFO - 2018-08-30 15:00:33 --> Language Class Initialized
INFO - 2018-08-30 15:00:33 --> Loader Class Initialized
INFO - 2018-08-30 15:00:33 --> Helper loaded: url_helper
INFO - 2018-08-30 15:00:33 --> Helper loaded: form_helper
INFO - 2018-08-30 15:00:33 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:00:33 --> User Agent Class Initialized
INFO - 2018-08-30 15:00:33 --> Controller Class Initialized
INFO - 2018-08-30 15:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:00:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:00:33 --> Pixel_Model class loaded
INFO - 2018-08-30 15:00:33 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:33 --> Form Validation Class Initialized
INFO - 2018-08-30 15:00:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:00:33 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:34 --> Config Class Initialized
INFO - 2018-08-30 15:00:34 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:00:34 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:00:34 --> Utf8 Class Initialized
INFO - 2018-08-30 15:00:34 --> URI Class Initialized
INFO - 2018-08-30 15:00:34 --> Router Class Initialized
INFO - 2018-08-30 15:00:34 --> Output Class Initialized
INFO - 2018-08-30 15:00:34 --> Security Class Initialized
DEBUG - 2018-08-30 15:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:00:34 --> CSRF cookie sent
INFO - 2018-08-30 15:00:34 --> Input Class Initialized
INFO - 2018-08-30 15:00:34 --> Language Class Initialized
INFO - 2018-08-30 15:00:34 --> Loader Class Initialized
INFO - 2018-08-30 15:00:34 --> Helper loaded: url_helper
INFO - 2018-08-30 15:00:34 --> Helper loaded: form_helper
INFO - 2018-08-30 15:00:34 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:00:34 --> User Agent Class Initialized
INFO - 2018-08-30 15:00:34 --> Controller Class Initialized
INFO - 2018-08-30 15:00:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:00:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:00:34 --> Pixel_Model class loaded
INFO - 2018-08-30 15:00:34 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:34 --> Database Driver Class Initialized
INFO - 2018-08-30 15:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-08-30 15:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:00:34 --> Final output sent to browser
DEBUG - 2018-08-30 15:00:34 --> Total execution time: 0.0411
INFO - 2018-08-30 15:01:00 --> Config Class Initialized
INFO - 2018-08-30 15:01:00 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:00 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:00 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:00 --> URI Class Initialized
INFO - 2018-08-30 15:01:00 --> Router Class Initialized
INFO - 2018-08-30 15:01:00 --> Output Class Initialized
INFO - 2018-08-30 15:01:00 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:00 --> CSRF cookie sent
INFO - 2018-08-30 15:01:00 --> CSRF token verified
INFO - 2018-08-30 15:01:00 --> Input Class Initialized
INFO - 2018-08-30 15:01:00 --> Language Class Initialized
INFO - 2018-08-30 15:01:00 --> Loader Class Initialized
INFO - 2018-08-30 15:01:00 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:00 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:00 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:00 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:00 --> Controller Class Initialized
INFO - 2018-08-30 15:01:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:00 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:00 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:00 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:00 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:01 --> Config Class Initialized
INFO - 2018-08-30 15:01:01 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:01 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:01 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:01 --> URI Class Initialized
INFO - 2018-08-30 15:01:01 --> Router Class Initialized
INFO - 2018-08-30 15:01:01 --> Output Class Initialized
INFO - 2018-08-30 15:01:01 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:01 --> CSRF cookie sent
INFO - 2018-08-30 15:01:01 --> Input Class Initialized
INFO - 2018-08-30 15:01:01 --> Language Class Initialized
INFO - 2018-08-30 15:01:01 --> Loader Class Initialized
INFO - 2018-08-30 15:01:01 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:01 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:01 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:01 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:01 --> Controller Class Initialized
INFO - 2018-08-30 15:01:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:01 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:01 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:01 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-08-30 15:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:01 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:01 --> Total execution time: 0.0452
INFO - 2018-08-30 15:01:13 --> Config Class Initialized
INFO - 2018-08-30 15:01:13 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:13 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:13 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:13 --> URI Class Initialized
INFO - 2018-08-30 15:01:13 --> Router Class Initialized
INFO - 2018-08-30 15:01:13 --> Output Class Initialized
INFO - 2018-08-30 15:01:13 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:13 --> CSRF cookie sent
INFO - 2018-08-30 15:01:13 --> CSRF token verified
INFO - 2018-08-30 15:01:13 --> Input Class Initialized
INFO - 2018-08-30 15:01:13 --> Language Class Initialized
INFO - 2018-08-30 15:01:13 --> Loader Class Initialized
INFO - 2018-08-30 15:01:13 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:13 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:13 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:13 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:13 --> Controller Class Initialized
INFO - 2018-08-30 15:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:13 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:13 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:13 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:13 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:14 --> Config Class Initialized
INFO - 2018-08-30 15:01:14 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:14 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:14 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:14 --> URI Class Initialized
INFO - 2018-08-30 15:01:14 --> Router Class Initialized
INFO - 2018-08-30 15:01:14 --> Output Class Initialized
INFO - 2018-08-30 15:01:14 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:14 --> CSRF cookie sent
INFO - 2018-08-30 15:01:14 --> Input Class Initialized
INFO - 2018-08-30 15:01:14 --> Language Class Initialized
INFO - 2018-08-30 15:01:14 --> Loader Class Initialized
INFO - 2018-08-30 15:01:14 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:14 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:14 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:14 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:14 --> Controller Class Initialized
INFO - 2018-08-30 15:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:14 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:14 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:14 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-08-30 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:14 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:14 --> Total execution time: 0.0389
INFO - 2018-08-30 15:01:22 --> Config Class Initialized
INFO - 2018-08-30 15:01:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:22 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:22 --> URI Class Initialized
INFO - 2018-08-30 15:01:22 --> Router Class Initialized
INFO - 2018-08-30 15:01:22 --> Output Class Initialized
INFO - 2018-08-30 15:01:22 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:22 --> CSRF cookie sent
INFO - 2018-08-30 15:01:22 --> CSRF token verified
INFO - 2018-08-30 15:01:22 --> Input Class Initialized
INFO - 2018-08-30 15:01:22 --> Language Class Initialized
INFO - 2018-08-30 15:01:22 --> Loader Class Initialized
INFO - 2018-08-30 15:01:22 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:22 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:22 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:22 --> Controller Class Initialized
INFO - 2018-08-30 15:01:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:22 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:22 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:22 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:22 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:23 --> Config Class Initialized
INFO - 2018-08-30 15:01:23 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:23 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:23 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:23 --> URI Class Initialized
INFO - 2018-08-30 15:01:23 --> Router Class Initialized
INFO - 2018-08-30 15:01:23 --> Output Class Initialized
INFO - 2018-08-30 15:01:23 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:23 --> CSRF cookie sent
INFO - 2018-08-30 15:01:23 --> Input Class Initialized
INFO - 2018-08-30 15:01:23 --> Language Class Initialized
INFO - 2018-08-30 15:01:23 --> Loader Class Initialized
INFO - 2018-08-30 15:01:23 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:23 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:23 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:23 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:23 --> Controller Class Initialized
INFO - 2018-08-30 15:01:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:23 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:23 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:23 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-08-30 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:23 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:23 --> Total execution time: 0.0428
INFO - 2018-08-30 15:01:31 --> Config Class Initialized
INFO - 2018-08-30 15:01:31 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:31 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:31 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:31 --> URI Class Initialized
INFO - 2018-08-30 15:01:31 --> Router Class Initialized
INFO - 2018-08-30 15:01:31 --> Output Class Initialized
INFO - 2018-08-30 15:01:31 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:31 --> CSRF cookie sent
INFO - 2018-08-30 15:01:31 --> CSRF token verified
INFO - 2018-08-30 15:01:31 --> Input Class Initialized
INFO - 2018-08-30 15:01:31 --> Language Class Initialized
INFO - 2018-08-30 15:01:31 --> Loader Class Initialized
INFO - 2018-08-30 15:01:31 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:31 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:31 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:31 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:31 --> Controller Class Initialized
INFO - 2018-08-30 15:01:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:31 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:31 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:31 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:31 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:31 --> Config Class Initialized
INFO - 2018-08-30 15:01:31 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:31 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:31 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:31 --> URI Class Initialized
INFO - 2018-08-30 15:01:31 --> Router Class Initialized
INFO - 2018-08-30 15:01:31 --> Output Class Initialized
INFO - 2018-08-30 15:01:31 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:31 --> CSRF cookie sent
INFO - 2018-08-30 15:01:31 --> Input Class Initialized
INFO - 2018-08-30 15:01:31 --> Language Class Initialized
INFO - 2018-08-30 15:01:31 --> Loader Class Initialized
INFO - 2018-08-30 15:01:31 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:31 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:31 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:31 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:31 --> Controller Class Initialized
INFO - 2018-08-30 15:01:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:31 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:31 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:31 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-08-30 15:01:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:31 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:31 --> Total execution time: 0.0692
INFO - 2018-08-30 15:01:37 --> Config Class Initialized
INFO - 2018-08-30 15:01:37 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:37 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:37 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:37 --> URI Class Initialized
INFO - 2018-08-30 15:01:37 --> Router Class Initialized
INFO - 2018-08-30 15:01:37 --> Output Class Initialized
INFO - 2018-08-30 15:01:37 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:37 --> CSRF cookie sent
INFO - 2018-08-30 15:01:37 --> CSRF token verified
INFO - 2018-08-30 15:01:37 --> Input Class Initialized
INFO - 2018-08-30 15:01:37 --> Language Class Initialized
INFO - 2018-08-30 15:01:37 --> Loader Class Initialized
INFO - 2018-08-30 15:01:37 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:37 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:37 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:37 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:37 --> Controller Class Initialized
INFO - 2018-08-30 15:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:37 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:37 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:37 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:37 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:38 --> Config Class Initialized
INFO - 2018-08-30 15:01:38 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:38 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:38 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:38 --> URI Class Initialized
INFO - 2018-08-30 15:01:38 --> Router Class Initialized
INFO - 2018-08-30 15:01:38 --> Output Class Initialized
INFO - 2018-08-30 15:01:38 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:38 --> CSRF cookie sent
INFO - 2018-08-30 15:01:38 --> Input Class Initialized
INFO - 2018-08-30 15:01:38 --> Language Class Initialized
INFO - 2018-08-30 15:01:38 --> Loader Class Initialized
INFO - 2018-08-30 15:01:38 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:38 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:38 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:38 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:38 --> Controller Class Initialized
INFO - 2018-08-30 15:01:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:38 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:38 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:38 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-08-30 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:38 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:38 --> Total execution time: 0.0663
INFO - 2018-08-30 15:01:49 --> Config Class Initialized
INFO - 2018-08-30 15:01:49 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:49 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:49 --> URI Class Initialized
INFO - 2018-08-30 15:01:49 --> Router Class Initialized
INFO - 2018-08-30 15:01:49 --> Output Class Initialized
INFO - 2018-08-30 15:01:49 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:49 --> CSRF cookie sent
INFO - 2018-08-30 15:01:49 --> CSRF token verified
INFO - 2018-08-30 15:01:49 --> Input Class Initialized
INFO - 2018-08-30 15:01:49 --> Language Class Initialized
INFO - 2018-08-30 15:01:49 --> Loader Class Initialized
INFO - 2018-08-30 15:01:49 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:49 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:49 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:49 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:49 --> Controller Class Initialized
INFO - 2018-08-30 15:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:49 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:49 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:49 --> Form Validation Class Initialized
INFO - 2018-08-30 15:01:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:01:49 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:50 --> Config Class Initialized
INFO - 2018-08-30 15:01:50 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:01:50 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:01:50 --> Utf8 Class Initialized
INFO - 2018-08-30 15:01:50 --> URI Class Initialized
INFO - 2018-08-30 15:01:50 --> Router Class Initialized
INFO - 2018-08-30 15:01:50 --> Output Class Initialized
INFO - 2018-08-30 15:01:50 --> Security Class Initialized
DEBUG - 2018-08-30 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:01:50 --> CSRF cookie sent
INFO - 2018-08-30 15:01:50 --> Input Class Initialized
INFO - 2018-08-30 15:01:50 --> Language Class Initialized
INFO - 2018-08-30 15:01:50 --> Loader Class Initialized
INFO - 2018-08-30 15:01:50 --> Helper loaded: url_helper
INFO - 2018-08-30 15:01:50 --> Helper loaded: form_helper
INFO - 2018-08-30 15:01:50 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:01:50 --> User Agent Class Initialized
INFO - 2018-08-30 15:01:50 --> Controller Class Initialized
INFO - 2018-08-30 15:01:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:01:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:01:50 --> Pixel_Model class loaded
INFO - 2018-08-30 15:01:50 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:50 --> Database Driver Class Initialized
INFO - 2018-08-30 15:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-30 15:01:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:01:50 --> Final output sent to browser
DEBUG - 2018-08-30 15:01:50 --> Total execution time: 0.0529
INFO - 2018-08-30 15:02:21 --> Config Class Initialized
INFO - 2018-08-30 15:02:21 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:02:21 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:02:21 --> Utf8 Class Initialized
INFO - 2018-08-30 15:02:21 --> URI Class Initialized
INFO - 2018-08-30 15:02:21 --> Router Class Initialized
INFO - 2018-08-30 15:02:21 --> Output Class Initialized
INFO - 2018-08-30 15:02:21 --> Security Class Initialized
DEBUG - 2018-08-30 15:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:02:21 --> CSRF cookie sent
INFO - 2018-08-30 15:02:21 --> CSRF token verified
INFO - 2018-08-30 15:02:21 --> Input Class Initialized
INFO - 2018-08-30 15:02:21 --> Language Class Initialized
INFO - 2018-08-30 15:02:21 --> Loader Class Initialized
INFO - 2018-08-30 15:02:21 --> Helper loaded: url_helper
INFO - 2018-08-30 15:02:21 --> Helper loaded: form_helper
INFO - 2018-08-30 15:02:21 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:02:21 --> User Agent Class Initialized
INFO - 2018-08-30 15:02:21 --> Controller Class Initialized
INFO - 2018-08-30 15:02:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:02:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:02:21 --> Pixel_Model class loaded
INFO - 2018-08-30 15:02:21 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:21 --> Form Validation Class Initialized
INFO - 2018-08-30 15:02:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:02:21 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:22 --> Config Class Initialized
INFO - 2018-08-30 15:02:22 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:02:22 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:02:22 --> Utf8 Class Initialized
INFO - 2018-08-30 15:02:22 --> URI Class Initialized
INFO - 2018-08-30 15:02:22 --> Router Class Initialized
INFO - 2018-08-30 15:02:22 --> Output Class Initialized
INFO - 2018-08-30 15:02:22 --> Security Class Initialized
DEBUG - 2018-08-30 15:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:02:22 --> CSRF cookie sent
INFO - 2018-08-30 15:02:22 --> Input Class Initialized
INFO - 2018-08-30 15:02:22 --> Language Class Initialized
INFO - 2018-08-30 15:02:22 --> Loader Class Initialized
INFO - 2018-08-30 15:02:22 --> Helper loaded: url_helper
INFO - 2018-08-30 15:02:22 --> Helper loaded: form_helper
INFO - 2018-08-30 15:02:22 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:02:22 --> User Agent Class Initialized
INFO - 2018-08-30 15:02:22 --> Controller Class Initialized
INFO - 2018-08-30 15:02:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:02:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:02:22 --> Pixel_Model class loaded
INFO - 2018-08-30 15:02:22 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:22 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-30 15:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:02:22 --> Final output sent to browser
DEBUG - 2018-08-30 15:02:22 --> Total execution time: 0.0500
INFO - 2018-08-30 15:02:47 --> Config Class Initialized
INFO - 2018-08-30 15:02:47 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:02:47 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:02:47 --> Utf8 Class Initialized
INFO - 2018-08-30 15:02:47 --> URI Class Initialized
INFO - 2018-08-30 15:02:47 --> Router Class Initialized
INFO - 2018-08-30 15:02:47 --> Output Class Initialized
INFO - 2018-08-30 15:02:47 --> Security Class Initialized
DEBUG - 2018-08-30 15:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:02:47 --> CSRF cookie sent
INFO - 2018-08-30 15:02:47 --> CSRF token verified
INFO - 2018-08-30 15:02:47 --> Input Class Initialized
INFO - 2018-08-30 15:02:47 --> Language Class Initialized
INFO - 2018-08-30 15:02:47 --> Loader Class Initialized
INFO - 2018-08-30 15:02:47 --> Helper loaded: url_helper
INFO - 2018-08-30 15:02:47 --> Helper loaded: form_helper
INFO - 2018-08-30 15:02:47 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:02:47 --> User Agent Class Initialized
INFO - 2018-08-30 15:02:48 --> Controller Class Initialized
INFO - 2018-08-30 15:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:02:48 --> Pixel_Model class loaded
INFO - 2018-08-30 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:48 --> Form Validation Class Initialized
INFO - 2018-08-30 15:02:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-30 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:48 --> Config Class Initialized
INFO - 2018-08-30 15:02:48 --> Hooks Class Initialized
DEBUG - 2018-08-30 15:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-30 15:02:48 --> Utf8 Class Initialized
INFO - 2018-08-30 15:02:48 --> URI Class Initialized
INFO - 2018-08-30 15:02:48 --> Router Class Initialized
INFO - 2018-08-30 15:02:48 --> Output Class Initialized
INFO - 2018-08-30 15:02:48 --> Security Class Initialized
DEBUG - 2018-08-30 15:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-30 15:02:48 --> CSRF cookie sent
INFO - 2018-08-30 15:02:48 --> Input Class Initialized
INFO - 2018-08-30 15:02:48 --> Language Class Initialized
INFO - 2018-08-30 15:02:48 --> Loader Class Initialized
INFO - 2018-08-30 15:02:48 --> Helper loaded: url_helper
INFO - 2018-08-30 15:02:48 --> Helper loaded: form_helper
INFO - 2018-08-30 15:02:48 --> Helper loaded: language_helper
DEBUG - 2018-08-30 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-30 15:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-30 15:02:48 --> User Agent Class Initialized
INFO - 2018-08-30 15:02:48 --> Controller Class Initialized
INFO - 2018-08-30 15:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-30 15:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-30 15:02:48 --> Pixel_Model class loaded
INFO - 2018-08-30 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:48 --> Database Driver Class Initialized
INFO - 2018-08-30 15:02:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-30 15:02:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-30 15:02:48 --> Final output sent to browser
DEBUG - 2018-08-30 15:02:48 --> Total execution time: 0.0624

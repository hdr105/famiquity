<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-10 02:01:14 --> Config Class Initialized
INFO - 2018-09-10 02:01:14 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:14 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:14 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:14 --> URI Class Initialized
DEBUG - 2018-09-10 02:01:14 --> No URI present. Default controller set.
INFO - 2018-09-10 02:01:14 --> Router Class Initialized
INFO - 2018-09-10 02:01:14 --> Output Class Initialized
INFO - 2018-09-10 02:01:14 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:14 --> CSRF cookie sent
INFO - 2018-09-10 02:01:14 --> Input Class Initialized
INFO - 2018-09-10 02:01:14 --> Language Class Initialized
INFO - 2018-09-10 02:01:14 --> Loader Class Initialized
INFO - 2018-09-10 02:01:14 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:14 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:14 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:14 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:14 --> Controller Class Initialized
INFO - 2018-09-10 02:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:14 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:14 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-10 02:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:14 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:14 --> Total execution time: 0.0440
INFO - 2018-09-10 02:01:19 --> Config Class Initialized
INFO - 2018-09-10 02:01:19 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:19 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:19 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:19 --> URI Class Initialized
INFO - 2018-09-10 02:01:19 --> Router Class Initialized
INFO - 2018-09-10 02:01:19 --> Output Class Initialized
INFO - 2018-09-10 02:01:19 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:19 --> CSRF cookie sent
INFO - 2018-09-10 02:01:19 --> CSRF token verified
INFO - 2018-09-10 02:01:19 --> Input Class Initialized
INFO - 2018-09-10 02:01:19 --> Language Class Initialized
INFO - 2018-09-10 02:01:19 --> Loader Class Initialized
INFO - 2018-09-10 02:01:19 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:19 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:19 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:19 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:19 --> Controller Class Initialized
INFO - 2018-09-10 02:01:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:19 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:19 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:19 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:19 --> Config Class Initialized
INFO - 2018-09-10 02:01:19 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:19 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:19 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:19 --> URI Class Initialized
INFO - 2018-09-10 02:01:19 --> Router Class Initialized
INFO - 2018-09-10 02:01:19 --> Output Class Initialized
INFO - 2018-09-10 02:01:19 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:19 --> CSRF cookie sent
INFO - 2018-09-10 02:01:19 --> Input Class Initialized
INFO - 2018-09-10 02:01:19 --> Language Class Initialized
INFO - 2018-09-10 02:01:19 --> Loader Class Initialized
INFO - 2018-09-10 02:01:19 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:19 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:19 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:19 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:19 --> Controller Class Initialized
INFO - 2018-09-10 02:01:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:19 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:19 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:19 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-10 02:01:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:19 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:19 --> Total execution time: 0.0447
INFO - 2018-09-10 02:01:22 --> Config Class Initialized
INFO - 2018-09-10 02:01:22 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:22 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:22 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:22 --> URI Class Initialized
INFO - 2018-09-10 02:01:22 --> Router Class Initialized
INFO - 2018-09-10 02:01:22 --> Output Class Initialized
INFO - 2018-09-10 02:01:22 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:22 --> CSRF cookie sent
INFO - 2018-09-10 02:01:22 --> Input Class Initialized
INFO - 2018-09-10 02:01:22 --> Language Class Initialized
INFO - 2018-09-10 02:01:22 --> Loader Class Initialized
INFO - 2018-09-10 02:01:22 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:22 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:22 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:22 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:22 --> Controller Class Initialized
INFO - 2018-09-10 02:01:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:22 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-10 02:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:22 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:22 --> Total execution time: 0.0485
INFO - 2018-09-10 02:01:24 --> Config Class Initialized
INFO - 2018-09-10 02:01:24 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:24 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:24 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:24 --> URI Class Initialized
INFO - 2018-09-10 02:01:24 --> Router Class Initialized
INFO - 2018-09-10 02:01:24 --> Output Class Initialized
INFO - 2018-09-10 02:01:24 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:24 --> CSRF cookie sent
INFO - 2018-09-10 02:01:24 --> Input Class Initialized
INFO - 2018-09-10 02:01:24 --> Language Class Initialized
INFO - 2018-09-10 02:01:24 --> Loader Class Initialized
INFO - 2018-09-10 02:01:24 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:24 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:24 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:24 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:24 --> Controller Class Initialized
INFO - 2018-09-10 02:01:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:24 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:24 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:24 --> Model "RegistrationModel" initialized
DEBUG - 2018-09-10 02:01:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-10 02:01:24 --> Could not find the language line "req_email"
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-09-10 02:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:24 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:24 --> Total execution time: 0.0390
INFO - 2018-09-10 02:01:32 --> Config Class Initialized
INFO - 2018-09-10 02:01:32 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:32 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:32 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:32 --> URI Class Initialized
INFO - 2018-09-10 02:01:32 --> Router Class Initialized
INFO - 2018-09-10 02:01:32 --> Output Class Initialized
INFO - 2018-09-10 02:01:32 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:32 --> CSRF cookie sent
INFO - 2018-09-10 02:01:32 --> Input Class Initialized
INFO - 2018-09-10 02:01:32 --> Language Class Initialized
INFO - 2018-09-10 02:01:32 --> Loader Class Initialized
INFO - 2018-09-10 02:01:32 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:32 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:32 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:32 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:32 --> Controller Class Initialized
INFO - 2018-09-10 02:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:32 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-10 02:01:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:32 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:32 --> Total execution time: 0.0444
INFO - 2018-09-10 02:01:33 --> Config Class Initialized
INFO - 2018-09-10 02:01:33 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:33 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:33 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:33 --> URI Class Initialized
INFO - 2018-09-10 02:01:33 --> Router Class Initialized
INFO - 2018-09-10 02:01:33 --> Output Class Initialized
INFO - 2018-09-10 02:01:33 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:33 --> CSRF cookie sent
INFO - 2018-09-10 02:01:33 --> Input Class Initialized
INFO - 2018-09-10 02:01:33 --> Language Class Initialized
INFO - 2018-09-10 02:01:33 --> Loader Class Initialized
INFO - 2018-09-10 02:01:33 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:33 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:33 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:33 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:33 --> Controller Class Initialized
INFO - 2018-09-10 02:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:33 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:33 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:33 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-10 02:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:33 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:33 --> Total execution time: 0.0444
INFO - 2018-09-10 02:01:37 --> Config Class Initialized
INFO - 2018-09-10 02:01:37 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:37 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:37 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:37 --> URI Class Initialized
INFO - 2018-09-10 02:01:37 --> Router Class Initialized
INFO - 2018-09-10 02:01:37 --> Output Class Initialized
INFO - 2018-09-10 02:01:37 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:37 --> CSRF cookie sent
INFO - 2018-09-10 02:01:37 --> CSRF token verified
INFO - 2018-09-10 02:01:37 --> Input Class Initialized
INFO - 2018-09-10 02:01:37 --> Language Class Initialized
INFO - 2018-09-10 02:01:37 --> Loader Class Initialized
INFO - 2018-09-10 02:01:37 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:37 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:37 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:37 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:37 --> Controller Class Initialized
INFO - 2018-09-10 02:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:37 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:37 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:37 --> Form Validation Class Initialized
INFO - 2018-09-10 02:01:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:01:37 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:37 --> Config Class Initialized
INFO - 2018-09-10 02:01:37 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:37 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:37 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:37 --> URI Class Initialized
INFO - 2018-09-10 02:01:37 --> Router Class Initialized
INFO - 2018-09-10 02:01:37 --> Output Class Initialized
INFO - 2018-09-10 02:01:37 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:37 --> CSRF cookie sent
INFO - 2018-09-10 02:01:37 --> Input Class Initialized
INFO - 2018-09-10 02:01:37 --> Language Class Initialized
INFO - 2018-09-10 02:01:37 --> Loader Class Initialized
INFO - 2018-09-10 02:01:37 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:37 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:37 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:37 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:37 --> Controller Class Initialized
INFO - 2018-09-10 02:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:37 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:37 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:37 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-10 02:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:37 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:37 --> Total execution time: 0.0406
INFO - 2018-09-10 02:01:39 --> Config Class Initialized
INFO - 2018-09-10 02:01:39 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:39 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:39 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:39 --> URI Class Initialized
INFO - 2018-09-10 02:01:39 --> Router Class Initialized
INFO - 2018-09-10 02:01:39 --> Output Class Initialized
INFO - 2018-09-10 02:01:39 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:39 --> CSRF cookie sent
INFO - 2018-09-10 02:01:39 --> CSRF token verified
INFO - 2018-09-10 02:01:39 --> Input Class Initialized
INFO - 2018-09-10 02:01:39 --> Language Class Initialized
INFO - 2018-09-10 02:01:39 --> Loader Class Initialized
INFO - 2018-09-10 02:01:39 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:39 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:39 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:39 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:39 --> Controller Class Initialized
INFO - 2018-09-10 02:01:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:39 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:39 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:39 --> Form Validation Class Initialized
INFO - 2018-09-10 02:01:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:01:39 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:39 --> Config Class Initialized
INFO - 2018-09-10 02:01:39 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:39 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:39 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:39 --> URI Class Initialized
INFO - 2018-09-10 02:01:39 --> Router Class Initialized
INFO - 2018-09-10 02:01:39 --> Output Class Initialized
INFO - 2018-09-10 02:01:39 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:39 --> CSRF cookie sent
INFO - 2018-09-10 02:01:39 --> Input Class Initialized
INFO - 2018-09-10 02:01:39 --> Language Class Initialized
INFO - 2018-09-10 02:01:39 --> Loader Class Initialized
INFO - 2018-09-10 02:01:39 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:39 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:39 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:39 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:39 --> Controller Class Initialized
INFO - 2018-09-10 02:01:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:39 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:39 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:39 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-10 02:01:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:39 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:39 --> Total execution time: 0.0408
INFO - 2018-09-10 02:01:44 --> Config Class Initialized
INFO - 2018-09-10 02:01:44 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:44 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:44 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:44 --> URI Class Initialized
INFO - 2018-09-10 02:01:44 --> Router Class Initialized
INFO - 2018-09-10 02:01:44 --> Output Class Initialized
INFO - 2018-09-10 02:01:44 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:44 --> CSRF cookie sent
INFO - 2018-09-10 02:01:44 --> CSRF token verified
INFO - 2018-09-10 02:01:44 --> Input Class Initialized
INFO - 2018-09-10 02:01:44 --> Language Class Initialized
INFO - 2018-09-10 02:01:44 --> Loader Class Initialized
INFO - 2018-09-10 02:01:44 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:44 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:44 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:44 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:44 --> Controller Class Initialized
INFO - 2018-09-10 02:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:44 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:44 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:44 --> Form Validation Class Initialized
INFO - 2018-09-10 02:01:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:01:44 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:44 --> Config Class Initialized
INFO - 2018-09-10 02:01:44 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:44 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:44 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:44 --> URI Class Initialized
INFO - 2018-09-10 02:01:44 --> Router Class Initialized
INFO - 2018-09-10 02:01:44 --> Output Class Initialized
INFO - 2018-09-10 02:01:44 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:44 --> CSRF cookie sent
INFO - 2018-09-10 02:01:44 --> Input Class Initialized
INFO - 2018-09-10 02:01:44 --> Language Class Initialized
INFO - 2018-09-10 02:01:44 --> Loader Class Initialized
INFO - 2018-09-10 02:01:44 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:44 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:44 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:44 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:44 --> Controller Class Initialized
INFO - 2018-09-10 02:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:44 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:44 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:44 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-10 02:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:44 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:44 --> Total execution time: 0.0337
INFO - 2018-09-10 02:01:55 --> Config Class Initialized
INFO - 2018-09-10 02:01:55 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:55 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:55 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:55 --> URI Class Initialized
INFO - 2018-09-10 02:01:55 --> Router Class Initialized
INFO - 2018-09-10 02:01:55 --> Output Class Initialized
INFO - 2018-09-10 02:01:55 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:55 --> CSRF cookie sent
INFO - 2018-09-10 02:01:55 --> CSRF token verified
INFO - 2018-09-10 02:01:55 --> Input Class Initialized
INFO - 2018-09-10 02:01:55 --> Language Class Initialized
INFO - 2018-09-10 02:01:55 --> Loader Class Initialized
INFO - 2018-09-10 02:01:55 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:55 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:55 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:55 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:55 --> Controller Class Initialized
INFO - 2018-09-10 02:01:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:55 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:55 --> Form Validation Class Initialized
INFO - 2018-09-10 02:01:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:01:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:55 --> Config Class Initialized
INFO - 2018-09-10 02:01:55 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:01:55 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:01:55 --> Utf8 Class Initialized
INFO - 2018-09-10 02:01:55 --> URI Class Initialized
INFO - 2018-09-10 02:01:55 --> Router Class Initialized
INFO - 2018-09-10 02:01:55 --> Output Class Initialized
INFO - 2018-09-10 02:01:55 --> Security Class Initialized
DEBUG - 2018-09-10 02:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:01:55 --> CSRF cookie sent
INFO - 2018-09-10 02:01:55 --> Input Class Initialized
INFO - 2018-09-10 02:01:55 --> Language Class Initialized
INFO - 2018-09-10 02:01:55 --> Loader Class Initialized
INFO - 2018-09-10 02:01:55 --> Helper loaded: url_helper
INFO - 2018-09-10 02:01:55 --> Helper loaded: form_helper
INFO - 2018-09-10 02:01:55 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:01:55 --> User Agent Class Initialized
INFO - 2018-09-10 02:01:55 --> Controller Class Initialized
INFO - 2018-09-10 02:01:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:01:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:01:55 --> Pixel_Model class loaded
INFO - 2018-09-10 02:01:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-10 02:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:01:55 --> Final output sent to browser
DEBUG - 2018-09-10 02:01:55 --> Total execution time: 0.0482
INFO - 2018-09-10 02:02:07 --> Config Class Initialized
INFO - 2018-09-10 02:02:07 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:07 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:07 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:07 --> URI Class Initialized
INFO - 2018-09-10 02:02:07 --> Router Class Initialized
INFO - 2018-09-10 02:02:07 --> Output Class Initialized
INFO - 2018-09-10 02:02:07 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:07 --> CSRF cookie sent
INFO - 2018-09-10 02:02:07 --> CSRF token verified
INFO - 2018-09-10 02:02:07 --> Input Class Initialized
INFO - 2018-09-10 02:02:07 --> Language Class Initialized
INFO - 2018-09-10 02:02:07 --> Loader Class Initialized
INFO - 2018-09-10 02:02:07 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:07 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:07 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:07 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:07 --> Controller Class Initialized
INFO - 2018-09-10 02:02:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:07 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:07 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:07 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:07 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:07 --> Config Class Initialized
INFO - 2018-09-10 02:02:07 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:07 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:07 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:07 --> URI Class Initialized
INFO - 2018-09-10 02:02:07 --> Router Class Initialized
INFO - 2018-09-10 02:02:07 --> Output Class Initialized
INFO - 2018-09-10 02:02:07 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:07 --> CSRF cookie sent
INFO - 2018-09-10 02:02:07 --> Input Class Initialized
INFO - 2018-09-10 02:02:07 --> Language Class Initialized
INFO - 2018-09-10 02:02:07 --> Loader Class Initialized
INFO - 2018-09-10 02:02:07 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:07 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:07 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:07 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:07 --> Controller Class Initialized
INFO - 2018-09-10 02:02:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:07 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:07 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:07 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-10 02:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:07 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:07 --> Total execution time: 0.0416
INFO - 2018-09-10 02:02:22 --> Config Class Initialized
INFO - 2018-09-10 02:02:22 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:22 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:22 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:22 --> URI Class Initialized
INFO - 2018-09-10 02:02:22 --> Router Class Initialized
INFO - 2018-09-10 02:02:22 --> Output Class Initialized
INFO - 2018-09-10 02:02:22 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:22 --> CSRF cookie sent
INFO - 2018-09-10 02:02:22 --> CSRF token verified
INFO - 2018-09-10 02:02:22 --> Input Class Initialized
INFO - 2018-09-10 02:02:22 --> Language Class Initialized
INFO - 2018-09-10 02:02:22 --> Loader Class Initialized
INFO - 2018-09-10 02:02:22 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:22 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:22 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:22 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:22 --> Controller Class Initialized
INFO - 2018-09-10 02:02:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:22 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:22 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:22 --> Config Class Initialized
INFO - 2018-09-10 02:02:22 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:22 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:22 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:22 --> URI Class Initialized
INFO - 2018-09-10 02:02:22 --> Router Class Initialized
INFO - 2018-09-10 02:02:22 --> Output Class Initialized
INFO - 2018-09-10 02:02:22 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:22 --> CSRF cookie sent
INFO - 2018-09-10 02:02:22 --> Input Class Initialized
INFO - 2018-09-10 02:02:22 --> Language Class Initialized
INFO - 2018-09-10 02:02:22 --> Loader Class Initialized
INFO - 2018-09-10 02:02:22 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:22 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:22 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:22 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:22 --> Controller Class Initialized
INFO - 2018-09-10 02:02:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:22 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:22 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-10 02:02:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:22 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:22 --> Total execution time: 0.0383
INFO - 2018-09-10 02:02:32 --> Config Class Initialized
INFO - 2018-09-10 02:02:32 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:32 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:32 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:32 --> URI Class Initialized
INFO - 2018-09-10 02:02:32 --> Router Class Initialized
INFO - 2018-09-10 02:02:32 --> Output Class Initialized
INFO - 2018-09-10 02:02:32 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:32 --> CSRF cookie sent
INFO - 2018-09-10 02:02:32 --> CSRF token verified
INFO - 2018-09-10 02:02:32 --> Input Class Initialized
INFO - 2018-09-10 02:02:32 --> Language Class Initialized
INFO - 2018-09-10 02:02:32 --> Loader Class Initialized
INFO - 2018-09-10 02:02:32 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:32 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:32 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:32 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:32 --> Controller Class Initialized
INFO - 2018-09-10 02:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:32 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:32 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:32 --> Config Class Initialized
INFO - 2018-09-10 02:02:32 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:32 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:32 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:32 --> URI Class Initialized
INFO - 2018-09-10 02:02:32 --> Router Class Initialized
INFO - 2018-09-10 02:02:32 --> Output Class Initialized
INFO - 2018-09-10 02:02:32 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:32 --> CSRF cookie sent
INFO - 2018-09-10 02:02:32 --> Input Class Initialized
INFO - 2018-09-10 02:02:32 --> Language Class Initialized
INFO - 2018-09-10 02:02:32 --> Loader Class Initialized
INFO - 2018-09-10 02:02:32 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:32 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:32 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:32 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:32 --> Controller Class Initialized
INFO - 2018-09-10 02:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:32 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:32 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-10 02:02:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:32 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:32 --> Total execution time: 0.0427
INFO - 2018-09-10 02:02:41 --> Config Class Initialized
INFO - 2018-09-10 02:02:41 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:41 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:41 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:41 --> URI Class Initialized
INFO - 2018-09-10 02:02:41 --> Router Class Initialized
INFO - 2018-09-10 02:02:41 --> Output Class Initialized
INFO - 2018-09-10 02:02:41 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:41 --> CSRF cookie sent
INFO - 2018-09-10 02:02:41 --> CSRF token verified
INFO - 2018-09-10 02:02:41 --> Input Class Initialized
INFO - 2018-09-10 02:02:41 --> Language Class Initialized
INFO - 2018-09-10 02:02:41 --> Loader Class Initialized
INFO - 2018-09-10 02:02:41 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:41 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:41 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:41 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:41 --> Controller Class Initialized
INFO - 2018-09-10 02:02:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:41 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:41 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:41 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:41 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:41 --> Config Class Initialized
INFO - 2018-09-10 02:02:41 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:41 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:41 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:41 --> URI Class Initialized
INFO - 2018-09-10 02:02:41 --> Router Class Initialized
INFO - 2018-09-10 02:02:41 --> Output Class Initialized
INFO - 2018-09-10 02:02:41 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:41 --> CSRF cookie sent
INFO - 2018-09-10 02:02:41 --> Input Class Initialized
INFO - 2018-09-10 02:02:41 --> Language Class Initialized
INFO - 2018-09-10 02:02:41 --> Loader Class Initialized
INFO - 2018-09-10 02:02:41 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:41 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:41 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:41 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:41 --> Controller Class Initialized
INFO - 2018-09-10 02:02:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:41 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:41 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:41 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-10 02:02:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:41 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:41 --> Total execution time: 0.0397
INFO - 2018-09-10 02:02:46 --> Config Class Initialized
INFO - 2018-09-10 02:02:46 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:46 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:46 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:46 --> URI Class Initialized
INFO - 2018-09-10 02:02:46 --> Router Class Initialized
INFO - 2018-09-10 02:02:46 --> Output Class Initialized
INFO - 2018-09-10 02:02:46 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:46 --> CSRF cookie sent
INFO - 2018-09-10 02:02:46 --> CSRF token verified
INFO - 2018-09-10 02:02:46 --> Input Class Initialized
INFO - 2018-09-10 02:02:46 --> Language Class Initialized
INFO - 2018-09-10 02:02:46 --> Loader Class Initialized
INFO - 2018-09-10 02:02:46 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:46 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:46 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:46 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:46 --> Controller Class Initialized
INFO - 2018-09-10 02:02:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:46 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:46 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:46 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:46 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:46 --> Config Class Initialized
INFO - 2018-09-10 02:02:46 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:46 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:46 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:46 --> URI Class Initialized
INFO - 2018-09-10 02:02:46 --> Router Class Initialized
INFO - 2018-09-10 02:02:46 --> Output Class Initialized
INFO - 2018-09-10 02:02:46 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:46 --> CSRF cookie sent
INFO - 2018-09-10 02:02:46 --> Input Class Initialized
INFO - 2018-09-10 02:02:46 --> Language Class Initialized
INFO - 2018-09-10 02:02:46 --> Loader Class Initialized
INFO - 2018-09-10 02:02:46 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:46 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:46 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:46 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:46 --> Controller Class Initialized
INFO - 2018-09-10 02:02:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:46 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:46 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:46 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-10 02:02:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:46 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:46 --> Total execution time: 0.0516
INFO - 2018-09-10 02:02:55 --> Config Class Initialized
INFO - 2018-09-10 02:02:55 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:55 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:55 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:55 --> URI Class Initialized
INFO - 2018-09-10 02:02:55 --> Router Class Initialized
INFO - 2018-09-10 02:02:55 --> Output Class Initialized
INFO - 2018-09-10 02:02:55 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:55 --> CSRF cookie sent
INFO - 2018-09-10 02:02:55 --> CSRF token verified
INFO - 2018-09-10 02:02:55 --> Input Class Initialized
INFO - 2018-09-10 02:02:55 --> Language Class Initialized
INFO - 2018-09-10 02:02:55 --> Loader Class Initialized
INFO - 2018-09-10 02:02:55 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:55 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:55 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:55 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:55 --> Controller Class Initialized
INFO - 2018-09-10 02:02:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:55 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:55 --> Form Validation Class Initialized
INFO - 2018-09-10 02:02:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:02:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:55 --> Config Class Initialized
INFO - 2018-09-10 02:02:55 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:02:55 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:02:55 --> Utf8 Class Initialized
INFO - 2018-09-10 02:02:55 --> URI Class Initialized
INFO - 2018-09-10 02:02:55 --> Router Class Initialized
INFO - 2018-09-10 02:02:55 --> Output Class Initialized
INFO - 2018-09-10 02:02:55 --> Security Class Initialized
DEBUG - 2018-09-10 02:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:02:55 --> CSRF cookie sent
INFO - 2018-09-10 02:02:55 --> Input Class Initialized
INFO - 2018-09-10 02:02:55 --> Language Class Initialized
INFO - 2018-09-10 02:02:55 --> Loader Class Initialized
INFO - 2018-09-10 02:02:55 --> Helper loaded: url_helper
INFO - 2018-09-10 02:02:55 --> Helper loaded: form_helper
INFO - 2018-09-10 02:02:55 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:02:55 --> User Agent Class Initialized
INFO - 2018-09-10 02:02:55 --> Controller Class Initialized
INFO - 2018-09-10 02:02:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:02:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:02:55 --> Pixel_Model class loaded
INFO - 2018-09-10 02:02:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:55 --> Database Driver Class Initialized
INFO - 2018-09-10 02:02:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-10 02:02:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:02:55 --> Final output sent to browser
DEBUG - 2018-09-10 02:02:55 --> Total execution time: 0.0644
INFO - 2018-09-10 02:03:04 --> Config Class Initialized
INFO - 2018-09-10 02:03:04 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:03:04 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:03:04 --> Utf8 Class Initialized
INFO - 2018-09-10 02:03:04 --> URI Class Initialized
INFO - 2018-09-10 02:03:04 --> Router Class Initialized
INFO - 2018-09-10 02:03:04 --> Output Class Initialized
INFO - 2018-09-10 02:03:04 --> Security Class Initialized
DEBUG - 2018-09-10 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:03:04 --> CSRF cookie sent
INFO - 2018-09-10 02:03:04 --> CSRF token verified
INFO - 2018-09-10 02:03:04 --> Input Class Initialized
INFO - 2018-09-10 02:03:04 --> Language Class Initialized
INFO - 2018-09-10 02:03:04 --> Loader Class Initialized
INFO - 2018-09-10 02:03:04 --> Helper loaded: url_helper
INFO - 2018-09-10 02:03:04 --> Helper loaded: form_helper
INFO - 2018-09-10 02:03:04 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:03:04 --> User Agent Class Initialized
INFO - 2018-09-10 02:03:04 --> Controller Class Initialized
INFO - 2018-09-10 02:03:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:03:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:03:04 --> Pixel_Model class loaded
INFO - 2018-09-10 02:03:04 --> Database Driver Class Initialized
INFO - 2018-09-10 02:03:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:03:05 --> Form Validation Class Initialized
INFO - 2018-09-10 02:03:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 02:03:05 --> Database Driver Class Initialized
INFO - 2018-09-10 02:03:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:03:05 --> Config Class Initialized
INFO - 2018-09-10 02:03:05 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:03:05 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:03:05 --> Utf8 Class Initialized
INFO - 2018-09-10 02:03:05 --> URI Class Initialized
INFO - 2018-09-10 02:03:05 --> Router Class Initialized
INFO - 2018-09-10 02:03:05 --> Output Class Initialized
INFO - 2018-09-10 02:03:05 --> Security Class Initialized
DEBUG - 2018-09-10 02:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:03:05 --> CSRF cookie sent
INFO - 2018-09-10 02:03:05 --> Input Class Initialized
INFO - 2018-09-10 02:03:05 --> Language Class Initialized
INFO - 2018-09-10 02:03:05 --> Loader Class Initialized
INFO - 2018-09-10 02:03:05 --> Helper loaded: url_helper
INFO - 2018-09-10 02:03:05 --> Helper loaded: form_helper
INFO - 2018-09-10 02:03:05 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:03:05 --> User Agent Class Initialized
INFO - 2018-09-10 02:03:05 --> Controller Class Initialized
INFO - 2018-09-10 02:03:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:03:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 02:03:05 --> Pixel_Model class loaded
INFO - 2018-09-10 02:03:05 --> Database Driver Class Initialized
INFO - 2018-09-10 02:03:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 02:03:05 --> Config Class Initialized
INFO - 2018-09-10 02:03:05 --> Hooks Class Initialized
DEBUG - 2018-09-10 02:03:05 --> UTF-8 Support Enabled
INFO - 2018-09-10 02:03:05 --> Utf8 Class Initialized
INFO - 2018-09-10 02:03:05 --> URI Class Initialized
INFO - 2018-09-10 02:03:05 --> Router Class Initialized
INFO - 2018-09-10 02:03:05 --> Output Class Initialized
INFO - 2018-09-10 02:03:05 --> Security Class Initialized
DEBUG - 2018-09-10 02:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 02:03:05 --> CSRF cookie sent
INFO - 2018-09-10 02:03:05 --> Input Class Initialized
INFO - 2018-09-10 02:03:05 --> Language Class Initialized
INFO - 2018-09-10 02:03:05 --> Loader Class Initialized
INFO - 2018-09-10 02:03:05 --> Helper loaded: url_helper
INFO - 2018-09-10 02:03:05 --> Helper loaded: form_helper
INFO - 2018-09-10 02:03:05 --> Helper loaded: language_helper
DEBUG - 2018-09-10 02:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 02:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 02:03:05 --> User Agent Class Initialized
INFO - 2018-09-10 02:03:05 --> Controller Class Initialized
INFO - 2018-09-10 02:03:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 02:03:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-10 02:03:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-10 02:03:05 --> Could not find the language line "req_email"
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-10 02:03:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 02:03:05 --> Final output sent to browser
DEBUG - 2018-09-10 02:03:05 --> Total execution time: 0.0230
INFO - 2018-09-10 14:47:59 --> Config Class Initialized
INFO - 2018-09-10 14:47:59 --> Hooks Class Initialized
DEBUG - 2018-09-10 14:47:59 --> UTF-8 Support Enabled
INFO - 2018-09-10 14:47:59 --> Utf8 Class Initialized
INFO - 2018-09-10 14:47:59 --> URI Class Initialized
DEBUG - 2018-09-10 14:47:59 --> No URI present. Default controller set.
INFO - 2018-09-10 14:47:59 --> Router Class Initialized
INFO - 2018-09-10 14:47:59 --> Output Class Initialized
INFO - 2018-09-10 14:47:59 --> Security Class Initialized
DEBUG - 2018-09-10 14:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 14:47:59 --> CSRF cookie sent
INFO - 2018-09-10 14:47:59 --> Input Class Initialized
INFO - 2018-09-10 14:47:59 --> Language Class Initialized
INFO - 2018-09-10 14:47:59 --> Loader Class Initialized
INFO - 2018-09-10 14:47:59 --> Helper loaded: url_helper
INFO - 2018-09-10 14:47:59 --> Helper loaded: form_helper
INFO - 2018-09-10 14:47:59 --> Helper loaded: language_helper
DEBUG - 2018-09-10 14:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 14:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 14:47:59 --> User Agent Class Initialized
INFO - 2018-09-10 14:47:59 --> Controller Class Initialized
INFO - 2018-09-10 14:47:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 14:47:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 14:47:59 --> Pixel_Model class loaded
INFO - 2018-09-10 14:47:59 --> Database Driver Class Initialized
INFO - 2018-09-10 14:47:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 14:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 14:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 14:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-10 14:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 14:47:59 --> Final output sent to browser
DEBUG - 2018-09-10 14:47:59 --> Total execution time: 0.0354
INFO - 2018-09-10 14:48:00 --> Config Class Initialized
INFO - 2018-09-10 14:48:00 --> Hooks Class Initialized
DEBUG - 2018-09-10 14:48:00 --> UTF-8 Support Enabled
INFO - 2018-09-10 14:48:00 --> Utf8 Class Initialized
INFO - 2018-09-10 14:48:00 --> URI Class Initialized
DEBUG - 2018-09-10 14:48:00 --> No URI present. Default controller set.
INFO - 2018-09-10 14:48:00 --> Router Class Initialized
INFO - 2018-09-10 14:48:00 --> Output Class Initialized
INFO - 2018-09-10 14:48:00 --> Security Class Initialized
DEBUG - 2018-09-10 14:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 14:48:00 --> CSRF cookie sent
INFO - 2018-09-10 14:48:00 --> Input Class Initialized
INFO - 2018-09-10 14:48:00 --> Language Class Initialized
INFO - 2018-09-10 14:48:00 --> Loader Class Initialized
INFO - 2018-09-10 14:48:00 --> Helper loaded: url_helper
INFO - 2018-09-10 14:48:00 --> Helper loaded: form_helper
INFO - 2018-09-10 14:48:00 --> Helper loaded: language_helper
DEBUG - 2018-09-10 14:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 14:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 14:48:00 --> User Agent Class Initialized
INFO - 2018-09-10 14:48:00 --> Controller Class Initialized
INFO - 2018-09-10 14:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 14:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 14:48:00 --> Pixel_Model class loaded
INFO - 2018-09-10 14:48:00 --> Database Driver Class Initialized
INFO - 2018-09-10 14:48:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 14:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 14:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 14:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-10 14:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 14:48:00 --> Final output sent to browser
DEBUG - 2018-09-10 14:48:00 --> Total execution time: 0.0291
INFO - 2018-09-10 22:09:41 --> Config Class Initialized
INFO - 2018-09-10 22:09:41 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:09:41 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:09:41 --> Utf8 Class Initialized
INFO - 2018-09-10 22:09:41 --> URI Class Initialized
DEBUG - 2018-09-10 22:09:41 --> No URI present. Default controller set.
INFO - 2018-09-10 22:09:41 --> Router Class Initialized
INFO - 2018-09-10 22:09:41 --> Output Class Initialized
INFO - 2018-09-10 22:09:41 --> Security Class Initialized
DEBUG - 2018-09-10 22:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:09:41 --> CSRF cookie sent
INFO - 2018-09-10 22:09:41 --> Input Class Initialized
INFO - 2018-09-10 22:09:41 --> Language Class Initialized
INFO - 2018-09-10 22:09:41 --> Loader Class Initialized
INFO - 2018-09-10 22:09:41 --> Helper loaded: url_helper
INFO - 2018-09-10 22:09:41 --> Helper loaded: form_helper
INFO - 2018-09-10 22:09:41 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:09:41 --> User Agent Class Initialized
INFO - 2018-09-10 22:09:41 --> Controller Class Initialized
INFO - 2018-09-10 22:09:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:09:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:09:41 --> Pixel_Model class loaded
INFO - 2018-09-10 22:09:41 --> Database Driver Class Initialized
INFO - 2018-09-10 22:09:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-10 22:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:09:41 --> Final output sent to browser
DEBUG - 2018-09-10 22:09:41 --> Total execution time: 0.0520
INFO - 2018-09-10 22:14:06 --> Config Class Initialized
INFO - 2018-09-10 22:14:06 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:14:06 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:14:06 --> Utf8 Class Initialized
INFO - 2018-09-10 22:14:06 --> URI Class Initialized
DEBUG - 2018-09-10 22:14:06 --> No URI present. Default controller set.
INFO - 2018-09-10 22:14:06 --> Router Class Initialized
INFO - 2018-09-10 22:14:06 --> Output Class Initialized
INFO - 2018-09-10 22:14:06 --> Security Class Initialized
DEBUG - 2018-09-10 22:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:14:06 --> CSRF cookie sent
INFO - 2018-09-10 22:14:06 --> Input Class Initialized
INFO - 2018-09-10 22:14:06 --> Language Class Initialized
INFO - 2018-09-10 22:14:06 --> Loader Class Initialized
INFO - 2018-09-10 22:14:06 --> Helper loaded: url_helper
INFO - 2018-09-10 22:14:06 --> Helper loaded: form_helper
INFO - 2018-09-10 22:14:06 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:14:06 --> User Agent Class Initialized
INFO - 2018-09-10 22:14:06 --> Controller Class Initialized
INFO - 2018-09-10 22:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:14:06 --> Pixel_Model class loaded
INFO - 2018-09-10 22:14:06 --> Database Driver Class Initialized
INFO - 2018-09-10 22:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-10 22:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:14:06 --> Final output sent to browser
DEBUG - 2018-09-10 22:14:06 --> Total execution time: 0.0381
INFO - 2018-09-10 22:14:33 --> Config Class Initialized
INFO - 2018-09-10 22:14:33 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:14:33 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:14:33 --> Utf8 Class Initialized
INFO - 2018-09-10 22:14:33 --> URI Class Initialized
INFO - 2018-09-10 22:14:33 --> Router Class Initialized
INFO - 2018-09-10 22:14:33 --> Output Class Initialized
INFO - 2018-09-10 22:14:33 --> Security Class Initialized
DEBUG - 2018-09-10 22:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:14:33 --> CSRF cookie sent
INFO - 2018-09-10 22:14:33 --> Input Class Initialized
INFO - 2018-09-10 22:14:33 --> Language Class Initialized
INFO - 2018-09-10 22:14:33 --> Loader Class Initialized
INFO - 2018-09-10 22:14:33 --> Helper loaded: url_helper
INFO - 2018-09-10 22:14:33 --> Helper loaded: form_helper
INFO - 2018-09-10 22:14:33 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:14:33 --> User Agent Class Initialized
INFO - 2018-09-10 22:14:33 --> Controller Class Initialized
INFO - 2018-09-10 22:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:14:33 --> Pixel_Model class loaded
INFO - 2018-09-10 22:14:33 --> Database Driver Class Initialized
INFO - 2018-09-10 22:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-10 22:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:14:33 --> Final output sent to browser
DEBUG - 2018-09-10 22:14:33 --> Total execution time: 0.0532
INFO - 2018-09-10 22:15:45 --> Config Class Initialized
INFO - 2018-09-10 22:15:45 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:15:45 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:15:45 --> Utf8 Class Initialized
INFO - 2018-09-10 22:15:45 --> URI Class Initialized
INFO - 2018-09-10 22:15:45 --> Router Class Initialized
INFO - 2018-09-10 22:15:45 --> Output Class Initialized
INFO - 2018-09-10 22:15:45 --> Security Class Initialized
DEBUG - 2018-09-10 22:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:15:45 --> CSRF cookie sent
INFO - 2018-09-10 22:15:45 --> CSRF token verified
INFO - 2018-09-10 22:15:45 --> Input Class Initialized
INFO - 2018-09-10 22:15:45 --> Language Class Initialized
INFO - 2018-09-10 22:15:45 --> Loader Class Initialized
INFO - 2018-09-10 22:15:45 --> Helper loaded: url_helper
INFO - 2018-09-10 22:15:45 --> Helper loaded: form_helper
INFO - 2018-09-10 22:15:45 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:15:45 --> User Agent Class Initialized
INFO - 2018-09-10 22:15:45 --> Controller Class Initialized
INFO - 2018-09-10 22:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:15:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:15:45 --> Pixel_Model class loaded
INFO - 2018-09-10 22:15:45 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:45 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:45 --> Config Class Initialized
INFO - 2018-09-10 22:15:45 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:15:45 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:15:45 --> Utf8 Class Initialized
INFO - 2018-09-10 22:15:45 --> URI Class Initialized
INFO - 2018-09-10 22:15:45 --> Router Class Initialized
INFO - 2018-09-10 22:15:45 --> Output Class Initialized
INFO - 2018-09-10 22:15:45 --> Security Class Initialized
DEBUG - 2018-09-10 22:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:15:45 --> CSRF cookie sent
INFO - 2018-09-10 22:15:45 --> Input Class Initialized
INFO - 2018-09-10 22:15:45 --> Language Class Initialized
INFO - 2018-09-10 22:15:45 --> Loader Class Initialized
INFO - 2018-09-10 22:15:45 --> Helper loaded: url_helper
INFO - 2018-09-10 22:15:45 --> Helper loaded: form_helper
INFO - 2018-09-10 22:15:45 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:15:45 --> User Agent Class Initialized
INFO - 2018-09-10 22:15:45 --> Controller Class Initialized
INFO - 2018-09-10 22:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:15:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:15:45 --> Pixel_Model class loaded
INFO - 2018-09-10 22:15:45 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:45 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-10 22:15:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:15:45 --> Final output sent to browser
DEBUG - 2018-09-10 22:15:45 --> Total execution time: 0.0482
INFO - 2018-09-10 22:15:58 --> Config Class Initialized
INFO - 2018-09-10 22:15:58 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:15:58 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:15:58 --> Utf8 Class Initialized
INFO - 2018-09-10 22:15:58 --> URI Class Initialized
INFO - 2018-09-10 22:15:58 --> Router Class Initialized
INFO - 2018-09-10 22:15:58 --> Output Class Initialized
INFO - 2018-09-10 22:15:58 --> Security Class Initialized
DEBUG - 2018-09-10 22:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:15:58 --> CSRF cookie sent
INFO - 2018-09-10 22:15:58 --> CSRF token verified
INFO - 2018-09-10 22:15:58 --> Input Class Initialized
INFO - 2018-09-10 22:15:58 --> Language Class Initialized
INFO - 2018-09-10 22:15:58 --> Loader Class Initialized
INFO - 2018-09-10 22:15:58 --> Helper loaded: url_helper
INFO - 2018-09-10 22:15:58 --> Helper loaded: form_helper
INFO - 2018-09-10 22:15:58 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:15:58 --> User Agent Class Initialized
INFO - 2018-09-10 22:15:58 --> Controller Class Initialized
INFO - 2018-09-10 22:15:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:15:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:15:58 --> Pixel_Model class loaded
INFO - 2018-09-10 22:15:58 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:58 --> Form Validation Class Initialized
INFO - 2018-09-10 22:15:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:15:58 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:59 --> Config Class Initialized
INFO - 2018-09-10 22:15:59 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:15:59 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:15:59 --> Utf8 Class Initialized
INFO - 2018-09-10 22:15:59 --> URI Class Initialized
INFO - 2018-09-10 22:15:59 --> Router Class Initialized
INFO - 2018-09-10 22:15:59 --> Output Class Initialized
INFO - 2018-09-10 22:15:59 --> Security Class Initialized
DEBUG - 2018-09-10 22:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:15:59 --> CSRF cookie sent
INFO - 2018-09-10 22:15:59 --> Input Class Initialized
INFO - 2018-09-10 22:15:59 --> Language Class Initialized
INFO - 2018-09-10 22:15:59 --> Loader Class Initialized
INFO - 2018-09-10 22:15:59 --> Helper loaded: url_helper
INFO - 2018-09-10 22:15:59 --> Helper loaded: form_helper
INFO - 2018-09-10 22:15:59 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:15:59 --> User Agent Class Initialized
INFO - 2018-09-10 22:15:59 --> Controller Class Initialized
INFO - 2018-09-10 22:15:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:15:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:15:59 --> Pixel_Model class loaded
INFO - 2018-09-10 22:15:59 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:59 --> Database Driver Class Initialized
INFO - 2018-09-10 22:15:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-10 22:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:15:59 --> Final output sent to browser
DEBUG - 2018-09-10 22:15:59 --> Total execution time: 0.0490
INFO - 2018-09-10 22:16:07 --> Config Class Initialized
INFO - 2018-09-10 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:07 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:07 --> URI Class Initialized
INFO - 2018-09-10 22:16:07 --> Router Class Initialized
INFO - 2018-09-10 22:16:07 --> Output Class Initialized
INFO - 2018-09-10 22:16:07 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:07 --> CSRF cookie sent
INFO - 2018-09-10 22:16:07 --> CSRF token verified
INFO - 2018-09-10 22:16:07 --> Input Class Initialized
INFO - 2018-09-10 22:16:07 --> Language Class Initialized
INFO - 2018-09-10 22:16:07 --> Loader Class Initialized
INFO - 2018-09-10 22:16:07 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:07 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:07 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:07 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:07 --> Controller Class Initialized
INFO - 2018-09-10 22:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:07 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:07 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:07 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:07 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:07 --> Config Class Initialized
INFO - 2018-09-10 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:07 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:07 --> URI Class Initialized
INFO - 2018-09-10 22:16:07 --> Router Class Initialized
INFO - 2018-09-10 22:16:07 --> Output Class Initialized
INFO - 2018-09-10 22:16:07 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:07 --> CSRF cookie sent
INFO - 2018-09-10 22:16:07 --> Input Class Initialized
INFO - 2018-09-10 22:16:07 --> Language Class Initialized
INFO - 2018-09-10 22:16:07 --> Loader Class Initialized
INFO - 2018-09-10 22:16:07 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:07 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:07 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:07 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:07 --> Controller Class Initialized
INFO - 2018-09-10 22:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:07 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:07 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:07 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-10 22:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:07 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:07 --> Total execution time: 0.0420
INFO - 2018-09-10 22:16:14 --> Config Class Initialized
INFO - 2018-09-10 22:16:14 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:14 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:14 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:14 --> URI Class Initialized
INFO - 2018-09-10 22:16:14 --> Router Class Initialized
INFO - 2018-09-10 22:16:14 --> Output Class Initialized
INFO - 2018-09-10 22:16:14 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:14 --> CSRF cookie sent
INFO - 2018-09-10 22:16:14 --> CSRF token verified
INFO - 2018-09-10 22:16:14 --> Input Class Initialized
INFO - 2018-09-10 22:16:14 --> Language Class Initialized
INFO - 2018-09-10 22:16:14 --> Loader Class Initialized
INFO - 2018-09-10 22:16:14 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:14 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:14 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:14 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:14 --> Controller Class Initialized
INFO - 2018-09-10 22:16:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:14 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:14 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:14 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:14 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:14 --> Config Class Initialized
INFO - 2018-09-10 22:16:14 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:14 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:14 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:14 --> URI Class Initialized
INFO - 2018-09-10 22:16:14 --> Router Class Initialized
INFO - 2018-09-10 22:16:14 --> Output Class Initialized
INFO - 2018-09-10 22:16:14 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:14 --> CSRF cookie sent
INFO - 2018-09-10 22:16:14 --> Input Class Initialized
INFO - 2018-09-10 22:16:14 --> Language Class Initialized
INFO - 2018-09-10 22:16:14 --> Loader Class Initialized
INFO - 2018-09-10 22:16:14 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:14 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:14 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:14 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:14 --> Controller Class Initialized
INFO - 2018-09-10 22:16:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:14 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:14 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:14 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-10 22:16:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:14 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:14 --> Total execution time: 0.0393
INFO - 2018-09-10 22:16:26 --> Config Class Initialized
INFO - 2018-09-10 22:16:26 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:26 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:26 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:26 --> URI Class Initialized
INFO - 2018-09-10 22:16:26 --> Router Class Initialized
INFO - 2018-09-10 22:16:26 --> Output Class Initialized
INFO - 2018-09-10 22:16:26 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:26 --> CSRF cookie sent
INFO - 2018-09-10 22:16:26 --> CSRF token verified
INFO - 2018-09-10 22:16:26 --> Input Class Initialized
INFO - 2018-09-10 22:16:26 --> Language Class Initialized
INFO - 2018-09-10 22:16:26 --> Loader Class Initialized
INFO - 2018-09-10 22:16:26 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:26 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:26 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:26 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:26 --> Controller Class Initialized
INFO - 2018-09-10 22:16:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:26 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:26 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:26 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:26 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:27 --> Config Class Initialized
INFO - 2018-09-10 22:16:27 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:27 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:27 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:27 --> URI Class Initialized
INFO - 2018-09-10 22:16:27 --> Router Class Initialized
INFO - 2018-09-10 22:16:27 --> Output Class Initialized
INFO - 2018-09-10 22:16:27 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:27 --> CSRF cookie sent
INFO - 2018-09-10 22:16:27 --> Input Class Initialized
INFO - 2018-09-10 22:16:27 --> Language Class Initialized
INFO - 2018-09-10 22:16:27 --> Loader Class Initialized
INFO - 2018-09-10 22:16:27 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:27 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:27 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:27 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:27 --> Controller Class Initialized
INFO - 2018-09-10 22:16:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:27 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:27 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:27 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-10 22:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:27 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:27 --> Total execution time: 0.0450
INFO - 2018-09-10 22:16:34 --> Config Class Initialized
INFO - 2018-09-10 22:16:34 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:34 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:34 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:34 --> URI Class Initialized
INFO - 2018-09-10 22:16:34 --> Router Class Initialized
INFO - 2018-09-10 22:16:34 --> Output Class Initialized
INFO - 2018-09-10 22:16:34 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:34 --> CSRF cookie sent
INFO - 2018-09-10 22:16:34 --> CSRF token verified
INFO - 2018-09-10 22:16:34 --> Input Class Initialized
INFO - 2018-09-10 22:16:34 --> Language Class Initialized
INFO - 2018-09-10 22:16:34 --> Loader Class Initialized
INFO - 2018-09-10 22:16:34 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:34 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:34 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:34 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:34 --> Controller Class Initialized
INFO - 2018-09-10 22:16:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:34 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:34 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:34 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:34 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:34 --> Config Class Initialized
INFO - 2018-09-10 22:16:34 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:34 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:34 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:34 --> URI Class Initialized
INFO - 2018-09-10 22:16:34 --> Router Class Initialized
INFO - 2018-09-10 22:16:34 --> Output Class Initialized
INFO - 2018-09-10 22:16:34 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:34 --> CSRF cookie sent
INFO - 2018-09-10 22:16:34 --> Input Class Initialized
INFO - 2018-09-10 22:16:34 --> Language Class Initialized
INFO - 2018-09-10 22:16:34 --> Loader Class Initialized
INFO - 2018-09-10 22:16:34 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:34 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:34 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:34 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:34 --> Controller Class Initialized
INFO - 2018-09-10 22:16:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:34 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:34 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:34 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-10 22:16:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:34 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:34 --> Total execution time: 0.0390
INFO - 2018-09-10 22:16:43 --> Config Class Initialized
INFO - 2018-09-10 22:16:43 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:43 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:43 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:43 --> URI Class Initialized
INFO - 2018-09-10 22:16:43 --> Router Class Initialized
INFO - 2018-09-10 22:16:43 --> Output Class Initialized
INFO - 2018-09-10 22:16:43 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:43 --> CSRF cookie sent
INFO - 2018-09-10 22:16:43 --> CSRF token verified
INFO - 2018-09-10 22:16:43 --> Input Class Initialized
INFO - 2018-09-10 22:16:43 --> Language Class Initialized
INFO - 2018-09-10 22:16:43 --> Loader Class Initialized
INFO - 2018-09-10 22:16:43 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:43 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:43 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:43 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:43 --> Controller Class Initialized
INFO - 2018-09-10 22:16:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:43 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:43 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:43 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:43 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:43 --> Config Class Initialized
INFO - 2018-09-10 22:16:43 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:43 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:43 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:43 --> URI Class Initialized
INFO - 2018-09-10 22:16:43 --> Router Class Initialized
INFO - 2018-09-10 22:16:43 --> Output Class Initialized
INFO - 2018-09-10 22:16:43 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:43 --> CSRF cookie sent
INFO - 2018-09-10 22:16:43 --> Input Class Initialized
INFO - 2018-09-10 22:16:43 --> Language Class Initialized
INFO - 2018-09-10 22:16:43 --> Loader Class Initialized
INFO - 2018-09-10 22:16:43 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:43 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:43 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:43 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:43 --> Controller Class Initialized
INFO - 2018-09-10 22:16:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:43 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:43 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:43 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-10 22:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:43 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:43 --> Total execution time: 0.0505
INFO - 2018-09-10 22:16:52 --> Config Class Initialized
INFO - 2018-09-10 22:16:52 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:52 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:52 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:52 --> URI Class Initialized
INFO - 2018-09-10 22:16:52 --> Router Class Initialized
INFO - 2018-09-10 22:16:52 --> Output Class Initialized
INFO - 2018-09-10 22:16:52 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:52 --> CSRF cookie sent
INFO - 2018-09-10 22:16:52 --> CSRF token verified
INFO - 2018-09-10 22:16:52 --> Input Class Initialized
INFO - 2018-09-10 22:16:52 --> Language Class Initialized
INFO - 2018-09-10 22:16:52 --> Loader Class Initialized
INFO - 2018-09-10 22:16:52 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:52 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:52 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:52 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:52 --> Controller Class Initialized
INFO - 2018-09-10 22:16:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:52 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:52 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:52 --> Form Validation Class Initialized
INFO - 2018-09-10 22:16:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:16:52 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:52 --> Config Class Initialized
INFO - 2018-09-10 22:16:52 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:16:52 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:16:52 --> Utf8 Class Initialized
INFO - 2018-09-10 22:16:52 --> URI Class Initialized
INFO - 2018-09-10 22:16:52 --> Router Class Initialized
INFO - 2018-09-10 22:16:52 --> Output Class Initialized
INFO - 2018-09-10 22:16:52 --> Security Class Initialized
DEBUG - 2018-09-10 22:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:16:52 --> CSRF cookie sent
INFO - 2018-09-10 22:16:52 --> Input Class Initialized
INFO - 2018-09-10 22:16:52 --> Language Class Initialized
INFO - 2018-09-10 22:16:52 --> Loader Class Initialized
INFO - 2018-09-10 22:16:53 --> Helper loaded: url_helper
INFO - 2018-09-10 22:16:53 --> Helper loaded: form_helper
INFO - 2018-09-10 22:16:53 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:16:53 --> User Agent Class Initialized
INFO - 2018-09-10 22:16:53 --> Controller Class Initialized
INFO - 2018-09-10 22:16:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:16:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:16:53 --> Pixel_Model class loaded
INFO - 2018-09-10 22:16:53 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:53 --> Database Driver Class Initialized
INFO - 2018-09-10 22:16:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-10 22:16:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:16:53 --> Final output sent to browser
DEBUG - 2018-09-10 22:16:53 --> Total execution time: 0.0681
INFO - 2018-09-10 22:17:02 --> Config Class Initialized
INFO - 2018-09-10 22:17:02 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:02 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:02 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:02 --> URI Class Initialized
INFO - 2018-09-10 22:17:02 --> Router Class Initialized
INFO - 2018-09-10 22:17:02 --> Output Class Initialized
INFO - 2018-09-10 22:17:02 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:02 --> CSRF cookie sent
INFO - 2018-09-10 22:17:02 --> CSRF token verified
INFO - 2018-09-10 22:17:02 --> Input Class Initialized
INFO - 2018-09-10 22:17:02 --> Language Class Initialized
INFO - 2018-09-10 22:17:02 --> Loader Class Initialized
INFO - 2018-09-10 22:17:02 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:02 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:02 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:02 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:02 --> Controller Class Initialized
INFO - 2018-09-10 22:17:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:02 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:02 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:02 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:02 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:02 --> Config Class Initialized
INFO - 2018-09-10 22:17:02 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:02 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:02 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:02 --> URI Class Initialized
INFO - 2018-09-10 22:17:02 --> Router Class Initialized
INFO - 2018-09-10 22:17:02 --> Output Class Initialized
INFO - 2018-09-10 22:17:02 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:02 --> CSRF cookie sent
INFO - 2018-09-10 22:17:02 --> Input Class Initialized
INFO - 2018-09-10 22:17:02 --> Language Class Initialized
INFO - 2018-09-10 22:17:03 --> Loader Class Initialized
INFO - 2018-09-10 22:17:03 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:03 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:03 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:03 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:03 --> Controller Class Initialized
INFO - 2018-09-10 22:17:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:03 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:03 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:03 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-10 22:17:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:03 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:03 --> Total execution time: 0.0531
INFO - 2018-09-10 22:17:05 --> Config Class Initialized
INFO - 2018-09-10 22:17:05 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:05 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:05 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:05 --> URI Class Initialized
INFO - 2018-09-10 22:17:05 --> Router Class Initialized
INFO - 2018-09-10 22:17:05 --> Output Class Initialized
INFO - 2018-09-10 22:17:05 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:05 --> CSRF cookie sent
INFO - 2018-09-10 22:17:05 --> CSRF token verified
INFO - 2018-09-10 22:17:05 --> Input Class Initialized
INFO - 2018-09-10 22:17:05 --> Language Class Initialized
INFO - 2018-09-10 22:17:05 --> Loader Class Initialized
INFO - 2018-09-10 22:17:05 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:05 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:05 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:05 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:05 --> Controller Class Initialized
INFO - 2018-09-10 22:17:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:05 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:05 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:05 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:05 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:05 --> Config Class Initialized
INFO - 2018-09-10 22:17:05 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:05 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:05 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:05 --> URI Class Initialized
INFO - 2018-09-10 22:17:05 --> Router Class Initialized
INFO - 2018-09-10 22:17:05 --> Output Class Initialized
INFO - 2018-09-10 22:17:05 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:05 --> CSRF cookie sent
INFO - 2018-09-10 22:17:05 --> Input Class Initialized
INFO - 2018-09-10 22:17:05 --> Language Class Initialized
INFO - 2018-09-10 22:17:05 --> Loader Class Initialized
INFO - 2018-09-10 22:17:05 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:05 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:05 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:05 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:05 --> Controller Class Initialized
INFO - 2018-09-10 22:17:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:05 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:05 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:05 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-10 22:17:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:05 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:05 --> Total execution time: 0.0457
INFO - 2018-09-10 22:17:06 --> Config Class Initialized
INFO - 2018-09-10 22:17:06 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:06 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:06 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:06 --> URI Class Initialized
INFO - 2018-09-10 22:17:06 --> Router Class Initialized
INFO - 2018-09-10 22:17:06 --> Output Class Initialized
INFO - 2018-09-10 22:17:06 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:06 --> CSRF cookie sent
INFO - 2018-09-10 22:17:06 --> CSRF token verified
INFO - 2018-09-10 22:17:06 --> Input Class Initialized
INFO - 2018-09-10 22:17:06 --> Language Class Initialized
INFO - 2018-09-10 22:17:06 --> Loader Class Initialized
INFO - 2018-09-10 22:17:06 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:06 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:06 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:06 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:06 --> Controller Class Initialized
INFO - 2018-09-10 22:17:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:06 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:06 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:06 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:06 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:06 --> Config Class Initialized
INFO - 2018-09-10 22:17:06 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:06 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:06 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:06 --> URI Class Initialized
INFO - 2018-09-10 22:17:06 --> Router Class Initialized
INFO - 2018-09-10 22:17:06 --> Output Class Initialized
INFO - 2018-09-10 22:17:06 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:06 --> CSRF cookie sent
INFO - 2018-09-10 22:17:06 --> Input Class Initialized
INFO - 2018-09-10 22:17:06 --> Language Class Initialized
INFO - 2018-09-10 22:17:06 --> Loader Class Initialized
INFO - 2018-09-10 22:17:06 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:06 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:06 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:06 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:06 --> Controller Class Initialized
INFO - 2018-09-10 22:17:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:06 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:06 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:06 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-10 22:17:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:06 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:06 --> Total execution time: 0.0477
INFO - 2018-09-10 22:17:15 --> Config Class Initialized
INFO - 2018-09-10 22:17:15 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:15 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:15 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:15 --> URI Class Initialized
INFO - 2018-09-10 22:17:15 --> Router Class Initialized
INFO - 2018-09-10 22:17:15 --> Output Class Initialized
INFO - 2018-09-10 22:17:15 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:15 --> CSRF cookie sent
INFO - 2018-09-10 22:17:15 --> CSRF token verified
INFO - 2018-09-10 22:17:15 --> Input Class Initialized
INFO - 2018-09-10 22:17:15 --> Language Class Initialized
INFO - 2018-09-10 22:17:15 --> Loader Class Initialized
INFO - 2018-09-10 22:17:15 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:15 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:15 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:15 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:15 --> Controller Class Initialized
INFO - 2018-09-10 22:17:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:15 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:15 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:15 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:15 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:15 --> Config Class Initialized
INFO - 2018-09-10 22:17:15 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:15 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:15 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:15 --> URI Class Initialized
INFO - 2018-09-10 22:17:15 --> Router Class Initialized
INFO - 2018-09-10 22:17:15 --> Output Class Initialized
INFO - 2018-09-10 22:17:15 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:15 --> CSRF cookie sent
INFO - 2018-09-10 22:17:15 --> Input Class Initialized
INFO - 2018-09-10 22:17:15 --> Language Class Initialized
INFO - 2018-09-10 22:17:16 --> Loader Class Initialized
INFO - 2018-09-10 22:17:16 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:16 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:16 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:16 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:16 --> Controller Class Initialized
INFO - 2018-09-10 22:17:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:16 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:16 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:16 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-09-10 22:17:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:16 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:16 --> Total execution time: 0.0466
INFO - 2018-09-10 22:17:17 --> Config Class Initialized
INFO - 2018-09-10 22:17:17 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:17 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:17 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:17 --> URI Class Initialized
INFO - 2018-09-10 22:17:17 --> Router Class Initialized
INFO - 2018-09-10 22:17:17 --> Output Class Initialized
INFO - 2018-09-10 22:17:17 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:17 --> CSRF cookie sent
INFO - 2018-09-10 22:17:17 --> CSRF token verified
INFO - 2018-09-10 22:17:17 --> Input Class Initialized
INFO - 2018-09-10 22:17:17 --> Language Class Initialized
INFO - 2018-09-10 22:17:17 --> Loader Class Initialized
INFO - 2018-09-10 22:17:17 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:17 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:17 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:17 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:17 --> Controller Class Initialized
INFO - 2018-09-10 22:17:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:17 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:17 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:17 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:17 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:17 --> Config Class Initialized
INFO - 2018-09-10 22:17:17 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:17 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:17 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:17 --> URI Class Initialized
INFO - 2018-09-10 22:17:17 --> Router Class Initialized
INFO - 2018-09-10 22:17:17 --> Output Class Initialized
INFO - 2018-09-10 22:17:17 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:17 --> CSRF cookie sent
INFO - 2018-09-10 22:17:17 --> Input Class Initialized
INFO - 2018-09-10 22:17:17 --> Language Class Initialized
INFO - 2018-09-10 22:17:17 --> Loader Class Initialized
INFO - 2018-09-10 22:17:17 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:17 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:17 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:17 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:17 --> Controller Class Initialized
INFO - 2018-09-10 22:17:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:17 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:17 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:17 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-10 22:17:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:17 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:17 --> Total execution time: 0.0481
INFO - 2018-09-10 22:17:18 --> Config Class Initialized
INFO - 2018-09-10 22:17:18 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:18 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:18 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:18 --> URI Class Initialized
INFO - 2018-09-10 22:17:18 --> Router Class Initialized
INFO - 2018-09-10 22:17:18 --> Output Class Initialized
INFO - 2018-09-10 22:17:18 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:18 --> CSRF cookie sent
INFO - 2018-09-10 22:17:18 --> CSRF token verified
INFO - 2018-09-10 22:17:18 --> Input Class Initialized
INFO - 2018-09-10 22:17:18 --> Language Class Initialized
INFO - 2018-09-10 22:17:18 --> Loader Class Initialized
INFO - 2018-09-10 22:17:18 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:18 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:18 --> Controller Class Initialized
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:18 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:18 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:18 --> Form Validation Class Initialized
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-10 22:17:18 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:18 --> Config Class Initialized
INFO - 2018-09-10 22:17:18 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:18 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:18 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:18 --> URI Class Initialized
INFO - 2018-09-10 22:17:18 --> Router Class Initialized
INFO - 2018-09-10 22:17:18 --> Output Class Initialized
INFO - 2018-09-10 22:17:18 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:18 --> CSRF cookie sent
INFO - 2018-09-10 22:17:18 --> Input Class Initialized
INFO - 2018-09-10 22:17:18 --> Language Class Initialized
INFO - 2018-09-10 22:17:18 --> Loader Class Initialized
INFO - 2018-09-10 22:17:18 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:18 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:18 --> Controller Class Initialized
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:18 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:18 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:18 --> Config Class Initialized
INFO - 2018-09-10 22:17:18 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:18 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:18 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:18 --> URI Class Initialized
INFO - 2018-09-10 22:17:18 --> Router Class Initialized
INFO - 2018-09-10 22:17:18 --> Output Class Initialized
INFO - 2018-09-10 22:17:18 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:18 --> CSRF cookie sent
INFO - 2018-09-10 22:17:18 --> Input Class Initialized
INFO - 2018-09-10 22:17:18 --> Language Class Initialized
INFO - 2018-09-10 22:17:18 --> Loader Class Initialized
INFO - 2018-09-10 22:17:18 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:18 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:18 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:18 --> Controller Class Initialized
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-10 22:17:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-10 22:17:18 --> Could not find the language line "req_email"
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-10 22:17:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:18 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:18 --> Total execution time: 0.0185
INFO - 2018-09-10 22:17:23 --> Config Class Initialized
INFO - 2018-09-10 22:17:23 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:23 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:23 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:23 --> URI Class Initialized
INFO - 2018-09-10 22:17:23 --> Router Class Initialized
INFO - 2018-09-10 22:17:23 --> Output Class Initialized
INFO - 2018-09-10 22:17:23 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:23 --> CSRF cookie sent
INFO - 2018-09-10 22:17:23 --> Input Class Initialized
INFO - 2018-09-10 22:17:23 --> Language Class Initialized
INFO - 2018-09-10 22:17:23 --> Loader Class Initialized
INFO - 2018-09-10 22:17:23 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:23 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:23 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:23 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:23 --> Controller Class Initialized
INFO - 2018-09-10 22:17:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:23 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:23 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-09-10 22:17:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-10 22:17:23 --> Could not find the language line "req_email"
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-09-10 22:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:23 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:23 --> Total execution time: 0.0417
INFO - 2018-09-10 22:17:28 --> Config Class Initialized
INFO - 2018-09-10 22:17:28 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:17:28 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:17:28 --> Utf8 Class Initialized
INFO - 2018-09-10 22:17:28 --> URI Class Initialized
INFO - 2018-09-10 22:17:28 --> Router Class Initialized
INFO - 2018-09-10 22:17:28 --> Output Class Initialized
INFO - 2018-09-10 22:17:28 --> Security Class Initialized
DEBUG - 2018-09-10 22:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:17:28 --> CSRF cookie sent
INFO - 2018-09-10 22:17:28 --> Input Class Initialized
INFO - 2018-09-10 22:17:28 --> Language Class Initialized
INFO - 2018-09-10 22:17:28 --> Loader Class Initialized
INFO - 2018-09-10 22:17:28 --> Helper loaded: url_helper
INFO - 2018-09-10 22:17:28 --> Helper loaded: form_helper
INFO - 2018-09-10 22:17:28 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:17:28 --> User Agent Class Initialized
INFO - 2018-09-10 22:17:28 --> Controller Class Initialized
INFO - 2018-09-10 22:17:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:17:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:17:28 --> Pixel_Model class loaded
INFO - 2018-09-10 22:17:28 --> Database Driver Class Initialized
INFO - 2018-09-10 22:17:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-10 22:17:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:17:28 --> Final output sent to browser
DEBUG - 2018-09-10 22:17:28 --> Total execution time: 0.0401
INFO - 2018-09-10 22:18:20 --> Config Class Initialized
INFO - 2018-09-10 22:18:20 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:18:20 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:18:20 --> Utf8 Class Initialized
INFO - 2018-09-10 22:18:20 --> URI Class Initialized
INFO - 2018-09-10 22:18:20 --> Router Class Initialized
INFO - 2018-09-10 22:18:20 --> Output Class Initialized
INFO - 2018-09-10 22:18:20 --> Security Class Initialized
DEBUG - 2018-09-10 22:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:18:20 --> CSRF cookie sent
INFO - 2018-09-10 22:18:20 --> Input Class Initialized
INFO - 2018-09-10 22:18:20 --> Language Class Initialized
INFO - 2018-09-10 22:18:20 --> Loader Class Initialized
INFO - 2018-09-10 22:18:20 --> Helper loaded: url_helper
INFO - 2018-09-10 22:18:20 --> Helper loaded: form_helper
INFO - 2018-09-10 22:18:20 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:18:20 --> User Agent Class Initialized
INFO - 2018-09-10 22:18:20 --> Controller Class Initialized
INFO - 2018-09-10 22:18:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:18:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-09-10 22:18:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:18:20 --> Final output sent to browser
DEBUG - 2018-09-10 22:18:20 --> Total execution time: 0.0285
INFO - 2018-09-10 22:18:59 --> Config Class Initialized
INFO - 2018-09-10 22:18:59 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:18:59 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:18:59 --> Utf8 Class Initialized
INFO - 2018-09-10 22:18:59 --> URI Class Initialized
INFO - 2018-09-10 22:18:59 --> Router Class Initialized
INFO - 2018-09-10 22:18:59 --> Output Class Initialized
INFO - 2018-09-10 22:18:59 --> Security Class Initialized
DEBUG - 2018-09-10 22:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:18:59 --> CSRF cookie sent
INFO - 2018-09-10 22:18:59 --> Input Class Initialized
INFO - 2018-09-10 22:18:59 --> Language Class Initialized
ERROR - 2018-09-10 22:18:59 --> 404 Page Not Found: Faviconico/index
INFO - 2018-09-10 22:19:06 --> Config Class Initialized
INFO - 2018-09-10 22:19:06 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:19:06 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:19:06 --> Utf8 Class Initialized
INFO - 2018-09-10 22:19:06 --> URI Class Initialized
INFO - 2018-09-10 22:19:06 --> Router Class Initialized
INFO - 2018-09-10 22:19:06 --> Output Class Initialized
INFO - 2018-09-10 22:19:06 --> Security Class Initialized
DEBUG - 2018-09-10 22:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:19:06 --> CSRF cookie sent
INFO - 2018-09-10 22:19:06 --> Input Class Initialized
INFO - 2018-09-10 22:19:06 --> Language Class Initialized
INFO - 2018-09-10 22:19:06 --> Loader Class Initialized
INFO - 2018-09-10 22:19:06 --> Helper loaded: url_helper
INFO - 2018-09-10 22:19:06 --> Helper loaded: form_helper
INFO - 2018-09-10 22:19:06 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:19:06 --> User Agent Class Initialized
INFO - 2018-09-10 22:19:06 --> Controller Class Initialized
INFO - 2018-09-10 22:19:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:19:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-09-10 22:19:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:19:06 --> Final output sent to browser
DEBUG - 2018-09-10 22:19:06 --> Total execution time: 0.0213
INFO - 2018-09-10 22:19:08 --> Config Class Initialized
INFO - 2018-09-10 22:19:08 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:19:08 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:19:08 --> Utf8 Class Initialized
INFO - 2018-09-10 22:19:08 --> URI Class Initialized
INFO - 2018-09-10 22:19:08 --> Router Class Initialized
INFO - 2018-09-10 22:19:08 --> Output Class Initialized
INFO - 2018-09-10 22:19:08 --> Security Class Initialized
DEBUG - 2018-09-10 22:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:19:08 --> CSRF cookie sent
INFO - 2018-09-10 22:19:08 --> Input Class Initialized
INFO - 2018-09-10 22:19:08 --> Language Class Initialized
INFO - 2018-09-10 22:19:08 --> Loader Class Initialized
INFO - 2018-09-10 22:19:08 --> Helper loaded: url_helper
INFO - 2018-09-10 22:19:08 --> Helper loaded: form_helper
INFO - 2018-09-10 22:19:08 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:19:08 --> User Agent Class Initialized
INFO - 2018-09-10 22:19:08 --> Controller Class Initialized
INFO - 2018-09-10 22:19:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:19:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-09-10 22:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:19:08 --> Final output sent to browser
DEBUG - 2018-09-10 22:19:08 --> Total execution time: 0.0361
INFO - 2018-09-10 22:21:31 --> Config Class Initialized
INFO - 2018-09-10 22:21:31 --> Hooks Class Initialized
DEBUG - 2018-09-10 22:21:31 --> UTF-8 Support Enabled
INFO - 2018-09-10 22:21:31 --> Utf8 Class Initialized
INFO - 2018-09-10 22:21:31 --> URI Class Initialized
INFO - 2018-09-10 22:21:31 --> Router Class Initialized
INFO - 2018-09-10 22:21:31 --> Output Class Initialized
INFO - 2018-09-10 22:21:31 --> Security Class Initialized
DEBUG - 2018-09-10 22:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-10 22:21:31 --> CSRF cookie sent
INFO - 2018-09-10 22:21:31 --> Input Class Initialized
INFO - 2018-09-10 22:21:31 --> Language Class Initialized
INFO - 2018-09-10 22:21:31 --> Loader Class Initialized
INFO - 2018-09-10 22:21:31 --> Helper loaded: url_helper
INFO - 2018-09-10 22:21:31 --> Helper loaded: form_helper
INFO - 2018-09-10 22:21:31 --> Helper loaded: language_helper
DEBUG - 2018-09-10 22:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-10 22:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-10 22:21:31 --> User Agent Class Initialized
INFO - 2018-09-10 22:21:31 --> Controller Class Initialized
INFO - 2018-09-10 22:21:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-10 22:21:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-10 22:21:31 --> Pixel_Model class loaded
INFO - 2018-09-10 22:21:31 --> Database Driver Class Initialized
INFO - 2018-09-10 22:21:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-10 22:21:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-10 22:21:31 --> Final output sent to browser
DEBUG - 2018-09-10 22:21:31 --> Total execution time: 0.0461

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-11 18:18:11 --> Config Class Initialized
INFO - 2018-09-11 18:18:11 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:18:11 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:18:11 --> Utf8 Class Initialized
INFO - 2018-09-11 18:18:11 --> URI Class Initialized
DEBUG - 2018-09-11 18:18:11 --> No URI present. Default controller set.
INFO - 2018-09-11 18:18:11 --> Router Class Initialized
INFO - 2018-09-11 18:18:11 --> Output Class Initialized
INFO - 2018-09-11 18:18:11 --> Security Class Initialized
DEBUG - 2018-09-11 18:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:18:11 --> CSRF cookie sent
INFO - 2018-09-11 18:18:11 --> Input Class Initialized
INFO - 2018-09-11 18:18:11 --> Language Class Initialized
INFO - 2018-09-11 18:18:11 --> Loader Class Initialized
INFO - 2018-09-11 18:18:11 --> Helper loaded: url_helper
INFO - 2018-09-11 18:18:11 --> Helper loaded: form_helper
INFO - 2018-09-11 18:18:11 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:18:11 --> User Agent Class Initialized
INFO - 2018-09-11 18:18:11 --> Controller Class Initialized
INFO - 2018-09-11 18:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:18:11 --> Pixel_Model class loaded
INFO - 2018-09-11 18:18:11 --> Database Driver Class Initialized
INFO - 2018-09-11 18:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-11 18:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:18:11 --> Final output sent to browser
DEBUG - 2018-09-11 18:18:11 --> Total execution time: 0.0511
INFO - 2018-09-11 18:18:12 --> Config Class Initialized
INFO - 2018-09-11 18:18:12 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:18:12 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:18:12 --> Utf8 Class Initialized
INFO - 2018-09-11 18:18:12 --> URI Class Initialized
DEBUG - 2018-09-11 18:18:12 --> No URI present. Default controller set.
INFO - 2018-09-11 18:18:12 --> Router Class Initialized
INFO - 2018-09-11 18:18:12 --> Output Class Initialized
INFO - 2018-09-11 18:18:12 --> Security Class Initialized
DEBUG - 2018-09-11 18:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:18:12 --> CSRF cookie sent
INFO - 2018-09-11 18:18:12 --> Input Class Initialized
INFO - 2018-09-11 18:18:12 --> Language Class Initialized
INFO - 2018-09-11 18:18:12 --> Loader Class Initialized
INFO - 2018-09-11 18:18:12 --> Helper loaded: url_helper
INFO - 2018-09-11 18:18:12 --> Helper loaded: form_helper
INFO - 2018-09-11 18:18:12 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:18:12 --> User Agent Class Initialized
INFO - 2018-09-11 18:18:12 --> Controller Class Initialized
INFO - 2018-09-11 18:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:18:12 --> Pixel_Model class loaded
INFO - 2018-09-11 18:18:12 --> Database Driver Class Initialized
INFO - 2018-09-11 18:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-11 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:18:12 --> Final output sent to browser
DEBUG - 2018-09-11 18:18:12 --> Total execution time: 0.0341
INFO - 2018-09-11 18:18:15 --> Config Class Initialized
INFO - 2018-09-11 18:18:15 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:18:15 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:18:15 --> Utf8 Class Initialized
INFO - 2018-09-11 18:18:15 --> URI Class Initialized
INFO - 2018-09-11 18:18:15 --> Router Class Initialized
INFO - 2018-09-11 18:18:15 --> Output Class Initialized
INFO - 2018-09-11 18:18:15 --> Security Class Initialized
DEBUG - 2018-09-11 18:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:18:15 --> CSRF cookie sent
INFO - 2018-09-11 18:18:15 --> Input Class Initialized
INFO - 2018-09-11 18:18:15 --> Language Class Initialized
INFO - 2018-09-11 18:18:15 --> Loader Class Initialized
INFO - 2018-09-11 18:18:15 --> Helper loaded: url_helper
INFO - 2018-09-11 18:18:15 --> Helper loaded: form_helper
INFO - 2018-09-11 18:18:15 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:18:15 --> User Agent Class Initialized
INFO - 2018-09-11 18:18:15 --> Controller Class Initialized
INFO - 2018-09-11 18:18:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:18:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:18:15 --> Pixel_Model class loaded
INFO - 2018-09-11 18:18:15 --> Database Driver Class Initialized
INFO - 2018-09-11 18:18:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-11 18:18:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:18:15 --> Final output sent to browser
DEBUG - 2018-09-11 18:18:15 --> Total execution time: 0.0371
INFO - 2018-09-11 18:18:24 --> Config Class Initialized
INFO - 2018-09-11 18:18:24 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:18:24 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:18:24 --> Utf8 Class Initialized
INFO - 2018-09-11 18:18:24 --> URI Class Initialized
INFO - 2018-09-11 18:18:24 --> Router Class Initialized
INFO - 2018-09-11 18:18:24 --> Output Class Initialized
INFO - 2018-09-11 18:18:24 --> Security Class Initialized
DEBUG - 2018-09-11 18:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:18:24 --> CSRF cookie sent
INFO - 2018-09-11 18:18:24 --> Input Class Initialized
INFO - 2018-09-11 18:18:24 --> Language Class Initialized
INFO - 2018-09-11 18:18:25 --> Loader Class Initialized
INFO - 2018-09-11 18:18:25 --> Helper loaded: url_helper
INFO - 2018-09-11 18:18:25 --> Helper loaded: form_helper
INFO - 2018-09-11 18:18:25 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:18:25 --> User Agent Class Initialized
INFO - 2018-09-11 18:18:25 --> Controller Class Initialized
INFO - 2018-09-11 18:18:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:18:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:18:25 --> Pixel_Model class loaded
INFO - 2018-09-11 18:18:25 --> Database Driver Class Initialized
INFO - 2018-09-11 18:18:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-11 18:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:18:25 --> Final output sent to browser
DEBUG - 2018-09-11 18:18:25 --> Total execution time: 0.0379
INFO - 2018-09-11 18:21:49 --> Config Class Initialized
INFO - 2018-09-11 18:21:49 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:21:49 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:21:49 --> Utf8 Class Initialized
INFO - 2018-09-11 18:21:49 --> URI Class Initialized
INFO - 2018-09-11 18:21:49 --> Router Class Initialized
INFO - 2018-09-11 18:21:49 --> Output Class Initialized
INFO - 2018-09-11 18:21:49 --> Security Class Initialized
DEBUG - 2018-09-11 18:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:21:49 --> CSRF cookie sent
INFO - 2018-09-11 18:21:49 --> CSRF token verified
INFO - 2018-09-11 18:21:49 --> Input Class Initialized
INFO - 2018-09-11 18:21:49 --> Language Class Initialized
INFO - 2018-09-11 18:21:49 --> Loader Class Initialized
INFO - 2018-09-11 18:21:49 --> Helper loaded: url_helper
INFO - 2018-09-11 18:21:49 --> Helper loaded: form_helper
INFO - 2018-09-11 18:21:49 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:21:49 --> User Agent Class Initialized
INFO - 2018-09-11 18:21:49 --> Controller Class Initialized
INFO - 2018-09-11 18:21:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:21:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:21:49 --> Pixel_Model class loaded
INFO - 2018-09-11 18:21:49 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:49 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:49 --> Config Class Initialized
INFO - 2018-09-11 18:21:49 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:21:49 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:21:49 --> Utf8 Class Initialized
INFO - 2018-09-11 18:21:49 --> URI Class Initialized
INFO - 2018-09-11 18:21:49 --> Router Class Initialized
INFO - 2018-09-11 18:21:49 --> Output Class Initialized
INFO - 2018-09-11 18:21:49 --> Security Class Initialized
DEBUG - 2018-09-11 18:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:21:49 --> CSRF cookie sent
INFO - 2018-09-11 18:21:49 --> Input Class Initialized
INFO - 2018-09-11 18:21:49 --> Language Class Initialized
INFO - 2018-09-11 18:21:49 --> Loader Class Initialized
INFO - 2018-09-11 18:21:49 --> Helper loaded: url_helper
INFO - 2018-09-11 18:21:49 --> Helper loaded: form_helper
INFO - 2018-09-11 18:21:49 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:21:49 --> User Agent Class Initialized
INFO - 2018-09-11 18:21:49 --> Controller Class Initialized
INFO - 2018-09-11 18:21:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:21:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:21:49 --> Pixel_Model class loaded
INFO - 2018-09-11 18:21:49 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:49 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-11 18:21:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:21:49 --> Final output sent to browser
DEBUG - 2018-09-11 18:21:49 --> Total execution time: 0.0460
INFO - 2018-09-11 18:21:54 --> Config Class Initialized
INFO - 2018-09-11 18:21:54 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:21:54 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:21:54 --> Utf8 Class Initialized
INFO - 2018-09-11 18:21:54 --> URI Class Initialized
INFO - 2018-09-11 18:21:54 --> Router Class Initialized
INFO - 2018-09-11 18:21:54 --> Output Class Initialized
INFO - 2018-09-11 18:21:54 --> Security Class Initialized
DEBUG - 2018-09-11 18:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:21:54 --> CSRF cookie sent
INFO - 2018-09-11 18:21:54 --> Input Class Initialized
INFO - 2018-09-11 18:21:54 --> Language Class Initialized
INFO - 2018-09-11 18:21:54 --> Loader Class Initialized
INFO - 2018-09-11 18:21:54 --> Helper loaded: url_helper
INFO - 2018-09-11 18:21:54 --> Helper loaded: form_helper
INFO - 2018-09-11 18:21:54 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:21:54 --> User Agent Class Initialized
INFO - 2018-09-11 18:21:54 --> Controller Class Initialized
INFO - 2018-09-11 18:21:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:21:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:21:54 --> Pixel_Model class loaded
INFO - 2018-09-11 18:21:54 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:54 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-11 18:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:21:54 --> Final output sent to browser
DEBUG - 2018-09-11 18:21:54 --> Total execution time: 0.0467
INFO - 2018-09-11 18:21:56 --> Config Class Initialized
INFO - 2018-09-11 18:21:56 --> Hooks Class Initialized
DEBUG - 2018-09-11 18:21:56 --> UTF-8 Support Enabled
INFO - 2018-09-11 18:21:56 --> Utf8 Class Initialized
INFO - 2018-09-11 18:21:56 --> URI Class Initialized
INFO - 2018-09-11 18:21:56 --> Router Class Initialized
INFO - 2018-09-11 18:21:56 --> Output Class Initialized
INFO - 2018-09-11 18:21:56 --> Security Class Initialized
DEBUG - 2018-09-11 18:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 18:21:56 --> CSRF cookie sent
INFO - 2018-09-11 18:21:56 --> Input Class Initialized
INFO - 2018-09-11 18:21:56 --> Language Class Initialized
INFO - 2018-09-11 18:21:56 --> Loader Class Initialized
INFO - 2018-09-11 18:21:56 --> Helper loaded: url_helper
INFO - 2018-09-11 18:21:56 --> Helper loaded: form_helper
INFO - 2018-09-11 18:21:56 --> Helper loaded: language_helper
DEBUG - 2018-09-11 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 18:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 18:21:56 --> User Agent Class Initialized
INFO - 2018-09-11 18:21:56 --> Controller Class Initialized
INFO - 2018-09-11 18:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 18:21:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 18:21:56 --> Pixel_Model class loaded
INFO - 2018-09-11 18:21:56 --> Database Driver Class Initialized
INFO - 2018-09-11 18:21:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-09-11 18:21:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-11 18:21:56 --> Could not find the language line "req_email"
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-09-11 18:21:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 18:21:56 --> Final output sent to browser
DEBUG - 2018-09-11 18:21:56 --> Total execution time: 0.0357
INFO - 2018-09-11 19:28:39 --> Config Class Initialized
INFO - 2018-09-11 19:28:39 --> Hooks Class Initialized
DEBUG - 2018-09-11 19:28:39 --> UTF-8 Support Enabled
INFO - 2018-09-11 19:28:39 --> Utf8 Class Initialized
INFO - 2018-09-11 19:28:39 --> URI Class Initialized
DEBUG - 2018-09-11 19:28:39 --> No URI present. Default controller set.
INFO - 2018-09-11 19:28:39 --> Router Class Initialized
INFO - 2018-09-11 19:28:39 --> Output Class Initialized
INFO - 2018-09-11 19:28:39 --> Security Class Initialized
DEBUG - 2018-09-11 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 19:28:39 --> CSRF cookie sent
INFO - 2018-09-11 19:28:39 --> Input Class Initialized
INFO - 2018-09-11 19:28:39 --> Language Class Initialized
INFO - 2018-09-11 19:28:39 --> Loader Class Initialized
INFO - 2018-09-11 19:28:39 --> Helper loaded: url_helper
INFO - 2018-09-11 19:28:39 --> Helper loaded: form_helper
INFO - 2018-09-11 19:28:39 --> Helper loaded: language_helper
DEBUG - 2018-09-11 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 19:28:39 --> User Agent Class Initialized
INFO - 2018-09-11 19:28:39 --> Controller Class Initialized
INFO - 2018-09-11 19:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 19:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 19:28:39 --> Pixel_Model class loaded
INFO - 2018-09-11 19:28:39 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-11 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 19:28:39 --> Final output sent to browser
DEBUG - 2018-09-11 19:28:39 --> Total execution time: 0.0374
INFO - 2018-09-11 19:28:40 --> Config Class Initialized
INFO - 2018-09-11 19:28:40 --> Hooks Class Initialized
DEBUG - 2018-09-11 19:28:40 --> UTF-8 Support Enabled
INFO - 2018-09-11 19:28:40 --> Utf8 Class Initialized
INFO - 2018-09-11 19:28:40 --> URI Class Initialized
DEBUG - 2018-09-11 19:28:40 --> No URI present. Default controller set.
INFO - 2018-09-11 19:28:40 --> Router Class Initialized
INFO - 2018-09-11 19:28:40 --> Output Class Initialized
INFO - 2018-09-11 19:28:40 --> Security Class Initialized
DEBUG - 2018-09-11 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 19:28:40 --> CSRF cookie sent
INFO - 2018-09-11 19:28:40 --> Input Class Initialized
INFO - 2018-09-11 19:28:40 --> Language Class Initialized
INFO - 2018-09-11 19:28:40 --> Loader Class Initialized
INFO - 2018-09-11 19:28:40 --> Helper loaded: url_helper
INFO - 2018-09-11 19:28:40 --> Helper loaded: form_helper
INFO - 2018-09-11 19:28:40 --> Helper loaded: language_helper
DEBUG - 2018-09-11 19:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 19:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 19:28:40 --> User Agent Class Initialized
INFO - 2018-09-11 19:28:40 --> Controller Class Initialized
INFO - 2018-09-11 19:28:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 19:28:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 19:28:40 --> Pixel_Model class loaded
INFO - 2018-09-11 19:28:40 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 19:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 19:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-11 19:28:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 19:28:40 --> Final output sent to browser
DEBUG - 2018-09-11 19:28:40 --> Total execution time: 0.0360
INFO - 2018-09-11 19:28:49 --> Config Class Initialized
INFO - 2018-09-11 19:28:49 --> Hooks Class Initialized
DEBUG - 2018-09-11 19:28:49 --> UTF-8 Support Enabled
INFO - 2018-09-11 19:28:49 --> Utf8 Class Initialized
INFO - 2018-09-11 19:28:49 --> URI Class Initialized
INFO - 2018-09-11 19:28:49 --> Router Class Initialized
INFO - 2018-09-11 19:28:49 --> Output Class Initialized
INFO - 2018-09-11 19:28:49 --> Security Class Initialized
DEBUG - 2018-09-11 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 19:28:49 --> CSRF cookie sent
INFO - 2018-09-11 19:28:49 --> CSRF token verified
INFO - 2018-09-11 19:28:49 --> Input Class Initialized
INFO - 2018-09-11 19:28:49 --> Language Class Initialized
INFO - 2018-09-11 19:28:49 --> Loader Class Initialized
INFO - 2018-09-11 19:28:49 --> Helper loaded: url_helper
INFO - 2018-09-11 19:28:49 --> Helper loaded: form_helper
INFO - 2018-09-11 19:28:49 --> Helper loaded: language_helper
DEBUG - 2018-09-11 19:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 19:28:49 --> User Agent Class Initialized
INFO - 2018-09-11 19:28:49 --> Controller Class Initialized
INFO - 2018-09-11 19:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 19:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 19:28:49 --> Pixel_Model class loaded
INFO - 2018-09-11 19:28:49 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:49 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:49 --> Config Class Initialized
INFO - 2018-09-11 19:28:49 --> Hooks Class Initialized
DEBUG - 2018-09-11 19:28:49 --> UTF-8 Support Enabled
INFO - 2018-09-11 19:28:49 --> Utf8 Class Initialized
INFO - 2018-09-11 19:28:49 --> URI Class Initialized
INFO - 2018-09-11 19:28:49 --> Router Class Initialized
INFO - 2018-09-11 19:28:49 --> Output Class Initialized
INFO - 2018-09-11 19:28:49 --> Security Class Initialized
DEBUG - 2018-09-11 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 19:28:49 --> CSRF cookie sent
INFO - 2018-09-11 19:28:49 --> Input Class Initialized
INFO - 2018-09-11 19:28:49 --> Language Class Initialized
INFO - 2018-09-11 19:28:49 --> Loader Class Initialized
INFO - 2018-09-11 19:28:49 --> Helper loaded: url_helper
INFO - 2018-09-11 19:28:49 --> Helper loaded: form_helper
INFO - 2018-09-11 19:28:49 --> Helper loaded: language_helper
DEBUG - 2018-09-11 19:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 19:28:49 --> User Agent Class Initialized
INFO - 2018-09-11 19:28:49 --> Controller Class Initialized
INFO - 2018-09-11 19:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 19:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 19:28:49 --> Pixel_Model class loaded
INFO - 2018-09-11 19:28:49 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:49 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-11 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 19:28:49 --> Final output sent to browser
DEBUG - 2018-09-11 19:28:49 --> Total execution time: 0.0589
INFO - 2018-09-11 19:28:53 --> Config Class Initialized
INFO - 2018-09-11 19:28:53 --> Hooks Class Initialized
DEBUG - 2018-09-11 19:28:53 --> UTF-8 Support Enabled
INFO - 2018-09-11 19:28:53 --> Utf8 Class Initialized
INFO - 2018-09-11 19:28:53 --> URI Class Initialized
INFO - 2018-09-11 19:28:53 --> Router Class Initialized
INFO - 2018-09-11 19:28:53 --> Output Class Initialized
INFO - 2018-09-11 19:28:53 --> Security Class Initialized
DEBUG - 2018-09-11 19:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-11 19:28:53 --> CSRF cookie sent
INFO - 2018-09-11 19:28:53 --> CSRF token verified
INFO - 2018-09-11 19:28:53 --> Input Class Initialized
INFO - 2018-09-11 19:28:53 --> Language Class Initialized
INFO - 2018-09-11 19:28:53 --> Loader Class Initialized
INFO - 2018-09-11 19:28:53 --> Helper loaded: url_helper
INFO - 2018-09-11 19:28:53 --> Helper loaded: form_helper
INFO - 2018-09-11 19:28:53 --> Helper loaded: language_helper
DEBUG - 2018-09-11 19:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-11 19:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-11 19:28:53 --> User Agent Class Initialized
INFO - 2018-09-11 19:28:53 --> Controller Class Initialized
INFO - 2018-09-11 19:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-11 19:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-11 19:28:53 --> Pixel_Model class loaded
INFO - 2018-09-11 19:28:53 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:53 --> Form Validation Class Initialized
INFO - 2018-09-11 19:28:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-11 19:28:53 --> Database Driver Class Initialized
INFO - 2018-09-11 19:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-11 19:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-11 19:28:53 --> Final output sent to browser
DEBUG - 2018-09-11 19:28:53 --> Total execution time: 0.0626

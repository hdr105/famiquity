<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-14 12:43:29 --> Config Class Initialized
INFO - 2018-09-14 12:43:29 --> Hooks Class Initialized
DEBUG - 2018-09-14 12:43:29 --> UTF-8 Support Enabled
INFO - 2018-09-14 12:43:29 --> Utf8 Class Initialized
INFO - 2018-09-14 12:43:29 --> URI Class Initialized
DEBUG - 2018-09-14 12:43:29 --> No URI present. Default controller set.
INFO - 2018-09-14 12:43:29 --> Router Class Initialized
INFO - 2018-09-14 12:43:29 --> Output Class Initialized
INFO - 2018-09-14 12:43:29 --> Security Class Initialized
DEBUG - 2018-09-14 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 12:43:29 --> CSRF cookie sent
INFO - 2018-09-14 12:43:29 --> Input Class Initialized
INFO - 2018-09-14 12:43:29 --> Language Class Initialized
INFO - 2018-09-14 12:43:29 --> Loader Class Initialized
INFO - 2018-09-14 12:43:29 --> Helper loaded: url_helper
INFO - 2018-09-14 12:43:29 --> Helper loaded: form_helper
INFO - 2018-09-14 12:43:29 --> Helper loaded: language_helper
DEBUG - 2018-09-14 12:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 12:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 12:43:29 --> User Agent Class Initialized
INFO - 2018-09-14 12:43:29 --> Controller Class Initialized
INFO - 2018-09-14 12:43:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 12:43:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 12:43:29 --> Pixel_Model class loaded
INFO - 2018-09-14 12:43:29 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 12:43:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 12:43:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-14 12:43:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 12:43:29 --> Final output sent to browser
DEBUG - 2018-09-14 12:43:29 --> Total execution time: 0.0361
INFO - 2018-09-14 12:43:30 --> Config Class Initialized
INFO - 2018-09-14 12:43:30 --> Hooks Class Initialized
DEBUG - 2018-09-14 12:43:30 --> UTF-8 Support Enabled
INFO - 2018-09-14 12:43:30 --> Utf8 Class Initialized
INFO - 2018-09-14 12:43:30 --> URI Class Initialized
DEBUG - 2018-09-14 12:43:30 --> No URI present. Default controller set.
INFO - 2018-09-14 12:43:30 --> Router Class Initialized
INFO - 2018-09-14 12:43:30 --> Output Class Initialized
INFO - 2018-09-14 12:43:30 --> Security Class Initialized
DEBUG - 2018-09-14 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 12:43:30 --> CSRF cookie sent
INFO - 2018-09-14 12:43:30 --> Input Class Initialized
INFO - 2018-09-14 12:43:30 --> Language Class Initialized
INFO - 2018-09-14 12:43:30 --> Loader Class Initialized
INFO - 2018-09-14 12:43:30 --> Helper loaded: url_helper
INFO - 2018-09-14 12:43:30 --> Helper loaded: form_helper
INFO - 2018-09-14 12:43:30 --> Helper loaded: language_helper
DEBUG - 2018-09-14 12:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 12:43:30 --> User Agent Class Initialized
INFO - 2018-09-14 12:43:30 --> Controller Class Initialized
INFO - 2018-09-14 12:43:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 12:43:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 12:43:30 --> Pixel_Model class loaded
INFO - 2018-09-14 12:43:30 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 12:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 12:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-14 12:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 12:43:30 --> Final output sent to browser
DEBUG - 2018-09-14 12:43:30 --> Total execution time: 0.0346
INFO - 2018-09-14 12:43:47 --> Config Class Initialized
INFO - 2018-09-14 12:43:47 --> Hooks Class Initialized
DEBUG - 2018-09-14 12:43:47 --> UTF-8 Support Enabled
INFO - 2018-09-14 12:43:47 --> Utf8 Class Initialized
INFO - 2018-09-14 12:43:47 --> URI Class Initialized
INFO - 2018-09-14 12:43:47 --> Router Class Initialized
INFO - 2018-09-14 12:43:47 --> Output Class Initialized
INFO - 2018-09-14 12:43:47 --> Security Class Initialized
DEBUG - 2018-09-14 12:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 12:43:47 --> CSRF cookie sent
INFO - 2018-09-14 12:43:47 --> CSRF token verified
INFO - 2018-09-14 12:43:47 --> Input Class Initialized
INFO - 2018-09-14 12:43:47 --> Language Class Initialized
INFO - 2018-09-14 12:43:47 --> Loader Class Initialized
INFO - 2018-09-14 12:43:47 --> Helper loaded: url_helper
INFO - 2018-09-14 12:43:47 --> Helper loaded: form_helper
INFO - 2018-09-14 12:43:47 --> Helper loaded: language_helper
DEBUG - 2018-09-14 12:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 12:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 12:43:47 --> User Agent Class Initialized
INFO - 2018-09-14 12:43:47 --> Controller Class Initialized
INFO - 2018-09-14 12:43:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 12:43:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 12:43:47 --> Pixel_Model class loaded
INFO - 2018-09-14 12:43:47 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:47 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:48 --> Config Class Initialized
INFO - 2018-09-14 12:43:48 --> Hooks Class Initialized
DEBUG - 2018-09-14 12:43:48 --> UTF-8 Support Enabled
INFO - 2018-09-14 12:43:48 --> Utf8 Class Initialized
INFO - 2018-09-14 12:43:48 --> URI Class Initialized
INFO - 2018-09-14 12:43:48 --> Router Class Initialized
INFO - 2018-09-14 12:43:48 --> Output Class Initialized
INFO - 2018-09-14 12:43:48 --> Security Class Initialized
DEBUG - 2018-09-14 12:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 12:43:48 --> CSRF cookie sent
INFO - 2018-09-14 12:43:48 --> Input Class Initialized
INFO - 2018-09-14 12:43:48 --> Language Class Initialized
INFO - 2018-09-14 12:43:48 --> Loader Class Initialized
INFO - 2018-09-14 12:43:48 --> Helper loaded: url_helper
INFO - 2018-09-14 12:43:48 --> Helper loaded: form_helper
INFO - 2018-09-14 12:43:48 --> Helper loaded: language_helper
DEBUG - 2018-09-14 12:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 12:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 12:43:48 --> User Agent Class Initialized
INFO - 2018-09-14 12:43:48 --> Controller Class Initialized
INFO - 2018-09-14 12:43:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 12:43:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 12:43:48 --> Pixel_Model class loaded
INFO - 2018-09-14 12:43:48 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:48 --> Database Driver Class Initialized
INFO - 2018-09-14 12:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-14 12:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 12:43:48 --> Final output sent to browser
DEBUG - 2018-09-14 12:43:48 --> Total execution time: 0.0492
INFO - 2018-09-14 23:07:24 --> Config Class Initialized
INFO - 2018-09-14 23:07:24 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:07:24 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:07:24 --> Utf8 Class Initialized
INFO - 2018-09-14 23:07:24 --> URI Class Initialized
DEBUG - 2018-09-14 23:07:24 --> No URI present. Default controller set.
INFO - 2018-09-14 23:07:24 --> Router Class Initialized
INFO - 2018-09-14 23:07:24 --> Output Class Initialized
INFO - 2018-09-14 23:07:24 --> Security Class Initialized
DEBUG - 2018-09-14 23:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:07:24 --> CSRF cookie sent
INFO - 2018-09-14 23:07:24 --> Input Class Initialized
INFO - 2018-09-14 23:07:24 --> Language Class Initialized
INFO - 2018-09-14 23:07:24 --> Loader Class Initialized
INFO - 2018-09-14 23:07:24 --> Helper loaded: url_helper
INFO - 2018-09-14 23:07:24 --> Helper loaded: form_helper
INFO - 2018-09-14 23:07:24 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:07:24 --> User Agent Class Initialized
INFO - 2018-09-14 23:07:24 --> Controller Class Initialized
INFO - 2018-09-14 23:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:07:24 --> Pixel_Model class loaded
INFO - 2018-09-14 23:07:24 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-14 23:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:07:24 --> Final output sent to browser
DEBUG - 2018-09-14 23:07:24 --> Total execution time: 0.0667
INFO - 2018-09-14 23:07:41 --> Config Class Initialized
INFO - 2018-09-14 23:07:41 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:07:41 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:07:41 --> Utf8 Class Initialized
INFO - 2018-09-14 23:07:41 --> URI Class Initialized
INFO - 2018-09-14 23:07:41 --> Router Class Initialized
INFO - 2018-09-14 23:07:41 --> Output Class Initialized
INFO - 2018-09-14 23:07:41 --> Security Class Initialized
DEBUG - 2018-09-14 23:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:07:41 --> CSRF cookie sent
INFO - 2018-09-14 23:07:41 --> CSRF token verified
INFO - 2018-09-14 23:07:41 --> Input Class Initialized
INFO - 2018-09-14 23:07:41 --> Language Class Initialized
INFO - 2018-09-14 23:07:41 --> Loader Class Initialized
INFO - 2018-09-14 23:07:41 --> Helper loaded: url_helper
INFO - 2018-09-14 23:07:41 --> Helper loaded: form_helper
INFO - 2018-09-14 23:07:41 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:07:41 --> User Agent Class Initialized
INFO - 2018-09-14 23:07:41 --> Controller Class Initialized
INFO - 2018-09-14 23:07:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:07:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:07:41 --> Pixel_Model class loaded
INFO - 2018-09-14 23:07:41 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:41 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:41 --> Config Class Initialized
INFO - 2018-09-14 23:07:41 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:07:41 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:07:41 --> Utf8 Class Initialized
INFO - 2018-09-14 23:07:41 --> URI Class Initialized
INFO - 2018-09-14 23:07:41 --> Router Class Initialized
INFO - 2018-09-14 23:07:41 --> Output Class Initialized
INFO - 2018-09-14 23:07:41 --> Security Class Initialized
DEBUG - 2018-09-14 23:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:07:41 --> CSRF cookie sent
INFO - 2018-09-14 23:07:41 --> Input Class Initialized
INFO - 2018-09-14 23:07:41 --> Language Class Initialized
INFO - 2018-09-14 23:07:41 --> Loader Class Initialized
INFO - 2018-09-14 23:07:41 --> Helper loaded: url_helper
INFO - 2018-09-14 23:07:41 --> Helper loaded: form_helper
INFO - 2018-09-14 23:07:41 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:07:41 --> User Agent Class Initialized
INFO - 2018-09-14 23:07:41 --> Controller Class Initialized
INFO - 2018-09-14 23:07:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:07:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:07:41 --> Pixel_Model class loaded
INFO - 2018-09-14 23:07:41 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:41 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-14 23:07:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:07:41 --> Final output sent to browser
DEBUG - 2018-09-14 23:07:41 --> Total execution time: 0.0653
INFO - 2018-09-14 23:07:47 --> Config Class Initialized
INFO - 2018-09-14 23:07:47 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:07:47 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:07:47 --> Utf8 Class Initialized
INFO - 2018-09-14 23:07:47 --> URI Class Initialized
INFO - 2018-09-14 23:07:47 --> Router Class Initialized
INFO - 2018-09-14 23:07:47 --> Output Class Initialized
INFO - 2018-09-14 23:07:47 --> Security Class Initialized
DEBUG - 2018-09-14 23:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:07:47 --> CSRF cookie sent
INFO - 2018-09-14 23:07:47 --> CSRF token verified
INFO - 2018-09-14 23:07:47 --> Input Class Initialized
INFO - 2018-09-14 23:07:47 --> Language Class Initialized
INFO - 2018-09-14 23:07:47 --> Loader Class Initialized
INFO - 2018-09-14 23:07:47 --> Helper loaded: url_helper
INFO - 2018-09-14 23:07:47 --> Helper loaded: form_helper
INFO - 2018-09-14 23:07:47 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:07:47 --> User Agent Class Initialized
INFO - 2018-09-14 23:07:47 --> Controller Class Initialized
INFO - 2018-09-14 23:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:07:47 --> Pixel_Model class loaded
INFO - 2018-09-14 23:07:47 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:47 --> Form Validation Class Initialized
INFO - 2018-09-14 23:07:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:07:47 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:47 --> Config Class Initialized
INFO - 2018-09-14 23:07:47 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:07:47 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:07:47 --> Utf8 Class Initialized
INFO - 2018-09-14 23:07:47 --> URI Class Initialized
INFO - 2018-09-14 23:07:47 --> Router Class Initialized
INFO - 2018-09-14 23:07:47 --> Output Class Initialized
INFO - 2018-09-14 23:07:47 --> Security Class Initialized
DEBUG - 2018-09-14 23:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:07:47 --> CSRF cookie sent
INFO - 2018-09-14 23:07:47 --> Input Class Initialized
INFO - 2018-09-14 23:07:47 --> Language Class Initialized
INFO - 2018-09-14 23:07:47 --> Loader Class Initialized
INFO - 2018-09-14 23:07:47 --> Helper loaded: url_helper
INFO - 2018-09-14 23:07:47 --> Helper loaded: form_helper
INFO - 2018-09-14 23:07:47 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:07:47 --> User Agent Class Initialized
INFO - 2018-09-14 23:07:47 --> Controller Class Initialized
INFO - 2018-09-14 23:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:07:47 --> Pixel_Model class loaded
INFO - 2018-09-14 23:07:47 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:47 --> Database Driver Class Initialized
INFO - 2018-09-14 23:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-14 23:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:07:47 --> Final output sent to browser
DEBUG - 2018-09-14 23:07:47 --> Total execution time: 0.0437
INFO - 2018-09-14 23:08:00 --> Config Class Initialized
INFO - 2018-09-14 23:08:00 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:00 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:00 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:00 --> URI Class Initialized
INFO - 2018-09-14 23:08:00 --> Router Class Initialized
INFO - 2018-09-14 23:08:00 --> Output Class Initialized
INFO - 2018-09-14 23:08:00 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:00 --> CSRF cookie sent
INFO - 2018-09-14 23:08:00 --> Input Class Initialized
INFO - 2018-09-14 23:08:00 --> Language Class Initialized
INFO - 2018-09-14 23:08:00 --> Loader Class Initialized
INFO - 2018-09-14 23:08:00 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:00 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:00 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:00 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:00 --> Controller Class Initialized
INFO - 2018-09-14 23:08:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:00 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:00 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:00 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-14 23:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:00 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:00 --> Total execution time: 0.0530
INFO - 2018-09-14 23:08:01 --> Config Class Initialized
INFO - 2018-09-14 23:08:01 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:01 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:01 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:01 --> URI Class Initialized
DEBUG - 2018-09-14 23:08:01 --> No URI present. Default controller set.
INFO - 2018-09-14 23:08:01 --> Router Class Initialized
INFO - 2018-09-14 23:08:01 --> Output Class Initialized
INFO - 2018-09-14 23:08:01 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:01 --> CSRF cookie sent
INFO - 2018-09-14 23:08:01 --> Input Class Initialized
INFO - 2018-09-14 23:08:01 --> Language Class Initialized
INFO - 2018-09-14 23:08:01 --> Loader Class Initialized
INFO - 2018-09-14 23:08:01 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:01 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:01 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:01 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:01 --> Controller Class Initialized
INFO - 2018-09-14 23:08:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:01 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:01 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-14 23:08:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:01 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:01 --> Total execution time: 0.0350
INFO - 2018-09-14 23:08:23 --> Config Class Initialized
INFO - 2018-09-14 23:08:23 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:23 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:23 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:23 --> URI Class Initialized
INFO - 2018-09-14 23:08:23 --> Router Class Initialized
INFO - 2018-09-14 23:08:23 --> Output Class Initialized
INFO - 2018-09-14 23:08:23 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:23 --> CSRF cookie sent
INFO - 2018-09-14 23:08:23 --> CSRF token verified
INFO - 2018-09-14 23:08:23 --> Input Class Initialized
INFO - 2018-09-14 23:08:23 --> Language Class Initialized
INFO - 2018-09-14 23:08:23 --> Loader Class Initialized
INFO - 2018-09-14 23:08:23 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:23 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:23 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:23 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:23 --> Controller Class Initialized
INFO - 2018-09-14 23:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:23 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:23 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:23 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:24 --> Config Class Initialized
INFO - 2018-09-14 23:08:24 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:24 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:24 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:24 --> URI Class Initialized
INFO - 2018-09-14 23:08:24 --> Router Class Initialized
INFO - 2018-09-14 23:08:24 --> Output Class Initialized
INFO - 2018-09-14 23:08:24 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:24 --> CSRF cookie sent
INFO - 2018-09-14 23:08:24 --> Input Class Initialized
INFO - 2018-09-14 23:08:24 --> Language Class Initialized
INFO - 2018-09-14 23:08:24 --> Loader Class Initialized
INFO - 2018-09-14 23:08:24 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:24 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:24 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:24 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:24 --> Controller Class Initialized
INFO - 2018-09-14 23:08:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:24 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:24 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:24 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-14 23:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:24 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:24 --> Total execution time: 0.0500
INFO - 2018-09-14 23:08:30 --> Config Class Initialized
INFO - 2018-09-14 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:30 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:30 --> URI Class Initialized
INFO - 2018-09-14 23:08:30 --> Router Class Initialized
INFO - 2018-09-14 23:08:30 --> Output Class Initialized
INFO - 2018-09-14 23:08:30 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:30 --> CSRF cookie sent
INFO - 2018-09-14 23:08:30 --> CSRF token verified
INFO - 2018-09-14 23:08:30 --> Input Class Initialized
INFO - 2018-09-14 23:08:30 --> Language Class Initialized
INFO - 2018-09-14 23:08:30 --> Loader Class Initialized
INFO - 2018-09-14 23:08:30 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:30 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:30 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:30 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:30 --> Controller Class Initialized
INFO - 2018-09-14 23:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:30 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:30 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:30 --> Form Validation Class Initialized
INFO - 2018-09-14 23:08:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:08:30 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:30 --> Config Class Initialized
INFO - 2018-09-14 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:30 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:30 --> URI Class Initialized
INFO - 2018-09-14 23:08:30 --> Router Class Initialized
INFO - 2018-09-14 23:08:30 --> Output Class Initialized
INFO - 2018-09-14 23:08:30 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:30 --> CSRF cookie sent
INFO - 2018-09-14 23:08:30 --> Input Class Initialized
INFO - 2018-09-14 23:08:30 --> Language Class Initialized
INFO - 2018-09-14 23:08:30 --> Loader Class Initialized
INFO - 2018-09-14 23:08:30 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:30 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:30 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:30 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:30 --> Controller Class Initialized
INFO - 2018-09-14 23:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:30 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:30 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:30 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-14 23:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:30 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:30 --> Total execution time: 0.0347
INFO - 2018-09-14 23:08:39 --> Config Class Initialized
INFO - 2018-09-14 23:08:39 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:39 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:39 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:39 --> URI Class Initialized
INFO - 2018-09-14 23:08:39 --> Router Class Initialized
INFO - 2018-09-14 23:08:39 --> Output Class Initialized
INFO - 2018-09-14 23:08:39 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:39 --> CSRF cookie sent
INFO - 2018-09-14 23:08:39 --> CSRF token verified
INFO - 2018-09-14 23:08:39 --> Input Class Initialized
INFO - 2018-09-14 23:08:39 --> Language Class Initialized
INFO - 2018-09-14 23:08:39 --> Loader Class Initialized
INFO - 2018-09-14 23:08:39 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:39 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:39 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:39 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:39 --> Controller Class Initialized
INFO - 2018-09-14 23:08:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:39 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:39 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:39 --> Form Validation Class Initialized
INFO - 2018-09-14 23:08:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:08:39 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:39 --> Config Class Initialized
INFO - 2018-09-14 23:08:39 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:39 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:39 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:39 --> URI Class Initialized
INFO - 2018-09-14 23:08:39 --> Router Class Initialized
INFO - 2018-09-14 23:08:39 --> Output Class Initialized
INFO - 2018-09-14 23:08:39 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:39 --> CSRF cookie sent
INFO - 2018-09-14 23:08:39 --> Input Class Initialized
INFO - 2018-09-14 23:08:39 --> Language Class Initialized
INFO - 2018-09-14 23:08:39 --> Loader Class Initialized
INFO - 2018-09-14 23:08:39 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:39 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:39 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:39 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:39 --> Controller Class Initialized
INFO - 2018-09-14 23:08:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:39 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:39 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:39 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-14 23:08:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:39 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:39 --> Total execution time: 0.0373
INFO - 2018-09-14 23:08:52 --> Config Class Initialized
INFO - 2018-09-14 23:08:52 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:52 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:52 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:52 --> URI Class Initialized
INFO - 2018-09-14 23:08:52 --> Router Class Initialized
INFO - 2018-09-14 23:08:52 --> Output Class Initialized
INFO - 2018-09-14 23:08:52 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:52 --> CSRF cookie sent
INFO - 2018-09-14 23:08:52 --> CSRF token verified
INFO - 2018-09-14 23:08:52 --> Input Class Initialized
INFO - 2018-09-14 23:08:52 --> Language Class Initialized
INFO - 2018-09-14 23:08:52 --> Loader Class Initialized
INFO - 2018-09-14 23:08:52 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:52 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:52 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:52 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:52 --> Controller Class Initialized
INFO - 2018-09-14 23:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:52 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:52 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:52 --> Form Validation Class Initialized
INFO - 2018-09-14 23:08:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:08:52 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:52 --> Config Class Initialized
INFO - 2018-09-14 23:08:52 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:08:52 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:08:52 --> Utf8 Class Initialized
INFO - 2018-09-14 23:08:52 --> URI Class Initialized
INFO - 2018-09-14 23:08:52 --> Router Class Initialized
INFO - 2018-09-14 23:08:52 --> Output Class Initialized
INFO - 2018-09-14 23:08:52 --> Security Class Initialized
DEBUG - 2018-09-14 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:08:52 --> CSRF cookie sent
INFO - 2018-09-14 23:08:52 --> Input Class Initialized
INFO - 2018-09-14 23:08:52 --> Language Class Initialized
INFO - 2018-09-14 23:08:52 --> Loader Class Initialized
INFO - 2018-09-14 23:08:52 --> Helper loaded: url_helper
INFO - 2018-09-14 23:08:52 --> Helper loaded: form_helper
INFO - 2018-09-14 23:08:52 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:08:52 --> User Agent Class Initialized
INFO - 2018-09-14 23:08:52 --> Controller Class Initialized
INFO - 2018-09-14 23:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:08:52 --> Pixel_Model class loaded
INFO - 2018-09-14 23:08:52 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:52 --> Database Driver Class Initialized
INFO - 2018-09-14 23:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-14 23:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:08:52 --> Final output sent to browser
DEBUG - 2018-09-14 23:08:52 --> Total execution time: 0.0471
INFO - 2018-09-14 23:09:06 --> Config Class Initialized
INFO - 2018-09-14 23:09:06 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:06 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:06 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:06 --> URI Class Initialized
INFO - 2018-09-14 23:09:06 --> Router Class Initialized
INFO - 2018-09-14 23:09:06 --> Output Class Initialized
INFO - 2018-09-14 23:09:06 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:06 --> CSRF cookie sent
INFO - 2018-09-14 23:09:06 --> CSRF token verified
INFO - 2018-09-14 23:09:06 --> Input Class Initialized
INFO - 2018-09-14 23:09:06 --> Language Class Initialized
INFO - 2018-09-14 23:09:06 --> Loader Class Initialized
INFO - 2018-09-14 23:09:06 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:06 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:06 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:06 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:06 --> Controller Class Initialized
INFO - 2018-09-14 23:09:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:06 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:06 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:06 --> Form Validation Class Initialized
INFO - 2018-09-14 23:09:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:09:06 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:07 --> Config Class Initialized
INFO - 2018-09-14 23:09:07 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:07 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:07 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:07 --> URI Class Initialized
INFO - 2018-09-14 23:09:07 --> Router Class Initialized
INFO - 2018-09-14 23:09:07 --> Output Class Initialized
INFO - 2018-09-14 23:09:07 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:07 --> CSRF cookie sent
INFO - 2018-09-14 23:09:07 --> Input Class Initialized
INFO - 2018-09-14 23:09:07 --> Language Class Initialized
INFO - 2018-09-14 23:09:07 --> Loader Class Initialized
INFO - 2018-09-14 23:09:07 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:07 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:07 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:07 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:07 --> Controller Class Initialized
INFO - 2018-09-14 23:09:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:07 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:07 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:07 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-14 23:09:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:09:07 --> Final output sent to browser
DEBUG - 2018-09-14 23:09:07 --> Total execution time: 0.0608
INFO - 2018-09-14 23:09:15 --> Config Class Initialized
INFO - 2018-09-14 23:09:15 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:15 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:15 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:15 --> URI Class Initialized
INFO - 2018-09-14 23:09:15 --> Router Class Initialized
INFO - 2018-09-14 23:09:15 --> Output Class Initialized
INFO - 2018-09-14 23:09:15 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:15 --> CSRF cookie sent
INFO - 2018-09-14 23:09:15 --> CSRF token verified
INFO - 2018-09-14 23:09:15 --> Input Class Initialized
INFO - 2018-09-14 23:09:15 --> Language Class Initialized
INFO - 2018-09-14 23:09:15 --> Loader Class Initialized
INFO - 2018-09-14 23:09:15 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:15 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:15 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:15 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:15 --> Controller Class Initialized
INFO - 2018-09-14 23:09:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:15 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:15 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:15 --> Form Validation Class Initialized
INFO - 2018-09-14 23:09:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:09:16 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:16 --> Config Class Initialized
INFO - 2018-09-14 23:09:16 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:16 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:16 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:16 --> URI Class Initialized
INFO - 2018-09-14 23:09:16 --> Router Class Initialized
INFO - 2018-09-14 23:09:16 --> Output Class Initialized
INFO - 2018-09-14 23:09:16 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:16 --> CSRF cookie sent
INFO - 2018-09-14 23:09:16 --> Input Class Initialized
INFO - 2018-09-14 23:09:16 --> Language Class Initialized
INFO - 2018-09-14 23:09:16 --> Loader Class Initialized
INFO - 2018-09-14 23:09:16 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:16 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:16 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:16 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:16 --> Controller Class Initialized
INFO - 2018-09-14 23:09:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:16 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:16 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:16 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-14 23:09:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:09:16 --> Final output sent to browser
DEBUG - 2018-09-14 23:09:16 --> Total execution time: 0.0466
INFO - 2018-09-14 23:09:24 --> Config Class Initialized
INFO - 2018-09-14 23:09:24 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:24 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:24 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:24 --> URI Class Initialized
INFO - 2018-09-14 23:09:24 --> Router Class Initialized
INFO - 2018-09-14 23:09:24 --> Output Class Initialized
INFO - 2018-09-14 23:09:24 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:24 --> CSRF cookie sent
INFO - 2018-09-14 23:09:24 --> CSRF token verified
INFO - 2018-09-14 23:09:24 --> Input Class Initialized
INFO - 2018-09-14 23:09:24 --> Language Class Initialized
INFO - 2018-09-14 23:09:24 --> Loader Class Initialized
INFO - 2018-09-14 23:09:24 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:24 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:24 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:24 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:24 --> Controller Class Initialized
INFO - 2018-09-14 23:09:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:24 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:24 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:24 --> Form Validation Class Initialized
INFO - 2018-09-14 23:09:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-14 23:09:24 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:25 --> Config Class Initialized
INFO - 2018-09-14 23:09:25 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:25 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:25 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:25 --> URI Class Initialized
INFO - 2018-09-14 23:09:25 --> Router Class Initialized
INFO - 2018-09-14 23:09:25 --> Output Class Initialized
INFO - 2018-09-14 23:09:25 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:25 --> CSRF cookie sent
INFO - 2018-09-14 23:09:25 --> Input Class Initialized
INFO - 2018-09-14 23:09:25 --> Language Class Initialized
INFO - 2018-09-14 23:09:25 --> Loader Class Initialized
INFO - 2018-09-14 23:09:25 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:25 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:25 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:25 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:25 --> Controller Class Initialized
INFO - 2018-09-14 23:09:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-14 23:09:25 --> Pixel_Model class loaded
INFO - 2018-09-14 23:09:25 --> Database Driver Class Initialized
INFO - 2018-09-14 23:09:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-14 23:09:25 --> Config Class Initialized
INFO - 2018-09-14 23:09:25 --> Hooks Class Initialized
DEBUG - 2018-09-14 23:09:25 --> UTF-8 Support Enabled
INFO - 2018-09-14 23:09:25 --> Utf8 Class Initialized
INFO - 2018-09-14 23:09:25 --> URI Class Initialized
INFO - 2018-09-14 23:09:25 --> Router Class Initialized
INFO - 2018-09-14 23:09:25 --> Output Class Initialized
INFO - 2018-09-14 23:09:25 --> Security Class Initialized
DEBUG - 2018-09-14 23:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-14 23:09:25 --> CSRF cookie sent
INFO - 2018-09-14 23:09:25 --> Input Class Initialized
INFO - 2018-09-14 23:09:25 --> Language Class Initialized
INFO - 2018-09-14 23:09:25 --> Loader Class Initialized
INFO - 2018-09-14 23:09:25 --> Helper loaded: url_helper
INFO - 2018-09-14 23:09:25 --> Helper loaded: form_helper
INFO - 2018-09-14 23:09:25 --> Helper loaded: language_helper
DEBUG - 2018-09-14 23:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-14 23:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-14 23:09:25 --> User Agent Class Initialized
INFO - 2018-09-14 23:09:25 --> Controller Class Initialized
INFO - 2018-09-14 23:09:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-14 23:09:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-14 23:09:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-14 23:09:25 --> Could not find the language line "req_email"
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-14 23:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-14 23:09:25 --> Final output sent to browser
DEBUG - 2018-09-14 23:09:25 --> Total execution time: 0.0235

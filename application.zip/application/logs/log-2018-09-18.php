<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-18 13:08:18 --> Config Class Initialized
INFO - 2018-09-18 13:08:18 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:18 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:18 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:18 --> URI Class Initialized
DEBUG - 2018-09-18 13:08:18 --> No URI present. Default controller set.
INFO - 2018-09-18 13:08:18 --> Router Class Initialized
INFO - 2018-09-18 13:08:18 --> Output Class Initialized
INFO - 2018-09-18 13:08:18 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:18 --> CSRF cookie sent
INFO - 2018-09-18 13:08:18 --> Input Class Initialized
INFO - 2018-09-18 13:08:18 --> Language Class Initialized
INFO - 2018-09-18 13:08:18 --> Loader Class Initialized
INFO - 2018-09-18 13:08:18 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:18 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:18 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:18 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:18 --> Controller Class Initialized
INFO - 2018-09-18 13:08:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:18 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:18 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 13:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:08:18 --> Final output sent to browser
DEBUG - 2018-09-18 13:08:18 --> Total execution time: 0.0359
INFO - 2018-09-18 13:08:20 --> Config Class Initialized
INFO - 2018-09-18 13:08:20 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:20 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:20 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:20 --> URI Class Initialized
DEBUG - 2018-09-18 13:08:20 --> No URI present. Default controller set.
INFO - 2018-09-18 13:08:20 --> Router Class Initialized
INFO - 2018-09-18 13:08:20 --> Output Class Initialized
INFO - 2018-09-18 13:08:20 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:20 --> CSRF cookie sent
INFO - 2018-09-18 13:08:20 --> Input Class Initialized
INFO - 2018-09-18 13:08:20 --> Language Class Initialized
INFO - 2018-09-18 13:08:20 --> Loader Class Initialized
INFO - 2018-09-18 13:08:20 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:20 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:20 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:20 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:20 --> Controller Class Initialized
INFO - 2018-09-18 13:08:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:20 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:20 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 13:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:08:20 --> Final output sent to browser
DEBUG - 2018-09-18 13:08:20 --> Total execution time: 0.0488
INFO - 2018-09-18 13:08:32 --> Config Class Initialized
INFO - 2018-09-18 13:08:32 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:32 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:32 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:32 --> URI Class Initialized
INFO - 2018-09-18 13:08:32 --> Router Class Initialized
INFO - 2018-09-18 13:08:32 --> Output Class Initialized
INFO - 2018-09-18 13:08:32 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:32 --> CSRF cookie sent
INFO - 2018-09-18 13:08:32 --> CSRF token verified
INFO - 2018-09-18 13:08:32 --> Input Class Initialized
INFO - 2018-09-18 13:08:32 --> Language Class Initialized
INFO - 2018-09-18 13:08:32 --> Loader Class Initialized
INFO - 2018-09-18 13:08:32 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:32 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:32 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:32 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:32 --> Controller Class Initialized
INFO - 2018-09-18 13:08:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:32 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:32 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:32 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:32 --> Config Class Initialized
INFO - 2018-09-18 13:08:32 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:32 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:32 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:32 --> URI Class Initialized
INFO - 2018-09-18 13:08:32 --> Router Class Initialized
INFO - 2018-09-18 13:08:32 --> Output Class Initialized
INFO - 2018-09-18 13:08:32 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:32 --> CSRF cookie sent
INFO - 2018-09-18 13:08:32 --> Input Class Initialized
INFO - 2018-09-18 13:08:32 --> Language Class Initialized
INFO - 2018-09-18 13:08:32 --> Loader Class Initialized
INFO - 2018-09-18 13:08:32 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:32 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:32 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:32 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:32 --> Controller Class Initialized
INFO - 2018-09-18 13:08:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:32 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:32 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:32 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-18 13:08:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:08:32 --> Final output sent to browser
DEBUG - 2018-09-18 13:08:32 --> Total execution time: 0.0652
INFO - 2018-09-18 13:08:43 --> Config Class Initialized
INFO - 2018-09-18 13:08:43 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:43 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:43 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:43 --> URI Class Initialized
INFO - 2018-09-18 13:08:43 --> Router Class Initialized
INFO - 2018-09-18 13:08:43 --> Output Class Initialized
INFO - 2018-09-18 13:08:43 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:43 --> CSRF cookie sent
INFO - 2018-09-18 13:08:43 --> CSRF token verified
INFO - 2018-09-18 13:08:43 --> Input Class Initialized
INFO - 2018-09-18 13:08:43 --> Language Class Initialized
INFO - 2018-09-18 13:08:43 --> Loader Class Initialized
INFO - 2018-09-18 13:08:43 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:43 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:43 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:43 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:43 --> Controller Class Initialized
INFO - 2018-09-18 13:08:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:43 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:43 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:43 --> Form Validation Class Initialized
INFO - 2018-09-18 13:08:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 13:08:43 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:43 --> Config Class Initialized
INFO - 2018-09-18 13:08:43 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:43 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:43 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:43 --> URI Class Initialized
INFO - 2018-09-18 13:08:43 --> Router Class Initialized
INFO - 2018-09-18 13:08:43 --> Output Class Initialized
INFO - 2018-09-18 13:08:43 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:43 --> CSRF cookie sent
INFO - 2018-09-18 13:08:43 --> Input Class Initialized
INFO - 2018-09-18 13:08:43 --> Language Class Initialized
INFO - 2018-09-18 13:08:43 --> Loader Class Initialized
INFO - 2018-09-18 13:08:43 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:43 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:43 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:43 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:43 --> Controller Class Initialized
INFO - 2018-09-18 13:08:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:43 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:43 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:43 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-18 13:08:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:08:43 --> Final output sent to browser
DEBUG - 2018-09-18 13:08:43 --> Total execution time: 0.0476
INFO - 2018-09-18 13:08:51 --> Config Class Initialized
INFO - 2018-09-18 13:08:51 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:51 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:51 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:51 --> URI Class Initialized
INFO - 2018-09-18 13:08:51 --> Router Class Initialized
INFO - 2018-09-18 13:08:51 --> Output Class Initialized
INFO - 2018-09-18 13:08:51 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:51 --> CSRF cookie sent
INFO - 2018-09-18 13:08:51 --> CSRF token verified
INFO - 2018-09-18 13:08:51 --> Input Class Initialized
INFO - 2018-09-18 13:08:51 --> Language Class Initialized
INFO - 2018-09-18 13:08:51 --> Loader Class Initialized
INFO - 2018-09-18 13:08:51 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:51 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:51 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:51 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:51 --> Controller Class Initialized
INFO - 2018-09-18 13:08:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:51 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:51 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:51 --> Form Validation Class Initialized
INFO - 2018-09-18 13:08:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 13:08:51 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:51 --> Config Class Initialized
INFO - 2018-09-18 13:08:51 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:08:51 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:08:51 --> Utf8 Class Initialized
INFO - 2018-09-18 13:08:51 --> URI Class Initialized
INFO - 2018-09-18 13:08:51 --> Router Class Initialized
INFO - 2018-09-18 13:08:51 --> Output Class Initialized
INFO - 2018-09-18 13:08:51 --> Security Class Initialized
DEBUG - 2018-09-18 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:08:51 --> CSRF cookie sent
INFO - 2018-09-18 13:08:51 --> Input Class Initialized
INFO - 2018-09-18 13:08:51 --> Language Class Initialized
INFO - 2018-09-18 13:08:51 --> Loader Class Initialized
INFO - 2018-09-18 13:08:51 --> Helper loaded: url_helper
INFO - 2018-09-18 13:08:51 --> Helper loaded: form_helper
INFO - 2018-09-18 13:08:51 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:08:51 --> User Agent Class Initialized
INFO - 2018-09-18 13:08:51 --> Controller Class Initialized
INFO - 2018-09-18 13:08:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:08:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:08:51 --> Pixel_Model class loaded
INFO - 2018-09-18 13:08:51 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:51 --> Database Driver Class Initialized
INFO - 2018-09-18 13:08:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-18 13:08:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:08:51 --> Final output sent to browser
DEBUG - 2018-09-18 13:08:51 --> Total execution time: 0.0401
INFO - 2018-09-18 13:09:47 --> Config Class Initialized
INFO - 2018-09-18 13:09:47 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:09:47 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:09:47 --> Utf8 Class Initialized
INFO - 2018-09-18 13:09:47 --> URI Class Initialized
INFO - 2018-09-18 13:09:47 --> Router Class Initialized
INFO - 2018-09-18 13:09:47 --> Output Class Initialized
INFO - 2018-09-18 13:09:47 --> Security Class Initialized
DEBUG - 2018-09-18 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:09:47 --> CSRF cookie sent
INFO - 2018-09-18 13:09:47 --> CSRF token verified
INFO - 2018-09-18 13:09:47 --> Input Class Initialized
INFO - 2018-09-18 13:09:47 --> Language Class Initialized
INFO - 2018-09-18 13:09:47 --> Loader Class Initialized
INFO - 2018-09-18 13:09:47 --> Helper loaded: url_helper
INFO - 2018-09-18 13:09:47 --> Helper loaded: form_helper
INFO - 2018-09-18 13:09:47 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:09:47 --> User Agent Class Initialized
INFO - 2018-09-18 13:09:47 --> Controller Class Initialized
INFO - 2018-09-18 13:09:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:09:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:09:47 --> Pixel_Model class loaded
INFO - 2018-09-18 13:09:47 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:47 --> Form Validation Class Initialized
INFO - 2018-09-18 13:09:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 13:09:47 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:48 --> Config Class Initialized
INFO - 2018-09-18 13:09:48 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:09:48 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:09:48 --> Utf8 Class Initialized
INFO - 2018-09-18 13:09:48 --> URI Class Initialized
INFO - 2018-09-18 13:09:48 --> Router Class Initialized
INFO - 2018-09-18 13:09:48 --> Output Class Initialized
INFO - 2018-09-18 13:09:48 --> Security Class Initialized
DEBUG - 2018-09-18 13:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:09:48 --> CSRF cookie sent
INFO - 2018-09-18 13:09:48 --> Input Class Initialized
INFO - 2018-09-18 13:09:48 --> Language Class Initialized
INFO - 2018-09-18 13:09:48 --> Loader Class Initialized
INFO - 2018-09-18 13:09:48 --> Helper loaded: url_helper
INFO - 2018-09-18 13:09:48 --> Helper loaded: form_helper
INFO - 2018-09-18 13:09:48 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:09:48 --> User Agent Class Initialized
INFO - 2018-09-18 13:09:48 --> Controller Class Initialized
INFO - 2018-09-18 13:09:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:09:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:09:48 --> Pixel_Model class loaded
INFO - 2018-09-18 13:09:48 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:48 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-18 13:09:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:09:48 --> Final output sent to browser
DEBUG - 2018-09-18 13:09:48 --> Total execution time: 0.0500
INFO - 2018-09-18 13:09:55 --> Config Class Initialized
INFO - 2018-09-18 13:09:55 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:09:55 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:09:55 --> Utf8 Class Initialized
INFO - 2018-09-18 13:09:55 --> URI Class Initialized
INFO - 2018-09-18 13:09:55 --> Router Class Initialized
INFO - 2018-09-18 13:09:55 --> Output Class Initialized
INFO - 2018-09-18 13:09:55 --> Security Class Initialized
DEBUG - 2018-09-18 13:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:09:55 --> CSRF cookie sent
INFO - 2018-09-18 13:09:55 --> CSRF token verified
INFO - 2018-09-18 13:09:55 --> Input Class Initialized
INFO - 2018-09-18 13:09:55 --> Language Class Initialized
INFO - 2018-09-18 13:09:55 --> Loader Class Initialized
INFO - 2018-09-18 13:09:55 --> Helper loaded: url_helper
INFO - 2018-09-18 13:09:55 --> Helper loaded: form_helper
INFO - 2018-09-18 13:09:55 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:09:55 --> User Agent Class Initialized
INFO - 2018-09-18 13:09:55 --> Controller Class Initialized
INFO - 2018-09-18 13:09:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:09:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:09:55 --> Pixel_Model class loaded
INFO - 2018-09-18 13:09:55 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:55 --> Form Validation Class Initialized
INFO - 2018-09-18 13:09:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 13:09:55 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:55 --> Config Class Initialized
INFO - 2018-09-18 13:09:55 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:09:55 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:09:55 --> Utf8 Class Initialized
INFO - 2018-09-18 13:09:55 --> URI Class Initialized
INFO - 2018-09-18 13:09:55 --> Router Class Initialized
INFO - 2018-09-18 13:09:55 --> Output Class Initialized
INFO - 2018-09-18 13:09:55 --> Security Class Initialized
DEBUG - 2018-09-18 13:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:09:55 --> CSRF cookie sent
INFO - 2018-09-18 13:09:55 --> Input Class Initialized
INFO - 2018-09-18 13:09:55 --> Language Class Initialized
INFO - 2018-09-18 13:09:55 --> Loader Class Initialized
INFO - 2018-09-18 13:09:55 --> Helper loaded: url_helper
INFO - 2018-09-18 13:09:55 --> Helper loaded: form_helper
INFO - 2018-09-18 13:09:55 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:09:55 --> User Agent Class Initialized
INFO - 2018-09-18 13:09:55 --> Controller Class Initialized
INFO - 2018-09-18 13:09:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:09:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:09:55 --> Pixel_Model class loaded
INFO - 2018-09-18 13:09:55 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:55 --> Database Driver Class Initialized
INFO - 2018-09-18 13:09:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-09-18 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:09:55 --> Final output sent to browser
DEBUG - 2018-09-18 13:09:55 --> Total execution time: 0.0400
INFO - 2018-09-18 13:10:10 --> Config Class Initialized
INFO - 2018-09-18 13:10:10 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:10:10 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:10:10 --> Utf8 Class Initialized
INFO - 2018-09-18 13:10:10 --> URI Class Initialized
INFO - 2018-09-18 13:10:10 --> Router Class Initialized
INFO - 2018-09-18 13:10:10 --> Output Class Initialized
INFO - 2018-09-18 13:10:10 --> Security Class Initialized
DEBUG - 2018-09-18 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:10:10 --> CSRF cookie sent
INFO - 2018-09-18 13:10:10 --> Input Class Initialized
INFO - 2018-09-18 13:10:10 --> Language Class Initialized
INFO - 2018-09-18 13:10:10 --> Loader Class Initialized
INFO - 2018-09-18 13:10:10 --> Helper loaded: url_helper
INFO - 2018-09-18 13:10:10 --> Helper loaded: form_helper
INFO - 2018-09-18 13:10:10 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:10:10 --> User Agent Class Initialized
INFO - 2018-09-18 13:10:10 --> Controller Class Initialized
INFO - 2018-09-18 13:10:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:10:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:10:10 --> Pixel_Model class loaded
INFO - 2018-09-18 13:10:10 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:10 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-18 13:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:10:10 --> Final output sent to browser
DEBUG - 2018-09-18 13:10:10 --> Total execution time: 0.0395
INFO - 2018-09-18 13:10:11 --> Config Class Initialized
INFO - 2018-09-18 13:10:11 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:10:11 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:10:11 --> Utf8 Class Initialized
INFO - 2018-09-18 13:10:11 --> URI Class Initialized
INFO - 2018-09-18 13:10:11 --> Router Class Initialized
INFO - 2018-09-18 13:10:11 --> Output Class Initialized
INFO - 2018-09-18 13:10:11 --> Security Class Initialized
DEBUG - 2018-09-18 13:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:10:11 --> CSRF cookie sent
INFO - 2018-09-18 13:10:11 --> Input Class Initialized
INFO - 2018-09-18 13:10:11 --> Language Class Initialized
INFO - 2018-09-18 13:10:11 --> Loader Class Initialized
INFO - 2018-09-18 13:10:11 --> Helper loaded: url_helper
INFO - 2018-09-18 13:10:11 --> Helper loaded: form_helper
INFO - 2018-09-18 13:10:11 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:10:11 --> User Agent Class Initialized
INFO - 2018-09-18 13:10:11 --> Controller Class Initialized
INFO - 2018-09-18 13:10:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:10:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:10:11 --> Pixel_Model class loaded
INFO - 2018-09-18 13:10:11 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:11 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-18 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:10:11 --> Final output sent to browser
DEBUG - 2018-09-18 13:10:11 --> Total execution time: 0.0385
INFO - 2018-09-18 13:10:16 --> Config Class Initialized
INFO - 2018-09-18 13:10:16 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:10:16 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:10:16 --> Utf8 Class Initialized
INFO - 2018-09-18 13:10:16 --> URI Class Initialized
INFO - 2018-09-18 13:10:16 --> Router Class Initialized
INFO - 2018-09-18 13:10:16 --> Output Class Initialized
INFO - 2018-09-18 13:10:16 --> Security Class Initialized
DEBUG - 2018-09-18 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:10:16 --> CSRF cookie sent
INFO - 2018-09-18 13:10:16 --> Input Class Initialized
INFO - 2018-09-18 13:10:16 --> Language Class Initialized
INFO - 2018-09-18 13:10:16 --> Loader Class Initialized
INFO - 2018-09-18 13:10:16 --> Helper loaded: url_helper
INFO - 2018-09-18 13:10:16 --> Helper loaded: form_helper
INFO - 2018-09-18 13:10:16 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:10:16 --> User Agent Class Initialized
INFO - 2018-09-18 13:10:16 --> Controller Class Initialized
INFO - 2018-09-18 13:10:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:10:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:10:16 --> Pixel_Model class loaded
INFO - 2018-09-18 13:10:16 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:16 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-18 13:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:10:16 --> Final output sent to browser
DEBUG - 2018-09-18 13:10:16 --> Total execution time: 0.0466
INFO - 2018-09-18 13:10:20 --> Config Class Initialized
INFO - 2018-09-18 13:10:20 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:10:20 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:10:20 --> Utf8 Class Initialized
INFO - 2018-09-18 13:10:20 --> URI Class Initialized
INFO - 2018-09-18 13:10:20 --> Router Class Initialized
INFO - 2018-09-18 13:10:20 --> Output Class Initialized
INFO - 2018-09-18 13:10:20 --> Security Class Initialized
DEBUG - 2018-09-18 13:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:10:20 --> CSRF cookie sent
INFO - 2018-09-18 13:10:20 --> Input Class Initialized
INFO - 2018-09-18 13:10:20 --> Language Class Initialized
INFO - 2018-09-18 13:10:20 --> Loader Class Initialized
INFO - 2018-09-18 13:10:20 --> Helper loaded: url_helper
INFO - 2018-09-18 13:10:20 --> Helper loaded: form_helper
INFO - 2018-09-18 13:10:20 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:10:20 --> User Agent Class Initialized
INFO - 2018-09-18 13:10:20 --> Controller Class Initialized
INFO - 2018-09-18 13:10:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:10:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:10:20 --> Pixel_Model class loaded
INFO - 2018-09-18 13:10:20 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:20 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-18 13:10:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:10:20 --> Final output sent to browser
DEBUG - 2018-09-18 13:10:20 --> Total execution time: 0.0612
INFO - 2018-09-18 13:10:21 --> Config Class Initialized
INFO - 2018-09-18 13:10:21 --> Hooks Class Initialized
DEBUG - 2018-09-18 13:10:21 --> UTF-8 Support Enabled
INFO - 2018-09-18 13:10:21 --> Utf8 Class Initialized
INFO - 2018-09-18 13:10:21 --> URI Class Initialized
DEBUG - 2018-09-18 13:10:21 --> No URI present. Default controller set.
INFO - 2018-09-18 13:10:21 --> Router Class Initialized
INFO - 2018-09-18 13:10:21 --> Output Class Initialized
INFO - 2018-09-18 13:10:21 --> Security Class Initialized
DEBUG - 2018-09-18 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 13:10:21 --> CSRF cookie sent
INFO - 2018-09-18 13:10:21 --> Input Class Initialized
INFO - 2018-09-18 13:10:21 --> Language Class Initialized
INFO - 2018-09-18 13:10:21 --> Loader Class Initialized
INFO - 2018-09-18 13:10:21 --> Helper loaded: url_helper
INFO - 2018-09-18 13:10:21 --> Helper loaded: form_helper
INFO - 2018-09-18 13:10:21 --> Helper loaded: language_helper
DEBUG - 2018-09-18 13:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 13:10:21 --> User Agent Class Initialized
INFO - 2018-09-18 13:10:21 --> Controller Class Initialized
INFO - 2018-09-18 13:10:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 13:10:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 13:10:21 --> Pixel_Model class loaded
INFO - 2018-09-18 13:10:21 --> Database Driver Class Initialized
INFO - 2018-09-18 13:10:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 13:10:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 13:10:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 13:10:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 13:10:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 13:10:21 --> Final output sent to browser
DEBUG - 2018-09-18 13:10:21 --> Total execution time: 0.0436
INFO - 2018-09-18 16:48:32 --> Config Class Initialized
INFO - 2018-09-18 16:48:32 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:32 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:32 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:32 --> URI Class Initialized
DEBUG - 2018-09-18 16:48:32 --> No URI present. Default controller set.
INFO - 2018-09-18 16:48:32 --> Router Class Initialized
INFO - 2018-09-18 16:48:32 --> Output Class Initialized
INFO - 2018-09-18 16:48:32 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:32 --> CSRF cookie sent
INFO - 2018-09-18 16:48:32 --> Input Class Initialized
INFO - 2018-09-18 16:48:32 --> Language Class Initialized
INFO - 2018-09-18 16:48:32 --> Loader Class Initialized
INFO - 2018-09-18 16:48:32 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:32 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:32 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:32 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:32 --> Controller Class Initialized
INFO - 2018-09-18 16:48:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:32 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:32 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 16:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 16:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 16:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 16:48:32 --> Final output sent to browser
DEBUG - 2018-09-18 16:48:32 --> Total execution time: 0.0336
INFO - 2018-09-18 16:48:33 --> Config Class Initialized
INFO - 2018-09-18 16:48:33 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:33 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:33 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:33 --> URI Class Initialized
DEBUG - 2018-09-18 16:48:33 --> No URI present. Default controller set.
INFO - 2018-09-18 16:48:33 --> Router Class Initialized
INFO - 2018-09-18 16:48:33 --> Output Class Initialized
INFO - 2018-09-18 16:48:33 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:33 --> CSRF cookie sent
INFO - 2018-09-18 16:48:33 --> Input Class Initialized
INFO - 2018-09-18 16:48:33 --> Language Class Initialized
INFO - 2018-09-18 16:48:33 --> Loader Class Initialized
INFO - 2018-09-18 16:48:33 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:33 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:33 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:33 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:33 --> Controller Class Initialized
INFO - 2018-09-18 16:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:33 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:33 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 16:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 16:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 16:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 16:48:33 --> Final output sent to browser
DEBUG - 2018-09-18 16:48:33 --> Total execution time: 0.0350
INFO - 2018-09-18 16:48:44 --> Config Class Initialized
INFO - 2018-09-18 16:48:44 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:44 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:44 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:44 --> URI Class Initialized
INFO - 2018-09-18 16:48:44 --> Router Class Initialized
INFO - 2018-09-18 16:48:44 --> Output Class Initialized
INFO - 2018-09-18 16:48:44 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:44 --> CSRF cookie sent
INFO - 2018-09-18 16:48:44 --> CSRF token verified
INFO - 2018-09-18 16:48:44 --> Input Class Initialized
INFO - 2018-09-18 16:48:44 --> Language Class Initialized
INFO - 2018-09-18 16:48:44 --> Loader Class Initialized
INFO - 2018-09-18 16:48:44 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:44 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:44 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:44 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:44 --> Controller Class Initialized
INFO - 2018-09-18 16:48:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:44 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:44 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:44 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:44 --> Config Class Initialized
INFO - 2018-09-18 16:48:44 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:44 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:44 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:44 --> URI Class Initialized
INFO - 2018-09-18 16:48:44 --> Router Class Initialized
INFO - 2018-09-18 16:48:44 --> Output Class Initialized
INFO - 2018-09-18 16:48:44 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:44 --> CSRF cookie sent
INFO - 2018-09-18 16:48:44 --> Input Class Initialized
INFO - 2018-09-18 16:48:44 --> Language Class Initialized
INFO - 2018-09-18 16:48:44 --> Loader Class Initialized
INFO - 2018-09-18 16:48:44 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:44 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:44 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:44 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:44 --> Controller Class Initialized
INFO - 2018-09-18 16:48:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:44 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:44 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:44 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-18 16:48:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 16:48:45 --> Final output sent to browser
DEBUG - 2018-09-18 16:48:45 --> Total execution time: 0.0447
INFO - 2018-09-18 16:48:48 --> Config Class Initialized
INFO - 2018-09-18 16:48:48 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:48 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:48 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:48 --> URI Class Initialized
INFO - 2018-09-18 16:48:48 --> Router Class Initialized
INFO - 2018-09-18 16:48:48 --> Output Class Initialized
INFO - 2018-09-18 16:48:48 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:48 --> CSRF cookie sent
INFO - 2018-09-18 16:48:48 --> CSRF token verified
INFO - 2018-09-18 16:48:48 --> Input Class Initialized
INFO - 2018-09-18 16:48:48 --> Language Class Initialized
INFO - 2018-09-18 16:48:48 --> Loader Class Initialized
INFO - 2018-09-18 16:48:48 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:48 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:48 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:48 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:48 --> Controller Class Initialized
INFO - 2018-09-18 16:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:48 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:48 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:48 --> Form Validation Class Initialized
INFO - 2018-09-18 16:48:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 16:48:48 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:48 --> Config Class Initialized
INFO - 2018-09-18 16:48:48 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:48 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:48 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:48 --> URI Class Initialized
INFO - 2018-09-18 16:48:48 --> Router Class Initialized
INFO - 2018-09-18 16:48:48 --> Output Class Initialized
INFO - 2018-09-18 16:48:48 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:48 --> CSRF cookie sent
INFO - 2018-09-18 16:48:48 --> Input Class Initialized
INFO - 2018-09-18 16:48:48 --> Language Class Initialized
INFO - 2018-09-18 16:48:48 --> Loader Class Initialized
INFO - 2018-09-18 16:48:48 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:48 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:48 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:48 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:48 --> Controller Class Initialized
INFO - 2018-09-18 16:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:48 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:48 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:48 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-18 16:48:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 16:48:48 --> Final output sent to browser
DEBUG - 2018-09-18 16:48:48 --> Total execution time: 0.0466
INFO - 2018-09-18 16:48:50 --> Config Class Initialized
INFO - 2018-09-18 16:48:50 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:50 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:50 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:50 --> URI Class Initialized
INFO - 2018-09-18 16:48:50 --> Router Class Initialized
INFO - 2018-09-18 16:48:50 --> Output Class Initialized
INFO - 2018-09-18 16:48:50 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:50 --> CSRF cookie sent
INFO - 2018-09-18 16:48:50 --> CSRF token verified
INFO - 2018-09-18 16:48:50 --> Input Class Initialized
INFO - 2018-09-18 16:48:50 --> Language Class Initialized
INFO - 2018-09-18 16:48:50 --> Loader Class Initialized
INFO - 2018-09-18 16:48:50 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:50 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:50 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:50 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:50 --> Controller Class Initialized
INFO - 2018-09-18 16:48:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:50 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:50 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:50 --> Form Validation Class Initialized
INFO - 2018-09-18 16:48:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-18 16:48:50 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:51 --> Config Class Initialized
INFO - 2018-09-18 16:48:51 --> Hooks Class Initialized
DEBUG - 2018-09-18 16:48:51 --> UTF-8 Support Enabled
INFO - 2018-09-18 16:48:51 --> Utf8 Class Initialized
INFO - 2018-09-18 16:48:51 --> URI Class Initialized
INFO - 2018-09-18 16:48:51 --> Router Class Initialized
INFO - 2018-09-18 16:48:51 --> Output Class Initialized
INFO - 2018-09-18 16:48:51 --> Security Class Initialized
DEBUG - 2018-09-18 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 16:48:51 --> CSRF cookie sent
INFO - 2018-09-18 16:48:51 --> Input Class Initialized
INFO - 2018-09-18 16:48:51 --> Language Class Initialized
INFO - 2018-09-18 16:48:51 --> Loader Class Initialized
INFO - 2018-09-18 16:48:51 --> Helper loaded: url_helper
INFO - 2018-09-18 16:48:51 --> Helper loaded: form_helper
INFO - 2018-09-18 16:48:51 --> Helper loaded: language_helper
DEBUG - 2018-09-18 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 16:48:51 --> User Agent Class Initialized
INFO - 2018-09-18 16:48:51 --> Controller Class Initialized
INFO - 2018-09-18 16:48:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 16:48:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 16:48:51 --> Pixel_Model class loaded
INFO - 2018-09-18 16:48:51 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:51 --> Database Driver Class Initialized
INFO - 2018-09-18 16:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-18 16:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 16:48:51 --> Final output sent to browser
DEBUG - 2018-09-18 16:48:51 --> Total execution time: 0.0403
INFO - 2018-09-18 17:13:46 --> Config Class Initialized
INFO - 2018-09-18 17:13:46 --> Hooks Class Initialized
DEBUG - 2018-09-18 17:13:46 --> UTF-8 Support Enabled
INFO - 2018-09-18 17:13:46 --> Utf8 Class Initialized
INFO - 2018-09-18 17:13:46 --> URI Class Initialized
DEBUG - 2018-09-18 17:13:46 --> No URI present. Default controller set.
INFO - 2018-09-18 17:13:46 --> Router Class Initialized
INFO - 2018-09-18 17:13:46 --> Output Class Initialized
INFO - 2018-09-18 17:13:46 --> Security Class Initialized
DEBUG - 2018-09-18 17:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-18 17:13:46 --> CSRF cookie sent
INFO - 2018-09-18 17:13:46 --> Input Class Initialized
INFO - 2018-09-18 17:13:46 --> Language Class Initialized
INFO - 2018-09-18 17:13:46 --> Loader Class Initialized
INFO - 2018-09-18 17:13:46 --> Helper loaded: url_helper
INFO - 2018-09-18 17:13:46 --> Helper loaded: form_helper
INFO - 2018-09-18 17:13:46 --> Helper loaded: language_helper
DEBUG - 2018-09-18 17:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-18 17:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-18 17:13:46 --> User Agent Class Initialized
INFO - 2018-09-18 17:13:46 --> Controller Class Initialized
INFO - 2018-09-18 17:13:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-18 17:13:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-18 17:13:46 --> Pixel_Model class loaded
INFO - 2018-09-18 17:13:46 --> Database Driver Class Initialized
INFO - 2018-09-18 17:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-18 17:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-18 17:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-18 17:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-18 17:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-18 17:13:46 --> Final output sent to browser
DEBUG - 2018-09-18 17:13:46 --> Total execution time: 0.0518

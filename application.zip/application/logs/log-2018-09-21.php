<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-21 23:13:43 --> Config Class Initialized
INFO - 2018-09-21 23:13:43 --> Hooks Class Initialized
DEBUG - 2018-09-21 23:13:43 --> UTF-8 Support Enabled
INFO - 2018-09-21 23:13:43 --> Utf8 Class Initialized
INFO - 2018-09-21 23:13:43 --> URI Class Initialized
DEBUG - 2018-09-21 23:13:43 --> No URI present. Default controller set.
INFO - 2018-09-21 23:13:43 --> Router Class Initialized
INFO - 2018-09-21 23:13:43 --> Output Class Initialized
INFO - 2018-09-21 23:13:43 --> Security Class Initialized
DEBUG - 2018-09-21 23:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-21 23:13:43 --> CSRF cookie sent
INFO - 2018-09-21 23:13:43 --> Input Class Initialized
INFO - 2018-09-21 23:13:43 --> Language Class Initialized
INFO - 2018-09-21 23:13:43 --> Loader Class Initialized
INFO - 2018-09-21 23:13:43 --> Helper loaded: url_helper
INFO - 2018-09-21 23:13:43 --> Helper loaded: form_helper
INFO - 2018-09-21 23:13:43 --> Helper loaded: language_helper
DEBUG - 2018-09-21 23:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-21 23:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-21 23:13:43 --> User Agent Class Initialized
INFO - 2018-09-21 23:13:43 --> Controller Class Initialized
INFO - 2018-09-21 23:13:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-21 23:13:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-21 23:13:43 --> Pixel_Model class loaded
INFO - 2018-09-21 23:13:43 --> Database Driver Class Initialized
INFO - 2018-09-21 23:13:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-21 23:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-21 23:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-21 23:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-21 23:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-21 23:13:43 --> Final output sent to browser
DEBUG - 2018-09-21 23:13:43 --> Total execution time: 0.0387
INFO - 2018-09-21 23:59:36 --> Config Class Initialized
INFO - 2018-09-21 23:59:36 --> Hooks Class Initialized
DEBUG - 2018-09-21 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-09-21 23:59:36 --> Utf8 Class Initialized
INFO - 2018-09-21 23:59:36 --> URI Class Initialized
DEBUG - 2018-09-21 23:59:36 --> No URI present. Default controller set.
INFO - 2018-09-21 23:59:36 --> Router Class Initialized
INFO - 2018-09-21 23:59:36 --> Output Class Initialized
INFO - 2018-09-21 23:59:36 --> Security Class Initialized
DEBUG - 2018-09-21 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-21 23:59:36 --> CSRF cookie sent
INFO - 2018-09-21 23:59:36 --> Input Class Initialized
INFO - 2018-09-21 23:59:36 --> Language Class Initialized
INFO - 2018-09-21 23:59:36 --> Loader Class Initialized
INFO - 2018-09-21 23:59:36 --> Helper loaded: url_helper
INFO - 2018-09-21 23:59:36 --> Helper loaded: form_helper
INFO - 2018-09-21 23:59:36 --> Helper loaded: language_helper
DEBUG - 2018-09-21 23:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-21 23:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-21 23:59:36 --> User Agent Class Initialized
INFO - 2018-09-21 23:59:36 --> Controller Class Initialized
INFO - 2018-09-21 23:59:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-21 23:59:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-21 23:59:36 --> Pixel_Model class loaded
INFO - 2018-09-21 23:59:36 --> Database Driver Class Initialized
INFO - 2018-09-21 23:59:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-21 23:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-21 23:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-21 23:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-21 23:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-21 23:59:36 --> Final output sent to browser
DEBUG - 2018-09-21 23:59:36 --> Total execution time: 0.0445

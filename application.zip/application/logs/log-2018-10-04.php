<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-04 13:40:39 --> Config Class Initialized
INFO - 2018-10-04 13:40:39 --> Hooks Class Initialized
DEBUG - 2018-10-04 13:40:39 --> UTF-8 Support Enabled
INFO - 2018-10-04 13:40:39 --> Utf8 Class Initialized
INFO - 2018-10-04 13:40:39 --> URI Class Initialized
DEBUG - 2018-10-04 13:40:39 --> No URI present. Default controller set.
INFO - 2018-10-04 13:40:39 --> Router Class Initialized
INFO - 2018-10-04 13:40:39 --> Output Class Initialized
INFO - 2018-10-04 13:40:39 --> Security Class Initialized
DEBUG - 2018-10-04 13:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 13:40:39 --> CSRF cookie sent
INFO - 2018-10-04 13:40:39 --> Input Class Initialized
INFO - 2018-10-04 13:40:39 --> Language Class Initialized
INFO - 2018-10-04 13:40:39 --> Loader Class Initialized
INFO - 2018-10-04 13:40:39 --> Helper loaded: url_helper
INFO - 2018-10-04 13:40:39 --> Helper loaded: form_helper
INFO - 2018-10-04 13:40:39 --> Helper loaded: language_helper
DEBUG - 2018-10-04 13:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 13:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 13:40:39 --> User Agent Class Initialized
INFO - 2018-10-04 13:40:39 --> Controller Class Initialized
INFO - 2018-10-04 13:40:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 13:40:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 13:40:39 --> Pixel_Model class loaded
INFO - 2018-10-04 13:40:39 --> Database Driver Class Initialized
INFO - 2018-10-04 13:40:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 13:40:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 13:40:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 13:40:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-04 13:40:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 13:40:39 --> Final output sent to browser
DEBUG - 2018-10-04 13:40:39 --> Total execution time: 0.0440
INFO - 2018-10-04 13:40:42 --> Config Class Initialized
INFO - 2018-10-04 13:40:42 --> Hooks Class Initialized
DEBUG - 2018-10-04 13:40:42 --> UTF-8 Support Enabled
INFO - 2018-10-04 13:40:42 --> Utf8 Class Initialized
INFO - 2018-10-04 13:40:42 --> URI Class Initialized
DEBUG - 2018-10-04 13:40:42 --> No URI present. Default controller set.
INFO - 2018-10-04 13:40:42 --> Router Class Initialized
INFO - 2018-10-04 13:40:42 --> Output Class Initialized
INFO - 2018-10-04 13:40:42 --> Security Class Initialized
DEBUG - 2018-10-04 13:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 13:40:42 --> CSRF cookie sent
INFO - 2018-10-04 13:40:42 --> Input Class Initialized
INFO - 2018-10-04 13:40:42 --> Language Class Initialized
INFO - 2018-10-04 13:40:42 --> Loader Class Initialized
INFO - 2018-10-04 13:40:42 --> Helper loaded: url_helper
INFO - 2018-10-04 13:40:42 --> Helper loaded: form_helper
INFO - 2018-10-04 13:40:42 --> Helper loaded: language_helper
DEBUG - 2018-10-04 13:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 13:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 13:40:42 --> User Agent Class Initialized
INFO - 2018-10-04 13:40:42 --> Controller Class Initialized
INFO - 2018-10-04 13:40:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 13:40:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 13:40:42 --> Pixel_Model class loaded
INFO - 2018-10-04 13:40:42 --> Database Driver Class Initialized
INFO - 2018-10-04 13:40:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 13:40:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 13:40:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 13:40:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-04 13:40:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 13:40:42 --> Final output sent to browser
DEBUG - 2018-10-04 13:40:42 --> Total execution time: 0.0357
INFO - 2018-10-04 14:03:28 --> Config Class Initialized
INFO - 2018-10-04 14:03:28 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:28 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:28 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:28 --> URI Class Initialized
INFO - 2018-10-04 14:03:28 --> Router Class Initialized
INFO - 2018-10-04 14:03:28 --> Output Class Initialized
INFO - 2018-10-04 14:03:28 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:28 --> CSRF cookie sent
INFO - 2018-10-04 14:03:28 --> CSRF token verified
INFO - 2018-10-04 14:03:28 --> Input Class Initialized
INFO - 2018-10-04 14:03:28 --> Language Class Initialized
INFO - 2018-10-04 14:03:28 --> Loader Class Initialized
INFO - 2018-10-04 14:03:28 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:28 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:28 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:28 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:28 --> Controller Class Initialized
INFO - 2018-10-04 14:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:28 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:28 --> Config Class Initialized
INFO - 2018-10-04 14:03:28 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:28 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:28 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:28 --> URI Class Initialized
INFO - 2018-10-04 14:03:28 --> Router Class Initialized
INFO - 2018-10-04 14:03:28 --> Output Class Initialized
INFO - 2018-10-04 14:03:28 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:28 --> CSRF cookie sent
INFO - 2018-10-04 14:03:28 --> Input Class Initialized
INFO - 2018-10-04 14:03:28 --> Language Class Initialized
INFO - 2018-10-04 14:03:28 --> Loader Class Initialized
INFO - 2018-10-04 14:03:28 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:28 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:28 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:28 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:28 --> Controller Class Initialized
INFO - 2018-10-04 14:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:28 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:28 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:28 --> Total execution time: 0.0479
INFO - 2018-10-04 14:03:31 --> Config Class Initialized
INFO - 2018-10-04 14:03:31 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:31 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:31 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:31 --> URI Class Initialized
INFO - 2018-10-04 14:03:31 --> Router Class Initialized
INFO - 2018-10-04 14:03:31 --> Output Class Initialized
INFO - 2018-10-04 14:03:31 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:31 --> CSRF cookie sent
INFO - 2018-10-04 14:03:31 --> CSRF token verified
INFO - 2018-10-04 14:03:31 --> Input Class Initialized
INFO - 2018-10-04 14:03:31 --> Language Class Initialized
INFO - 2018-10-04 14:03:31 --> Loader Class Initialized
INFO - 2018-10-04 14:03:31 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:31 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:31 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:31 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:31 --> Controller Class Initialized
INFO - 2018-10-04 14:03:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:31 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:31 --> Form Validation Class Initialized
INFO - 2018-10-04 14:03:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:31 --> Config Class Initialized
INFO - 2018-10-04 14:03:31 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:31 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:31 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:31 --> URI Class Initialized
INFO - 2018-10-04 14:03:31 --> Router Class Initialized
INFO - 2018-10-04 14:03:31 --> Output Class Initialized
INFO - 2018-10-04 14:03:31 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:31 --> CSRF cookie sent
INFO - 2018-10-04 14:03:31 --> Input Class Initialized
INFO - 2018-10-04 14:03:31 --> Language Class Initialized
INFO - 2018-10-04 14:03:31 --> Loader Class Initialized
INFO - 2018-10-04 14:03:31 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:31 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:31 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:31 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:31 --> Controller Class Initialized
INFO - 2018-10-04 14:03:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:31 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:03:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:31 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:31 --> Total execution time: 0.0577
INFO - 2018-10-04 14:03:33 --> Config Class Initialized
INFO - 2018-10-04 14:03:33 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:33 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:33 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:33 --> URI Class Initialized
INFO - 2018-10-04 14:03:33 --> Router Class Initialized
INFO - 2018-10-04 14:03:33 --> Output Class Initialized
INFO - 2018-10-04 14:03:33 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:33 --> CSRF cookie sent
INFO - 2018-10-04 14:03:33 --> Input Class Initialized
INFO - 2018-10-04 14:03:33 --> Language Class Initialized
INFO - 2018-10-04 14:03:33 --> Loader Class Initialized
INFO - 2018-10-04 14:03:33 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:33 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:33 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:33 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:33 --> Controller Class Initialized
INFO - 2018-10-04 14:03:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:33 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:33 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:33 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 14:03:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:33 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:33 --> Total execution time: 0.0542
INFO - 2018-10-04 14:03:34 --> Config Class Initialized
INFO - 2018-10-04 14:03:34 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:34 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:34 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:34 --> URI Class Initialized
INFO - 2018-10-04 14:03:34 --> Router Class Initialized
INFO - 2018-10-04 14:03:34 --> Output Class Initialized
INFO - 2018-10-04 14:03:34 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:34 --> CSRF cookie sent
INFO - 2018-10-04 14:03:34 --> Input Class Initialized
INFO - 2018-10-04 14:03:34 --> Language Class Initialized
INFO - 2018-10-04 14:03:34 --> Loader Class Initialized
INFO - 2018-10-04 14:03:34 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:34 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:34 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:34 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:34 --> Controller Class Initialized
INFO - 2018-10-04 14:03:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:34 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:34 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-04 14:03:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-04 14:03:34 --> Could not find the language line "req_email"
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-04 14:03:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:34 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:34 --> Total execution time: 0.0358
INFO - 2018-10-04 14:03:36 --> Config Class Initialized
INFO - 2018-10-04 14:03:36 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:36 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:36 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:36 --> URI Class Initialized
INFO - 2018-10-04 14:03:36 --> Router Class Initialized
INFO - 2018-10-04 14:03:36 --> Output Class Initialized
INFO - 2018-10-04 14:03:36 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:36 --> CSRF cookie sent
INFO - 2018-10-04 14:03:36 --> Input Class Initialized
INFO - 2018-10-04 14:03:36 --> Language Class Initialized
INFO - 2018-10-04 14:03:36 --> Loader Class Initialized
INFO - 2018-10-04 14:03:36 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:36 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:36 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:36 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:36 --> Controller Class Initialized
INFO - 2018-10-04 14:03:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:36 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:36 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:36 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 14:03:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:36 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:36 --> Total execution time: 0.0464
INFO - 2018-10-04 14:03:51 --> Config Class Initialized
INFO - 2018-10-04 14:03:51 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:03:51 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:03:51 --> Utf8 Class Initialized
INFO - 2018-10-04 14:03:51 --> URI Class Initialized
INFO - 2018-10-04 14:03:51 --> Router Class Initialized
INFO - 2018-10-04 14:03:51 --> Output Class Initialized
INFO - 2018-10-04 14:03:51 --> Security Class Initialized
DEBUG - 2018-10-04 14:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:03:51 --> CSRF cookie sent
INFO - 2018-10-04 14:03:51 --> Input Class Initialized
INFO - 2018-10-04 14:03:51 --> Language Class Initialized
INFO - 2018-10-04 14:03:51 --> Loader Class Initialized
INFO - 2018-10-04 14:03:51 --> Helper loaded: url_helper
INFO - 2018-10-04 14:03:51 --> Helper loaded: form_helper
INFO - 2018-10-04 14:03:51 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:03:51 --> User Agent Class Initialized
INFO - 2018-10-04 14:03:51 --> Controller Class Initialized
INFO - 2018-10-04 14:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:03:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:03:51 --> Pixel_Model class loaded
INFO - 2018-10-04 14:03:51 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:51 --> Database Driver Class Initialized
INFO - 2018-10-04 14:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:03:51 --> Final output sent to browser
DEBUG - 2018-10-04 14:03:51 --> Total execution time: 0.0580
INFO - 2018-10-04 14:04:05 --> Config Class Initialized
INFO - 2018-10-04 14:04:05 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:05 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:05 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:05 --> URI Class Initialized
INFO - 2018-10-04 14:04:05 --> Router Class Initialized
INFO - 2018-10-04 14:04:05 --> Output Class Initialized
INFO - 2018-10-04 14:04:05 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:05 --> CSRF cookie sent
INFO - 2018-10-04 14:04:05 --> CSRF token verified
INFO - 2018-10-04 14:04:05 --> Input Class Initialized
INFO - 2018-10-04 14:04:05 --> Language Class Initialized
INFO - 2018-10-04 14:04:05 --> Loader Class Initialized
INFO - 2018-10-04 14:04:05 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:05 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:05 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:05 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:05 --> Controller Class Initialized
INFO - 2018-10-04 14:04:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:05 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:05 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:05 --> Form Validation Class Initialized
INFO - 2018-10-04 14:04:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:04:05 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:05 --> Config Class Initialized
INFO - 2018-10-04 14:04:05 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:05 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:05 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:05 --> URI Class Initialized
INFO - 2018-10-04 14:04:05 --> Router Class Initialized
INFO - 2018-10-04 14:04:05 --> Output Class Initialized
INFO - 2018-10-04 14:04:05 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:05 --> CSRF cookie sent
INFO - 2018-10-04 14:04:05 --> Input Class Initialized
INFO - 2018-10-04 14:04:05 --> Language Class Initialized
INFO - 2018-10-04 14:04:05 --> Loader Class Initialized
INFO - 2018-10-04 14:04:05 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:05 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:05 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:05 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:05 --> Controller Class Initialized
INFO - 2018-10-04 14:04:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:05 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:05 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:05 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-04 14:04:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:05 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:05 --> Total execution time: 0.0445
INFO - 2018-10-04 14:04:07 --> Config Class Initialized
INFO - 2018-10-04 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:07 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:07 --> URI Class Initialized
INFO - 2018-10-04 14:04:07 --> Router Class Initialized
INFO - 2018-10-04 14:04:07 --> Output Class Initialized
INFO - 2018-10-04 14:04:07 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:07 --> CSRF cookie sent
INFO - 2018-10-04 14:04:07 --> CSRF token verified
INFO - 2018-10-04 14:04:07 --> Input Class Initialized
INFO - 2018-10-04 14:04:07 --> Language Class Initialized
INFO - 2018-10-04 14:04:07 --> Loader Class Initialized
INFO - 2018-10-04 14:04:07 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:07 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:07 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:07 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:07 --> Controller Class Initialized
INFO - 2018-10-04 14:04:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:07 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:07 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:07 --> Form Validation Class Initialized
INFO - 2018-10-04 14:04:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:04:07 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:07 --> Config Class Initialized
INFO - 2018-10-04 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:07 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:07 --> URI Class Initialized
INFO - 2018-10-04 14:04:07 --> Router Class Initialized
INFO - 2018-10-04 14:04:07 --> Output Class Initialized
INFO - 2018-10-04 14:04:07 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:07 --> CSRF cookie sent
INFO - 2018-10-04 14:04:07 --> Input Class Initialized
INFO - 2018-10-04 14:04:07 --> Language Class Initialized
INFO - 2018-10-04 14:04:07 --> Loader Class Initialized
INFO - 2018-10-04 14:04:07 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:07 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:07 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:07 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:07 --> Controller Class Initialized
INFO - 2018-10-04 14:04:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:07 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:07 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:07 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:04:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:07 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:07 --> Total execution time: 0.0405
INFO - 2018-10-04 14:04:14 --> Config Class Initialized
INFO - 2018-10-04 14:04:14 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:14 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:14 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:14 --> URI Class Initialized
INFO - 2018-10-04 14:04:14 --> Router Class Initialized
INFO - 2018-10-04 14:04:14 --> Output Class Initialized
INFO - 2018-10-04 14:04:14 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:14 --> CSRF cookie sent
INFO - 2018-10-04 14:04:14 --> CSRF token verified
INFO - 2018-10-04 14:04:14 --> Input Class Initialized
INFO - 2018-10-04 14:04:14 --> Language Class Initialized
INFO - 2018-10-04 14:04:14 --> Loader Class Initialized
INFO - 2018-10-04 14:04:14 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:14 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:14 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:14 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:14 --> Controller Class Initialized
INFO - 2018-10-04 14:04:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:14 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:14 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:14 --> Form Validation Class Initialized
INFO - 2018-10-04 14:04:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:04:14 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:14 --> Config Class Initialized
INFO - 2018-10-04 14:04:14 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:14 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:14 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:14 --> URI Class Initialized
INFO - 2018-10-04 14:04:14 --> Router Class Initialized
INFO - 2018-10-04 14:04:14 --> Output Class Initialized
INFO - 2018-10-04 14:04:14 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:14 --> CSRF cookie sent
INFO - 2018-10-04 14:04:14 --> Input Class Initialized
INFO - 2018-10-04 14:04:14 --> Language Class Initialized
INFO - 2018-10-04 14:04:14 --> Loader Class Initialized
INFO - 2018-10-04 14:04:14 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:14 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:14 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:14 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:14 --> Controller Class Initialized
INFO - 2018-10-04 14:04:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:14 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:14 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:14 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:14 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:14 --> Total execution time: 0.0659
INFO - 2018-10-04 14:04:19 --> Config Class Initialized
INFO - 2018-10-04 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:19 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:19 --> URI Class Initialized
INFO - 2018-10-04 14:04:19 --> Router Class Initialized
INFO - 2018-10-04 14:04:19 --> Output Class Initialized
INFO - 2018-10-04 14:04:19 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:19 --> CSRF cookie sent
INFO - 2018-10-04 14:04:19 --> CSRF token verified
INFO - 2018-10-04 14:04:19 --> Input Class Initialized
INFO - 2018-10-04 14:04:19 --> Language Class Initialized
INFO - 2018-10-04 14:04:19 --> Loader Class Initialized
INFO - 2018-10-04 14:04:19 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:19 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:19 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:19 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:19 --> Controller Class Initialized
INFO - 2018-10-04 14:04:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:19 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:19 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:19 --> Form Validation Class Initialized
INFO - 2018-10-04 14:04:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:04:19 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:19 --> Config Class Initialized
INFO - 2018-10-04 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:19 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:19 --> URI Class Initialized
INFO - 2018-10-04 14:04:19 --> Router Class Initialized
INFO - 2018-10-04 14:04:19 --> Output Class Initialized
INFO - 2018-10-04 14:04:19 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:19 --> CSRF cookie sent
INFO - 2018-10-04 14:04:19 --> Input Class Initialized
INFO - 2018-10-04 14:04:19 --> Language Class Initialized
INFO - 2018-10-04 14:04:19 --> Loader Class Initialized
INFO - 2018-10-04 14:04:19 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:19 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:19 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:19 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:19 --> Controller Class Initialized
INFO - 2018-10-04 14:04:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:19 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:19 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:19 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-04 14:04:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:19 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:19 --> Total execution time: 0.0538
INFO - 2018-10-04 14:04:21 --> Config Class Initialized
INFO - 2018-10-04 14:04:21 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:21 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:21 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:21 --> URI Class Initialized
INFO - 2018-10-04 14:04:21 --> Router Class Initialized
INFO - 2018-10-04 14:04:21 --> Output Class Initialized
INFO - 2018-10-04 14:04:21 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:21 --> CSRF cookie sent
INFO - 2018-10-04 14:04:21 --> CSRF token verified
INFO - 2018-10-04 14:04:21 --> Input Class Initialized
INFO - 2018-10-04 14:04:21 --> Language Class Initialized
INFO - 2018-10-04 14:04:21 --> Loader Class Initialized
INFO - 2018-10-04 14:04:21 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:21 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:21 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:21 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:21 --> Controller Class Initialized
INFO - 2018-10-04 14:04:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:21 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:21 --> Form Validation Class Initialized
INFO - 2018-10-04 14:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:22 --> Config Class Initialized
INFO - 2018-10-04 14:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:22 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:22 --> URI Class Initialized
INFO - 2018-10-04 14:04:22 --> Router Class Initialized
INFO - 2018-10-04 14:04:22 --> Output Class Initialized
INFO - 2018-10-04 14:04:22 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:22 --> CSRF cookie sent
INFO - 2018-10-04 14:04:22 --> Input Class Initialized
INFO - 2018-10-04 14:04:22 --> Language Class Initialized
INFO - 2018-10-04 14:04:22 --> Loader Class Initialized
INFO - 2018-10-04 14:04:22 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:22 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:22 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:22 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:22 --> Controller Class Initialized
INFO - 2018-10-04 14:04:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:22 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:22 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:22 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-04 14:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:22 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:22 --> Total execution time: 0.0491
INFO - 2018-10-04 14:04:32 --> Config Class Initialized
INFO - 2018-10-04 14:04:32 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:32 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:32 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:32 --> URI Class Initialized
INFO - 2018-10-04 14:04:32 --> Router Class Initialized
INFO - 2018-10-04 14:04:32 --> Output Class Initialized
INFO - 2018-10-04 14:04:32 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:32 --> CSRF cookie sent
INFO - 2018-10-04 14:04:32 --> Input Class Initialized
INFO - 2018-10-04 14:04:32 --> Language Class Initialized
INFO - 2018-10-04 14:04:32 --> Loader Class Initialized
INFO - 2018-10-04 14:04:32 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:32 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:32 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:32 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:32 --> Controller Class Initialized
INFO - 2018-10-04 14:04:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:32 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:32 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:32 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-04 14:04:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:32 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:32 --> Total execution time: 0.0600
INFO - 2018-10-04 14:04:34 --> Config Class Initialized
INFO - 2018-10-04 14:04:34 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:04:34 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:04:34 --> Utf8 Class Initialized
INFO - 2018-10-04 14:04:34 --> URI Class Initialized
INFO - 2018-10-04 14:04:34 --> Router Class Initialized
INFO - 2018-10-04 14:04:34 --> Output Class Initialized
INFO - 2018-10-04 14:04:34 --> Security Class Initialized
DEBUG - 2018-10-04 14:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:04:34 --> CSRF cookie sent
INFO - 2018-10-04 14:04:34 --> Input Class Initialized
INFO - 2018-10-04 14:04:34 --> Language Class Initialized
INFO - 2018-10-04 14:04:35 --> Loader Class Initialized
INFO - 2018-10-04 14:04:35 --> Helper loaded: url_helper
INFO - 2018-10-04 14:04:35 --> Helper loaded: form_helper
INFO - 2018-10-04 14:04:35 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:04:35 --> User Agent Class Initialized
INFO - 2018-10-04 14:04:35 --> Controller Class Initialized
INFO - 2018-10-04 14:04:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:04:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:04:35 --> Pixel_Model class loaded
INFO - 2018-10-04 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-04 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:04:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:04:35 --> Final output sent to browser
DEBUG - 2018-10-04 14:04:35 --> Total execution time: 0.0472
INFO - 2018-10-04 14:05:40 --> Config Class Initialized
INFO - 2018-10-04 14:05:40 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:40 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:40 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:40 --> URI Class Initialized
INFO - 2018-10-04 14:05:40 --> Router Class Initialized
INFO - 2018-10-04 14:05:40 --> Output Class Initialized
INFO - 2018-10-04 14:05:40 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:40 --> CSRF cookie sent
INFO - 2018-10-04 14:05:40 --> Input Class Initialized
INFO - 2018-10-04 14:05:40 --> Language Class Initialized
INFO - 2018-10-04 14:05:40 --> Loader Class Initialized
INFO - 2018-10-04 14:05:40 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:40 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:40 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:40 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:40 --> Controller Class Initialized
INFO - 2018-10-04 14:05:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:40 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:40 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:40 --> Model "MyAccountModel" initialized
INFO - 2018-10-04 14:05:40 --> Config Class Initialized
INFO - 2018-10-04 14:05:40 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:40 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:40 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:40 --> URI Class Initialized
INFO - 2018-10-04 14:05:40 --> Router Class Initialized
INFO - 2018-10-04 14:05:40 --> Output Class Initialized
INFO - 2018-10-04 14:05:40 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:40 --> CSRF cookie sent
INFO - 2018-10-04 14:05:40 --> Input Class Initialized
INFO - 2018-10-04 14:05:40 --> Language Class Initialized
INFO - 2018-10-04 14:05:40 --> Loader Class Initialized
INFO - 2018-10-04 14:05:40 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:40 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:40 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:40 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:40 --> Controller Class Initialized
INFO - 2018-10-04 14:05:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:40 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:40 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:40 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-04 14:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:05:40 --> Final output sent to browser
DEBUG - 2018-10-04 14:05:40 --> Total execution time: 0.0456
INFO - 2018-10-04 14:05:44 --> Config Class Initialized
INFO - 2018-10-04 14:05:44 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:44 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:44 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:44 --> URI Class Initialized
INFO - 2018-10-04 14:05:44 --> Router Class Initialized
INFO - 2018-10-04 14:05:44 --> Output Class Initialized
INFO - 2018-10-04 14:05:44 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:44 --> CSRF cookie sent
INFO - 2018-10-04 14:05:44 --> Input Class Initialized
INFO - 2018-10-04 14:05:44 --> Language Class Initialized
INFO - 2018-10-04 14:05:44 --> Loader Class Initialized
INFO - 2018-10-04 14:05:44 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:44 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:44 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:44 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:44 --> Controller Class Initialized
INFO - 2018-10-04 14:05:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:44 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:44 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:44 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-04 14:05:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:05:44 --> Final output sent to browser
DEBUG - 2018-10-04 14:05:44 --> Total execution time: 0.0462
INFO - 2018-10-04 14:05:46 --> Config Class Initialized
INFO - 2018-10-04 14:05:46 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:46 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:46 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:46 --> URI Class Initialized
INFO - 2018-10-04 14:05:46 --> Router Class Initialized
INFO - 2018-10-04 14:05:46 --> Output Class Initialized
INFO - 2018-10-04 14:05:46 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:46 --> CSRF cookie sent
INFO - 2018-10-04 14:05:46 --> Input Class Initialized
INFO - 2018-10-04 14:05:46 --> Language Class Initialized
INFO - 2018-10-04 14:05:46 --> Loader Class Initialized
INFO - 2018-10-04 14:05:46 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:46 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:46 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:46 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:46 --> Controller Class Initialized
INFO - 2018-10-04 14:05:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:46 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:46 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:46 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:05:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:05:46 --> Final output sent to browser
DEBUG - 2018-10-04 14:05:46 --> Total execution time: 0.0602
INFO - 2018-10-04 14:05:48 --> Config Class Initialized
INFO - 2018-10-04 14:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:48 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:48 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:48 --> URI Class Initialized
INFO - 2018-10-04 14:05:48 --> Router Class Initialized
INFO - 2018-10-04 14:05:48 --> Output Class Initialized
INFO - 2018-10-04 14:05:48 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:48 --> CSRF cookie sent
INFO - 2018-10-04 14:05:48 --> Input Class Initialized
INFO - 2018-10-04 14:05:48 --> Language Class Initialized
INFO - 2018-10-04 14:05:48 --> Loader Class Initialized
INFO - 2018-10-04 14:05:48 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:48 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:48 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:48 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:48 --> Controller Class Initialized
INFO - 2018-10-04 14:05:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:48 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:05:48 --> Final output sent to browser
DEBUG - 2018-10-04 14:05:48 --> Total execution time: 0.0560
INFO - 2018-10-04 14:05:53 --> Config Class Initialized
INFO - 2018-10-04 14:05:53 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:53 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:53 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:53 --> URI Class Initialized
INFO - 2018-10-04 14:05:53 --> Router Class Initialized
INFO - 2018-10-04 14:05:53 --> Output Class Initialized
INFO - 2018-10-04 14:05:53 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:53 --> CSRF cookie sent
INFO - 2018-10-04 14:05:53 --> Input Class Initialized
INFO - 2018-10-04 14:05:53 --> Language Class Initialized
INFO - 2018-10-04 14:05:53 --> Loader Class Initialized
INFO - 2018-10-04 14:05:53 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:53 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:53 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:53 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:53 --> Controller Class Initialized
INFO - 2018-10-04 14:05:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:53 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:53 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:53 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-04 14:05:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:05:53 --> Final output sent to browser
DEBUG - 2018-10-04 14:05:53 --> Total execution time: 0.0394
INFO - 2018-10-04 14:05:59 --> Config Class Initialized
INFO - 2018-10-04 14:05:59 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:59 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:59 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:59 --> URI Class Initialized
INFO - 2018-10-04 14:05:59 --> Router Class Initialized
INFO - 2018-10-04 14:05:59 --> Output Class Initialized
INFO - 2018-10-04 14:05:59 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:59 --> CSRF cookie sent
INFO - 2018-10-04 14:05:59 --> CSRF token verified
INFO - 2018-10-04 14:05:59 --> Input Class Initialized
INFO - 2018-10-04 14:05:59 --> Language Class Initialized
INFO - 2018-10-04 14:05:59 --> Loader Class Initialized
INFO - 2018-10-04 14:05:59 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:59 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:59 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:59 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:59 --> Controller Class Initialized
INFO - 2018-10-04 14:05:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:59 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:59 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:59 --> Form Validation Class Initialized
INFO - 2018-10-04 14:05:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:05:59 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:05:59 --> Config Class Initialized
INFO - 2018-10-04 14:05:59 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:05:59 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:05:59 --> Utf8 Class Initialized
INFO - 2018-10-04 14:05:59 --> URI Class Initialized
INFO - 2018-10-04 14:05:59 --> Router Class Initialized
INFO - 2018-10-04 14:05:59 --> Output Class Initialized
INFO - 2018-10-04 14:05:59 --> Security Class Initialized
DEBUG - 2018-10-04 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:05:59 --> CSRF cookie sent
INFO - 2018-10-04 14:05:59 --> Input Class Initialized
INFO - 2018-10-04 14:05:59 --> Language Class Initialized
INFO - 2018-10-04 14:05:59 --> Loader Class Initialized
INFO - 2018-10-04 14:05:59 --> Helper loaded: url_helper
INFO - 2018-10-04 14:05:59 --> Helper loaded: form_helper
INFO - 2018-10-04 14:05:59 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:05:59 --> User Agent Class Initialized
INFO - 2018-10-04 14:05:59 --> Controller Class Initialized
INFO - 2018-10-04 14:05:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:05:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:05:59 --> Pixel_Model class loaded
INFO - 2018-10-04 14:05:59 --> Database Driver Class Initialized
INFO - 2018-10-04 14:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:00 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:00 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:00 --> Total execution time: 0.0580
INFO - 2018-10-04 14:06:01 --> Config Class Initialized
INFO - 2018-10-04 14:06:01 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:01 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:01 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:01 --> URI Class Initialized
INFO - 2018-10-04 14:06:01 --> Router Class Initialized
INFO - 2018-10-04 14:06:01 --> Output Class Initialized
INFO - 2018-10-04 14:06:01 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:01 --> CSRF cookie sent
INFO - 2018-10-04 14:06:01 --> CSRF token verified
INFO - 2018-10-04 14:06:01 --> Input Class Initialized
INFO - 2018-10-04 14:06:01 --> Language Class Initialized
INFO - 2018-10-04 14:06:01 --> Loader Class Initialized
INFO - 2018-10-04 14:06:01 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:01 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:01 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:01 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:01 --> Controller Class Initialized
INFO - 2018-10-04 14:06:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:01 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:01 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:01 --> Form Validation Class Initialized
INFO - 2018-10-04 14:06:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:06:01 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:01 --> Config Class Initialized
INFO - 2018-10-04 14:06:01 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:01 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:01 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:01 --> URI Class Initialized
INFO - 2018-10-04 14:06:01 --> Router Class Initialized
INFO - 2018-10-04 14:06:01 --> Output Class Initialized
INFO - 2018-10-04 14:06:01 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:01 --> CSRF cookie sent
INFO - 2018-10-04 14:06:01 --> Input Class Initialized
INFO - 2018-10-04 14:06:01 --> Language Class Initialized
INFO - 2018-10-04 14:06:01 --> Loader Class Initialized
INFO - 2018-10-04 14:06:01 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:01 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:01 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:01 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:01 --> Controller Class Initialized
INFO - 2018-10-04 14:06:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:01 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:01 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:01 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:06:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:01 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:01 --> Total execution time: 0.0462
INFO - 2018-10-04 14:06:02 --> Config Class Initialized
INFO - 2018-10-04 14:06:02 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:02 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:02 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:02 --> URI Class Initialized
INFO - 2018-10-04 14:06:02 --> Router Class Initialized
INFO - 2018-10-04 14:06:02 --> Output Class Initialized
INFO - 2018-10-04 14:06:02 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:02 --> CSRF cookie sent
INFO - 2018-10-04 14:06:02 --> CSRF token verified
INFO - 2018-10-04 14:06:02 --> Input Class Initialized
INFO - 2018-10-04 14:06:02 --> Language Class Initialized
INFO - 2018-10-04 14:06:02 --> Loader Class Initialized
INFO - 2018-10-04 14:06:02 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:02 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:02 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:02 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:02 --> Controller Class Initialized
INFO - 2018-10-04 14:06:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:02 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:02 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:02 --> Form Validation Class Initialized
INFO - 2018-10-04 14:06:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:06:02 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:03 --> Config Class Initialized
INFO - 2018-10-04 14:06:03 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:03 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:03 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:03 --> URI Class Initialized
INFO - 2018-10-04 14:06:03 --> Router Class Initialized
INFO - 2018-10-04 14:06:03 --> Output Class Initialized
INFO - 2018-10-04 14:06:03 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:03 --> CSRF cookie sent
INFO - 2018-10-04 14:06:03 --> Input Class Initialized
INFO - 2018-10-04 14:06:03 --> Language Class Initialized
INFO - 2018-10-04 14:06:03 --> Loader Class Initialized
INFO - 2018-10-04 14:06:03 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:03 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:03 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:03 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:03 --> Controller Class Initialized
INFO - 2018-10-04 14:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:03 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:03 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:03 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-04 14:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:03 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:03 --> Total execution time: 0.0607
INFO - 2018-10-04 14:06:10 --> Config Class Initialized
INFO - 2018-10-04 14:06:10 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:10 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:10 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:10 --> URI Class Initialized
INFO - 2018-10-04 14:06:10 --> Router Class Initialized
INFO - 2018-10-04 14:06:10 --> Output Class Initialized
INFO - 2018-10-04 14:06:10 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:10 --> CSRF cookie sent
INFO - 2018-10-04 14:06:10 --> CSRF token verified
INFO - 2018-10-04 14:06:10 --> Input Class Initialized
INFO - 2018-10-04 14:06:10 --> Language Class Initialized
INFO - 2018-10-04 14:06:10 --> Loader Class Initialized
INFO - 2018-10-04 14:06:10 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:10 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:10 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:10 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:10 --> Controller Class Initialized
INFO - 2018-10-04 14:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:10 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:10 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:10 --> Form Validation Class Initialized
INFO - 2018-10-04 14:06:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:06:10 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:10 --> Config Class Initialized
INFO - 2018-10-04 14:06:10 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:10 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:10 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:10 --> URI Class Initialized
INFO - 2018-10-04 14:06:10 --> Router Class Initialized
INFO - 2018-10-04 14:06:10 --> Output Class Initialized
INFO - 2018-10-04 14:06:10 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:10 --> CSRF cookie sent
INFO - 2018-10-04 14:06:10 --> Input Class Initialized
INFO - 2018-10-04 14:06:10 --> Language Class Initialized
INFO - 2018-10-04 14:06:10 --> Loader Class Initialized
INFO - 2018-10-04 14:06:10 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:10 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:10 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:10 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:10 --> Controller Class Initialized
INFO - 2018-10-04 14:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:10 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:10 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:10 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-04 14:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:10 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:10 --> Total execution time: 0.0535
INFO - 2018-10-04 14:06:16 --> Config Class Initialized
INFO - 2018-10-04 14:06:16 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:16 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:16 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:16 --> URI Class Initialized
INFO - 2018-10-04 14:06:16 --> Router Class Initialized
INFO - 2018-10-04 14:06:16 --> Output Class Initialized
INFO - 2018-10-04 14:06:16 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:16 --> CSRF cookie sent
INFO - 2018-10-04 14:06:16 --> CSRF token verified
INFO - 2018-10-04 14:06:16 --> Input Class Initialized
INFO - 2018-10-04 14:06:16 --> Language Class Initialized
INFO - 2018-10-04 14:06:16 --> Loader Class Initialized
INFO - 2018-10-04 14:06:16 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:16 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:16 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:16 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:16 --> Controller Class Initialized
INFO - 2018-10-04 14:06:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:16 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:16 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:16 --> Form Validation Class Initialized
INFO - 2018-10-04 14:06:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:06:16 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:16 --> Config Class Initialized
INFO - 2018-10-04 14:06:16 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:16 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:16 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:16 --> URI Class Initialized
INFO - 2018-10-04 14:06:16 --> Router Class Initialized
INFO - 2018-10-04 14:06:16 --> Output Class Initialized
INFO - 2018-10-04 14:06:16 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:16 --> CSRF cookie sent
INFO - 2018-10-04 14:06:16 --> Input Class Initialized
INFO - 2018-10-04 14:06:16 --> Language Class Initialized
INFO - 2018-10-04 14:06:16 --> Loader Class Initialized
INFO - 2018-10-04 14:06:16 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:16 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:16 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:16 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:16 --> Controller Class Initialized
INFO - 2018-10-04 14:06:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:16 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:16 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:16 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:06:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:16 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:16 --> Total execution time: 0.0479
INFO - 2018-10-04 14:06:24 --> Config Class Initialized
INFO - 2018-10-04 14:06:24 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:24 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:24 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:24 --> URI Class Initialized
INFO - 2018-10-04 14:06:24 --> Router Class Initialized
INFO - 2018-10-04 14:06:24 --> Output Class Initialized
INFO - 2018-10-04 14:06:24 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:24 --> CSRF cookie sent
INFO - 2018-10-04 14:06:24 --> Input Class Initialized
INFO - 2018-10-04 14:06:24 --> Language Class Initialized
INFO - 2018-10-04 14:06:24 --> Loader Class Initialized
INFO - 2018-10-04 14:06:24 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:24 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:24 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:24 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:24 --> Controller Class Initialized
INFO - 2018-10-04 14:06:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:24 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-04 14:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:24 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:24 --> Total execution time: 0.0640
INFO - 2018-10-04 14:06:27 --> Config Class Initialized
INFO - 2018-10-04 14:06:27 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:27 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:27 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:27 --> URI Class Initialized
INFO - 2018-10-04 14:06:27 --> Router Class Initialized
INFO - 2018-10-04 14:06:27 --> Output Class Initialized
INFO - 2018-10-04 14:06:27 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:27 --> CSRF cookie sent
INFO - 2018-10-04 14:06:27 --> Input Class Initialized
INFO - 2018-10-04 14:06:27 --> Language Class Initialized
INFO - 2018-10-04 14:06:27 --> Loader Class Initialized
INFO - 2018-10-04 14:06:27 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:27 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:27 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:27 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:27 --> Controller Class Initialized
INFO - 2018-10-04 14:06:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:27 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:27 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:27 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-04 14:06:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:27 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:27 --> Total execution time: 0.0442
INFO - 2018-10-04 14:06:28 --> Config Class Initialized
INFO - 2018-10-04 14:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:28 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:28 --> URI Class Initialized
INFO - 2018-10-04 14:06:28 --> Router Class Initialized
INFO - 2018-10-04 14:06:28 --> Output Class Initialized
INFO - 2018-10-04 14:06:28 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:28 --> CSRF cookie sent
INFO - 2018-10-04 14:06:28 --> Input Class Initialized
INFO - 2018-10-04 14:06:28 --> Language Class Initialized
INFO - 2018-10-04 14:06:28 --> Loader Class Initialized
INFO - 2018-10-04 14:06:28 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:28 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:28 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:28 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:28 --> Controller Class Initialized
INFO - 2018-10-04 14:06:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:28 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:28 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:06:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:28 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:28 --> Total execution time: 0.0461
INFO - 2018-10-04 14:06:29 --> Config Class Initialized
INFO - 2018-10-04 14:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:29 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:29 --> URI Class Initialized
INFO - 2018-10-04 14:06:29 --> Router Class Initialized
INFO - 2018-10-04 14:06:29 --> Output Class Initialized
INFO - 2018-10-04 14:06:29 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:29 --> CSRF cookie sent
INFO - 2018-10-04 14:06:29 --> Input Class Initialized
INFO - 2018-10-04 14:06:29 --> Language Class Initialized
INFO - 2018-10-04 14:06:29 --> Loader Class Initialized
INFO - 2018-10-04 14:06:29 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:29 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:29 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:29 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:29 --> Controller Class Initialized
INFO - 2018-10-04 14:06:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:29 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:29 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:29 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:06:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:29 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:29 --> Total execution time: 0.0403
INFO - 2018-10-04 14:06:34 --> Config Class Initialized
INFO - 2018-10-04 14:06:34 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:34 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:34 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:34 --> URI Class Initialized
INFO - 2018-10-04 14:06:34 --> Router Class Initialized
INFO - 2018-10-04 14:06:34 --> Output Class Initialized
INFO - 2018-10-04 14:06:34 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:34 --> CSRF cookie sent
INFO - 2018-10-04 14:06:34 --> Input Class Initialized
INFO - 2018-10-04 14:06:34 --> Language Class Initialized
INFO - 2018-10-04 14:06:34 --> Loader Class Initialized
INFO - 2018-10-04 14:06:34 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:34 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:34 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:34 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:34 --> Controller Class Initialized
INFO - 2018-10-04 14:06:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:34 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:34 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:34 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-04 14:06:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:34 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:34 --> Total execution time: 0.0461
INFO - 2018-10-04 14:06:42 --> Config Class Initialized
INFO - 2018-10-04 14:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:42 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:42 --> URI Class Initialized
INFO - 2018-10-04 14:06:42 --> Router Class Initialized
INFO - 2018-10-04 14:06:42 --> Output Class Initialized
INFO - 2018-10-04 14:06:42 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:42 --> CSRF cookie sent
INFO - 2018-10-04 14:06:42 --> Input Class Initialized
INFO - 2018-10-04 14:06:42 --> Language Class Initialized
INFO - 2018-10-04 14:06:42 --> Loader Class Initialized
INFO - 2018-10-04 14:06:42 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:42 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:42 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:42 --> Controller Class Initialized
INFO - 2018-10-04 14:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:42 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:06:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:42 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:42 --> Total execution time: 0.0449
INFO - 2018-10-04 14:06:44 --> Config Class Initialized
INFO - 2018-10-04 14:06:44 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:06:44 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:06:44 --> Utf8 Class Initialized
INFO - 2018-10-04 14:06:44 --> URI Class Initialized
INFO - 2018-10-04 14:06:44 --> Router Class Initialized
INFO - 2018-10-04 14:06:44 --> Output Class Initialized
INFO - 2018-10-04 14:06:44 --> Security Class Initialized
DEBUG - 2018-10-04 14:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:06:44 --> CSRF cookie sent
INFO - 2018-10-04 14:06:44 --> Input Class Initialized
INFO - 2018-10-04 14:06:44 --> Language Class Initialized
INFO - 2018-10-04 14:06:44 --> Loader Class Initialized
INFO - 2018-10-04 14:06:44 --> Helper loaded: url_helper
INFO - 2018-10-04 14:06:44 --> Helper loaded: form_helper
INFO - 2018-10-04 14:06:44 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:06:44 --> User Agent Class Initialized
INFO - 2018-10-04 14:06:44 --> Controller Class Initialized
INFO - 2018-10-04 14:06:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:06:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:06:44 --> Pixel_Model class loaded
INFO - 2018-10-04 14:06:44 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:44 --> Database Driver Class Initialized
INFO - 2018-10-04 14:06:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:06:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:06:44 --> Final output sent to browser
DEBUG - 2018-10-04 14:06:44 --> Total execution time: 0.0461
INFO - 2018-10-04 14:07:06 --> Config Class Initialized
INFO - 2018-10-04 14:07:06 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:06 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:06 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:06 --> URI Class Initialized
INFO - 2018-10-04 14:07:06 --> Router Class Initialized
INFO - 2018-10-04 14:07:06 --> Output Class Initialized
INFO - 2018-10-04 14:07:06 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:06 --> CSRF cookie sent
INFO - 2018-10-04 14:07:06 --> CSRF token verified
INFO - 2018-10-04 14:07:06 --> Input Class Initialized
INFO - 2018-10-04 14:07:06 --> Language Class Initialized
INFO - 2018-10-04 14:07:06 --> Loader Class Initialized
INFO - 2018-10-04 14:07:06 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:06 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:06 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:06 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:06 --> Controller Class Initialized
INFO - 2018-10-04 14:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:06 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:06 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:06 --> Form Validation Class Initialized
INFO - 2018-10-04 14:07:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:07:06 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:06 --> Config Class Initialized
INFO - 2018-10-04 14:07:06 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:06 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:06 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:06 --> URI Class Initialized
INFO - 2018-10-04 14:07:06 --> Router Class Initialized
INFO - 2018-10-04 14:07:06 --> Output Class Initialized
INFO - 2018-10-04 14:07:06 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:06 --> CSRF cookie sent
INFO - 2018-10-04 14:07:06 --> Input Class Initialized
INFO - 2018-10-04 14:07:06 --> Language Class Initialized
INFO - 2018-10-04 14:07:06 --> Loader Class Initialized
INFO - 2018-10-04 14:07:06 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:06 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:06 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:06 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:06 --> Controller Class Initialized
INFO - 2018-10-04 14:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:06 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:06 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:06 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:06 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:06 --> Total execution time: 0.0461
INFO - 2018-10-04 14:07:15 --> Config Class Initialized
INFO - 2018-10-04 14:07:15 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:15 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:15 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:15 --> URI Class Initialized
INFO - 2018-10-04 14:07:15 --> Router Class Initialized
INFO - 2018-10-04 14:07:15 --> Output Class Initialized
INFO - 2018-10-04 14:07:15 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:15 --> CSRF cookie sent
INFO - 2018-10-04 14:07:15 --> Input Class Initialized
INFO - 2018-10-04 14:07:15 --> Language Class Initialized
INFO - 2018-10-04 14:07:15 --> Loader Class Initialized
INFO - 2018-10-04 14:07:15 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:15 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:15 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:15 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:15 --> Controller Class Initialized
INFO - 2018-10-04 14:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:15 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:15 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:15 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:07:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:15 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:15 --> Total execution time: 0.0627
INFO - 2018-10-04 14:07:17 --> Config Class Initialized
INFO - 2018-10-04 14:07:17 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:17 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:17 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:17 --> URI Class Initialized
INFO - 2018-10-04 14:07:17 --> Router Class Initialized
INFO - 2018-10-04 14:07:17 --> Output Class Initialized
INFO - 2018-10-04 14:07:17 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:17 --> CSRF cookie sent
INFO - 2018-10-04 14:07:17 --> Input Class Initialized
INFO - 2018-10-04 14:07:17 --> Language Class Initialized
INFO - 2018-10-04 14:07:17 --> Loader Class Initialized
INFO - 2018-10-04 14:07:17 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:17 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:17 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:17 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:17 --> Controller Class Initialized
INFO - 2018-10-04 14:07:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:17 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:17 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:17 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:07:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:17 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:17 --> Total execution time: 0.0636
INFO - 2018-10-04 14:07:22 --> Config Class Initialized
INFO - 2018-10-04 14:07:22 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:22 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:22 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:22 --> URI Class Initialized
INFO - 2018-10-04 14:07:22 --> Router Class Initialized
INFO - 2018-10-04 14:07:22 --> Output Class Initialized
INFO - 2018-10-04 14:07:22 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:22 --> CSRF cookie sent
INFO - 2018-10-04 14:07:22 --> CSRF token verified
INFO - 2018-10-04 14:07:22 --> Input Class Initialized
INFO - 2018-10-04 14:07:22 --> Language Class Initialized
INFO - 2018-10-04 14:07:22 --> Loader Class Initialized
INFO - 2018-10-04 14:07:22 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:22 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:22 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:22 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:22 --> Controller Class Initialized
INFO - 2018-10-04 14:07:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:22 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:22 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:22 --> Form Validation Class Initialized
INFO - 2018-10-04 14:07:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:07:22 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:23 --> Config Class Initialized
INFO - 2018-10-04 14:07:23 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:23 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:23 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:23 --> URI Class Initialized
INFO - 2018-10-04 14:07:23 --> Router Class Initialized
INFO - 2018-10-04 14:07:23 --> Output Class Initialized
INFO - 2018-10-04 14:07:23 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:23 --> CSRF cookie sent
INFO - 2018-10-04 14:07:23 --> Input Class Initialized
INFO - 2018-10-04 14:07:23 --> Language Class Initialized
INFO - 2018-10-04 14:07:23 --> Loader Class Initialized
INFO - 2018-10-04 14:07:23 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:23 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:23 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:23 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:23 --> Controller Class Initialized
INFO - 2018-10-04 14:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:23 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:23 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:23 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-04 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:23 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:23 --> Total execution time: 0.0413
INFO - 2018-10-04 14:07:24 --> Config Class Initialized
INFO - 2018-10-04 14:07:24 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:24 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:24 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:24 --> URI Class Initialized
INFO - 2018-10-04 14:07:24 --> Router Class Initialized
INFO - 2018-10-04 14:07:24 --> Output Class Initialized
INFO - 2018-10-04 14:07:24 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:24 --> CSRF cookie sent
INFO - 2018-10-04 14:07:24 --> CSRF token verified
INFO - 2018-10-04 14:07:24 --> Input Class Initialized
INFO - 2018-10-04 14:07:24 --> Language Class Initialized
INFO - 2018-10-04 14:07:24 --> Loader Class Initialized
INFO - 2018-10-04 14:07:24 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:24 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:24 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:24 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:24 --> Controller Class Initialized
INFO - 2018-10-04 14:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:24 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:24 --> Form Validation Class Initialized
INFO - 2018-10-04 14:07:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:24 --> Config Class Initialized
INFO - 2018-10-04 14:07:24 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:24 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:24 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:24 --> URI Class Initialized
INFO - 2018-10-04 14:07:24 --> Router Class Initialized
INFO - 2018-10-04 14:07:24 --> Output Class Initialized
INFO - 2018-10-04 14:07:24 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:24 --> CSRF cookie sent
INFO - 2018-10-04 14:07:24 --> Input Class Initialized
INFO - 2018-10-04 14:07:24 --> Language Class Initialized
INFO - 2018-10-04 14:07:24 --> Loader Class Initialized
INFO - 2018-10-04 14:07:24 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:24 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:24 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:24 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:24 --> Controller Class Initialized
INFO - 2018-10-04 14:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:24 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:24 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:24 --> Total execution time: 0.0355
INFO - 2018-10-04 14:07:25 --> Config Class Initialized
INFO - 2018-10-04 14:07:25 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:25 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:25 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:25 --> URI Class Initialized
INFO - 2018-10-04 14:07:25 --> Router Class Initialized
INFO - 2018-10-04 14:07:25 --> Output Class Initialized
INFO - 2018-10-04 14:07:25 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:25 --> CSRF cookie sent
INFO - 2018-10-04 14:07:25 --> CSRF token verified
INFO - 2018-10-04 14:07:25 --> Input Class Initialized
INFO - 2018-10-04 14:07:25 --> Language Class Initialized
INFO - 2018-10-04 14:07:25 --> Loader Class Initialized
INFO - 2018-10-04 14:07:25 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:25 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:25 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:25 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:25 --> Controller Class Initialized
INFO - 2018-10-04 14:07:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:25 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:25 --> Form Validation Class Initialized
INFO - 2018-10-04 14:07:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:07:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:25 --> Config Class Initialized
INFO - 2018-10-04 14:07:25 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:25 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:25 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:25 --> URI Class Initialized
INFO - 2018-10-04 14:07:25 --> Router Class Initialized
INFO - 2018-10-04 14:07:25 --> Output Class Initialized
INFO - 2018-10-04 14:07:25 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:25 --> CSRF cookie sent
INFO - 2018-10-04 14:07:25 --> Input Class Initialized
INFO - 2018-10-04 14:07:25 --> Language Class Initialized
INFO - 2018-10-04 14:07:25 --> Loader Class Initialized
INFO - 2018-10-04 14:07:25 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:25 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:25 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:25 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:25 --> Controller Class Initialized
INFO - 2018-10-04 14:07:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:25 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:07:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:25 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:25 --> Total execution time: 0.0630
INFO - 2018-10-04 14:07:31 --> Config Class Initialized
INFO - 2018-10-04 14:07:31 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:31 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:31 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:31 --> URI Class Initialized
INFO - 2018-10-04 14:07:31 --> Router Class Initialized
INFO - 2018-10-04 14:07:31 --> Output Class Initialized
INFO - 2018-10-04 14:07:31 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:31 --> CSRF cookie sent
INFO - 2018-10-04 14:07:31 --> Input Class Initialized
INFO - 2018-10-04 14:07:31 --> Language Class Initialized
INFO - 2018-10-04 14:07:31 --> Loader Class Initialized
INFO - 2018-10-04 14:07:31 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:31 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:31 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:31 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:31 --> Controller Class Initialized
INFO - 2018-10-04 14:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:31 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:31 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:31 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:31 --> Total execution time: 0.0460
INFO - 2018-10-04 14:07:38 --> Config Class Initialized
INFO - 2018-10-04 14:07:38 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:38 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:38 --> URI Class Initialized
INFO - 2018-10-04 14:07:38 --> Router Class Initialized
INFO - 2018-10-04 14:07:38 --> Output Class Initialized
INFO - 2018-10-04 14:07:38 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:38 --> CSRF cookie sent
INFO - 2018-10-04 14:07:38 --> Input Class Initialized
INFO - 2018-10-04 14:07:38 --> Language Class Initialized
INFO - 2018-10-04 14:07:38 --> Loader Class Initialized
INFO - 2018-10-04 14:07:38 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:38 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:38 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:38 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:38 --> Controller Class Initialized
INFO - 2018-10-04 14:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:38 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:38 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:38 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:38 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:38 --> Total execution time: 0.0562
INFO - 2018-10-04 14:07:49 --> Config Class Initialized
INFO - 2018-10-04 14:07:49 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:49 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:49 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:49 --> URI Class Initialized
INFO - 2018-10-04 14:07:49 --> Router Class Initialized
INFO - 2018-10-04 14:07:49 --> Output Class Initialized
INFO - 2018-10-04 14:07:49 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:49 --> CSRF cookie sent
INFO - 2018-10-04 14:07:49 --> Input Class Initialized
INFO - 2018-10-04 14:07:49 --> Language Class Initialized
INFO - 2018-10-04 14:07:49 --> Loader Class Initialized
INFO - 2018-10-04 14:07:49 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:49 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:49 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:49 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:49 --> Controller Class Initialized
INFO - 2018-10-04 14:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:49 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:49 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:49 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:49 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:49 --> Total execution time: 0.0554
INFO - 2018-10-04 14:07:51 --> Config Class Initialized
INFO - 2018-10-04 14:07:51 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:07:51 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:07:51 --> Utf8 Class Initialized
INFO - 2018-10-04 14:07:51 --> URI Class Initialized
INFO - 2018-10-04 14:07:51 --> Router Class Initialized
INFO - 2018-10-04 14:07:51 --> Output Class Initialized
INFO - 2018-10-04 14:07:51 --> Security Class Initialized
DEBUG - 2018-10-04 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:07:51 --> CSRF cookie sent
INFO - 2018-10-04 14:07:51 --> Input Class Initialized
INFO - 2018-10-04 14:07:51 --> Language Class Initialized
INFO - 2018-10-04 14:07:51 --> Loader Class Initialized
INFO - 2018-10-04 14:07:51 --> Helper loaded: url_helper
INFO - 2018-10-04 14:07:51 --> Helper loaded: form_helper
INFO - 2018-10-04 14:07:51 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:07:51 --> User Agent Class Initialized
INFO - 2018-10-04 14:07:51 --> Controller Class Initialized
INFO - 2018-10-04 14:07:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:07:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:07:51 --> Pixel_Model class loaded
INFO - 2018-10-04 14:07:51 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:51 --> Database Driver Class Initialized
INFO - 2018-10-04 14:07:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:07:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:07:51 --> Final output sent to browser
DEBUG - 2018-10-04 14:07:51 --> Total execution time: 0.0489
INFO - 2018-10-04 14:08:04 --> Config Class Initialized
INFO - 2018-10-04 14:08:04 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:08:04 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:08:04 --> Utf8 Class Initialized
INFO - 2018-10-04 14:08:04 --> URI Class Initialized
INFO - 2018-10-04 14:08:04 --> Router Class Initialized
INFO - 2018-10-04 14:08:04 --> Output Class Initialized
INFO - 2018-10-04 14:08:04 --> Security Class Initialized
DEBUG - 2018-10-04 14:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:08:04 --> CSRF cookie sent
INFO - 2018-10-04 14:08:04 --> Input Class Initialized
INFO - 2018-10-04 14:08:04 --> Language Class Initialized
INFO - 2018-10-04 14:08:04 --> Loader Class Initialized
INFO - 2018-10-04 14:08:04 --> Helper loaded: url_helper
INFO - 2018-10-04 14:08:04 --> Helper loaded: form_helper
INFO - 2018-10-04 14:08:04 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:08:04 --> User Agent Class Initialized
INFO - 2018-10-04 14:08:04 --> Controller Class Initialized
INFO - 2018-10-04 14:08:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:08:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:08:04 --> Pixel_Model class loaded
INFO - 2018-10-04 14:08:04 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:04 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:08:04 --> Final output sent to browser
DEBUG - 2018-10-04 14:08:04 --> Total execution time: 0.0452
INFO - 2018-10-04 14:08:08 --> Config Class Initialized
INFO - 2018-10-04 14:08:08 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:08:08 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:08:08 --> Utf8 Class Initialized
INFO - 2018-10-04 14:08:08 --> URI Class Initialized
INFO - 2018-10-04 14:08:08 --> Router Class Initialized
INFO - 2018-10-04 14:08:08 --> Output Class Initialized
INFO - 2018-10-04 14:08:08 --> Security Class Initialized
DEBUG - 2018-10-04 14:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:08:08 --> CSRF cookie sent
INFO - 2018-10-04 14:08:08 --> Input Class Initialized
INFO - 2018-10-04 14:08:08 --> Language Class Initialized
INFO - 2018-10-04 14:08:08 --> Loader Class Initialized
INFO - 2018-10-04 14:08:08 --> Helper loaded: url_helper
INFO - 2018-10-04 14:08:08 --> Helper loaded: form_helper
INFO - 2018-10-04 14:08:08 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:08:08 --> User Agent Class Initialized
INFO - 2018-10-04 14:08:08 --> Controller Class Initialized
INFO - 2018-10-04 14:08:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:08:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:08:08 --> Pixel_Model class loaded
INFO - 2018-10-04 14:08:08 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:08 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:08:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:08:08 --> Final output sent to browser
DEBUG - 2018-10-04 14:08:08 --> Total execution time: 0.0645
INFO - 2018-10-04 14:08:11 --> Config Class Initialized
INFO - 2018-10-04 14:08:11 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:08:11 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:08:11 --> Utf8 Class Initialized
INFO - 2018-10-04 14:08:11 --> URI Class Initialized
INFO - 2018-10-04 14:08:11 --> Router Class Initialized
INFO - 2018-10-04 14:08:11 --> Output Class Initialized
INFO - 2018-10-04 14:08:11 --> Security Class Initialized
DEBUG - 2018-10-04 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:08:11 --> CSRF cookie sent
INFO - 2018-10-04 14:08:11 --> Input Class Initialized
INFO - 2018-10-04 14:08:11 --> Language Class Initialized
INFO - 2018-10-04 14:08:11 --> Loader Class Initialized
INFO - 2018-10-04 14:08:11 --> Helper loaded: url_helper
INFO - 2018-10-04 14:08:11 --> Helper loaded: form_helper
INFO - 2018-10-04 14:08:11 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:08:11 --> User Agent Class Initialized
INFO - 2018-10-04 14:08:11 --> Controller Class Initialized
INFO - 2018-10-04 14:08:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:08:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:08:11 --> Pixel_Model class loaded
INFO - 2018-10-04 14:08:11 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:11 --> Database Driver Class Initialized
INFO - 2018-10-04 14:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:08:11 --> Final output sent to browser
DEBUG - 2018-10-04 14:08:11 --> Total execution time: 0.0706
INFO - 2018-10-04 14:09:58 --> Config Class Initialized
INFO - 2018-10-04 14:09:58 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:09:58 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:09:58 --> Utf8 Class Initialized
INFO - 2018-10-04 14:09:58 --> URI Class Initialized
INFO - 2018-10-04 14:09:58 --> Router Class Initialized
INFO - 2018-10-04 14:09:58 --> Output Class Initialized
INFO - 2018-10-04 14:09:58 --> Security Class Initialized
DEBUG - 2018-10-04 14:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:09:58 --> CSRF cookie sent
INFO - 2018-10-04 14:09:58 --> Input Class Initialized
INFO - 2018-10-04 14:09:58 --> Language Class Initialized
INFO - 2018-10-04 14:09:58 --> Loader Class Initialized
INFO - 2018-10-04 14:09:58 --> Helper loaded: url_helper
INFO - 2018-10-04 14:09:58 --> Helper loaded: form_helper
INFO - 2018-10-04 14:09:58 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:09:58 --> User Agent Class Initialized
INFO - 2018-10-04 14:09:58 --> Controller Class Initialized
INFO - 2018-10-04 14:09:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:09:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:09:58 --> Pixel_Model class loaded
INFO - 2018-10-04 14:09:58 --> Database Driver Class Initialized
INFO - 2018-10-04 14:09:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:09:58 --> Database Driver Class Initialized
INFO - 2018-10-04 14:09:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:09:58 --> Final output sent to browser
DEBUG - 2018-10-04 14:09:58 --> Total execution time: 0.0458
INFO - 2018-10-04 14:09:59 --> Config Class Initialized
INFO - 2018-10-04 14:09:59 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:09:59 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:09:59 --> Utf8 Class Initialized
INFO - 2018-10-04 14:09:59 --> URI Class Initialized
INFO - 2018-10-04 14:09:59 --> Router Class Initialized
INFO - 2018-10-04 14:09:59 --> Output Class Initialized
INFO - 2018-10-04 14:09:59 --> Security Class Initialized
DEBUG - 2018-10-04 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:09:59 --> CSRF cookie sent
INFO - 2018-10-04 14:09:59 --> Input Class Initialized
INFO - 2018-10-04 14:09:59 --> Language Class Initialized
INFO - 2018-10-04 14:09:59 --> Loader Class Initialized
INFO - 2018-10-04 14:09:59 --> Helper loaded: url_helper
INFO - 2018-10-04 14:09:59 --> Helper loaded: form_helper
INFO - 2018-10-04 14:09:59 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:09:59 --> User Agent Class Initialized
INFO - 2018-10-04 14:09:59 --> Controller Class Initialized
INFO - 2018-10-04 14:09:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:09:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:09:59 --> Pixel_Model class loaded
INFO - 2018-10-04 14:09:59 --> Database Driver Class Initialized
INFO - 2018-10-04 14:09:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:09:59 --> Database Driver Class Initialized
INFO - 2018-10-04 14:09:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-04 14:09:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:09:59 --> Final output sent to browser
DEBUG - 2018-10-04 14:09:59 --> Total execution time: 0.0508
INFO - 2018-10-04 14:10:00 --> Config Class Initialized
INFO - 2018-10-04 14:10:00 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:00 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:00 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:00 --> URI Class Initialized
INFO - 2018-10-04 14:10:00 --> Router Class Initialized
INFO - 2018-10-04 14:10:00 --> Output Class Initialized
INFO - 2018-10-04 14:10:00 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:00 --> CSRF cookie sent
INFO - 2018-10-04 14:10:00 --> Input Class Initialized
INFO - 2018-10-04 14:10:00 --> Language Class Initialized
INFO - 2018-10-04 14:10:00 --> Loader Class Initialized
INFO - 2018-10-04 14:10:00 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:00 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:00 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:00 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:00 --> Controller Class Initialized
INFO - 2018-10-04 14:10:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:00 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:00 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:00 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-04 14:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:00 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:00 --> Total execution time: 0.0590
INFO - 2018-10-04 14:10:03 --> Config Class Initialized
INFO - 2018-10-04 14:10:03 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:03 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:03 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:03 --> URI Class Initialized
INFO - 2018-10-04 14:10:03 --> Router Class Initialized
INFO - 2018-10-04 14:10:03 --> Output Class Initialized
INFO - 2018-10-04 14:10:03 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:03 --> CSRF cookie sent
INFO - 2018-10-04 14:10:03 --> Input Class Initialized
INFO - 2018-10-04 14:10:03 --> Language Class Initialized
INFO - 2018-10-04 14:10:03 --> Loader Class Initialized
INFO - 2018-10-04 14:10:03 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:03 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:03 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:03 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:03 --> Controller Class Initialized
INFO - 2018-10-04 14:10:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:03 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:03 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:03 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-04 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:03 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:03 --> Total execution time: 0.0421
INFO - 2018-10-04 14:10:04 --> Config Class Initialized
INFO - 2018-10-04 14:10:04 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:04 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:04 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:04 --> URI Class Initialized
INFO - 2018-10-04 14:10:04 --> Router Class Initialized
INFO - 2018-10-04 14:10:04 --> Output Class Initialized
INFO - 2018-10-04 14:10:04 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:04 --> CSRF cookie sent
INFO - 2018-10-04 14:10:04 --> Input Class Initialized
INFO - 2018-10-04 14:10:04 --> Language Class Initialized
INFO - 2018-10-04 14:10:04 --> Loader Class Initialized
INFO - 2018-10-04 14:10:04 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:04 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:04 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:04 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:04 --> Controller Class Initialized
INFO - 2018-10-04 14:10:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:04 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:04 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:04 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-04 14:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:04 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:04 --> Total execution time: 0.0411
INFO - 2018-10-04 14:10:11 --> Config Class Initialized
INFO - 2018-10-04 14:10:11 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:11 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:11 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:11 --> URI Class Initialized
INFO - 2018-10-04 14:10:11 --> Router Class Initialized
INFO - 2018-10-04 14:10:11 --> Output Class Initialized
INFO - 2018-10-04 14:10:11 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:11 --> CSRF cookie sent
INFO - 2018-10-04 14:10:11 --> Input Class Initialized
INFO - 2018-10-04 14:10:11 --> Language Class Initialized
INFO - 2018-10-04 14:10:12 --> Loader Class Initialized
INFO - 2018-10-04 14:10:12 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:12 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:12 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:12 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:12 --> Controller Class Initialized
INFO - 2018-10-04 14:10:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:12 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:12 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:12 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:12 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:12 --> Total execution time: 0.0486
INFO - 2018-10-04 14:10:13 --> Config Class Initialized
INFO - 2018-10-04 14:10:13 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:13 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:13 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:13 --> URI Class Initialized
INFO - 2018-10-04 14:10:13 --> Router Class Initialized
INFO - 2018-10-04 14:10:13 --> Output Class Initialized
INFO - 2018-10-04 14:10:13 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:13 --> CSRF cookie sent
INFO - 2018-10-04 14:10:13 --> Input Class Initialized
INFO - 2018-10-04 14:10:13 --> Language Class Initialized
INFO - 2018-10-04 14:10:13 --> Loader Class Initialized
INFO - 2018-10-04 14:10:13 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:13 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:13 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:13 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:13 --> Controller Class Initialized
INFO - 2018-10-04 14:10:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:13 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:13 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:13 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:13 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:13 --> Total execution time: 0.0375
INFO - 2018-10-04 14:10:25 --> Config Class Initialized
INFO - 2018-10-04 14:10:25 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:25 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:25 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:25 --> URI Class Initialized
INFO - 2018-10-04 14:10:25 --> Router Class Initialized
INFO - 2018-10-04 14:10:25 --> Output Class Initialized
INFO - 2018-10-04 14:10:25 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:25 --> CSRF cookie sent
INFO - 2018-10-04 14:10:25 --> CSRF token verified
INFO - 2018-10-04 14:10:25 --> Input Class Initialized
INFO - 2018-10-04 14:10:25 --> Language Class Initialized
INFO - 2018-10-04 14:10:25 --> Loader Class Initialized
INFO - 2018-10-04 14:10:25 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:25 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:25 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:25 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:25 --> Controller Class Initialized
INFO - 2018-10-04 14:10:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:25 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:25 --> Form Validation Class Initialized
INFO - 2018-10-04 14:10:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 14:10:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:25 --> Config Class Initialized
INFO - 2018-10-04 14:10:25 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:10:25 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:10:25 --> Utf8 Class Initialized
INFO - 2018-10-04 14:10:25 --> URI Class Initialized
INFO - 2018-10-04 14:10:25 --> Router Class Initialized
INFO - 2018-10-04 14:10:25 --> Output Class Initialized
INFO - 2018-10-04 14:10:25 --> Security Class Initialized
DEBUG - 2018-10-04 14:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:10:25 --> CSRF cookie sent
INFO - 2018-10-04 14:10:25 --> Input Class Initialized
INFO - 2018-10-04 14:10:25 --> Language Class Initialized
INFO - 2018-10-04 14:10:25 --> Loader Class Initialized
INFO - 2018-10-04 14:10:25 --> Helper loaded: url_helper
INFO - 2018-10-04 14:10:25 --> Helper loaded: form_helper
INFO - 2018-10-04 14:10:25 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:10:25 --> User Agent Class Initialized
INFO - 2018-10-04 14:10:25 --> Controller Class Initialized
INFO - 2018-10-04 14:10:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:10:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:10:25 --> Pixel_Model class loaded
INFO - 2018-10-04 14:10:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:25 --> Database Driver Class Initialized
INFO - 2018-10-04 14:10:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:10:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:10:25 --> Final output sent to browser
DEBUG - 2018-10-04 14:10:25 --> Total execution time: 0.0461
INFO - 2018-10-04 14:11:29 --> Config Class Initialized
INFO - 2018-10-04 14:11:29 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:11:29 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:11:29 --> Utf8 Class Initialized
INFO - 2018-10-04 14:11:29 --> URI Class Initialized
INFO - 2018-10-04 14:11:29 --> Router Class Initialized
INFO - 2018-10-04 14:11:29 --> Output Class Initialized
INFO - 2018-10-04 14:11:29 --> Security Class Initialized
DEBUG - 2018-10-04 14:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:11:29 --> CSRF cookie sent
INFO - 2018-10-04 14:11:29 --> Input Class Initialized
INFO - 2018-10-04 14:11:29 --> Language Class Initialized
INFO - 2018-10-04 14:11:29 --> Loader Class Initialized
INFO - 2018-10-04 14:11:29 --> Helper loaded: url_helper
INFO - 2018-10-04 14:11:29 --> Helper loaded: form_helper
INFO - 2018-10-04 14:11:29 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:11:29 --> User Agent Class Initialized
INFO - 2018-10-04 14:11:29 --> Controller Class Initialized
INFO - 2018-10-04 14:11:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:11:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:11:29 --> Pixel_Model class loaded
INFO - 2018-10-04 14:11:29 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:29 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:11:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:11:29 --> Final output sent to browser
DEBUG - 2018-10-04 14:11:29 --> Total execution time: 0.0465
INFO - 2018-10-04 14:11:42 --> Config Class Initialized
INFO - 2018-10-04 14:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:11:42 --> Utf8 Class Initialized
INFO - 2018-10-04 14:11:42 --> URI Class Initialized
INFO - 2018-10-04 14:11:42 --> Router Class Initialized
INFO - 2018-10-04 14:11:42 --> Output Class Initialized
INFO - 2018-10-04 14:11:42 --> Security Class Initialized
DEBUG - 2018-10-04 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:11:42 --> CSRF cookie sent
INFO - 2018-10-04 14:11:42 --> Input Class Initialized
INFO - 2018-10-04 14:11:42 --> Language Class Initialized
INFO - 2018-10-04 14:11:42 --> Loader Class Initialized
INFO - 2018-10-04 14:11:42 --> Helper loaded: url_helper
INFO - 2018-10-04 14:11:42 --> Helper loaded: form_helper
INFO - 2018-10-04 14:11:42 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:11:42 --> User Agent Class Initialized
INFO - 2018-10-04 14:11:42 --> Controller Class Initialized
INFO - 2018-10-04 14:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:11:42 --> Pixel_Model class loaded
INFO - 2018-10-04 14:11:42 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:42 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 14:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:11:42 --> Final output sent to browser
DEBUG - 2018-10-04 14:11:42 --> Total execution time: 0.0457
INFO - 2018-10-04 14:11:45 --> Config Class Initialized
INFO - 2018-10-04 14:11:45 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:11:45 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:11:45 --> Utf8 Class Initialized
INFO - 2018-10-04 14:11:45 --> URI Class Initialized
INFO - 2018-10-04 14:11:45 --> Router Class Initialized
INFO - 2018-10-04 14:11:45 --> Output Class Initialized
INFO - 2018-10-04 14:11:45 --> Security Class Initialized
DEBUG - 2018-10-04 14:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:11:45 --> CSRF cookie sent
INFO - 2018-10-04 14:11:45 --> Input Class Initialized
INFO - 2018-10-04 14:11:45 --> Language Class Initialized
INFO - 2018-10-04 14:11:45 --> Loader Class Initialized
INFO - 2018-10-04 14:11:45 --> Helper loaded: url_helper
INFO - 2018-10-04 14:11:45 --> Helper loaded: form_helper
INFO - 2018-10-04 14:11:45 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:11:45 --> User Agent Class Initialized
INFO - 2018-10-04 14:11:45 --> Controller Class Initialized
INFO - 2018-10-04 14:11:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:11:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:11:45 --> Pixel_Model class loaded
INFO - 2018-10-04 14:11:45 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:45 --> Database Driver Class Initialized
INFO - 2018-10-04 14:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 14:11:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:11:45 --> Final output sent to browser
DEBUG - 2018-10-04 14:11:45 --> Total execution time: 0.0540
INFO - 2018-10-04 14:12:20 --> Config Class Initialized
INFO - 2018-10-04 14:12:20 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:12:20 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:12:20 --> Utf8 Class Initialized
INFO - 2018-10-04 14:12:20 --> URI Class Initialized
INFO - 2018-10-04 14:12:20 --> Router Class Initialized
INFO - 2018-10-04 14:12:20 --> Output Class Initialized
INFO - 2018-10-04 14:12:20 --> Security Class Initialized
DEBUG - 2018-10-04 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:12:20 --> CSRF cookie sent
INFO - 2018-10-04 14:12:20 --> Input Class Initialized
INFO - 2018-10-04 14:12:20 --> Language Class Initialized
INFO - 2018-10-04 14:12:20 --> Loader Class Initialized
INFO - 2018-10-04 14:12:20 --> Helper loaded: url_helper
INFO - 2018-10-04 14:12:20 --> Helper loaded: form_helper
INFO - 2018-10-04 14:12:20 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:12:20 --> User Agent Class Initialized
INFO - 2018-10-04 14:12:20 --> Controller Class Initialized
INFO - 2018-10-04 14:12:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:12:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:12:20 --> Pixel_Model class loaded
INFO - 2018-10-04 14:12:20 --> Database Driver Class Initialized
INFO - 2018-10-04 14:12:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:12:20 --> Database Driver Class Initialized
INFO - 2018-10-04 14:12:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 14:12:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:12:20 --> Final output sent to browser
DEBUG - 2018-10-04 14:12:20 --> Total execution time: 0.0456
INFO - 2018-10-04 14:12:23 --> Config Class Initialized
INFO - 2018-10-04 14:12:23 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:12:23 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:12:23 --> Utf8 Class Initialized
INFO - 2018-10-04 14:12:23 --> URI Class Initialized
INFO - 2018-10-04 14:12:23 --> Router Class Initialized
INFO - 2018-10-04 14:12:23 --> Output Class Initialized
INFO - 2018-10-04 14:12:23 --> Security Class Initialized
DEBUG - 2018-10-04 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:12:23 --> CSRF cookie sent
INFO - 2018-10-04 14:12:23 --> Input Class Initialized
INFO - 2018-10-04 14:12:23 --> Language Class Initialized
INFO - 2018-10-04 14:12:23 --> Loader Class Initialized
INFO - 2018-10-04 14:12:23 --> Helper loaded: url_helper
INFO - 2018-10-04 14:12:23 --> Helper loaded: form_helper
INFO - 2018-10-04 14:12:23 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:12:23 --> User Agent Class Initialized
INFO - 2018-10-04 14:12:23 --> Controller Class Initialized
INFO - 2018-10-04 14:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:12:23 --> Pixel_Model class loaded
INFO - 2018-10-04 14:12:23 --> Database Driver Class Initialized
INFO - 2018-10-04 14:12:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-04 14:12:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-04 14:12:23 --> Could not find the language line "req_email"
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-04 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:12:23 --> Final output sent to browser
DEBUG - 2018-10-04 14:12:23 --> Total execution time: 0.0469
INFO - 2018-10-04 14:12:40 --> Config Class Initialized
INFO - 2018-10-04 14:12:40 --> Hooks Class Initialized
DEBUG - 2018-10-04 14:12:40 --> UTF-8 Support Enabled
INFO - 2018-10-04 14:12:40 --> Utf8 Class Initialized
INFO - 2018-10-04 14:12:40 --> URI Class Initialized
INFO - 2018-10-04 14:12:40 --> Router Class Initialized
INFO - 2018-10-04 14:12:40 --> Output Class Initialized
INFO - 2018-10-04 14:12:40 --> Security Class Initialized
DEBUG - 2018-10-04 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 14:12:40 --> CSRF cookie sent
INFO - 2018-10-04 14:12:40 --> Input Class Initialized
INFO - 2018-10-04 14:12:40 --> Language Class Initialized
INFO - 2018-10-04 14:12:40 --> Loader Class Initialized
INFO - 2018-10-04 14:12:40 --> Helper loaded: url_helper
INFO - 2018-10-04 14:12:40 --> Helper loaded: form_helper
INFO - 2018-10-04 14:12:40 --> Helper loaded: language_helper
DEBUG - 2018-10-04 14:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 14:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 14:12:40 --> User Agent Class Initialized
INFO - 2018-10-04 14:12:40 --> Controller Class Initialized
INFO - 2018-10-04 14:12:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 14:12:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 14:12:40 --> Pixel_Model class loaded
INFO - 2018-10-04 14:12:40 --> Database Driver Class Initialized
INFO - 2018-10-04 14:12:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:12:40 --> Database Driver Class Initialized
INFO - 2018-10-04 14:12:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 14:12:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 14:12:40 --> Final output sent to browser
DEBUG - 2018-10-04 14:12:40 --> Total execution time: 0.0645
INFO - 2018-10-04 22:46:37 --> Config Class Initialized
INFO - 2018-10-04 22:46:37 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:46:37 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:46:37 --> Utf8 Class Initialized
INFO - 2018-10-04 22:46:37 --> URI Class Initialized
DEBUG - 2018-10-04 22:46:37 --> No URI present. Default controller set.
INFO - 2018-10-04 22:46:37 --> Router Class Initialized
INFO - 2018-10-04 22:46:37 --> Output Class Initialized
INFO - 2018-10-04 22:46:37 --> Security Class Initialized
DEBUG - 2018-10-04 22:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:46:37 --> CSRF cookie sent
INFO - 2018-10-04 22:46:37 --> Input Class Initialized
INFO - 2018-10-04 22:46:37 --> Language Class Initialized
INFO - 2018-10-04 22:46:37 --> Loader Class Initialized
INFO - 2018-10-04 22:46:37 --> Helper loaded: url_helper
INFO - 2018-10-04 22:46:37 --> Helper loaded: form_helper
INFO - 2018-10-04 22:46:37 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:46:37 --> User Agent Class Initialized
INFO - 2018-10-04 22:46:37 --> Controller Class Initialized
INFO - 2018-10-04 22:46:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:46:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:46:37 --> Pixel_Model class loaded
INFO - 2018-10-04 22:46:37 --> Database Driver Class Initialized
INFO - 2018-10-04 22:46:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-04 22:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:46:37 --> Final output sent to browser
DEBUG - 2018-10-04 22:46:37 --> Total execution time: 0.0349
INFO - 2018-10-04 22:49:44 --> Config Class Initialized
INFO - 2018-10-04 22:49:44 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:44 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:44 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:44 --> URI Class Initialized
DEBUG - 2018-10-04 22:49:44 --> No URI present. Default controller set.
INFO - 2018-10-04 22:49:44 --> Router Class Initialized
INFO - 2018-10-04 22:49:44 --> Output Class Initialized
INFO - 2018-10-04 22:49:44 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:44 --> CSRF cookie sent
INFO - 2018-10-04 22:49:44 --> Input Class Initialized
INFO - 2018-10-04 22:49:44 --> Language Class Initialized
INFO - 2018-10-04 22:49:44 --> Loader Class Initialized
INFO - 2018-10-04 22:49:44 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:44 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:44 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:44 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:44 --> Controller Class Initialized
INFO - 2018-10-04 22:49:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:44 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:44 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-04 22:49:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:44 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:44 --> Total execution time: 0.0414
INFO - 2018-10-04 22:49:48 --> Config Class Initialized
INFO - 2018-10-04 22:49:48 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:48 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:48 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:48 --> URI Class Initialized
INFO - 2018-10-04 22:49:48 --> Router Class Initialized
INFO - 2018-10-04 22:49:48 --> Output Class Initialized
INFO - 2018-10-04 22:49:48 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:48 --> CSRF cookie sent
INFO - 2018-10-04 22:49:48 --> CSRF token verified
INFO - 2018-10-04 22:49:48 --> Input Class Initialized
INFO - 2018-10-04 22:49:48 --> Language Class Initialized
INFO - 2018-10-04 22:49:48 --> Loader Class Initialized
INFO - 2018-10-04 22:49:48 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:48 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:48 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:48 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:48 --> Controller Class Initialized
INFO - 2018-10-04 22:49:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:48 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:48 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:48 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:48 --> Config Class Initialized
INFO - 2018-10-04 22:49:48 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:48 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:48 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:48 --> URI Class Initialized
INFO - 2018-10-04 22:49:48 --> Router Class Initialized
INFO - 2018-10-04 22:49:48 --> Output Class Initialized
INFO - 2018-10-04 22:49:48 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:48 --> CSRF cookie sent
INFO - 2018-10-04 22:49:48 --> Input Class Initialized
INFO - 2018-10-04 22:49:48 --> Language Class Initialized
INFO - 2018-10-04 22:49:48 --> Loader Class Initialized
INFO - 2018-10-04 22:49:48 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:48 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:48 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:48 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:48 --> Controller Class Initialized
INFO - 2018-10-04 22:49:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:48 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:48 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:48 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-04 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:48 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:48 --> Total execution time: 0.0472
INFO - 2018-10-04 22:49:51 --> Config Class Initialized
INFO - 2018-10-04 22:49:51 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:51 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:51 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:51 --> URI Class Initialized
INFO - 2018-10-04 22:49:51 --> Router Class Initialized
INFO - 2018-10-04 22:49:51 --> Output Class Initialized
INFO - 2018-10-04 22:49:51 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:51 --> CSRF cookie sent
INFO - 2018-10-04 22:49:51 --> CSRF token verified
INFO - 2018-10-04 22:49:51 --> Input Class Initialized
INFO - 2018-10-04 22:49:51 --> Language Class Initialized
INFO - 2018-10-04 22:49:51 --> Loader Class Initialized
INFO - 2018-10-04 22:49:51 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:51 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:51 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:51 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:51 --> Controller Class Initialized
INFO - 2018-10-04 22:49:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:51 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:51 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:51 --> Form Validation Class Initialized
INFO - 2018-10-04 22:49:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-04 22:49:51 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:51 --> Config Class Initialized
INFO - 2018-10-04 22:49:51 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:51 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:51 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:51 --> URI Class Initialized
INFO - 2018-10-04 22:49:51 --> Router Class Initialized
INFO - 2018-10-04 22:49:51 --> Output Class Initialized
INFO - 2018-10-04 22:49:51 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:51 --> CSRF cookie sent
INFO - 2018-10-04 22:49:51 --> Input Class Initialized
INFO - 2018-10-04 22:49:51 --> Language Class Initialized
INFO - 2018-10-04 22:49:51 --> Loader Class Initialized
INFO - 2018-10-04 22:49:51 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:51 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:51 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:51 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:51 --> Controller Class Initialized
INFO - 2018-10-04 22:49:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:51 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:51 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:51 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-04 22:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:51 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:51 --> Total execution time: 0.0398
INFO - 2018-10-04 22:49:53 --> Config Class Initialized
INFO - 2018-10-04 22:49:53 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:53 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:53 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:53 --> URI Class Initialized
INFO - 2018-10-04 22:49:53 --> Router Class Initialized
INFO - 2018-10-04 22:49:53 --> Output Class Initialized
INFO - 2018-10-04 22:49:53 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:53 --> CSRF cookie sent
INFO - 2018-10-04 22:49:53 --> Input Class Initialized
INFO - 2018-10-04 22:49:53 --> Language Class Initialized
INFO - 2018-10-04 22:49:53 --> Loader Class Initialized
INFO - 2018-10-04 22:49:53 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:53 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:53 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:53 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:53 --> Controller Class Initialized
INFO - 2018-10-04 22:49:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:53 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:53 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:53 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 22:49:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:53 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:53 --> Total execution time: 0.0463
INFO - 2018-10-04 22:49:54 --> Config Class Initialized
INFO - 2018-10-04 22:49:54 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:54 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:54 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:54 --> URI Class Initialized
INFO - 2018-10-04 22:49:54 --> Router Class Initialized
INFO - 2018-10-04 22:49:54 --> Output Class Initialized
INFO - 2018-10-04 22:49:54 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:54 --> CSRF cookie sent
INFO - 2018-10-04 22:49:54 --> Input Class Initialized
INFO - 2018-10-04 22:49:54 --> Language Class Initialized
INFO - 2018-10-04 22:49:54 --> Loader Class Initialized
INFO - 2018-10-04 22:49:54 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:54 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:54 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:54 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:54 --> Controller Class Initialized
INFO - 2018-10-04 22:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:54 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:54 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:54 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-04 22:49:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-04 22:49:54 --> Could not find the language line "req_email"
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-04 22:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:54 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:54 --> Total execution time: 0.0414
INFO - 2018-10-04 22:49:56 --> Config Class Initialized
INFO - 2018-10-04 22:49:56 --> Hooks Class Initialized
DEBUG - 2018-10-04 22:49:56 --> UTF-8 Support Enabled
INFO - 2018-10-04 22:49:56 --> Utf8 Class Initialized
INFO - 2018-10-04 22:49:56 --> URI Class Initialized
INFO - 2018-10-04 22:49:56 --> Router Class Initialized
INFO - 2018-10-04 22:49:56 --> Output Class Initialized
INFO - 2018-10-04 22:49:56 --> Security Class Initialized
DEBUG - 2018-10-04 22:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-04 22:49:56 --> CSRF cookie sent
INFO - 2018-10-04 22:49:56 --> Input Class Initialized
INFO - 2018-10-04 22:49:56 --> Language Class Initialized
INFO - 2018-10-04 22:49:56 --> Loader Class Initialized
INFO - 2018-10-04 22:49:56 --> Helper loaded: url_helper
INFO - 2018-10-04 22:49:56 --> Helper loaded: form_helper
INFO - 2018-10-04 22:49:56 --> Helper loaded: language_helper
DEBUG - 2018-10-04 22:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-04 22:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-04 22:49:56 --> User Agent Class Initialized
INFO - 2018-10-04 22:49:56 --> Controller Class Initialized
INFO - 2018-10-04 22:49:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-04 22:49:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-04 22:49:56 --> Pixel_Model class loaded
INFO - 2018-10-04 22:49:56 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:56 --> Database Driver Class Initialized
INFO - 2018-10-04 22:49:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-04 22:49:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-04 22:49:56 --> Final output sent to browser
DEBUG - 2018-10-04 22:49:56 --> Total execution time: 0.0454

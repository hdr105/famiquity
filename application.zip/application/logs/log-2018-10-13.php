<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-13 13:52:05 --> Config Class Initialized
INFO - 2018-10-13 13:52:05 --> Hooks Class Initialized
DEBUG - 2018-10-13 13:52:05 --> UTF-8 Support Enabled
INFO - 2018-10-13 13:52:05 --> Utf8 Class Initialized
INFO - 2018-10-13 13:52:05 --> URI Class Initialized
INFO - 2018-10-13 13:52:05 --> Router Class Initialized
INFO - 2018-10-13 13:52:05 --> Output Class Initialized
INFO - 2018-10-13 13:52:05 --> Security Class Initialized
DEBUG - 2018-10-13 13:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 13:52:05 --> CSRF cookie sent
INFO - 2018-10-13 13:52:05 --> Input Class Initialized
INFO - 2018-10-13 13:52:05 --> Language Class Initialized
ERROR - 2018-10-13 13:52:05 --> 404 Page Not Found: 401shtml/index
INFO - 2018-10-13 13:52:06 --> Config Class Initialized
INFO - 2018-10-13 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-13 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-13 13:52:06 --> Utf8 Class Initialized
INFO - 2018-10-13 13:52:06 --> URI Class Initialized
INFO - 2018-10-13 13:52:06 --> Router Class Initialized
INFO - 2018-10-13 13:52:06 --> Output Class Initialized
INFO - 2018-10-13 13:52:06 --> Config Class Initialized
INFO - 2018-10-13 13:52:06 --> Hooks Class Initialized
INFO - 2018-10-13 13:52:06 --> Security Class Initialized
DEBUG - 2018-10-13 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-13 13:52:06 --> Utf8 Class Initialized
DEBUG - 2018-10-13 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 13:52:06 --> CSRF cookie sent
INFO - 2018-10-13 13:52:06 --> Input Class Initialized
INFO - 2018-10-13 13:52:06 --> Language Class Initialized
INFO - 2018-10-13 13:52:06 --> URI Class Initialized
ERROR - 2018-10-13 13:52:06 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-13 13:52:06 --> Router Class Initialized
INFO - 2018-10-13 13:52:06 --> Output Class Initialized
INFO - 2018-10-13 13:52:06 --> Security Class Initialized
DEBUG - 2018-10-13 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 13:52:06 --> CSRF cookie sent
INFO - 2018-10-13 13:52:06 --> Input Class Initialized
INFO - 2018-10-13 13:52:06 --> Language Class Initialized
ERROR - 2018-10-13 13:52:06 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-13 13:52:09 --> Config Class Initialized
INFO - 2018-10-13 13:52:09 --> Hooks Class Initialized
DEBUG - 2018-10-13 13:52:09 --> UTF-8 Support Enabled
INFO - 2018-10-13 13:52:09 --> Utf8 Class Initialized
INFO - 2018-10-13 13:52:09 --> URI Class Initialized
DEBUG - 2018-10-13 13:52:09 --> No URI present. Default controller set.
INFO - 2018-10-13 13:52:09 --> Router Class Initialized
INFO - 2018-10-13 13:52:09 --> Output Class Initialized
INFO - 2018-10-13 13:52:09 --> Security Class Initialized
DEBUG - 2018-10-13 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 13:52:09 --> CSRF cookie sent
INFO - 2018-10-13 13:52:09 --> Input Class Initialized
INFO - 2018-10-13 13:52:09 --> Language Class Initialized
INFO - 2018-10-13 13:52:09 --> Loader Class Initialized
INFO - 2018-10-13 13:52:09 --> Helper loaded: url_helper
INFO - 2018-10-13 13:52:09 --> Helper loaded: form_helper
INFO - 2018-10-13 13:52:09 --> Helper loaded: language_helper
DEBUG - 2018-10-13 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 13:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 13:52:09 --> User Agent Class Initialized
INFO - 2018-10-13 13:52:09 --> Controller Class Initialized
INFO - 2018-10-13 13:52:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 13:52:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 13:52:09 --> Pixel_Model class loaded
INFO - 2018-10-13 13:52:09 --> Database Driver Class Initialized
INFO - 2018-10-13 13:52:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 13:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 13:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 13:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-13 13:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 13:52:09 --> Final output sent to browser
DEBUG - 2018-10-13 13:52:09 --> Total execution time: 0.0349
INFO - 2018-10-13 13:52:30 --> Config Class Initialized
INFO - 2018-10-13 13:52:30 --> Hooks Class Initialized
DEBUG - 2018-10-13 13:52:30 --> UTF-8 Support Enabled
INFO - 2018-10-13 13:52:30 --> Utf8 Class Initialized
INFO - 2018-10-13 13:52:30 --> URI Class Initialized
INFO - 2018-10-13 13:52:30 --> Router Class Initialized
INFO - 2018-10-13 13:52:30 --> Output Class Initialized
INFO - 2018-10-13 13:52:30 --> Security Class Initialized
DEBUG - 2018-10-13 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 13:52:30 --> CSRF cookie sent
INFO - 2018-10-13 13:52:30 --> Input Class Initialized
INFO - 2018-10-13 13:52:30 --> Language Class Initialized
INFO - 2018-10-13 13:52:30 --> Loader Class Initialized
INFO - 2018-10-13 13:52:30 --> Helper loaded: url_helper
INFO - 2018-10-13 13:52:30 --> Helper loaded: form_helper
INFO - 2018-10-13 13:52:30 --> Helper loaded: language_helper
DEBUG - 2018-10-13 13:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 13:52:30 --> User Agent Class Initialized
INFO - 2018-10-13 13:52:30 --> Controller Class Initialized
INFO - 2018-10-13 13:52:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 13:52:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 13:52:30 --> Pixel_Model class loaded
INFO - 2018-10-13 13:52:30 --> Database Driver Class Initialized
INFO - 2018-10-13 13:52:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-13 13:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 13:52:30 --> Final output sent to browser
DEBUG - 2018-10-13 13:52:30 --> Total execution time: 0.0501
INFO - 2018-10-13 14:46:49 --> Config Class Initialized
INFO - 2018-10-13 14:46:49 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:46:49 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:46:49 --> Utf8 Class Initialized
INFO - 2018-10-13 14:46:49 --> URI Class Initialized
INFO - 2018-10-13 14:46:49 --> Router Class Initialized
INFO - 2018-10-13 14:46:49 --> Output Class Initialized
INFO - 2018-10-13 14:46:49 --> Security Class Initialized
DEBUG - 2018-10-13 14:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:46:49 --> CSRF cookie sent
INFO - 2018-10-13 14:46:49 --> Input Class Initialized
INFO - 2018-10-13 14:46:49 --> Language Class Initialized
ERROR - 2018-10-13 14:46:49 --> 404 Page Not Found: 401shtml/index
INFO - 2018-10-13 14:46:53 --> Config Class Initialized
INFO - 2018-10-13 14:46:53 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:46:53 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:46:53 --> Utf8 Class Initialized
INFO - 2018-10-13 14:46:53 --> URI Class Initialized
DEBUG - 2018-10-13 14:46:53 --> No URI present. Default controller set.
INFO - 2018-10-13 14:46:53 --> Router Class Initialized
INFO - 2018-10-13 14:46:53 --> Output Class Initialized
INFO - 2018-10-13 14:46:53 --> Security Class Initialized
DEBUG - 2018-10-13 14:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:46:53 --> CSRF cookie sent
INFO - 2018-10-13 14:46:53 --> Input Class Initialized
INFO - 2018-10-13 14:46:53 --> Language Class Initialized
INFO - 2018-10-13 14:46:53 --> Loader Class Initialized
INFO - 2018-10-13 14:46:53 --> Helper loaded: url_helper
INFO - 2018-10-13 14:46:53 --> Helper loaded: form_helper
INFO - 2018-10-13 14:46:53 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:46:53 --> User Agent Class Initialized
INFO - 2018-10-13 14:46:53 --> Controller Class Initialized
INFO - 2018-10-13 14:46:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:46:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:46:53 --> Pixel_Model class loaded
INFO - 2018-10-13 14:46:53 --> Database Driver Class Initialized
INFO - 2018-10-13 14:46:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:46:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:46:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:46:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-13 14:46:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:46:53 --> Final output sent to browser
DEBUG - 2018-10-13 14:46:53 --> Total execution time: 0.0473
INFO - 2018-10-13 14:46:55 --> Config Class Initialized
INFO - 2018-10-13 14:46:55 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:46:55 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:46:55 --> Utf8 Class Initialized
INFO - 2018-10-13 14:46:55 --> URI Class Initialized
INFO - 2018-10-13 14:46:55 --> Router Class Initialized
INFO - 2018-10-13 14:46:55 --> Output Class Initialized
INFO - 2018-10-13 14:46:55 --> Security Class Initialized
DEBUG - 2018-10-13 14:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:46:55 --> CSRF cookie sent
INFO - 2018-10-13 14:46:55 --> Input Class Initialized
INFO - 2018-10-13 14:46:55 --> Language Class Initialized
INFO - 2018-10-13 14:46:55 --> Loader Class Initialized
INFO - 2018-10-13 14:46:55 --> Helper loaded: url_helper
INFO - 2018-10-13 14:46:55 --> Helper loaded: form_helper
INFO - 2018-10-13 14:46:55 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:46:55 --> User Agent Class Initialized
INFO - 2018-10-13 14:46:55 --> Controller Class Initialized
INFO - 2018-10-13 14:46:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:46:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:46:55 --> Pixel_Model class loaded
INFO - 2018-10-13 14:46:55 --> Database Driver Class Initialized
INFO - 2018-10-13 14:46:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-13 14:46:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:46:55 --> Final output sent to browser
DEBUG - 2018-10-13 14:46:55 --> Total execution time: 0.0439
INFO - 2018-10-13 14:47:01 --> Config Class Initialized
INFO - 2018-10-13 14:47:01 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:01 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:01 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:01 --> URI Class Initialized
INFO - 2018-10-13 14:47:01 --> Router Class Initialized
INFO - 2018-10-13 14:47:01 --> Output Class Initialized
INFO - 2018-10-13 14:47:01 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:01 --> CSRF cookie sent
INFO - 2018-10-13 14:47:01 --> Input Class Initialized
INFO - 2018-10-13 14:47:01 --> Language Class Initialized
INFO - 2018-10-13 14:47:01 --> Loader Class Initialized
INFO - 2018-10-13 14:47:01 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:01 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:01 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:01 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:01 --> Controller Class Initialized
INFO - 2018-10-13 14:47:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:01 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:01 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-13 14:47:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:47:01 --> Final output sent to browser
DEBUG - 2018-10-13 14:47:01 --> Total execution time: 0.0395
INFO - 2018-10-13 14:47:09 --> Config Class Initialized
INFO - 2018-10-13 14:47:09 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:09 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:09 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:09 --> URI Class Initialized
INFO - 2018-10-13 14:47:09 --> Router Class Initialized
INFO - 2018-10-13 14:47:09 --> Output Class Initialized
INFO - 2018-10-13 14:47:09 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:09 --> CSRF cookie sent
INFO - 2018-10-13 14:47:09 --> CSRF token verified
INFO - 2018-10-13 14:47:09 --> Input Class Initialized
INFO - 2018-10-13 14:47:09 --> Language Class Initialized
INFO - 2018-10-13 14:47:09 --> Loader Class Initialized
INFO - 2018-10-13 14:47:09 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:09 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:09 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:09 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:09 --> Controller Class Initialized
INFO - 2018-10-13 14:47:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:09 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:09 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:09 --> Form Validation Class Initialized
INFO - 2018-10-13 14:47:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-13 14:47:09 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:09 --> Config Class Initialized
INFO - 2018-10-13 14:47:09 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:09 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:09 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:09 --> URI Class Initialized
INFO - 2018-10-13 14:47:09 --> Router Class Initialized
INFO - 2018-10-13 14:47:09 --> Output Class Initialized
INFO - 2018-10-13 14:47:09 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:09 --> CSRF cookie sent
INFO - 2018-10-13 14:47:09 --> Input Class Initialized
INFO - 2018-10-13 14:47:09 --> Language Class Initialized
INFO - 2018-10-13 14:47:09 --> Loader Class Initialized
INFO - 2018-10-13 14:47:09 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:09 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:09 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:09 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:09 --> Controller Class Initialized
INFO - 2018-10-13 14:47:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:09 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:09 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:09 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-13 14:47:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:47:09 --> Final output sent to browser
DEBUG - 2018-10-13 14:47:09 --> Total execution time: 0.0502
INFO - 2018-10-13 14:47:14 --> Config Class Initialized
INFO - 2018-10-13 14:47:14 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:14 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:14 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:14 --> URI Class Initialized
INFO - 2018-10-13 14:47:14 --> Router Class Initialized
INFO - 2018-10-13 14:47:14 --> Output Class Initialized
INFO - 2018-10-13 14:47:14 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:14 --> CSRF cookie sent
INFO - 2018-10-13 14:47:14 --> CSRF token verified
INFO - 2018-10-13 14:47:14 --> Input Class Initialized
INFO - 2018-10-13 14:47:14 --> Language Class Initialized
INFO - 2018-10-13 14:47:14 --> Loader Class Initialized
INFO - 2018-10-13 14:47:14 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:14 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:14 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:14 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:14 --> Controller Class Initialized
INFO - 2018-10-13 14:47:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:14 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:14 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:14 --> Form Validation Class Initialized
INFO - 2018-10-13 14:47:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-13 14:47:14 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:15 --> Config Class Initialized
INFO - 2018-10-13 14:47:15 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:15 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:15 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:15 --> URI Class Initialized
INFO - 2018-10-13 14:47:15 --> Router Class Initialized
INFO - 2018-10-13 14:47:15 --> Output Class Initialized
INFO - 2018-10-13 14:47:15 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:15 --> CSRF cookie sent
INFO - 2018-10-13 14:47:15 --> Input Class Initialized
INFO - 2018-10-13 14:47:15 --> Language Class Initialized
INFO - 2018-10-13 14:47:15 --> Loader Class Initialized
INFO - 2018-10-13 14:47:15 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:15 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:15 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:15 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:15 --> Controller Class Initialized
INFO - 2018-10-13 14:47:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:15 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:15 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:15 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-13 14:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:47:15 --> Final output sent to browser
DEBUG - 2018-10-13 14:47:15 --> Total execution time: 0.0528
INFO - 2018-10-13 14:47:16 --> Config Class Initialized
INFO - 2018-10-13 14:47:16 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:16 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:16 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:16 --> URI Class Initialized
INFO - 2018-10-13 14:47:16 --> Router Class Initialized
INFO - 2018-10-13 14:47:16 --> Output Class Initialized
INFO - 2018-10-13 14:47:16 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:16 --> CSRF cookie sent
INFO - 2018-10-13 14:47:16 --> CSRF token verified
INFO - 2018-10-13 14:47:16 --> Input Class Initialized
INFO - 2018-10-13 14:47:16 --> Language Class Initialized
INFO - 2018-10-13 14:47:16 --> Loader Class Initialized
INFO - 2018-10-13 14:47:16 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:16 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:16 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:16 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:16 --> Controller Class Initialized
INFO - 2018-10-13 14:47:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:16 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:16 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:16 --> Form Validation Class Initialized
INFO - 2018-10-13 14:47:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-13 14:47:16 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:17 --> Config Class Initialized
INFO - 2018-10-13 14:47:17 --> Hooks Class Initialized
DEBUG - 2018-10-13 14:47:17 --> UTF-8 Support Enabled
INFO - 2018-10-13 14:47:17 --> Utf8 Class Initialized
INFO - 2018-10-13 14:47:17 --> URI Class Initialized
INFO - 2018-10-13 14:47:17 --> Router Class Initialized
INFO - 2018-10-13 14:47:17 --> Output Class Initialized
INFO - 2018-10-13 14:47:17 --> Security Class Initialized
DEBUG - 2018-10-13 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-13 14:47:17 --> CSRF cookie sent
INFO - 2018-10-13 14:47:17 --> Input Class Initialized
INFO - 2018-10-13 14:47:17 --> Language Class Initialized
INFO - 2018-10-13 14:47:17 --> Loader Class Initialized
INFO - 2018-10-13 14:47:17 --> Helper loaded: url_helper
INFO - 2018-10-13 14:47:17 --> Helper loaded: form_helper
INFO - 2018-10-13 14:47:17 --> Helper loaded: language_helper
DEBUG - 2018-10-13 14:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-13 14:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-13 14:47:17 --> User Agent Class Initialized
INFO - 2018-10-13 14:47:17 --> Controller Class Initialized
INFO - 2018-10-13 14:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-13 14:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-13 14:47:17 --> Pixel_Model class loaded
INFO - 2018-10-13 14:47:17 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:17 --> Database Driver Class Initialized
INFO - 2018-10-13 14:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-13 14:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-13 14:47:17 --> Final output sent to browser
DEBUG - 2018-10-13 14:47:17 --> Total execution time: 0.0420

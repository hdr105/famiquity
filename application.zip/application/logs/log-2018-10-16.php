<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-16 05:57:31 --> Config Class Initialized
INFO - 2018-10-16 05:57:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:31 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:31 --> URI Class Initialized
DEBUG - 2018-10-16 05:57:31 --> No URI present. Default controller set.
INFO - 2018-10-16 05:57:31 --> Router Class Initialized
INFO - 2018-10-16 05:57:31 --> Output Class Initialized
INFO - 2018-10-16 05:57:31 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:31 --> CSRF cookie sent
INFO - 2018-10-16 05:57:31 --> Input Class Initialized
INFO - 2018-10-16 05:57:31 --> Language Class Initialized
INFO - 2018-10-16 05:57:31 --> Loader Class Initialized
INFO - 2018-10-16 05:57:31 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:31 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:31 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:31 --> Controller Class Initialized
INFO - 2018-10-16 05:57:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:31 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:31 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:57:31 --> Final output sent to browser
DEBUG - 2018-10-16 05:57:31 --> Total execution time: 0.0475
INFO - 2018-10-16 05:57:31 --> Config Class Initialized
INFO - 2018-10-16 05:57:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:31 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:31 --> URI Class Initialized
DEBUG - 2018-10-16 05:57:31 --> No URI present. Default controller set.
INFO - 2018-10-16 05:57:31 --> Router Class Initialized
INFO - 2018-10-16 05:57:31 --> Output Class Initialized
INFO - 2018-10-16 05:57:31 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:31 --> CSRF cookie sent
INFO - 2018-10-16 05:57:31 --> Input Class Initialized
INFO - 2018-10-16 05:57:31 --> Language Class Initialized
INFO - 2018-10-16 05:57:31 --> Loader Class Initialized
INFO - 2018-10-16 05:57:31 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:31 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:31 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:31 --> Controller Class Initialized
INFO - 2018-10-16 05:57:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:31 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:31 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 05:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:57:31 --> Final output sent to browser
DEBUG - 2018-10-16 05:57:31 --> Total execution time: 0.0366
INFO - 2018-10-16 05:57:40 --> Config Class Initialized
INFO - 2018-10-16 05:57:40 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:40 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:40 --> URI Class Initialized
INFO - 2018-10-16 05:57:40 --> Router Class Initialized
INFO - 2018-10-16 05:57:40 --> Output Class Initialized
INFO - 2018-10-16 05:57:40 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:40 --> CSRF cookie sent
INFO - 2018-10-16 05:57:40 --> CSRF token verified
INFO - 2018-10-16 05:57:40 --> Input Class Initialized
INFO - 2018-10-16 05:57:40 --> Language Class Initialized
INFO - 2018-10-16 05:57:40 --> Loader Class Initialized
INFO - 2018-10-16 05:57:40 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:40 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:40 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:40 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:40 --> Controller Class Initialized
INFO - 2018-10-16 05:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:40 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:40 --> Form Validation Class Initialized
INFO - 2018-10-16 05:57:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:40 --> Config Class Initialized
INFO - 2018-10-16 05:57:40 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:40 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:40 --> URI Class Initialized
INFO - 2018-10-16 05:57:40 --> Router Class Initialized
INFO - 2018-10-16 05:57:40 --> Output Class Initialized
INFO - 2018-10-16 05:57:40 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:40 --> CSRF cookie sent
INFO - 2018-10-16 05:57:40 --> Input Class Initialized
INFO - 2018-10-16 05:57:40 --> Language Class Initialized
INFO - 2018-10-16 05:57:40 --> Loader Class Initialized
INFO - 2018-10-16 05:57:40 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:40 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:40 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:40 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:40 --> Controller Class Initialized
INFO - 2018-10-16 05:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:40 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 05:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:57:40 --> Final output sent to browser
DEBUG - 2018-10-16 05:57:40 --> Total execution time: 0.0465
INFO - 2018-10-16 05:57:52 --> Config Class Initialized
INFO - 2018-10-16 05:57:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:52 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:52 --> URI Class Initialized
INFO - 2018-10-16 05:57:52 --> Router Class Initialized
INFO - 2018-10-16 05:57:52 --> Output Class Initialized
INFO - 2018-10-16 05:57:52 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:52 --> CSRF cookie sent
INFO - 2018-10-16 05:57:52 --> CSRF token verified
INFO - 2018-10-16 05:57:52 --> Input Class Initialized
INFO - 2018-10-16 05:57:52 --> Language Class Initialized
INFO - 2018-10-16 05:57:52 --> Loader Class Initialized
INFO - 2018-10-16 05:57:52 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:52 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:52 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:52 --> Controller Class Initialized
INFO - 2018-10-16 05:57:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:52 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:52 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:52 --> Form Validation Class Initialized
INFO - 2018-10-16 05:57:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:57:52 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:53 --> Config Class Initialized
INFO - 2018-10-16 05:57:53 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:53 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:53 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:53 --> URI Class Initialized
INFO - 2018-10-16 05:57:53 --> Router Class Initialized
INFO - 2018-10-16 05:57:53 --> Output Class Initialized
INFO - 2018-10-16 05:57:53 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:53 --> CSRF cookie sent
INFO - 2018-10-16 05:57:53 --> Input Class Initialized
INFO - 2018-10-16 05:57:53 --> Language Class Initialized
INFO - 2018-10-16 05:57:53 --> Loader Class Initialized
INFO - 2018-10-16 05:57:53 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:53 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:53 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:53 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:53 --> Controller Class Initialized
INFO - 2018-10-16 05:57:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:53 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:53 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:53 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 05:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:57:53 --> Final output sent to browser
DEBUG - 2018-10-16 05:57:53 --> Total execution time: 0.0519
INFO - 2018-10-16 05:57:56 --> Config Class Initialized
INFO - 2018-10-16 05:57:56 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:56 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:56 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:56 --> URI Class Initialized
INFO - 2018-10-16 05:57:56 --> Router Class Initialized
INFO - 2018-10-16 05:57:56 --> Output Class Initialized
INFO - 2018-10-16 05:57:56 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:56 --> CSRF cookie sent
INFO - 2018-10-16 05:57:56 --> CSRF token verified
INFO - 2018-10-16 05:57:56 --> Input Class Initialized
INFO - 2018-10-16 05:57:56 --> Language Class Initialized
INFO - 2018-10-16 05:57:56 --> Loader Class Initialized
INFO - 2018-10-16 05:57:56 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:56 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:56 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:56 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:56 --> Controller Class Initialized
INFO - 2018-10-16 05:57:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:56 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:57 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:57 --> Form Validation Class Initialized
INFO - 2018-10-16 05:57:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:57:57 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:57 --> Config Class Initialized
INFO - 2018-10-16 05:57:57 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:57:57 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:57:57 --> Utf8 Class Initialized
INFO - 2018-10-16 05:57:57 --> URI Class Initialized
INFO - 2018-10-16 05:57:57 --> Router Class Initialized
INFO - 2018-10-16 05:57:57 --> Output Class Initialized
INFO - 2018-10-16 05:57:57 --> Security Class Initialized
DEBUG - 2018-10-16 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:57:57 --> CSRF cookie sent
INFO - 2018-10-16 05:57:57 --> Input Class Initialized
INFO - 2018-10-16 05:57:57 --> Language Class Initialized
INFO - 2018-10-16 05:57:57 --> Loader Class Initialized
INFO - 2018-10-16 05:57:57 --> Helper loaded: url_helper
INFO - 2018-10-16 05:57:57 --> Helper loaded: form_helper
INFO - 2018-10-16 05:57:57 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:57:57 --> User Agent Class Initialized
INFO - 2018-10-16 05:57:57 --> Controller Class Initialized
INFO - 2018-10-16 05:57:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:57:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:57:57 --> Pixel_Model class loaded
INFO - 2018-10-16 05:57:57 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:57 --> Database Driver Class Initialized
INFO - 2018-10-16 05:57:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 05:57:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:57:57 --> Final output sent to browser
DEBUG - 2018-10-16 05:57:57 --> Total execution time: 0.0491
INFO - 2018-10-16 05:58:04 --> Config Class Initialized
INFO - 2018-10-16 05:58:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:58:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:58:04 --> Utf8 Class Initialized
INFO - 2018-10-16 05:58:04 --> URI Class Initialized
INFO - 2018-10-16 05:58:04 --> Router Class Initialized
INFO - 2018-10-16 05:58:04 --> Output Class Initialized
INFO - 2018-10-16 05:58:04 --> Security Class Initialized
DEBUG - 2018-10-16 05:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:58:04 --> CSRF cookie sent
INFO - 2018-10-16 05:58:04 --> CSRF token verified
INFO - 2018-10-16 05:58:04 --> Input Class Initialized
INFO - 2018-10-16 05:58:04 --> Language Class Initialized
INFO - 2018-10-16 05:58:04 --> Loader Class Initialized
INFO - 2018-10-16 05:58:04 --> Helper loaded: url_helper
INFO - 2018-10-16 05:58:04 --> Helper loaded: form_helper
INFO - 2018-10-16 05:58:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:58:04 --> User Agent Class Initialized
INFO - 2018-10-16 05:58:04 --> Controller Class Initialized
INFO - 2018-10-16 05:58:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:58:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:58:04 --> Pixel_Model class loaded
INFO - 2018-10-16 05:58:04 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:04 --> Form Validation Class Initialized
INFO - 2018-10-16 05:58:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:58:04 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:04 --> Config Class Initialized
INFO - 2018-10-16 05:58:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:58:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:58:04 --> Utf8 Class Initialized
INFO - 2018-10-16 05:58:04 --> URI Class Initialized
INFO - 2018-10-16 05:58:04 --> Router Class Initialized
INFO - 2018-10-16 05:58:04 --> Output Class Initialized
INFO - 2018-10-16 05:58:04 --> Security Class Initialized
DEBUG - 2018-10-16 05:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:58:04 --> CSRF cookie sent
INFO - 2018-10-16 05:58:04 --> Input Class Initialized
INFO - 2018-10-16 05:58:04 --> Language Class Initialized
INFO - 2018-10-16 05:58:04 --> Loader Class Initialized
INFO - 2018-10-16 05:58:04 --> Helper loaded: url_helper
INFO - 2018-10-16 05:58:04 --> Helper loaded: form_helper
INFO - 2018-10-16 05:58:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:58:04 --> User Agent Class Initialized
INFO - 2018-10-16 05:58:04 --> Controller Class Initialized
INFO - 2018-10-16 05:58:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:58:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:58:04 --> Pixel_Model class loaded
INFO - 2018-10-16 05:58:04 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:04 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 05:58:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:58:04 --> Final output sent to browser
DEBUG - 2018-10-16 05:58:04 --> Total execution time: 0.0406
INFO - 2018-10-16 05:58:10 --> Config Class Initialized
INFO - 2018-10-16 05:58:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:58:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:58:10 --> Utf8 Class Initialized
INFO - 2018-10-16 05:58:10 --> URI Class Initialized
INFO - 2018-10-16 05:58:10 --> Router Class Initialized
INFO - 2018-10-16 05:58:10 --> Output Class Initialized
INFO - 2018-10-16 05:58:10 --> Security Class Initialized
DEBUG - 2018-10-16 05:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:58:10 --> CSRF cookie sent
INFO - 2018-10-16 05:58:10 --> CSRF token verified
INFO - 2018-10-16 05:58:10 --> Input Class Initialized
INFO - 2018-10-16 05:58:10 --> Language Class Initialized
INFO - 2018-10-16 05:58:10 --> Loader Class Initialized
INFO - 2018-10-16 05:58:10 --> Helper loaded: url_helper
INFO - 2018-10-16 05:58:10 --> Helper loaded: form_helper
INFO - 2018-10-16 05:58:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:58:10 --> User Agent Class Initialized
INFO - 2018-10-16 05:58:10 --> Controller Class Initialized
INFO - 2018-10-16 05:58:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:58:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:58:10 --> Pixel_Model class loaded
INFO - 2018-10-16 05:58:10 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:10 --> Form Validation Class Initialized
INFO - 2018-10-16 05:58:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:58:10 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:10 --> Config Class Initialized
INFO - 2018-10-16 05:58:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:58:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:58:10 --> Utf8 Class Initialized
INFO - 2018-10-16 05:58:10 --> URI Class Initialized
INFO - 2018-10-16 05:58:10 --> Router Class Initialized
INFO - 2018-10-16 05:58:10 --> Output Class Initialized
INFO - 2018-10-16 05:58:10 --> Security Class Initialized
DEBUG - 2018-10-16 05:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:58:10 --> CSRF cookie sent
INFO - 2018-10-16 05:58:10 --> Input Class Initialized
INFO - 2018-10-16 05:58:10 --> Language Class Initialized
INFO - 2018-10-16 05:58:10 --> Loader Class Initialized
INFO - 2018-10-16 05:58:10 --> Helper loaded: url_helper
INFO - 2018-10-16 05:58:10 --> Helper loaded: form_helper
INFO - 2018-10-16 05:58:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:58:10 --> User Agent Class Initialized
INFO - 2018-10-16 05:58:10 --> Controller Class Initialized
INFO - 2018-10-16 05:58:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:58:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:58:10 --> Pixel_Model class loaded
INFO - 2018-10-16 05:58:10 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:10 --> Database Driver Class Initialized
INFO - 2018-10-16 05:58:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 05:58:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:58:10 --> Final output sent to browser
DEBUG - 2018-10-16 05:58:10 --> Total execution time: 0.0392
INFO - 2018-10-16 05:59:23 --> Config Class Initialized
INFO - 2018-10-16 05:59:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:23 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:23 --> URI Class Initialized
INFO - 2018-10-16 05:59:23 --> Router Class Initialized
INFO - 2018-10-16 05:59:23 --> Output Class Initialized
INFO - 2018-10-16 05:59:23 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:23 --> CSRF cookie sent
INFO - 2018-10-16 05:59:23 --> Input Class Initialized
INFO - 2018-10-16 05:59:23 --> Language Class Initialized
INFO - 2018-10-16 05:59:23 --> Loader Class Initialized
INFO - 2018-10-16 05:59:23 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:23 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:23 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:23 --> Controller Class Initialized
INFO - 2018-10-16 05:59:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:23 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:23 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:23 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 05:59:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:59:23 --> Final output sent to browser
DEBUG - 2018-10-16 05:59:23 --> Total execution time: 0.0561
INFO - 2018-10-16 05:59:25 --> Config Class Initialized
INFO - 2018-10-16 05:59:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:25 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:25 --> URI Class Initialized
INFO - 2018-10-16 05:59:25 --> Router Class Initialized
INFO - 2018-10-16 05:59:25 --> Output Class Initialized
INFO - 2018-10-16 05:59:25 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:25 --> CSRF cookie sent
INFO - 2018-10-16 05:59:25 --> Input Class Initialized
INFO - 2018-10-16 05:59:25 --> Language Class Initialized
INFO - 2018-10-16 05:59:25 --> Loader Class Initialized
INFO - 2018-10-16 05:59:25 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:25 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:25 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:25 --> Controller Class Initialized
INFO - 2018-10-16 05:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:25 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:25 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:25 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 05:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:59:25 --> Final output sent to browser
DEBUG - 2018-10-16 05:59:25 --> Total execution time: 0.0454
INFO - 2018-10-16 05:59:29 --> Config Class Initialized
INFO - 2018-10-16 05:59:29 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:29 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:29 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:29 --> URI Class Initialized
INFO - 2018-10-16 05:59:29 --> Router Class Initialized
INFO - 2018-10-16 05:59:29 --> Output Class Initialized
INFO - 2018-10-16 05:59:29 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:29 --> CSRF cookie sent
INFO - 2018-10-16 05:59:29 --> CSRF token verified
INFO - 2018-10-16 05:59:29 --> Input Class Initialized
INFO - 2018-10-16 05:59:29 --> Language Class Initialized
INFO - 2018-10-16 05:59:29 --> Loader Class Initialized
INFO - 2018-10-16 05:59:29 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:29 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:29 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:29 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:29 --> Controller Class Initialized
INFO - 2018-10-16 05:59:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:29 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:29 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:29 --> Form Validation Class Initialized
INFO - 2018-10-16 05:59:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 05:59:29 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:29 --> Config Class Initialized
INFO - 2018-10-16 05:59:29 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:29 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:29 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:29 --> URI Class Initialized
INFO - 2018-10-16 05:59:29 --> Router Class Initialized
INFO - 2018-10-16 05:59:29 --> Output Class Initialized
INFO - 2018-10-16 05:59:29 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:29 --> CSRF cookie sent
INFO - 2018-10-16 05:59:29 --> Input Class Initialized
INFO - 2018-10-16 05:59:29 --> Language Class Initialized
INFO - 2018-10-16 05:59:29 --> Loader Class Initialized
INFO - 2018-10-16 05:59:29 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:29 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:29 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:29 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:29 --> Controller Class Initialized
INFO - 2018-10-16 05:59:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:29 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:29 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:29 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 05:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:59:29 --> Final output sent to browser
DEBUG - 2018-10-16 05:59:29 --> Total execution time: 0.0392
INFO - 2018-10-16 05:59:33 --> Config Class Initialized
INFO - 2018-10-16 05:59:33 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:33 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:33 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:33 --> URI Class Initialized
INFO - 2018-10-16 05:59:33 --> Router Class Initialized
INFO - 2018-10-16 05:59:33 --> Output Class Initialized
INFO - 2018-10-16 05:59:33 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:33 --> CSRF cookie sent
INFO - 2018-10-16 05:59:33 --> Input Class Initialized
INFO - 2018-10-16 05:59:33 --> Language Class Initialized
INFO - 2018-10-16 05:59:33 --> Loader Class Initialized
INFO - 2018-10-16 05:59:33 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:33 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:33 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:33 --> Controller Class Initialized
INFO - 2018-10-16 05:59:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:33 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:33 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:33 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 05:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:59:33 --> Final output sent to browser
DEBUG - 2018-10-16 05:59:33 --> Total execution time: 0.0530
INFO - 2018-10-16 05:59:38 --> Config Class Initialized
INFO - 2018-10-16 05:59:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:38 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:38 --> URI Class Initialized
INFO - 2018-10-16 05:59:38 --> Router Class Initialized
INFO - 2018-10-16 05:59:38 --> Output Class Initialized
INFO - 2018-10-16 05:59:38 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:38 --> CSRF cookie sent
INFO - 2018-10-16 05:59:38 --> Input Class Initialized
INFO - 2018-10-16 05:59:38 --> Language Class Initialized
INFO - 2018-10-16 05:59:38 --> Loader Class Initialized
INFO - 2018-10-16 05:59:38 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:38 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:38 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:38 --> Controller Class Initialized
INFO - 2018-10-16 05:59:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:38 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:38 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:38 --> Model "MyAccountModel" initialized
INFO - 2018-10-16 05:59:38 --> Config Class Initialized
INFO - 2018-10-16 05:59:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 05:59:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 05:59:38 --> Utf8 Class Initialized
INFO - 2018-10-16 05:59:38 --> URI Class Initialized
INFO - 2018-10-16 05:59:38 --> Router Class Initialized
INFO - 2018-10-16 05:59:38 --> Output Class Initialized
INFO - 2018-10-16 05:59:38 --> Security Class Initialized
DEBUG - 2018-10-16 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 05:59:38 --> CSRF cookie sent
INFO - 2018-10-16 05:59:38 --> Input Class Initialized
INFO - 2018-10-16 05:59:38 --> Language Class Initialized
INFO - 2018-10-16 05:59:38 --> Loader Class Initialized
INFO - 2018-10-16 05:59:38 --> Helper loaded: url_helper
INFO - 2018-10-16 05:59:38 --> Helper loaded: form_helper
INFO - 2018-10-16 05:59:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 05:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 05:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 05:59:38 --> User Agent Class Initialized
INFO - 2018-10-16 05:59:38 --> Controller Class Initialized
INFO - 2018-10-16 05:59:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 05:59:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 05:59:38 --> Pixel_Model class loaded
INFO - 2018-10-16 05:59:38 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:38 --> Database Driver Class Initialized
INFO - 2018-10-16 05:59:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 05:59:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 05:59:38 --> Final output sent to browser
DEBUG - 2018-10-16 05:59:38 --> Total execution time: 0.0404
INFO - 2018-10-16 06:01:29 --> Config Class Initialized
INFO - 2018-10-16 06:01:29 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:01:29 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:01:29 --> Utf8 Class Initialized
INFO - 2018-10-16 06:01:29 --> URI Class Initialized
INFO - 2018-10-16 06:01:29 --> Router Class Initialized
INFO - 2018-10-16 06:01:29 --> Output Class Initialized
INFO - 2018-10-16 06:01:29 --> Security Class Initialized
DEBUG - 2018-10-16 06:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:01:29 --> CSRF cookie sent
INFO - 2018-10-16 06:01:29 --> Input Class Initialized
INFO - 2018-10-16 06:01:29 --> Language Class Initialized
ERROR - 2018-10-16 06:01:29 --> 404 Page Not Found: Assets/css
INFO - 2018-10-16 06:01:33 --> Config Class Initialized
INFO - 2018-10-16 06:01:33 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:01:33 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:01:33 --> Utf8 Class Initialized
INFO - 2018-10-16 06:01:33 --> URI Class Initialized
INFO - 2018-10-16 06:01:33 --> Router Class Initialized
INFO - 2018-10-16 06:01:33 --> Output Class Initialized
INFO - 2018-10-16 06:01:33 --> Security Class Initialized
DEBUG - 2018-10-16 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:01:33 --> CSRF cookie sent
INFO - 2018-10-16 06:01:33 --> Input Class Initialized
INFO - 2018-10-16 06:01:33 --> Language Class Initialized
INFO - 2018-10-16 06:01:33 --> Loader Class Initialized
INFO - 2018-10-16 06:01:33 --> Helper loaded: url_helper
INFO - 2018-10-16 06:01:33 --> Helper loaded: form_helper
INFO - 2018-10-16 06:01:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:01:33 --> User Agent Class Initialized
INFO - 2018-10-16 06:01:33 --> Controller Class Initialized
INFO - 2018-10-16 06:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:01:33 --> Pixel_Model class loaded
INFO - 2018-10-16 06:01:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:01:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:01:33 --> Final output sent to browser
DEBUG - 2018-10-16 06:01:33 --> Total execution time: 0.0445
INFO - 2018-10-16 06:14:12 --> Config Class Initialized
INFO - 2018-10-16 06:14:12 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:14:12 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:14:12 --> Utf8 Class Initialized
INFO - 2018-10-16 06:14:12 --> URI Class Initialized
INFO - 2018-10-16 06:14:12 --> Router Class Initialized
INFO - 2018-10-16 06:14:12 --> Output Class Initialized
INFO - 2018-10-16 06:14:12 --> Security Class Initialized
DEBUG - 2018-10-16 06:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:14:12 --> CSRF cookie sent
INFO - 2018-10-16 06:14:12 --> CSRF token verified
INFO - 2018-10-16 06:14:12 --> Input Class Initialized
INFO - 2018-10-16 06:14:12 --> Language Class Initialized
INFO - 2018-10-16 06:14:12 --> Loader Class Initialized
INFO - 2018-10-16 06:14:12 --> Helper loaded: url_helper
INFO - 2018-10-16 06:14:12 --> Helper loaded: form_helper
INFO - 2018-10-16 06:14:12 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:14:12 --> User Agent Class Initialized
INFO - 2018-10-16 06:14:12 --> Controller Class Initialized
INFO - 2018-10-16 06:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:14:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:14:12 --> Pixel_Model class loaded
INFO - 2018-10-16 06:14:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:14:12 --> Form Validation Class Initialized
INFO - 2018-10-16 06:14:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:14:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:14:12 --> Config Class Initialized
INFO - 2018-10-16 06:14:12 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:14:12 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:14:12 --> Utf8 Class Initialized
INFO - 2018-10-16 06:14:12 --> URI Class Initialized
INFO - 2018-10-16 06:14:12 --> Router Class Initialized
INFO - 2018-10-16 06:14:12 --> Output Class Initialized
INFO - 2018-10-16 06:14:12 --> Security Class Initialized
DEBUG - 2018-10-16 06:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:14:12 --> CSRF cookie sent
INFO - 2018-10-16 06:14:12 --> Input Class Initialized
INFO - 2018-10-16 06:14:12 --> Language Class Initialized
INFO - 2018-10-16 06:14:12 --> Loader Class Initialized
INFO - 2018-10-16 06:14:12 --> Helper loaded: url_helper
INFO - 2018-10-16 06:14:12 --> Helper loaded: form_helper
INFO - 2018-10-16 06:14:12 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:14:12 --> User Agent Class Initialized
INFO - 2018-10-16 06:14:12 --> Controller Class Initialized
INFO - 2018-10-16 06:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:14:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:14:12 --> Pixel_Model class loaded
INFO - 2018-10-16 06:14:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:14:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:14:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:14:12 --> Final output sent to browser
DEBUG - 2018-10-16 06:14:12 --> Total execution time: 0.0333
INFO - 2018-10-16 06:15:05 --> Config Class Initialized
INFO - 2018-10-16 06:15:05 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:15:05 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:15:05 --> Utf8 Class Initialized
INFO - 2018-10-16 06:15:05 --> URI Class Initialized
INFO - 2018-10-16 06:15:05 --> Router Class Initialized
INFO - 2018-10-16 06:15:05 --> Output Class Initialized
INFO - 2018-10-16 06:15:05 --> Security Class Initialized
DEBUG - 2018-10-16 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:15:05 --> CSRF cookie sent
INFO - 2018-10-16 06:15:05 --> Input Class Initialized
INFO - 2018-10-16 06:15:05 --> Language Class Initialized
INFO - 2018-10-16 06:15:05 --> Loader Class Initialized
INFO - 2018-10-16 06:15:05 --> Helper loaded: url_helper
INFO - 2018-10-16 06:15:05 --> Helper loaded: form_helper
INFO - 2018-10-16 06:15:05 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:15:05 --> User Agent Class Initialized
INFO - 2018-10-16 06:15:05 --> Controller Class Initialized
INFO - 2018-10-16 06:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:15:05 --> Pixel_Model class loaded
INFO - 2018-10-16 06:15:05 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:05 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:15:05 --> Final output sent to browser
DEBUG - 2018-10-16 06:15:05 --> Total execution time: 0.0567
INFO - 2018-10-16 06:15:30 --> Config Class Initialized
INFO - 2018-10-16 06:15:30 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:15:30 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:15:30 --> Utf8 Class Initialized
INFO - 2018-10-16 06:15:30 --> URI Class Initialized
INFO - 2018-10-16 06:15:30 --> Router Class Initialized
INFO - 2018-10-16 06:15:30 --> Output Class Initialized
INFO - 2018-10-16 06:15:30 --> Security Class Initialized
DEBUG - 2018-10-16 06:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:15:30 --> CSRF cookie sent
INFO - 2018-10-16 06:15:30 --> Input Class Initialized
INFO - 2018-10-16 06:15:30 --> Language Class Initialized
INFO - 2018-10-16 06:15:30 --> Loader Class Initialized
INFO - 2018-10-16 06:15:30 --> Helper loaded: url_helper
INFO - 2018-10-16 06:15:30 --> Helper loaded: form_helper
INFO - 2018-10-16 06:15:30 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:15:30 --> User Agent Class Initialized
INFO - 2018-10-16 06:15:30 --> Controller Class Initialized
INFO - 2018-10-16 06:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:15:30 --> Pixel_Model class loaded
INFO - 2018-10-16 06:15:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:15:30 --> Final output sent to browser
DEBUG - 2018-10-16 06:15:30 --> Total execution time: 0.0406
INFO - 2018-10-16 06:15:38 --> Config Class Initialized
INFO - 2018-10-16 06:15:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:15:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:15:38 --> Utf8 Class Initialized
INFO - 2018-10-16 06:15:38 --> URI Class Initialized
INFO - 2018-10-16 06:15:38 --> Router Class Initialized
INFO - 2018-10-16 06:15:38 --> Output Class Initialized
INFO - 2018-10-16 06:15:38 --> Security Class Initialized
DEBUG - 2018-10-16 06:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:15:38 --> CSRF cookie sent
INFO - 2018-10-16 06:15:38 --> Input Class Initialized
INFO - 2018-10-16 06:15:38 --> Language Class Initialized
INFO - 2018-10-16 06:15:38 --> Loader Class Initialized
INFO - 2018-10-16 06:15:38 --> Helper loaded: url_helper
INFO - 2018-10-16 06:15:38 --> Helper loaded: form_helper
INFO - 2018-10-16 06:15:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:15:38 --> User Agent Class Initialized
INFO - 2018-10-16 06:15:38 --> Controller Class Initialized
INFO - 2018-10-16 06:15:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:15:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:15:38 --> Pixel_Model class loaded
INFO - 2018-10-16 06:15:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:15:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:15:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:15:38 --> Final output sent to browser
DEBUG - 2018-10-16 06:15:38 --> Total execution time: 0.0559
INFO - 2018-10-16 06:31:49 --> Config Class Initialized
INFO - 2018-10-16 06:31:49 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:31:49 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:31:49 --> Utf8 Class Initialized
INFO - 2018-10-16 06:31:49 --> URI Class Initialized
INFO - 2018-10-16 06:31:49 --> Router Class Initialized
INFO - 2018-10-16 06:31:49 --> Output Class Initialized
INFO - 2018-10-16 06:31:49 --> Security Class Initialized
DEBUG - 2018-10-16 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:31:49 --> CSRF cookie sent
INFO - 2018-10-16 06:31:49 --> CSRF token verified
INFO - 2018-10-16 06:31:49 --> Input Class Initialized
INFO - 2018-10-16 06:31:49 --> Language Class Initialized
INFO - 2018-10-16 06:31:49 --> Loader Class Initialized
INFO - 2018-10-16 06:31:49 --> Helper loaded: url_helper
INFO - 2018-10-16 06:31:49 --> Helper loaded: form_helper
INFO - 2018-10-16 06:31:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:31:49 --> User Agent Class Initialized
INFO - 2018-10-16 06:31:49 --> Controller Class Initialized
INFO - 2018-10-16 06:31:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:31:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:31:49 --> Pixel_Model class loaded
INFO - 2018-10-16 06:31:49 --> Database Driver Class Initialized
INFO - 2018-10-16 06:31:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:31:49 --> Form Validation Class Initialized
INFO - 2018-10-16 06:31:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:31:49 --> Database Driver Class Initialized
INFO - 2018-10-16 06:31:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:31:49 --> Final output sent to browser
DEBUG - 2018-10-16 06:31:49 --> Total execution time: 0.0463
INFO - 2018-10-16 06:31:52 --> Config Class Initialized
INFO - 2018-10-16 06:31:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:31:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:31:52 --> Utf8 Class Initialized
INFO - 2018-10-16 06:31:52 --> URI Class Initialized
INFO - 2018-10-16 06:31:52 --> Router Class Initialized
INFO - 2018-10-16 06:31:52 --> Output Class Initialized
INFO - 2018-10-16 06:31:52 --> Security Class Initialized
DEBUG - 2018-10-16 06:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:31:52 --> CSRF cookie sent
INFO - 2018-10-16 06:31:52 --> Input Class Initialized
INFO - 2018-10-16 06:31:52 --> Language Class Initialized
INFO - 2018-10-16 06:31:52 --> Loader Class Initialized
INFO - 2018-10-16 06:31:52 --> Helper loaded: url_helper
INFO - 2018-10-16 06:31:52 --> Helper loaded: form_helper
INFO - 2018-10-16 06:31:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:31:52 --> User Agent Class Initialized
INFO - 2018-10-16 06:31:52 --> Controller Class Initialized
INFO - 2018-10-16 06:31:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:31:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:31:52 --> Pixel_Model class loaded
INFO - 2018-10-16 06:31:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:31:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:31:52 --> Final output sent to browser
DEBUG - 2018-10-16 06:31:52 --> Total execution time: 0.0424
INFO - 2018-10-16 06:33:45 --> Config Class Initialized
INFO - 2018-10-16 06:33:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:33:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:33:45 --> Utf8 Class Initialized
INFO - 2018-10-16 06:33:45 --> URI Class Initialized
INFO - 2018-10-16 06:33:45 --> Router Class Initialized
INFO - 2018-10-16 06:33:45 --> Output Class Initialized
INFO - 2018-10-16 06:33:45 --> Security Class Initialized
DEBUG - 2018-10-16 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:33:45 --> CSRF cookie sent
INFO - 2018-10-16 06:33:45 --> Input Class Initialized
INFO - 2018-10-16 06:33:45 --> Language Class Initialized
INFO - 2018-10-16 06:33:45 --> Loader Class Initialized
INFO - 2018-10-16 06:33:45 --> Helper loaded: url_helper
INFO - 2018-10-16 06:33:45 --> Helper loaded: form_helper
INFO - 2018-10-16 06:33:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:33:45 --> User Agent Class Initialized
INFO - 2018-10-16 06:33:45 --> Controller Class Initialized
INFO - 2018-10-16 06:33:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:33:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:33:45 --> Pixel_Model class loaded
INFO - 2018-10-16 06:33:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 06:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:33:45 --> Final output sent to browser
DEBUG - 2018-10-16 06:33:45 --> Total execution time: 0.0481
INFO - 2018-10-16 06:33:47 --> Config Class Initialized
INFO - 2018-10-16 06:33:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:33:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:33:47 --> Utf8 Class Initialized
INFO - 2018-10-16 06:33:47 --> URI Class Initialized
INFO - 2018-10-16 06:33:47 --> Router Class Initialized
INFO - 2018-10-16 06:33:47 --> Output Class Initialized
INFO - 2018-10-16 06:33:47 --> Security Class Initialized
DEBUG - 2018-10-16 06:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:33:47 --> CSRF cookie sent
INFO - 2018-10-16 06:33:47 --> CSRF token verified
INFO - 2018-10-16 06:33:47 --> Input Class Initialized
INFO - 2018-10-16 06:33:47 --> Language Class Initialized
INFO - 2018-10-16 06:33:47 --> Loader Class Initialized
INFO - 2018-10-16 06:33:47 --> Helper loaded: url_helper
INFO - 2018-10-16 06:33:47 --> Helper loaded: form_helper
INFO - 2018-10-16 06:33:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:33:47 --> User Agent Class Initialized
INFO - 2018-10-16 06:33:47 --> Controller Class Initialized
INFO - 2018-10-16 06:33:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:33:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:33:47 --> Pixel_Model class loaded
INFO - 2018-10-16 06:33:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:47 --> Form Validation Class Initialized
INFO - 2018-10-16 06:33:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:33:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:47 --> Config Class Initialized
INFO - 2018-10-16 06:33:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:33:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:33:47 --> Utf8 Class Initialized
INFO - 2018-10-16 06:33:47 --> URI Class Initialized
INFO - 2018-10-16 06:33:47 --> Router Class Initialized
INFO - 2018-10-16 06:33:47 --> Output Class Initialized
INFO - 2018-10-16 06:33:47 --> Security Class Initialized
DEBUG - 2018-10-16 06:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:33:47 --> CSRF cookie sent
INFO - 2018-10-16 06:33:47 --> Input Class Initialized
INFO - 2018-10-16 06:33:47 --> Language Class Initialized
INFO - 2018-10-16 06:33:47 --> Loader Class Initialized
INFO - 2018-10-16 06:33:47 --> Helper loaded: url_helper
INFO - 2018-10-16 06:33:47 --> Helper loaded: form_helper
INFO - 2018-10-16 06:33:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:33:47 --> User Agent Class Initialized
INFO - 2018-10-16 06:33:47 --> Controller Class Initialized
INFO - 2018-10-16 06:33:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:33:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:33:47 --> Pixel_Model class loaded
INFO - 2018-10-16 06:33:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:48 --> Database Driver Class Initialized
INFO - 2018-10-16 06:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:33:48 --> Final output sent to browser
DEBUG - 2018-10-16 06:33:48 --> Total execution time: 0.0603
INFO - 2018-10-16 06:34:00 --> Config Class Initialized
INFO - 2018-10-16 06:34:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:00 --> URI Class Initialized
INFO - 2018-10-16 06:34:00 --> Router Class Initialized
INFO - 2018-10-16 06:34:00 --> Output Class Initialized
INFO - 2018-10-16 06:34:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:00 --> CSRF cookie sent
INFO - 2018-10-16 06:34:00 --> CSRF token verified
INFO - 2018-10-16 06:34:00 --> Input Class Initialized
INFO - 2018-10-16 06:34:00 --> Language Class Initialized
INFO - 2018-10-16 06:34:00 --> Loader Class Initialized
INFO - 2018-10-16 06:34:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:00 --> Controller Class Initialized
INFO - 2018-10-16 06:34:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:00 --> Form Validation Class Initialized
INFO - 2018-10-16 06:34:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:34:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:00 --> Config Class Initialized
INFO - 2018-10-16 06:34:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:00 --> URI Class Initialized
INFO - 2018-10-16 06:34:00 --> Router Class Initialized
INFO - 2018-10-16 06:34:00 --> Output Class Initialized
INFO - 2018-10-16 06:34:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:00 --> CSRF cookie sent
INFO - 2018-10-16 06:34:00 --> Input Class Initialized
INFO - 2018-10-16 06:34:00 --> Language Class Initialized
INFO - 2018-10-16 06:34:00 --> Loader Class Initialized
INFO - 2018-10-16 06:34:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:00 --> Controller Class Initialized
INFO - 2018-10-16 06:34:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:34:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:34:00 --> Final output sent to browser
DEBUG - 2018-10-16 06:34:00 --> Total execution time: 0.0477
INFO - 2018-10-16 06:34:23 --> Config Class Initialized
INFO - 2018-10-16 06:34:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:23 --> URI Class Initialized
INFO - 2018-10-16 06:34:23 --> Router Class Initialized
INFO - 2018-10-16 06:34:23 --> Output Class Initialized
INFO - 2018-10-16 06:34:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:23 --> CSRF cookie sent
INFO - 2018-10-16 06:34:23 --> CSRF token verified
INFO - 2018-10-16 06:34:23 --> Input Class Initialized
INFO - 2018-10-16 06:34:23 --> Language Class Initialized
INFO - 2018-10-16 06:34:23 --> Loader Class Initialized
INFO - 2018-10-16 06:34:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:23 --> Controller Class Initialized
INFO - 2018-10-16 06:34:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:23 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:23 --> Form Validation Class Initialized
INFO - 2018-10-16 06:34:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:34:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:23 --> Config Class Initialized
INFO - 2018-10-16 06:34:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:23 --> URI Class Initialized
INFO - 2018-10-16 06:34:23 --> Router Class Initialized
INFO - 2018-10-16 06:34:23 --> Output Class Initialized
INFO - 2018-10-16 06:34:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:23 --> CSRF cookie sent
INFO - 2018-10-16 06:34:23 --> Input Class Initialized
INFO - 2018-10-16 06:34:23 --> Language Class Initialized
INFO - 2018-10-16 06:34:23 --> Loader Class Initialized
INFO - 2018-10-16 06:34:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:23 --> Controller Class Initialized
INFO - 2018-10-16 06:34:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:23 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-16 06:34:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:34:23 --> Final output sent to browser
DEBUG - 2018-10-16 06:34:23 --> Total execution time: 0.0443
INFO - 2018-10-16 06:34:41 --> Config Class Initialized
INFO - 2018-10-16 06:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:41 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:41 --> URI Class Initialized
INFO - 2018-10-16 06:34:41 --> Router Class Initialized
INFO - 2018-10-16 06:34:41 --> Output Class Initialized
INFO - 2018-10-16 06:34:41 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:41 --> CSRF cookie sent
INFO - 2018-10-16 06:34:41 --> CSRF token verified
INFO - 2018-10-16 06:34:41 --> Input Class Initialized
INFO - 2018-10-16 06:34:41 --> Language Class Initialized
INFO - 2018-10-16 06:34:41 --> Loader Class Initialized
INFO - 2018-10-16 06:34:41 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:41 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:41 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:41 --> Controller Class Initialized
INFO - 2018-10-16 06:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:41 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:41 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:41 --> Form Validation Class Initialized
INFO - 2018-10-16 06:34:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:34:41 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:41 --> Config Class Initialized
INFO - 2018-10-16 06:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:41 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:41 --> URI Class Initialized
INFO - 2018-10-16 06:34:41 --> Router Class Initialized
INFO - 2018-10-16 06:34:41 --> Output Class Initialized
INFO - 2018-10-16 06:34:41 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:41 --> CSRF cookie sent
INFO - 2018-10-16 06:34:41 --> Input Class Initialized
INFO - 2018-10-16 06:34:41 --> Language Class Initialized
INFO - 2018-10-16 06:34:41 --> Loader Class Initialized
INFO - 2018-10-16 06:34:41 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:41 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:41 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:41 --> Controller Class Initialized
INFO - 2018-10-16 06:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:41 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:41 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:41 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-16 06:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:34:41 --> Final output sent to browser
DEBUG - 2018-10-16 06:34:41 --> Total execution time: 0.0450
INFO - 2018-10-16 06:34:52 --> Config Class Initialized
INFO - 2018-10-16 06:34:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:52 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:52 --> URI Class Initialized
INFO - 2018-10-16 06:34:52 --> Router Class Initialized
INFO - 2018-10-16 06:34:52 --> Output Class Initialized
INFO - 2018-10-16 06:34:52 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:52 --> CSRF cookie sent
INFO - 2018-10-16 06:34:52 --> CSRF token verified
INFO - 2018-10-16 06:34:52 --> Input Class Initialized
INFO - 2018-10-16 06:34:52 --> Language Class Initialized
INFO - 2018-10-16 06:34:52 --> Loader Class Initialized
INFO - 2018-10-16 06:34:52 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:52 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:52 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:52 --> Controller Class Initialized
INFO - 2018-10-16 06:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:52 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:52 --> Form Validation Class Initialized
INFO - 2018-10-16 06:34:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:34:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:52 --> Config Class Initialized
INFO - 2018-10-16 06:34:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:34:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:34:52 --> Utf8 Class Initialized
INFO - 2018-10-16 06:34:52 --> URI Class Initialized
INFO - 2018-10-16 06:34:52 --> Router Class Initialized
INFO - 2018-10-16 06:34:52 --> Output Class Initialized
INFO - 2018-10-16 06:34:52 --> Security Class Initialized
DEBUG - 2018-10-16 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:34:52 --> CSRF cookie sent
INFO - 2018-10-16 06:34:52 --> Input Class Initialized
INFO - 2018-10-16 06:34:52 --> Language Class Initialized
INFO - 2018-10-16 06:34:52 --> Loader Class Initialized
INFO - 2018-10-16 06:34:52 --> Helper loaded: url_helper
INFO - 2018-10-16 06:34:52 --> Helper loaded: form_helper
INFO - 2018-10-16 06:34:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:34:52 --> User Agent Class Initialized
INFO - 2018-10-16 06:34:52 --> Controller Class Initialized
INFO - 2018-10-16 06:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:34:52 --> Pixel_Model class loaded
INFO - 2018-10-16 06:34:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-16 06:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:34:52 --> Final output sent to browser
DEBUG - 2018-10-16 06:34:52 --> Total execution time: 0.0579
INFO - 2018-10-16 06:35:04 --> Config Class Initialized
INFO - 2018-10-16 06:35:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:04 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:04 --> URI Class Initialized
INFO - 2018-10-16 06:35:04 --> Router Class Initialized
INFO - 2018-10-16 06:35:04 --> Output Class Initialized
INFO - 2018-10-16 06:35:04 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:04 --> CSRF cookie sent
INFO - 2018-10-16 06:35:04 --> CSRF token verified
INFO - 2018-10-16 06:35:04 --> Input Class Initialized
INFO - 2018-10-16 06:35:04 --> Language Class Initialized
INFO - 2018-10-16 06:35:04 --> Loader Class Initialized
INFO - 2018-10-16 06:35:04 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:04 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:04 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:04 --> Controller Class Initialized
INFO - 2018-10-16 06:35:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:04 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:04 --> Form Validation Class Initialized
INFO - 2018-10-16 06:35:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:35:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:04 --> Config Class Initialized
INFO - 2018-10-16 06:35:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:04 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:04 --> URI Class Initialized
INFO - 2018-10-16 06:35:04 --> Router Class Initialized
INFO - 2018-10-16 06:35:04 --> Output Class Initialized
INFO - 2018-10-16 06:35:04 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:04 --> CSRF cookie sent
INFO - 2018-10-16 06:35:04 --> Input Class Initialized
INFO - 2018-10-16 06:35:04 --> Language Class Initialized
INFO - 2018-10-16 06:35:04 --> Loader Class Initialized
INFO - 2018-10-16 06:35:04 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:04 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:04 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:04 --> Controller Class Initialized
INFO - 2018-10-16 06:35:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:04 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-16 06:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:35:04 --> Final output sent to browser
DEBUG - 2018-10-16 06:35:04 --> Total execution time: 0.0527
INFO - 2018-10-16 06:35:13 --> Config Class Initialized
INFO - 2018-10-16 06:35:13 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:13 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:13 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:13 --> URI Class Initialized
INFO - 2018-10-16 06:35:13 --> Router Class Initialized
INFO - 2018-10-16 06:35:13 --> Output Class Initialized
INFO - 2018-10-16 06:35:13 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:13 --> CSRF cookie sent
INFO - 2018-10-16 06:35:13 --> CSRF token verified
INFO - 2018-10-16 06:35:13 --> Input Class Initialized
INFO - 2018-10-16 06:35:13 --> Language Class Initialized
INFO - 2018-10-16 06:35:13 --> Loader Class Initialized
INFO - 2018-10-16 06:35:13 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:13 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:13 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:13 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:13 --> Controller Class Initialized
INFO - 2018-10-16 06:35:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:13 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:13 --> Form Validation Class Initialized
INFO - 2018-10-16 06:35:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:35:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:13 --> Config Class Initialized
INFO - 2018-10-16 06:35:13 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:13 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:13 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:13 --> URI Class Initialized
INFO - 2018-10-16 06:35:13 --> Router Class Initialized
INFO - 2018-10-16 06:35:13 --> Output Class Initialized
INFO - 2018-10-16 06:35:13 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:13 --> CSRF cookie sent
INFO - 2018-10-16 06:35:13 --> Input Class Initialized
INFO - 2018-10-16 06:35:13 --> Language Class Initialized
INFO - 2018-10-16 06:35:13 --> Loader Class Initialized
INFO - 2018-10-16 06:35:13 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:13 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:13 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:13 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:13 --> Controller Class Initialized
INFO - 2018-10-16 06:35:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:13 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-16 06:35:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:35:13 --> Final output sent to browser
DEBUG - 2018-10-16 06:35:13 --> Total execution time: 0.0511
INFO - 2018-10-16 06:35:28 --> Config Class Initialized
INFO - 2018-10-16 06:35:28 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:28 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:28 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:28 --> URI Class Initialized
INFO - 2018-10-16 06:35:28 --> Router Class Initialized
INFO - 2018-10-16 06:35:28 --> Output Class Initialized
INFO - 2018-10-16 06:35:28 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:28 --> CSRF cookie sent
INFO - 2018-10-16 06:35:28 --> CSRF token verified
INFO - 2018-10-16 06:35:28 --> Input Class Initialized
INFO - 2018-10-16 06:35:28 --> Language Class Initialized
INFO - 2018-10-16 06:35:28 --> Loader Class Initialized
INFO - 2018-10-16 06:35:28 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:28 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:28 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:28 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:28 --> Controller Class Initialized
INFO - 2018-10-16 06:35:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:28 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:28 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:28 --> Form Validation Class Initialized
INFO - 2018-10-16 06:35:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:35:28 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:28 --> Config Class Initialized
INFO - 2018-10-16 06:35:28 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:28 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:28 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:28 --> URI Class Initialized
INFO - 2018-10-16 06:35:28 --> Router Class Initialized
INFO - 2018-10-16 06:35:28 --> Output Class Initialized
INFO - 2018-10-16 06:35:28 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:28 --> CSRF cookie sent
INFO - 2018-10-16 06:35:28 --> Input Class Initialized
INFO - 2018-10-16 06:35:28 --> Language Class Initialized
INFO - 2018-10-16 06:35:28 --> Loader Class Initialized
INFO - 2018-10-16 06:35:28 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:28 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:28 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:28 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:28 --> Controller Class Initialized
INFO - 2018-10-16 06:35:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:28 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:28 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:28 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-16 06:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:35:28 --> Final output sent to browser
DEBUG - 2018-10-16 06:35:28 --> Total execution time: 0.0453
INFO - 2018-10-16 06:35:38 --> Config Class Initialized
INFO - 2018-10-16 06:35:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:38 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:38 --> URI Class Initialized
INFO - 2018-10-16 06:35:38 --> Router Class Initialized
INFO - 2018-10-16 06:35:38 --> Output Class Initialized
INFO - 2018-10-16 06:35:38 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:38 --> CSRF cookie sent
INFO - 2018-10-16 06:35:38 --> CSRF token verified
INFO - 2018-10-16 06:35:38 --> Input Class Initialized
INFO - 2018-10-16 06:35:38 --> Language Class Initialized
INFO - 2018-10-16 06:35:38 --> Loader Class Initialized
INFO - 2018-10-16 06:35:38 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:38 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:38 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:38 --> Controller Class Initialized
INFO - 2018-10-16 06:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:38 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:38 --> Form Validation Class Initialized
INFO - 2018-10-16 06:35:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:35:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:38 --> Config Class Initialized
INFO - 2018-10-16 06:35:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:35:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:35:38 --> Utf8 Class Initialized
INFO - 2018-10-16 06:35:38 --> URI Class Initialized
INFO - 2018-10-16 06:35:38 --> Router Class Initialized
INFO - 2018-10-16 06:35:38 --> Output Class Initialized
INFO - 2018-10-16 06:35:38 --> Security Class Initialized
DEBUG - 2018-10-16 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:35:38 --> CSRF cookie sent
INFO - 2018-10-16 06:35:38 --> Input Class Initialized
INFO - 2018-10-16 06:35:38 --> Language Class Initialized
INFO - 2018-10-16 06:35:38 --> Loader Class Initialized
INFO - 2018-10-16 06:35:38 --> Helper loaded: url_helper
INFO - 2018-10-16 06:35:38 --> Helper loaded: form_helper
INFO - 2018-10-16 06:35:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:35:38 --> User Agent Class Initialized
INFO - 2018-10-16 06:35:38 --> Controller Class Initialized
INFO - 2018-10-16 06:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:35:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:35:38 --> Pixel_Model class loaded
INFO - 2018-10-16 06:35:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-16 06:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:35:38 --> Final output sent to browser
DEBUG - 2018-10-16 06:35:38 --> Total execution time: 0.0481
INFO - 2018-10-16 06:36:21 --> Config Class Initialized
INFO - 2018-10-16 06:36:21 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:21 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:21 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:21 --> URI Class Initialized
INFO - 2018-10-16 06:36:21 --> Router Class Initialized
INFO - 2018-10-16 06:36:21 --> Output Class Initialized
INFO - 2018-10-16 06:36:21 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:21 --> CSRF cookie sent
INFO - 2018-10-16 06:36:21 --> Input Class Initialized
INFO - 2018-10-16 06:36:21 --> Language Class Initialized
INFO - 2018-10-16 06:36:21 --> Loader Class Initialized
INFO - 2018-10-16 06:36:21 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:21 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:21 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:21 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:21 --> Controller Class Initialized
INFO - 2018-10-16 06:36:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:21 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:21 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:21 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:36:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:21 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:21 --> Total execution time: 0.0462
INFO - 2018-10-16 06:36:23 --> Config Class Initialized
INFO - 2018-10-16 06:36:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:23 --> URI Class Initialized
INFO - 2018-10-16 06:36:23 --> Router Class Initialized
INFO - 2018-10-16 06:36:23 --> Output Class Initialized
INFO - 2018-10-16 06:36:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:23 --> CSRF cookie sent
INFO - 2018-10-16 06:36:23 --> Input Class Initialized
INFO - 2018-10-16 06:36:23 --> Language Class Initialized
INFO - 2018-10-16 06:36:23 --> Loader Class Initialized
INFO - 2018-10-16 06:36:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:23 --> Controller Class Initialized
INFO - 2018-10-16 06:36:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:23 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:36:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:24 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:24 --> Total execution time: 0.0447
INFO - 2018-10-16 06:36:27 --> Config Class Initialized
INFO - 2018-10-16 06:36:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:27 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:27 --> URI Class Initialized
INFO - 2018-10-16 06:36:27 --> Router Class Initialized
INFO - 2018-10-16 06:36:27 --> Output Class Initialized
INFO - 2018-10-16 06:36:27 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:27 --> CSRF cookie sent
INFO - 2018-10-16 06:36:27 --> CSRF token verified
INFO - 2018-10-16 06:36:27 --> Input Class Initialized
INFO - 2018-10-16 06:36:27 --> Language Class Initialized
INFO - 2018-10-16 06:36:27 --> Loader Class Initialized
INFO - 2018-10-16 06:36:27 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:27 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:27 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:27 --> Controller Class Initialized
INFO - 2018-10-16 06:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:27 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:27 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:27 --> Config Class Initialized
INFO - 2018-10-16 06:36:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:27 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:27 --> URI Class Initialized
INFO - 2018-10-16 06:36:27 --> Router Class Initialized
INFO - 2018-10-16 06:36:27 --> Output Class Initialized
INFO - 2018-10-16 06:36:27 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:27 --> CSRF cookie sent
INFO - 2018-10-16 06:36:27 --> Input Class Initialized
INFO - 2018-10-16 06:36:27 --> Language Class Initialized
INFO - 2018-10-16 06:36:27 --> Loader Class Initialized
INFO - 2018-10-16 06:36:27 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:27 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:27 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:27 --> Controller Class Initialized
INFO - 2018-10-16 06:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:27 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:27 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:27 --> Total execution time: 0.0482
INFO - 2018-10-16 06:36:31 --> Config Class Initialized
INFO - 2018-10-16 06:36:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:31 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:31 --> URI Class Initialized
INFO - 2018-10-16 06:36:31 --> Router Class Initialized
INFO - 2018-10-16 06:36:31 --> Output Class Initialized
INFO - 2018-10-16 06:36:31 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:31 --> CSRF cookie sent
INFO - 2018-10-16 06:36:31 --> CSRF token verified
INFO - 2018-10-16 06:36:31 --> Input Class Initialized
INFO - 2018-10-16 06:36:31 --> Language Class Initialized
INFO - 2018-10-16 06:36:31 --> Loader Class Initialized
INFO - 2018-10-16 06:36:31 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:31 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:31 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:31 --> Controller Class Initialized
INFO - 2018-10-16 06:36:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:31 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:31 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:31 --> Config Class Initialized
INFO - 2018-10-16 06:36:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:31 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:31 --> URI Class Initialized
INFO - 2018-10-16 06:36:31 --> Router Class Initialized
INFO - 2018-10-16 06:36:31 --> Output Class Initialized
INFO - 2018-10-16 06:36:31 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:31 --> CSRF cookie sent
INFO - 2018-10-16 06:36:31 --> Input Class Initialized
INFO - 2018-10-16 06:36:31 --> Language Class Initialized
INFO - 2018-10-16 06:36:31 --> Loader Class Initialized
INFO - 2018-10-16 06:36:31 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:31 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:31 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:31 --> Controller Class Initialized
INFO - 2018-10-16 06:36:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:31 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:36:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:31 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:31 --> Total execution time: 0.0572
INFO - 2018-10-16 06:36:35 --> Config Class Initialized
INFO - 2018-10-16 06:36:35 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:35 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:35 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:35 --> URI Class Initialized
INFO - 2018-10-16 06:36:35 --> Router Class Initialized
INFO - 2018-10-16 06:36:35 --> Output Class Initialized
INFO - 2018-10-16 06:36:35 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:35 --> CSRF cookie sent
INFO - 2018-10-16 06:36:35 --> CSRF token verified
INFO - 2018-10-16 06:36:35 --> Input Class Initialized
INFO - 2018-10-16 06:36:35 --> Language Class Initialized
INFO - 2018-10-16 06:36:35 --> Loader Class Initialized
INFO - 2018-10-16 06:36:35 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:35 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:35 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:35 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:35 --> Controller Class Initialized
INFO - 2018-10-16 06:36:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:35 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:35 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:35 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:35 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:35 --> Config Class Initialized
INFO - 2018-10-16 06:36:35 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:35 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:35 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:35 --> URI Class Initialized
INFO - 2018-10-16 06:36:35 --> Router Class Initialized
INFO - 2018-10-16 06:36:35 --> Output Class Initialized
INFO - 2018-10-16 06:36:35 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:35 --> CSRF cookie sent
INFO - 2018-10-16 06:36:35 --> Input Class Initialized
INFO - 2018-10-16 06:36:35 --> Language Class Initialized
INFO - 2018-10-16 06:36:35 --> Loader Class Initialized
INFO - 2018-10-16 06:36:35 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:35 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:35 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:35 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:35 --> Controller Class Initialized
INFO - 2018-10-16 06:36:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:35 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:35 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:35 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 06:36:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:35 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:35 --> Total execution time: 0.0403
INFO - 2018-10-16 06:36:42 --> Config Class Initialized
INFO - 2018-10-16 06:36:42 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:42 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:42 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:42 --> URI Class Initialized
INFO - 2018-10-16 06:36:42 --> Router Class Initialized
INFO - 2018-10-16 06:36:42 --> Output Class Initialized
INFO - 2018-10-16 06:36:42 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:42 --> CSRF cookie sent
INFO - 2018-10-16 06:36:42 --> CSRF token verified
INFO - 2018-10-16 06:36:42 --> Input Class Initialized
INFO - 2018-10-16 06:36:42 --> Language Class Initialized
INFO - 2018-10-16 06:36:42 --> Loader Class Initialized
INFO - 2018-10-16 06:36:42 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:42 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:42 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:42 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:42 --> Controller Class Initialized
INFO - 2018-10-16 06:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:42 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:42 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:42 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:42 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:42 --> Config Class Initialized
INFO - 2018-10-16 06:36:42 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:42 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:42 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:42 --> URI Class Initialized
INFO - 2018-10-16 06:36:42 --> Router Class Initialized
INFO - 2018-10-16 06:36:42 --> Output Class Initialized
INFO - 2018-10-16 06:36:42 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:42 --> CSRF cookie sent
INFO - 2018-10-16 06:36:42 --> Input Class Initialized
INFO - 2018-10-16 06:36:42 --> Language Class Initialized
INFO - 2018-10-16 06:36:42 --> Loader Class Initialized
INFO - 2018-10-16 06:36:42 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:42 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:42 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:42 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:42 --> Controller Class Initialized
INFO - 2018-10-16 06:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:42 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:42 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:42 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 06:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:42 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:42 --> Total execution time: 0.0385
INFO - 2018-10-16 06:36:45 --> Config Class Initialized
INFO - 2018-10-16 06:36:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:45 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:45 --> URI Class Initialized
INFO - 2018-10-16 06:36:45 --> Router Class Initialized
INFO - 2018-10-16 06:36:45 --> Output Class Initialized
INFO - 2018-10-16 06:36:45 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:45 --> CSRF cookie sent
INFO - 2018-10-16 06:36:45 --> CSRF token verified
INFO - 2018-10-16 06:36:45 --> Input Class Initialized
INFO - 2018-10-16 06:36:45 --> Language Class Initialized
INFO - 2018-10-16 06:36:45 --> Loader Class Initialized
INFO - 2018-10-16 06:36:45 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:45 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:45 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:45 --> Controller Class Initialized
INFO - 2018-10-16 06:36:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:45 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:45 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:45 --> Config Class Initialized
INFO - 2018-10-16 06:36:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:45 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:45 --> URI Class Initialized
INFO - 2018-10-16 06:36:45 --> Router Class Initialized
INFO - 2018-10-16 06:36:45 --> Output Class Initialized
INFO - 2018-10-16 06:36:45 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:45 --> CSRF cookie sent
INFO - 2018-10-16 06:36:45 --> Input Class Initialized
INFO - 2018-10-16 06:36:45 --> Language Class Initialized
INFO - 2018-10-16 06:36:45 --> Loader Class Initialized
INFO - 2018-10-16 06:36:45 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:45 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:45 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:45 --> Controller Class Initialized
INFO - 2018-10-16 06:36:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:45 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:36:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:45 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:45 --> Total execution time: 0.0554
INFO - 2018-10-16 06:36:47 --> Config Class Initialized
INFO - 2018-10-16 06:36:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:47 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:47 --> URI Class Initialized
INFO - 2018-10-16 06:36:47 --> Router Class Initialized
INFO - 2018-10-16 06:36:47 --> Output Class Initialized
INFO - 2018-10-16 06:36:47 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:47 --> CSRF cookie sent
INFO - 2018-10-16 06:36:47 --> CSRF token verified
INFO - 2018-10-16 06:36:47 --> Input Class Initialized
INFO - 2018-10-16 06:36:47 --> Language Class Initialized
INFO - 2018-10-16 06:36:47 --> Loader Class Initialized
INFO - 2018-10-16 06:36:47 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:47 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:47 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:47 --> Controller Class Initialized
INFO - 2018-10-16 06:36:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:47 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:47 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:47 --> Config Class Initialized
INFO - 2018-10-16 06:36:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:47 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:47 --> URI Class Initialized
INFO - 2018-10-16 06:36:47 --> Router Class Initialized
INFO - 2018-10-16 06:36:47 --> Output Class Initialized
INFO - 2018-10-16 06:36:47 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:47 --> CSRF cookie sent
INFO - 2018-10-16 06:36:47 --> Input Class Initialized
INFO - 2018-10-16 06:36:47 --> Language Class Initialized
INFO - 2018-10-16 06:36:47 --> Loader Class Initialized
INFO - 2018-10-16 06:36:47 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:47 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:47 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:47 --> Controller Class Initialized
INFO - 2018-10-16 06:36:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:47 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:47 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:47 --> Total execution time: 0.0524
INFO - 2018-10-16 06:36:48 --> Config Class Initialized
INFO - 2018-10-16 06:36:48 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:48 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:48 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:48 --> URI Class Initialized
INFO - 2018-10-16 06:36:48 --> Router Class Initialized
INFO - 2018-10-16 06:36:48 --> Output Class Initialized
INFO - 2018-10-16 06:36:48 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:48 --> CSRF cookie sent
INFO - 2018-10-16 06:36:48 --> CSRF token verified
INFO - 2018-10-16 06:36:48 --> Input Class Initialized
INFO - 2018-10-16 06:36:48 --> Language Class Initialized
INFO - 2018-10-16 06:36:48 --> Loader Class Initialized
INFO - 2018-10-16 06:36:48 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:48 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:48 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:48 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:48 --> Controller Class Initialized
INFO - 2018-10-16 06:36:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:48 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:48 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:48 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:48 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:48 --> Config Class Initialized
INFO - 2018-10-16 06:36:48 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:48 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:48 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:48 --> URI Class Initialized
INFO - 2018-10-16 06:36:48 --> Router Class Initialized
INFO - 2018-10-16 06:36:48 --> Output Class Initialized
INFO - 2018-10-16 06:36:48 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:48 --> CSRF cookie sent
INFO - 2018-10-16 06:36:48 --> Input Class Initialized
INFO - 2018-10-16 06:36:48 --> Language Class Initialized
INFO - 2018-10-16 06:36:49 --> Loader Class Initialized
INFO - 2018-10-16 06:36:49 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:49 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:49 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:49 --> Controller Class Initialized
INFO - 2018-10-16 06:36:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:49 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:49 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:49 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-16 06:36:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:49 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:49 --> Total execution time: 0.0670
INFO - 2018-10-16 06:36:51 --> Config Class Initialized
INFO - 2018-10-16 06:36:51 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:51 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:51 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:51 --> URI Class Initialized
INFO - 2018-10-16 06:36:51 --> Router Class Initialized
INFO - 2018-10-16 06:36:51 --> Output Class Initialized
INFO - 2018-10-16 06:36:51 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:51 --> CSRF cookie sent
INFO - 2018-10-16 06:36:51 --> CSRF token verified
INFO - 2018-10-16 06:36:51 --> Input Class Initialized
INFO - 2018-10-16 06:36:51 --> Language Class Initialized
INFO - 2018-10-16 06:36:51 --> Loader Class Initialized
INFO - 2018-10-16 06:36:51 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:51 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:51 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:51 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:51 --> Controller Class Initialized
INFO - 2018-10-16 06:36:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:51 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:51 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:51 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:51 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:51 --> Config Class Initialized
INFO - 2018-10-16 06:36:51 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:51 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:51 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:51 --> URI Class Initialized
INFO - 2018-10-16 06:36:51 --> Router Class Initialized
INFO - 2018-10-16 06:36:51 --> Output Class Initialized
INFO - 2018-10-16 06:36:51 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:51 --> CSRF cookie sent
INFO - 2018-10-16 06:36:51 --> Input Class Initialized
INFO - 2018-10-16 06:36:51 --> Language Class Initialized
INFO - 2018-10-16 06:36:51 --> Loader Class Initialized
INFO - 2018-10-16 06:36:51 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:51 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:51 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:51 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:51 --> Controller Class Initialized
INFO - 2018-10-16 06:36:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:51 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:51 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:51 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-16 06:36:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:51 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:51 --> Total execution time: 0.0453
INFO - 2018-10-16 06:36:52 --> Config Class Initialized
INFO - 2018-10-16 06:36:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:52 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:52 --> URI Class Initialized
INFO - 2018-10-16 06:36:52 --> Router Class Initialized
INFO - 2018-10-16 06:36:52 --> Output Class Initialized
INFO - 2018-10-16 06:36:52 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:52 --> CSRF cookie sent
INFO - 2018-10-16 06:36:52 --> CSRF token verified
INFO - 2018-10-16 06:36:52 --> Input Class Initialized
INFO - 2018-10-16 06:36:52 --> Language Class Initialized
INFO - 2018-10-16 06:36:52 --> Loader Class Initialized
INFO - 2018-10-16 06:36:52 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:52 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:52 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:52 --> Controller Class Initialized
INFO - 2018-10-16 06:36:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:52 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:52 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:52 --> Config Class Initialized
INFO - 2018-10-16 06:36:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:52 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:52 --> URI Class Initialized
INFO - 2018-10-16 06:36:52 --> Router Class Initialized
INFO - 2018-10-16 06:36:52 --> Output Class Initialized
INFO - 2018-10-16 06:36:52 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:52 --> CSRF cookie sent
INFO - 2018-10-16 06:36:52 --> Input Class Initialized
INFO - 2018-10-16 06:36:52 --> Language Class Initialized
INFO - 2018-10-16 06:36:52 --> Loader Class Initialized
INFO - 2018-10-16 06:36:52 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:52 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:52 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:52 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:52 --> Controller Class Initialized
INFO - 2018-10-16 06:36:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:52 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:52 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-16 06:36:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:52 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:52 --> Total execution time: 0.0498
INFO - 2018-10-16 06:36:54 --> Config Class Initialized
INFO - 2018-10-16 06:36:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:54 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:54 --> URI Class Initialized
INFO - 2018-10-16 06:36:54 --> Router Class Initialized
INFO - 2018-10-16 06:36:54 --> Output Class Initialized
INFO - 2018-10-16 06:36:54 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:54 --> CSRF cookie sent
INFO - 2018-10-16 06:36:54 --> CSRF token verified
INFO - 2018-10-16 06:36:54 --> Input Class Initialized
INFO - 2018-10-16 06:36:54 --> Language Class Initialized
INFO - 2018-10-16 06:36:54 --> Loader Class Initialized
INFO - 2018-10-16 06:36:54 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:54 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:54 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:54 --> Controller Class Initialized
INFO - 2018-10-16 06:36:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:54 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:54 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:54 --> Config Class Initialized
INFO - 2018-10-16 06:36:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:54 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:54 --> URI Class Initialized
INFO - 2018-10-16 06:36:54 --> Router Class Initialized
INFO - 2018-10-16 06:36:54 --> Output Class Initialized
INFO - 2018-10-16 06:36:54 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:54 --> CSRF cookie sent
INFO - 2018-10-16 06:36:54 --> Input Class Initialized
INFO - 2018-10-16 06:36:54 --> Language Class Initialized
INFO - 2018-10-16 06:36:54 --> Loader Class Initialized
INFO - 2018-10-16 06:36:54 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:54 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:54 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:54 --> Controller Class Initialized
INFO - 2018-10-16 06:36:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:54 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-16 06:36:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:54 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:54 --> Total execution time: 0.0460
INFO - 2018-10-16 06:36:57 --> Config Class Initialized
INFO - 2018-10-16 06:36:57 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:57 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:57 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:57 --> URI Class Initialized
INFO - 2018-10-16 06:36:57 --> Router Class Initialized
INFO - 2018-10-16 06:36:57 --> Output Class Initialized
INFO - 2018-10-16 06:36:57 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:57 --> CSRF cookie sent
INFO - 2018-10-16 06:36:57 --> CSRF token verified
INFO - 2018-10-16 06:36:57 --> Input Class Initialized
INFO - 2018-10-16 06:36:57 --> Language Class Initialized
INFO - 2018-10-16 06:36:57 --> Loader Class Initialized
INFO - 2018-10-16 06:36:57 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:57 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:57 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:57 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:57 --> Controller Class Initialized
INFO - 2018-10-16 06:36:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:57 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:57 --> Form Validation Class Initialized
INFO - 2018-10-16 06:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:57 --> Config Class Initialized
INFO - 2018-10-16 06:36:57 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:36:57 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:36:57 --> Utf8 Class Initialized
INFO - 2018-10-16 06:36:57 --> URI Class Initialized
INFO - 2018-10-16 06:36:57 --> Router Class Initialized
INFO - 2018-10-16 06:36:57 --> Output Class Initialized
INFO - 2018-10-16 06:36:57 --> Security Class Initialized
DEBUG - 2018-10-16 06:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:36:57 --> CSRF cookie sent
INFO - 2018-10-16 06:36:57 --> Input Class Initialized
INFO - 2018-10-16 06:36:57 --> Language Class Initialized
INFO - 2018-10-16 06:36:57 --> Loader Class Initialized
INFO - 2018-10-16 06:36:57 --> Helper loaded: url_helper
INFO - 2018-10-16 06:36:57 --> Helper loaded: form_helper
INFO - 2018-10-16 06:36:57 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:36:57 --> User Agent Class Initialized
INFO - 2018-10-16 06:36:57 --> Controller Class Initialized
INFO - 2018-10-16 06:36:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:36:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:36:57 --> Pixel_Model class loaded
INFO - 2018-10-16 06:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 06:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-16 06:36:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:36:57 --> Final output sent to browser
DEBUG - 2018-10-16 06:36:57 --> Total execution time: 0.0467
INFO - 2018-10-16 06:37:00 --> Config Class Initialized
INFO - 2018-10-16 06:37:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:00 --> URI Class Initialized
INFO - 2018-10-16 06:37:00 --> Router Class Initialized
INFO - 2018-10-16 06:37:00 --> Output Class Initialized
INFO - 2018-10-16 06:37:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:00 --> CSRF cookie sent
INFO - 2018-10-16 06:37:00 --> CSRF token verified
INFO - 2018-10-16 06:37:00 --> Input Class Initialized
INFO - 2018-10-16 06:37:00 --> Language Class Initialized
INFO - 2018-10-16 06:37:00 --> Loader Class Initialized
INFO - 2018-10-16 06:37:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:00 --> Controller Class Initialized
INFO - 2018-10-16 06:37:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:00 --> Form Validation Class Initialized
INFO - 2018-10-16 06:37:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:37:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:00 --> Config Class Initialized
INFO - 2018-10-16 06:37:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:00 --> URI Class Initialized
INFO - 2018-10-16 06:37:00 --> Router Class Initialized
INFO - 2018-10-16 06:37:00 --> Output Class Initialized
INFO - 2018-10-16 06:37:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:00 --> CSRF cookie sent
INFO - 2018-10-16 06:37:00 --> Input Class Initialized
INFO - 2018-10-16 06:37:00 --> Language Class Initialized
INFO - 2018-10-16 06:37:00 --> Loader Class Initialized
INFO - 2018-10-16 06:37:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:00 --> Controller Class Initialized
INFO - 2018-10-16 06:37:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-16 06:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:00 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:00 --> Total execution time: 0.0537
INFO - 2018-10-16 06:37:10 --> Config Class Initialized
INFO - 2018-10-16 06:37:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:10 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:10 --> URI Class Initialized
INFO - 2018-10-16 06:37:10 --> Router Class Initialized
INFO - 2018-10-16 06:37:10 --> Output Class Initialized
INFO - 2018-10-16 06:37:10 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:10 --> CSRF cookie sent
INFO - 2018-10-16 06:37:10 --> CSRF token verified
INFO - 2018-10-16 06:37:10 --> Input Class Initialized
INFO - 2018-10-16 06:37:10 --> Language Class Initialized
INFO - 2018-10-16 06:37:10 --> Loader Class Initialized
INFO - 2018-10-16 06:37:10 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:10 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:10 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:10 --> Controller Class Initialized
INFO - 2018-10-16 06:37:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:10 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:10 --> Form Validation Class Initialized
INFO - 2018-10-16 06:37:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:10 --> Config Class Initialized
INFO - 2018-10-16 06:37:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:10 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:10 --> URI Class Initialized
INFO - 2018-10-16 06:37:10 --> Router Class Initialized
INFO - 2018-10-16 06:37:10 --> Output Class Initialized
INFO - 2018-10-16 06:37:10 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:10 --> CSRF cookie sent
INFO - 2018-10-16 06:37:10 --> Input Class Initialized
INFO - 2018-10-16 06:37:10 --> Language Class Initialized
INFO - 2018-10-16 06:37:10 --> Loader Class Initialized
INFO - 2018-10-16 06:37:10 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:10 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:10 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:10 --> Controller Class Initialized
INFO - 2018-10-16 06:37:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:10 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-16 06:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:10 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:10 --> Total execution time: 0.0475
INFO - 2018-10-16 06:37:20 --> Config Class Initialized
INFO - 2018-10-16 06:37:20 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:20 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:20 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:20 --> URI Class Initialized
INFO - 2018-10-16 06:37:20 --> Router Class Initialized
INFO - 2018-10-16 06:37:20 --> Output Class Initialized
INFO - 2018-10-16 06:37:20 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:20 --> CSRF cookie sent
INFO - 2018-10-16 06:37:20 --> Input Class Initialized
INFO - 2018-10-16 06:37:20 --> Language Class Initialized
INFO - 2018-10-16 06:37:20 --> Loader Class Initialized
INFO - 2018-10-16 06:37:20 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:20 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:20 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:20 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:20 --> Controller Class Initialized
INFO - 2018-10-16 06:37:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:20 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:20 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:37:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:20 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:20 --> Total execution time: 0.0385
INFO - 2018-10-16 06:37:24 --> Config Class Initialized
INFO - 2018-10-16 06:37:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:24 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:24 --> URI Class Initialized
INFO - 2018-10-16 06:37:24 --> Router Class Initialized
INFO - 2018-10-16 06:37:24 --> Output Class Initialized
INFO - 2018-10-16 06:37:24 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:24 --> CSRF cookie sent
INFO - 2018-10-16 06:37:24 --> CSRF token verified
INFO - 2018-10-16 06:37:24 --> Input Class Initialized
INFO - 2018-10-16 06:37:24 --> Language Class Initialized
INFO - 2018-10-16 06:37:24 --> Loader Class Initialized
INFO - 2018-10-16 06:37:24 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:24 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:24 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:24 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:24 --> Controller Class Initialized
INFO - 2018-10-16 06:37:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:24 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:24 --> Form Validation Class Initialized
INFO - 2018-10-16 06:37:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:37:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:24 --> Config Class Initialized
INFO - 2018-10-16 06:37:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:24 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:24 --> URI Class Initialized
INFO - 2018-10-16 06:37:24 --> Router Class Initialized
INFO - 2018-10-16 06:37:24 --> Output Class Initialized
INFO - 2018-10-16 06:37:24 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:24 --> CSRF cookie sent
INFO - 2018-10-16 06:37:24 --> Input Class Initialized
INFO - 2018-10-16 06:37:24 --> Language Class Initialized
INFO - 2018-10-16 06:37:24 --> Loader Class Initialized
INFO - 2018-10-16 06:37:24 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:24 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:24 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:24 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:24 --> Controller Class Initialized
INFO - 2018-10-16 06:37:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:24 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:24 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:24 --> Total execution time: 0.0451
INFO - 2018-10-16 06:37:30 --> Config Class Initialized
INFO - 2018-10-16 06:37:30 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:30 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:30 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:30 --> URI Class Initialized
INFO - 2018-10-16 06:37:30 --> Router Class Initialized
INFO - 2018-10-16 06:37:30 --> Output Class Initialized
INFO - 2018-10-16 06:37:30 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:30 --> CSRF cookie sent
INFO - 2018-10-16 06:37:30 --> CSRF token verified
INFO - 2018-10-16 06:37:30 --> Input Class Initialized
INFO - 2018-10-16 06:37:30 --> Language Class Initialized
INFO - 2018-10-16 06:37:30 --> Loader Class Initialized
INFO - 2018-10-16 06:37:30 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:30 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:30 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:30 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:30 --> Controller Class Initialized
INFO - 2018-10-16 06:37:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:30 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:30 --> Form Validation Class Initialized
INFO - 2018-10-16 06:37:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:30 --> Config Class Initialized
INFO - 2018-10-16 06:37:30 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:30 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:30 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:30 --> URI Class Initialized
INFO - 2018-10-16 06:37:30 --> Router Class Initialized
INFO - 2018-10-16 06:37:30 --> Output Class Initialized
INFO - 2018-10-16 06:37:30 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:30 --> CSRF cookie sent
INFO - 2018-10-16 06:37:30 --> Input Class Initialized
INFO - 2018-10-16 06:37:30 --> Language Class Initialized
INFO - 2018-10-16 06:37:30 --> Loader Class Initialized
INFO - 2018-10-16 06:37:30 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:30 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:30 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:30 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:30 --> Controller Class Initialized
INFO - 2018-10-16 06:37:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:30 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:37:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:30 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:30 --> Total execution time: 0.0449
INFO - 2018-10-16 06:37:32 --> Config Class Initialized
INFO - 2018-10-16 06:37:32 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:37:32 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:37:32 --> Utf8 Class Initialized
INFO - 2018-10-16 06:37:32 --> URI Class Initialized
INFO - 2018-10-16 06:37:32 --> Router Class Initialized
INFO - 2018-10-16 06:37:32 --> Output Class Initialized
INFO - 2018-10-16 06:37:33 --> Security Class Initialized
DEBUG - 2018-10-16 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:37:33 --> CSRF cookie sent
INFO - 2018-10-16 06:37:33 --> Input Class Initialized
INFO - 2018-10-16 06:37:33 --> Language Class Initialized
INFO - 2018-10-16 06:37:33 --> Loader Class Initialized
INFO - 2018-10-16 06:37:33 --> Helper loaded: url_helper
INFO - 2018-10-16 06:37:33 --> Helper loaded: form_helper
INFO - 2018-10-16 06:37:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:37:33 --> User Agent Class Initialized
INFO - 2018-10-16 06:37:33 --> Controller Class Initialized
INFO - 2018-10-16 06:37:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:37:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:37:33 --> Pixel_Model class loaded
INFO - 2018-10-16 06:37:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:37:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:37:33 --> Final output sent to browser
DEBUG - 2018-10-16 06:37:33 --> Total execution time: 0.0500
INFO - 2018-10-16 06:40:33 --> Config Class Initialized
INFO - 2018-10-16 06:40:33 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:40:33 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:40:33 --> Utf8 Class Initialized
INFO - 2018-10-16 06:40:33 --> URI Class Initialized
DEBUG - 2018-10-16 06:40:33 --> No URI present. Default controller set.
INFO - 2018-10-16 06:40:33 --> Router Class Initialized
INFO - 2018-10-16 06:40:33 --> Output Class Initialized
INFO - 2018-10-16 06:40:33 --> Security Class Initialized
DEBUG - 2018-10-16 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:40:33 --> CSRF cookie sent
INFO - 2018-10-16 06:40:33 --> Input Class Initialized
INFO - 2018-10-16 06:40:33 --> Language Class Initialized
INFO - 2018-10-16 06:40:33 --> Loader Class Initialized
INFO - 2018-10-16 06:40:33 --> Helper loaded: url_helper
INFO - 2018-10-16 06:40:33 --> Helper loaded: form_helper
INFO - 2018-10-16 06:40:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:40:33 --> User Agent Class Initialized
INFO - 2018-10-16 06:40:33 --> Controller Class Initialized
INFO - 2018-10-16 06:40:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:40:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:40:33 --> Pixel_Model class loaded
INFO - 2018-10-16 06:40:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:40:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 06:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:40:33 --> Final output sent to browser
DEBUG - 2018-10-16 06:40:33 --> Total execution time: 0.0403
INFO - 2018-10-16 06:40:48 --> Config Class Initialized
INFO - 2018-10-16 06:40:48 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:40:48 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:40:48 --> Utf8 Class Initialized
INFO - 2018-10-16 06:40:48 --> URI Class Initialized
INFO - 2018-10-16 06:40:48 --> Router Class Initialized
INFO - 2018-10-16 06:40:48 --> Output Class Initialized
INFO - 2018-10-16 06:40:48 --> Security Class Initialized
DEBUG - 2018-10-16 06:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:40:48 --> CSRF cookie sent
INFO - 2018-10-16 06:40:48 --> Input Class Initialized
INFO - 2018-10-16 06:40:48 --> Language Class Initialized
INFO - 2018-10-16 06:40:48 --> Loader Class Initialized
INFO - 2018-10-16 06:40:48 --> Helper loaded: url_helper
INFO - 2018-10-16 06:40:48 --> Helper loaded: form_helper
INFO - 2018-10-16 06:40:48 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:40:48 --> User Agent Class Initialized
INFO - 2018-10-16 06:40:48 --> Controller Class Initialized
INFO - 2018-10-16 06:40:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:40:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:40:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:40:48 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 06:40:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:40:48 --> Final output sent to browser
DEBUG - 2018-10-16 06:40:48 --> Total execution time: 0.0253
INFO - 2018-10-16 06:40:50 --> Config Class Initialized
INFO - 2018-10-16 06:40:50 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:40:50 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:40:50 --> Utf8 Class Initialized
INFO - 2018-10-16 06:40:50 --> URI Class Initialized
INFO - 2018-10-16 06:40:50 --> Router Class Initialized
INFO - 2018-10-16 06:40:50 --> Output Class Initialized
INFO - 2018-10-16 06:40:50 --> Security Class Initialized
DEBUG - 2018-10-16 06:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:40:50 --> CSRF cookie sent
INFO - 2018-10-16 06:40:50 --> Input Class Initialized
INFO - 2018-10-16 06:40:50 --> Language Class Initialized
INFO - 2018-10-16 06:40:50 --> Loader Class Initialized
INFO - 2018-10-16 06:40:50 --> Helper loaded: url_helper
INFO - 2018-10-16 06:40:50 --> Helper loaded: form_helper
INFO - 2018-10-16 06:40:50 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:40:50 --> User Agent Class Initialized
INFO - 2018-10-16 06:40:50 --> Controller Class Initialized
INFO - 2018-10-16 06:40:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:40:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:40:50 --> Pixel_Model class loaded
INFO - 2018-10-16 06:40:50 --> Database Driver Class Initialized
INFO - 2018-10-16 06:40:50 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:40:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:40:50 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:40:50 --> Final output sent to browser
DEBUG - 2018-10-16 06:40:50 --> Total execution time: 0.0353
INFO - 2018-10-16 06:41:14 --> Config Class Initialized
INFO - 2018-10-16 06:41:14 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:41:14 --> Utf8 Class Initialized
INFO - 2018-10-16 06:41:14 --> URI Class Initialized
INFO - 2018-10-16 06:41:14 --> Router Class Initialized
INFO - 2018-10-16 06:41:14 --> Output Class Initialized
INFO - 2018-10-16 06:41:14 --> Security Class Initialized
DEBUG - 2018-10-16 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:41:14 --> CSRF cookie sent
INFO - 2018-10-16 06:41:14 --> Input Class Initialized
INFO - 2018-10-16 06:41:14 --> Language Class Initialized
INFO - 2018-10-16 06:41:14 --> Loader Class Initialized
INFO - 2018-10-16 06:41:14 --> Helper loaded: url_helper
INFO - 2018-10-16 06:41:14 --> Helper loaded: form_helper
INFO - 2018-10-16 06:41:14 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:41:14 --> User Agent Class Initialized
INFO - 2018-10-16 06:41:14 --> Controller Class Initialized
INFO - 2018-10-16 06:41:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:41:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:41:14 --> Pixel_Model class loaded
INFO - 2018-10-16 06:41:14 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:41:14 --> Final output sent to browser
DEBUG - 2018-10-16 06:41:14 --> Total execution time: 0.0383
INFO - 2018-10-16 06:41:16 --> Config Class Initialized
INFO - 2018-10-16 06:41:16 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:41:16 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:41:16 --> Utf8 Class Initialized
INFO - 2018-10-16 06:41:16 --> URI Class Initialized
INFO - 2018-10-16 06:41:16 --> Router Class Initialized
INFO - 2018-10-16 06:41:16 --> Output Class Initialized
INFO - 2018-10-16 06:41:16 --> Security Class Initialized
DEBUG - 2018-10-16 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:41:16 --> CSRF cookie sent
INFO - 2018-10-16 06:41:16 --> CSRF token verified
INFO - 2018-10-16 06:41:16 --> Input Class Initialized
INFO - 2018-10-16 06:41:16 --> Language Class Initialized
INFO - 2018-10-16 06:41:16 --> Loader Class Initialized
INFO - 2018-10-16 06:41:16 --> Helper loaded: url_helper
INFO - 2018-10-16 06:41:16 --> Helper loaded: form_helper
INFO - 2018-10-16 06:41:16 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:41:16 --> User Agent Class Initialized
INFO - 2018-10-16 06:41:16 --> Controller Class Initialized
INFO - 2018-10-16 06:41:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:41:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:41:16 --> Pixel_Model class loaded
INFO - 2018-10-16 06:41:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:16 --> Form Validation Class Initialized
INFO - 2018-10-16 06:41:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:41:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:16 --> Config Class Initialized
INFO - 2018-10-16 06:41:16 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:41:16 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:41:16 --> Utf8 Class Initialized
INFO - 2018-10-16 06:41:16 --> URI Class Initialized
INFO - 2018-10-16 06:41:16 --> Router Class Initialized
INFO - 2018-10-16 06:41:16 --> Output Class Initialized
INFO - 2018-10-16 06:41:16 --> Security Class Initialized
DEBUG - 2018-10-16 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:41:16 --> CSRF cookie sent
INFO - 2018-10-16 06:41:16 --> Input Class Initialized
INFO - 2018-10-16 06:41:16 --> Language Class Initialized
INFO - 2018-10-16 06:41:16 --> Loader Class Initialized
INFO - 2018-10-16 06:41:16 --> Helper loaded: url_helper
INFO - 2018-10-16 06:41:16 --> Helper loaded: form_helper
INFO - 2018-10-16 06:41:16 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:41:16 --> User Agent Class Initialized
INFO - 2018-10-16 06:41:16 --> Controller Class Initialized
INFO - 2018-10-16 06:41:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:41:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:41:16 --> Pixel_Model class loaded
INFO - 2018-10-16 06:41:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:41:16 --> Final output sent to browser
DEBUG - 2018-10-16 06:41:16 --> Total execution time: 0.0449
INFO - 2018-10-16 06:41:22 --> Config Class Initialized
INFO - 2018-10-16 06:41:22 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:41:22 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:41:22 --> Utf8 Class Initialized
INFO - 2018-10-16 06:41:22 --> URI Class Initialized
INFO - 2018-10-16 06:41:22 --> Router Class Initialized
INFO - 2018-10-16 06:41:22 --> Output Class Initialized
INFO - 2018-10-16 06:41:22 --> Security Class Initialized
DEBUG - 2018-10-16 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:41:22 --> CSRF cookie sent
INFO - 2018-10-16 06:41:22 --> Input Class Initialized
INFO - 2018-10-16 06:41:22 --> Language Class Initialized
INFO - 2018-10-16 06:41:22 --> Loader Class Initialized
INFO - 2018-10-16 06:41:22 --> Helper loaded: url_helper
INFO - 2018-10-16 06:41:22 --> Helper loaded: form_helper
INFO - 2018-10-16 06:41:22 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:41:22 --> User Agent Class Initialized
INFO - 2018-10-16 06:41:22 --> Controller Class Initialized
INFO - 2018-10-16 06:41:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:41:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:41:22 --> Pixel_Model class loaded
INFO - 2018-10-16 06:41:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-16 06:41:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:41:22 --> Final output sent to browser
DEBUG - 2018-10-16 06:41:22 --> Total execution time: 0.0450
INFO - 2018-10-16 06:41:25 --> Config Class Initialized
INFO - 2018-10-16 06:41:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:41:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:41:25 --> Utf8 Class Initialized
INFO - 2018-10-16 06:41:25 --> URI Class Initialized
INFO - 2018-10-16 06:41:25 --> Router Class Initialized
INFO - 2018-10-16 06:41:25 --> Output Class Initialized
INFO - 2018-10-16 06:41:25 --> Security Class Initialized
DEBUG - 2018-10-16 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:41:25 --> CSRF cookie sent
INFO - 2018-10-16 06:41:25 --> Input Class Initialized
INFO - 2018-10-16 06:41:25 --> Language Class Initialized
INFO - 2018-10-16 06:41:25 --> Loader Class Initialized
INFO - 2018-10-16 06:41:25 --> Helper loaded: url_helper
INFO - 2018-10-16 06:41:25 --> Helper loaded: form_helper
INFO - 2018-10-16 06:41:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:41:25 --> User Agent Class Initialized
INFO - 2018-10-16 06:41:25 --> Controller Class Initialized
INFO - 2018-10-16 06:41:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:41:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:41:25 --> Pixel_Model class loaded
INFO - 2018-10-16 06:41:25 --> Database Driver Class Initialized
INFO - 2018-10-16 06:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-16 06:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:41:25 --> Final output sent to browser
DEBUG - 2018-10-16 06:41:25 --> Total execution time: 0.0427
INFO - 2018-10-16 06:46:04 --> Config Class Initialized
INFO - 2018-10-16 06:46:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:04 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:04 --> URI Class Initialized
INFO - 2018-10-16 06:46:04 --> Router Class Initialized
INFO - 2018-10-16 06:46:04 --> Output Class Initialized
INFO - 2018-10-16 06:46:04 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:04 --> CSRF cookie sent
INFO - 2018-10-16 06:46:04 --> Input Class Initialized
INFO - 2018-10-16 06:46:04 --> Language Class Initialized
INFO - 2018-10-16 06:46:04 --> Loader Class Initialized
INFO - 2018-10-16 06:46:04 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:04 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:04 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:04 --> Controller Class Initialized
INFO - 2018-10-16 06:46:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:46:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:46:04 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 06:46:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:46:04 --> Final output sent to browser
DEBUG - 2018-10-16 06:46:04 --> Total execution time: 0.0319
INFO - 2018-10-16 06:46:08 --> Config Class Initialized
INFO - 2018-10-16 06:46:08 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:08 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:08 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:08 --> URI Class Initialized
INFO - 2018-10-16 06:46:08 --> Router Class Initialized
INFO - 2018-10-16 06:46:08 --> Output Class Initialized
INFO - 2018-10-16 06:46:08 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:08 --> CSRF cookie sent
INFO - 2018-10-16 06:46:08 --> Input Class Initialized
INFO - 2018-10-16 06:46:08 --> Language Class Initialized
INFO - 2018-10-16 06:46:08 --> Loader Class Initialized
INFO - 2018-10-16 06:46:08 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:08 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:08 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:08 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:08 --> Controller Class Initialized
INFO - 2018-10-16 06:46:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:46:08 --> Pixel_Model class loaded
INFO - 2018-10-16 06:46:08 --> Database Driver Class Initialized
INFO - 2018-10-16 06:46:08 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:46:08 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:46:08 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:46:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:46:08 --> Final output sent to browser
DEBUG - 2018-10-16 06:46:08 --> Total execution time: 0.0403
INFO - 2018-10-16 06:46:12 --> Config Class Initialized
INFO - 2018-10-16 06:46:12 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:12 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:12 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:12 --> URI Class Initialized
INFO - 2018-10-16 06:46:12 --> Router Class Initialized
INFO - 2018-10-16 06:46:12 --> Output Class Initialized
INFO - 2018-10-16 06:46:12 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:12 --> CSRF cookie sent
INFO - 2018-10-16 06:46:12 --> CSRF token verified
INFO - 2018-10-16 06:46:12 --> Input Class Initialized
INFO - 2018-10-16 06:46:12 --> Language Class Initialized
INFO - 2018-10-16 06:46:12 --> Loader Class Initialized
INFO - 2018-10-16 06:46:12 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:12 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:12 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:12 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:12 --> Controller Class Initialized
INFO - 2018-10-16 06:46:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:46:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:12 --> Form Validation Class Initialized
INFO - 2018-10-16 06:46:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:46:13 --> Pixel_Model class loaded
INFO - 2018-10-16 06:46:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:46:13 --> Model "RegistrationModel" initialized
INFO - 2018-10-16 06:46:13 --> Config Class Initialized
INFO - 2018-10-16 06:46:13 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:13 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:13 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:13 --> URI Class Initialized
INFO - 2018-10-16 06:46:13 --> Router Class Initialized
INFO - 2018-10-16 06:46:13 --> Output Class Initialized
INFO - 2018-10-16 06:46:13 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:13 --> CSRF cookie sent
INFO - 2018-10-16 06:46:13 --> Input Class Initialized
INFO - 2018-10-16 06:46:13 --> Language Class Initialized
INFO - 2018-10-16 06:46:13 --> Loader Class Initialized
INFO - 2018-10-16 06:46:13 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:13 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:13 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:13 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:13 --> Controller Class Initialized
INFO - 2018-10-16 06:46:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:46:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-16 06:46:13 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-10-16 06:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:46:13 --> Final output sent to browser
DEBUG - 2018-10-16 06:46:13 --> Total execution time: 0.0270
INFO - 2018-10-16 06:46:18 --> Config Class Initialized
INFO - 2018-10-16 06:46:18 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:18 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:18 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:18 --> URI Class Initialized
INFO - 2018-10-16 06:46:18 --> Router Class Initialized
INFO - 2018-10-16 06:46:18 --> Output Class Initialized
INFO - 2018-10-16 06:46:18 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:18 --> CSRF cookie sent
INFO - 2018-10-16 06:46:18 --> Input Class Initialized
INFO - 2018-10-16 06:46:18 --> Language Class Initialized
INFO - 2018-10-16 06:46:18 --> Loader Class Initialized
INFO - 2018-10-16 06:46:18 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:18 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:18 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:18 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:18 --> Controller Class Initialized
INFO - 2018-10-16 06:46:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:46:18 --> Pixel_Model class loaded
INFO - 2018-10-16 06:46:18 --> Database Driver Class Initialized
INFO - 2018-10-16 06:46:18 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:46:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:46:18 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:46:18 --> Final output sent to browser
DEBUG - 2018-10-16 06:46:18 --> Total execution time: 0.0450
INFO - 2018-10-16 06:46:32 --> Config Class Initialized
INFO - 2018-10-16 06:46:32 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:46:32 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:46:32 --> Utf8 Class Initialized
INFO - 2018-10-16 06:46:32 --> URI Class Initialized
INFO - 2018-10-16 06:46:32 --> Router Class Initialized
INFO - 2018-10-16 06:46:32 --> Output Class Initialized
INFO - 2018-10-16 06:46:32 --> Security Class Initialized
DEBUG - 2018-10-16 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:46:32 --> CSRF cookie sent
INFO - 2018-10-16 06:46:32 --> CSRF token verified
INFO - 2018-10-16 06:46:32 --> Input Class Initialized
INFO - 2018-10-16 06:46:32 --> Language Class Initialized
INFO - 2018-10-16 06:46:32 --> Loader Class Initialized
INFO - 2018-10-16 06:46:32 --> Helper loaded: url_helper
INFO - 2018-10-16 06:46:32 --> Helper loaded: form_helper
INFO - 2018-10-16 06:46:32 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:46:32 --> User Agent Class Initialized
INFO - 2018-10-16 06:46:32 --> Controller Class Initialized
INFO - 2018-10-16 06:46:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:46:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:46:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:46:32 --> Form Validation Class Initialized
INFO - 2018-10-16 06:46:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:46:32 --> Pixel_Model class loaded
INFO - 2018-10-16 06:46:32 --> Database Driver Class Initialized
INFO - 2018-10-16 06:46:32 --> Model "RegistrationModel" initialized
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-10-16 06:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:46:32 --> Final output sent to browser
DEBUG - 2018-10-16 06:46:32 --> Total execution time: 0.2193
INFO - 2018-10-16 06:47:23 --> Config Class Initialized
INFO - 2018-10-16 06:47:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:23 --> URI Class Initialized
INFO - 2018-10-16 06:47:23 --> Router Class Initialized
INFO - 2018-10-16 06:47:23 --> Output Class Initialized
INFO - 2018-10-16 06:47:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:23 --> CSRF cookie sent
INFO - 2018-10-16 06:47:23 --> Input Class Initialized
INFO - 2018-10-16 06:47:23 --> Language Class Initialized
INFO - 2018-10-16 06:47:23 --> Loader Class Initialized
INFO - 2018-10-16 06:47:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:23 --> Controller Class Initialized
INFO - 2018-10-16 06:47:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:47:23 --> Pixel_Model class loaded
INFO - 2018-10-16 06:47:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:47:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:47:23 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:47:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:47:23 --> Final output sent to browser
DEBUG - 2018-10-16 06:47:23 --> Total execution time: 0.0356
INFO - 2018-10-16 06:47:25 --> Config Class Initialized
INFO - 2018-10-16 06:47:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:25 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:25 --> URI Class Initialized
INFO - 2018-10-16 06:47:25 --> Router Class Initialized
INFO - 2018-10-16 06:47:25 --> Output Class Initialized
INFO - 2018-10-16 06:47:25 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:25 --> CSRF cookie sent
INFO - 2018-10-16 06:47:25 --> Input Class Initialized
INFO - 2018-10-16 06:47:25 --> Language Class Initialized
INFO - 2018-10-16 06:47:25 --> Loader Class Initialized
INFO - 2018-10-16 06:47:25 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:25 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:25 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:25 --> Controller Class Initialized
INFO - 2018-10-16 06:47:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:47:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:47:25 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 06:47:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:47:25 --> Final output sent to browser
DEBUG - 2018-10-16 06:47:25 --> Total execution time: 0.0377
INFO - 2018-10-16 06:47:28 --> Config Class Initialized
INFO - 2018-10-16 06:47:28 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:28 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:28 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:28 --> URI Class Initialized
DEBUG - 2018-10-16 06:47:28 --> No URI present. Default controller set.
INFO - 2018-10-16 06:47:28 --> Router Class Initialized
INFO - 2018-10-16 06:47:28 --> Output Class Initialized
INFO - 2018-10-16 06:47:28 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:28 --> CSRF cookie sent
INFO - 2018-10-16 06:47:28 --> Input Class Initialized
INFO - 2018-10-16 06:47:28 --> Language Class Initialized
INFO - 2018-10-16 06:47:28 --> Loader Class Initialized
INFO - 2018-10-16 06:47:28 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:28 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:28 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:28 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:28 --> Controller Class Initialized
INFO - 2018-10-16 06:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:47:28 --> Pixel_Model class loaded
INFO - 2018-10-16 06:47:28 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 06:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:47:28 --> Final output sent to browser
DEBUG - 2018-10-16 06:47:28 --> Total execution time: 0.0391
INFO - 2018-10-16 06:47:31 --> Config Class Initialized
INFO - 2018-10-16 06:47:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:31 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:31 --> URI Class Initialized
INFO - 2018-10-16 06:47:31 --> Router Class Initialized
INFO - 2018-10-16 06:47:31 --> Output Class Initialized
INFO - 2018-10-16 06:47:31 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:31 --> CSRF cookie sent
INFO - 2018-10-16 06:47:31 --> Input Class Initialized
INFO - 2018-10-16 06:47:31 --> Language Class Initialized
INFO - 2018-10-16 06:47:31 --> Loader Class Initialized
INFO - 2018-10-16 06:47:31 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:31 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:31 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:31 --> Controller Class Initialized
INFO - 2018-10-16 06:47:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:47:31 --> Pixel_Model class loaded
INFO - 2018-10-16 06:47:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:47:31 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 06:47:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:47:31 --> Final output sent to browser
DEBUG - 2018-10-16 06:47:31 --> Total execution time: 0.0441
INFO - 2018-10-16 06:47:36 --> Config Class Initialized
INFO - 2018-10-16 06:47:36 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:36 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:36 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:36 --> URI Class Initialized
INFO - 2018-10-16 06:47:36 --> Router Class Initialized
INFO - 2018-10-16 06:47:36 --> Output Class Initialized
INFO - 2018-10-16 06:47:36 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:36 --> CSRF cookie sent
INFO - 2018-10-16 06:47:36 --> Input Class Initialized
INFO - 2018-10-16 06:47:36 --> Language Class Initialized
INFO - 2018-10-16 06:47:36 --> Loader Class Initialized
INFO - 2018-10-16 06:47:36 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:36 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:36 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:36 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:36 --> Controller Class Initialized
INFO - 2018-10-16 06:47:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:47:36 --> Pixel_Model class loaded
INFO - 2018-10-16 06:47:36 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:36 --> Model "MyAccountModel" initialized
ERROR - 2018-10-16 06:47:36 --> 404 Page Not Found: 
INFO - 2018-10-16 06:47:38 --> Config Class Initialized
INFO - 2018-10-16 06:47:38 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:47:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:47:38 --> Utf8 Class Initialized
INFO - 2018-10-16 06:47:38 --> URI Class Initialized
INFO - 2018-10-16 06:47:38 --> Router Class Initialized
INFO - 2018-10-16 06:47:38 --> Output Class Initialized
INFO - 2018-10-16 06:47:38 --> Security Class Initialized
DEBUG - 2018-10-16 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:47:38 --> CSRF cookie sent
INFO - 2018-10-16 06:47:38 --> Input Class Initialized
INFO - 2018-10-16 06:47:38 --> Language Class Initialized
INFO - 2018-10-16 06:47:38 --> Loader Class Initialized
INFO - 2018-10-16 06:47:38 --> Helper loaded: url_helper
INFO - 2018-10-16 06:47:38 --> Helper loaded: form_helper
INFO - 2018-10-16 06:47:38 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:47:38 --> User Agent Class Initialized
INFO - 2018-10-16 06:47:38 --> Controller Class Initialized
INFO - 2018-10-16 06:47:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:47:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:47:38 --> Pixel_Model class loaded
INFO - 2018-10-16 06:47:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:47:38 --> Database Driver Class Initialized
INFO - 2018-10-16 06:47:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 06:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:47:38 --> Final output sent to browser
DEBUG - 2018-10-16 06:47:38 --> Total execution time: 0.0483
INFO - 2018-10-16 06:48:46 --> Config Class Initialized
INFO - 2018-10-16 06:48:46 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:48:46 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:48:46 --> Utf8 Class Initialized
INFO - 2018-10-16 06:48:46 --> URI Class Initialized
INFO - 2018-10-16 06:48:46 --> Router Class Initialized
INFO - 2018-10-16 06:48:46 --> Output Class Initialized
INFO - 2018-10-16 06:48:46 --> Security Class Initialized
DEBUG - 2018-10-16 06:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:48:46 --> CSRF cookie sent
INFO - 2018-10-16 06:48:46 --> Input Class Initialized
INFO - 2018-10-16 06:48:46 --> Language Class Initialized
INFO - 2018-10-16 06:48:46 --> Loader Class Initialized
INFO - 2018-10-16 06:48:46 --> Helper loaded: url_helper
INFO - 2018-10-16 06:48:46 --> Helper loaded: form_helper
INFO - 2018-10-16 06:48:46 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:48:46 --> User Agent Class Initialized
INFO - 2018-10-16 06:48:46 --> Controller Class Initialized
INFO - 2018-10-16 06:48:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:48:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:48:46 --> Pixel_Model class loaded
INFO - 2018-10-16 06:48:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:48:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-16 06:48:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:48:47 --> Final output sent to browser
DEBUG - 2018-10-16 06:48:47 --> Total execution time: 0.0620
INFO - 2018-10-16 06:49:54 --> Config Class Initialized
INFO - 2018-10-16 06:49:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:49:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:49:54 --> Utf8 Class Initialized
INFO - 2018-10-16 06:49:54 --> URI Class Initialized
INFO - 2018-10-16 06:49:54 --> Router Class Initialized
INFO - 2018-10-16 06:49:54 --> Output Class Initialized
INFO - 2018-10-16 06:49:54 --> Security Class Initialized
DEBUG - 2018-10-16 06:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:49:54 --> CSRF cookie sent
INFO - 2018-10-16 06:49:54 --> Input Class Initialized
INFO - 2018-10-16 06:49:54 --> Language Class Initialized
INFO - 2018-10-16 06:49:54 --> Loader Class Initialized
INFO - 2018-10-16 06:49:54 --> Helper loaded: url_helper
INFO - 2018-10-16 06:49:54 --> Helper loaded: form_helper
INFO - 2018-10-16 06:49:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:49:54 --> User Agent Class Initialized
INFO - 2018-10-16 06:49:54 --> Controller Class Initialized
INFO - 2018-10-16 06:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:49:54 --> Pixel_Model class loaded
INFO - 2018-10-16 06:49:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:49:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:49:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:49:54 --> Final output sent to browser
DEBUG - 2018-10-16 06:49:54 --> Total execution time: 0.0409
INFO - 2018-10-16 06:49:58 --> Config Class Initialized
INFO - 2018-10-16 06:49:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:49:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:49:58 --> Utf8 Class Initialized
INFO - 2018-10-16 06:49:58 --> URI Class Initialized
DEBUG - 2018-10-16 06:49:58 --> No URI present. Default controller set.
INFO - 2018-10-16 06:49:58 --> Router Class Initialized
INFO - 2018-10-16 06:49:58 --> Output Class Initialized
INFO - 2018-10-16 06:49:58 --> Security Class Initialized
DEBUG - 2018-10-16 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:49:58 --> CSRF cookie sent
INFO - 2018-10-16 06:49:58 --> Input Class Initialized
INFO - 2018-10-16 06:49:58 --> Language Class Initialized
INFO - 2018-10-16 06:49:58 --> Loader Class Initialized
INFO - 2018-10-16 06:49:58 --> Helper loaded: url_helper
INFO - 2018-10-16 06:49:58 --> Helper loaded: form_helper
INFO - 2018-10-16 06:49:58 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:49:58 --> User Agent Class Initialized
INFO - 2018-10-16 06:49:58 --> Controller Class Initialized
INFO - 2018-10-16 06:49:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:49:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:49:58 --> Pixel_Model class loaded
INFO - 2018-10-16 06:49:58 --> Database Driver Class Initialized
INFO - 2018-10-16 06:49:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:49:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:49:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:49:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 06:49:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:49:58 --> Final output sent to browser
DEBUG - 2018-10-16 06:49:58 --> Total execution time: 0.0405
INFO - 2018-10-16 06:50:53 --> Config Class Initialized
INFO - 2018-10-16 06:50:53 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:50:53 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:50:53 --> Utf8 Class Initialized
INFO - 2018-10-16 06:50:53 --> URI Class Initialized
INFO - 2018-10-16 06:50:53 --> Router Class Initialized
INFO - 2018-10-16 06:50:53 --> Output Class Initialized
INFO - 2018-10-16 06:50:53 --> Security Class Initialized
DEBUG - 2018-10-16 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:50:53 --> CSRF cookie sent
INFO - 2018-10-16 06:50:53 --> CSRF token verified
INFO - 2018-10-16 06:50:53 --> Input Class Initialized
INFO - 2018-10-16 06:50:53 --> Language Class Initialized
INFO - 2018-10-16 06:50:53 --> Loader Class Initialized
INFO - 2018-10-16 06:50:53 --> Helper loaded: url_helper
INFO - 2018-10-16 06:50:53 --> Helper loaded: form_helper
INFO - 2018-10-16 06:50:53 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:50:53 --> User Agent Class Initialized
INFO - 2018-10-16 06:50:53 --> Controller Class Initialized
INFO - 2018-10-16 06:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:50:53 --> Pixel_Model class loaded
INFO - 2018-10-16 06:50:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:50:53 --> Form Validation Class Initialized
INFO - 2018-10-16 06:50:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:50:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:50:53 --> Config Class Initialized
INFO - 2018-10-16 06:50:53 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:50:53 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:50:53 --> Utf8 Class Initialized
INFO - 2018-10-16 06:50:53 --> URI Class Initialized
INFO - 2018-10-16 06:50:53 --> Router Class Initialized
INFO - 2018-10-16 06:50:53 --> Output Class Initialized
INFO - 2018-10-16 06:50:53 --> Security Class Initialized
DEBUG - 2018-10-16 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:50:53 --> CSRF cookie sent
INFO - 2018-10-16 06:50:53 --> Input Class Initialized
INFO - 2018-10-16 06:50:53 --> Language Class Initialized
INFO - 2018-10-16 06:50:53 --> Loader Class Initialized
INFO - 2018-10-16 06:50:53 --> Helper loaded: url_helper
INFO - 2018-10-16 06:50:53 --> Helper loaded: form_helper
INFO - 2018-10-16 06:50:53 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:50:53 --> User Agent Class Initialized
INFO - 2018-10-16 06:50:53 --> Controller Class Initialized
INFO - 2018-10-16 06:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:50:53 --> Pixel_Model class loaded
INFO - 2018-10-16 06:50:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:50:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:50:53 --> Final output sent to browser
DEBUG - 2018-10-16 06:50:53 --> Total execution time: 0.0475
INFO - 2018-10-16 06:54:59 --> Config Class Initialized
INFO - 2018-10-16 06:54:59 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:54:59 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:54:59 --> Utf8 Class Initialized
INFO - 2018-10-16 06:54:59 --> URI Class Initialized
INFO - 2018-10-16 06:54:59 --> Router Class Initialized
INFO - 2018-10-16 06:54:59 --> Output Class Initialized
INFO - 2018-10-16 06:54:59 --> Security Class Initialized
DEBUG - 2018-10-16 06:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:54:59 --> CSRF cookie sent
INFO - 2018-10-16 06:54:59 --> Input Class Initialized
INFO - 2018-10-16 06:54:59 --> Language Class Initialized
INFO - 2018-10-16 06:54:59 --> Loader Class Initialized
INFO - 2018-10-16 06:54:59 --> Helper loaded: url_helper
INFO - 2018-10-16 06:54:59 --> Helper loaded: form_helper
INFO - 2018-10-16 06:54:59 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:54:59 --> User Agent Class Initialized
INFO - 2018-10-16 06:54:59 --> Controller Class Initialized
INFO - 2018-10-16 06:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:54:59 --> Pixel_Model class loaded
INFO - 2018-10-16 06:54:59 --> Database Driver Class Initialized
INFO - 2018-10-16 06:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:54:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:54:59 --> Final output sent to browser
DEBUG - 2018-10-16 06:54:59 --> Total execution time: 0.0508
INFO - 2018-10-16 06:55:00 --> Config Class Initialized
INFO - 2018-10-16 06:55:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:00 --> URI Class Initialized
INFO - 2018-10-16 06:55:00 --> Router Class Initialized
INFO - 2018-10-16 06:55:00 --> Output Class Initialized
INFO - 2018-10-16 06:55:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:00 --> CSRF cookie sent
INFO - 2018-10-16 06:55:00 --> CSRF token verified
INFO - 2018-10-16 06:55:00 --> Input Class Initialized
INFO - 2018-10-16 06:55:00 --> Language Class Initialized
INFO - 2018-10-16 06:55:00 --> Loader Class Initialized
INFO - 2018-10-16 06:55:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:00 --> Controller Class Initialized
INFO - 2018-10-16 06:55:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:00 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:00 --> Config Class Initialized
INFO - 2018-10-16 06:55:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:00 --> URI Class Initialized
INFO - 2018-10-16 06:55:00 --> Router Class Initialized
INFO - 2018-10-16 06:55:00 --> Output Class Initialized
INFO - 2018-10-16 06:55:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:00 --> CSRF cookie sent
INFO - 2018-10-16 06:55:00 --> Input Class Initialized
INFO - 2018-10-16 06:55:00 --> Language Class Initialized
INFO - 2018-10-16 06:55:00 --> Loader Class Initialized
INFO - 2018-10-16 06:55:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:00 --> Controller Class Initialized
INFO - 2018-10-16 06:55:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:55:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:00 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:00 --> Total execution time: 0.0468
INFO - 2018-10-16 06:55:06 --> Config Class Initialized
INFO - 2018-10-16 06:55:06 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:06 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:06 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:06 --> URI Class Initialized
INFO - 2018-10-16 06:55:06 --> Router Class Initialized
INFO - 2018-10-16 06:55:06 --> Output Class Initialized
INFO - 2018-10-16 06:55:06 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:06 --> CSRF cookie sent
INFO - 2018-10-16 06:55:06 --> CSRF token verified
INFO - 2018-10-16 06:55:06 --> Input Class Initialized
INFO - 2018-10-16 06:55:06 --> Language Class Initialized
INFO - 2018-10-16 06:55:06 --> Loader Class Initialized
INFO - 2018-10-16 06:55:06 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:06 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:06 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:06 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:06 --> Controller Class Initialized
INFO - 2018-10-16 06:55:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:06 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:06 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:06 --> Config Class Initialized
INFO - 2018-10-16 06:55:06 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:06 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:06 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:06 --> URI Class Initialized
INFO - 2018-10-16 06:55:06 --> Router Class Initialized
INFO - 2018-10-16 06:55:06 --> Output Class Initialized
INFO - 2018-10-16 06:55:06 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:06 --> CSRF cookie sent
INFO - 2018-10-16 06:55:06 --> Input Class Initialized
INFO - 2018-10-16 06:55:06 --> Language Class Initialized
INFO - 2018-10-16 06:55:06 --> Loader Class Initialized
INFO - 2018-10-16 06:55:06 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:06 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:06 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:06 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:06 --> Controller Class Initialized
INFO - 2018-10-16 06:55:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:06 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:06 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:06 --> Total execution time: 0.0465
INFO - 2018-10-16 06:55:07 --> Config Class Initialized
INFO - 2018-10-16 06:55:07 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:07 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:07 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:07 --> URI Class Initialized
INFO - 2018-10-16 06:55:07 --> Router Class Initialized
INFO - 2018-10-16 06:55:07 --> Output Class Initialized
INFO - 2018-10-16 06:55:07 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:07 --> CSRF cookie sent
INFO - 2018-10-16 06:55:07 --> CSRF token verified
INFO - 2018-10-16 06:55:07 --> Input Class Initialized
INFO - 2018-10-16 06:55:07 --> Language Class Initialized
INFO - 2018-10-16 06:55:07 --> Loader Class Initialized
INFO - 2018-10-16 06:55:07 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:07 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:07 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:07 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:07 --> Controller Class Initialized
INFO - 2018-10-16 06:55:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:07 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:07 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:07 --> Config Class Initialized
INFO - 2018-10-16 06:55:07 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:07 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:07 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:07 --> URI Class Initialized
INFO - 2018-10-16 06:55:07 --> Router Class Initialized
INFO - 2018-10-16 06:55:07 --> Output Class Initialized
INFO - 2018-10-16 06:55:07 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:07 --> CSRF cookie sent
INFO - 2018-10-16 06:55:07 --> Input Class Initialized
INFO - 2018-10-16 06:55:07 --> Language Class Initialized
INFO - 2018-10-16 06:55:07 --> Loader Class Initialized
INFO - 2018-10-16 06:55:07 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:07 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:07 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:07 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:07 --> Controller Class Initialized
INFO - 2018-10-16 06:55:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:07 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 06:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:07 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:07 --> Total execution time: 0.0463
INFO - 2018-10-16 06:55:08 --> Config Class Initialized
INFO - 2018-10-16 06:55:08 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:08 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:08 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:08 --> URI Class Initialized
INFO - 2018-10-16 06:55:08 --> Router Class Initialized
INFO - 2018-10-16 06:55:08 --> Output Class Initialized
INFO - 2018-10-16 06:55:08 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:08 --> CSRF cookie sent
INFO - 2018-10-16 06:55:08 --> CSRF token verified
INFO - 2018-10-16 06:55:08 --> Input Class Initialized
INFO - 2018-10-16 06:55:08 --> Language Class Initialized
INFO - 2018-10-16 06:55:08 --> Loader Class Initialized
INFO - 2018-10-16 06:55:09 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:09 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:09 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:09 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:09 --> Controller Class Initialized
INFO - 2018-10-16 06:55:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:09 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:09 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:09 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:09 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:09 --> Config Class Initialized
INFO - 2018-10-16 06:55:09 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:09 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:09 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:09 --> URI Class Initialized
INFO - 2018-10-16 06:55:09 --> Router Class Initialized
INFO - 2018-10-16 06:55:09 --> Output Class Initialized
INFO - 2018-10-16 06:55:09 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:09 --> CSRF cookie sent
INFO - 2018-10-16 06:55:09 --> Input Class Initialized
INFO - 2018-10-16 06:55:09 --> Language Class Initialized
INFO - 2018-10-16 06:55:09 --> Loader Class Initialized
INFO - 2018-10-16 06:55:09 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:09 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:09 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:09 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:09 --> Controller Class Initialized
INFO - 2018-10-16 06:55:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:09 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:09 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:09 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 06:55:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:09 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:09 --> Total execution time: 0.0442
INFO - 2018-10-16 06:55:10 --> Config Class Initialized
INFO - 2018-10-16 06:55:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:10 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:10 --> URI Class Initialized
INFO - 2018-10-16 06:55:10 --> Router Class Initialized
INFO - 2018-10-16 06:55:10 --> Output Class Initialized
INFO - 2018-10-16 06:55:10 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:10 --> CSRF cookie sent
INFO - 2018-10-16 06:55:10 --> CSRF token verified
INFO - 2018-10-16 06:55:10 --> Input Class Initialized
INFO - 2018-10-16 06:55:10 --> Language Class Initialized
INFO - 2018-10-16 06:55:10 --> Loader Class Initialized
INFO - 2018-10-16 06:55:10 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:10 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:10 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:10 --> Controller Class Initialized
INFO - 2018-10-16 06:55:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:10 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:10 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:11 --> Config Class Initialized
INFO - 2018-10-16 06:55:11 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:11 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:11 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:11 --> URI Class Initialized
INFO - 2018-10-16 06:55:11 --> Router Class Initialized
INFO - 2018-10-16 06:55:11 --> Output Class Initialized
INFO - 2018-10-16 06:55:11 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:11 --> CSRF cookie sent
INFO - 2018-10-16 06:55:11 --> Input Class Initialized
INFO - 2018-10-16 06:55:11 --> Language Class Initialized
INFO - 2018-10-16 06:55:11 --> Loader Class Initialized
INFO - 2018-10-16 06:55:11 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:11 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:11 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:11 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:11 --> Controller Class Initialized
INFO - 2018-10-16 06:55:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:11 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:55:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:11 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:11 --> Total execution time: 0.0487
INFO - 2018-10-16 06:55:12 --> Config Class Initialized
INFO - 2018-10-16 06:55:12 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:12 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:12 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:12 --> URI Class Initialized
INFO - 2018-10-16 06:55:12 --> Router Class Initialized
INFO - 2018-10-16 06:55:12 --> Output Class Initialized
INFO - 2018-10-16 06:55:12 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:12 --> CSRF cookie sent
INFO - 2018-10-16 06:55:12 --> CSRF token verified
INFO - 2018-10-16 06:55:12 --> Input Class Initialized
INFO - 2018-10-16 06:55:12 --> Language Class Initialized
INFO - 2018-10-16 06:55:12 --> Loader Class Initialized
INFO - 2018-10-16 06:55:12 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:12 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:12 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:12 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:12 --> Controller Class Initialized
INFO - 2018-10-16 06:55:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:12 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:12 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:12 --> Config Class Initialized
INFO - 2018-10-16 06:55:12 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:12 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:12 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:12 --> URI Class Initialized
INFO - 2018-10-16 06:55:12 --> Router Class Initialized
INFO - 2018-10-16 06:55:12 --> Output Class Initialized
INFO - 2018-10-16 06:55:12 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:12 --> CSRF cookie sent
INFO - 2018-10-16 06:55:12 --> Input Class Initialized
INFO - 2018-10-16 06:55:12 --> Language Class Initialized
INFO - 2018-10-16 06:55:12 --> Loader Class Initialized
INFO - 2018-10-16 06:55:12 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:12 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:12 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:12 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:12 --> Controller Class Initialized
INFO - 2018-10-16 06:55:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:12 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:12 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:55:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:12 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:12 --> Total execution time: 0.0424
INFO - 2018-10-16 06:55:14 --> Config Class Initialized
INFO - 2018-10-16 06:55:14 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:14 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:14 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:14 --> URI Class Initialized
INFO - 2018-10-16 06:55:14 --> Router Class Initialized
INFO - 2018-10-16 06:55:14 --> Output Class Initialized
INFO - 2018-10-16 06:55:14 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:14 --> CSRF cookie sent
INFO - 2018-10-16 06:55:14 --> CSRF token verified
INFO - 2018-10-16 06:55:14 --> Input Class Initialized
INFO - 2018-10-16 06:55:14 --> Language Class Initialized
INFO - 2018-10-16 06:55:14 --> Loader Class Initialized
INFO - 2018-10-16 06:55:14 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:14 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:14 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:14 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:14 --> Controller Class Initialized
INFO - 2018-10-16 06:55:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:14 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:14 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:14 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:14 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:14 --> Config Class Initialized
INFO - 2018-10-16 06:55:14 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:14 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:14 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:14 --> URI Class Initialized
INFO - 2018-10-16 06:55:14 --> Router Class Initialized
INFO - 2018-10-16 06:55:14 --> Output Class Initialized
INFO - 2018-10-16 06:55:14 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:14 --> CSRF cookie sent
INFO - 2018-10-16 06:55:14 --> Input Class Initialized
INFO - 2018-10-16 06:55:14 --> Language Class Initialized
INFO - 2018-10-16 06:55:14 --> Loader Class Initialized
INFO - 2018-10-16 06:55:14 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:14 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:14 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:14 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:14 --> Controller Class Initialized
INFO - 2018-10-16 06:55:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:14 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:14 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:14 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-16 06:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:14 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:14 --> Total execution time: 0.0622
INFO - 2018-10-16 06:55:15 --> Config Class Initialized
INFO - 2018-10-16 06:55:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:15 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:15 --> URI Class Initialized
INFO - 2018-10-16 06:55:15 --> Router Class Initialized
INFO - 2018-10-16 06:55:15 --> Output Class Initialized
INFO - 2018-10-16 06:55:15 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:15 --> CSRF cookie sent
INFO - 2018-10-16 06:55:15 --> CSRF token verified
INFO - 2018-10-16 06:55:15 --> Input Class Initialized
INFO - 2018-10-16 06:55:15 --> Language Class Initialized
INFO - 2018-10-16 06:55:15 --> Loader Class Initialized
INFO - 2018-10-16 06:55:15 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:15 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:15 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:15 --> Controller Class Initialized
INFO - 2018-10-16 06:55:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:15 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:15 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:15 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:15 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:15 --> Config Class Initialized
INFO - 2018-10-16 06:55:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:15 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:15 --> URI Class Initialized
INFO - 2018-10-16 06:55:15 --> Router Class Initialized
INFO - 2018-10-16 06:55:15 --> Output Class Initialized
INFO - 2018-10-16 06:55:15 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:15 --> CSRF cookie sent
INFO - 2018-10-16 06:55:15 --> Input Class Initialized
INFO - 2018-10-16 06:55:15 --> Language Class Initialized
INFO - 2018-10-16 06:55:15 --> Loader Class Initialized
INFO - 2018-10-16 06:55:15 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:15 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:15 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:15 --> Controller Class Initialized
INFO - 2018-10-16 06:55:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:16 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:16 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-16 06:55:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:16 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:16 --> Total execution time: 0.0537
INFO - 2018-10-16 06:55:17 --> Config Class Initialized
INFO - 2018-10-16 06:55:17 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:17 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:17 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:17 --> URI Class Initialized
INFO - 2018-10-16 06:55:17 --> Router Class Initialized
INFO - 2018-10-16 06:55:17 --> Output Class Initialized
INFO - 2018-10-16 06:55:17 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:17 --> CSRF cookie sent
INFO - 2018-10-16 06:55:17 --> CSRF token verified
INFO - 2018-10-16 06:55:17 --> Input Class Initialized
INFO - 2018-10-16 06:55:17 --> Language Class Initialized
INFO - 2018-10-16 06:55:17 --> Loader Class Initialized
INFO - 2018-10-16 06:55:17 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:17 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:17 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:17 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:17 --> Controller Class Initialized
INFO - 2018-10-16 06:55:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:17 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:17 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:17 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:17 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:17 --> Config Class Initialized
INFO - 2018-10-16 06:55:17 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:17 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:17 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:17 --> URI Class Initialized
INFO - 2018-10-16 06:55:17 --> Router Class Initialized
INFO - 2018-10-16 06:55:17 --> Output Class Initialized
INFO - 2018-10-16 06:55:17 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:17 --> CSRF cookie sent
INFO - 2018-10-16 06:55:17 --> Input Class Initialized
INFO - 2018-10-16 06:55:17 --> Language Class Initialized
INFO - 2018-10-16 06:55:17 --> Loader Class Initialized
INFO - 2018-10-16 06:55:17 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:17 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:17 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:17 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:17 --> Controller Class Initialized
INFO - 2018-10-16 06:55:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:17 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:17 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:17 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-16 06:55:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:17 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:17 --> Total execution time: 0.0474
INFO - 2018-10-16 06:55:18 --> Config Class Initialized
INFO - 2018-10-16 06:55:18 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:18 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:18 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:18 --> URI Class Initialized
INFO - 2018-10-16 06:55:18 --> Router Class Initialized
INFO - 2018-10-16 06:55:18 --> Output Class Initialized
INFO - 2018-10-16 06:55:18 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:18 --> CSRF cookie sent
INFO - 2018-10-16 06:55:18 --> CSRF token verified
INFO - 2018-10-16 06:55:18 --> Input Class Initialized
INFO - 2018-10-16 06:55:18 --> Language Class Initialized
INFO - 2018-10-16 06:55:18 --> Loader Class Initialized
INFO - 2018-10-16 06:55:18 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:18 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:18 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:18 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:18 --> Controller Class Initialized
INFO - 2018-10-16 06:55:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:18 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:18 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:18 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:18 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:19 --> Config Class Initialized
INFO - 2018-10-16 06:55:19 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:19 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:19 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:19 --> URI Class Initialized
INFO - 2018-10-16 06:55:19 --> Router Class Initialized
INFO - 2018-10-16 06:55:19 --> Output Class Initialized
INFO - 2018-10-16 06:55:19 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:19 --> CSRF cookie sent
INFO - 2018-10-16 06:55:19 --> Input Class Initialized
INFO - 2018-10-16 06:55:19 --> Language Class Initialized
INFO - 2018-10-16 06:55:19 --> Loader Class Initialized
INFO - 2018-10-16 06:55:19 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:19 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:19 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:19 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:19 --> Controller Class Initialized
INFO - 2018-10-16 06:55:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:19 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:19 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:19 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-16 06:55:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:19 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:19 --> Total execution time: 0.0494
INFO - 2018-10-16 06:55:22 --> Config Class Initialized
INFO - 2018-10-16 06:55:22 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:22 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:22 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:22 --> URI Class Initialized
INFO - 2018-10-16 06:55:22 --> Router Class Initialized
INFO - 2018-10-16 06:55:22 --> Output Class Initialized
INFO - 2018-10-16 06:55:22 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:22 --> CSRF cookie sent
INFO - 2018-10-16 06:55:22 --> CSRF token verified
INFO - 2018-10-16 06:55:22 --> Input Class Initialized
INFO - 2018-10-16 06:55:22 --> Language Class Initialized
INFO - 2018-10-16 06:55:22 --> Loader Class Initialized
INFO - 2018-10-16 06:55:22 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:22 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:22 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:22 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:22 --> Controller Class Initialized
INFO - 2018-10-16 06:55:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:22 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:22 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:22 --> Config Class Initialized
INFO - 2018-10-16 06:55:22 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:22 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:22 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:22 --> URI Class Initialized
INFO - 2018-10-16 06:55:22 --> Router Class Initialized
INFO - 2018-10-16 06:55:22 --> Output Class Initialized
INFO - 2018-10-16 06:55:22 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:22 --> CSRF cookie sent
INFO - 2018-10-16 06:55:22 --> Input Class Initialized
INFO - 2018-10-16 06:55:22 --> Language Class Initialized
INFO - 2018-10-16 06:55:22 --> Loader Class Initialized
INFO - 2018-10-16 06:55:22 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:22 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:22 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:22 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:22 --> Controller Class Initialized
INFO - 2018-10-16 06:55:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:22 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:22 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-16 06:55:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:22 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:22 --> Total execution time: 0.0493
INFO - 2018-10-16 06:55:24 --> Config Class Initialized
INFO - 2018-10-16 06:55:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:24 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:24 --> URI Class Initialized
INFO - 2018-10-16 06:55:24 --> Router Class Initialized
INFO - 2018-10-16 06:55:24 --> Output Class Initialized
INFO - 2018-10-16 06:55:24 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:24 --> CSRF cookie sent
INFO - 2018-10-16 06:55:24 --> CSRF token verified
INFO - 2018-10-16 06:55:24 --> Input Class Initialized
INFO - 2018-10-16 06:55:24 --> Language Class Initialized
INFO - 2018-10-16 06:55:24 --> Loader Class Initialized
INFO - 2018-10-16 06:55:24 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:24 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:24 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:24 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:24 --> Controller Class Initialized
INFO - 2018-10-16 06:55:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:24 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:24 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:24 --> Config Class Initialized
INFO - 2018-10-16 06:55:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:24 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:24 --> URI Class Initialized
INFO - 2018-10-16 06:55:24 --> Router Class Initialized
INFO - 2018-10-16 06:55:24 --> Output Class Initialized
INFO - 2018-10-16 06:55:24 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:24 --> CSRF cookie sent
INFO - 2018-10-16 06:55:24 --> Input Class Initialized
INFO - 2018-10-16 06:55:24 --> Language Class Initialized
INFO - 2018-10-16 06:55:24 --> Loader Class Initialized
INFO - 2018-10-16 06:55:24 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:24 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:24 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:24 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:24 --> Controller Class Initialized
INFO - 2018-10-16 06:55:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:24 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:24 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-16 06:55:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:24 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:24 --> Total execution time: 0.0456
INFO - 2018-10-16 06:55:25 --> Config Class Initialized
INFO - 2018-10-16 06:55:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:25 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:25 --> URI Class Initialized
INFO - 2018-10-16 06:55:25 --> Router Class Initialized
INFO - 2018-10-16 06:55:25 --> Output Class Initialized
INFO - 2018-10-16 06:55:25 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:25 --> CSRF cookie sent
INFO - 2018-10-16 06:55:25 --> CSRF token verified
INFO - 2018-10-16 06:55:25 --> Input Class Initialized
INFO - 2018-10-16 06:55:25 --> Language Class Initialized
INFO - 2018-10-16 06:55:25 --> Loader Class Initialized
INFO - 2018-10-16 06:55:25 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:25 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:25 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:25 --> Controller Class Initialized
INFO - 2018-10-16 06:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:25 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:25 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:25 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:25 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:25 --> Config Class Initialized
INFO - 2018-10-16 06:55:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:25 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:25 --> URI Class Initialized
INFO - 2018-10-16 06:55:25 --> Router Class Initialized
INFO - 2018-10-16 06:55:25 --> Output Class Initialized
INFO - 2018-10-16 06:55:25 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:25 --> CSRF cookie sent
INFO - 2018-10-16 06:55:25 --> Input Class Initialized
INFO - 2018-10-16 06:55:25 --> Language Class Initialized
INFO - 2018-10-16 06:55:25 --> Loader Class Initialized
INFO - 2018-10-16 06:55:25 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:25 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:25 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:25 --> Controller Class Initialized
INFO - 2018-10-16 06:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:25 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:25 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:25 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-16 06:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:25 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:25 --> Total execution time: 0.0541
INFO - 2018-10-16 06:55:27 --> Config Class Initialized
INFO - 2018-10-16 06:55:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:27 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:27 --> URI Class Initialized
INFO - 2018-10-16 06:55:27 --> Router Class Initialized
INFO - 2018-10-16 06:55:27 --> Output Class Initialized
INFO - 2018-10-16 06:55:27 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:27 --> CSRF cookie sent
INFO - 2018-10-16 06:55:27 --> CSRF token verified
INFO - 2018-10-16 06:55:27 --> Input Class Initialized
INFO - 2018-10-16 06:55:27 --> Language Class Initialized
INFO - 2018-10-16 06:55:27 --> Loader Class Initialized
INFO - 2018-10-16 06:55:27 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:27 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:27 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:27 --> Controller Class Initialized
INFO - 2018-10-16 06:55:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:27 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:27 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:27 --> Config Class Initialized
INFO - 2018-10-16 06:55:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:27 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:27 --> URI Class Initialized
INFO - 2018-10-16 06:55:27 --> Router Class Initialized
INFO - 2018-10-16 06:55:27 --> Output Class Initialized
INFO - 2018-10-16 06:55:27 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:27 --> CSRF cookie sent
INFO - 2018-10-16 06:55:27 --> Input Class Initialized
INFO - 2018-10-16 06:55:27 --> Language Class Initialized
INFO - 2018-10-16 06:55:27 --> Loader Class Initialized
INFO - 2018-10-16 06:55:27 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:27 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:27 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:27 --> Controller Class Initialized
INFO - 2018-10-16 06:55:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:27 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 06:55:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:27 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:27 --> Total execution time: 0.0542
INFO - 2018-10-16 06:55:29 --> Config Class Initialized
INFO - 2018-10-16 06:55:29 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:29 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:29 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:29 --> URI Class Initialized
INFO - 2018-10-16 06:55:29 --> Router Class Initialized
INFO - 2018-10-16 06:55:29 --> Output Class Initialized
INFO - 2018-10-16 06:55:29 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:29 --> CSRF cookie sent
INFO - 2018-10-16 06:55:29 --> Input Class Initialized
INFO - 2018-10-16 06:55:29 --> Language Class Initialized
INFO - 2018-10-16 06:55:29 --> Loader Class Initialized
INFO - 2018-10-16 06:55:29 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:29 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:29 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:29 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:29 --> Controller Class Initialized
INFO - 2018-10-16 06:55:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:29 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:29 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:29 --> Config Class Initialized
INFO - 2018-10-16 06:55:29 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:29 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:29 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:29 --> URI Class Initialized
INFO - 2018-10-16 06:55:29 --> Router Class Initialized
INFO - 2018-10-16 06:55:29 --> Output Class Initialized
INFO - 2018-10-16 06:55:29 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:29 --> CSRF cookie sent
INFO - 2018-10-16 06:55:29 --> Input Class Initialized
INFO - 2018-10-16 06:55:29 --> Language Class Initialized
INFO - 2018-10-16 06:55:29 --> Loader Class Initialized
INFO - 2018-10-16 06:55:29 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:29 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:29 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:29 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:29 --> Controller Class Initialized
INFO - 2018-10-16 06:55:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:55:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:55:29 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 06:55:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:29 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:29 --> Total execution time: 0.0285
INFO - 2018-10-16 06:55:33 --> Config Class Initialized
INFO - 2018-10-16 06:55:33 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:33 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:33 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:33 --> URI Class Initialized
INFO - 2018-10-16 06:55:33 --> Router Class Initialized
INFO - 2018-10-16 06:55:33 --> Output Class Initialized
INFO - 2018-10-16 06:55:33 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:33 --> CSRF cookie sent
INFO - 2018-10-16 06:55:33 --> CSRF token verified
INFO - 2018-10-16 06:55:33 --> Input Class Initialized
INFO - 2018-10-16 06:55:33 --> Language Class Initialized
INFO - 2018-10-16 06:55:33 --> Loader Class Initialized
INFO - 2018-10-16 06:55:33 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:33 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:33 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:33 --> Controller Class Initialized
INFO - 2018-10-16 06:55:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:55:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:55:33 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:33 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:33 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:33 --> Model "AuthenticationModel" initialized
INFO - 2018-10-16 06:55:33 --> Config Class Initialized
INFO - 2018-10-16 06:55:33 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:33 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:33 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:33 --> URI Class Initialized
DEBUG - 2018-10-16 06:55:33 --> No URI present. Default controller set.
INFO - 2018-10-16 06:55:33 --> Router Class Initialized
INFO - 2018-10-16 06:55:33 --> Output Class Initialized
INFO - 2018-10-16 06:55:34 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:34 --> CSRF cookie sent
INFO - 2018-10-16 06:55:34 --> Input Class Initialized
INFO - 2018-10-16 06:55:34 --> Language Class Initialized
INFO - 2018-10-16 06:55:34 --> Loader Class Initialized
INFO - 2018-10-16 06:55:34 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:34 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:34 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:34 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:34 --> Controller Class Initialized
INFO - 2018-10-16 06:55:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:34 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:34 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 06:55:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:34 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:34 --> Total execution time: 0.0385
INFO - 2018-10-16 06:55:39 --> Config Class Initialized
INFO - 2018-10-16 06:55:39 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:39 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:39 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:39 --> URI Class Initialized
INFO - 2018-10-16 06:55:39 --> Router Class Initialized
INFO - 2018-10-16 06:55:39 --> Output Class Initialized
INFO - 2018-10-16 06:55:39 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:39 --> CSRF cookie sent
INFO - 2018-10-16 06:55:39 --> CSRF token verified
INFO - 2018-10-16 06:55:39 --> Input Class Initialized
INFO - 2018-10-16 06:55:39 --> Language Class Initialized
INFO - 2018-10-16 06:55:39 --> Loader Class Initialized
INFO - 2018-10-16 06:55:39 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:39 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:39 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:39 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:39 --> Controller Class Initialized
INFO - 2018-10-16 06:55:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:39 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:39 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:39 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:39 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:39 --> Config Class Initialized
INFO - 2018-10-16 06:55:39 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:39 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:39 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:39 --> URI Class Initialized
INFO - 2018-10-16 06:55:39 --> Router Class Initialized
INFO - 2018-10-16 06:55:39 --> Output Class Initialized
INFO - 2018-10-16 06:55:39 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:39 --> CSRF cookie sent
INFO - 2018-10-16 06:55:39 --> Input Class Initialized
INFO - 2018-10-16 06:55:39 --> Language Class Initialized
INFO - 2018-10-16 06:55:39 --> Loader Class Initialized
INFO - 2018-10-16 06:55:39 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:39 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:39 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:39 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:39 --> Controller Class Initialized
INFO - 2018-10-16 06:55:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:39 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:39 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:39 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:39 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:39 --> Total execution time: 0.0627
INFO - 2018-10-16 06:55:44 --> Config Class Initialized
INFO - 2018-10-16 06:55:44 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:44 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:44 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:44 --> URI Class Initialized
INFO - 2018-10-16 06:55:44 --> Router Class Initialized
INFO - 2018-10-16 06:55:44 --> Output Class Initialized
INFO - 2018-10-16 06:55:44 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:44 --> CSRF cookie sent
INFO - 2018-10-16 06:55:44 --> CSRF token verified
INFO - 2018-10-16 06:55:44 --> Input Class Initialized
INFO - 2018-10-16 06:55:44 --> Language Class Initialized
INFO - 2018-10-16 06:55:44 --> Loader Class Initialized
INFO - 2018-10-16 06:55:44 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:44 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:44 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:44 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:44 --> Controller Class Initialized
INFO - 2018-10-16 06:55:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:44 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:44 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:44 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:44 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:44 --> Config Class Initialized
INFO - 2018-10-16 06:55:44 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:44 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:44 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:44 --> URI Class Initialized
INFO - 2018-10-16 06:55:44 --> Router Class Initialized
INFO - 2018-10-16 06:55:44 --> Output Class Initialized
INFO - 2018-10-16 06:55:44 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:44 --> CSRF cookie sent
INFO - 2018-10-16 06:55:44 --> Input Class Initialized
INFO - 2018-10-16 06:55:44 --> Language Class Initialized
INFO - 2018-10-16 06:55:44 --> Loader Class Initialized
INFO - 2018-10-16 06:55:44 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:44 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:44 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:44 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:44 --> Controller Class Initialized
INFO - 2018-10-16 06:55:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:44 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:44 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:44 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:44 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:44 --> Total execution time: 0.0487
INFO - 2018-10-16 06:55:45 --> Config Class Initialized
INFO - 2018-10-16 06:55:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:45 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:45 --> URI Class Initialized
INFO - 2018-10-16 06:55:45 --> Router Class Initialized
INFO - 2018-10-16 06:55:45 --> Output Class Initialized
INFO - 2018-10-16 06:55:45 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:45 --> CSRF cookie sent
INFO - 2018-10-16 06:55:45 --> CSRF token verified
INFO - 2018-10-16 06:55:45 --> Input Class Initialized
INFO - 2018-10-16 06:55:45 --> Language Class Initialized
INFO - 2018-10-16 06:55:45 --> Loader Class Initialized
INFO - 2018-10-16 06:55:45 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:45 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:45 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:45 --> Controller Class Initialized
INFO - 2018-10-16 06:55:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:45 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:45 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:45 --> Config Class Initialized
INFO - 2018-10-16 06:55:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:45 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:45 --> URI Class Initialized
INFO - 2018-10-16 06:55:45 --> Router Class Initialized
INFO - 2018-10-16 06:55:45 --> Output Class Initialized
INFO - 2018-10-16 06:55:45 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:45 --> CSRF cookie sent
INFO - 2018-10-16 06:55:45 --> Input Class Initialized
INFO - 2018-10-16 06:55:45 --> Language Class Initialized
INFO - 2018-10-16 06:55:45 --> Loader Class Initialized
INFO - 2018-10-16 06:55:45 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:45 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:45 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:45 --> Controller Class Initialized
INFO - 2018-10-16 06:55:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:45 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:45 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 06:55:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:45 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:45 --> Total execution time: 0.0477
INFO - 2018-10-16 06:55:46 --> Config Class Initialized
INFO - 2018-10-16 06:55:46 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:46 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:46 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:46 --> URI Class Initialized
INFO - 2018-10-16 06:55:46 --> Router Class Initialized
INFO - 2018-10-16 06:55:46 --> Output Class Initialized
INFO - 2018-10-16 06:55:46 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:46 --> CSRF cookie sent
INFO - 2018-10-16 06:55:46 --> Input Class Initialized
INFO - 2018-10-16 06:55:46 --> Language Class Initialized
INFO - 2018-10-16 06:55:46 --> Loader Class Initialized
INFO - 2018-10-16 06:55:46 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:46 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:46 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:46 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:46 --> Controller Class Initialized
INFO - 2018-10-16 06:55:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:46 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:46 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:47 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:47 --> Total execution time: 0.0721
INFO - 2018-10-16 06:55:47 --> Config Class Initialized
INFO - 2018-10-16 06:55:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:47 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:47 --> URI Class Initialized
INFO - 2018-10-16 06:55:47 --> Router Class Initialized
INFO - 2018-10-16 06:55:47 --> Output Class Initialized
INFO - 2018-10-16 06:55:47 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:47 --> CSRF cookie sent
INFO - 2018-10-16 06:55:47 --> Input Class Initialized
INFO - 2018-10-16 06:55:47 --> Language Class Initialized
INFO - 2018-10-16 06:55:47 --> Loader Class Initialized
INFO - 2018-10-16 06:55:47 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:47 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:47 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:47 --> Controller Class Initialized
INFO - 2018-10-16 06:55:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:47 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:47 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 06:55:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:47 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:47 --> Total execution time: 0.0627
INFO - 2018-10-16 06:55:53 --> Config Class Initialized
INFO - 2018-10-16 06:55:53 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:53 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:53 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:53 --> URI Class Initialized
INFO - 2018-10-16 06:55:53 --> Router Class Initialized
INFO - 2018-10-16 06:55:53 --> Output Class Initialized
INFO - 2018-10-16 06:55:53 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:53 --> CSRF cookie sent
INFO - 2018-10-16 06:55:53 --> CSRF token verified
INFO - 2018-10-16 06:55:53 --> Input Class Initialized
INFO - 2018-10-16 06:55:53 --> Language Class Initialized
INFO - 2018-10-16 06:55:53 --> Loader Class Initialized
INFO - 2018-10-16 06:55:53 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:53 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:53 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:53 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:53 --> Controller Class Initialized
INFO - 2018-10-16 06:55:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:53 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:53 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:53 --> Config Class Initialized
INFO - 2018-10-16 06:55:53 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:53 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:53 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:53 --> URI Class Initialized
INFO - 2018-10-16 06:55:53 --> Router Class Initialized
INFO - 2018-10-16 06:55:53 --> Output Class Initialized
INFO - 2018-10-16 06:55:53 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:53 --> CSRF cookie sent
INFO - 2018-10-16 06:55:53 --> Input Class Initialized
INFO - 2018-10-16 06:55:53 --> Language Class Initialized
INFO - 2018-10-16 06:55:53 --> Loader Class Initialized
INFO - 2018-10-16 06:55:53 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:53 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:53 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:53 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:53 --> Controller Class Initialized
INFO - 2018-10-16 06:55:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:53 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:53 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 06:55:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:53 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:53 --> Total execution time: 0.0474
INFO - 2018-10-16 06:55:54 --> Config Class Initialized
INFO - 2018-10-16 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:54 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:54 --> URI Class Initialized
INFO - 2018-10-16 06:55:54 --> Router Class Initialized
INFO - 2018-10-16 06:55:54 --> Output Class Initialized
INFO - 2018-10-16 06:55:54 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:54 --> CSRF cookie sent
INFO - 2018-10-16 06:55:54 --> CSRF token verified
INFO - 2018-10-16 06:55:54 --> Input Class Initialized
INFO - 2018-10-16 06:55:54 --> Language Class Initialized
INFO - 2018-10-16 06:55:54 --> Loader Class Initialized
INFO - 2018-10-16 06:55:54 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:54 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:54 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:54 --> Controller Class Initialized
INFO - 2018-10-16 06:55:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:54 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:54 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:54 --> Config Class Initialized
INFO - 2018-10-16 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:54 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:54 --> URI Class Initialized
INFO - 2018-10-16 06:55:54 --> Router Class Initialized
INFO - 2018-10-16 06:55:54 --> Output Class Initialized
INFO - 2018-10-16 06:55:54 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:54 --> CSRF cookie sent
INFO - 2018-10-16 06:55:54 --> Input Class Initialized
INFO - 2018-10-16 06:55:54 --> Language Class Initialized
INFO - 2018-10-16 06:55:54 --> Loader Class Initialized
INFO - 2018-10-16 06:55:54 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:54 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:54 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:54 --> Controller Class Initialized
INFO - 2018-10-16 06:55:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:54 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:54 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 06:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:54 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:54 --> Total execution time: 0.0388
INFO - 2018-10-16 06:55:55 --> Config Class Initialized
INFO - 2018-10-16 06:55:55 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:55 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:55 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:55 --> URI Class Initialized
INFO - 2018-10-16 06:55:55 --> Router Class Initialized
INFO - 2018-10-16 06:55:55 --> Output Class Initialized
INFO - 2018-10-16 06:55:55 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:55 --> CSRF cookie sent
INFO - 2018-10-16 06:55:55 --> CSRF token verified
INFO - 2018-10-16 06:55:55 --> Input Class Initialized
INFO - 2018-10-16 06:55:55 --> Language Class Initialized
INFO - 2018-10-16 06:55:55 --> Loader Class Initialized
INFO - 2018-10-16 06:55:55 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:55 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:55 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:55 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:55 --> Controller Class Initialized
INFO - 2018-10-16 06:55:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:55 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:55 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:55 --> Config Class Initialized
INFO - 2018-10-16 06:55:55 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:55 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:55 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:55 --> URI Class Initialized
INFO - 2018-10-16 06:55:55 --> Router Class Initialized
INFO - 2018-10-16 06:55:55 --> Output Class Initialized
INFO - 2018-10-16 06:55:55 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:55 --> CSRF cookie sent
INFO - 2018-10-16 06:55:55 --> Input Class Initialized
INFO - 2018-10-16 06:55:55 --> Language Class Initialized
INFO - 2018-10-16 06:55:55 --> Loader Class Initialized
INFO - 2018-10-16 06:55:55 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:55 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:55 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:55 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:55 --> Controller Class Initialized
INFO - 2018-10-16 06:55:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:55 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 06:55:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:55 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:55 --> Total execution time: 0.0346
INFO - 2018-10-16 06:55:58 --> Config Class Initialized
INFO - 2018-10-16 06:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:58 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:58 --> URI Class Initialized
INFO - 2018-10-16 06:55:58 --> Router Class Initialized
INFO - 2018-10-16 06:55:58 --> Output Class Initialized
INFO - 2018-10-16 06:55:58 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:58 --> CSRF cookie sent
INFO - 2018-10-16 06:55:58 --> CSRF token verified
INFO - 2018-10-16 06:55:58 --> Input Class Initialized
INFO - 2018-10-16 06:55:58 --> Language Class Initialized
INFO - 2018-10-16 06:55:58 --> Loader Class Initialized
INFO - 2018-10-16 06:55:58 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:58 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:58 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:58 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:58 --> Controller Class Initialized
INFO - 2018-10-16 06:55:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:58 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:58 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:58 --> Form Validation Class Initialized
INFO - 2018-10-16 06:55:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:55:58 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:58 --> Config Class Initialized
INFO - 2018-10-16 06:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:55:58 --> Utf8 Class Initialized
INFO - 2018-10-16 06:55:58 --> URI Class Initialized
INFO - 2018-10-16 06:55:58 --> Router Class Initialized
INFO - 2018-10-16 06:55:58 --> Output Class Initialized
INFO - 2018-10-16 06:55:58 --> Security Class Initialized
DEBUG - 2018-10-16 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:55:58 --> CSRF cookie sent
INFO - 2018-10-16 06:55:58 --> Input Class Initialized
INFO - 2018-10-16 06:55:58 --> Language Class Initialized
INFO - 2018-10-16 06:55:58 --> Loader Class Initialized
INFO - 2018-10-16 06:55:58 --> Helper loaded: url_helper
INFO - 2018-10-16 06:55:58 --> Helper loaded: form_helper
INFO - 2018-10-16 06:55:58 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:55:58 --> User Agent Class Initialized
INFO - 2018-10-16 06:55:58 --> Controller Class Initialized
INFO - 2018-10-16 06:55:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:55:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:55:58 --> Pixel_Model class loaded
INFO - 2018-10-16 06:55:58 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:58 --> Database Driver Class Initialized
INFO - 2018-10-16 06:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 06:55:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:55:58 --> Final output sent to browser
DEBUG - 2018-10-16 06:55:58 --> Total execution time: 0.0474
INFO - 2018-10-16 06:56:00 --> Config Class Initialized
INFO - 2018-10-16 06:56:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:00 --> URI Class Initialized
INFO - 2018-10-16 06:56:00 --> Router Class Initialized
INFO - 2018-10-16 06:56:00 --> Output Class Initialized
INFO - 2018-10-16 06:56:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:00 --> CSRF cookie sent
INFO - 2018-10-16 06:56:00 --> CSRF token verified
INFO - 2018-10-16 06:56:00 --> Input Class Initialized
INFO - 2018-10-16 06:56:00 --> Language Class Initialized
INFO - 2018-10-16 06:56:00 --> Loader Class Initialized
INFO - 2018-10-16 06:56:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:00 --> Controller Class Initialized
INFO - 2018-10-16 06:56:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:00 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:00 --> Config Class Initialized
INFO - 2018-10-16 06:56:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:00 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:00 --> URI Class Initialized
INFO - 2018-10-16 06:56:00 --> Router Class Initialized
INFO - 2018-10-16 06:56:00 --> Output Class Initialized
INFO - 2018-10-16 06:56:00 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:00 --> CSRF cookie sent
INFO - 2018-10-16 06:56:00 --> Input Class Initialized
INFO - 2018-10-16 06:56:00 --> Language Class Initialized
INFO - 2018-10-16 06:56:00 --> Loader Class Initialized
INFO - 2018-10-16 06:56:00 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:00 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:00 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:00 --> Controller Class Initialized
INFO - 2018-10-16 06:56:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:00 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:00 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 06:56:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:00 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:00 --> Total execution time: 0.0395
INFO - 2018-10-16 06:56:02 --> Config Class Initialized
INFO - 2018-10-16 06:56:02 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:02 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:02 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:02 --> URI Class Initialized
INFO - 2018-10-16 06:56:02 --> Router Class Initialized
INFO - 2018-10-16 06:56:02 --> Output Class Initialized
INFO - 2018-10-16 06:56:02 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:02 --> CSRF cookie sent
INFO - 2018-10-16 06:56:02 --> CSRF token verified
INFO - 2018-10-16 06:56:02 --> Input Class Initialized
INFO - 2018-10-16 06:56:02 --> Language Class Initialized
INFO - 2018-10-16 06:56:02 --> Loader Class Initialized
INFO - 2018-10-16 06:56:02 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:02 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:02 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:02 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:02 --> Controller Class Initialized
INFO - 2018-10-16 06:56:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:02 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:02 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:02 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:02 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:02 --> Config Class Initialized
INFO - 2018-10-16 06:56:02 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:02 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:02 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:02 --> URI Class Initialized
INFO - 2018-10-16 06:56:02 --> Router Class Initialized
INFO - 2018-10-16 06:56:02 --> Output Class Initialized
INFO - 2018-10-16 06:56:02 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:02 --> CSRF cookie sent
INFO - 2018-10-16 06:56:02 --> Input Class Initialized
INFO - 2018-10-16 06:56:02 --> Language Class Initialized
INFO - 2018-10-16 06:56:02 --> Loader Class Initialized
INFO - 2018-10-16 06:56:02 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:02 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:02 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:02 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:02 --> Controller Class Initialized
INFO - 2018-10-16 06:56:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:02 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:02 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:02 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-16 06:56:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:02 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:02 --> Total execution time: 0.0413
INFO - 2018-10-16 06:56:03 --> Config Class Initialized
INFO - 2018-10-16 06:56:03 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:03 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:03 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:03 --> URI Class Initialized
INFO - 2018-10-16 06:56:03 --> Router Class Initialized
INFO - 2018-10-16 06:56:03 --> Output Class Initialized
INFO - 2018-10-16 06:56:03 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:03 --> CSRF cookie sent
INFO - 2018-10-16 06:56:03 --> CSRF token verified
INFO - 2018-10-16 06:56:03 --> Input Class Initialized
INFO - 2018-10-16 06:56:03 --> Language Class Initialized
INFO - 2018-10-16 06:56:03 --> Loader Class Initialized
INFO - 2018-10-16 06:56:03 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:03 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:03 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:03 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:03 --> Controller Class Initialized
INFO - 2018-10-16 06:56:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:03 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:03 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:03 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:03 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:03 --> Config Class Initialized
INFO - 2018-10-16 06:56:03 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:03 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:03 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:03 --> URI Class Initialized
INFO - 2018-10-16 06:56:03 --> Router Class Initialized
INFO - 2018-10-16 06:56:03 --> Output Class Initialized
INFO - 2018-10-16 06:56:03 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:03 --> CSRF cookie sent
INFO - 2018-10-16 06:56:03 --> Input Class Initialized
INFO - 2018-10-16 06:56:03 --> Language Class Initialized
INFO - 2018-10-16 06:56:03 --> Loader Class Initialized
INFO - 2018-10-16 06:56:03 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:03 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:03 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:03 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:03 --> Controller Class Initialized
INFO - 2018-10-16 06:56:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:03 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:03 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:03 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-16 06:56:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:03 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:03 --> Total execution time: 0.0468
INFO - 2018-10-16 06:56:04 --> Config Class Initialized
INFO - 2018-10-16 06:56:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:04 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:04 --> URI Class Initialized
INFO - 2018-10-16 06:56:04 --> Router Class Initialized
INFO - 2018-10-16 06:56:04 --> Output Class Initialized
INFO - 2018-10-16 06:56:04 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:04 --> CSRF cookie sent
INFO - 2018-10-16 06:56:04 --> CSRF token verified
INFO - 2018-10-16 06:56:04 --> Input Class Initialized
INFO - 2018-10-16 06:56:04 --> Language Class Initialized
INFO - 2018-10-16 06:56:04 --> Loader Class Initialized
INFO - 2018-10-16 06:56:04 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:04 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:04 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:04 --> Controller Class Initialized
INFO - 2018-10-16 06:56:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:04 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:04 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:04 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:04 --> Config Class Initialized
INFO - 2018-10-16 06:56:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:04 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:04 --> URI Class Initialized
INFO - 2018-10-16 06:56:04 --> Router Class Initialized
INFO - 2018-10-16 06:56:04 --> Output Class Initialized
INFO - 2018-10-16 06:56:04 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:04 --> CSRF cookie sent
INFO - 2018-10-16 06:56:04 --> Input Class Initialized
INFO - 2018-10-16 06:56:04 --> Language Class Initialized
INFO - 2018-10-16 06:56:04 --> Loader Class Initialized
INFO - 2018-10-16 06:56:04 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:04 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:04 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:04 --> Controller Class Initialized
INFO - 2018-10-16 06:56:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:04 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:05 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:05 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-16 06:56:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:05 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:05 --> Total execution time: 0.0534
INFO - 2018-10-16 06:56:06 --> Config Class Initialized
INFO - 2018-10-16 06:56:06 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:06 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:06 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:06 --> URI Class Initialized
INFO - 2018-10-16 06:56:06 --> Router Class Initialized
INFO - 2018-10-16 06:56:06 --> Output Class Initialized
INFO - 2018-10-16 06:56:06 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:06 --> CSRF cookie sent
INFO - 2018-10-16 06:56:06 --> CSRF token verified
INFO - 2018-10-16 06:56:06 --> Input Class Initialized
INFO - 2018-10-16 06:56:06 --> Language Class Initialized
INFO - 2018-10-16 06:56:06 --> Loader Class Initialized
INFO - 2018-10-16 06:56:06 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:06 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:06 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:06 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:06 --> Controller Class Initialized
INFO - 2018-10-16 06:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:06 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:06 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:06 --> Config Class Initialized
INFO - 2018-10-16 06:56:06 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:06 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:06 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:06 --> URI Class Initialized
INFO - 2018-10-16 06:56:06 --> Router Class Initialized
INFO - 2018-10-16 06:56:06 --> Output Class Initialized
INFO - 2018-10-16 06:56:06 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:06 --> CSRF cookie sent
INFO - 2018-10-16 06:56:06 --> Input Class Initialized
INFO - 2018-10-16 06:56:06 --> Language Class Initialized
INFO - 2018-10-16 06:56:06 --> Loader Class Initialized
INFO - 2018-10-16 06:56:06 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:06 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:06 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:06 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:06 --> Controller Class Initialized
INFO - 2018-10-16 06:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:06 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:06 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-16 06:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:06 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:06 --> Total execution time: 0.0501
INFO - 2018-10-16 06:56:07 --> Config Class Initialized
INFO - 2018-10-16 06:56:07 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:07 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:07 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:07 --> URI Class Initialized
INFO - 2018-10-16 06:56:07 --> Router Class Initialized
INFO - 2018-10-16 06:56:07 --> Output Class Initialized
INFO - 2018-10-16 06:56:07 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:07 --> CSRF cookie sent
INFO - 2018-10-16 06:56:07 --> CSRF token verified
INFO - 2018-10-16 06:56:07 --> Input Class Initialized
INFO - 2018-10-16 06:56:07 --> Language Class Initialized
INFO - 2018-10-16 06:56:07 --> Loader Class Initialized
INFO - 2018-10-16 06:56:07 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:07 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:07 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:07 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:07 --> Controller Class Initialized
INFO - 2018-10-16 06:56:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:07 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:07 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:07 --> Config Class Initialized
INFO - 2018-10-16 06:56:07 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:07 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:07 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:07 --> URI Class Initialized
INFO - 2018-10-16 06:56:07 --> Router Class Initialized
INFO - 2018-10-16 06:56:07 --> Output Class Initialized
INFO - 2018-10-16 06:56:07 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:07 --> CSRF cookie sent
INFO - 2018-10-16 06:56:07 --> Input Class Initialized
INFO - 2018-10-16 06:56:07 --> Language Class Initialized
INFO - 2018-10-16 06:56:07 --> Loader Class Initialized
INFO - 2018-10-16 06:56:07 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:07 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:07 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:07 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:07 --> Controller Class Initialized
INFO - 2018-10-16 06:56:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:07 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:07 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-16 06:56:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:07 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:07 --> Total execution time: 0.0440
INFO - 2018-10-16 06:56:08 --> Config Class Initialized
INFO - 2018-10-16 06:56:08 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:08 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:08 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:08 --> URI Class Initialized
INFO - 2018-10-16 06:56:08 --> Router Class Initialized
INFO - 2018-10-16 06:56:08 --> Output Class Initialized
INFO - 2018-10-16 06:56:08 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:08 --> CSRF cookie sent
INFO - 2018-10-16 06:56:08 --> CSRF token verified
INFO - 2018-10-16 06:56:08 --> Input Class Initialized
INFO - 2018-10-16 06:56:08 --> Language Class Initialized
INFO - 2018-10-16 06:56:08 --> Loader Class Initialized
INFO - 2018-10-16 06:56:08 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:08 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:08 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:08 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:08 --> Controller Class Initialized
INFO - 2018-10-16 06:56:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:08 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:08 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:08 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:08 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:08 --> Config Class Initialized
INFO - 2018-10-16 06:56:08 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:08 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:08 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:08 --> URI Class Initialized
INFO - 2018-10-16 06:56:08 --> Router Class Initialized
INFO - 2018-10-16 06:56:08 --> Output Class Initialized
INFO - 2018-10-16 06:56:08 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:08 --> CSRF cookie sent
INFO - 2018-10-16 06:56:08 --> Input Class Initialized
INFO - 2018-10-16 06:56:08 --> Language Class Initialized
INFO - 2018-10-16 06:56:08 --> Loader Class Initialized
INFO - 2018-10-16 06:56:08 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:08 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:08 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:08 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:08 --> Controller Class Initialized
INFO - 2018-10-16 06:56:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:08 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:08 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:08 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-16 06:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:08 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:08 --> Total execution time: 0.0473
INFO - 2018-10-16 06:56:10 --> Config Class Initialized
INFO - 2018-10-16 06:56:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:10 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:10 --> URI Class Initialized
INFO - 2018-10-16 06:56:10 --> Router Class Initialized
INFO - 2018-10-16 06:56:10 --> Output Class Initialized
INFO - 2018-10-16 06:56:10 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:10 --> CSRF cookie sent
INFO - 2018-10-16 06:56:10 --> CSRF token verified
INFO - 2018-10-16 06:56:10 --> Input Class Initialized
INFO - 2018-10-16 06:56:10 --> Language Class Initialized
INFO - 2018-10-16 06:56:10 --> Loader Class Initialized
INFO - 2018-10-16 06:56:10 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:10 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:10 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:10 --> Controller Class Initialized
INFO - 2018-10-16 06:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:10 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:10 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:10 --> Config Class Initialized
INFO - 2018-10-16 06:56:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:10 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:10 --> URI Class Initialized
INFO - 2018-10-16 06:56:10 --> Router Class Initialized
INFO - 2018-10-16 06:56:10 --> Output Class Initialized
INFO - 2018-10-16 06:56:10 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:10 --> CSRF cookie sent
INFO - 2018-10-16 06:56:10 --> Input Class Initialized
INFO - 2018-10-16 06:56:10 --> Language Class Initialized
INFO - 2018-10-16 06:56:10 --> Loader Class Initialized
INFO - 2018-10-16 06:56:10 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:10 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:10 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:10 --> Controller Class Initialized
INFO - 2018-10-16 06:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:10 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:10 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-16 06:56:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:10 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:10 --> Total execution time: 0.0546
INFO - 2018-10-16 06:56:11 --> Config Class Initialized
INFO - 2018-10-16 06:56:11 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:11 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:11 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:11 --> URI Class Initialized
INFO - 2018-10-16 06:56:11 --> Router Class Initialized
INFO - 2018-10-16 06:56:11 --> Output Class Initialized
INFO - 2018-10-16 06:56:11 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:11 --> CSRF cookie sent
INFO - 2018-10-16 06:56:11 --> CSRF token verified
INFO - 2018-10-16 06:56:11 --> Input Class Initialized
INFO - 2018-10-16 06:56:11 --> Language Class Initialized
INFO - 2018-10-16 06:56:11 --> Loader Class Initialized
INFO - 2018-10-16 06:56:11 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:11 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:11 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:11 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:11 --> Controller Class Initialized
INFO - 2018-10-16 06:56:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:11 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:11 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:11 --> Config Class Initialized
INFO - 2018-10-16 06:56:11 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:11 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:11 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:11 --> URI Class Initialized
INFO - 2018-10-16 06:56:11 --> Router Class Initialized
INFO - 2018-10-16 06:56:11 --> Output Class Initialized
INFO - 2018-10-16 06:56:11 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:11 --> CSRF cookie sent
INFO - 2018-10-16 06:56:11 --> Input Class Initialized
INFO - 2018-10-16 06:56:11 --> Language Class Initialized
INFO - 2018-10-16 06:56:11 --> Loader Class Initialized
INFO - 2018-10-16 06:56:11 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:11 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:11 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:11 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:11 --> Controller Class Initialized
INFO - 2018-10-16 06:56:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:11 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-10-16 06:56:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:11 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:11 --> Total execution time: 0.0605
INFO - 2018-10-16 06:56:13 --> Config Class Initialized
INFO - 2018-10-16 06:56:13 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:13 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:13 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:13 --> URI Class Initialized
INFO - 2018-10-16 06:56:13 --> Router Class Initialized
INFO - 2018-10-16 06:56:13 --> Output Class Initialized
INFO - 2018-10-16 06:56:13 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:13 --> CSRF cookie sent
INFO - 2018-10-16 06:56:13 --> CSRF token verified
INFO - 2018-10-16 06:56:13 --> Input Class Initialized
INFO - 2018-10-16 06:56:13 --> Language Class Initialized
INFO - 2018-10-16 06:56:13 --> Loader Class Initialized
INFO - 2018-10-16 06:56:13 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:13 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:13 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:13 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:13 --> Controller Class Initialized
INFO - 2018-10-16 06:56:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:13 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:13 --> Form Validation Class Initialized
INFO - 2018-10-16 06:56:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 06:56:13 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-10-16 06:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:13 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:13 --> Total execution time: 0.0509
INFO - 2018-10-16 06:56:18 --> Config Class Initialized
INFO - 2018-10-16 06:56:18 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:18 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:18 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:18 --> URI Class Initialized
INFO - 2018-10-16 06:56:18 --> Router Class Initialized
INFO - 2018-10-16 06:56:18 --> Output Class Initialized
INFO - 2018-10-16 06:56:18 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:18 --> CSRF cookie sent
INFO - 2018-10-16 06:56:18 --> Input Class Initialized
INFO - 2018-10-16 06:56:18 --> Language Class Initialized
INFO - 2018-10-16 06:56:18 --> Loader Class Initialized
INFO - 2018-10-16 06:56:18 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:18 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:18 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:18 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:18 --> Controller Class Initialized
INFO - 2018-10-16 06:56:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:18 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:18 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 06:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:18 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:18 --> Total execution time: 0.0481
INFO - 2018-10-16 06:56:23 --> Config Class Initialized
INFO - 2018-10-16 06:56:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:23 --> URI Class Initialized
INFO - 2018-10-16 06:56:23 --> Router Class Initialized
INFO - 2018-10-16 06:56:23 --> Output Class Initialized
INFO - 2018-10-16 06:56:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:23 --> CSRF cookie sent
INFO - 2018-10-16 06:56:23 --> Input Class Initialized
INFO - 2018-10-16 06:56:23 --> Language Class Initialized
INFO - 2018-10-16 06:56:23 --> Loader Class Initialized
INFO - 2018-10-16 06:56:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:23 --> Controller Class Initialized
INFO - 2018-10-16 06:56:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:23 --> CSRF cookie sent
INFO - 2018-10-16 06:56:23 --> Config Class Initialized
INFO - 2018-10-16 06:56:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:23 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:23 --> URI Class Initialized
DEBUG - 2018-10-16 06:56:23 --> No URI present. Default controller set.
INFO - 2018-10-16 06:56:23 --> Router Class Initialized
INFO - 2018-10-16 06:56:23 --> Output Class Initialized
INFO - 2018-10-16 06:56:23 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:23 --> CSRF cookie sent
INFO - 2018-10-16 06:56:23 --> Input Class Initialized
INFO - 2018-10-16 06:56:23 --> Language Class Initialized
INFO - 2018-10-16 06:56:23 --> Loader Class Initialized
INFO - 2018-10-16 06:56:23 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:23 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:23 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:23 --> Controller Class Initialized
INFO - 2018-10-16 06:56:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:23 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:23 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 06:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 06:56:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:23 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:23 --> Total execution time: 0.0344
INFO - 2018-10-16 06:56:24 --> Config Class Initialized
INFO - 2018-10-16 06:56:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:24 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:24 --> URI Class Initialized
INFO - 2018-10-16 06:56:24 --> Router Class Initialized
INFO - 2018-10-16 06:56:24 --> Output Class Initialized
INFO - 2018-10-16 06:56:24 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:24 --> CSRF cookie sent
INFO - 2018-10-16 06:56:24 --> Input Class Initialized
INFO - 2018-10-16 06:56:24 --> Language Class Initialized
INFO - 2018-10-16 06:56:24 --> Loader Class Initialized
INFO - 2018-10-16 06:56:24 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:24 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:24 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:24 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:24 --> Controller Class Initialized
INFO - 2018-10-16 06:56:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 06:56:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:56:24 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 06:56:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:24 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:24 --> Total execution time: 0.0272
INFO - 2018-10-16 06:56:27 --> Config Class Initialized
INFO - 2018-10-16 06:56:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:27 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:27 --> URI Class Initialized
INFO - 2018-10-16 06:56:27 --> Router Class Initialized
INFO - 2018-10-16 06:56:27 --> Output Class Initialized
INFO - 2018-10-16 06:56:27 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:27 --> CSRF cookie sent
INFO - 2018-10-16 06:56:27 --> Input Class Initialized
INFO - 2018-10-16 06:56:27 --> Language Class Initialized
INFO - 2018-10-16 06:56:27 --> Loader Class Initialized
INFO - 2018-10-16 06:56:27 --> Helper loaded: url_helper
INFO - 2018-10-16 06:56:27 --> Helper loaded: form_helper
INFO - 2018-10-16 06:56:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:56:27 --> User Agent Class Initialized
INFO - 2018-10-16 06:56:27 --> Controller Class Initialized
INFO - 2018-10-16 06:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:56:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:56:27 --> Pixel_Model class loaded
INFO - 2018-10-16 06:56:27 --> Database Driver Class Initialized
INFO - 2018-10-16 06:56:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:56:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:56:27 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:56:27 --> Final output sent to browser
DEBUG - 2018-10-16 06:56:27 --> Total execution time: 0.0444
INFO - 2018-10-16 06:56:35 --> Config Class Initialized
INFO - 2018-10-16 06:56:35 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:56:35 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:56:35 --> Utf8 Class Initialized
INFO - 2018-10-16 06:56:35 --> URI Class Initialized
INFO - 2018-10-16 06:56:35 --> Router Class Initialized
INFO - 2018-10-16 06:56:35 --> Output Class Initialized
INFO - 2018-10-16 06:56:35 --> Security Class Initialized
DEBUG - 2018-10-16 06:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:56:35 --> CSRF cookie sent
INFO - 2018-10-16 06:56:35 --> Input Class Initialized
INFO - 2018-10-16 06:56:35 --> Language Class Initialized
ERROR - 2018-10-16 06:56:35 --> 404 Page Not Found: Assets/css
INFO - 2018-10-16 06:57:11 --> Config Class Initialized
INFO - 2018-10-16 06:57:11 --> Hooks Class Initialized
DEBUG - 2018-10-16 06:57:11 --> UTF-8 Support Enabled
INFO - 2018-10-16 06:57:11 --> Utf8 Class Initialized
INFO - 2018-10-16 06:57:11 --> URI Class Initialized
INFO - 2018-10-16 06:57:11 --> Router Class Initialized
INFO - 2018-10-16 06:57:11 --> Output Class Initialized
INFO - 2018-10-16 06:57:11 --> Security Class Initialized
DEBUG - 2018-10-16 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 06:57:11 --> CSRF cookie sent
INFO - 2018-10-16 06:57:11 --> Input Class Initialized
INFO - 2018-10-16 06:57:11 --> Language Class Initialized
INFO - 2018-10-16 06:57:11 --> Loader Class Initialized
INFO - 2018-10-16 06:57:11 --> Helper loaded: url_helper
INFO - 2018-10-16 06:57:11 --> Helper loaded: form_helper
INFO - 2018-10-16 06:57:11 --> Helper loaded: language_helper
DEBUG - 2018-10-16 06:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 06:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 06:57:11 --> User Agent Class Initialized
INFO - 2018-10-16 06:57:11 --> Controller Class Initialized
INFO - 2018-10-16 06:57:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 06:57:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 06:57:11 --> Pixel_Model class loaded
INFO - 2018-10-16 06:57:11 --> Database Driver Class Initialized
INFO - 2018-10-16 06:57:11 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 06:57:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 06:57:11 --> Could not find the language line "req_email"
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 06:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 06:57:11 --> Final output sent to browser
DEBUG - 2018-10-16 06:57:11 --> Total execution time: 0.0408
INFO - 2018-10-16 07:00:51 --> Config Class Initialized
INFO - 2018-10-16 07:00:51 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:00:51 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:00:51 --> Utf8 Class Initialized
INFO - 2018-10-16 07:00:51 --> URI Class Initialized
INFO - 2018-10-16 07:00:51 --> Router Class Initialized
INFO - 2018-10-16 07:00:51 --> Output Class Initialized
INFO - 2018-10-16 07:00:51 --> Security Class Initialized
DEBUG - 2018-10-16 07:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:00:51 --> CSRF cookie sent
INFO - 2018-10-16 07:00:51 --> Input Class Initialized
INFO - 2018-10-16 07:00:51 --> Language Class Initialized
INFO - 2018-10-16 07:00:51 --> Loader Class Initialized
INFO - 2018-10-16 07:00:51 --> Helper loaded: url_helper
INFO - 2018-10-16 07:00:51 --> Helper loaded: form_helper
INFO - 2018-10-16 07:00:51 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:00:51 --> User Agent Class Initialized
INFO - 2018-10-16 07:00:51 --> Controller Class Initialized
INFO - 2018-10-16 07:00:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:00:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:00:51 --> Pixel_Model class loaded
INFO - 2018-10-16 07:00:51 --> Database Driver Class Initialized
INFO - 2018-10-16 07:00:51 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 07:00:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 07:00:51 --> Could not find the language line "req_email"
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 07:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:00:51 --> Final output sent to browser
DEBUG - 2018-10-16 07:00:51 --> Total execution time: 0.0397
INFO - 2018-10-16 07:01:16 --> Config Class Initialized
INFO - 2018-10-16 07:01:16 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:01:16 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:01:16 --> Utf8 Class Initialized
INFO - 2018-10-16 07:01:16 --> URI Class Initialized
INFO - 2018-10-16 07:01:16 --> Router Class Initialized
INFO - 2018-10-16 07:01:16 --> Output Class Initialized
INFO - 2018-10-16 07:01:16 --> Security Class Initialized
DEBUG - 2018-10-16 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:01:16 --> CSRF cookie sent
INFO - 2018-10-16 07:01:16 --> Input Class Initialized
INFO - 2018-10-16 07:01:16 --> Language Class Initialized
INFO - 2018-10-16 07:01:16 --> Loader Class Initialized
INFO - 2018-10-16 07:01:16 --> Helper loaded: url_helper
INFO - 2018-10-16 07:01:16 --> Helper loaded: form_helper
INFO - 2018-10-16 07:01:16 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:01:16 --> User Agent Class Initialized
INFO - 2018-10-16 07:01:16 --> Controller Class Initialized
INFO - 2018-10-16 07:01:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:01:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:01:16 --> Pixel_Model class loaded
INFO - 2018-10-16 07:01:16 --> Database Driver Class Initialized
INFO - 2018-10-16 07:01:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 07:01:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 07:01:16 --> Could not find the language line "req_email"
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 07:01:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:01:16 --> Final output sent to browser
DEBUG - 2018-10-16 07:01:16 --> Total execution time: 0.0525
INFO - 2018-10-16 07:01:56 --> Config Class Initialized
INFO - 2018-10-16 07:01:56 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:01:56 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:01:56 --> Utf8 Class Initialized
INFO - 2018-10-16 07:01:56 --> URI Class Initialized
INFO - 2018-10-16 07:01:56 --> Router Class Initialized
INFO - 2018-10-16 07:01:56 --> Output Class Initialized
INFO - 2018-10-16 07:01:56 --> Security Class Initialized
DEBUG - 2018-10-16 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:01:56 --> CSRF cookie sent
INFO - 2018-10-16 07:01:56 --> Input Class Initialized
INFO - 2018-10-16 07:01:56 --> Language Class Initialized
INFO - 2018-10-16 07:01:56 --> Loader Class Initialized
INFO - 2018-10-16 07:01:56 --> Helper loaded: url_helper
INFO - 2018-10-16 07:01:56 --> Helper loaded: form_helper
INFO - 2018-10-16 07:01:56 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:01:56 --> User Agent Class Initialized
INFO - 2018-10-16 07:01:56 --> Controller Class Initialized
INFO - 2018-10-16 07:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:01:56 --> Pixel_Model class loaded
INFO - 2018-10-16 07:01:56 --> Database Driver Class Initialized
INFO - 2018-10-16 07:01:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 07:01:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 07:01:56 --> Could not find the language line "req_email"
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 07:01:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:01:56 --> Final output sent to browser
DEBUG - 2018-10-16 07:01:56 --> Total execution time: 0.0410
INFO - 2018-10-16 07:05:39 --> Config Class Initialized
INFO - 2018-10-16 07:05:39 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:39 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:39 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:39 --> URI Class Initialized
INFO - 2018-10-16 07:05:39 --> Router Class Initialized
INFO - 2018-10-16 07:05:39 --> Output Class Initialized
INFO - 2018-10-16 07:05:39 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:39 --> CSRF cookie sent
INFO - 2018-10-16 07:05:39 --> Input Class Initialized
INFO - 2018-10-16 07:05:39 --> Language Class Initialized
INFO - 2018-10-16 07:05:39 --> Loader Class Initialized
INFO - 2018-10-16 07:05:39 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:39 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:39 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:39 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:39 --> Controller Class Initialized
INFO - 2018-10-16 07:05:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:39 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:39 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 07:05:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:39 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:39 --> Total execution time: 0.0367
INFO - 2018-10-16 07:05:40 --> Config Class Initialized
INFO - 2018-10-16 07:05:40 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:40 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:40 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:40 --> URI Class Initialized
INFO - 2018-10-16 07:05:40 --> Router Class Initialized
INFO - 2018-10-16 07:05:40 --> Output Class Initialized
INFO - 2018-10-16 07:05:40 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:40 --> CSRF cookie sent
INFO - 2018-10-16 07:05:40 --> CSRF token verified
INFO - 2018-10-16 07:05:40 --> Input Class Initialized
INFO - 2018-10-16 07:05:40 --> Language Class Initialized
INFO - 2018-10-16 07:05:40 --> Loader Class Initialized
INFO - 2018-10-16 07:05:40 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:40 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:40 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:40 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:40 --> Controller Class Initialized
INFO - 2018-10-16 07:05:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:40 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:40 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:40 --> Form Validation Class Initialized
INFO - 2018-10-16 07:05:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 07:05:40 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:41 --> Config Class Initialized
INFO - 2018-10-16 07:05:41 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:41 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:41 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:41 --> URI Class Initialized
INFO - 2018-10-16 07:05:41 --> Router Class Initialized
INFO - 2018-10-16 07:05:41 --> Output Class Initialized
INFO - 2018-10-16 07:05:41 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:41 --> CSRF cookie sent
INFO - 2018-10-16 07:05:41 --> Input Class Initialized
INFO - 2018-10-16 07:05:41 --> Language Class Initialized
INFO - 2018-10-16 07:05:41 --> Loader Class Initialized
INFO - 2018-10-16 07:05:41 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:41 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:41 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:41 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:41 --> Controller Class Initialized
INFO - 2018-10-16 07:05:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:41 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:41 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:41 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 07:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:41 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:41 --> Total execution time: 0.0463
INFO - 2018-10-16 07:05:47 --> Config Class Initialized
INFO - 2018-10-16 07:05:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:47 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:47 --> URI Class Initialized
INFO - 2018-10-16 07:05:47 --> Router Class Initialized
INFO - 2018-10-16 07:05:47 --> Output Class Initialized
INFO - 2018-10-16 07:05:47 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:47 --> CSRF cookie sent
INFO - 2018-10-16 07:05:47 --> CSRF token verified
INFO - 2018-10-16 07:05:47 --> Input Class Initialized
INFO - 2018-10-16 07:05:47 --> Language Class Initialized
INFO - 2018-10-16 07:05:47 --> Loader Class Initialized
INFO - 2018-10-16 07:05:47 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:47 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:47 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:47 --> Controller Class Initialized
INFO - 2018-10-16 07:05:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:47 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:47 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:47 --> Form Validation Class Initialized
INFO - 2018-10-16 07:05:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 07:05:47 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:47 --> Config Class Initialized
INFO - 2018-10-16 07:05:47 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:47 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:47 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:47 --> URI Class Initialized
INFO - 2018-10-16 07:05:47 --> Router Class Initialized
INFO - 2018-10-16 07:05:47 --> Output Class Initialized
INFO - 2018-10-16 07:05:47 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:47 --> CSRF cookie sent
INFO - 2018-10-16 07:05:47 --> Input Class Initialized
INFO - 2018-10-16 07:05:47 --> Language Class Initialized
INFO - 2018-10-16 07:05:47 --> Loader Class Initialized
INFO - 2018-10-16 07:05:47 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:47 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:47 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:47 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:47 --> Controller Class Initialized
INFO - 2018-10-16 07:05:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:47 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:47 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:47 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 07:05:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:47 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:47 --> Total execution time: 0.0483
INFO - 2018-10-16 07:05:49 --> Config Class Initialized
INFO - 2018-10-16 07:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:49 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:49 --> URI Class Initialized
INFO - 2018-10-16 07:05:49 --> Router Class Initialized
INFO - 2018-10-16 07:05:49 --> Output Class Initialized
INFO - 2018-10-16 07:05:49 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:49 --> CSRF cookie sent
INFO - 2018-10-16 07:05:49 --> CSRF token verified
INFO - 2018-10-16 07:05:49 --> Input Class Initialized
INFO - 2018-10-16 07:05:49 --> Language Class Initialized
INFO - 2018-10-16 07:05:49 --> Loader Class Initialized
INFO - 2018-10-16 07:05:49 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:49 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:49 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:49 --> Controller Class Initialized
INFO - 2018-10-16 07:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:49 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:49 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:49 --> Form Validation Class Initialized
INFO - 2018-10-16 07:05:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 07:05:49 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:49 --> Config Class Initialized
INFO - 2018-10-16 07:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:49 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:49 --> URI Class Initialized
INFO - 2018-10-16 07:05:49 --> Router Class Initialized
INFO - 2018-10-16 07:05:49 --> Output Class Initialized
INFO - 2018-10-16 07:05:49 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:49 --> CSRF cookie sent
INFO - 2018-10-16 07:05:49 --> Input Class Initialized
INFO - 2018-10-16 07:05:49 --> Language Class Initialized
INFO - 2018-10-16 07:05:49 --> Loader Class Initialized
INFO - 2018-10-16 07:05:49 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:49 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:49 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:49 --> Controller Class Initialized
INFO - 2018-10-16 07:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:49 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:49 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:49 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 07:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:49 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:49 --> Total execution time: 0.0511
INFO - 2018-10-16 07:05:54 --> Config Class Initialized
INFO - 2018-10-16 07:05:54 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:54 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:54 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:54 --> URI Class Initialized
INFO - 2018-10-16 07:05:54 --> Router Class Initialized
INFO - 2018-10-16 07:05:54 --> Output Class Initialized
INFO - 2018-10-16 07:05:54 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:54 --> CSRF cookie sent
INFO - 2018-10-16 07:05:54 --> Input Class Initialized
INFO - 2018-10-16 07:05:54 --> Language Class Initialized
INFO - 2018-10-16 07:05:54 --> Loader Class Initialized
INFO - 2018-10-16 07:05:54 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:54 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:54 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:54 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:54 --> Controller Class Initialized
INFO - 2018-10-16 07:05:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:54 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:54 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:54 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 07:05:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:54 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:54 --> Total execution time: 0.0455
INFO - 2018-10-16 07:05:55 --> Config Class Initialized
INFO - 2018-10-16 07:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:55 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:55 --> URI Class Initialized
INFO - 2018-10-16 07:05:55 --> Router Class Initialized
INFO - 2018-10-16 07:05:55 --> Output Class Initialized
INFO - 2018-10-16 07:05:55 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:55 --> CSRF cookie sent
INFO - 2018-10-16 07:05:55 --> Input Class Initialized
INFO - 2018-10-16 07:05:55 --> Language Class Initialized
INFO - 2018-10-16 07:05:55 --> Loader Class Initialized
INFO - 2018-10-16 07:05:55 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:55 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:55 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:55 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:55 --> Controller Class Initialized
INFO - 2018-10-16 07:05:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:55 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:55 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:55 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 07:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:55 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:55 --> Total execution time: 0.0614
INFO - 2018-10-16 07:05:57 --> Config Class Initialized
INFO - 2018-10-16 07:05:57 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:57 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:57 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:57 --> URI Class Initialized
INFO - 2018-10-16 07:05:57 --> Router Class Initialized
INFO - 2018-10-16 07:05:57 --> Output Class Initialized
INFO - 2018-10-16 07:05:57 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:57 --> CSRF cookie sent
INFO - 2018-10-16 07:05:57 --> Input Class Initialized
INFO - 2018-10-16 07:05:57 --> Language Class Initialized
INFO - 2018-10-16 07:05:57 --> Loader Class Initialized
INFO - 2018-10-16 07:05:57 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:57 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:57 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:57 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:57 --> Controller Class Initialized
INFO - 2018-10-16 07:05:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:57 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:57 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 07:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:57 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:57 --> Total execution time: 0.0393
INFO - 2018-10-16 07:05:59 --> Config Class Initialized
INFO - 2018-10-16 07:05:59 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:59 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:59 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:59 --> URI Class Initialized
INFO - 2018-10-16 07:05:59 --> Router Class Initialized
INFO - 2018-10-16 07:05:59 --> Output Class Initialized
INFO - 2018-10-16 07:05:59 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:59 --> CSRF cookie sent
INFO - 2018-10-16 07:05:59 --> CSRF token verified
INFO - 2018-10-16 07:05:59 --> Input Class Initialized
INFO - 2018-10-16 07:05:59 --> Language Class Initialized
INFO - 2018-10-16 07:05:59 --> Loader Class Initialized
INFO - 2018-10-16 07:05:59 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:59 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:59 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:59 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:59 --> Controller Class Initialized
INFO - 2018-10-16 07:05:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:59 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:59 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:59 --> Form Validation Class Initialized
INFO - 2018-10-16 07:05:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 07:05:59 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:59 --> Config Class Initialized
INFO - 2018-10-16 07:05:59 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:05:59 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:05:59 --> Utf8 Class Initialized
INFO - 2018-10-16 07:05:59 --> URI Class Initialized
INFO - 2018-10-16 07:05:59 --> Router Class Initialized
INFO - 2018-10-16 07:05:59 --> Output Class Initialized
INFO - 2018-10-16 07:05:59 --> Security Class Initialized
DEBUG - 2018-10-16 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:05:59 --> CSRF cookie sent
INFO - 2018-10-16 07:05:59 --> Input Class Initialized
INFO - 2018-10-16 07:05:59 --> Language Class Initialized
INFO - 2018-10-16 07:05:59 --> Loader Class Initialized
INFO - 2018-10-16 07:05:59 --> Helper loaded: url_helper
INFO - 2018-10-16 07:05:59 --> Helper loaded: form_helper
INFO - 2018-10-16 07:05:59 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:05:59 --> User Agent Class Initialized
INFO - 2018-10-16 07:05:59 --> Controller Class Initialized
INFO - 2018-10-16 07:05:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:05:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:05:59 --> Pixel_Model class loaded
INFO - 2018-10-16 07:05:59 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:59 --> Database Driver Class Initialized
INFO - 2018-10-16 07:05:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 07:05:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:05:59 --> Final output sent to browser
DEBUG - 2018-10-16 07:05:59 --> Total execution time: 0.0671
INFO - 2018-10-16 07:06:00 --> Config Class Initialized
INFO - 2018-10-16 07:06:00 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:06:00 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:06:00 --> Utf8 Class Initialized
INFO - 2018-10-16 07:06:00 --> URI Class Initialized
INFO - 2018-10-16 07:06:00 --> Router Class Initialized
INFO - 2018-10-16 07:06:00 --> Output Class Initialized
INFO - 2018-10-16 07:06:00 --> Security Class Initialized
DEBUG - 2018-10-16 07:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:06:00 --> CSRF cookie sent
INFO - 2018-10-16 07:06:00 --> CSRF token verified
INFO - 2018-10-16 07:06:00 --> Input Class Initialized
INFO - 2018-10-16 07:06:00 --> Language Class Initialized
INFO - 2018-10-16 07:06:00 --> Loader Class Initialized
INFO - 2018-10-16 07:06:00 --> Helper loaded: url_helper
INFO - 2018-10-16 07:06:00 --> Helper loaded: form_helper
INFO - 2018-10-16 07:06:00 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:06:00 --> User Agent Class Initialized
INFO - 2018-10-16 07:06:00 --> Controller Class Initialized
INFO - 2018-10-16 07:06:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:06:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:06:00 --> Pixel_Model class loaded
INFO - 2018-10-16 07:06:00 --> Database Driver Class Initialized
INFO - 2018-10-16 07:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:06:00 --> Form Validation Class Initialized
INFO - 2018-10-16 07:06:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 07:06:00 --> Database Driver Class Initialized
INFO - 2018-10-16 07:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 07:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:06:00 --> Final output sent to browser
DEBUG - 2018-10-16 07:06:00 --> Total execution time: 0.0598
INFO - 2018-10-16 07:06:04 --> Config Class Initialized
INFO - 2018-10-16 07:06:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:06:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:06:04 --> Utf8 Class Initialized
INFO - 2018-10-16 07:06:04 --> URI Class Initialized
INFO - 2018-10-16 07:06:04 --> Router Class Initialized
INFO - 2018-10-16 07:06:04 --> Output Class Initialized
INFO - 2018-10-16 07:06:04 --> Security Class Initialized
DEBUG - 2018-10-16 07:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:06:04 --> CSRF cookie sent
INFO - 2018-10-16 07:06:04 --> Input Class Initialized
INFO - 2018-10-16 07:06:04 --> Language Class Initialized
INFO - 2018-10-16 07:06:04 --> Loader Class Initialized
INFO - 2018-10-16 07:06:04 --> Helper loaded: url_helper
INFO - 2018-10-16 07:06:04 --> Helper loaded: form_helper
INFO - 2018-10-16 07:06:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:06:04 --> User Agent Class Initialized
INFO - 2018-10-16 07:06:04 --> Controller Class Initialized
INFO - 2018-10-16 07:06:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:06:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-16 07:06:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 07:06:04 --> Could not find the language line "req_email"
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-16 07:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:06:04 --> Final output sent to browser
DEBUG - 2018-10-16 07:06:04 --> Total execution time: 0.0235
INFO - 2018-10-16 07:06:06 --> Config Class Initialized
INFO - 2018-10-16 07:06:06 --> Hooks Class Initialized
DEBUG - 2018-10-16 07:06:06 --> UTF-8 Support Enabled
INFO - 2018-10-16 07:06:06 --> Utf8 Class Initialized
INFO - 2018-10-16 07:06:06 --> URI Class Initialized
INFO - 2018-10-16 07:06:06 --> Router Class Initialized
INFO - 2018-10-16 07:06:06 --> Output Class Initialized
INFO - 2018-10-16 07:06:06 --> Security Class Initialized
DEBUG - 2018-10-16 07:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 07:06:06 --> CSRF cookie sent
INFO - 2018-10-16 07:06:06 --> Input Class Initialized
INFO - 2018-10-16 07:06:06 --> Language Class Initialized
INFO - 2018-10-16 07:06:06 --> Loader Class Initialized
INFO - 2018-10-16 07:06:06 --> Helper loaded: url_helper
INFO - 2018-10-16 07:06:06 --> Helper loaded: form_helper
INFO - 2018-10-16 07:06:06 --> Helper loaded: language_helper
DEBUG - 2018-10-16 07:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 07:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 07:06:06 --> User Agent Class Initialized
INFO - 2018-10-16 07:06:06 --> Controller Class Initialized
INFO - 2018-10-16 07:06:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 07:06:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 07:06:06 --> Pixel_Model class loaded
INFO - 2018-10-16 07:06:06 --> Database Driver Class Initialized
INFO - 2018-10-16 07:06:06 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 07:06:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 07:06:06 --> Could not find the language line "req_email"
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 07:06:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 07:06:06 --> Final output sent to browser
DEBUG - 2018-10-16 07:06:06 --> Total execution time: 0.0362
INFO - 2018-10-16 17:35:25 --> Config Class Initialized
INFO - 2018-10-16 17:35:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:35:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:35:25 --> Utf8 Class Initialized
INFO - 2018-10-16 17:35:25 --> URI Class Initialized
INFO - 2018-10-16 17:35:25 --> Router Class Initialized
INFO - 2018-10-16 17:35:25 --> Output Class Initialized
INFO - 2018-10-16 17:35:25 --> Security Class Initialized
DEBUG - 2018-10-16 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:35:25 --> CSRF cookie sent
INFO - 2018-10-16 17:35:25 --> Input Class Initialized
INFO - 2018-10-16 17:35:25 --> Language Class Initialized
INFO - 2018-10-16 17:35:25 --> Loader Class Initialized
INFO - 2018-10-16 17:35:25 --> Helper loaded: url_helper
INFO - 2018-10-16 17:35:25 --> Helper loaded: form_helper
INFO - 2018-10-16 17:35:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:35:25 --> User Agent Class Initialized
INFO - 2018-10-16 17:35:25 --> Controller Class Initialized
INFO - 2018-10-16 17:35:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:35:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:35:25 --> Pixel_Model class loaded
INFO - 2018-10-16 17:35:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:35:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:35:25 --> Config Class Initialized
INFO - 2018-10-16 17:35:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:35:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:35:25 --> Utf8 Class Initialized
INFO - 2018-10-16 17:35:25 --> URI Class Initialized
INFO - 2018-10-16 17:35:25 --> Router Class Initialized
INFO - 2018-10-16 17:35:25 --> Output Class Initialized
INFO - 2018-10-16 17:35:25 --> Security Class Initialized
DEBUG - 2018-10-16 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:35:25 --> CSRF cookie sent
INFO - 2018-10-16 17:35:25 --> Input Class Initialized
INFO - 2018-10-16 17:35:25 --> Language Class Initialized
INFO - 2018-10-16 17:35:25 --> Loader Class Initialized
INFO - 2018-10-16 17:35:25 --> Helper loaded: url_helper
INFO - 2018-10-16 17:35:25 --> Helper loaded: form_helper
INFO - 2018-10-16 17:35:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:35:25 --> User Agent Class Initialized
INFO - 2018-10-16 17:35:25 --> Controller Class Initialized
INFO - 2018-10-16 17:35:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:35:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:35:25 --> Pixel_Model class loaded
INFO - 2018-10-16 17:35:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:35:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-16 17:35:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:35:25 --> Final output sent to browser
DEBUG - 2018-10-16 17:35:25 --> Total execution time: 0.0382
INFO - 2018-10-16 17:36:14 --> Config Class Initialized
INFO - 2018-10-16 17:36:14 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:14 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:14 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:14 --> URI Class Initialized
INFO - 2018-10-16 17:36:14 --> Router Class Initialized
INFO - 2018-10-16 17:36:14 --> Output Class Initialized
INFO - 2018-10-16 17:36:14 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:14 --> CSRF cookie sent
INFO - 2018-10-16 17:36:14 --> CSRF token verified
INFO - 2018-10-16 17:36:14 --> Input Class Initialized
INFO - 2018-10-16 17:36:14 --> Language Class Initialized
INFO - 2018-10-16 17:36:14 --> Loader Class Initialized
INFO - 2018-10-16 17:36:14 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:14 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:14 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:14 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:14 --> Controller Class Initialized
INFO - 2018-10-16 17:36:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:14 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:14 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:14 --> Form Validation Class Initialized
INFO - 2018-10-16 17:36:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:36:14 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:15 --> Config Class Initialized
INFO - 2018-10-16 17:36:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:15 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:15 --> URI Class Initialized
INFO - 2018-10-16 17:36:15 --> Router Class Initialized
INFO - 2018-10-16 17:36:15 --> Output Class Initialized
INFO - 2018-10-16 17:36:15 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:15 --> CSRF cookie sent
INFO - 2018-10-16 17:36:15 --> Input Class Initialized
INFO - 2018-10-16 17:36:15 --> Language Class Initialized
INFO - 2018-10-16 17:36:15 --> Loader Class Initialized
INFO - 2018-10-16 17:36:15 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:15 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:15 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:15 --> Controller Class Initialized
INFO - 2018-10-16 17:36:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:15 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:15 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:15 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 17:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:36:15 --> Final output sent to browser
DEBUG - 2018-10-16 17:36:15 --> Total execution time: 0.0610
INFO - 2018-10-16 17:36:24 --> Config Class Initialized
INFO - 2018-10-16 17:36:24 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:24 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:24 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:24 --> URI Class Initialized
INFO - 2018-10-16 17:36:24 --> Router Class Initialized
INFO - 2018-10-16 17:36:25 --> Output Class Initialized
INFO - 2018-10-16 17:36:25 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:25 --> CSRF cookie sent
INFO - 2018-10-16 17:36:25 --> CSRF token verified
INFO - 2018-10-16 17:36:25 --> Input Class Initialized
INFO - 2018-10-16 17:36:25 --> Language Class Initialized
INFO - 2018-10-16 17:36:25 --> Loader Class Initialized
INFO - 2018-10-16 17:36:25 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:25 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:25 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:25 --> Controller Class Initialized
INFO - 2018-10-16 17:36:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:25 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:25 --> Form Validation Class Initialized
INFO - 2018-10-16 17:36:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:36:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:25 --> Config Class Initialized
INFO - 2018-10-16 17:36:25 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:25 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:25 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:25 --> URI Class Initialized
INFO - 2018-10-16 17:36:25 --> Router Class Initialized
INFO - 2018-10-16 17:36:25 --> Output Class Initialized
INFO - 2018-10-16 17:36:25 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:25 --> CSRF cookie sent
INFO - 2018-10-16 17:36:25 --> Input Class Initialized
INFO - 2018-10-16 17:36:25 --> Language Class Initialized
INFO - 2018-10-16 17:36:25 --> Loader Class Initialized
INFO - 2018-10-16 17:36:25 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:25 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:25 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:25 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:25 --> Controller Class Initialized
INFO - 2018-10-16 17:36:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:25 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:25 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 17:36:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:36:25 --> Final output sent to browser
DEBUG - 2018-10-16 17:36:25 --> Total execution time: 0.0487
INFO - 2018-10-16 17:36:27 --> Config Class Initialized
INFO - 2018-10-16 17:36:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:27 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:27 --> URI Class Initialized
INFO - 2018-10-16 17:36:27 --> Router Class Initialized
INFO - 2018-10-16 17:36:27 --> Output Class Initialized
INFO - 2018-10-16 17:36:27 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:27 --> CSRF cookie sent
INFO - 2018-10-16 17:36:27 --> CSRF token verified
INFO - 2018-10-16 17:36:27 --> Input Class Initialized
INFO - 2018-10-16 17:36:27 --> Language Class Initialized
INFO - 2018-10-16 17:36:27 --> Loader Class Initialized
INFO - 2018-10-16 17:36:27 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:27 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:27 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:27 --> Controller Class Initialized
INFO - 2018-10-16 17:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:27 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:27 --> Form Validation Class Initialized
INFO - 2018-10-16 17:36:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:27 --> Config Class Initialized
INFO - 2018-10-16 17:36:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:27 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:27 --> URI Class Initialized
INFO - 2018-10-16 17:36:27 --> Router Class Initialized
INFO - 2018-10-16 17:36:27 --> Output Class Initialized
INFO - 2018-10-16 17:36:27 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:27 --> CSRF cookie sent
INFO - 2018-10-16 17:36:27 --> Input Class Initialized
INFO - 2018-10-16 17:36:27 --> Language Class Initialized
INFO - 2018-10-16 17:36:27 --> Loader Class Initialized
INFO - 2018-10-16 17:36:27 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:27 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:27 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:27 --> Controller Class Initialized
INFO - 2018-10-16 17:36:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:27 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:27 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 17:36:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:36:27 --> Final output sent to browser
DEBUG - 2018-10-16 17:36:27 --> Total execution time: 0.0409
INFO - 2018-10-16 17:36:34 --> Config Class Initialized
INFO - 2018-10-16 17:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:34 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:34 --> URI Class Initialized
INFO - 2018-10-16 17:36:34 --> Router Class Initialized
INFO - 2018-10-16 17:36:34 --> Output Class Initialized
INFO - 2018-10-16 17:36:34 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:34 --> CSRF cookie sent
INFO - 2018-10-16 17:36:34 --> CSRF token verified
INFO - 2018-10-16 17:36:34 --> Input Class Initialized
INFO - 2018-10-16 17:36:34 --> Language Class Initialized
INFO - 2018-10-16 17:36:34 --> Loader Class Initialized
INFO - 2018-10-16 17:36:34 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:34 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:34 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:34 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:34 --> Controller Class Initialized
INFO - 2018-10-16 17:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:34 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:34 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:34 --> Form Validation Class Initialized
INFO - 2018-10-16 17:36:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:36:34 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:34 --> Config Class Initialized
INFO - 2018-10-16 17:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:34 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:34 --> URI Class Initialized
INFO - 2018-10-16 17:36:34 --> Router Class Initialized
INFO - 2018-10-16 17:36:34 --> Output Class Initialized
INFO - 2018-10-16 17:36:34 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:34 --> CSRF cookie sent
INFO - 2018-10-16 17:36:34 --> Input Class Initialized
INFO - 2018-10-16 17:36:34 --> Language Class Initialized
INFO - 2018-10-16 17:36:34 --> Loader Class Initialized
INFO - 2018-10-16 17:36:34 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:34 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:34 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:34 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:34 --> Controller Class Initialized
INFO - 2018-10-16 17:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:34 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:34 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:34 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 17:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:36:34 --> Final output sent to browser
DEBUG - 2018-10-16 17:36:34 --> Total execution time: 0.0544
INFO - 2018-10-16 17:36:57 --> Config Class Initialized
INFO - 2018-10-16 17:36:57 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:57 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:57 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:57 --> URI Class Initialized
INFO - 2018-10-16 17:36:57 --> Router Class Initialized
INFO - 2018-10-16 17:36:57 --> Output Class Initialized
INFO - 2018-10-16 17:36:57 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:57 --> CSRF cookie sent
INFO - 2018-10-16 17:36:57 --> CSRF token verified
INFO - 2018-10-16 17:36:57 --> Input Class Initialized
INFO - 2018-10-16 17:36:57 --> Language Class Initialized
INFO - 2018-10-16 17:36:57 --> Loader Class Initialized
INFO - 2018-10-16 17:36:57 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:57 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:57 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:57 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:57 --> Controller Class Initialized
INFO - 2018-10-16 17:36:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:57 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:57 --> Form Validation Class Initialized
INFO - 2018-10-16 17:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:36:57 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:58 --> Config Class Initialized
INFO - 2018-10-16 17:36:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:36:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:36:58 --> Utf8 Class Initialized
INFO - 2018-10-16 17:36:58 --> URI Class Initialized
INFO - 2018-10-16 17:36:58 --> Router Class Initialized
INFO - 2018-10-16 17:36:58 --> Output Class Initialized
INFO - 2018-10-16 17:36:58 --> Security Class Initialized
DEBUG - 2018-10-16 17:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:36:58 --> CSRF cookie sent
INFO - 2018-10-16 17:36:58 --> Input Class Initialized
INFO - 2018-10-16 17:36:58 --> Language Class Initialized
INFO - 2018-10-16 17:36:58 --> Loader Class Initialized
INFO - 2018-10-16 17:36:58 --> Helper loaded: url_helper
INFO - 2018-10-16 17:36:58 --> Helper loaded: form_helper
INFO - 2018-10-16 17:36:58 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:36:58 --> User Agent Class Initialized
INFO - 2018-10-16 17:36:58 --> Controller Class Initialized
INFO - 2018-10-16 17:36:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:36:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:36:58 --> Pixel_Model class loaded
INFO - 2018-10-16 17:36:58 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:58 --> Database Driver Class Initialized
INFO - 2018-10-16 17:36:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 17:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:36:58 --> Final output sent to browser
DEBUG - 2018-10-16 17:36:58 --> Total execution time: 0.0406
INFO - 2018-10-16 17:37:10 --> Config Class Initialized
INFO - 2018-10-16 17:37:10 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:10 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:10 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:10 --> URI Class Initialized
INFO - 2018-10-16 17:37:10 --> Router Class Initialized
INFO - 2018-10-16 17:37:10 --> Output Class Initialized
INFO - 2018-10-16 17:37:10 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:10 --> CSRF cookie sent
INFO - 2018-10-16 17:37:10 --> CSRF token verified
INFO - 2018-10-16 17:37:10 --> Input Class Initialized
INFO - 2018-10-16 17:37:10 --> Language Class Initialized
INFO - 2018-10-16 17:37:10 --> Loader Class Initialized
INFO - 2018-10-16 17:37:10 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:10 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:10 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:10 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:10 --> Controller Class Initialized
INFO - 2018-10-16 17:37:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:10 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:10 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:10 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 17:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:10 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:10 --> Total execution time: 0.0501
INFO - 2018-10-16 17:37:14 --> Config Class Initialized
INFO - 2018-10-16 17:37:14 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:14 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:14 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:14 --> URI Class Initialized
INFO - 2018-10-16 17:37:14 --> Router Class Initialized
INFO - 2018-10-16 17:37:14 --> Output Class Initialized
INFO - 2018-10-16 17:37:14 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:14 --> CSRF cookie sent
INFO - 2018-10-16 17:37:14 --> CSRF token verified
INFO - 2018-10-16 17:37:14 --> Input Class Initialized
INFO - 2018-10-16 17:37:14 --> Language Class Initialized
INFO - 2018-10-16 17:37:14 --> Loader Class Initialized
INFO - 2018-10-16 17:37:14 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:14 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:14 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:14 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:14 --> Controller Class Initialized
INFO - 2018-10-16 17:37:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:14 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:14 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:14 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:14 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:15 --> Config Class Initialized
INFO - 2018-10-16 17:37:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:15 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:15 --> URI Class Initialized
INFO - 2018-10-16 17:37:15 --> Router Class Initialized
INFO - 2018-10-16 17:37:15 --> Output Class Initialized
INFO - 2018-10-16 17:37:15 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:15 --> CSRF cookie sent
INFO - 2018-10-16 17:37:15 --> Input Class Initialized
INFO - 2018-10-16 17:37:15 --> Language Class Initialized
INFO - 2018-10-16 17:37:15 --> Loader Class Initialized
INFO - 2018-10-16 17:37:15 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:15 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:15 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:15 --> Controller Class Initialized
INFO - 2018-10-16 17:37:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:15 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:15 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:15 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 17:37:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:15 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:15 --> Total execution time: 0.0329
INFO - 2018-10-16 17:37:18 --> Config Class Initialized
INFO - 2018-10-16 17:37:18 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:18 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:18 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:18 --> URI Class Initialized
INFO - 2018-10-16 17:37:18 --> Router Class Initialized
INFO - 2018-10-16 17:37:18 --> Output Class Initialized
INFO - 2018-10-16 17:37:18 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:18 --> CSRF cookie sent
INFO - 2018-10-16 17:37:18 --> CSRF token verified
INFO - 2018-10-16 17:37:18 --> Input Class Initialized
INFO - 2018-10-16 17:37:18 --> Language Class Initialized
INFO - 2018-10-16 17:37:18 --> Loader Class Initialized
INFO - 2018-10-16 17:37:18 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:18 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:18 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:18 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:19 --> Controller Class Initialized
INFO - 2018-10-16 17:37:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:19 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:19 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:19 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:19 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 17:37:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:19 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:19 --> Total execution time: 0.0433
INFO - 2018-10-16 17:37:23 --> Config Class Initialized
INFO - 2018-10-16 17:37:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:23 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:23 --> URI Class Initialized
INFO - 2018-10-16 17:37:23 --> Router Class Initialized
INFO - 2018-10-16 17:37:23 --> Output Class Initialized
INFO - 2018-10-16 17:37:23 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:23 --> CSRF cookie sent
INFO - 2018-10-16 17:37:23 --> CSRF token verified
INFO - 2018-10-16 17:37:23 --> Input Class Initialized
INFO - 2018-10-16 17:37:23 --> Language Class Initialized
INFO - 2018-10-16 17:37:23 --> Loader Class Initialized
INFO - 2018-10-16 17:37:23 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:23 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:23 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:23 --> Controller Class Initialized
INFO - 2018-10-16 17:37:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:23 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:23 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:23 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:23 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:23 --> Config Class Initialized
INFO - 2018-10-16 17:37:23 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:23 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:23 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:23 --> URI Class Initialized
INFO - 2018-10-16 17:37:23 --> Router Class Initialized
INFO - 2018-10-16 17:37:23 --> Output Class Initialized
INFO - 2018-10-16 17:37:23 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:23 --> CSRF cookie sent
INFO - 2018-10-16 17:37:23 --> Input Class Initialized
INFO - 2018-10-16 17:37:23 --> Language Class Initialized
INFO - 2018-10-16 17:37:23 --> Loader Class Initialized
INFO - 2018-10-16 17:37:23 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:23 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:23 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:23 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:23 --> Controller Class Initialized
INFO - 2018-10-16 17:37:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:23 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:23 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:23 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-16 17:37:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:23 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:23 --> Total execution time: 0.0457
INFO - 2018-10-16 17:37:30 --> Config Class Initialized
INFO - 2018-10-16 17:37:30 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:30 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:30 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:30 --> URI Class Initialized
INFO - 2018-10-16 17:37:30 --> Router Class Initialized
INFO - 2018-10-16 17:37:30 --> Output Class Initialized
INFO - 2018-10-16 17:37:30 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:30 --> CSRF cookie sent
INFO - 2018-10-16 17:37:30 --> CSRF token verified
INFO - 2018-10-16 17:37:30 --> Input Class Initialized
INFO - 2018-10-16 17:37:30 --> Language Class Initialized
INFO - 2018-10-16 17:37:30 --> Loader Class Initialized
INFO - 2018-10-16 17:37:30 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:30 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:30 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:30 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:30 --> Controller Class Initialized
INFO - 2018-10-16 17:37:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:30 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:30 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:30 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:31 --> Config Class Initialized
INFO - 2018-10-16 17:37:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:31 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:31 --> URI Class Initialized
INFO - 2018-10-16 17:37:31 --> Router Class Initialized
INFO - 2018-10-16 17:37:31 --> Output Class Initialized
INFO - 2018-10-16 17:37:31 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:31 --> CSRF cookie sent
INFO - 2018-10-16 17:37:31 --> Input Class Initialized
INFO - 2018-10-16 17:37:31 --> Language Class Initialized
INFO - 2018-10-16 17:37:31 --> Loader Class Initialized
INFO - 2018-10-16 17:37:31 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:31 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:31 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:31 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:31 --> Controller Class Initialized
INFO - 2018-10-16 17:37:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:31 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:31 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:31 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-16 17:37:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:31 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:31 --> Total execution time: 0.0612
INFO - 2018-10-16 17:37:37 --> Config Class Initialized
INFO - 2018-10-16 17:37:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:37 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:37 --> URI Class Initialized
INFO - 2018-10-16 17:37:37 --> Router Class Initialized
INFO - 2018-10-16 17:37:37 --> Output Class Initialized
INFO - 2018-10-16 17:37:37 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:37 --> CSRF cookie sent
INFO - 2018-10-16 17:37:37 --> CSRF token verified
INFO - 2018-10-16 17:37:37 --> Input Class Initialized
INFO - 2018-10-16 17:37:37 --> Language Class Initialized
INFO - 2018-10-16 17:37:37 --> Loader Class Initialized
INFO - 2018-10-16 17:37:37 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:37 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:37 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:37 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:37 --> Controller Class Initialized
INFO - 2018-10-16 17:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:37 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:37 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:37 --> Config Class Initialized
INFO - 2018-10-16 17:37:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:37 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:37 --> URI Class Initialized
INFO - 2018-10-16 17:37:37 --> Router Class Initialized
INFO - 2018-10-16 17:37:37 --> Output Class Initialized
INFO - 2018-10-16 17:37:37 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:37 --> CSRF cookie sent
INFO - 2018-10-16 17:37:37 --> Input Class Initialized
INFO - 2018-10-16 17:37:37 --> Language Class Initialized
INFO - 2018-10-16 17:37:37 --> Loader Class Initialized
INFO - 2018-10-16 17:37:37 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:37 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:37 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:37 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:37 --> Controller Class Initialized
INFO - 2018-10-16 17:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:37 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-16 17:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:37 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:37 --> Total execution time: 0.0448
INFO - 2018-10-16 17:37:44 --> Config Class Initialized
INFO - 2018-10-16 17:37:44 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:44 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:44 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:44 --> URI Class Initialized
INFO - 2018-10-16 17:37:44 --> Router Class Initialized
INFO - 2018-10-16 17:37:44 --> Output Class Initialized
INFO - 2018-10-16 17:37:44 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:44 --> CSRF cookie sent
INFO - 2018-10-16 17:37:44 --> CSRF token verified
INFO - 2018-10-16 17:37:44 --> Input Class Initialized
INFO - 2018-10-16 17:37:44 --> Language Class Initialized
INFO - 2018-10-16 17:37:44 --> Loader Class Initialized
INFO - 2018-10-16 17:37:44 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:44 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:44 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:44 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:44 --> Controller Class Initialized
INFO - 2018-10-16 17:37:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:44 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:44 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:44 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:44 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:45 --> Config Class Initialized
INFO - 2018-10-16 17:37:45 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:45 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:45 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:45 --> URI Class Initialized
INFO - 2018-10-16 17:37:45 --> Router Class Initialized
INFO - 2018-10-16 17:37:45 --> Output Class Initialized
INFO - 2018-10-16 17:37:45 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:45 --> CSRF cookie sent
INFO - 2018-10-16 17:37:45 --> Input Class Initialized
INFO - 2018-10-16 17:37:45 --> Language Class Initialized
INFO - 2018-10-16 17:37:45 --> Loader Class Initialized
INFO - 2018-10-16 17:37:45 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:45 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:45 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:45 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:45 --> Controller Class Initialized
INFO - 2018-10-16 17:37:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:45 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:45 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:45 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-16 17:37:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:45 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:45 --> Total execution time: 0.0481
INFO - 2018-10-16 17:37:48 --> Config Class Initialized
INFO - 2018-10-16 17:37:48 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:48 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:48 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:48 --> URI Class Initialized
INFO - 2018-10-16 17:37:48 --> Router Class Initialized
INFO - 2018-10-16 17:37:48 --> Output Class Initialized
INFO - 2018-10-16 17:37:48 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:48 --> CSRF cookie sent
INFO - 2018-10-16 17:37:48 --> CSRF token verified
INFO - 2018-10-16 17:37:48 --> Input Class Initialized
INFO - 2018-10-16 17:37:48 --> Language Class Initialized
INFO - 2018-10-16 17:37:49 --> Loader Class Initialized
INFO - 2018-10-16 17:37:49 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:49 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:49 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:49 --> Controller Class Initialized
INFO - 2018-10-16 17:37:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:49 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:49 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:49 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:49 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:49 --> Config Class Initialized
INFO - 2018-10-16 17:37:49 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:49 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:49 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:49 --> URI Class Initialized
INFO - 2018-10-16 17:37:49 --> Router Class Initialized
INFO - 2018-10-16 17:37:49 --> Output Class Initialized
INFO - 2018-10-16 17:37:49 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:49 --> CSRF cookie sent
INFO - 2018-10-16 17:37:49 --> Input Class Initialized
INFO - 2018-10-16 17:37:49 --> Language Class Initialized
INFO - 2018-10-16 17:37:49 --> Loader Class Initialized
INFO - 2018-10-16 17:37:49 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:49 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:49 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:49 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:49 --> Controller Class Initialized
INFO - 2018-10-16 17:37:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:49 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:49 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:49 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-16 17:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:49 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:49 --> Total execution time: 0.0456
INFO - 2018-10-16 17:37:59 --> Config Class Initialized
INFO - 2018-10-16 17:37:59 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:59 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:59 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:59 --> URI Class Initialized
INFO - 2018-10-16 17:37:59 --> Router Class Initialized
INFO - 2018-10-16 17:37:59 --> Output Class Initialized
INFO - 2018-10-16 17:37:59 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:59 --> CSRF cookie sent
INFO - 2018-10-16 17:37:59 --> CSRF token verified
INFO - 2018-10-16 17:37:59 --> Input Class Initialized
INFO - 2018-10-16 17:37:59 --> Language Class Initialized
INFO - 2018-10-16 17:37:59 --> Loader Class Initialized
INFO - 2018-10-16 17:37:59 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:59 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:59 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:59 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:59 --> Controller Class Initialized
INFO - 2018-10-16 17:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:59 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:59 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:59 --> Form Validation Class Initialized
INFO - 2018-10-16 17:37:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:37:59 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:59 --> Config Class Initialized
INFO - 2018-10-16 17:37:59 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:37:59 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:37:59 --> Utf8 Class Initialized
INFO - 2018-10-16 17:37:59 --> URI Class Initialized
INFO - 2018-10-16 17:37:59 --> Router Class Initialized
INFO - 2018-10-16 17:37:59 --> Output Class Initialized
INFO - 2018-10-16 17:37:59 --> Security Class Initialized
DEBUG - 2018-10-16 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:37:59 --> CSRF cookie sent
INFO - 2018-10-16 17:37:59 --> Input Class Initialized
INFO - 2018-10-16 17:37:59 --> Language Class Initialized
INFO - 2018-10-16 17:37:59 --> Loader Class Initialized
INFO - 2018-10-16 17:37:59 --> Helper loaded: url_helper
INFO - 2018-10-16 17:37:59 --> Helper loaded: form_helper
INFO - 2018-10-16 17:37:59 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:37:59 --> User Agent Class Initialized
INFO - 2018-10-16 17:37:59 --> Controller Class Initialized
INFO - 2018-10-16 17:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:37:59 --> Pixel_Model class loaded
INFO - 2018-10-16 17:37:59 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:59 --> Database Driver Class Initialized
INFO - 2018-10-16 17:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-16 17:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:37:59 --> Final output sent to browser
DEBUG - 2018-10-16 17:37:59 --> Total execution time: 0.0397
INFO - 2018-10-16 17:38:04 --> Config Class Initialized
INFO - 2018-10-16 17:38:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:38:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:38:04 --> Utf8 Class Initialized
INFO - 2018-10-16 17:38:04 --> URI Class Initialized
INFO - 2018-10-16 17:38:04 --> Router Class Initialized
INFO - 2018-10-16 17:38:04 --> Output Class Initialized
INFO - 2018-10-16 17:38:04 --> Security Class Initialized
DEBUG - 2018-10-16 17:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:38:04 --> CSRF cookie sent
INFO - 2018-10-16 17:38:04 --> CSRF token verified
INFO - 2018-10-16 17:38:04 --> Input Class Initialized
INFO - 2018-10-16 17:38:04 --> Language Class Initialized
INFO - 2018-10-16 17:38:04 --> Loader Class Initialized
INFO - 2018-10-16 17:38:04 --> Helper loaded: url_helper
INFO - 2018-10-16 17:38:04 --> Helper loaded: form_helper
INFO - 2018-10-16 17:38:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:38:04 --> User Agent Class Initialized
INFO - 2018-10-16 17:38:04 --> Controller Class Initialized
INFO - 2018-10-16 17:38:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:38:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:38:04 --> Pixel_Model class loaded
INFO - 2018-10-16 17:38:04 --> Database Driver Class Initialized
INFO - 2018-10-16 17:38:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:38:04 --> Form Validation Class Initialized
INFO - 2018-10-16 17:38:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:38:04 --> Database Driver Class Initialized
INFO - 2018-10-16 17:38:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:38:04 --> Config Class Initialized
INFO - 2018-10-16 17:38:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:38:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:38:04 --> Utf8 Class Initialized
INFO - 2018-10-16 17:38:04 --> URI Class Initialized
INFO - 2018-10-16 17:38:04 --> Router Class Initialized
INFO - 2018-10-16 17:38:04 --> Output Class Initialized
INFO - 2018-10-16 17:38:04 --> Security Class Initialized
DEBUG - 2018-10-16 17:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:38:04 --> CSRF cookie sent
INFO - 2018-10-16 17:38:04 --> Input Class Initialized
INFO - 2018-10-16 17:38:04 --> Language Class Initialized
INFO - 2018-10-16 17:38:04 --> Loader Class Initialized
INFO - 2018-10-16 17:38:04 --> Helper loaded: url_helper
INFO - 2018-10-16 17:38:04 --> Helper loaded: form_helper
INFO - 2018-10-16 17:38:04 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:38:04 --> User Agent Class Initialized
INFO - 2018-10-16 17:38:04 --> Controller Class Initialized
INFO - 2018-10-16 17:38:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:38:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:38:04 --> Pixel_Model class loaded
INFO - 2018-10-16 17:38:04 --> Database Driver Class Initialized
INFO - 2018-10-16 17:38:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:38:04 --> Database Driver Class Initialized
INFO - 2018-10-16 17:38:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-16 17:38:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:38:04 --> Final output sent to browser
DEBUG - 2018-10-16 17:38:04 --> Total execution time: 0.0561
INFO - 2018-10-16 17:38:16 --> Config Class Initialized
INFO - 2018-10-16 17:38:16 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:38:16 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:38:16 --> Utf8 Class Initialized
INFO - 2018-10-16 17:38:16 --> URI Class Initialized
INFO - 2018-10-16 17:38:16 --> Router Class Initialized
INFO - 2018-10-16 17:38:16 --> Output Class Initialized
INFO - 2018-10-16 17:38:16 --> Security Class Initialized
DEBUG - 2018-10-16 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:38:16 --> CSRF cookie sent
INFO - 2018-10-16 17:38:16 --> Input Class Initialized
INFO - 2018-10-16 17:38:16 --> Language Class Initialized
INFO - 2018-10-16 17:38:16 --> Loader Class Initialized
INFO - 2018-10-16 17:38:16 --> Helper loaded: url_helper
INFO - 2018-10-16 17:38:16 --> Helper loaded: form_helper
INFO - 2018-10-16 17:38:16 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:38:16 --> User Agent Class Initialized
INFO - 2018-10-16 17:38:16 --> Controller Class Initialized
INFO - 2018-10-16 17:38:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:38:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:38:16 --> Pixel_Model class loaded
INFO - 2018-10-16 17:38:16 --> Database Driver Class Initialized
INFO - 2018-10-16 17:38:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-16 17:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:38:16 --> Final output sent to browser
DEBUG - 2018-10-16 17:38:16 --> Total execution time: 0.0490
INFO - 2018-10-16 17:48:37 --> Config Class Initialized
INFO - 2018-10-16 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:48:37 --> Utf8 Class Initialized
INFO - 2018-10-16 17:48:37 --> URI Class Initialized
INFO - 2018-10-16 17:48:37 --> Router Class Initialized
INFO - 2018-10-16 17:48:37 --> Output Class Initialized
INFO - 2018-10-16 17:48:37 --> Security Class Initialized
DEBUG - 2018-10-16 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:48:37 --> CSRF cookie sent
INFO - 2018-10-16 17:48:37 --> CSRF token verified
INFO - 2018-10-16 17:48:37 --> Input Class Initialized
INFO - 2018-10-16 17:48:37 --> Language Class Initialized
INFO - 2018-10-16 17:48:37 --> Loader Class Initialized
INFO - 2018-10-16 17:48:37 --> Helper loaded: url_helper
INFO - 2018-10-16 17:48:37 --> Helper loaded: form_helper
INFO - 2018-10-16 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:48:37 --> User Agent Class Initialized
INFO - 2018-10-16 17:48:37 --> Controller Class Initialized
INFO - 2018-10-16 17:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:48:37 --> Pixel_Model class loaded
INFO - 2018-10-16 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:48:37 --> Form Validation Class Initialized
INFO - 2018-10-16 17:48:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:48:37 --> Config Class Initialized
INFO - 2018-10-16 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:48:37 --> Utf8 Class Initialized
INFO - 2018-10-16 17:48:37 --> URI Class Initialized
INFO - 2018-10-16 17:48:37 --> Router Class Initialized
INFO - 2018-10-16 17:48:37 --> Output Class Initialized
INFO - 2018-10-16 17:48:37 --> Security Class Initialized
DEBUG - 2018-10-16 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:48:37 --> CSRF cookie sent
INFO - 2018-10-16 17:48:37 --> Input Class Initialized
INFO - 2018-10-16 17:48:37 --> Language Class Initialized
INFO - 2018-10-16 17:48:37 --> Loader Class Initialized
INFO - 2018-10-16 17:48:37 --> Helper loaded: url_helper
INFO - 2018-10-16 17:48:37 --> Helper loaded: form_helper
INFO - 2018-10-16 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:48:37 --> User Agent Class Initialized
INFO - 2018-10-16 17:48:37 --> Controller Class Initialized
INFO - 2018-10-16 17:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:48:37 --> Pixel_Model class loaded
INFO - 2018-10-16 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-16 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:48:37 --> Final output sent to browser
DEBUG - 2018-10-16 17:48:37 --> Total execution time: 0.0411
INFO - 2018-10-16 17:49:05 --> Config Class Initialized
INFO - 2018-10-16 17:49:05 --> Hooks Class Initialized
DEBUG - 2018-10-16 17:49:05 --> UTF-8 Support Enabled
INFO - 2018-10-16 17:49:05 --> Utf8 Class Initialized
INFO - 2018-10-16 17:49:05 --> URI Class Initialized
INFO - 2018-10-16 17:49:05 --> Router Class Initialized
INFO - 2018-10-16 17:49:05 --> Output Class Initialized
INFO - 2018-10-16 17:49:05 --> Security Class Initialized
DEBUG - 2018-10-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 17:49:05 --> CSRF cookie sent
INFO - 2018-10-16 17:49:05 --> Input Class Initialized
INFO - 2018-10-16 17:49:05 --> Language Class Initialized
INFO - 2018-10-16 17:49:05 --> Loader Class Initialized
INFO - 2018-10-16 17:49:05 --> Helper loaded: url_helper
INFO - 2018-10-16 17:49:05 --> Helper loaded: form_helper
INFO - 2018-10-16 17:49:05 --> Helper loaded: language_helper
DEBUG - 2018-10-16 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 17:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 17:49:05 --> User Agent Class Initialized
INFO - 2018-10-16 17:49:05 --> Controller Class Initialized
INFO - 2018-10-16 17:49:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 17:49:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 17:49:05 --> Pixel_Model class loaded
INFO - 2018-10-16 17:49:05 --> Database Driver Class Initialized
INFO - 2018-10-16 17:49:05 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-16 17:49:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-16 17:49:05 --> Could not find the language line "req_email"
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-16 17:49:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 17:49:05 --> Final output sent to browser
DEBUG - 2018-10-16 17:49:05 --> Total execution time: 0.0402
INFO - 2018-10-16 18:14:26 --> Config Class Initialized
INFO - 2018-10-16 18:14:26 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:26 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:26 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:26 --> URI Class Initialized
DEBUG - 2018-10-16 18:14:26 --> No URI present. Default controller set.
INFO - 2018-10-16 18:14:26 --> Router Class Initialized
INFO - 2018-10-16 18:14:26 --> Output Class Initialized
INFO - 2018-10-16 18:14:26 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:26 --> CSRF cookie sent
INFO - 2018-10-16 18:14:26 --> Input Class Initialized
INFO - 2018-10-16 18:14:26 --> Language Class Initialized
INFO - 2018-10-16 18:14:26 --> Loader Class Initialized
INFO - 2018-10-16 18:14:26 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:26 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:26 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:26 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:26 --> Controller Class Initialized
INFO - 2018-10-16 18:14:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:26 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:26 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 18:14:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:26 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:26 --> Total execution time: 0.0377
INFO - 2018-10-16 18:14:27 --> Config Class Initialized
INFO - 2018-10-16 18:14:27 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:27 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:27 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:27 --> URI Class Initialized
DEBUG - 2018-10-16 18:14:27 --> No URI present. Default controller set.
INFO - 2018-10-16 18:14:27 --> Router Class Initialized
INFO - 2018-10-16 18:14:27 --> Output Class Initialized
INFO - 2018-10-16 18:14:27 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:27 --> CSRF cookie sent
INFO - 2018-10-16 18:14:27 --> Input Class Initialized
INFO - 2018-10-16 18:14:27 --> Language Class Initialized
INFO - 2018-10-16 18:14:27 --> Loader Class Initialized
INFO - 2018-10-16 18:14:27 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:27 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:27 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:27 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:27 --> Controller Class Initialized
INFO - 2018-10-16 18:14:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:27 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:27 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 18:14:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:27 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:27 --> Total execution time: 0.0379
INFO - 2018-10-16 18:14:32 --> Config Class Initialized
INFO - 2018-10-16 18:14:32 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:32 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:32 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:32 --> URI Class Initialized
INFO - 2018-10-16 18:14:32 --> Router Class Initialized
INFO - 2018-10-16 18:14:32 --> Output Class Initialized
INFO - 2018-10-16 18:14:32 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:32 --> CSRF cookie sent
INFO - 2018-10-16 18:14:32 --> CSRF token verified
INFO - 2018-10-16 18:14:32 --> Input Class Initialized
INFO - 2018-10-16 18:14:32 --> Language Class Initialized
INFO - 2018-10-16 18:14:32 --> Loader Class Initialized
INFO - 2018-10-16 18:14:32 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:32 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:32 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:32 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:32 --> Controller Class Initialized
INFO - 2018-10-16 18:14:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:32 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:32 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:32 --> Form Validation Class Initialized
INFO - 2018-10-16 18:14:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:14:32 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:32 --> Config Class Initialized
INFO - 2018-10-16 18:14:32 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:32 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:32 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:32 --> URI Class Initialized
INFO - 2018-10-16 18:14:32 --> Router Class Initialized
INFO - 2018-10-16 18:14:32 --> Output Class Initialized
INFO - 2018-10-16 18:14:32 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:32 --> CSRF cookie sent
INFO - 2018-10-16 18:14:32 --> Input Class Initialized
INFO - 2018-10-16 18:14:32 --> Language Class Initialized
INFO - 2018-10-16 18:14:33 --> Loader Class Initialized
INFO - 2018-10-16 18:14:33 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:33 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:33 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:33 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:33 --> Controller Class Initialized
INFO - 2018-10-16 18:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:33 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:33 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:33 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-16 18:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:33 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:33 --> Total execution time: 0.0456
INFO - 2018-10-16 18:14:39 --> Config Class Initialized
INFO - 2018-10-16 18:14:39 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:39 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:39 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:39 --> URI Class Initialized
INFO - 2018-10-16 18:14:39 --> Router Class Initialized
INFO - 2018-10-16 18:14:39 --> Output Class Initialized
INFO - 2018-10-16 18:14:39 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:39 --> CSRF cookie sent
INFO - 2018-10-16 18:14:39 --> CSRF token verified
INFO - 2018-10-16 18:14:39 --> Input Class Initialized
INFO - 2018-10-16 18:14:39 --> Language Class Initialized
INFO - 2018-10-16 18:14:40 --> Loader Class Initialized
INFO - 2018-10-16 18:14:40 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:40 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:40 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:40 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:40 --> Controller Class Initialized
INFO - 2018-10-16 18:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:40 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:40 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:40 --> Form Validation Class Initialized
INFO - 2018-10-16 18:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:14:40 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:40 --> Config Class Initialized
INFO - 2018-10-16 18:14:40 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:40 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:40 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:40 --> URI Class Initialized
INFO - 2018-10-16 18:14:40 --> Router Class Initialized
INFO - 2018-10-16 18:14:40 --> Output Class Initialized
INFO - 2018-10-16 18:14:40 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:40 --> CSRF cookie sent
INFO - 2018-10-16 18:14:40 --> Input Class Initialized
INFO - 2018-10-16 18:14:40 --> Language Class Initialized
INFO - 2018-10-16 18:14:40 --> Loader Class Initialized
INFO - 2018-10-16 18:14:40 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:40 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:40 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:40 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:40 --> Controller Class Initialized
INFO - 2018-10-16 18:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:40 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:40 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:40 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-16 18:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:40 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:40 --> Total execution time: 0.0483
INFO - 2018-10-16 18:14:41 --> Config Class Initialized
INFO - 2018-10-16 18:14:41 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:41 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:41 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:41 --> URI Class Initialized
INFO - 2018-10-16 18:14:41 --> Router Class Initialized
INFO - 2018-10-16 18:14:41 --> Output Class Initialized
INFO - 2018-10-16 18:14:41 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:41 --> CSRF cookie sent
INFO - 2018-10-16 18:14:41 --> CSRF token verified
INFO - 2018-10-16 18:14:41 --> Input Class Initialized
INFO - 2018-10-16 18:14:41 --> Language Class Initialized
INFO - 2018-10-16 18:14:41 --> Loader Class Initialized
INFO - 2018-10-16 18:14:41 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:41 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:41 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:41 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:41 --> Controller Class Initialized
INFO - 2018-10-16 18:14:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:41 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:41 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:41 --> Form Validation Class Initialized
INFO - 2018-10-16 18:14:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:14:41 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:41 --> Config Class Initialized
INFO - 2018-10-16 18:14:41 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:41 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:41 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:41 --> URI Class Initialized
INFO - 2018-10-16 18:14:41 --> Router Class Initialized
INFO - 2018-10-16 18:14:41 --> Output Class Initialized
INFO - 2018-10-16 18:14:41 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:41 --> CSRF cookie sent
INFO - 2018-10-16 18:14:41 --> Input Class Initialized
INFO - 2018-10-16 18:14:41 --> Language Class Initialized
INFO - 2018-10-16 18:14:41 --> Loader Class Initialized
INFO - 2018-10-16 18:14:41 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:41 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:41 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:41 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:41 --> Controller Class Initialized
INFO - 2018-10-16 18:14:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:41 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:41 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:41 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-16 18:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:41 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:41 --> Total execution time: 0.0381
INFO - 2018-10-16 18:14:44 --> Config Class Initialized
INFO - 2018-10-16 18:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:44 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:44 --> URI Class Initialized
INFO - 2018-10-16 18:14:44 --> Router Class Initialized
INFO - 2018-10-16 18:14:44 --> Output Class Initialized
INFO - 2018-10-16 18:14:44 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:44 --> CSRF cookie sent
INFO - 2018-10-16 18:14:44 --> CSRF token verified
INFO - 2018-10-16 18:14:44 --> Input Class Initialized
INFO - 2018-10-16 18:14:44 --> Language Class Initialized
INFO - 2018-10-16 18:14:44 --> Loader Class Initialized
INFO - 2018-10-16 18:14:44 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:44 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:44 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:44 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:44 --> Controller Class Initialized
INFO - 2018-10-16 18:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:44 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:44 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:44 --> Form Validation Class Initialized
INFO - 2018-10-16 18:14:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:14:44 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:44 --> Config Class Initialized
INFO - 2018-10-16 18:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:14:44 --> Utf8 Class Initialized
INFO - 2018-10-16 18:14:44 --> URI Class Initialized
INFO - 2018-10-16 18:14:44 --> Router Class Initialized
INFO - 2018-10-16 18:14:44 --> Output Class Initialized
INFO - 2018-10-16 18:14:44 --> Security Class Initialized
DEBUG - 2018-10-16 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:14:44 --> CSRF cookie sent
INFO - 2018-10-16 18:14:44 --> Input Class Initialized
INFO - 2018-10-16 18:14:44 --> Language Class Initialized
INFO - 2018-10-16 18:14:44 --> Loader Class Initialized
INFO - 2018-10-16 18:14:44 --> Helper loaded: url_helper
INFO - 2018-10-16 18:14:44 --> Helper loaded: form_helper
INFO - 2018-10-16 18:14:44 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:14:44 --> User Agent Class Initialized
INFO - 2018-10-16 18:14:44 --> Controller Class Initialized
INFO - 2018-10-16 18:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:14:44 --> Pixel_Model class loaded
INFO - 2018-10-16 18:14:44 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:44 --> Database Driver Class Initialized
INFO - 2018-10-16 18:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 18:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:14:44 --> Final output sent to browser
DEBUG - 2018-10-16 18:14:44 --> Total execution time: 0.0402
INFO - 2018-10-16 18:15:01 --> Config Class Initialized
INFO - 2018-10-16 18:15:01 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:01 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:01 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:01 --> URI Class Initialized
INFO - 2018-10-16 18:15:01 --> Router Class Initialized
INFO - 2018-10-16 18:15:01 --> Output Class Initialized
INFO - 2018-10-16 18:15:01 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:01 --> CSRF cookie sent
INFO - 2018-10-16 18:15:01 --> Input Class Initialized
INFO - 2018-10-16 18:15:01 --> Language Class Initialized
INFO - 2018-10-16 18:15:01 --> Loader Class Initialized
INFO - 2018-10-16 18:15:01 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:01 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:01 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:01 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:01 --> Controller Class Initialized
INFO - 2018-10-16 18:15:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:01 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:01 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:01 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-16 18:15:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:15:01 --> Final output sent to browser
DEBUG - 2018-10-16 18:15:01 --> Total execution time: 0.0474
INFO - 2018-10-16 18:15:02 --> Config Class Initialized
INFO - 2018-10-16 18:15:02 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:02 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:02 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:03 --> URI Class Initialized
INFO - 2018-10-16 18:15:03 --> Router Class Initialized
INFO - 2018-10-16 18:15:03 --> Output Class Initialized
INFO - 2018-10-16 18:15:03 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:03 --> CSRF cookie sent
INFO - 2018-10-16 18:15:03 --> Input Class Initialized
INFO - 2018-10-16 18:15:03 --> Language Class Initialized
INFO - 2018-10-16 18:15:03 --> Loader Class Initialized
INFO - 2018-10-16 18:15:03 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:03 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:03 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:03 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:03 --> Controller Class Initialized
INFO - 2018-10-16 18:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:03 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:03 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:03 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-16 18:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:15:03 --> Final output sent to browser
DEBUG - 2018-10-16 18:15:03 --> Total execution time: 0.2806
INFO - 2018-10-16 18:15:09 --> Config Class Initialized
INFO - 2018-10-16 18:15:09 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:09 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:09 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:09 --> URI Class Initialized
INFO - 2018-10-16 18:15:09 --> Router Class Initialized
INFO - 2018-10-16 18:15:09 --> Output Class Initialized
INFO - 2018-10-16 18:15:09 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:09 --> CSRF cookie sent
INFO - 2018-10-16 18:15:09 --> CSRF token verified
INFO - 2018-10-16 18:15:09 --> Input Class Initialized
INFO - 2018-10-16 18:15:09 --> Language Class Initialized
INFO - 2018-10-16 18:15:09 --> Loader Class Initialized
INFO - 2018-10-16 18:15:09 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:09 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:09 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:09 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:09 --> Controller Class Initialized
INFO - 2018-10-16 18:15:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:09 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:09 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:09 --> Form Validation Class Initialized
INFO - 2018-10-16 18:15:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:15:09 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:09 --> Config Class Initialized
INFO - 2018-10-16 18:15:09 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:09 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:09 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:09 --> URI Class Initialized
INFO - 2018-10-16 18:15:09 --> Router Class Initialized
INFO - 2018-10-16 18:15:09 --> Output Class Initialized
INFO - 2018-10-16 18:15:09 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:09 --> CSRF cookie sent
INFO - 2018-10-16 18:15:09 --> Input Class Initialized
INFO - 2018-10-16 18:15:09 --> Language Class Initialized
INFO - 2018-10-16 18:15:09 --> Loader Class Initialized
INFO - 2018-10-16 18:15:09 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:09 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:09 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:09 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:09 --> Controller Class Initialized
INFO - 2018-10-16 18:15:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:09 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:09 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:09 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-16 18:15:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:15:09 --> Final output sent to browser
DEBUG - 2018-10-16 18:15:09 --> Total execution time: 0.0414
INFO - 2018-10-16 18:15:15 --> Config Class Initialized
INFO - 2018-10-16 18:15:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:15 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:15 --> URI Class Initialized
INFO - 2018-10-16 18:15:15 --> Router Class Initialized
INFO - 2018-10-16 18:15:15 --> Output Class Initialized
INFO - 2018-10-16 18:15:15 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:15 --> CSRF cookie sent
INFO - 2018-10-16 18:15:15 --> CSRF token verified
INFO - 2018-10-16 18:15:15 --> Input Class Initialized
INFO - 2018-10-16 18:15:15 --> Language Class Initialized
INFO - 2018-10-16 18:15:15 --> Loader Class Initialized
INFO - 2018-10-16 18:15:15 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:15 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:15 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:15 --> Controller Class Initialized
INFO - 2018-10-16 18:15:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:15 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:15 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:15 --> Form Validation Class Initialized
INFO - 2018-10-16 18:15:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 18:15:15 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:15 --> Config Class Initialized
INFO - 2018-10-16 18:15:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:15 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:15 --> URI Class Initialized
INFO - 2018-10-16 18:15:15 --> Router Class Initialized
INFO - 2018-10-16 18:15:15 --> Output Class Initialized
INFO - 2018-10-16 18:15:15 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:15 --> CSRF cookie sent
INFO - 2018-10-16 18:15:15 --> Input Class Initialized
INFO - 2018-10-16 18:15:15 --> Language Class Initialized
INFO - 2018-10-16 18:15:15 --> Loader Class Initialized
INFO - 2018-10-16 18:15:15 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:15 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:15 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:15 --> Controller Class Initialized
INFO - 2018-10-16 18:15:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:15 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:15 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:15 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-16 18:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:15:15 --> Final output sent to browser
DEBUG - 2018-10-16 18:15:15 --> Total execution time: 0.0396
INFO - 2018-10-16 18:15:16 --> Config Class Initialized
INFO - 2018-10-16 18:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:15:16 --> Utf8 Class Initialized
INFO - 2018-10-16 18:15:16 --> URI Class Initialized
INFO - 2018-10-16 18:15:16 --> Router Class Initialized
INFO - 2018-10-16 18:15:16 --> Output Class Initialized
INFO - 2018-10-16 18:15:16 --> Security Class Initialized
DEBUG - 2018-10-16 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:15:16 --> CSRF cookie sent
INFO - 2018-10-16 18:15:16 --> Input Class Initialized
INFO - 2018-10-16 18:15:16 --> Language Class Initialized
INFO - 2018-10-16 18:15:16 --> Loader Class Initialized
INFO - 2018-10-16 18:15:16 --> Helper loaded: url_helper
INFO - 2018-10-16 18:15:16 --> Helper loaded: form_helper
INFO - 2018-10-16 18:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:15:16 --> User Agent Class Initialized
INFO - 2018-10-16 18:15:16 --> Controller Class Initialized
INFO - 2018-10-16 18:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:15:16 --> Pixel_Model class loaded
INFO - 2018-10-16 18:15:16 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:16 --> Database Driver Class Initialized
INFO - 2018-10-16 18:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-16 18:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:15:16 --> Final output sent to browser
DEBUG - 2018-10-16 18:15:16 --> Total execution time: 0.0556
INFO - 2018-10-16 18:32:13 --> Config Class Initialized
INFO - 2018-10-16 18:32:13 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:32:13 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:32:13 --> Utf8 Class Initialized
INFO - 2018-10-16 18:32:13 --> URI Class Initialized
DEBUG - 2018-10-16 18:32:13 --> No URI present. Default controller set.
INFO - 2018-10-16 18:32:13 --> Router Class Initialized
INFO - 2018-10-16 18:32:13 --> Output Class Initialized
INFO - 2018-10-16 18:32:13 --> Security Class Initialized
DEBUG - 2018-10-16 18:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:32:13 --> CSRF cookie sent
INFO - 2018-10-16 18:32:13 --> Input Class Initialized
INFO - 2018-10-16 18:32:13 --> Language Class Initialized
INFO - 2018-10-16 18:32:13 --> Loader Class Initialized
INFO - 2018-10-16 18:32:13 --> Helper loaded: url_helper
INFO - 2018-10-16 18:32:13 --> Helper loaded: form_helper
INFO - 2018-10-16 18:32:13 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:32:13 --> User Agent Class Initialized
INFO - 2018-10-16 18:32:13 --> Controller Class Initialized
INFO - 2018-10-16 18:32:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:32:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:32:13 --> Pixel_Model class loaded
INFO - 2018-10-16 18:32:13 --> Database Driver Class Initialized
INFO - 2018-10-16 18:32:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 18:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:32:13 --> Final output sent to browser
DEBUG - 2018-10-16 18:32:13 --> Total execution time: 0.0427
INFO - 2018-10-16 18:32:15 --> Config Class Initialized
INFO - 2018-10-16 18:32:15 --> Hooks Class Initialized
DEBUG - 2018-10-16 18:32:15 --> UTF-8 Support Enabled
INFO - 2018-10-16 18:32:15 --> Utf8 Class Initialized
INFO - 2018-10-16 18:32:15 --> URI Class Initialized
DEBUG - 2018-10-16 18:32:15 --> No URI present. Default controller set.
INFO - 2018-10-16 18:32:15 --> Router Class Initialized
INFO - 2018-10-16 18:32:15 --> Output Class Initialized
INFO - 2018-10-16 18:32:15 --> Security Class Initialized
DEBUG - 2018-10-16 18:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 18:32:15 --> CSRF cookie sent
INFO - 2018-10-16 18:32:15 --> Input Class Initialized
INFO - 2018-10-16 18:32:15 --> Language Class Initialized
INFO - 2018-10-16 18:32:15 --> Loader Class Initialized
INFO - 2018-10-16 18:32:15 --> Helper loaded: url_helper
INFO - 2018-10-16 18:32:15 --> Helper loaded: form_helper
INFO - 2018-10-16 18:32:15 --> Helper loaded: language_helper
DEBUG - 2018-10-16 18:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 18:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 18:32:15 --> User Agent Class Initialized
INFO - 2018-10-16 18:32:15 --> Controller Class Initialized
INFO - 2018-10-16 18:32:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-16 18:32:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-16 18:32:15 --> Pixel_Model class loaded
INFO - 2018-10-16 18:32:15 --> Database Driver Class Initialized
INFO - 2018-10-16 18:32:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-16 18:32:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-16 18:32:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-16 18:32:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-16 18:32:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-16 18:32:15 --> Final output sent to browser
DEBUG - 2018-10-16 18:32:15 --> Total execution time: 0.0430

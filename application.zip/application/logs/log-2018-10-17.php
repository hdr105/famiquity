<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-17 13:48:42 --> Config Class Initialized
INFO - 2018-10-17 13:48:42 --> Hooks Class Initialized
DEBUG - 2018-10-17 13:48:42 --> UTF-8 Support Enabled
INFO - 2018-10-17 13:48:42 --> Utf8 Class Initialized
INFO - 2018-10-17 13:48:42 --> URI Class Initialized
INFO - 2018-10-17 13:48:42 --> Router Class Initialized
INFO - 2018-10-17 13:48:42 --> Output Class Initialized
INFO - 2018-10-17 13:48:42 --> Security Class Initialized
DEBUG - 2018-10-17 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 13:48:42 --> CSRF cookie sent
INFO - 2018-10-17 13:48:42 --> Input Class Initialized
INFO - 2018-10-17 13:48:42 --> Language Class Initialized
INFO - 2018-10-17 13:48:42 --> Loader Class Initialized
INFO - 2018-10-17 13:48:42 --> Helper loaded: url_helper
INFO - 2018-10-17 13:48:42 --> Helper loaded: form_helper
INFO - 2018-10-17 13:48:42 --> Helper loaded: language_helper
DEBUG - 2018-10-17 13:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 13:48:42 --> User Agent Class Initialized
INFO - 2018-10-17 13:48:42 --> Controller Class Initialized
INFO - 2018-10-17 13:48:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 13:48:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 13:48:42 --> Pixel_Model class loaded
INFO - 2018-10-17 13:48:42 --> Database Driver Class Initialized
INFO - 2018-10-17 13:48:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 13:48:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-17 13:48:42 --> Could not find the language line "req_email"
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 13:48:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 13:48:42 --> Final output sent to browser
DEBUG - 2018-10-17 13:48:42 --> Total execution time: 0.0350
INFO - 2018-10-17 14:19:31 --> Config Class Initialized
INFO - 2018-10-17 14:19:31 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:19:31 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:19:31 --> Utf8 Class Initialized
INFO - 2018-10-17 14:19:31 --> URI Class Initialized
INFO - 2018-10-17 14:19:31 --> Router Class Initialized
INFO - 2018-10-17 14:19:31 --> Output Class Initialized
INFO - 2018-10-17 14:19:31 --> Security Class Initialized
DEBUG - 2018-10-17 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:19:31 --> CSRF cookie sent
INFO - 2018-10-17 14:19:31 --> Input Class Initialized
INFO - 2018-10-17 14:19:31 --> Language Class Initialized
INFO - 2018-10-17 14:19:31 --> Loader Class Initialized
INFO - 2018-10-17 14:19:31 --> Helper loaded: url_helper
INFO - 2018-10-17 14:19:31 --> Helper loaded: form_helper
INFO - 2018-10-17 14:19:31 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:19:31 --> User Agent Class Initialized
INFO - 2018-10-17 14:19:31 --> Controller Class Initialized
INFO - 2018-10-17 14:19:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:19:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:19:31 --> Pixel_Model class loaded
INFO - 2018-10-17 14:19:31 --> Database Driver Class Initialized
INFO - 2018-10-17 14:19:31 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 14:19:31 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-17 14:19:31 --> Could not find the language line "req_email"
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 14:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:19:31 --> Final output sent to browser
DEBUG - 2018-10-17 14:19:31 --> Total execution time: 0.0483
INFO - 2018-10-17 14:22:40 --> Config Class Initialized
INFO - 2018-10-17 14:22:40 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:22:40 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:22:40 --> Utf8 Class Initialized
INFO - 2018-10-17 14:22:40 --> URI Class Initialized
INFO - 2018-10-17 14:22:40 --> Router Class Initialized
INFO - 2018-10-17 14:22:40 --> Output Class Initialized
INFO - 2018-10-17 14:22:40 --> Security Class Initialized
DEBUG - 2018-10-17 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:22:40 --> CSRF cookie sent
INFO - 2018-10-17 14:22:40 --> Input Class Initialized
INFO - 2018-10-17 14:22:40 --> Language Class Initialized
ERROR - 2018-10-17 14:22:40 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 14:29:10 --> Config Class Initialized
INFO - 2018-10-17 14:29:10 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:29:10 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:29:10 --> Utf8 Class Initialized
INFO - 2018-10-17 14:29:10 --> URI Class Initialized
INFO - 2018-10-17 14:29:10 --> Router Class Initialized
INFO - 2018-10-17 14:29:10 --> Output Class Initialized
INFO - 2018-10-17 14:29:10 --> Security Class Initialized
DEBUG - 2018-10-17 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:29:10 --> CSRF cookie sent
INFO - 2018-10-17 14:29:10 --> Input Class Initialized
INFO - 2018-10-17 14:29:10 --> Language Class Initialized
INFO - 2018-10-17 14:29:10 --> Loader Class Initialized
INFO - 2018-10-17 14:29:10 --> Helper loaded: url_helper
INFO - 2018-10-17 14:29:10 --> Helper loaded: form_helper
INFO - 2018-10-17 14:29:10 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:29:10 --> User Agent Class Initialized
INFO - 2018-10-17 14:29:10 --> Controller Class Initialized
INFO - 2018-10-17 14:29:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:29:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:29:10 --> Pixel_Model class loaded
INFO - 2018-10-17 14:29:10 --> Database Driver Class Initialized
INFO - 2018-10-17 14:29:10 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 14:29:10 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-17 14:29:10 --> Could not find the language line "req_email"
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 14:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:29:10 --> Final output sent to browser
DEBUG - 2018-10-17 14:29:10 --> Total execution time: 0.0403
INFO - 2018-10-17 14:29:19 --> Config Class Initialized
INFO - 2018-10-17 14:29:19 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:29:19 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:29:19 --> Utf8 Class Initialized
INFO - 2018-10-17 14:29:19 --> URI Class Initialized
INFO - 2018-10-17 14:29:19 --> Router Class Initialized
INFO - 2018-10-17 14:29:19 --> Output Class Initialized
INFO - 2018-10-17 14:29:19 --> Security Class Initialized
DEBUG - 2018-10-17 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:29:19 --> CSRF cookie sent
INFO - 2018-10-17 14:29:19 --> Input Class Initialized
INFO - 2018-10-17 14:29:19 --> Language Class Initialized
ERROR - 2018-10-17 14:29:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 14:31:44 --> Config Class Initialized
INFO - 2018-10-17 14:31:44 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:31:44 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:31:44 --> Utf8 Class Initialized
INFO - 2018-10-17 14:31:44 --> URI Class Initialized
INFO - 2018-10-17 14:31:44 --> Router Class Initialized
INFO - 2018-10-17 14:31:44 --> Output Class Initialized
INFO - 2018-10-17 14:31:44 --> Security Class Initialized
DEBUG - 2018-10-17 14:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:31:44 --> CSRF cookie sent
INFO - 2018-10-17 14:31:44 --> Input Class Initialized
INFO - 2018-10-17 14:31:44 --> Language Class Initialized
INFO - 2018-10-17 14:31:44 --> Loader Class Initialized
INFO - 2018-10-17 14:31:44 --> Helper loaded: url_helper
INFO - 2018-10-17 14:31:44 --> Helper loaded: form_helper
INFO - 2018-10-17 14:31:44 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:31:44 --> User Agent Class Initialized
INFO - 2018-10-17 14:31:44 --> Controller Class Initialized
INFO - 2018-10-17 14:31:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:31:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:31:44 --> Pixel_Model class loaded
INFO - 2018-10-17 14:31:44 --> Database Driver Class Initialized
INFO - 2018-10-17 14:31:44 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 14:31:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-17 14:31:44 --> Could not find the language line "req_email"
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 14:31:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:31:44 --> Final output sent to browser
DEBUG - 2018-10-17 14:31:44 --> Total execution time: 0.0370
INFO - 2018-10-17 14:31:52 --> Config Class Initialized
INFO - 2018-10-17 14:31:52 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:31:52 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:31:52 --> Utf8 Class Initialized
INFO - 2018-10-17 14:31:52 --> URI Class Initialized
INFO - 2018-10-17 14:31:52 --> Router Class Initialized
INFO - 2018-10-17 14:31:52 --> Output Class Initialized
INFO - 2018-10-17 14:31:52 --> Security Class Initialized
DEBUG - 2018-10-17 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:31:52 --> CSRF cookie sent
INFO - 2018-10-17 14:31:52 --> Input Class Initialized
INFO - 2018-10-17 14:31:52 --> Language Class Initialized
INFO - 2018-10-17 14:31:52 --> Loader Class Initialized
INFO - 2018-10-17 14:31:52 --> Helper loaded: url_helper
INFO - 2018-10-17 14:31:52 --> Helper loaded: form_helper
INFO - 2018-10-17 14:31:52 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:31:52 --> User Agent Class Initialized
INFO - 2018-10-17 14:31:52 --> Controller Class Initialized
INFO - 2018-10-17 14:31:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:31:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:31:52 --> Pixel_Model class loaded
INFO - 2018-10-17 14:31:52 --> Database Driver Class Initialized
INFO - 2018-10-17 14:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-17 14:31:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:31:52 --> Final output sent to browser
DEBUG - 2018-10-17 14:31:52 --> Total execution time: 0.0405
INFO - 2018-10-17 14:49:26 --> Config Class Initialized
INFO - 2018-10-17 14:49:26 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:26 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:26 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:26 --> URI Class Initialized
INFO - 2018-10-17 14:49:26 --> Router Class Initialized
INFO - 2018-10-17 14:49:26 --> Output Class Initialized
INFO - 2018-10-17 14:49:26 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:26 --> CSRF cookie sent
INFO - 2018-10-17 14:49:26 --> Input Class Initialized
INFO - 2018-10-17 14:49:26 --> Language Class Initialized
INFO - 2018-10-17 14:49:26 --> Loader Class Initialized
INFO - 2018-10-17 14:49:26 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:26 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:26 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:26 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:26 --> Controller Class Initialized
INFO - 2018-10-17 14:49:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:26 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:26 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-17 14:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:26 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:26 --> Total execution time: 0.0391
INFO - 2018-10-17 14:49:32 --> Config Class Initialized
INFO - 2018-10-17 14:49:32 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:32 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:32 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:32 --> URI Class Initialized
INFO - 2018-10-17 14:49:32 --> Router Class Initialized
INFO - 2018-10-17 14:49:32 --> Output Class Initialized
INFO - 2018-10-17 14:49:32 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:32 --> CSRF cookie sent
INFO - 2018-10-17 14:49:32 --> Input Class Initialized
INFO - 2018-10-17 14:49:32 --> Language Class Initialized
INFO - 2018-10-17 14:49:32 --> Loader Class Initialized
INFO - 2018-10-17 14:49:32 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:32 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:32 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:32 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:32 --> Controller Class Initialized
INFO - 2018-10-17 14:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:32 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:32 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-17 14:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:32 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:32 --> Total execution time: 0.0500
INFO - 2018-10-17 14:49:36 --> Config Class Initialized
INFO - 2018-10-17 14:49:36 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:36 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:36 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:36 --> URI Class Initialized
INFO - 2018-10-17 14:49:36 --> Router Class Initialized
INFO - 2018-10-17 14:49:36 --> Output Class Initialized
INFO - 2018-10-17 14:49:36 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:36 --> CSRF cookie sent
INFO - 2018-10-17 14:49:36 --> CSRF token verified
INFO - 2018-10-17 14:49:36 --> Input Class Initialized
INFO - 2018-10-17 14:49:36 --> Language Class Initialized
INFO - 2018-10-17 14:49:37 --> Loader Class Initialized
INFO - 2018-10-17 14:49:37 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:37 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:37 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:37 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:37 --> Controller Class Initialized
INFO - 2018-10-17 14:49:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:37 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:37 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:37 --> Form Validation Class Initialized
INFO - 2018-10-17 14:49:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 14:49:37 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:37 --> Config Class Initialized
INFO - 2018-10-17 14:49:37 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:37 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:37 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:37 --> URI Class Initialized
INFO - 2018-10-17 14:49:37 --> Router Class Initialized
INFO - 2018-10-17 14:49:37 --> Output Class Initialized
INFO - 2018-10-17 14:49:37 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:37 --> CSRF cookie sent
INFO - 2018-10-17 14:49:37 --> Input Class Initialized
INFO - 2018-10-17 14:49:37 --> Language Class Initialized
INFO - 2018-10-17 14:49:37 --> Loader Class Initialized
INFO - 2018-10-17 14:49:37 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:37 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:37 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:37 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:37 --> Controller Class Initialized
INFO - 2018-10-17 14:49:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:37 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:37 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:37 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-17 14:49:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:37 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:37 --> Total execution time: 0.0433
INFO - 2018-10-17 14:49:41 --> Config Class Initialized
INFO - 2018-10-17 14:49:41 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:41 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:41 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:41 --> URI Class Initialized
INFO - 2018-10-17 14:49:41 --> Router Class Initialized
INFO - 2018-10-17 14:49:41 --> Output Class Initialized
INFO - 2018-10-17 14:49:41 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:41 --> CSRF cookie sent
INFO - 2018-10-17 14:49:41 --> CSRF token verified
INFO - 2018-10-17 14:49:41 --> Input Class Initialized
INFO - 2018-10-17 14:49:41 --> Language Class Initialized
INFO - 2018-10-17 14:49:41 --> Loader Class Initialized
INFO - 2018-10-17 14:49:41 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:41 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:41 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:41 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:41 --> Controller Class Initialized
INFO - 2018-10-17 14:49:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:41 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:41 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:41 --> Form Validation Class Initialized
INFO - 2018-10-17 14:49:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 14:49:41 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:41 --> Config Class Initialized
INFO - 2018-10-17 14:49:41 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:41 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:41 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:41 --> URI Class Initialized
INFO - 2018-10-17 14:49:41 --> Router Class Initialized
INFO - 2018-10-17 14:49:41 --> Output Class Initialized
INFO - 2018-10-17 14:49:41 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:41 --> CSRF cookie sent
INFO - 2018-10-17 14:49:41 --> Input Class Initialized
INFO - 2018-10-17 14:49:41 --> Language Class Initialized
INFO - 2018-10-17 14:49:41 --> Loader Class Initialized
INFO - 2018-10-17 14:49:41 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:41 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:41 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:41 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:41 --> Controller Class Initialized
INFO - 2018-10-17 14:49:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:41 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:41 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:41 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-17 14:49:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:41 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:41 --> Total execution time: 0.0583
INFO - 2018-10-17 14:49:43 --> Config Class Initialized
INFO - 2018-10-17 14:49:43 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:43 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:43 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:43 --> URI Class Initialized
INFO - 2018-10-17 14:49:43 --> Router Class Initialized
INFO - 2018-10-17 14:49:43 --> Output Class Initialized
INFO - 2018-10-17 14:49:43 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:43 --> CSRF cookie sent
INFO - 2018-10-17 14:49:43 --> CSRF token verified
INFO - 2018-10-17 14:49:43 --> Input Class Initialized
INFO - 2018-10-17 14:49:43 --> Language Class Initialized
INFO - 2018-10-17 14:49:43 --> Loader Class Initialized
INFO - 2018-10-17 14:49:43 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:43 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:43 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:43 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:43 --> Controller Class Initialized
INFO - 2018-10-17 14:49:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:43 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:43 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:43 --> Form Validation Class Initialized
INFO - 2018-10-17 14:49:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 14:49:43 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:43 --> Config Class Initialized
INFO - 2018-10-17 14:49:43 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:43 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:43 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:43 --> URI Class Initialized
INFO - 2018-10-17 14:49:43 --> Router Class Initialized
INFO - 2018-10-17 14:49:43 --> Output Class Initialized
INFO - 2018-10-17 14:49:43 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:43 --> CSRF cookie sent
INFO - 2018-10-17 14:49:43 --> Input Class Initialized
INFO - 2018-10-17 14:49:43 --> Language Class Initialized
INFO - 2018-10-17 14:49:43 --> Loader Class Initialized
INFO - 2018-10-17 14:49:43 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:43 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:43 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:43 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:43 --> Controller Class Initialized
INFO - 2018-10-17 14:49:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:43 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:43 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:43 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 14:49:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:43 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:43 --> Total execution time: 0.0416
INFO - 2018-10-17 14:49:45 --> Config Class Initialized
INFO - 2018-10-17 14:49:45 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:45 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:45 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:45 --> URI Class Initialized
INFO - 2018-10-17 14:49:45 --> Router Class Initialized
INFO - 2018-10-17 14:49:45 --> Output Class Initialized
INFO - 2018-10-17 14:49:45 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:45 --> CSRF cookie sent
INFO - 2018-10-17 14:49:45 --> CSRF token verified
INFO - 2018-10-17 14:49:45 --> Input Class Initialized
INFO - 2018-10-17 14:49:45 --> Language Class Initialized
INFO - 2018-10-17 14:49:45 --> Loader Class Initialized
INFO - 2018-10-17 14:49:45 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:45 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:45 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:45 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:45 --> Controller Class Initialized
INFO - 2018-10-17 14:49:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:45 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:45 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:45 --> Form Validation Class Initialized
INFO - 2018-10-17 14:49:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 14:49:45 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:45 --> Config Class Initialized
INFO - 2018-10-17 14:49:45 --> Hooks Class Initialized
DEBUG - 2018-10-17 14:49:45 --> UTF-8 Support Enabled
INFO - 2018-10-17 14:49:45 --> Utf8 Class Initialized
INFO - 2018-10-17 14:49:45 --> URI Class Initialized
INFO - 2018-10-17 14:49:45 --> Router Class Initialized
INFO - 2018-10-17 14:49:45 --> Output Class Initialized
INFO - 2018-10-17 14:49:45 --> Security Class Initialized
DEBUG - 2018-10-17 14:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 14:49:45 --> CSRF cookie sent
INFO - 2018-10-17 14:49:45 --> Input Class Initialized
INFO - 2018-10-17 14:49:45 --> Language Class Initialized
INFO - 2018-10-17 14:49:45 --> Loader Class Initialized
INFO - 2018-10-17 14:49:45 --> Helper loaded: url_helper
INFO - 2018-10-17 14:49:45 --> Helper loaded: form_helper
INFO - 2018-10-17 14:49:45 --> Helper loaded: language_helper
DEBUG - 2018-10-17 14:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 14:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 14:49:45 --> User Agent Class Initialized
INFO - 2018-10-17 14:49:45 --> Controller Class Initialized
INFO - 2018-10-17 14:49:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 14:49:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 14:49:45 --> Pixel_Model class loaded
INFO - 2018-10-17 14:49:45 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:45 --> Database Driver Class Initialized
INFO - 2018-10-17 14:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 14:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 14:49:45 --> Final output sent to browser
DEBUG - 2018-10-17 14:49:45 --> Total execution time: 0.0466
INFO - 2018-10-17 15:28:09 --> Config Class Initialized
INFO - 2018-10-17 15:28:09 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:28:09 --> UTF-8 Support Enabled
INFO - 2018-10-17 15:28:09 --> Utf8 Class Initialized
INFO - 2018-10-17 15:28:09 --> URI Class Initialized
DEBUG - 2018-10-17 15:28:09 --> No URI present. Default controller set.
INFO - 2018-10-17 15:28:09 --> Router Class Initialized
INFO - 2018-10-17 15:28:09 --> Output Class Initialized
INFO - 2018-10-17 15:28:09 --> Security Class Initialized
DEBUG - 2018-10-17 15:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 15:28:09 --> CSRF cookie sent
INFO - 2018-10-17 15:28:09 --> Input Class Initialized
INFO - 2018-10-17 15:28:09 --> Language Class Initialized
INFO - 2018-10-17 15:28:09 --> Loader Class Initialized
INFO - 2018-10-17 15:28:09 --> Helper loaded: url_helper
INFO - 2018-10-17 15:28:09 --> Helper loaded: form_helper
INFO - 2018-10-17 15:28:09 --> Helper loaded: language_helper
DEBUG - 2018-10-17 15:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 15:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 15:28:09 --> User Agent Class Initialized
INFO - 2018-10-17 15:28:09 --> Controller Class Initialized
INFO - 2018-10-17 15:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 15:28:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 15:28:09 --> Pixel_Model class loaded
INFO - 2018-10-17 15:28:09 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 15:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 15:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 15:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 15:28:09 --> Final output sent to browser
DEBUG - 2018-10-17 15:28:09 --> Total execution time: 0.0349
INFO - 2018-10-17 15:28:10 --> Config Class Initialized
INFO - 2018-10-17 15:28:10 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:28:10 --> UTF-8 Support Enabled
INFO - 2018-10-17 15:28:10 --> Utf8 Class Initialized
INFO - 2018-10-17 15:28:10 --> URI Class Initialized
DEBUG - 2018-10-17 15:28:10 --> No URI present. Default controller set.
INFO - 2018-10-17 15:28:10 --> Router Class Initialized
INFO - 2018-10-17 15:28:10 --> Output Class Initialized
INFO - 2018-10-17 15:28:10 --> Security Class Initialized
DEBUG - 2018-10-17 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 15:28:10 --> CSRF cookie sent
INFO - 2018-10-17 15:28:10 --> Input Class Initialized
INFO - 2018-10-17 15:28:10 --> Language Class Initialized
INFO - 2018-10-17 15:28:10 --> Loader Class Initialized
INFO - 2018-10-17 15:28:10 --> Helper loaded: url_helper
INFO - 2018-10-17 15:28:10 --> Helper loaded: form_helper
INFO - 2018-10-17 15:28:10 --> Helper loaded: language_helper
DEBUG - 2018-10-17 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 15:28:10 --> User Agent Class Initialized
INFO - 2018-10-17 15:28:10 --> Controller Class Initialized
INFO - 2018-10-17 15:28:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 15:28:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 15:28:10 --> Pixel_Model class loaded
INFO - 2018-10-17 15:28:10 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 15:28:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 15:28:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 15:28:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 15:28:10 --> Final output sent to browser
DEBUG - 2018-10-17 15:28:10 --> Total execution time: 0.0356
INFO - 2018-10-17 15:28:18 --> Config Class Initialized
INFO - 2018-10-17 15:28:18 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:28:18 --> UTF-8 Support Enabled
INFO - 2018-10-17 15:28:18 --> Utf8 Class Initialized
INFO - 2018-10-17 15:28:18 --> URI Class Initialized
INFO - 2018-10-17 15:28:18 --> Router Class Initialized
INFO - 2018-10-17 15:28:18 --> Output Class Initialized
INFO - 2018-10-17 15:28:18 --> Security Class Initialized
DEBUG - 2018-10-17 15:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 15:28:18 --> CSRF cookie sent
INFO - 2018-10-17 15:28:18 --> CSRF token verified
INFO - 2018-10-17 15:28:18 --> Input Class Initialized
INFO - 2018-10-17 15:28:18 --> Language Class Initialized
INFO - 2018-10-17 15:28:18 --> Loader Class Initialized
INFO - 2018-10-17 15:28:18 --> Helper loaded: url_helper
INFO - 2018-10-17 15:28:18 --> Helper loaded: form_helper
INFO - 2018-10-17 15:28:18 --> Helper loaded: language_helper
DEBUG - 2018-10-17 15:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 15:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 15:28:18 --> User Agent Class Initialized
INFO - 2018-10-17 15:28:18 --> Controller Class Initialized
INFO - 2018-10-17 15:28:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 15:28:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 15:28:18 --> Pixel_Model class loaded
INFO - 2018-10-17 15:28:18 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:18 --> Form Validation Class Initialized
INFO - 2018-10-17 15:28:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 15:28:18 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:18 --> Config Class Initialized
INFO - 2018-10-17 15:28:18 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:28:18 --> UTF-8 Support Enabled
INFO - 2018-10-17 15:28:18 --> Utf8 Class Initialized
INFO - 2018-10-17 15:28:18 --> URI Class Initialized
INFO - 2018-10-17 15:28:18 --> Router Class Initialized
INFO - 2018-10-17 15:28:18 --> Output Class Initialized
INFO - 2018-10-17 15:28:18 --> Security Class Initialized
DEBUG - 2018-10-17 15:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 15:28:18 --> CSRF cookie sent
INFO - 2018-10-17 15:28:18 --> Input Class Initialized
INFO - 2018-10-17 15:28:18 --> Language Class Initialized
INFO - 2018-10-17 15:28:18 --> Loader Class Initialized
INFO - 2018-10-17 15:28:18 --> Helper loaded: url_helper
INFO - 2018-10-17 15:28:18 --> Helper loaded: form_helper
INFO - 2018-10-17 15:28:18 --> Helper loaded: language_helper
DEBUG - 2018-10-17 15:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 15:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 15:28:18 --> User Agent Class Initialized
INFO - 2018-10-17 15:28:18 --> Controller Class Initialized
INFO - 2018-10-17 15:28:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 15:28:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 15:28:18 --> Pixel_Model class loaded
INFO - 2018-10-17 15:28:18 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:18 --> Database Driver Class Initialized
INFO - 2018-10-17 15:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-17 15:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 15:28:18 --> Final output sent to browser
DEBUG - 2018-10-17 15:28:18 --> Total execution time: 0.0461
INFO - 2018-10-17 19:24:32 --> Config Class Initialized
INFO - 2018-10-17 19:24:32 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:32 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:32 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:32 --> URI Class Initialized
INFO - 2018-10-17 19:24:32 --> Router Class Initialized
INFO - 2018-10-17 19:24:32 --> Output Class Initialized
INFO - 2018-10-17 19:24:32 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:32 --> CSRF cookie sent
INFO - 2018-10-17 19:24:32 --> Input Class Initialized
INFO - 2018-10-17 19:24:32 --> Language Class Initialized
INFO - 2018-10-17 19:24:32 --> Loader Class Initialized
INFO - 2018-10-17 19:24:32 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:32 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:32 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:32 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:32 --> Controller Class Initialized
INFO - 2018-10-17 19:24:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:32 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:32 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-17 19:24:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:24:32 --> Final output sent to browser
DEBUG - 2018-10-17 19:24:32 --> Total execution time: 0.0522
INFO - 2018-10-17 19:24:36 --> Config Class Initialized
INFO - 2018-10-17 19:24:36 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:36 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:36 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:36 --> URI Class Initialized
INFO - 2018-10-17 19:24:36 --> Router Class Initialized
INFO - 2018-10-17 19:24:36 --> Output Class Initialized
INFO - 2018-10-17 19:24:36 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:36 --> CSRF cookie sent
INFO - 2018-10-17 19:24:36 --> CSRF token verified
INFO - 2018-10-17 19:24:36 --> Input Class Initialized
INFO - 2018-10-17 19:24:36 --> Language Class Initialized
INFO - 2018-10-17 19:24:36 --> Loader Class Initialized
INFO - 2018-10-17 19:24:36 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:36 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:36 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:36 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:36 --> Controller Class Initialized
INFO - 2018-10-17 19:24:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:36 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:36 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:36 --> Form Validation Class Initialized
INFO - 2018-10-17 19:24:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:24:36 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:37 --> Config Class Initialized
INFO - 2018-10-17 19:24:37 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:37 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:37 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:37 --> URI Class Initialized
INFO - 2018-10-17 19:24:37 --> Router Class Initialized
INFO - 2018-10-17 19:24:37 --> Output Class Initialized
INFO - 2018-10-17 19:24:37 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:37 --> CSRF cookie sent
INFO - 2018-10-17 19:24:37 --> Input Class Initialized
INFO - 2018-10-17 19:24:37 --> Language Class Initialized
INFO - 2018-10-17 19:24:37 --> Loader Class Initialized
INFO - 2018-10-17 19:24:37 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:37 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:37 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:37 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:37 --> Controller Class Initialized
INFO - 2018-10-17 19:24:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:37 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:37 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:37 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-17 19:24:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:24:37 --> Final output sent to browser
DEBUG - 2018-10-17 19:24:37 --> Total execution time: 0.0589
INFO - 2018-10-17 19:24:44 --> Config Class Initialized
INFO - 2018-10-17 19:24:44 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:44 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:44 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:44 --> URI Class Initialized
INFO - 2018-10-17 19:24:44 --> Router Class Initialized
INFO - 2018-10-17 19:24:44 --> Output Class Initialized
INFO - 2018-10-17 19:24:44 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:44 --> CSRF cookie sent
INFO - 2018-10-17 19:24:44 --> CSRF token verified
INFO - 2018-10-17 19:24:44 --> Input Class Initialized
INFO - 2018-10-17 19:24:44 --> Language Class Initialized
INFO - 2018-10-17 19:24:44 --> Loader Class Initialized
INFO - 2018-10-17 19:24:44 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:44 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:44 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:44 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:44 --> Controller Class Initialized
INFO - 2018-10-17 19:24:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:44 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:44 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:44 --> Form Validation Class Initialized
INFO - 2018-10-17 19:24:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:24:44 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:44 --> Config Class Initialized
INFO - 2018-10-17 19:24:44 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:44 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:44 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:44 --> URI Class Initialized
INFO - 2018-10-17 19:24:44 --> Router Class Initialized
INFO - 2018-10-17 19:24:44 --> Output Class Initialized
INFO - 2018-10-17 19:24:44 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:44 --> CSRF cookie sent
INFO - 2018-10-17 19:24:44 --> Input Class Initialized
INFO - 2018-10-17 19:24:44 --> Language Class Initialized
INFO - 2018-10-17 19:24:44 --> Loader Class Initialized
INFO - 2018-10-17 19:24:44 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:44 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:44 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:44 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:44 --> Controller Class Initialized
INFO - 2018-10-17 19:24:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:44 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:44 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:44 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-17 19:24:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:24:44 --> Final output sent to browser
DEBUG - 2018-10-17 19:24:44 --> Total execution time: 0.0381
INFO - 2018-10-17 19:24:46 --> Config Class Initialized
INFO - 2018-10-17 19:24:46 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:46 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:46 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:46 --> URI Class Initialized
INFO - 2018-10-17 19:24:46 --> Router Class Initialized
INFO - 2018-10-17 19:24:46 --> Output Class Initialized
INFO - 2018-10-17 19:24:46 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:46 --> CSRF cookie sent
INFO - 2018-10-17 19:24:46 --> CSRF token verified
INFO - 2018-10-17 19:24:46 --> Input Class Initialized
INFO - 2018-10-17 19:24:46 --> Language Class Initialized
INFO - 2018-10-17 19:24:46 --> Loader Class Initialized
INFO - 2018-10-17 19:24:46 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:46 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:46 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:46 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:46 --> Controller Class Initialized
INFO - 2018-10-17 19:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:46 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:46 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:46 --> Form Validation Class Initialized
INFO - 2018-10-17 19:24:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:24:46 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:46 --> Config Class Initialized
INFO - 2018-10-17 19:24:46 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:46 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:46 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:46 --> URI Class Initialized
INFO - 2018-10-17 19:24:46 --> Router Class Initialized
INFO - 2018-10-17 19:24:46 --> Output Class Initialized
INFO - 2018-10-17 19:24:46 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:46 --> CSRF cookie sent
INFO - 2018-10-17 19:24:46 --> Input Class Initialized
INFO - 2018-10-17 19:24:46 --> Language Class Initialized
INFO - 2018-10-17 19:24:46 --> Loader Class Initialized
INFO - 2018-10-17 19:24:46 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:46 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:46 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:46 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:46 --> Controller Class Initialized
INFO - 2018-10-17 19:24:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:46 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:46 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:46 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 19:24:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:24:46 --> Final output sent to browser
DEBUG - 2018-10-17 19:24:46 --> Total execution time: 0.0383
INFO - 2018-10-17 19:24:47 --> Config Class Initialized
INFO - 2018-10-17 19:24:47 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:47 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:47 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:47 --> URI Class Initialized
INFO - 2018-10-17 19:24:47 --> Router Class Initialized
INFO - 2018-10-17 19:24:47 --> Output Class Initialized
INFO - 2018-10-17 19:24:47 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:47 --> CSRF cookie sent
INFO - 2018-10-17 19:24:47 --> CSRF token verified
INFO - 2018-10-17 19:24:47 --> Input Class Initialized
INFO - 2018-10-17 19:24:47 --> Language Class Initialized
INFO - 2018-10-17 19:24:47 --> Loader Class Initialized
INFO - 2018-10-17 19:24:47 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:47 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:47 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:47 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:47 --> Controller Class Initialized
INFO - 2018-10-17 19:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:47 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:47 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:47 --> Form Validation Class Initialized
INFO - 2018-10-17 19:24:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:24:47 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:47 --> Config Class Initialized
INFO - 2018-10-17 19:24:47 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:24:47 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:24:47 --> Utf8 Class Initialized
INFO - 2018-10-17 19:24:47 --> URI Class Initialized
INFO - 2018-10-17 19:24:47 --> Router Class Initialized
INFO - 2018-10-17 19:24:47 --> Output Class Initialized
INFO - 2018-10-17 19:24:47 --> Security Class Initialized
DEBUG - 2018-10-17 19:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:24:47 --> CSRF cookie sent
INFO - 2018-10-17 19:24:47 --> Input Class Initialized
INFO - 2018-10-17 19:24:47 --> Language Class Initialized
INFO - 2018-10-17 19:24:47 --> Loader Class Initialized
INFO - 2018-10-17 19:24:47 --> Helper loaded: url_helper
INFO - 2018-10-17 19:24:47 --> Helper loaded: form_helper
INFO - 2018-10-17 19:24:47 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:24:47 --> User Agent Class Initialized
INFO - 2018-10-17 19:24:47 --> Controller Class Initialized
INFO - 2018-10-17 19:24:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:24:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:24:47 --> Pixel_Model class loaded
INFO - 2018-10-17 19:24:47 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:47 --> Database Driver Class Initialized
INFO - 2018-10-17 19:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 19:24:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:24:47 --> Final output sent to browser
DEBUG - 2018-10-17 19:24:47 --> Total execution time: 0.0397
INFO - 2018-10-17 19:25:03 --> Config Class Initialized
INFO - 2018-10-17 19:25:03 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:03 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:03 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:03 --> URI Class Initialized
INFO - 2018-10-17 19:25:03 --> Router Class Initialized
INFO - 2018-10-17 19:25:03 --> Output Class Initialized
INFO - 2018-10-17 19:25:03 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:03 --> CSRF cookie sent
INFO - 2018-10-17 19:25:03 --> Input Class Initialized
INFO - 2018-10-17 19:25:03 --> Language Class Initialized
ERROR - 2018-10-17 19:25:03 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:25:21 --> Config Class Initialized
INFO - 2018-10-17 19:25:21 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:21 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:21 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:21 --> URI Class Initialized
DEBUG - 2018-10-17 19:25:21 --> No URI present. Default controller set.
INFO - 2018-10-17 19:25:21 --> Router Class Initialized
INFO - 2018-10-17 19:25:21 --> Output Class Initialized
INFO - 2018-10-17 19:25:21 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:21 --> CSRF cookie sent
INFO - 2018-10-17 19:25:21 --> Input Class Initialized
INFO - 2018-10-17 19:25:21 --> Language Class Initialized
INFO - 2018-10-17 19:25:21 --> Loader Class Initialized
INFO - 2018-10-17 19:25:21 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:21 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:21 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:21 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:21 --> Controller Class Initialized
INFO - 2018-10-17 19:25:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:21 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:21 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 19:25:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:21 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:21 --> Total execution time: 0.0393
INFO - 2018-10-17 19:25:24 --> Config Class Initialized
INFO - 2018-10-17 19:25:24 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:24 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:24 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:24 --> URI Class Initialized
DEBUG - 2018-10-17 19:25:24 --> No URI present. Default controller set.
INFO - 2018-10-17 19:25:24 --> Router Class Initialized
INFO - 2018-10-17 19:25:24 --> Output Class Initialized
INFO - 2018-10-17 19:25:24 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:24 --> CSRF cookie sent
INFO - 2018-10-17 19:25:24 --> Input Class Initialized
INFO - 2018-10-17 19:25:24 --> Language Class Initialized
INFO - 2018-10-17 19:25:24 --> Loader Class Initialized
INFO - 2018-10-17 19:25:24 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:24 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:24 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:24 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:24 --> Controller Class Initialized
INFO - 2018-10-17 19:25:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:24 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:24 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 19:25:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:24 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:24 --> Total execution time: 0.0365
INFO - 2018-10-17 19:25:29 --> Config Class Initialized
INFO - 2018-10-17 19:25:29 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:29 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:29 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:29 --> URI Class Initialized
INFO - 2018-10-17 19:25:29 --> Router Class Initialized
INFO - 2018-10-17 19:25:29 --> Output Class Initialized
INFO - 2018-10-17 19:25:29 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:29 --> CSRF cookie sent
INFO - 2018-10-17 19:25:29 --> CSRF token verified
INFO - 2018-10-17 19:25:29 --> Input Class Initialized
INFO - 2018-10-17 19:25:29 --> Language Class Initialized
INFO - 2018-10-17 19:25:29 --> Loader Class Initialized
INFO - 2018-10-17 19:25:29 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:29 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:29 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:29 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:29 --> Controller Class Initialized
INFO - 2018-10-17 19:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:29 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:29 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:29 --> Form Validation Class Initialized
INFO - 2018-10-17 19:25:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:25:29 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:29 --> Config Class Initialized
INFO - 2018-10-17 19:25:29 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:29 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:29 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:29 --> URI Class Initialized
INFO - 2018-10-17 19:25:29 --> Router Class Initialized
INFO - 2018-10-17 19:25:29 --> Output Class Initialized
INFO - 2018-10-17 19:25:29 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:29 --> CSRF cookie sent
INFO - 2018-10-17 19:25:29 --> Input Class Initialized
INFO - 2018-10-17 19:25:29 --> Language Class Initialized
INFO - 2018-10-17 19:25:29 --> Loader Class Initialized
INFO - 2018-10-17 19:25:29 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:29 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:29 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:29 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:29 --> Controller Class Initialized
INFO - 2018-10-17 19:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:29 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:29 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:29 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-17 19:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:29 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:29 --> Total execution time: 0.0474
INFO - 2018-10-17 19:25:45 --> Config Class Initialized
INFO - 2018-10-17 19:25:45 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:45 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:45 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:45 --> URI Class Initialized
INFO - 2018-10-17 19:25:45 --> Router Class Initialized
INFO - 2018-10-17 19:25:45 --> Output Class Initialized
INFO - 2018-10-17 19:25:45 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:45 --> CSRF cookie sent
INFO - 2018-10-17 19:25:45 --> CSRF token verified
INFO - 2018-10-17 19:25:45 --> Input Class Initialized
INFO - 2018-10-17 19:25:45 --> Language Class Initialized
INFO - 2018-10-17 19:25:45 --> Loader Class Initialized
INFO - 2018-10-17 19:25:45 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:45 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:45 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:45 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:45 --> Controller Class Initialized
INFO - 2018-10-17 19:25:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:45 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:45 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:45 --> Form Validation Class Initialized
INFO - 2018-10-17 19:25:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:25:45 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:45 --> Config Class Initialized
INFO - 2018-10-17 19:25:45 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:45 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:45 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:45 --> URI Class Initialized
INFO - 2018-10-17 19:25:45 --> Router Class Initialized
INFO - 2018-10-17 19:25:45 --> Output Class Initialized
INFO - 2018-10-17 19:25:45 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:45 --> CSRF cookie sent
INFO - 2018-10-17 19:25:45 --> Input Class Initialized
INFO - 2018-10-17 19:25:45 --> Language Class Initialized
INFO - 2018-10-17 19:25:45 --> Loader Class Initialized
INFO - 2018-10-17 19:25:45 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:45 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:45 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:45 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:45 --> Controller Class Initialized
INFO - 2018-10-17 19:25:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:45 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:45 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:45 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-17 19:25:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:45 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:45 --> Total execution time: 0.0384
INFO - 2018-10-17 19:25:52 --> Config Class Initialized
INFO - 2018-10-17 19:25:52 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:52 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:52 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:52 --> URI Class Initialized
INFO - 2018-10-17 19:25:52 --> Router Class Initialized
INFO - 2018-10-17 19:25:52 --> Output Class Initialized
INFO - 2018-10-17 19:25:52 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:52 --> CSRF cookie sent
INFO - 2018-10-17 19:25:52 --> CSRF token verified
INFO - 2018-10-17 19:25:52 --> Input Class Initialized
INFO - 2018-10-17 19:25:52 --> Language Class Initialized
INFO - 2018-10-17 19:25:52 --> Loader Class Initialized
INFO - 2018-10-17 19:25:52 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:52 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:52 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:52 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:52 --> Controller Class Initialized
INFO - 2018-10-17 19:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:52 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:52 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:52 --> Form Validation Class Initialized
INFO - 2018-10-17 19:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:25:52 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:52 --> Config Class Initialized
INFO - 2018-10-17 19:25:52 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:52 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:52 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:52 --> URI Class Initialized
INFO - 2018-10-17 19:25:52 --> Router Class Initialized
INFO - 2018-10-17 19:25:52 --> Output Class Initialized
INFO - 2018-10-17 19:25:52 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:52 --> CSRF cookie sent
INFO - 2018-10-17 19:25:52 --> Input Class Initialized
INFO - 2018-10-17 19:25:52 --> Language Class Initialized
INFO - 2018-10-17 19:25:52 --> Loader Class Initialized
INFO - 2018-10-17 19:25:52 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:52 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:52 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:52 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:52 --> Controller Class Initialized
INFO - 2018-10-17 19:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:52 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:52 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:52 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 19:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:52 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:52 --> Total execution time: 0.0404
INFO - 2018-10-17 19:25:54 --> Config Class Initialized
INFO - 2018-10-17 19:25:54 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:54 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:54 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:54 --> URI Class Initialized
INFO - 2018-10-17 19:25:54 --> Router Class Initialized
INFO - 2018-10-17 19:25:54 --> Output Class Initialized
INFO - 2018-10-17 19:25:54 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:54 --> CSRF cookie sent
INFO - 2018-10-17 19:25:54 --> CSRF token verified
INFO - 2018-10-17 19:25:54 --> Input Class Initialized
INFO - 2018-10-17 19:25:54 --> Language Class Initialized
INFO - 2018-10-17 19:25:54 --> Loader Class Initialized
INFO - 2018-10-17 19:25:54 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:54 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:54 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:54 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:54 --> Controller Class Initialized
INFO - 2018-10-17 19:25:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:54 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:54 --> Form Validation Class Initialized
INFO - 2018-10-17 19:25:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:25:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:54 --> Config Class Initialized
INFO - 2018-10-17 19:25:54 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:25:54 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:25:54 --> Utf8 Class Initialized
INFO - 2018-10-17 19:25:54 --> URI Class Initialized
INFO - 2018-10-17 19:25:54 --> Router Class Initialized
INFO - 2018-10-17 19:25:54 --> Output Class Initialized
INFO - 2018-10-17 19:25:54 --> Security Class Initialized
DEBUG - 2018-10-17 19:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:25:54 --> CSRF cookie sent
INFO - 2018-10-17 19:25:54 --> Input Class Initialized
INFO - 2018-10-17 19:25:54 --> Language Class Initialized
INFO - 2018-10-17 19:25:54 --> Loader Class Initialized
INFO - 2018-10-17 19:25:54 --> Helper loaded: url_helper
INFO - 2018-10-17 19:25:54 --> Helper loaded: form_helper
INFO - 2018-10-17 19:25:54 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:25:54 --> User Agent Class Initialized
INFO - 2018-10-17 19:25:54 --> Controller Class Initialized
INFO - 2018-10-17 19:25:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:25:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:25:54 --> Pixel_Model class loaded
INFO - 2018-10-17 19:25:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 19:25:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:25:54 --> Final output sent to browser
DEBUG - 2018-10-17 19:25:54 --> Total execution time: 0.0421
INFO - 2018-10-17 19:26:50 --> Config Class Initialized
INFO - 2018-10-17 19:26:50 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:50 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:50 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:50 --> URI Class Initialized
INFO - 2018-10-17 19:26:50 --> Router Class Initialized
INFO - 2018-10-17 19:26:50 --> Output Class Initialized
INFO - 2018-10-17 19:26:50 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:50 --> CSRF cookie sent
INFO - 2018-10-17 19:26:50 --> Input Class Initialized
INFO - 2018-10-17 19:26:50 --> Language Class Initialized
INFO - 2018-10-17 19:26:50 --> Loader Class Initialized
INFO - 2018-10-17 19:26:50 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:50 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:50 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:50 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:50 --> Controller Class Initialized
INFO - 2018-10-17 19:26:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:50 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:50 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:50 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 19:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:26:50 --> Final output sent to browser
DEBUG - 2018-10-17 19:26:50 --> Total execution time: 0.0405
INFO - 2018-10-17 19:26:51 --> Config Class Initialized
INFO - 2018-10-17 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:51 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:51 --> URI Class Initialized
INFO - 2018-10-17 19:26:51 --> Router Class Initialized
INFO - 2018-10-17 19:26:51 --> Output Class Initialized
INFO - 2018-10-17 19:26:51 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:51 --> CSRF cookie sent
INFO - 2018-10-17 19:26:51 --> Input Class Initialized
INFO - 2018-10-17 19:26:51 --> Language Class Initialized
ERROR - 2018-10-17 19:26:51 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:26:54 --> Config Class Initialized
INFO - 2018-10-17 19:26:54 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:54 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:54 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:54 --> URI Class Initialized
INFO - 2018-10-17 19:26:54 --> Router Class Initialized
INFO - 2018-10-17 19:26:54 --> Output Class Initialized
INFO - 2018-10-17 19:26:54 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:54 --> CSRF cookie sent
INFO - 2018-10-17 19:26:54 --> CSRF token verified
INFO - 2018-10-17 19:26:54 --> Input Class Initialized
INFO - 2018-10-17 19:26:54 --> Language Class Initialized
INFO - 2018-10-17 19:26:54 --> Loader Class Initialized
INFO - 2018-10-17 19:26:54 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:54 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:54 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:54 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:54 --> Controller Class Initialized
INFO - 2018-10-17 19:26:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:54 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:54 --> Form Validation Class Initialized
INFO - 2018-10-17 19:26:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:26:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:54 --> Config Class Initialized
INFO - 2018-10-17 19:26:54 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:54 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:54 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:54 --> URI Class Initialized
INFO - 2018-10-17 19:26:54 --> Router Class Initialized
INFO - 2018-10-17 19:26:54 --> Output Class Initialized
INFO - 2018-10-17 19:26:54 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:54 --> CSRF cookie sent
INFO - 2018-10-17 19:26:54 --> Input Class Initialized
INFO - 2018-10-17 19:26:54 --> Language Class Initialized
INFO - 2018-10-17 19:26:54 --> Loader Class Initialized
INFO - 2018-10-17 19:26:54 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:54 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:54 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:54 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:54 --> Controller Class Initialized
INFO - 2018-10-17 19:26:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:54 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:54 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-17 19:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:26:54 --> Final output sent to browser
DEBUG - 2018-10-17 19:26:54 --> Total execution time: 0.0402
INFO - 2018-10-17 19:26:55 --> Config Class Initialized
INFO - 2018-10-17 19:26:55 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:55 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:55 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:55 --> URI Class Initialized
INFO - 2018-10-17 19:26:55 --> Router Class Initialized
INFO - 2018-10-17 19:26:55 --> Output Class Initialized
INFO - 2018-10-17 19:26:55 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:55 --> CSRF cookie sent
INFO - 2018-10-17 19:26:55 --> Input Class Initialized
INFO - 2018-10-17 19:26:55 --> Language Class Initialized
ERROR - 2018-10-17 19:26:55 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:26:57 --> Config Class Initialized
INFO - 2018-10-17 19:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:57 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:57 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:57 --> URI Class Initialized
INFO - 2018-10-17 19:26:57 --> Router Class Initialized
INFO - 2018-10-17 19:26:57 --> Output Class Initialized
INFO - 2018-10-17 19:26:57 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:57 --> CSRF cookie sent
INFO - 2018-10-17 19:26:57 --> Input Class Initialized
INFO - 2018-10-17 19:26:57 --> Language Class Initialized
INFO - 2018-10-17 19:26:57 --> Loader Class Initialized
INFO - 2018-10-17 19:26:57 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:57 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:57 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:57 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:57 --> Controller Class Initialized
INFO - 2018-10-17 19:26:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:57 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 19:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:26:57 --> Final output sent to browser
DEBUG - 2018-10-17 19:26:57 --> Total execution time: 0.0465
INFO - 2018-10-17 19:26:57 --> Config Class Initialized
INFO - 2018-10-17 19:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:57 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:57 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:57 --> URI Class Initialized
INFO - 2018-10-17 19:26:57 --> Router Class Initialized
INFO - 2018-10-17 19:26:57 --> Output Class Initialized
INFO - 2018-10-17 19:26:57 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:57 --> CSRF cookie sent
INFO - 2018-10-17 19:26:57 --> CSRF token verified
INFO - 2018-10-17 19:26:57 --> Input Class Initialized
INFO - 2018-10-17 19:26:57 --> Language Class Initialized
INFO - 2018-10-17 19:26:57 --> Loader Class Initialized
INFO - 2018-10-17 19:26:57 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:57 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:57 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:57 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:57 --> Controller Class Initialized
INFO - 2018-10-17 19:26:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:57 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:57 --> Form Validation Class Initialized
INFO - 2018-10-17 19:26:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:26:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:58 --> Config Class Initialized
INFO - 2018-10-17 19:26:58 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:58 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:58 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:58 --> URI Class Initialized
INFO - 2018-10-17 19:26:58 --> Router Class Initialized
INFO - 2018-10-17 19:26:58 --> Output Class Initialized
INFO - 2018-10-17 19:26:58 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:58 --> CSRF cookie sent
INFO - 2018-10-17 19:26:58 --> Input Class Initialized
INFO - 2018-10-17 19:26:58 --> Language Class Initialized
INFO - 2018-10-17 19:26:58 --> Loader Class Initialized
INFO - 2018-10-17 19:26:58 --> Helper loaded: url_helper
INFO - 2018-10-17 19:26:58 --> Helper loaded: form_helper
INFO - 2018-10-17 19:26:58 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:26:58 --> User Agent Class Initialized
INFO - 2018-10-17 19:26:58 --> Controller Class Initialized
INFO - 2018-10-17 19:26:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:26:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:26:58 --> Pixel_Model class loaded
INFO - 2018-10-17 19:26:58 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:58 --> Database Driver Class Initialized
INFO - 2018-10-17 19:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-17 19:26:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:26:58 --> Final output sent to browser
DEBUG - 2018-10-17 19:26:58 --> Total execution time: 0.0403
INFO - 2018-10-17 19:26:58 --> Config Class Initialized
INFO - 2018-10-17 19:26:58 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:26:58 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:26:58 --> Utf8 Class Initialized
INFO - 2018-10-17 19:26:58 --> URI Class Initialized
INFO - 2018-10-17 19:26:58 --> Router Class Initialized
INFO - 2018-10-17 19:26:58 --> Output Class Initialized
INFO - 2018-10-17 19:26:58 --> Security Class Initialized
DEBUG - 2018-10-17 19:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:26:58 --> CSRF cookie sent
INFO - 2018-10-17 19:26:58 --> Input Class Initialized
INFO - 2018-10-17 19:26:58 --> Language Class Initialized
ERROR - 2018-10-17 19:26:58 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:01 --> Config Class Initialized
INFO - 2018-10-17 19:27:01 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:01 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:01 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:01 --> URI Class Initialized
INFO - 2018-10-17 19:27:01 --> Router Class Initialized
INFO - 2018-10-17 19:27:01 --> Output Class Initialized
INFO - 2018-10-17 19:27:01 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:01 --> CSRF cookie sent
INFO - 2018-10-17 19:27:01 --> Input Class Initialized
INFO - 2018-10-17 19:27:01 --> Language Class Initialized
INFO - 2018-10-17 19:27:01 --> Loader Class Initialized
INFO - 2018-10-17 19:27:01 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:01 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:01 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:01 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:01 --> Controller Class Initialized
INFO - 2018-10-17 19:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:01 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:01 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:01 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 19:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:01 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:01 --> Total execution time: 0.0572
INFO - 2018-10-17 19:27:02 --> Config Class Initialized
INFO - 2018-10-17 19:27:02 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:02 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:02 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:02 --> URI Class Initialized
INFO - 2018-10-17 19:27:02 --> Router Class Initialized
INFO - 2018-10-17 19:27:02 --> Output Class Initialized
INFO - 2018-10-17 19:27:02 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:02 --> CSRF cookie sent
INFO - 2018-10-17 19:27:02 --> CSRF token verified
INFO - 2018-10-17 19:27:02 --> Input Class Initialized
INFO - 2018-10-17 19:27:02 --> Language Class Initialized
INFO - 2018-10-17 19:27:02 --> Loader Class Initialized
INFO - 2018-10-17 19:27:02 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:02 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:02 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:02 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:02 --> Controller Class Initialized
INFO - 2018-10-17 19:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:02 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:02 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:02 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:02 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:02 --> Config Class Initialized
INFO - 2018-10-17 19:27:02 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:02 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:02 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:02 --> URI Class Initialized
INFO - 2018-10-17 19:27:02 --> Router Class Initialized
INFO - 2018-10-17 19:27:02 --> Output Class Initialized
INFO - 2018-10-17 19:27:02 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:02 --> CSRF cookie sent
INFO - 2018-10-17 19:27:02 --> Input Class Initialized
INFO - 2018-10-17 19:27:02 --> Language Class Initialized
INFO - 2018-10-17 19:27:02 --> Loader Class Initialized
INFO - 2018-10-17 19:27:02 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:02 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:02 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:02 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:02 --> Controller Class Initialized
INFO - 2018-10-17 19:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:02 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:02 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:02 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-17 19:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:02 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:02 --> Total execution time: 0.0392
INFO - 2018-10-17 19:27:03 --> Config Class Initialized
INFO - 2018-10-17 19:27:03 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:03 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:03 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:03 --> URI Class Initialized
INFO - 2018-10-17 19:27:03 --> Router Class Initialized
INFO - 2018-10-17 19:27:03 --> Output Class Initialized
INFO - 2018-10-17 19:27:03 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:03 --> CSRF cookie sent
INFO - 2018-10-17 19:27:03 --> Input Class Initialized
INFO - 2018-10-17 19:27:03 --> Language Class Initialized
ERROR - 2018-10-17 19:27:03 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:08 --> Config Class Initialized
INFO - 2018-10-17 19:27:08 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:08 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:08 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:08 --> URI Class Initialized
INFO - 2018-10-17 19:27:08 --> Router Class Initialized
INFO - 2018-10-17 19:27:08 --> Output Class Initialized
INFO - 2018-10-17 19:27:08 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:08 --> CSRF cookie sent
INFO - 2018-10-17 19:27:08 --> CSRF token verified
INFO - 2018-10-17 19:27:08 --> Input Class Initialized
INFO - 2018-10-17 19:27:08 --> Language Class Initialized
INFO - 2018-10-17 19:27:08 --> Loader Class Initialized
INFO - 2018-10-17 19:27:08 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:08 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:08 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:08 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:08 --> Controller Class Initialized
INFO - 2018-10-17 19:27:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:08 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:08 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:08 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:08 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:08 --> Config Class Initialized
INFO - 2018-10-17 19:27:08 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:08 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:08 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:08 --> URI Class Initialized
INFO - 2018-10-17 19:27:08 --> Router Class Initialized
INFO - 2018-10-17 19:27:08 --> Output Class Initialized
INFO - 2018-10-17 19:27:08 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:08 --> CSRF cookie sent
INFO - 2018-10-17 19:27:08 --> Input Class Initialized
INFO - 2018-10-17 19:27:08 --> Language Class Initialized
INFO - 2018-10-17 19:27:08 --> Loader Class Initialized
INFO - 2018-10-17 19:27:09 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:09 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:09 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:09 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:09 --> Controller Class Initialized
INFO - 2018-10-17 19:27:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:09 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:09 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:09 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-17 19:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:09 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:09 --> Total execution time: 0.0451
INFO - 2018-10-17 19:27:09 --> Config Class Initialized
INFO - 2018-10-17 19:27:09 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:09 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:09 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:09 --> URI Class Initialized
INFO - 2018-10-17 19:27:09 --> Router Class Initialized
INFO - 2018-10-17 19:27:09 --> Output Class Initialized
INFO - 2018-10-17 19:27:09 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:09 --> CSRF cookie sent
INFO - 2018-10-17 19:27:09 --> Input Class Initialized
INFO - 2018-10-17 19:27:09 --> Language Class Initialized
ERROR - 2018-10-17 19:27:09 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:18 --> Config Class Initialized
INFO - 2018-10-17 19:27:18 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:18 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:18 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:18 --> URI Class Initialized
INFO - 2018-10-17 19:27:18 --> Router Class Initialized
INFO - 2018-10-17 19:27:18 --> Output Class Initialized
INFO - 2018-10-17 19:27:18 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:18 --> CSRF cookie sent
INFO - 2018-10-17 19:27:18 --> CSRF token verified
INFO - 2018-10-17 19:27:18 --> Input Class Initialized
INFO - 2018-10-17 19:27:18 --> Language Class Initialized
INFO - 2018-10-17 19:27:18 --> Loader Class Initialized
INFO - 2018-10-17 19:27:18 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:18 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:18 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:18 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:18 --> Controller Class Initialized
INFO - 2018-10-17 19:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:18 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:18 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:18 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:18 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:18 --> Config Class Initialized
INFO - 2018-10-17 19:27:18 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:18 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:18 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:18 --> URI Class Initialized
INFO - 2018-10-17 19:27:18 --> Router Class Initialized
INFO - 2018-10-17 19:27:18 --> Output Class Initialized
INFO - 2018-10-17 19:27:18 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:18 --> CSRF cookie sent
INFO - 2018-10-17 19:27:18 --> Input Class Initialized
INFO - 2018-10-17 19:27:18 --> Language Class Initialized
INFO - 2018-10-17 19:27:18 --> Loader Class Initialized
INFO - 2018-10-17 19:27:18 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:18 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:18 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:18 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:18 --> Controller Class Initialized
INFO - 2018-10-17 19:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:18 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:18 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:18 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-17 19:27:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:18 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:18 --> Total execution time: 0.0456
INFO - 2018-10-17 19:27:19 --> Config Class Initialized
INFO - 2018-10-17 19:27:19 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:19 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:19 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:19 --> URI Class Initialized
INFO - 2018-10-17 19:27:19 --> Router Class Initialized
INFO - 2018-10-17 19:27:19 --> Output Class Initialized
INFO - 2018-10-17 19:27:19 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:19 --> CSRF cookie sent
INFO - 2018-10-17 19:27:19 --> Input Class Initialized
INFO - 2018-10-17 19:27:19 --> Language Class Initialized
ERROR - 2018-10-17 19:27:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:20 --> Config Class Initialized
INFO - 2018-10-17 19:27:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:20 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:20 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:20 --> URI Class Initialized
INFO - 2018-10-17 19:27:20 --> Router Class Initialized
INFO - 2018-10-17 19:27:20 --> Output Class Initialized
INFO - 2018-10-17 19:27:20 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:20 --> CSRF cookie sent
INFO - 2018-10-17 19:27:20 --> CSRF token verified
INFO - 2018-10-17 19:27:20 --> Input Class Initialized
INFO - 2018-10-17 19:27:20 --> Language Class Initialized
INFO - 2018-10-17 19:27:20 --> Loader Class Initialized
INFO - 2018-10-17 19:27:20 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:20 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:20 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:20 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:20 --> Controller Class Initialized
INFO - 2018-10-17 19:27:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:20 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:20 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:20 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:20 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:20 --> Config Class Initialized
INFO - 2018-10-17 19:27:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:20 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:20 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:20 --> URI Class Initialized
INFO - 2018-10-17 19:27:20 --> Router Class Initialized
INFO - 2018-10-17 19:27:20 --> Output Class Initialized
INFO - 2018-10-17 19:27:20 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:20 --> CSRF cookie sent
INFO - 2018-10-17 19:27:20 --> Input Class Initialized
INFO - 2018-10-17 19:27:20 --> Language Class Initialized
INFO - 2018-10-17 19:27:20 --> Loader Class Initialized
INFO - 2018-10-17 19:27:20 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:20 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:20 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:20 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:20 --> Controller Class Initialized
INFO - 2018-10-17 19:27:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:20 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:20 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:20 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-17 19:27:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:20 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:20 --> Total execution time: 0.0598
INFO - 2018-10-17 19:27:21 --> Config Class Initialized
INFO - 2018-10-17 19:27:21 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:21 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:21 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:21 --> URI Class Initialized
INFO - 2018-10-17 19:27:21 --> Router Class Initialized
INFO - 2018-10-17 19:27:21 --> Output Class Initialized
INFO - 2018-10-17 19:27:21 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:21 --> CSRF cookie sent
INFO - 2018-10-17 19:27:21 --> Input Class Initialized
INFO - 2018-10-17 19:27:21 --> Language Class Initialized
ERROR - 2018-10-17 19:27:21 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:23 --> Config Class Initialized
INFO - 2018-10-17 19:27:23 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:23 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:23 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:23 --> URI Class Initialized
INFO - 2018-10-17 19:27:23 --> Router Class Initialized
INFO - 2018-10-17 19:27:23 --> Output Class Initialized
INFO - 2018-10-17 19:27:23 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:23 --> CSRF cookie sent
INFO - 2018-10-17 19:27:23 --> CSRF token verified
INFO - 2018-10-17 19:27:23 --> Input Class Initialized
INFO - 2018-10-17 19:27:23 --> Language Class Initialized
INFO - 2018-10-17 19:27:23 --> Loader Class Initialized
INFO - 2018-10-17 19:27:23 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:23 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:23 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:23 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:23 --> Controller Class Initialized
INFO - 2018-10-17 19:27:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:23 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:23 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:23 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:23 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:24 --> Config Class Initialized
INFO - 2018-10-17 19:27:24 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:24 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:24 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:24 --> URI Class Initialized
INFO - 2018-10-17 19:27:24 --> Router Class Initialized
INFO - 2018-10-17 19:27:24 --> Output Class Initialized
INFO - 2018-10-17 19:27:24 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:24 --> CSRF cookie sent
INFO - 2018-10-17 19:27:24 --> Input Class Initialized
INFO - 2018-10-17 19:27:24 --> Language Class Initialized
INFO - 2018-10-17 19:27:24 --> Loader Class Initialized
INFO - 2018-10-17 19:27:24 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:24 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:24 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:24 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:24 --> Controller Class Initialized
INFO - 2018-10-17 19:27:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:24 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:24 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:24 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-17 19:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:24 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:24 --> Total execution time: 0.0485
INFO - 2018-10-17 19:27:24 --> Config Class Initialized
INFO - 2018-10-17 19:27:24 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:24 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:24 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:24 --> URI Class Initialized
INFO - 2018-10-17 19:27:24 --> Router Class Initialized
INFO - 2018-10-17 19:27:24 --> Output Class Initialized
INFO - 2018-10-17 19:27:24 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:24 --> CSRF cookie sent
INFO - 2018-10-17 19:27:24 --> Input Class Initialized
INFO - 2018-10-17 19:27:24 --> Language Class Initialized
ERROR - 2018-10-17 19:27:24 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:54 --> Config Class Initialized
INFO - 2018-10-17 19:27:54 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:54 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:54 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:54 --> URI Class Initialized
INFO - 2018-10-17 19:27:54 --> Router Class Initialized
INFO - 2018-10-17 19:27:54 --> Output Class Initialized
INFO - 2018-10-17 19:27:54 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:54 --> CSRF cookie sent
INFO - 2018-10-17 19:27:54 --> Input Class Initialized
INFO - 2018-10-17 19:27:54 --> Language Class Initialized
INFO - 2018-10-17 19:27:54 --> Loader Class Initialized
INFO - 2018-10-17 19:27:54 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:55 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:55 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:55 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:55 --> Controller Class Initialized
INFO - 2018-10-17 19:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:55 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:55 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:55 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-17 19:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:55 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:55 --> Total execution time: 0.0451
INFO - 2018-10-17 19:27:55 --> Config Class Initialized
INFO - 2018-10-17 19:27:55 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:55 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:55 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:55 --> URI Class Initialized
INFO - 2018-10-17 19:27:55 --> Router Class Initialized
INFO - 2018-10-17 19:27:55 --> Output Class Initialized
INFO - 2018-10-17 19:27:55 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:55 --> CSRF cookie sent
INFO - 2018-10-17 19:27:55 --> Input Class Initialized
INFO - 2018-10-17 19:27:55 --> Language Class Initialized
ERROR - 2018-10-17 19:27:55 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:27:56 --> Config Class Initialized
INFO - 2018-10-17 19:27:56 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:56 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:56 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:56 --> URI Class Initialized
INFO - 2018-10-17 19:27:56 --> Router Class Initialized
INFO - 2018-10-17 19:27:56 --> Output Class Initialized
INFO - 2018-10-17 19:27:56 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:56 --> CSRF cookie sent
INFO - 2018-10-17 19:27:56 --> CSRF token verified
INFO - 2018-10-17 19:27:56 --> Input Class Initialized
INFO - 2018-10-17 19:27:56 --> Language Class Initialized
INFO - 2018-10-17 19:27:56 --> Loader Class Initialized
INFO - 2018-10-17 19:27:56 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:56 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:56 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:56 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:56 --> Controller Class Initialized
INFO - 2018-10-17 19:27:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:56 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:56 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:56 --> Form Validation Class Initialized
INFO - 2018-10-17 19:27:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:27:56 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:57 --> Config Class Initialized
INFO - 2018-10-17 19:27:57 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:57 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:57 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:57 --> URI Class Initialized
INFO - 2018-10-17 19:27:57 --> Router Class Initialized
INFO - 2018-10-17 19:27:57 --> Output Class Initialized
INFO - 2018-10-17 19:27:57 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:57 --> CSRF cookie sent
INFO - 2018-10-17 19:27:57 --> Input Class Initialized
INFO - 2018-10-17 19:27:57 --> Language Class Initialized
INFO - 2018-10-17 19:27:57 --> Loader Class Initialized
INFO - 2018-10-17 19:27:57 --> Helper loaded: url_helper
INFO - 2018-10-17 19:27:57 --> Helper loaded: form_helper
INFO - 2018-10-17 19:27:57 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:27:57 --> User Agent Class Initialized
INFO - 2018-10-17 19:27:57 --> Controller Class Initialized
INFO - 2018-10-17 19:27:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:27:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:27:57 --> Pixel_Model class loaded
INFO - 2018-10-17 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-17 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-17 19:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:27:57 --> Final output sent to browser
DEBUG - 2018-10-17 19:27:57 --> Total execution time: 0.0455
INFO - 2018-10-17 19:27:57 --> Config Class Initialized
INFO - 2018-10-17 19:27:57 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:27:57 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:27:57 --> Utf8 Class Initialized
INFO - 2018-10-17 19:27:57 --> URI Class Initialized
INFO - 2018-10-17 19:27:57 --> Router Class Initialized
INFO - 2018-10-17 19:27:57 --> Output Class Initialized
INFO - 2018-10-17 19:27:57 --> Security Class Initialized
DEBUG - 2018-10-17 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:27:57 --> CSRF cookie sent
INFO - 2018-10-17 19:27:57 --> Input Class Initialized
INFO - 2018-10-17 19:27:57 --> Language Class Initialized
ERROR - 2018-10-17 19:27:57 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:28:03 --> Config Class Initialized
INFO - 2018-10-17 19:28:03 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:03 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:03 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:03 --> URI Class Initialized
INFO - 2018-10-17 19:28:03 --> Router Class Initialized
INFO - 2018-10-17 19:28:03 --> Output Class Initialized
INFO - 2018-10-17 19:28:03 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:03 --> CSRF cookie sent
INFO - 2018-10-17 19:28:03 --> CSRF token verified
INFO - 2018-10-17 19:28:03 --> Input Class Initialized
INFO - 2018-10-17 19:28:03 --> Language Class Initialized
INFO - 2018-10-17 19:28:03 --> Loader Class Initialized
INFO - 2018-10-17 19:28:03 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:03 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:03 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:03 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:03 --> Controller Class Initialized
INFO - 2018-10-17 19:28:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:03 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:03 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:03 --> Form Validation Class Initialized
INFO - 2018-10-17 19:28:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:28:03 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:03 --> Config Class Initialized
INFO - 2018-10-17 19:28:03 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:03 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:03 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:03 --> URI Class Initialized
INFO - 2018-10-17 19:28:03 --> Router Class Initialized
INFO - 2018-10-17 19:28:03 --> Output Class Initialized
INFO - 2018-10-17 19:28:03 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:03 --> CSRF cookie sent
INFO - 2018-10-17 19:28:03 --> Input Class Initialized
INFO - 2018-10-17 19:28:03 --> Language Class Initialized
INFO - 2018-10-17 19:28:03 --> Loader Class Initialized
INFO - 2018-10-17 19:28:03 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:03 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:03 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:03 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:03 --> Controller Class Initialized
INFO - 2018-10-17 19:28:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:03 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:03 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:03 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-17 19:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:03 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:03 --> Total execution time: 0.0477
INFO - 2018-10-17 19:28:04 --> Config Class Initialized
INFO - 2018-10-17 19:28:04 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:04 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:04 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:04 --> URI Class Initialized
INFO - 2018-10-17 19:28:04 --> Router Class Initialized
INFO - 2018-10-17 19:28:04 --> Output Class Initialized
INFO - 2018-10-17 19:28:04 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:04 --> CSRF cookie sent
INFO - 2018-10-17 19:28:04 --> Input Class Initialized
INFO - 2018-10-17 19:28:04 --> Language Class Initialized
ERROR - 2018-10-17 19:28:04 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:28:05 --> Config Class Initialized
INFO - 2018-10-17 19:28:05 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:05 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:05 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:05 --> URI Class Initialized
INFO - 2018-10-17 19:28:05 --> Router Class Initialized
INFO - 2018-10-17 19:28:05 --> Output Class Initialized
INFO - 2018-10-17 19:28:05 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:05 --> CSRF cookie sent
INFO - 2018-10-17 19:28:05 --> CSRF token verified
INFO - 2018-10-17 19:28:05 --> Input Class Initialized
INFO - 2018-10-17 19:28:05 --> Language Class Initialized
INFO - 2018-10-17 19:28:05 --> Loader Class Initialized
INFO - 2018-10-17 19:28:05 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:05 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:05 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:05 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:05 --> Controller Class Initialized
INFO - 2018-10-17 19:28:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:05 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:05 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:05 --> Form Validation Class Initialized
INFO - 2018-10-17 19:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 19:28:05 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:05 --> Config Class Initialized
INFO - 2018-10-17 19:28:05 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:05 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:05 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:05 --> URI Class Initialized
INFO - 2018-10-17 19:28:05 --> Router Class Initialized
INFO - 2018-10-17 19:28:05 --> Output Class Initialized
INFO - 2018-10-17 19:28:05 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:05 --> CSRF cookie sent
INFO - 2018-10-17 19:28:05 --> Input Class Initialized
INFO - 2018-10-17 19:28:05 --> Language Class Initialized
INFO - 2018-10-17 19:28:05 --> Loader Class Initialized
INFO - 2018-10-17 19:28:05 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:05 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:05 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:05 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:05 --> Controller Class Initialized
INFO - 2018-10-17 19:28:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:06 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:06 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:06 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-17 19:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:06 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:06 --> Total execution time: 0.0461
INFO - 2018-10-17 19:28:06 --> Config Class Initialized
INFO - 2018-10-17 19:28:06 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:06 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:06 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:06 --> URI Class Initialized
INFO - 2018-10-17 19:28:06 --> Router Class Initialized
INFO - 2018-10-17 19:28:06 --> Output Class Initialized
INFO - 2018-10-17 19:28:06 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:06 --> CSRF cookie sent
INFO - 2018-10-17 19:28:06 --> Input Class Initialized
INFO - 2018-10-17 19:28:06 --> Language Class Initialized
ERROR - 2018-10-17 19:28:06 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:28:09 --> Config Class Initialized
INFO - 2018-10-17 19:28:09 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:09 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:09 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:09 --> URI Class Initialized
INFO - 2018-10-17 19:28:09 --> Router Class Initialized
INFO - 2018-10-17 19:28:09 --> Output Class Initialized
INFO - 2018-10-17 19:28:09 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:09 --> CSRF cookie sent
INFO - 2018-10-17 19:28:09 --> Input Class Initialized
INFO - 2018-10-17 19:28:09 --> Language Class Initialized
INFO - 2018-10-17 19:28:09 --> Loader Class Initialized
INFO - 2018-10-17 19:28:09 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:09 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:09 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:09 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:09 --> Controller Class Initialized
INFO - 2018-10-17 19:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:09 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:09 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:09 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-17 19:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:09 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:09 --> Total execution time: 0.0474
INFO - 2018-10-17 19:28:09 --> Config Class Initialized
INFO - 2018-10-17 19:28:09 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:09 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:09 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:09 --> URI Class Initialized
INFO - 2018-10-17 19:28:09 --> Router Class Initialized
INFO - 2018-10-17 19:28:09 --> Output Class Initialized
INFO - 2018-10-17 19:28:09 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:09 --> CSRF cookie sent
INFO - 2018-10-17 19:28:09 --> Input Class Initialized
INFO - 2018-10-17 19:28:09 --> Language Class Initialized
ERROR - 2018-10-17 19:28:09 --> 404 Page Not Found: Assets/css
INFO - 2018-10-17 19:28:20 --> Config Class Initialized
INFO - 2018-10-17 19:28:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:20 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:20 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:20 --> URI Class Initialized
INFO - 2018-10-17 19:28:20 --> Router Class Initialized
INFO - 2018-10-17 19:28:20 --> Output Class Initialized
INFO - 2018-10-17 19:28:20 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:20 --> CSRF cookie sent
INFO - 2018-10-17 19:28:20 --> Input Class Initialized
INFO - 2018-10-17 19:28:20 --> Language Class Initialized
INFO - 2018-10-17 19:28:20 --> Loader Class Initialized
INFO - 2018-10-17 19:28:20 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:20 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:20 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:20 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:20 --> Controller Class Initialized
INFO - 2018-10-17 19:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:20 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:20 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-17 19:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:20 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:20 --> Total execution time: 0.0590
INFO - 2018-10-17 19:28:23 --> Config Class Initialized
INFO - 2018-10-17 19:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:23 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:23 --> URI Class Initialized
INFO - 2018-10-17 19:28:23 --> Router Class Initialized
INFO - 2018-10-17 19:28:23 --> Output Class Initialized
INFO - 2018-10-17 19:28:23 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:23 --> CSRF cookie sent
INFO - 2018-10-17 19:28:23 --> Input Class Initialized
INFO - 2018-10-17 19:28:23 --> Language Class Initialized
INFO - 2018-10-17 19:28:23 --> Loader Class Initialized
INFO - 2018-10-17 19:28:23 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:23 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:23 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:23 --> Controller Class Initialized
INFO - 2018-10-17 19:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-17 19:28:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:23 --> Config Class Initialized
INFO - 2018-10-17 19:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:23 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:23 --> URI Class Initialized
INFO - 2018-10-17 19:28:23 --> Router Class Initialized
INFO - 2018-10-17 19:28:23 --> Output Class Initialized
INFO - 2018-10-17 19:28:23 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:23 --> CSRF cookie sent
INFO - 2018-10-17 19:28:23 --> Input Class Initialized
INFO - 2018-10-17 19:28:23 --> Language Class Initialized
INFO - 2018-10-17 19:28:23 --> Loader Class Initialized
INFO - 2018-10-17 19:28:23 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:23 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:23 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:23 --> Controller Class Initialized
INFO - 2018-10-17 19:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:23 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:23 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 19:28:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-17 19:28:23 --> Could not find the language line "req_email"
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 19:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:23 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:23 --> Total execution time: 0.0418
INFO - 2018-10-17 19:28:34 --> Config Class Initialized
INFO - 2018-10-17 19:28:34 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:34 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:34 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:34 --> URI Class Initialized
INFO - 2018-10-17 19:28:34 --> Router Class Initialized
INFO - 2018-10-17 19:28:34 --> Output Class Initialized
INFO - 2018-10-17 19:28:34 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:34 --> CSRF cookie sent
INFO - 2018-10-17 19:28:34 --> Input Class Initialized
INFO - 2018-10-17 19:28:34 --> Language Class Initialized
INFO - 2018-10-17 19:28:34 --> Loader Class Initialized
INFO - 2018-10-17 19:28:34 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:34 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:34 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:34 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:34 --> Controller Class Initialized
INFO - 2018-10-17 19:28:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:34 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:34 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-17 19:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:34 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:34 --> Total execution time: 0.0574
INFO - 2018-10-17 19:28:37 --> Config Class Initialized
INFO - 2018-10-17 19:28:37 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:37 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:37 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:37 --> URI Class Initialized
INFO - 2018-10-17 19:28:37 --> Router Class Initialized
INFO - 2018-10-17 19:28:37 --> Output Class Initialized
INFO - 2018-10-17 19:28:37 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:37 --> CSRF cookie sent
INFO - 2018-10-17 19:28:37 --> Input Class Initialized
INFO - 2018-10-17 19:28:37 --> Language Class Initialized
INFO - 2018-10-17 19:28:37 --> Loader Class Initialized
INFO - 2018-10-17 19:28:37 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:37 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:37 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:37 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:37 --> Controller Class Initialized
INFO - 2018-10-17 19:28:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-17 19:28:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:37 --> Config Class Initialized
INFO - 2018-10-17 19:28:37 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:37 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:37 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:37 --> URI Class Initialized
INFO - 2018-10-17 19:28:37 --> Router Class Initialized
INFO - 2018-10-17 19:28:37 --> Output Class Initialized
INFO - 2018-10-17 19:28:37 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:37 --> CSRF cookie sent
INFO - 2018-10-17 19:28:37 --> Input Class Initialized
INFO - 2018-10-17 19:28:37 --> Language Class Initialized
INFO - 2018-10-17 19:28:37 --> Loader Class Initialized
INFO - 2018-10-17 19:28:37 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:37 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:37 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:37 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:37 --> Controller Class Initialized
INFO - 2018-10-17 19:28:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:37 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:37 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:37 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 19:28:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-17 19:28:37 --> Could not find the language line "req_email"
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 19:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:37 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:37 --> Total execution time: 0.0445
INFO - 2018-10-17 19:28:43 --> Config Class Initialized
INFO - 2018-10-17 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:43 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:43 --> URI Class Initialized
INFO - 2018-10-17 19:28:43 --> Router Class Initialized
INFO - 2018-10-17 19:28:43 --> Output Class Initialized
INFO - 2018-10-17 19:28:43 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:43 --> CSRF cookie sent
INFO - 2018-10-17 19:28:43 --> Input Class Initialized
INFO - 2018-10-17 19:28:43 --> Language Class Initialized
INFO - 2018-10-17 19:28:43 --> Loader Class Initialized
INFO - 2018-10-17 19:28:43 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:43 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:43 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:43 --> Controller Class Initialized
INFO - 2018-10-17 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-17 19:28:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:43 --> Config Class Initialized
INFO - 2018-10-17 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-17 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-17 19:28:43 --> Utf8 Class Initialized
INFO - 2018-10-17 19:28:43 --> URI Class Initialized
INFO - 2018-10-17 19:28:43 --> Router Class Initialized
INFO - 2018-10-17 19:28:43 --> Output Class Initialized
INFO - 2018-10-17 19:28:43 --> Security Class Initialized
DEBUG - 2018-10-17 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 19:28:43 --> CSRF cookie sent
INFO - 2018-10-17 19:28:43 --> Input Class Initialized
INFO - 2018-10-17 19:28:43 --> Language Class Initialized
INFO - 2018-10-17 19:28:43 --> Loader Class Initialized
INFO - 2018-10-17 19:28:43 --> Helper loaded: url_helper
INFO - 2018-10-17 19:28:43 --> Helper loaded: form_helper
INFO - 2018-10-17 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-17 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 19:28:43 --> User Agent Class Initialized
INFO - 2018-10-17 19:28:43 --> Controller Class Initialized
INFO - 2018-10-17 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 19:28:43 --> Pixel_Model class loaded
INFO - 2018-10-17 19:28:43 --> Database Driver Class Initialized
INFO - 2018-10-17 19:28:43 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-17 19:28:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-17 19:28:43 --> Could not find the language line "req_email"
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-17 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 19:28:43 --> Final output sent to browser
DEBUG - 2018-10-17 19:28:43 --> Total execution time: 0.0455
INFO - 2018-10-17 22:51:07 --> Config Class Initialized
INFO - 2018-10-17 22:51:07 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:07 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:07 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:07 --> URI Class Initialized
DEBUG - 2018-10-17 22:51:07 --> No URI present. Default controller set.
INFO - 2018-10-17 22:51:07 --> Router Class Initialized
INFO - 2018-10-17 22:51:07 --> Output Class Initialized
INFO - 2018-10-17 22:51:07 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:07 --> CSRF cookie sent
INFO - 2018-10-17 22:51:07 --> Input Class Initialized
INFO - 2018-10-17 22:51:07 --> Language Class Initialized
INFO - 2018-10-17 22:51:07 --> Loader Class Initialized
INFO - 2018-10-17 22:51:07 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:07 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:07 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:07 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:07 --> Controller Class Initialized
INFO - 2018-10-17 22:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:07 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:07 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:07 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:07 --> Total execution time: 0.0354
INFO - 2018-10-17 22:51:07 --> Config Class Initialized
INFO - 2018-10-17 22:51:07 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:07 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:07 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:07 --> URI Class Initialized
DEBUG - 2018-10-17 22:51:07 --> No URI present. Default controller set.
INFO - 2018-10-17 22:51:07 --> Router Class Initialized
INFO - 2018-10-17 22:51:07 --> Output Class Initialized
INFO - 2018-10-17 22:51:07 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:07 --> CSRF cookie sent
INFO - 2018-10-17 22:51:07 --> Input Class Initialized
INFO - 2018-10-17 22:51:07 --> Language Class Initialized
INFO - 2018-10-17 22:51:07 --> Loader Class Initialized
INFO - 2018-10-17 22:51:07 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:07 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:07 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:07 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:07 --> Controller Class Initialized
INFO - 2018-10-17 22:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:07 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:07 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-17 22:51:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:07 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:07 --> Total execution time: 0.0347
INFO - 2018-10-17 22:51:10 --> Config Class Initialized
INFO - 2018-10-17 22:51:10 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:10 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:10 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:10 --> URI Class Initialized
INFO - 2018-10-17 22:51:10 --> Router Class Initialized
INFO - 2018-10-17 22:51:10 --> Output Class Initialized
INFO - 2018-10-17 22:51:10 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:10 --> CSRF cookie sent
INFO - 2018-10-17 22:51:10 --> CSRF token verified
INFO - 2018-10-17 22:51:10 --> Input Class Initialized
INFO - 2018-10-17 22:51:10 --> Language Class Initialized
INFO - 2018-10-17 22:51:10 --> Loader Class Initialized
INFO - 2018-10-17 22:51:10 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:10 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:10 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:10 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:10 --> Controller Class Initialized
INFO - 2018-10-17 22:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:10 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:10 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:10 --> Form Validation Class Initialized
INFO - 2018-10-17 22:51:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 22:51:10 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:10 --> Config Class Initialized
INFO - 2018-10-17 22:51:10 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:10 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:10 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:10 --> URI Class Initialized
INFO - 2018-10-17 22:51:10 --> Router Class Initialized
INFO - 2018-10-17 22:51:10 --> Output Class Initialized
INFO - 2018-10-17 22:51:10 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:10 --> CSRF cookie sent
INFO - 2018-10-17 22:51:10 --> Input Class Initialized
INFO - 2018-10-17 22:51:10 --> Language Class Initialized
INFO - 2018-10-17 22:51:10 --> Loader Class Initialized
INFO - 2018-10-17 22:51:10 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:10 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:10 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:10 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:10 --> Controller Class Initialized
INFO - 2018-10-17 22:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:10 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:10 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:10 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-17 22:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:10 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:10 --> Total execution time: 0.0555
INFO - 2018-10-17 22:51:15 --> Config Class Initialized
INFO - 2018-10-17 22:51:15 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:15 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:15 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:15 --> URI Class Initialized
INFO - 2018-10-17 22:51:15 --> Router Class Initialized
INFO - 2018-10-17 22:51:15 --> Output Class Initialized
INFO - 2018-10-17 22:51:15 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:15 --> CSRF cookie sent
INFO - 2018-10-17 22:51:15 --> CSRF token verified
INFO - 2018-10-17 22:51:15 --> Input Class Initialized
INFO - 2018-10-17 22:51:15 --> Language Class Initialized
INFO - 2018-10-17 22:51:15 --> Loader Class Initialized
INFO - 2018-10-17 22:51:15 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:15 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:15 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:15 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:15 --> Controller Class Initialized
INFO - 2018-10-17 22:51:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:15 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:15 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:15 --> Form Validation Class Initialized
INFO - 2018-10-17 22:51:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 22:51:15 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:15 --> Config Class Initialized
INFO - 2018-10-17 22:51:15 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:15 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:15 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:15 --> URI Class Initialized
INFO - 2018-10-17 22:51:15 --> Router Class Initialized
INFO - 2018-10-17 22:51:15 --> Output Class Initialized
INFO - 2018-10-17 22:51:15 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:15 --> CSRF cookie sent
INFO - 2018-10-17 22:51:15 --> Input Class Initialized
INFO - 2018-10-17 22:51:15 --> Language Class Initialized
INFO - 2018-10-17 22:51:15 --> Loader Class Initialized
INFO - 2018-10-17 22:51:15 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:15 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:15 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:15 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:15 --> Controller Class Initialized
INFO - 2018-10-17 22:51:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:15 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:15 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:15 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-17 22:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:15 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:15 --> Total execution time: 0.0464
INFO - 2018-10-17 22:51:20 --> Config Class Initialized
INFO - 2018-10-17 22:51:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:20 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:20 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:20 --> URI Class Initialized
INFO - 2018-10-17 22:51:20 --> Router Class Initialized
INFO - 2018-10-17 22:51:20 --> Output Class Initialized
INFO - 2018-10-17 22:51:20 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:20 --> CSRF cookie sent
INFO - 2018-10-17 22:51:20 --> CSRF token verified
INFO - 2018-10-17 22:51:20 --> Input Class Initialized
INFO - 2018-10-17 22:51:20 --> Language Class Initialized
INFO - 2018-10-17 22:51:20 --> Loader Class Initialized
INFO - 2018-10-17 22:51:20 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:20 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:20 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:20 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:20 --> Controller Class Initialized
INFO - 2018-10-17 22:51:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:20 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:20 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:20 --> Form Validation Class Initialized
INFO - 2018-10-17 22:51:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 22:51:20 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:20 --> Config Class Initialized
INFO - 2018-10-17 22:51:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:20 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:20 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:20 --> URI Class Initialized
INFO - 2018-10-17 22:51:20 --> Router Class Initialized
INFO - 2018-10-17 22:51:20 --> Output Class Initialized
INFO - 2018-10-17 22:51:20 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:20 --> CSRF cookie sent
INFO - 2018-10-17 22:51:20 --> Input Class Initialized
INFO - 2018-10-17 22:51:20 --> Language Class Initialized
INFO - 2018-10-17 22:51:20 --> Loader Class Initialized
INFO - 2018-10-17 22:51:20 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:20 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:20 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:20 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:20 --> Controller Class Initialized
INFO - 2018-10-17 22:51:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:20 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:20 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:20 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 22:51:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:20 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:20 --> Total execution time: 0.0501
INFO - 2018-10-17 22:51:21 --> Config Class Initialized
INFO - 2018-10-17 22:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:21 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:21 --> URI Class Initialized
INFO - 2018-10-17 22:51:21 --> Router Class Initialized
INFO - 2018-10-17 22:51:21 --> Output Class Initialized
INFO - 2018-10-17 22:51:21 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:21 --> CSRF cookie sent
INFO - 2018-10-17 22:51:21 --> CSRF token verified
INFO - 2018-10-17 22:51:21 --> Input Class Initialized
INFO - 2018-10-17 22:51:21 --> Language Class Initialized
INFO - 2018-10-17 22:51:21 --> Loader Class Initialized
INFO - 2018-10-17 22:51:21 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:21 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:21 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:21 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:21 --> Controller Class Initialized
INFO - 2018-10-17 22:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:21 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:21 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:21 --> Form Validation Class Initialized
INFO - 2018-10-17 22:51:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 22:51:21 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:21 --> Config Class Initialized
INFO - 2018-10-17 22:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:21 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:21 --> URI Class Initialized
INFO - 2018-10-17 22:51:21 --> Router Class Initialized
INFO - 2018-10-17 22:51:21 --> Output Class Initialized
INFO - 2018-10-17 22:51:21 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:21 --> CSRF cookie sent
INFO - 2018-10-17 22:51:21 --> Input Class Initialized
INFO - 2018-10-17 22:51:21 --> Language Class Initialized
INFO - 2018-10-17 22:51:21 --> Loader Class Initialized
INFO - 2018-10-17 22:51:21 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:21 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:21 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:21 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:21 --> Controller Class Initialized
INFO - 2018-10-17 22:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:21 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:21 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:21 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 22:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:21 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:21 --> Total execution time: 0.0479
INFO - 2018-10-17 22:51:33 --> Config Class Initialized
INFO - 2018-10-17 22:51:33 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:33 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:33 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:33 --> URI Class Initialized
INFO - 2018-10-17 22:51:33 --> Router Class Initialized
INFO - 2018-10-17 22:51:33 --> Output Class Initialized
INFO - 2018-10-17 22:51:33 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:33 --> CSRF cookie sent
INFO - 2018-10-17 22:51:33 --> Input Class Initialized
INFO - 2018-10-17 22:51:33 --> Language Class Initialized
INFO - 2018-10-17 22:51:33 --> Loader Class Initialized
INFO - 2018-10-17 22:51:33 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:33 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:33 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:33 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:33 --> Controller Class Initialized
INFO - 2018-10-17 22:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:33 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:33 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:33 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-17 22:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:33 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:33 --> Total execution time: 0.0393
INFO - 2018-10-17 22:51:34 --> Config Class Initialized
INFO - 2018-10-17 22:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:34 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:34 --> URI Class Initialized
INFO - 2018-10-17 22:51:34 --> Router Class Initialized
INFO - 2018-10-17 22:51:34 --> Output Class Initialized
INFO - 2018-10-17 22:51:34 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:34 --> CSRF cookie sent
INFO - 2018-10-17 22:51:34 --> CSRF token verified
INFO - 2018-10-17 22:51:34 --> Input Class Initialized
INFO - 2018-10-17 22:51:34 --> Language Class Initialized
INFO - 2018-10-17 22:51:34 --> Loader Class Initialized
INFO - 2018-10-17 22:51:34 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:34 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:34 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:34 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:34 --> Controller Class Initialized
INFO - 2018-10-17 22:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:34 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:34 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:34 --> Form Validation Class Initialized
INFO - 2018-10-17 22:51:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-17 22:51:34 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:35 --> Config Class Initialized
INFO - 2018-10-17 22:51:35 --> Hooks Class Initialized
DEBUG - 2018-10-17 22:51:35 --> UTF-8 Support Enabled
INFO - 2018-10-17 22:51:35 --> Utf8 Class Initialized
INFO - 2018-10-17 22:51:35 --> URI Class Initialized
INFO - 2018-10-17 22:51:35 --> Router Class Initialized
INFO - 2018-10-17 22:51:35 --> Output Class Initialized
INFO - 2018-10-17 22:51:35 --> Security Class Initialized
DEBUG - 2018-10-17 22:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 22:51:35 --> CSRF cookie sent
INFO - 2018-10-17 22:51:35 --> Input Class Initialized
INFO - 2018-10-17 22:51:35 --> Language Class Initialized
INFO - 2018-10-17 22:51:35 --> Loader Class Initialized
INFO - 2018-10-17 22:51:35 --> Helper loaded: url_helper
INFO - 2018-10-17 22:51:35 --> Helper loaded: form_helper
INFO - 2018-10-17 22:51:35 --> Helper loaded: language_helper
DEBUG - 2018-10-17 22:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-17 22:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 22:51:35 --> User Agent Class Initialized
INFO - 2018-10-17 22:51:35 --> Controller Class Initialized
INFO - 2018-10-17 22:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-17 22:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-17 22:51:35 --> Pixel_Model class loaded
INFO - 2018-10-17 22:51:35 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:35 --> Database Driver Class Initialized
INFO - 2018-10-17 22:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-17 22:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-17 22:51:35 --> Final output sent to browser
DEBUG - 2018-10-17 22:51:35 --> Total execution time: 0.0481

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-18 09:15:32 --> Config Class Initialized
INFO - 2018-10-18 09:15:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:15:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:15:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:15:32 --> URI Class Initialized
DEBUG - 2018-10-18 09:15:32 --> No URI present. Default controller set.
INFO - 2018-10-18 09:15:32 --> Router Class Initialized
INFO - 2018-10-18 09:15:32 --> Output Class Initialized
INFO - 2018-10-18 09:15:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:15:32 --> CSRF cookie sent
INFO - 2018-10-18 09:15:32 --> Input Class Initialized
INFO - 2018-10-18 09:15:32 --> Language Class Initialized
INFO - 2018-10-18 09:15:32 --> Loader Class Initialized
INFO - 2018-10-18 09:15:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:15:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:15:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:15:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:15:32 --> Controller Class Initialized
INFO - 2018-10-18 09:15:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:15:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:15:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:15:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:15:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:15:32 --> Final output sent to browser
DEBUG - 2018-10-18 09:15:32 --> Total execution time: 0.0432
INFO - 2018-10-18 09:18:09 --> Config Class Initialized
INFO - 2018-10-18 09:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:18:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:18:09 --> URI Class Initialized
INFO - 2018-10-18 09:18:09 --> Router Class Initialized
INFO - 2018-10-18 09:18:09 --> Output Class Initialized
INFO - 2018-10-18 09:18:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:18:09 --> CSRF cookie sent
INFO - 2018-10-18 09:18:09 --> Input Class Initialized
INFO - 2018-10-18 09:18:09 --> Language Class Initialized
INFO - 2018-10-18 09:18:09 --> Loader Class Initialized
INFO - 2018-10-18 09:18:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:18:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:18:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:18:09 --> Controller Class Initialized
INFO - 2018-10-18 09:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:18:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:18:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:18:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:18:09 --> Total execution time: 0.0520
INFO - 2018-10-18 09:23:21 --> Config Class Initialized
INFO - 2018-10-18 09:23:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:21 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:21 --> URI Class Initialized
INFO - 2018-10-18 09:23:21 --> Router Class Initialized
INFO - 2018-10-18 09:23:21 --> Output Class Initialized
INFO - 2018-10-18 09:23:21 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:21 --> CSRF cookie sent
INFO - 2018-10-18 09:23:21 --> CSRF token verified
INFO - 2018-10-18 09:23:21 --> Input Class Initialized
INFO - 2018-10-18 09:23:21 --> Language Class Initialized
INFO - 2018-10-18 09:23:21 --> Loader Class Initialized
INFO - 2018-10-18 09:23:21 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:21 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:21 --> Controller Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Config Class Initialized
INFO - 2018-10-18 09:23:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:21 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:21 --> URI Class Initialized
INFO - 2018-10-18 09:23:21 --> Router Class Initialized
INFO - 2018-10-18 09:23:21 --> Output Class Initialized
INFO - 2018-10-18 09:23:21 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:21 --> CSRF cookie sent
INFO - 2018-10-18 09:23:21 --> Input Class Initialized
INFO - 2018-10-18 09:23:21 --> Language Class Initialized
INFO - 2018-10-18 09:23:21 --> Loader Class Initialized
INFO - 2018-10-18 09:23:21 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:21 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:21 --> Controller Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:21 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:21 --> Total execution time: 0.0491
INFO - 2018-10-18 09:23:32 --> Config Class Initialized
INFO - 2018-10-18 09:23:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:32 --> URI Class Initialized
INFO - 2018-10-18 09:23:32 --> Router Class Initialized
INFO - 2018-10-18 09:23:32 --> Output Class Initialized
INFO - 2018-10-18 09:23:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:32 --> CSRF cookie sent
INFO - 2018-10-18 09:23:32 --> CSRF token verified
INFO - 2018-10-18 09:23:32 --> Input Class Initialized
INFO - 2018-10-18 09:23:32 --> Language Class Initialized
INFO - 2018-10-18 09:23:32 --> Loader Class Initialized
INFO - 2018-10-18 09:23:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:32 --> Controller Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Config Class Initialized
INFO - 2018-10-18 09:23:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:32 --> URI Class Initialized
INFO - 2018-10-18 09:23:32 --> Router Class Initialized
INFO - 2018-10-18 09:23:32 --> Output Class Initialized
INFO - 2018-10-18 09:23:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:32 --> CSRF cookie sent
INFO - 2018-10-18 09:23:32 --> Input Class Initialized
INFO - 2018-10-18 09:23:32 --> Language Class Initialized
INFO - 2018-10-18 09:23:32 --> Loader Class Initialized
INFO - 2018-10-18 09:23:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:32 --> Controller Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:32 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:32 --> Total execution time: 0.0473
INFO - 2018-10-18 09:23:39 --> Config Class Initialized
INFO - 2018-10-18 09:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:39 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:39 --> URI Class Initialized
INFO - 2018-10-18 09:23:39 --> Router Class Initialized
INFO - 2018-10-18 09:23:39 --> Output Class Initialized
INFO - 2018-10-18 09:23:39 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:39 --> CSRF cookie sent
INFO - 2018-10-18 09:23:39 --> CSRF token verified
INFO - 2018-10-18 09:23:39 --> Input Class Initialized
INFO - 2018-10-18 09:23:39 --> Language Class Initialized
INFO - 2018-10-18 09:23:39 --> Loader Class Initialized
INFO - 2018-10-18 09:23:39 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:39 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:39 --> Controller Class Initialized
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:39 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:39 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:39 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:39 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:39 --> Config Class Initialized
INFO - 2018-10-18 09:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:39 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:39 --> URI Class Initialized
INFO - 2018-10-18 09:23:39 --> Router Class Initialized
INFO - 2018-10-18 09:23:39 --> Output Class Initialized
INFO - 2018-10-18 09:23:39 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:39 --> CSRF cookie sent
INFO - 2018-10-18 09:23:39 --> Input Class Initialized
INFO - 2018-10-18 09:23:39 --> Language Class Initialized
INFO - 2018-10-18 09:23:39 --> Loader Class Initialized
INFO - 2018-10-18 09:23:39 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:39 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:40 --> Controller Class Initialized
INFO - 2018-10-18 09:23:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:40 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:40 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:40 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:40 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:40 --> Total execution time: 0.0452
INFO - 2018-10-18 09:23:42 --> Config Class Initialized
INFO - 2018-10-18 09:23:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:42 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:42 --> URI Class Initialized
INFO - 2018-10-18 09:23:42 --> Router Class Initialized
INFO - 2018-10-18 09:23:42 --> Output Class Initialized
INFO - 2018-10-18 09:23:42 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:42 --> CSRF cookie sent
INFO - 2018-10-18 09:23:42 --> CSRF token verified
INFO - 2018-10-18 09:23:42 --> Input Class Initialized
INFO - 2018-10-18 09:23:42 --> Language Class Initialized
INFO - 2018-10-18 09:23:42 --> Loader Class Initialized
INFO - 2018-10-18 09:23:42 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:42 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:42 --> Controller Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Config Class Initialized
INFO - 2018-10-18 09:23:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:42 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:42 --> URI Class Initialized
INFO - 2018-10-18 09:23:42 --> Router Class Initialized
INFO - 2018-10-18 09:23:42 --> Output Class Initialized
INFO - 2018-10-18 09:23:42 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:42 --> CSRF cookie sent
INFO - 2018-10-18 09:23:42 --> Input Class Initialized
INFO - 2018-10-18 09:23:42 --> Language Class Initialized
INFO - 2018-10-18 09:23:42 --> Loader Class Initialized
INFO - 2018-10-18 09:23:42 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:42 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:42 --> Controller Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:42 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:42 --> Total execution time: 0.0404
INFO - 2018-10-18 09:23:49 --> Config Class Initialized
INFO - 2018-10-18 09:23:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:49 --> URI Class Initialized
INFO - 2018-10-18 09:23:49 --> Router Class Initialized
INFO - 2018-10-18 09:23:49 --> Output Class Initialized
INFO - 2018-10-18 09:23:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:49 --> CSRF cookie sent
INFO - 2018-10-18 09:23:49 --> Input Class Initialized
INFO - 2018-10-18 09:23:49 --> Language Class Initialized
ERROR - 2018-10-18 09:23:49 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:25:13 --> Config Class Initialized
INFO - 2018-10-18 09:25:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:25:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:25:13 --> Utf8 Class Initialized
INFO - 2018-10-18 09:25:13 --> URI Class Initialized
INFO - 2018-10-18 09:25:13 --> Router Class Initialized
INFO - 2018-10-18 09:25:13 --> Output Class Initialized
INFO - 2018-10-18 09:25:13 --> Security Class Initialized
DEBUG - 2018-10-18 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:25:13 --> CSRF cookie sent
INFO - 2018-10-18 09:25:13 --> Input Class Initialized
INFO - 2018-10-18 09:25:13 --> Language Class Initialized
INFO - 2018-10-18 09:25:13 --> Loader Class Initialized
INFO - 2018-10-18 09:25:13 --> Helper loaded: url_helper
INFO - 2018-10-18 09:25:13 --> Helper loaded: form_helper
INFO - 2018-10-18 09:25:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:25:13 --> User Agent Class Initialized
INFO - 2018-10-18 09:25:13 --> Controller Class Initialized
INFO - 2018-10-18 09:25:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:25:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:25:13 --> Pixel_Model class loaded
INFO - 2018-10-18 09:25:13 --> Database Driver Class Initialized
INFO - 2018-10-18 09:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:25:13 --> Database Driver Class Initialized
INFO - 2018-10-18 09:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:25:13 --> Final output sent to browser
DEBUG - 2018-10-18 09:25:13 --> Total execution time: 0.0521
INFO - 2018-10-18 09:25:25 --> Config Class Initialized
INFO - 2018-10-18 09:25:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:25:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:25:25 --> Utf8 Class Initialized
INFO - 2018-10-18 09:25:25 --> URI Class Initialized
INFO - 2018-10-18 09:25:25 --> Router Class Initialized
INFO - 2018-10-18 09:25:25 --> Output Class Initialized
INFO - 2018-10-18 09:25:25 --> Security Class Initialized
DEBUG - 2018-10-18 09:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:25:25 --> CSRF cookie sent
INFO - 2018-10-18 09:25:25 --> Input Class Initialized
INFO - 2018-10-18 09:25:25 --> Language Class Initialized
ERROR - 2018-10-18 09:25:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:32:45 --> Config Class Initialized
INFO - 2018-10-18 09:32:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:32:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:32:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:32:45 --> URI Class Initialized
INFO - 2018-10-18 09:32:45 --> Router Class Initialized
INFO - 2018-10-18 09:32:45 --> Output Class Initialized
INFO - 2018-10-18 09:32:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:32:45 --> CSRF cookie sent
INFO - 2018-10-18 09:32:45 --> Input Class Initialized
INFO - 2018-10-18 09:32:45 --> Language Class Initialized
INFO - 2018-10-18 09:32:45 --> Loader Class Initialized
INFO - 2018-10-18 09:32:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:32:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:32:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:32:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:32:45 --> Controller Class Initialized
INFO - 2018-10-18 09:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:32:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:32:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:32:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:32:45 --> Final output sent to browser
DEBUG - 2018-10-18 09:32:45 --> Total execution time: 0.0518
INFO - 2018-10-18 09:32:51 --> Config Class Initialized
INFO - 2018-10-18 09:32:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:32:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:32:51 --> Utf8 Class Initialized
INFO - 2018-10-18 09:32:51 --> URI Class Initialized
INFO - 2018-10-18 09:32:51 --> Router Class Initialized
INFO - 2018-10-18 09:32:51 --> Output Class Initialized
INFO - 2018-10-18 09:32:51 --> Security Class Initialized
DEBUG - 2018-10-18 09:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:32:51 --> CSRF cookie sent
INFO - 2018-10-18 09:32:51 --> Input Class Initialized
INFO - 2018-10-18 09:32:51 --> Language Class Initialized
ERROR - 2018-10-18 09:32:51 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:33:09 --> Config Class Initialized
INFO - 2018-10-18 09:33:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:33:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:33:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:33:09 --> URI Class Initialized
INFO - 2018-10-18 09:33:09 --> Router Class Initialized
INFO - 2018-10-18 09:33:09 --> Output Class Initialized
INFO - 2018-10-18 09:33:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:33:09 --> CSRF cookie sent
INFO - 2018-10-18 09:33:09 --> Input Class Initialized
INFO - 2018-10-18 09:33:09 --> Language Class Initialized
INFO - 2018-10-18 09:33:09 --> Loader Class Initialized
INFO - 2018-10-18 09:33:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:33:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:33:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:33:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:33:09 --> Controller Class Initialized
INFO - 2018-10-18 09:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:33:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:33:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:33:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:33:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:33:09 --> Total execution time: 0.0543
INFO - 2018-10-18 09:33:11 --> Config Class Initialized
INFO - 2018-10-18 09:33:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:33:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:33:11 --> Utf8 Class Initialized
INFO - 2018-10-18 09:33:11 --> URI Class Initialized
INFO - 2018-10-18 09:33:11 --> Router Class Initialized
INFO - 2018-10-18 09:33:11 --> Output Class Initialized
INFO - 2018-10-18 09:33:11 --> Security Class Initialized
DEBUG - 2018-10-18 09:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:33:11 --> CSRF cookie sent
INFO - 2018-10-18 09:33:11 --> Input Class Initialized
INFO - 2018-10-18 09:33:11 --> Language Class Initialized
ERROR - 2018-10-18 09:33:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:03 --> Config Class Initialized
INFO - 2018-10-18 09:34:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:03 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:03 --> URI Class Initialized
INFO - 2018-10-18 09:34:03 --> Router Class Initialized
INFO - 2018-10-18 09:34:03 --> Output Class Initialized
INFO - 2018-10-18 09:34:03 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:03 --> CSRF cookie sent
INFO - 2018-10-18 09:34:03 --> Input Class Initialized
INFO - 2018-10-18 09:34:03 --> Language Class Initialized
INFO - 2018-10-18 09:34:03 --> Loader Class Initialized
INFO - 2018-10-18 09:34:03 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:03 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:03 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:03 --> Controller Class Initialized
INFO - 2018-10-18 09:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:03 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:03 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:03 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:03 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:03 --> Total execution time: 0.0482
INFO - 2018-10-18 09:34:08 --> Config Class Initialized
INFO - 2018-10-18 09:34:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:08 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:08 --> URI Class Initialized
INFO - 2018-10-18 09:34:08 --> Router Class Initialized
INFO - 2018-10-18 09:34:08 --> Output Class Initialized
INFO - 2018-10-18 09:34:08 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:08 --> CSRF cookie sent
INFO - 2018-10-18 09:34:08 --> Input Class Initialized
INFO - 2018-10-18 09:34:08 --> Language Class Initialized
ERROR - 2018-10-18 09:34:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:30 --> Config Class Initialized
INFO - 2018-10-18 09:34:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:30 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:30 --> URI Class Initialized
INFO - 2018-10-18 09:34:30 --> Router Class Initialized
INFO - 2018-10-18 09:34:30 --> Output Class Initialized
INFO - 2018-10-18 09:34:30 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:30 --> CSRF cookie sent
INFO - 2018-10-18 09:34:30 --> Input Class Initialized
INFO - 2018-10-18 09:34:30 --> Language Class Initialized
INFO - 2018-10-18 09:34:30 --> Loader Class Initialized
INFO - 2018-10-18 09:34:30 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:30 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:30 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:30 --> Controller Class Initialized
INFO - 2018-10-18 09:34:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:30 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:30 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:30 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:30 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:30 --> Total execution time: 0.0476
INFO - 2018-10-18 09:34:36 --> Config Class Initialized
INFO - 2018-10-18 09:34:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:36 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:36 --> URI Class Initialized
INFO - 2018-10-18 09:34:36 --> Router Class Initialized
INFO - 2018-10-18 09:34:36 --> Output Class Initialized
INFO - 2018-10-18 09:34:36 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:36 --> CSRF cookie sent
INFO - 2018-10-18 09:34:36 --> Input Class Initialized
INFO - 2018-10-18 09:34:36 --> Language Class Initialized
ERROR - 2018-10-18 09:34:36 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:41 --> Config Class Initialized
INFO - 2018-10-18 09:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:41 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:41 --> URI Class Initialized
INFO - 2018-10-18 09:34:41 --> Router Class Initialized
INFO - 2018-10-18 09:34:41 --> Output Class Initialized
INFO - 2018-10-18 09:34:41 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:41 --> CSRF cookie sent
INFO - 2018-10-18 09:34:41 --> CSRF token verified
INFO - 2018-10-18 09:34:41 --> Input Class Initialized
INFO - 2018-10-18 09:34:41 --> Language Class Initialized
INFO - 2018-10-18 09:34:41 --> Loader Class Initialized
INFO - 2018-10-18 09:34:41 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:41 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:41 --> Controller Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Config Class Initialized
INFO - 2018-10-18 09:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:41 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:41 --> URI Class Initialized
INFO - 2018-10-18 09:34:41 --> Router Class Initialized
INFO - 2018-10-18 09:34:41 --> Output Class Initialized
INFO - 2018-10-18 09:34:41 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:41 --> CSRF cookie sent
INFO - 2018-10-18 09:34:41 --> Input Class Initialized
INFO - 2018-10-18 09:34:41 --> Language Class Initialized
INFO - 2018-10-18 09:34:41 --> Loader Class Initialized
INFO - 2018-10-18 09:34:41 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:41 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:41 --> Controller Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:41 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:41 --> Total execution time: 0.0486
INFO - 2018-10-18 09:34:44 --> Config Class Initialized
INFO - 2018-10-18 09:34:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:44 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:44 --> URI Class Initialized
INFO - 2018-10-18 09:34:44 --> Router Class Initialized
INFO - 2018-10-18 09:34:44 --> Output Class Initialized
INFO - 2018-10-18 09:34:44 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:44 --> CSRF cookie sent
INFO - 2018-10-18 09:34:44 --> Input Class Initialized
INFO - 2018-10-18 09:34:44 --> Language Class Initialized
ERROR - 2018-10-18 09:34:44 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:45 --> Config Class Initialized
INFO - 2018-10-18 09:34:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:45 --> URI Class Initialized
INFO - 2018-10-18 09:34:45 --> Router Class Initialized
INFO - 2018-10-18 09:34:45 --> Output Class Initialized
INFO - 2018-10-18 09:34:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:45 --> CSRF cookie sent
INFO - 2018-10-18 09:34:45 --> CSRF token verified
INFO - 2018-10-18 09:34:45 --> Input Class Initialized
INFO - 2018-10-18 09:34:45 --> Language Class Initialized
INFO - 2018-10-18 09:34:45 --> Loader Class Initialized
INFO - 2018-10-18 09:34:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:45 --> Controller Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Config Class Initialized
INFO - 2018-10-18 09:34:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:45 --> URI Class Initialized
INFO - 2018-10-18 09:34:45 --> Router Class Initialized
INFO - 2018-10-18 09:34:45 --> Output Class Initialized
INFO - 2018-10-18 09:34:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:45 --> CSRF cookie sent
INFO - 2018-10-18 09:34:45 --> Input Class Initialized
INFO - 2018-10-18 09:34:45 --> Language Class Initialized
INFO - 2018-10-18 09:34:45 --> Loader Class Initialized
INFO - 2018-10-18 09:34:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:45 --> Controller Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:45 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:45 --> Total execution time: 0.0499
INFO - 2018-10-18 09:34:48 --> Config Class Initialized
INFO - 2018-10-18 09:34:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:48 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:48 --> URI Class Initialized
INFO - 2018-10-18 09:34:48 --> Router Class Initialized
INFO - 2018-10-18 09:34:48 --> Output Class Initialized
INFO - 2018-10-18 09:34:48 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:48 --> CSRF cookie sent
INFO - 2018-10-18 09:34:48 --> Input Class Initialized
INFO - 2018-10-18 09:34:48 --> Language Class Initialized
ERROR - 2018-10-18 09:34:48 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:49 --> Config Class Initialized
INFO - 2018-10-18 09:34:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:49 --> URI Class Initialized
INFO - 2018-10-18 09:34:49 --> Router Class Initialized
INFO - 2018-10-18 09:34:49 --> Output Class Initialized
INFO - 2018-10-18 09:34:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:49 --> CSRF cookie sent
INFO - 2018-10-18 09:34:49 --> CSRF token verified
INFO - 2018-10-18 09:34:49 --> Input Class Initialized
INFO - 2018-10-18 09:34:49 --> Language Class Initialized
INFO - 2018-10-18 09:34:49 --> Loader Class Initialized
INFO - 2018-10-18 09:34:49 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:49 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:49 --> Controller Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Config Class Initialized
INFO - 2018-10-18 09:34:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:49 --> URI Class Initialized
INFO - 2018-10-18 09:34:49 --> Router Class Initialized
INFO - 2018-10-18 09:34:49 --> Output Class Initialized
INFO - 2018-10-18 09:34:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:49 --> CSRF cookie sent
INFO - 2018-10-18 09:34:49 --> Input Class Initialized
INFO - 2018-10-18 09:34:49 --> Language Class Initialized
INFO - 2018-10-18 09:34:49 --> Loader Class Initialized
INFO - 2018-10-18 09:34:49 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:49 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:49 --> Controller Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:49 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:49 --> Total execution time: 0.0578
INFO - 2018-10-18 09:34:52 --> Config Class Initialized
INFO - 2018-10-18 09:34:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:52 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:52 --> URI Class Initialized
INFO - 2018-10-18 09:34:52 --> Router Class Initialized
INFO - 2018-10-18 09:34:52 --> Output Class Initialized
INFO - 2018-10-18 09:34:52 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:52 --> CSRF cookie sent
INFO - 2018-10-18 09:34:52 --> Input Class Initialized
INFO - 2018-10-18 09:34:52 --> Language Class Initialized
ERROR - 2018-10-18 09:34:52 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:40:15 --> Config Class Initialized
INFO - 2018-10-18 09:40:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:40:15 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:40:15 --> Utf8 Class Initialized
INFO - 2018-10-18 09:40:15 --> URI Class Initialized
INFO - 2018-10-18 09:40:15 --> Router Class Initialized
INFO - 2018-10-18 09:40:15 --> Output Class Initialized
INFO - 2018-10-18 09:40:15 --> Security Class Initialized
DEBUG - 2018-10-18 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:40:15 --> CSRF cookie sent
INFO - 2018-10-18 09:40:15 --> Input Class Initialized
INFO - 2018-10-18 09:40:15 --> Language Class Initialized
INFO - 2018-10-18 09:40:15 --> Loader Class Initialized
INFO - 2018-10-18 09:40:15 --> Helper loaded: url_helper
INFO - 2018-10-18 09:40:15 --> Helper loaded: form_helper
INFO - 2018-10-18 09:40:15 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:40:15 --> User Agent Class Initialized
INFO - 2018-10-18 09:40:15 --> Controller Class Initialized
INFO - 2018-10-18 09:40:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:40:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:40:15 --> Pixel_Model class loaded
INFO - 2018-10-18 09:40:15 --> Database Driver Class Initialized
INFO - 2018-10-18 09:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:40:15 --> Database Driver Class Initialized
INFO - 2018-10-18 09:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:40:15 --> Final output sent to browser
DEBUG - 2018-10-18 09:40:15 --> Total execution time: 0.0490
INFO - 2018-10-18 09:40:20 --> Config Class Initialized
INFO - 2018-10-18 09:40:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:40:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:40:20 --> Utf8 Class Initialized
INFO - 2018-10-18 09:40:20 --> URI Class Initialized
INFO - 2018-10-18 09:40:20 --> Router Class Initialized
INFO - 2018-10-18 09:40:20 --> Output Class Initialized
INFO - 2018-10-18 09:40:20 --> Security Class Initialized
DEBUG - 2018-10-18 09:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:40:20 --> CSRF cookie sent
INFO - 2018-10-18 09:40:20 --> Input Class Initialized
INFO - 2018-10-18 09:40:20 --> Language Class Initialized
ERROR - 2018-10-18 09:40:20 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:50:25 --> Config Class Initialized
INFO - 2018-10-18 09:50:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:50:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:50:25 --> Utf8 Class Initialized
INFO - 2018-10-18 09:50:25 --> URI Class Initialized
INFO - 2018-10-18 09:50:25 --> Router Class Initialized
INFO - 2018-10-18 09:50:25 --> Output Class Initialized
INFO - 2018-10-18 09:50:25 --> Security Class Initialized
DEBUG - 2018-10-18 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:50:25 --> CSRF cookie sent
INFO - 2018-10-18 09:50:25 --> Input Class Initialized
INFO - 2018-10-18 09:50:25 --> Language Class Initialized
INFO - 2018-10-18 09:50:25 --> Loader Class Initialized
INFO - 2018-10-18 09:50:25 --> Helper loaded: url_helper
INFO - 2018-10-18 09:50:25 --> Helper loaded: form_helper
INFO - 2018-10-18 09:50:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:50:25 --> User Agent Class Initialized
INFO - 2018-10-18 09:50:25 --> Controller Class Initialized
INFO - 2018-10-18 09:50:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:50:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:50:25 --> Pixel_Model class loaded
INFO - 2018-10-18 09:50:25 --> Database Driver Class Initialized
INFO - 2018-10-18 09:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:50:25 --> Database Driver Class Initialized
INFO - 2018-10-18 09:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:50:25 --> Final output sent to browser
DEBUG - 2018-10-18 09:50:25 --> Total execution time: 0.0430
INFO - 2018-10-18 09:50:30 --> Config Class Initialized
INFO - 2018-10-18 09:50:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:50:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:50:30 --> Utf8 Class Initialized
INFO - 2018-10-18 09:50:30 --> URI Class Initialized
INFO - 2018-10-18 09:50:30 --> Router Class Initialized
INFO - 2018-10-18 09:50:30 --> Output Class Initialized
INFO - 2018-10-18 09:50:30 --> Security Class Initialized
DEBUG - 2018-10-18 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:50:30 --> CSRF cookie sent
INFO - 2018-10-18 09:50:30 --> Input Class Initialized
INFO - 2018-10-18 09:50:30 --> Language Class Initialized
ERROR - 2018-10-18 09:50:30 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:51:09 --> Config Class Initialized
INFO - 2018-10-18 09:51:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:51:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:51:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:51:09 --> URI Class Initialized
INFO - 2018-10-18 09:51:09 --> Router Class Initialized
INFO - 2018-10-18 09:51:09 --> Output Class Initialized
INFO - 2018-10-18 09:51:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:51:09 --> CSRF cookie sent
INFO - 2018-10-18 09:51:09 --> Input Class Initialized
INFO - 2018-10-18 09:51:09 --> Language Class Initialized
INFO - 2018-10-18 09:51:09 --> Loader Class Initialized
INFO - 2018-10-18 09:51:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:51:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:51:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:51:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:51:09 --> Controller Class Initialized
INFO - 2018-10-18 09:51:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:51:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:51:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:51:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:51:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:51:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:51:09 --> Total execution time: 0.0548
INFO - 2018-10-18 09:59:47 --> Config Class Initialized
INFO - 2018-10-18 09:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:59:47 --> Utf8 Class Initialized
INFO - 2018-10-18 09:59:47 --> URI Class Initialized
INFO - 2018-10-18 09:59:47 --> Router Class Initialized
INFO - 2018-10-18 09:59:47 --> Output Class Initialized
INFO - 2018-10-18 09:59:47 --> Security Class Initialized
DEBUG - 2018-10-18 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:59:47 --> CSRF cookie sent
INFO - 2018-10-18 09:59:47 --> Input Class Initialized
INFO - 2018-10-18 09:59:47 --> Language Class Initialized
INFO - 2018-10-18 09:59:47 --> Loader Class Initialized
INFO - 2018-10-18 09:59:47 --> Helper loaded: url_helper
INFO - 2018-10-18 09:59:47 --> Helper loaded: form_helper
INFO - 2018-10-18 09:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:59:47 --> User Agent Class Initialized
INFO - 2018-10-18 09:59:47 --> Controller Class Initialized
INFO - 2018-10-18 09:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:59:47 --> Pixel_Model class loaded
INFO - 2018-10-18 09:59:47 --> Database Driver Class Initialized
INFO - 2018-10-18 09:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:59:47 --> Database Driver Class Initialized
INFO - 2018-10-18 09:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:59:47 --> Final output sent to browser
DEBUG - 2018-10-18 09:59:47 --> Total execution time: 0.0475
INFO - 2018-10-18 09:59:53 --> Config Class Initialized
INFO - 2018-10-18 09:59:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:59:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:59:53 --> Utf8 Class Initialized
INFO - 2018-10-18 09:59:53 --> URI Class Initialized
INFO - 2018-10-18 09:59:53 --> Router Class Initialized
INFO - 2018-10-18 09:59:53 --> Output Class Initialized
INFO - 2018-10-18 09:59:53 --> Security Class Initialized
DEBUG - 2018-10-18 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:59:53 --> CSRF cookie sent
INFO - 2018-10-18 09:59:53 --> Input Class Initialized
INFO - 2018-10-18 09:59:53 --> Language Class Initialized
ERROR - 2018-10-18 09:59:53 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:01:16 --> Config Class Initialized
INFO - 2018-10-18 10:01:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:01:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:01:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:01:16 --> URI Class Initialized
INFO - 2018-10-18 10:01:16 --> Router Class Initialized
INFO - 2018-10-18 10:01:16 --> Output Class Initialized
INFO - 2018-10-18 10:01:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:01:16 --> CSRF cookie sent
INFO - 2018-10-18 10:01:16 --> Input Class Initialized
INFO - 2018-10-18 10:01:16 --> Language Class Initialized
INFO - 2018-10-18 10:01:16 --> Loader Class Initialized
INFO - 2018-10-18 10:01:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:01:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:01:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:01:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:01:16 --> Controller Class Initialized
INFO - 2018-10-18 10:01:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:01:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:01:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:01:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:01:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:01:17 --> Final output sent to browser
DEBUG - 2018-10-18 10:01:17 --> Total execution time: 0.0404
INFO - 2018-10-18 10:01:22 --> Config Class Initialized
INFO - 2018-10-18 10:01:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:01:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:01:22 --> Utf8 Class Initialized
INFO - 2018-10-18 10:01:22 --> URI Class Initialized
INFO - 2018-10-18 10:01:22 --> Router Class Initialized
INFO - 2018-10-18 10:01:22 --> Output Class Initialized
INFO - 2018-10-18 10:01:22 --> Security Class Initialized
DEBUG - 2018-10-18 10:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:01:22 --> CSRF cookie sent
INFO - 2018-10-18 10:01:22 --> Input Class Initialized
INFO - 2018-10-18 10:01:22 --> Language Class Initialized
ERROR - 2018-10-18 10:01:22 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:02:03 --> Config Class Initialized
INFO - 2018-10-18 10:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:02:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:02:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:02:03 --> URI Class Initialized
INFO - 2018-10-18 10:02:03 --> Router Class Initialized
INFO - 2018-10-18 10:02:03 --> Output Class Initialized
INFO - 2018-10-18 10:02:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:02:03 --> CSRF cookie sent
INFO - 2018-10-18 10:02:03 --> Input Class Initialized
INFO - 2018-10-18 10:02:03 --> Language Class Initialized
INFO - 2018-10-18 10:02:03 --> Loader Class Initialized
INFO - 2018-10-18 10:02:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:02:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:02:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:02:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:02:03 --> Controller Class Initialized
INFO - 2018-10-18 10:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:02:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:02:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:02:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:02:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:02:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:02:03 --> Total execution time: 0.0493
INFO - 2018-10-18 10:02:08 --> Config Class Initialized
INFO - 2018-10-18 10:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:02:08 --> Utf8 Class Initialized
INFO - 2018-10-18 10:02:08 --> URI Class Initialized
INFO - 2018-10-18 10:02:08 --> Router Class Initialized
INFO - 2018-10-18 10:02:08 --> Output Class Initialized
INFO - 2018-10-18 10:02:08 --> Security Class Initialized
DEBUG - 2018-10-18 10:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:02:08 --> CSRF cookie sent
INFO - 2018-10-18 10:02:08 --> Input Class Initialized
INFO - 2018-10-18 10:02:08 --> Language Class Initialized
ERROR - 2018-10-18 10:02:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:03:03 --> Config Class Initialized
INFO - 2018-10-18 10:03:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:03:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:03:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:03:03 --> URI Class Initialized
INFO - 2018-10-18 10:03:03 --> Router Class Initialized
INFO - 2018-10-18 10:03:03 --> Output Class Initialized
INFO - 2018-10-18 10:03:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:03:03 --> CSRF cookie sent
INFO - 2018-10-18 10:03:03 --> Input Class Initialized
INFO - 2018-10-18 10:03:03 --> Language Class Initialized
INFO - 2018-10-18 10:03:03 --> Loader Class Initialized
INFO - 2018-10-18 10:03:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:03:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:03:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:03:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:03:03 --> Controller Class Initialized
INFO - 2018-10-18 10:03:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:03:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:03:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:03:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:03:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:03:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:03:03 --> Total execution time: 0.0419
INFO - 2018-10-18 10:03:08 --> Config Class Initialized
INFO - 2018-10-18 10:03:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:03:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:03:08 --> Utf8 Class Initialized
INFO - 2018-10-18 10:03:08 --> URI Class Initialized
INFO - 2018-10-18 10:03:08 --> Router Class Initialized
INFO - 2018-10-18 10:03:08 --> Output Class Initialized
INFO - 2018-10-18 10:03:08 --> Security Class Initialized
DEBUG - 2018-10-18 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:03:08 --> CSRF cookie sent
INFO - 2018-10-18 10:03:08 --> Input Class Initialized
INFO - 2018-10-18 10:03:08 --> Language Class Initialized
ERROR - 2018-10-18 10:03:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:05:49 --> Config Class Initialized
INFO - 2018-10-18 10:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:05:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:05:49 --> URI Class Initialized
INFO - 2018-10-18 10:05:49 --> Router Class Initialized
INFO - 2018-10-18 10:05:49 --> Output Class Initialized
INFO - 2018-10-18 10:05:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:05:49 --> CSRF cookie sent
INFO - 2018-10-18 10:05:49 --> Input Class Initialized
INFO - 2018-10-18 10:05:49 --> Language Class Initialized
INFO - 2018-10-18 10:05:49 --> Loader Class Initialized
INFO - 2018-10-18 10:05:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:05:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:05:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:05:49 --> Controller Class Initialized
INFO - 2018-10-18 10:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:05:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:05:49 --> Final output sent to browser
DEBUG - 2018-10-18 10:05:49 --> Total execution time: 0.0560
INFO - 2018-10-18 10:05:55 --> Config Class Initialized
INFO - 2018-10-18 10:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:05:55 --> Utf8 Class Initialized
INFO - 2018-10-18 10:05:55 --> URI Class Initialized
INFO - 2018-10-18 10:05:55 --> Router Class Initialized
INFO - 2018-10-18 10:05:55 --> Output Class Initialized
INFO - 2018-10-18 10:05:55 --> Security Class Initialized
DEBUG - 2018-10-18 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:05:55 --> CSRF cookie sent
INFO - 2018-10-18 10:05:55 --> Input Class Initialized
INFO - 2018-10-18 10:05:55 --> Language Class Initialized
ERROR - 2018-10-18 10:05:55 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:06:10 --> Config Class Initialized
INFO - 2018-10-18 10:06:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:06:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:06:10 --> Utf8 Class Initialized
INFO - 2018-10-18 10:06:10 --> URI Class Initialized
INFO - 2018-10-18 10:06:10 --> Router Class Initialized
INFO - 2018-10-18 10:06:10 --> Output Class Initialized
INFO - 2018-10-18 10:06:10 --> Security Class Initialized
DEBUG - 2018-10-18 10:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:06:10 --> CSRF cookie sent
INFO - 2018-10-18 10:06:10 --> Input Class Initialized
INFO - 2018-10-18 10:06:10 --> Language Class Initialized
INFO - 2018-10-18 10:06:10 --> Loader Class Initialized
INFO - 2018-10-18 10:06:10 --> Helper loaded: url_helper
INFO - 2018-10-18 10:06:10 --> Helper loaded: form_helper
INFO - 2018-10-18 10:06:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:06:10 --> User Agent Class Initialized
INFO - 2018-10-18 10:06:10 --> Controller Class Initialized
INFO - 2018-10-18 10:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:06:10 --> Pixel_Model class loaded
INFO - 2018-10-18 10:06:10 --> Database Driver Class Initialized
INFO - 2018-10-18 10:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:06:10 --> Database Driver Class Initialized
INFO - 2018-10-18 10:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:06:10 --> Final output sent to browser
DEBUG - 2018-10-18 10:06:10 --> Total execution time: 0.0539
INFO - 2018-10-18 10:07:11 --> Config Class Initialized
INFO - 2018-10-18 10:07:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:11 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:11 --> URI Class Initialized
INFO - 2018-10-18 10:07:11 --> Router Class Initialized
INFO - 2018-10-18 10:07:11 --> Output Class Initialized
INFO - 2018-10-18 10:07:11 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:11 --> CSRF cookie sent
INFO - 2018-10-18 10:07:11 --> Input Class Initialized
INFO - 2018-10-18 10:07:11 --> Language Class Initialized
INFO - 2018-10-18 10:07:11 --> Loader Class Initialized
INFO - 2018-10-18 10:07:11 --> Helper loaded: url_helper
INFO - 2018-10-18 10:07:11 --> Helper loaded: form_helper
INFO - 2018-10-18 10:07:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:07:11 --> User Agent Class Initialized
INFO - 2018-10-18 10:07:11 --> Controller Class Initialized
INFO - 2018-10-18 10:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:07:11 --> Pixel_Model class loaded
INFO - 2018-10-18 10:07:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:07:11 --> Final output sent to browser
DEBUG - 2018-10-18 10:07:11 --> Total execution time: 0.0591
INFO - 2018-10-18 10:07:21 --> Config Class Initialized
INFO - 2018-10-18 10:07:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:21 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:21 --> URI Class Initialized
INFO - 2018-10-18 10:07:21 --> Router Class Initialized
INFO - 2018-10-18 10:07:21 --> Output Class Initialized
INFO - 2018-10-18 10:07:21 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:21 --> CSRF cookie sent
INFO - 2018-10-18 10:07:21 --> Input Class Initialized
INFO - 2018-10-18 10:07:21 --> Language Class Initialized
INFO - 2018-10-18 10:07:21 --> Loader Class Initialized
INFO - 2018-10-18 10:07:21 --> Helper loaded: url_helper
INFO - 2018-10-18 10:07:21 --> Helper loaded: form_helper
INFO - 2018-10-18 10:07:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:07:21 --> User Agent Class Initialized
INFO - 2018-10-18 10:07:21 --> Controller Class Initialized
INFO - 2018-10-18 10:07:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:07:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:07:21 --> Pixel_Model class loaded
INFO - 2018-10-18 10:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:07:21 --> Final output sent to browser
DEBUG - 2018-10-18 10:07:21 --> Total execution time: 0.0444
INFO - 2018-10-18 10:07:27 --> Config Class Initialized
INFO - 2018-10-18 10:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:27 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:27 --> URI Class Initialized
INFO - 2018-10-18 10:07:27 --> Router Class Initialized
INFO - 2018-10-18 10:07:27 --> Output Class Initialized
INFO - 2018-10-18 10:07:27 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:27 --> CSRF cookie sent
INFO - 2018-10-18 10:07:27 --> Input Class Initialized
INFO - 2018-10-18 10:07:27 --> Language Class Initialized
ERROR - 2018-10-18 10:07:27 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:10:38 --> Config Class Initialized
INFO - 2018-10-18 10:10:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:10:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:10:38 --> Utf8 Class Initialized
INFO - 2018-10-18 10:10:38 --> URI Class Initialized
INFO - 2018-10-18 10:10:38 --> Router Class Initialized
INFO - 2018-10-18 10:10:38 --> Output Class Initialized
INFO - 2018-10-18 10:10:38 --> Security Class Initialized
DEBUG - 2018-10-18 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:10:38 --> CSRF cookie sent
INFO - 2018-10-18 10:10:38 --> Input Class Initialized
INFO - 2018-10-18 10:10:38 --> Language Class Initialized
INFO - 2018-10-18 10:10:38 --> Loader Class Initialized
INFO - 2018-10-18 10:10:38 --> Helper loaded: url_helper
INFO - 2018-10-18 10:10:38 --> Helper loaded: form_helper
INFO - 2018-10-18 10:10:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:10:38 --> User Agent Class Initialized
INFO - 2018-10-18 10:10:38 --> Controller Class Initialized
INFO - 2018-10-18 10:10:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:10:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:10:38 --> Pixel_Model class loaded
INFO - 2018-10-18 10:10:38 --> Database Driver Class Initialized
INFO - 2018-10-18 10:10:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:10:38 --> Database Driver Class Initialized
INFO - 2018-10-18 10:10:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:10:38 --> Final output sent to browser
DEBUG - 2018-10-18 10:10:38 --> Total execution time: 0.0530
INFO - 2018-10-18 10:10:44 --> Config Class Initialized
INFO - 2018-10-18 10:10:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:10:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:10:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:10:44 --> URI Class Initialized
INFO - 2018-10-18 10:10:44 --> Router Class Initialized
INFO - 2018-10-18 10:10:44 --> Output Class Initialized
INFO - 2018-10-18 10:10:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:10:44 --> CSRF cookie sent
INFO - 2018-10-18 10:10:44 --> Input Class Initialized
INFO - 2018-10-18 10:10:44 --> Language Class Initialized
ERROR - 2018-10-18 10:10:44 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:11:23 --> Config Class Initialized
INFO - 2018-10-18 10:11:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:23 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:23 --> URI Class Initialized
INFO - 2018-10-18 10:11:23 --> Router Class Initialized
INFO - 2018-10-18 10:11:23 --> Output Class Initialized
INFO - 2018-10-18 10:11:23 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:23 --> CSRF cookie sent
INFO - 2018-10-18 10:11:23 --> Input Class Initialized
INFO - 2018-10-18 10:11:23 --> Language Class Initialized
INFO - 2018-10-18 10:11:23 --> Loader Class Initialized
INFO - 2018-10-18 10:11:23 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:23 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:23 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:23 --> Controller Class Initialized
INFO - 2018-10-18 10:11:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:23 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:23 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:23 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:23 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:23 --> Total execution time: 0.0410
INFO - 2018-10-18 10:11:28 --> Config Class Initialized
INFO - 2018-10-18 10:11:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:28 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:28 --> URI Class Initialized
INFO - 2018-10-18 10:11:28 --> Router Class Initialized
INFO - 2018-10-18 10:11:28 --> Output Class Initialized
INFO - 2018-10-18 10:11:28 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:28 --> CSRF cookie sent
INFO - 2018-10-18 10:11:28 --> Input Class Initialized
INFO - 2018-10-18 10:11:28 --> Language Class Initialized
ERROR - 2018-10-18 10:11:28 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:11:34 --> Config Class Initialized
INFO - 2018-10-18 10:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:34 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:34 --> URI Class Initialized
INFO - 2018-10-18 10:11:34 --> Router Class Initialized
INFO - 2018-10-18 10:11:34 --> Output Class Initialized
INFO - 2018-10-18 10:11:34 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:34 --> CSRF cookie sent
INFO - 2018-10-18 10:11:34 --> Input Class Initialized
INFO - 2018-10-18 10:11:34 --> Language Class Initialized
INFO - 2018-10-18 10:11:34 --> Loader Class Initialized
INFO - 2018-10-18 10:11:34 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:34 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:34 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:34 --> Controller Class Initialized
INFO - 2018-10-18 10:11:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:34 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:34 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:34 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:34 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:34 --> Total execution time: 0.0481
INFO - 2018-10-18 10:11:40 --> Config Class Initialized
INFO - 2018-10-18 10:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:40 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:40 --> URI Class Initialized
INFO - 2018-10-18 10:11:40 --> Router Class Initialized
INFO - 2018-10-18 10:11:40 --> Output Class Initialized
INFO - 2018-10-18 10:11:40 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:40 --> CSRF cookie sent
INFO - 2018-10-18 10:11:40 --> Input Class Initialized
INFO - 2018-10-18 10:11:40 --> Language Class Initialized
INFO - 2018-10-18 10:11:40 --> Loader Class Initialized
INFO - 2018-10-18 10:11:40 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:40 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:40 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:40 --> Controller Class Initialized
INFO - 2018-10-18 10:11:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:40 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:40 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:40 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:40 --> Total execution time: 0.0440
INFO - 2018-10-18 10:11:44 --> Config Class Initialized
INFO - 2018-10-18 10:11:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:44 --> URI Class Initialized
INFO - 2018-10-18 10:11:44 --> Router Class Initialized
INFO - 2018-10-18 10:11:44 --> Output Class Initialized
INFO - 2018-10-18 10:11:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:44 --> CSRF cookie sent
INFO - 2018-10-18 10:11:44 --> CSRF token verified
INFO - 2018-10-18 10:11:44 --> Input Class Initialized
INFO - 2018-10-18 10:11:44 --> Language Class Initialized
INFO - 2018-10-18 10:11:44 --> Loader Class Initialized
INFO - 2018-10-18 10:11:44 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:44 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:44 --> Controller Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Config Class Initialized
INFO - 2018-10-18 10:11:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:44 --> URI Class Initialized
INFO - 2018-10-18 10:11:44 --> Router Class Initialized
INFO - 2018-10-18 10:11:44 --> Output Class Initialized
INFO - 2018-10-18 10:11:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:44 --> CSRF cookie sent
INFO - 2018-10-18 10:11:44 --> Input Class Initialized
INFO - 2018-10-18 10:11:44 --> Language Class Initialized
INFO - 2018-10-18 10:11:44 --> Loader Class Initialized
INFO - 2018-10-18 10:11:44 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:44 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:44 --> Controller Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:44 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:44 --> Total execution time: 0.0451
INFO - 2018-10-18 10:11:49 --> Config Class Initialized
INFO - 2018-10-18 10:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:49 --> URI Class Initialized
INFO - 2018-10-18 10:11:49 --> Router Class Initialized
INFO - 2018-10-18 10:11:49 --> Output Class Initialized
INFO - 2018-10-18 10:11:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:49 --> CSRF cookie sent
INFO - 2018-10-18 10:11:49 --> CSRF token verified
INFO - 2018-10-18 10:11:49 --> Input Class Initialized
INFO - 2018-10-18 10:11:49 --> Language Class Initialized
INFO - 2018-10-18 10:11:49 --> Loader Class Initialized
INFO - 2018-10-18 10:11:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:49 --> Controller Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Config Class Initialized
INFO - 2018-10-18 10:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:49 --> URI Class Initialized
INFO - 2018-10-18 10:11:49 --> Router Class Initialized
INFO - 2018-10-18 10:11:49 --> Output Class Initialized
INFO - 2018-10-18 10:11:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:49 --> CSRF cookie sent
INFO - 2018-10-18 10:11:49 --> Input Class Initialized
INFO - 2018-10-18 10:11:49 --> Language Class Initialized
INFO - 2018-10-18 10:11:49 --> Loader Class Initialized
INFO - 2018-10-18 10:11:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:49 --> Controller Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:49 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:49 --> Total execution time: 0.0572
INFO - 2018-10-18 10:11:51 --> Config Class Initialized
INFO - 2018-10-18 10:11:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:51 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:51 --> URI Class Initialized
INFO - 2018-10-18 10:11:51 --> Router Class Initialized
INFO - 2018-10-18 10:11:51 --> Output Class Initialized
INFO - 2018-10-18 10:11:51 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:51 --> CSRF cookie sent
INFO - 2018-10-18 10:11:51 --> CSRF token verified
INFO - 2018-10-18 10:11:51 --> Input Class Initialized
INFO - 2018-10-18 10:11:51 --> Language Class Initialized
INFO - 2018-10-18 10:11:51 --> Loader Class Initialized
INFO - 2018-10-18 10:11:51 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:51 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:51 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:51 --> Controller Class Initialized
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:51 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:51 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:51 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:51 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> Config Class Initialized
INFO - 2018-10-18 10:11:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:52 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:52 --> URI Class Initialized
INFO - 2018-10-18 10:11:52 --> Router Class Initialized
INFO - 2018-10-18 10:11:52 --> Output Class Initialized
INFO - 2018-10-18 10:11:52 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:52 --> CSRF cookie sent
INFO - 2018-10-18 10:11:52 --> Input Class Initialized
INFO - 2018-10-18 10:11:52 --> Language Class Initialized
INFO - 2018-10-18 10:11:52 --> Loader Class Initialized
INFO - 2018-10-18 10:11:52 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:52 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:52 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:52 --> Controller Class Initialized
INFO - 2018-10-18 10:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:52 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:52 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:52 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:52 --> Total execution time: 0.0522
INFO - 2018-10-18 10:11:55 --> Config Class Initialized
INFO - 2018-10-18 10:11:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:55 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:55 --> URI Class Initialized
INFO - 2018-10-18 10:11:55 --> Router Class Initialized
INFO - 2018-10-18 10:11:55 --> Output Class Initialized
INFO - 2018-10-18 10:11:55 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:55 --> CSRF cookie sent
INFO - 2018-10-18 10:11:55 --> CSRF token verified
INFO - 2018-10-18 10:11:55 --> Input Class Initialized
INFO - 2018-10-18 10:11:55 --> Language Class Initialized
INFO - 2018-10-18 10:11:55 --> Loader Class Initialized
INFO - 2018-10-18 10:11:55 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:55 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:55 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:55 --> Controller Class Initialized
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:55 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:55 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:55 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:55 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> Config Class Initialized
INFO - 2018-10-18 10:11:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:56 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:56 --> URI Class Initialized
INFO - 2018-10-18 10:11:56 --> Router Class Initialized
INFO - 2018-10-18 10:11:56 --> Output Class Initialized
INFO - 2018-10-18 10:11:56 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:56 --> CSRF cookie sent
INFO - 2018-10-18 10:11:56 --> Input Class Initialized
INFO - 2018-10-18 10:11:56 --> Language Class Initialized
INFO - 2018-10-18 10:11:56 --> Loader Class Initialized
INFO - 2018-10-18 10:11:56 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:56 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:56 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:56 --> Controller Class Initialized
INFO - 2018-10-18 10:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:56 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:56 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:56 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:56 --> Total execution time: 0.0370
INFO - 2018-10-18 10:12:39 --> Config Class Initialized
INFO - 2018-10-18 10:12:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:39 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:39 --> URI Class Initialized
INFO - 2018-10-18 10:12:39 --> Router Class Initialized
INFO - 2018-10-18 10:12:39 --> Output Class Initialized
INFO - 2018-10-18 10:12:39 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:39 --> CSRF cookie sent
INFO - 2018-10-18 10:12:39 --> Input Class Initialized
INFO - 2018-10-18 10:12:39 --> Language Class Initialized
INFO - 2018-10-18 10:12:39 --> Loader Class Initialized
INFO - 2018-10-18 10:12:39 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:39 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:39 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:39 --> Controller Class Initialized
INFO - 2018-10-18 10:12:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:39 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:39 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:39 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:39 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:39 --> Total execution time: 0.0441
INFO - 2018-10-18 10:12:48 --> Config Class Initialized
INFO - 2018-10-18 10:12:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:48 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:48 --> URI Class Initialized
INFO - 2018-10-18 10:12:48 --> Router Class Initialized
INFO - 2018-10-18 10:12:48 --> Output Class Initialized
INFO - 2018-10-18 10:12:48 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:48 --> CSRF cookie sent
INFO - 2018-10-18 10:12:48 --> CSRF token verified
INFO - 2018-10-18 10:12:48 --> Input Class Initialized
INFO - 2018-10-18 10:12:48 --> Language Class Initialized
INFO - 2018-10-18 10:12:48 --> Loader Class Initialized
INFO - 2018-10-18 10:12:48 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:48 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:48 --> Controller Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Config Class Initialized
INFO - 2018-10-18 10:12:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:48 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:48 --> URI Class Initialized
INFO - 2018-10-18 10:12:48 --> Router Class Initialized
INFO - 2018-10-18 10:12:48 --> Output Class Initialized
INFO - 2018-10-18 10:12:48 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:48 --> CSRF cookie sent
INFO - 2018-10-18 10:12:48 --> Input Class Initialized
INFO - 2018-10-18 10:12:48 --> Language Class Initialized
INFO - 2018-10-18 10:12:48 --> Loader Class Initialized
INFO - 2018-10-18 10:12:48 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:48 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:48 --> Controller Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:48 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:48 --> Total execution time: 0.0390
INFO - 2018-10-18 10:12:53 --> Config Class Initialized
INFO - 2018-10-18 10:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:53 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:53 --> URI Class Initialized
INFO - 2018-10-18 10:12:53 --> Router Class Initialized
INFO - 2018-10-18 10:12:53 --> Output Class Initialized
INFO - 2018-10-18 10:12:53 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:53 --> CSRF cookie sent
INFO - 2018-10-18 10:12:53 --> CSRF token verified
INFO - 2018-10-18 10:12:53 --> Input Class Initialized
INFO - 2018-10-18 10:12:53 --> Language Class Initialized
INFO - 2018-10-18 10:12:53 --> Loader Class Initialized
INFO - 2018-10-18 10:12:53 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:53 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:53 --> Controller Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Config Class Initialized
INFO - 2018-10-18 10:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:53 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:53 --> URI Class Initialized
INFO - 2018-10-18 10:12:53 --> Router Class Initialized
INFO - 2018-10-18 10:12:53 --> Output Class Initialized
INFO - 2018-10-18 10:12:53 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:53 --> CSRF cookie sent
INFO - 2018-10-18 10:12:53 --> Input Class Initialized
INFO - 2018-10-18 10:12:53 --> Language Class Initialized
INFO - 2018-10-18 10:12:53 --> Loader Class Initialized
INFO - 2018-10-18 10:12:53 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:53 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:53 --> Controller Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:53 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:53 --> Total execution time: 0.0459
INFO - 2018-10-18 10:12:58 --> Config Class Initialized
INFO - 2018-10-18 10:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:58 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:58 --> URI Class Initialized
INFO - 2018-10-18 10:12:58 --> Router Class Initialized
INFO - 2018-10-18 10:12:58 --> Output Class Initialized
INFO - 2018-10-18 10:12:58 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:58 --> CSRF cookie sent
INFO - 2018-10-18 10:12:58 --> CSRF token verified
INFO - 2018-10-18 10:12:58 --> Input Class Initialized
INFO - 2018-10-18 10:12:58 --> Language Class Initialized
INFO - 2018-10-18 10:12:58 --> Loader Class Initialized
INFO - 2018-10-18 10:12:58 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:58 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:58 --> Controller Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Config Class Initialized
INFO - 2018-10-18 10:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:58 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:58 --> URI Class Initialized
INFO - 2018-10-18 10:12:58 --> Router Class Initialized
INFO - 2018-10-18 10:12:58 --> Output Class Initialized
INFO - 2018-10-18 10:12:58 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:58 --> CSRF cookie sent
INFO - 2018-10-18 10:12:58 --> Input Class Initialized
INFO - 2018-10-18 10:12:58 --> Language Class Initialized
INFO - 2018-10-18 10:12:58 --> Loader Class Initialized
INFO - 2018-10-18 10:12:58 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:58 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:58 --> Controller Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:58 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:58 --> Total execution time: 0.0729
INFO - 2018-10-18 10:14:06 --> Config Class Initialized
INFO - 2018-10-18 10:14:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:06 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:06 --> URI Class Initialized
INFO - 2018-10-18 10:14:06 --> Router Class Initialized
INFO - 2018-10-18 10:14:06 --> Output Class Initialized
INFO - 2018-10-18 10:14:06 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:06 --> CSRF cookie sent
INFO - 2018-10-18 10:14:06 --> Input Class Initialized
INFO - 2018-10-18 10:14:06 --> Language Class Initialized
INFO - 2018-10-18 10:14:06 --> Loader Class Initialized
INFO - 2018-10-18 10:14:06 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:06 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:06 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:06 --> Controller Class Initialized
INFO - 2018-10-18 10:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:06 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:06 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:06 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:14:06 --> Final output sent to browser
DEBUG - 2018-10-18 10:14:06 --> Total execution time: 0.0452
INFO - 2018-10-18 10:14:16 --> Config Class Initialized
INFO - 2018-10-18 10:14:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:16 --> URI Class Initialized
INFO - 2018-10-18 10:14:16 --> Router Class Initialized
INFO - 2018-10-18 10:14:16 --> Output Class Initialized
INFO - 2018-10-18 10:14:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:16 --> CSRF cookie sent
INFO - 2018-10-18 10:14:16 --> CSRF token verified
INFO - 2018-10-18 10:14:16 --> Input Class Initialized
INFO - 2018-10-18 10:14:16 --> Language Class Initialized
INFO - 2018-10-18 10:14:16 --> Loader Class Initialized
INFO - 2018-10-18 10:14:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:16 --> Controller Class Initialized
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:16 --> Form Validation Class Initialized
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:14:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:16 --> Config Class Initialized
INFO - 2018-10-18 10:14:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:16 --> URI Class Initialized
INFO - 2018-10-18 10:14:16 --> Router Class Initialized
INFO - 2018-10-18 10:14:16 --> Output Class Initialized
INFO - 2018-10-18 10:14:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:16 --> CSRF cookie sent
INFO - 2018-10-18 10:14:16 --> Input Class Initialized
INFO - 2018-10-18 10:14:16 --> Language Class Initialized
INFO - 2018-10-18 10:14:17 --> Loader Class Initialized
INFO - 2018-10-18 10:14:17 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:17 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:17 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:17 --> Controller Class Initialized
INFO - 2018-10-18 10:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:17 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:14:17 --> Final output sent to browser
DEBUG - 2018-10-18 10:14:17 --> Total execution time: 0.0445
INFO - 2018-10-18 10:15:03 --> Config Class Initialized
INFO - 2018-10-18 10:15:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:03 --> URI Class Initialized
INFO - 2018-10-18 10:15:03 --> Router Class Initialized
INFO - 2018-10-18 10:15:03 --> Output Class Initialized
INFO - 2018-10-18 10:15:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:03 --> CSRF cookie sent
INFO - 2018-10-18 10:15:03 --> Input Class Initialized
INFO - 2018-10-18 10:15:03 --> Language Class Initialized
INFO - 2018-10-18 10:15:03 --> Loader Class Initialized
INFO - 2018-10-18 10:15:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:03 --> Controller Class Initialized
INFO - 2018-10-18 10:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:03 --> Total execution time: 0.0476
INFO - 2018-10-18 10:15:11 --> Config Class Initialized
INFO - 2018-10-18 10:15:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:11 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:11 --> URI Class Initialized
INFO - 2018-10-18 10:15:11 --> Router Class Initialized
INFO - 2018-10-18 10:15:11 --> Output Class Initialized
INFO - 2018-10-18 10:15:11 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:11 --> CSRF cookie sent
INFO - 2018-10-18 10:15:11 --> CSRF token verified
INFO - 2018-10-18 10:15:11 --> Input Class Initialized
INFO - 2018-10-18 10:15:11 --> Language Class Initialized
INFO - 2018-10-18 10:15:11 --> Loader Class Initialized
INFO - 2018-10-18 10:15:11 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:11 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:11 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:11 --> Controller Class Initialized
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:11 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:11 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> Config Class Initialized
INFO - 2018-10-18 10:15:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:12 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:12 --> URI Class Initialized
INFO - 2018-10-18 10:15:12 --> Router Class Initialized
INFO - 2018-10-18 10:15:12 --> Output Class Initialized
INFO - 2018-10-18 10:15:12 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:12 --> CSRF cookie sent
INFO - 2018-10-18 10:15:12 --> Input Class Initialized
INFO - 2018-10-18 10:15:12 --> Language Class Initialized
INFO - 2018-10-18 10:15:12 --> Loader Class Initialized
INFO - 2018-10-18 10:15:12 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:12 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:12 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:12 --> Controller Class Initialized
INFO - 2018-10-18 10:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:12 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:12 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:12 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:12 --> Total execution time: 0.0606
INFO - 2018-10-18 10:15:16 --> Config Class Initialized
INFO - 2018-10-18 10:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:16 --> URI Class Initialized
INFO - 2018-10-18 10:15:16 --> Router Class Initialized
INFO - 2018-10-18 10:15:16 --> Output Class Initialized
INFO - 2018-10-18 10:15:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:16 --> CSRF cookie sent
INFO - 2018-10-18 10:15:16 --> CSRF token verified
INFO - 2018-10-18 10:15:16 --> Input Class Initialized
INFO - 2018-10-18 10:15:16 --> Language Class Initialized
INFO - 2018-10-18 10:15:16 --> Loader Class Initialized
INFO - 2018-10-18 10:15:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:16 --> Controller Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Config Class Initialized
INFO - 2018-10-18 10:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:16 --> URI Class Initialized
INFO - 2018-10-18 10:15:16 --> Router Class Initialized
INFO - 2018-10-18 10:15:16 --> Output Class Initialized
INFO - 2018-10-18 10:15:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:16 --> CSRF cookie sent
INFO - 2018-10-18 10:15:16 --> Input Class Initialized
INFO - 2018-10-18 10:15:16 --> Language Class Initialized
INFO - 2018-10-18 10:15:16 --> Loader Class Initialized
INFO - 2018-10-18 10:15:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:16 --> Controller Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:16 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:16 --> Total execution time: 0.0435
INFO - 2018-10-18 10:15:18 --> Config Class Initialized
INFO - 2018-10-18 10:15:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:18 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:18 --> URI Class Initialized
INFO - 2018-10-18 10:15:18 --> Router Class Initialized
INFO - 2018-10-18 10:15:18 --> Output Class Initialized
INFO - 2018-10-18 10:15:18 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:18 --> CSRF cookie sent
INFO - 2018-10-18 10:15:18 --> CSRF token verified
INFO - 2018-10-18 10:15:18 --> Input Class Initialized
INFO - 2018-10-18 10:15:18 --> Language Class Initialized
INFO - 2018-10-18 10:15:18 --> Loader Class Initialized
INFO - 2018-10-18 10:15:18 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:18 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:18 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:18 --> Controller Class Initialized
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:18 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:18 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:18 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:18 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> Config Class Initialized
INFO - 2018-10-18 10:15:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:19 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:19 --> URI Class Initialized
INFO - 2018-10-18 10:15:19 --> Router Class Initialized
INFO - 2018-10-18 10:15:19 --> Output Class Initialized
INFO - 2018-10-18 10:15:19 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:19 --> CSRF cookie sent
INFO - 2018-10-18 10:15:19 --> Input Class Initialized
INFO - 2018-10-18 10:15:19 --> Language Class Initialized
INFO - 2018-10-18 10:15:19 --> Loader Class Initialized
INFO - 2018-10-18 10:15:19 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:19 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:19 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:19 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:19 --> Controller Class Initialized
INFO - 2018-10-18 10:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:19 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:19 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:19 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:19 --> Total execution time: 0.0383
INFO - 2018-10-18 10:15:26 --> Config Class Initialized
INFO - 2018-10-18 10:15:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:26 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:26 --> URI Class Initialized
INFO - 2018-10-18 10:15:26 --> Router Class Initialized
INFO - 2018-10-18 10:15:26 --> Output Class Initialized
INFO - 2018-10-18 10:15:26 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:26 --> CSRF cookie sent
INFO - 2018-10-18 10:15:26 --> CSRF token verified
INFO - 2018-10-18 10:15:26 --> Input Class Initialized
INFO - 2018-10-18 10:15:26 --> Language Class Initialized
INFO - 2018-10-18 10:15:26 --> Loader Class Initialized
INFO - 2018-10-18 10:15:26 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:26 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:26 --> Controller Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Config Class Initialized
INFO - 2018-10-18 10:15:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:26 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:26 --> URI Class Initialized
INFO - 2018-10-18 10:15:26 --> Router Class Initialized
INFO - 2018-10-18 10:15:26 --> Output Class Initialized
INFO - 2018-10-18 10:15:26 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:26 --> CSRF cookie sent
INFO - 2018-10-18 10:15:26 --> Input Class Initialized
INFO - 2018-10-18 10:15:26 --> Language Class Initialized
INFO - 2018-10-18 10:15:26 --> Loader Class Initialized
INFO - 2018-10-18 10:15:26 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:26 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:26 --> Controller Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:26 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:26 --> Total execution time: 0.0485
INFO - 2018-10-18 10:15:29 --> Config Class Initialized
INFO - 2018-10-18 10:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:29 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:29 --> URI Class Initialized
INFO - 2018-10-18 10:15:29 --> Router Class Initialized
INFO - 2018-10-18 10:15:29 --> Output Class Initialized
INFO - 2018-10-18 10:15:29 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:29 --> CSRF cookie sent
INFO - 2018-10-18 10:15:29 --> CSRF token verified
INFO - 2018-10-18 10:15:29 --> Input Class Initialized
INFO - 2018-10-18 10:15:29 --> Language Class Initialized
INFO - 2018-10-18 10:15:29 --> Loader Class Initialized
INFO - 2018-10-18 10:15:29 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:29 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:29 --> Controller Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Config Class Initialized
INFO - 2018-10-18 10:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:29 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:29 --> URI Class Initialized
INFO - 2018-10-18 10:15:29 --> Router Class Initialized
INFO - 2018-10-18 10:15:29 --> Output Class Initialized
INFO - 2018-10-18 10:15:29 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:29 --> CSRF cookie sent
INFO - 2018-10-18 10:15:29 --> Input Class Initialized
INFO - 2018-10-18 10:15:29 --> Language Class Initialized
INFO - 2018-10-18 10:15:29 --> Loader Class Initialized
INFO - 2018-10-18 10:15:29 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:29 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:29 --> Controller Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:29 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:29 --> Total execution time: 0.0421

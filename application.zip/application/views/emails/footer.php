			<table width="100%" cell cellspacing="0" border="0">
				<tr>
					<td height="30" width="100%" style="padding-right:20px; padding-left:20px; background: #e2d7c2;" valign="middle">
						<p style="font-family:'Open Sans',Arial, Sans-Serif; font-weight: 400; font-size: 14px; text-align:center; color:#666666; line-height:20px; display:block; margin-top:1em; margin-bottom:1em;">
							<?php echo Lang('email_footer_txt1');?>
						</p>
					</td>
				</tr>
				
				<tr>
					<td height="30" width="100%" bgcolor="" style="font-family:'Open Sans', Arial, Sans-Serif; font-size: 12px; text-align:center; color:#363636; line-height:16px; margin-top:1em; margin-bottom:1em; padding-right:20px; padding-left:20px;" valign="middle">
							<?php echo Lang('email_footer_txt2');?>
					</td>
				</tr>	
			</table>						
						
		</td></tr></table>
		
<!--[if (gte mso 9)|(IE)]>
	  </td>
	</tr>
</table>
<![endif]-->		
		
	</body>
	
</html>
<?php $this->load->view('shared/_page_banner_empty'); ?>
<section class="gray-bg page-section-ptb o-hidden">
    <?php $this->load->view('shared/_page_header', array("txt1" => "Don't have an Account? Register Now.", "txt2" => "Save your Data", "txt3" => "In order to save your answers please provide email and password.")); ?>
    <div class="container form-margin">

        <div class="row text-center">
            Feature temporarily unavailable.
        </div>
    </div>
</section>
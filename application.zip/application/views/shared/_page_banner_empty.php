<section class="page-title-empty gray-bg hidden-xs">
    
</section>
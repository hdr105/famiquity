<div class="row maroon-bg"> 
            <div class="col-lg-12 col-md-12">
                <div class="text-center">
                    <h6 class=""><?php Smart::echoString($txt1);?></h6>
                    <h2 class="title-effect"><?php Smart::echoString($txt2);?></h2>
                    <p class=""><?php echo $txt3;?></p>
                </div>
            </div>
        </div>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-<?php echo $class ?>"><?php Smart::echoString($message); ?></div>
    </div>
</div>
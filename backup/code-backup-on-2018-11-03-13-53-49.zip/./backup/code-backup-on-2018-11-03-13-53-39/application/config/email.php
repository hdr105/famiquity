<?php
$config['useragent']        = 'Famiquity';        
//$config['protocol']         = 'sendmail';        
$config['protocol']         = 'mail';        

$config['smtp_host']        = 'mail.fixi.ca';
$config['smtp_user']        = 'noreply@fixi.ca';
$config['smtp_pass']        = '2017$';
$config['smtp_port']        = 587;
$config['smtp_timeout']     = 5;

$config['wordwrap']         = TRUE;
$config['wrapchars']        = 76;
$config['mailtype']         = 'html';
$config['charset']          = 'utf-8';
$config['validate']         = FALSE;
$config['priority']         = 3;
$config['crlf']             = "\r\n";
$config['newline']          = "\r\n";
$config['bcc_batch_mode']   = FALSE;
$config['bcc_batch_size']   = 200;













?>

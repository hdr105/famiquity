<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['pagination_first_link'] = '&lsaquo; First';
$lang['pagination_next_link'] = '&raquo;';
$lang['pagination_prev_link'] = '&laquo;';
$lang['pagination_last_link'] = 'Last &rsaquo;';

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-12 22:28:27 --> Config Class Initialized
INFO - 2018-03-12 22:28:27 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
DEBUG - 2018-03-12 22:28:28 --> No URI present. Default controller set.
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
INFO - 2018-03-12 22:28:28 --> Loader Class Initialized
INFO - 2018-03-12 22:28:28 --> Helper loaded: url_helper
INFO - 2018-03-12 22:28:28 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:28:28 --> User Agent Class Initialized
INFO - 2018-03-12 22:28:28 --> Controller Class Initialized
INFO - 2018-03-12 22:28:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:28:28 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-03-12 22:28:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:28:28 --> Final output sent to browser
DEBUG - 2018-03-12 22:28:28 --> Total execution time: 0.6808
INFO - 2018-03-12 22:28:28 --> Config Class Initialized
INFO - 2018-03-12 22:28:28 --> Config Class Initialized
INFO - 2018-03-12 22:28:28 --> Config Class Initialized
INFO - 2018-03-12 22:28:28 --> Config Class Initialized
INFO - 2018-03-12 22:28:28 --> Config Class Initialized
INFO - 2018-03-12 22:28:28 --> Hooks Class Initialized
INFO - 2018-03-12 22:28:28 --> Hooks Class Initialized
INFO - 2018-03-12 22:28:28 --> Hooks Class Initialized
INFO - 2018-03-12 22:28:28 --> Hooks Class Initialized
INFO - 2018-03-12 22:28:28 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> Utf8 Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
INFO - 2018-03-12 22:28:28 --> URI Class Initialized
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Router Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Output Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
INFO - 2018-03-12 22:28:28 --> Security Class Initialized
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
INFO - 2018-03-12 22:28:28 --> CSRF cookie sent
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> Input Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
INFO - 2018-03-12 22:28:28 --> Language Class Initialized
ERROR - 2018-03-12 22:28:28 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:28:28 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-03-12 22:28:28 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:28:28 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:28:28 --> 404 Page Not Found: Images/team
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
DEBUG - 2018-03-12 22:29:01 --> No URI present. Default controller set.
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
INFO - 2018-03-12 22:29:01 --> Loader Class Initialized
INFO - 2018-03-12 22:29:01 --> Helper loaded: url_helper
INFO - 2018-03-12 22:29:01 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:29:01 --> User Agent Class Initialized
INFO - 2018-03-12 22:29:01 --> Controller Class Initialized
INFO - 2018-03-12 22:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:29:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-03-12 22:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:29:01 --> Final output sent to browser
DEBUG - 2018-03-12 22:29:01 --> Total execution time: 0.1681
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
DEBUG - 2018-03-12 22:29:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> URI Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
INFO - 2018-03-12 22:29:01 --> Router Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
INFO - 2018-03-12 22:29:01 --> Output Class Initialized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:01 --> Security Class Initialized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
DEBUG - 2018-03-12 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
INFO - 2018-03-12 22:29:01 --> CSRF cookie sent
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
INFO - 2018-03-12 22:29:01 --> Input Class Initialized
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Images/team
INFO - 2018-03-12 22:29:01 --> Language Class Initialized
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:29:01 --> 404 Page Not Found: Images/team
INFO - 2018-03-12 22:29:01 --> Config Class Initialized
INFO - 2018-03-12 22:29:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:02 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:02 --> URI Class Initialized
INFO - 2018-03-12 22:29:02 --> Router Class Initialized
INFO - 2018-03-12 22:29:02 --> Output Class Initialized
INFO - 2018-03-12 22:29:02 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:02 --> CSRF cookie sent
INFO - 2018-03-12 22:29:02 --> Input Class Initialized
INFO - 2018-03-12 22:29:02 --> Language Class Initialized
ERROR - 2018-03-12 22:29:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-03-12 22:29:03 --> Config Class Initialized
INFO - 2018-03-12 22:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:03 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:03 --> URI Class Initialized
INFO - 2018-03-12 22:29:03 --> Router Class Initialized
INFO - 2018-03-12 22:29:03 --> Output Class Initialized
INFO - 2018-03-12 22:29:03 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:03 --> CSRF cookie sent
INFO - 2018-03-12 22:29:03 --> Input Class Initialized
INFO - 2018-03-12 22:29:03 --> Language Class Initialized
ERROR - 2018-03-12 22:29:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
DEBUG - 2018-03-12 22:29:40 --> No URI present. Default controller set.
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
INFO - 2018-03-12 22:29:40 --> Loader Class Initialized
INFO - 2018-03-12 22:29:40 --> Helper loaded: url_helper
INFO - 2018-03-12 22:29:40 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:29:40 --> User Agent Class Initialized
INFO - 2018-03-12 22:29:40 --> Controller Class Initialized
INFO - 2018-03-12 22:29:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:29:40 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-03-12 22:29:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:29:40 --> Final output sent to browser
DEBUG - 2018-03-12 22:29:40 --> Total execution time: 0.1898
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Images/team
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Images/team
INFO - 2018-03-12 22:29:40 --> Config Class Initialized
INFO - 2018-03-12 22:29:40 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:40 --> URI Class Initialized
INFO - 2018-03-12 22:29:40 --> Router Class Initialized
INFO - 2018-03-12 22:29:40 --> Output Class Initialized
INFO - 2018-03-12 22:29:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:40 --> CSRF cookie sent
INFO - 2018-03-12 22:29:40 --> Input Class Initialized
INFO - 2018-03-12 22:29:40 --> Language Class Initialized
ERROR - 2018-03-12 22:29:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-03-12 22:29:41 --> Config Class Initialized
INFO - 2018-03-12 22:29:41 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:29:41 --> Utf8 Class Initialized
INFO - 2018-03-12 22:29:41 --> URI Class Initialized
INFO - 2018-03-12 22:29:41 --> Router Class Initialized
INFO - 2018-03-12 22:29:41 --> Output Class Initialized
INFO - 2018-03-12 22:29:41 --> Security Class Initialized
DEBUG - 2018-03-12 22:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:29:41 --> CSRF cookie sent
INFO - 2018-03-12 22:29:41 --> Input Class Initialized
INFO - 2018-03-12 22:29:41 --> Language Class Initialized
ERROR - 2018-03-12 22:29:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-03-12 22:30:29 --> Config Class Initialized
INFO - 2018-03-12 22:30:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:30:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:30:29 --> Utf8 Class Initialized
INFO - 2018-03-12 22:30:29 --> URI Class Initialized
INFO - 2018-03-12 22:30:29 --> Router Class Initialized
INFO - 2018-03-12 22:30:29 --> Output Class Initialized
INFO - 2018-03-12 22:30:29 --> Security Class Initialized
DEBUG - 2018-03-12 22:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:30:29 --> CSRF cookie sent
INFO - 2018-03-12 22:30:29 --> Input Class Initialized
INFO - 2018-03-12 22:30:29 --> Language Class Initialized
ERROR - 2018-03-12 22:30:29 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:30:42 --> Config Class Initialized
INFO - 2018-03-12 22:30:42 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:30:42 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:30:42 --> Utf8 Class Initialized
INFO - 2018-03-12 22:30:42 --> URI Class Initialized
INFO - 2018-03-12 22:30:42 --> Router Class Initialized
INFO - 2018-03-12 22:30:42 --> Output Class Initialized
INFO - 2018-03-12 22:30:42 --> Security Class Initialized
DEBUG - 2018-03-12 22:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:30:42 --> CSRF cookie sent
INFO - 2018-03-12 22:30:42 --> Input Class Initialized
INFO - 2018-03-12 22:30:42 --> Language Class Initialized
INFO - 2018-03-12 22:30:42 --> Loader Class Initialized
INFO - 2018-03-12 22:30:42 --> Helper loaded: url_helper
INFO - 2018-03-12 22:30:42 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:30:42 --> User Agent Class Initialized
INFO - 2018-03-12 22:30:42 --> Controller Class Initialized
INFO - 2018-03-12 22:30:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:30:42 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:30:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:30:42 --> Final output sent to browser
DEBUG - 2018-03-12 22:30:42 --> Total execution time: 0.1886
INFO - 2018-03-12 22:30:43 --> Config Class Initialized
INFO - 2018-03-12 22:30:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:30:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:30:43 --> Utf8 Class Initialized
INFO - 2018-03-12 22:30:43 --> URI Class Initialized
INFO - 2018-03-12 22:30:43 --> Router Class Initialized
INFO - 2018-03-12 22:30:43 --> Output Class Initialized
INFO - 2018-03-12 22:30:43 --> Security Class Initialized
DEBUG - 2018-03-12 22:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:30:43 --> CSRF cookie sent
INFO - 2018-03-12 22:30:43 --> Input Class Initialized
INFO - 2018-03-12 22:30:43 --> Language Class Initialized
ERROR - 2018-03-12 22:30:43 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:30:43 --> Config Class Initialized
INFO - 2018-03-12 22:30:43 --> Config Class Initialized
INFO - 2018-03-12 22:30:43 --> Hooks Class Initialized
INFO - 2018-03-12 22:30:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:30:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:30:43 --> Utf8 Class Initialized
INFO - 2018-03-12 22:30:43 --> Utf8 Class Initialized
INFO - 2018-03-12 22:30:43 --> URI Class Initialized
INFO - 2018-03-12 22:30:43 --> URI Class Initialized
INFO - 2018-03-12 22:30:43 --> Router Class Initialized
INFO - 2018-03-12 22:30:43 --> Router Class Initialized
INFO - 2018-03-12 22:30:43 --> Output Class Initialized
INFO - 2018-03-12 22:30:43 --> Output Class Initialized
INFO - 2018-03-12 22:30:43 --> Security Class Initialized
INFO - 2018-03-12 22:30:43 --> Security Class Initialized
DEBUG - 2018-03-12 22:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:30:43 --> CSRF cookie sent
INFO - 2018-03-12 22:30:43 --> CSRF cookie sent
INFO - 2018-03-12 22:30:43 --> Input Class Initialized
INFO - 2018-03-12 22:30:43 --> Input Class Initialized
INFO - 2018-03-12 22:30:43 --> Language Class Initialized
INFO - 2018-03-12 22:30:43 --> Language Class Initialized
ERROR - 2018-03-12 22:30:43 --> 404 Page Not Found: Images/bg
ERROR - 2018-03-12 22:30:43 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:32:07 --> Config Class Initialized
INFO - 2018-03-12 22:32:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:32:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:32:07 --> Utf8 Class Initialized
INFO - 2018-03-12 22:32:07 --> URI Class Initialized
INFO - 2018-03-12 22:32:07 --> Router Class Initialized
INFO - 2018-03-12 22:32:07 --> Output Class Initialized
INFO - 2018-03-12 22:32:07 --> Security Class Initialized
DEBUG - 2018-03-12 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:32:07 --> CSRF cookie sent
INFO - 2018-03-12 22:32:07 --> Input Class Initialized
INFO - 2018-03-12 22:32:07 --> Language Class Initialized
INFO - 2018-03-12 22:32:07 --> Loader Class Initialized
INFO - 2018-03-12 22:32:07 --> Helper loaded: url_helper
INFO - 2018-03-12 22:32:07 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:32:07 --> User Agent Class Initialized
INFO - 2018-03-12 22:32:07 --> Controller Class Initialized
INFO - 2018-03-12 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:32:07 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:32:07 --> Final output sent to browser
DEBUG - 2018-03-12 22:32:07 --> Total execution time: 0.1854
INFO - 2018-03-12 22:32:07 --> Config Class Initialized
INFO - 2018-03-12 22:32:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:32:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:32:07 --> Utf8 Class Initialized
INFO - 2018-03-12 22:32:07 --> URI Class Initialized
INFO - 2018-03-12 22:32:07 --> Router Class Initialized
INFO - 2018-03-12 22:32:07 --> Output Class Initialized
INFO - 2018-03-12 22:32:07 --> Security Class Initialized
DEBUG - 2018-03-12 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:32:07 --> CSRF cookie sent
INFO - 2018-03-12 22:32:07 --> Input Class Initialized
INFO - 2018-03-12 22:32:07 --> Language Class Initialized
ERROR - 2018-03-12 22:32:07 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:32:07 --> Config Class Initialized
INFO - 2018-03-12 22:32:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:32:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:32:07 --> Utf8 Class Initialized
INFO - 2018-03-12 22:32:07 --> URI Class Initialized
INFO - 2018-03-12 22:32:07 --> Router Class Initialized
INFO - 2018-03-12 22:32:07 --> Output Class Initialized
INFO - 2018-03-12 22:32:07 --> Config Class Initialized
INFO - 2018-03-12 22:32:07 --> Hooks Class Initialized
INFO - 2018-03-12 22:32:07 --> Security Class Initialized
DEBUG - 2018-03-12 22:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:32:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:32:07 --> Utf8 Class Initialized
INFO - 2018-03-12 22:32:07 --> CSRF cookie sent
INFO - 2018-03-12 22:32:07 --> Input Class Initialized
INFO - 2018-03-12 22:32:07 --> URI Class Initialized
INFO - 2018-03-12 22:32:07 --> Language Class Initialized
INFO - 2018-03-12 22:32:07 --> Router Class Initialized
ERROR - 2018-03-12 22:32:07 --> 404 Page Not Found: Images/bg
INFO - 2018-03-12 22:32:07 --> Output Class Initialized
INFO - 2018-03-12 22:32:07 --> Security Class Initialized
DEBUG - 2018-03-12 22:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:32:08 --> CSRF cookie sent
INFO - 2018-03-12 22:32:08 --> Input Class Initialized
INFO - 2018-03-12 22:32:08 --> Language Class Initialized
ERROR - 2018-03-12 22:32:08 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:32:08 --> Config Class Initialized
INFO - 2018-03-12 22:32:08 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:32:08 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:32:08 --> Utf8 Class Initialized
INFO - 2018-03-12 22:32:08 --> URI Class Initialized
INFO - 2018-03-12 22:32:08 --> Router Class Initialized
INFO - 2018-03-12 22:32:08 --> Output Class Initialized
INFO - 2018-03-12 22:32:08 --> Security Class Initialized
DEBUG - 2018-03-12 22:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:32:08 --> CSRF cookie sent
INFO - 2018-03-12 22:32:08 --> Input Class Initialized
INFO - 2018-03-12 22:32:08 --> Language Class Initialized
ERROR - 2018-03-12 22:32:08 --> 404 Page Not Found: Images/bg
INFO - 2018-03-12 22:33:34 --> Config Class Initialized
INFO - 2018-03-12 22:33:34 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:33:34 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:34 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:34 --> URI Class Initialized
INFO - 2018-03-12 22:33:34 --> Router Class Initialized
INFO - 2018-03-12 22:33:34 --> Output Class Initialized
INFO - 2018-03-12 22:33:35 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:33:35 --> CSRF cookie sent
INFO - 2018-03-12 22:33:35 --> Input Class Initialized
INFO - 2018-03-12 22:33:35 --> Language Class Initialized
INFO - 2018-03-12 22:33:35 --> Loader Class Initialized
INFO - 2018-03-12 22:33:35 --> Helper loaded: url_helper
INFO - 2018-03-12 22:33:35 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:33:35 --> User Agent Class Initialized
INFO - 2018-03-12 22:33:35 --> Controller Class Initialized
INFO - 2018-03-12 22:33:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:33:35 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:33:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:33:35 --> Final output sent to browser
DEBUG - 2018-03-12 22:33:35 --> Total execution time: 0.1875
INFO - 2018-03-12 22:33:35 --> Config Class Initialized
INFO - 2018-03-12 22:33:35 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:35 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:35 --> URI Class Initialized
INFO - 2018-03-12 22:33:35 --> Router Class Initialized
INFO - 2018-03-12 22:33:35 --> Output Class Initialized
INFO - 2018-03-12 22:33:35 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:33:35 --> CSRF cookie sent
INFO - 2018-03-12 22:33:35 --> Input Class Initialized
INFO - 2018-03-12 22:33:35 --> Language Class Initialized
INFO - 2018-03-12 22:33:35 --> Config Class Initialized
INFO - 2018-03-12 22:33:35 --> Hooks Class Initialized
ERROR - 2018-03-12 22:33:35 --> 404 Page Not Found: Assets/images
DEBUG - 2018-03-12 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:35 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:35 --> URI Class Initialized
INFO - 2018-03-12 22:33:35 --> Router Class Initialized
INFO - 2018-03-12 22:33:35 --> Output Class Initialized
INFO - 2018-03-12 22:33:35 --> Config Class Initialized
INFO - 2018-03-12 22:33:35 --> Hooks Class Initialized
INFO - 2018-03-12 22:33:35 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:35 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:35 --> CSRF cookie sent
INFO - 2018-03-12 22:33:35 --> Input Class Initialized
INFO - 2018-03-12 22:33:35 --> URI Class Initialized
INFO - 2018-03-12 22:33:35 --> Language Class Initialized
INFO - 2018-03-12 22:33:35 --> Router Class Initialized
ERROR - 2018-03-12 22:33:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:33:35 --> Output Class Initialized
INFO - 2018-03-12 22:33:35 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:33:35 --> CSRF cookie sent
INFO - 2018-03-12 22:33:35 --> Input Class Initialized
INFO - 2018-03-12 22:33:35 --> Language Class Initialized
ERROR - 2018-03-12 22:33:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:33:35 --> Config Class Initialized
INFO - 2018-03-12 22:33:35 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:35 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:35 --> URI Class Initialized
INFO - 2018-03-12 22:33:35 --> Router Class Initialized
INFO - 2018-03-12 22:33:35 --> Output Class Initialized
INFO - 2018-03-12 22:33:35 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:33:35 --> CSRF cookie sent
INFO - 2018-03-12 22:33:35 --> Input Class Initialized
INFO - 2018-03-12 22:33:35 --> Language Class Initialized
ERROR - 2018-03-12 22:33:35 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:33:52 --> Config Class Initialized
INFO - 2018-03-12 22:33:52 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:33:52 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:33:52 --> Utf8 Class Initialized
INFO - 2018-03-12 22:33:52 --> URI Class Initialized
INFO - 2018-03-12 22:33:52 --> Router Class Initialized
INFO - 2018-03-12 22:33:52 --> Output Class Initialized
INFO - 2018-03-12 22:33:52 --> Security Class Initialized
DEBUG - 2018-03-12 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:33:52 --> CSRF cookie sent
INFO - 2018-03-12 22:33:52 --> Input Class Initialized
INFO - 2018-03-12 22:33:52 --> Language Class Initialized
INFO - 2018-03-12 22:33:52 --> Loader Class Initialized
INFO - 2018-03-12 22:33:52 --> Helper loaded: url_helper
INFO - 2018-03-12 22:33:52 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:33:52 --> User Agent Class Initialized
INFO - 2018-03-12 22:33:52 --> Controller Class Initialized
INFO - 2018-03-12 22:33:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
ERROR - 2018-03-12 22:33:52 --> Severity: Error --> Call to undefined method Smart::loadImage() E:\www\yacopoo\application\views\register.php 1
INFO - 2018-03-12 22:34:24 --> Config Class Initialized
INFO - 2018-03-12 22:34:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:34:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:34:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:34:24 --> URI Class Initialized
INFO - 2018-03-12 22:34:24 --> Router Class Initialized
INFO - 2018-03-12 22:34:24 --> Output Class Initialized
INFO - 2018-03-12 22:34:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:34:24 --> CSRF cookie sent
INFO - 2018-03-12 22:34:24 --> Input Class Initialized
INFO - 2018-03-12 22:34:24 --> Language Class Initialized
INFO - 2018-03-12 22:34:24 --> Loader Class Initialized
INFO - 2018-03-12 22:34:24 --> Helper loaded: url_helper
INFO - 2018-03-12 22:34:24 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:34:24 --> User Agent Class Initialized
INFO - 2018-03-12 22:34:24 --> Controller Class Initialized
INFO - 2018-03-12 22:34:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:34:24 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:34:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:34:24 --> Final output sent to browser
DEBUG - 2018-03-12 22:34:24 --> Total execution time: 0.1932
INFO - 2018-03-12 22:34:24 --> Config Class Initialized
INFO - 2018-03-12 22:34:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:34:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:34:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:34:24 --> URI Class Initialized
INFO - 2018-03-12 22:34:24 --> Router Class Initialized
INFO - 2018-03-12 22:34:24 --> Output Class Initialized
INFO - 2018-03-12 22:34:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:34:24 --> CSRF cookie sent
INFO - 2018-03-12 22:34:24 --> Input Class Initialized
INFO - 2018-03-12 22:34:24 --> Language Class Initialized
ERROR - 2018-03-12 22:34:24 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:34:24 --> Config Class Initialized
INFO - 2018-03-12 22:34:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:34:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:34:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:34:24 --> URI Class Initialized
INFO - 2018-03-12 22:34:24 --> Router Class Initialized
INFO - 2018-03-12 22:34:24 --> Output Class Initialized
INFO - 2018-03-12 22:34:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:34:24 --> CSRF cookie sent
INFO - 2018-03-12 22:34:24 --> Input Class Initialized
INFO - 2018-03-12 22:34:24 --> Language Class Initialized
ERROR - 2018-03-12 22:34:24 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:36:22 --> Config Class Initialized
INFO - 2018-03-12 22:36:22 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:36:22 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:36:22 --> Utf8 Class Initialized
INFO - 2018-03-12 22:36:22 --> URI Class Initialized
INFO - 2018-03-12 22:36:22 --> Router Class Initialized
INFO - 2018-03-12 22:36:22 --> Output Class Initialized
INFO - 2018-03-12 22:36:22 --> Security Class Initialized
DEBUG - 2018-03-12 22:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:36:22 --> CSRF cookie sent
INFO - 2018-03-12 22:36:22 --> Input Class Initialized
INFO - 2018-03-12 22:36:23 --> Language Class Initialized
INFO - 2018-03-12 22:36:23 --> Loader Class Initialized
INFO - 2018-03-12 22:36:23 --> Helper loaded: url_helper
INFO - 2018-03-12 22:36:23 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:36:23 --> User Agent Class Initialized
INFO - 2018-03-12 22:36:23 --> Controller Class Initialized
INFO - 2018-03-12 22:36:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:36:23 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:36:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:36:23 --> Final output sent to browser
DEBUG - 2018-03-12 22:36:23 --> Total execution time: 0.1993
INFO - 2018-03-12 22:36:23 --> Config Class Initialized
INFO - 2018-03-12 22:36:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:36:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:36:23 --> Utf8 Class Initialized
INFO - 2018-03-12 22:36:23 --> URI Class Initialized
INFO - 2018-03-12 22:36:23 --> Router Class Initialized
INFO - 2018-03-12 22:36:23 --> Output Class Initialized
INFO - 2018-03-12 22:36:23 --> Security Class Initialized
DEBUG - 2018-03-12 22:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:36:23 --> CSRF cookie sent
INFO - 2018-03-12 22:36:23 --> Input Class Initialized
INFO - 2018-03-12 22:36:23 --> Language Class Initialized
ERROR - 2018-03-12 22:36:23 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:36:23 --> Config Class Initialized
INFO - 2018-03-12 22:36:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:36:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:36:23 --> Utf8 Class Initialized
INFO - 2018-03-12 22:36:23 --> URI Class Initialized
INFO - 2018-03-12 22:36:23 --> Router Class Initialized
INFO - 2018-03-12 22:36:23 --> Output Class Initialized
INFO - 2018-03-12 22:36:23 --> Security Class Initialized
DEBUG - 2018-03-12 22:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:36:23 --> CSRF cookie sent
INFO - 2018-03-12 22:36:23 --> Input Class Initialized
INFO - 2018-03-12 22:36:23 --> Language Class Initialized
ERROR - 2018-03-12 22:36:23 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:37:19 --> Config Class Initialized
INFO - 2018-03-12 22:37:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:19 --> URI Class Initialized
INFO - 2018-03-12 22:37:19 --> Router Class Initialized
INFO - 2018-03-12 22:37:19 --> Output Class Initialized
INFO - 2018-03-12 22:37:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:19 --> CSRF cookie sent
INFO - 2018-03-12 22:37:19 --> Input Class Initialized
INFO - 2018-03-12 22:37:19 --> Language Class Initialized
INFO - 2018-03-12 22:37:19 --> Loader Class Initialized
INFO - 2018-03-12 22:37:19 --> Helper loaded: url_helper
INFO - 2018-03-12 22:37:19 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:37:19 --> User Agent Class Initialized
INFO - 2018-03-12 22:37:19 --> Controller Class Initialized
INFO - 2018-03-12 22:37:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:37:19 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:37:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:37:19 --> Final output sent to browser
DEBUG - 2018-03-12 22:37:19 --> Total execution time: 0.2015
INFO - 2018-03-12 22:37:20 --> Config Class Initialized
INFO - 2018-03-12 22:37:20 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:20 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:20 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:20 --> URI Class Initialized
INFO - 2018-03-12 22:37:20 --> Router Class Initialized
INFO - 2018-03-12 22:37:20 --> Output Class Initialized
INFO - 2018-03-12 22:37:20 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:20 --> CSRF cookie sent
INFO - 2018-03-12 22:37:20 --> Input Class Initialized
INFO - 2018-03-12 22:37:20 --> Language Class Initialized
ERROR - 2018-03-12 22:37:20 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:37:20 --> Config Class Initialized
INFO - 2018-03-12 22:37:20 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:20 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:20 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:20 --> URI Class Initialized
INFO - 2018-03-12 22:37:20 --> Router Class Initialized
INFO - 2018-03-12 22:37:20 --> Output Class Initialized
INFO - 2018-03-12 22:37:20 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:20 --> CSRF cookie sent
INFO - 2018-03-12 22:37:20 --> Input Class Initialized
INFO - 2018-03-12 22:37:20 --> Language Class Initialized
ERROR - 2018-03-12 22:37:20 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:37:39 --> Config Class Initialized
INFO - 2018-03-12 22:37:39 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:39 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:39 --> URI Class Initialized
INFO - 2018-03-12 22:37:39 --> Router Class Initialized
INFO - 2018-03-12 22:37:39 --> Output Class Initialized
INFO - 2018-03-12 22:37:39 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:39 --> CSRF cookie sent
INFO - 2018-03-12 22:37:39 --> Input Class Initialized
INFO - 2018-03-12 22:37:39 --> Language Class Initialized
INFO - 2018-03-12 22:37:39 --> Loader Class Initialized
INFO - 2018-03-12 22:37:39 --> Helper loaded: url_helper
INFO - 2018-03-12 22:37:39 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:37:39 --> User Agent Class Initialized
INFO - 2018-03-12 22:37:39 --> Controller Class Initialized
INFO - 2018-03-12 22:37:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:37:39 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:37:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:37:39 --> Final output sent to browser
DEBUG - 2018-03-12 22:37:39 --> Total execution time: 0.1884
INFO - 2018-03-12 22:37:40 --> Config Class Initialized
INFO - 2018-03-12 22:37:40 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:40 --> URI Class Initialized
INFO - 2018-03-12 22:37:40 --> Router Class Initialized
INFO - 2018-03-12 22:37:40 --> Output Class Initialized
INFO - 2018-03-12 22:37:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:40 --> CSRF cookie sent
INFO - 2018-03-12 22:37:40 --> Input Class Initialized
INFO - 2018-03-12 22:37:40 --> Language Class Initialized
ERROR - 2018-03-12 22:37:40 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:37:40 --> Config Class Initialized
INFO - 2018-03-12 22:37:40 --> Config Class Initialized
INFO - 2018-03-12 22:37:40 --> Hooks Class Initialized
INFO - 2018-03-12 22:37:40 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 22:37:40 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:37:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:40 --> Utf8 Class Initialized
INFO - 2018-03-12 22:37:40 --> URI Class Initialized
INFO - 2018-03-12 22:37:40 --> URI Class Initialized
INFO - 2018-03-12 22:37:40 --> Router Class Initialized
INFO - 2018-03-12 22:37:40 --> Router Class Initialized
INFO - 2018-03-12 22:37:40 --> Output Class Initialized
INFO - 2018-03-12 22:37:40 --> Output Class Initialized
INFO - 2018-03-12 22:37:40 --> Security Class Initialized
DEBUG - 2018-03-12 22:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:40 --> CSRF cookie sent
INFO - 2018-03-12 22:37:40 --> Security Class Initialized
INFO - 2018-03-12 22:37:40 --> Input Class Initialized
INFO - 2018-03-12 22:37:40 --> Language Class Initialized
DEBUG - 2018-03-12 22:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:37:40 --> CSRF cookie sent
ERROR - 2018-03-12 22:37:40 --> 404 Page Not Found: Images/bg
INFO - 2018-03-12 22:37:40 --> Input Class Initialized
INFO - 2018-03-12 22:37:40 --> Language Class Initialized
ERROR - 2018-03-12 22:37:40 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:38:24 --> Config Class Initialized
INFO - 2018-03-12 22:38:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:38:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:38:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:38:24 --> URI Class Initialized
INFO - 2018-03-12 22:38:24 --> Router Class Initialized
INFO - 2018-03-12 22:38:24 --> Output Class Initialized
INFO - 2018-03-12 22:38:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:38:24 --> CSRF cookie sent
INFO - 2018-03-12 22:38:24 --> Input Class Initialized
INFO - 2018-03-12 22:38:24 --> Language Class Initialized
INFO - 2018-03-12 22:38:24 --> Loader Class Initialized
INFO - 2018-03-12 22:38:24 --> Helper loaded: url_helper
INFO - 2018-03-12 22:38:24 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:38:24 --> User Agent Class Initialized
INFO - 2018-03-12 22:38:24 --> Controller Class Initialized
INFO - 2018-03-12 22:38:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:38:24 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:38:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:38:24 --> Final output sent to browser
DEBUG - 2018-03-12 22:38:24 --> Total execution time: 0.1984
INFO - 2018-03-12 22:38:24 --> Config Class Initialized
INFO - 2018-03-12 22:38:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:38:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:38:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:38:24 --> URI Class Initialized
INFO - 2018-03-12 22:38:24 --> Router Class Initialized
INFO - 2018-03-12 22:38:24 --> Output Class Initialized
INFO - 2018-03-12 22:38:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:38:24 --> CSRF cookie sent
INFO - 2018-03-12 22:38:24 --> Input Class Initialized
INFO - 2018-03-12 22:38:24 --> Language Class Initialized
ERROR - 2018-03-12 22:38:24 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:38:24 --> Config Class Initialized
INFO - 2018-03-12 22:38:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:38:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:38:24 --> Utf8 Class Initialized
INFO - 2018-03-12 22:38:24 --> URI Class Initialized
INFO - 2018-03-12 22:38:24 --> Router Class Initialized
INFO - 2018-03-12 22:38:24 --> Output Class Initialized
INFO - 2018-03-12 22:38:24 --> Security Class Initialized
DEBUG - 2018-03-12 22:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:38:24 --> CSRF cookie sent
INFO - 2018-03-12 22:38:24 --> Input Class Initialized
INFO - 2018-03-12 22:38:24 --> Language Class Initialized
ERROR - 2018-03-12 22:38:24 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:39:31 --> Config Class Initialized
INFO - 2018-03-12 22:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:39:31 --> Utf8 Class Initialized
INFO - 2018-03-12 22:39:31 --> URI Class Initialized
INFO - 2018-03-12 22:39:31 --> Router Class Initialized
INFO - 2018-03-12 22:39:31 --> Output Class Initialized
INFO - 2018-03-12 22:39:31 --> Security Class Initialized
DEBUG - 2018-03-12 22:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:39:31 --> CSRF cookie sent
INFO - 2018-03-12 22:39:31 --> Input Class Initialized
INFO - 2018-03-12 22:39:31 --> Language Class Initialized
INFO - 2018-03-12 22:39:31 --> Loader Class Initialized
INFO - 2018-03-12 22:39:31 --> Helper loaded: url_helper
INFO - 2018-03-12 22:39:31 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:39:31 --> User Agent Class Initialized
INFO - 2018-03-12 22:39:31 --> Controller Class Initialized
INFO - 2018-03-12 22:39:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:39:31 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:39:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:39:31 --> Final output sent to browser
DEBUG - 2018-03-12 22:39:31 --> Total execution time: 0.2079
INFO - 2018-03-12 22:39:31 --> Config Class Initialized
INFO - 2018-03-12 22:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:39:31 --> Utf8 Class Initialized
INFO - 2018-03-12 22:39:31 --> URI Class Initialized
INFO - 2018-03-12 22:39:31 --> Router Class Initialized
INFO - 2018-03-12 22:39:31 --> Output Class Initialized
INFO - 2018-03-12 22:39:31 --> Security Class Initialized
DEBUG - 2018-03-12 22:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:39:31 --> CSRF cookie sent
INFO - 2018-03-12 22:39:31 --> Input Class Initialized
INFO - 2018-03-12 22:39:31 --> Language Class Initialized
ERROR - 2018-03-12 22:39:31 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:39:31 --> Config Class Initialized
INFO - 2018-03-12 22:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:39:31 --> Utf8 Class Initialized
INFO - 2018-03-12 22:39:32 --> URI Class Initialized
INFO - 2018-03-12 22:39:32 --> Router Class Initialized
INFO - 2018-03-12 22:39:32 --> Output Class Initialized
INFO - 2018-03-12 22:39:32 --> Security Class Initialized
DEBUG - 2018-03-12 22:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:39:32 --> CSRF cookie sent
INFO - 2018-03-12 22:39:32 --> Input Class Initialized
INFO - 2018-03-12 22:39:32 --> Language Class Initialized
ERROR - 2018-03-12 22:39:32 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:40:01 --> Config Class Initialized
INFO - 2018-03-12 22:40:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:01 --> URI Class Initialized
INFO - 2018-03-12 22:40:01 --> Router Class Initialized
INFO - 2018-03-12 22:40:01 --> Output Class Initialized
INFO - 2018-03-12 22:40:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:01 --> CSRF cookie sent
INFO - 2018-03-12 22:40:01 --> Input Class Initialized
INFO - 2018-03-12 22:40:01 --> Language Class Initialized
INFO - 2018-03-12 22:40:01 --> Loader Class Initialized
INFO - 2018-03-12 22:40:01 --> Helper loaded: url_helper
INFO - 2018-03-12 22:40:01 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:40:01 --> User Agent Class Initialized
INFO - 2018-03-12 22:40:01 --> Controller Class Initialized
INFO - 2018-03-12 22:40:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:40:01 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:40:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:40:01 --> Final output sent to browser
DEBUG - 2018-03-12 22:40:01 --> Total execution time: 0.2024
INFO - 2018-03-12 22:40:01 --> Config Class Initialized
INFO - 2018-03-12 22:40:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:01 --> URI Class Initialized
INFO - 2018-03-12 22:40:01 --> Router Class Initialized
INFO - 2018-03-12 22:40:01 --> Output Class Initialized
INFO - 2018-03-12 22:40:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:01 --> CSRF cookie sent
INFO - 2018-03-12 22:40:01 --> Input Class Initialized
INFO - 2018-03-12 22:40:01 --> Language Class Initialized
ERROR - 2018-03-12 22:40:01 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:40:01 --> Config Class Initialized
INFO - 2018-03-12 22:40:01 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:01 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:01 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:01 --> URI Class Initialized
INFO - 2018-03-12 22:40:01 --> Router Class Initialized
INFO - 2018-03-12 22:40:01 --> Output Class Initialized
INFO - 2018-03-12 22:40:01 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:01 --> CSRF cookie sent
INFO - 2018-03-12 22:40:01 --> Input Class Initialized
INFO - 2018-03-12 22:40:01 --> Language Class Initialized
ERROR - 2018-03-12 22:40:02 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:40:19 --> Config Class Initialized
INFO - 2018-03-12 22:40:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:19 --> URI Class Initialized
INFO - 2018-03-12 22:40:19 --> Router Class Initialized
INFO - 2018-03-12 22:40:19 --> Output Class Initialized
INFO - 2018-03-12 22:40:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:19 --> CSRF cookie sent
INFO - 2018-03-12 22:40:19 --> Input Class Initialized
INFO - 2018-03-12 22:40:19 --> Language Class Initialized
INFO - 2018-03-12 22:40:19 --> Loader Class Initialized
INFO - 2018-03-12 22:40:19 --> Helper loaded: url_helper
INFO - 2018-03-12 22:40:19 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:40:19 --> User Agent Class Initialized
INFO - 2018-03-12 22:40:19 --> Controller Class Initialized
INFO - 2018-03-12 22:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:40:19 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:40:19 --> Final output sent to browser
DEBUG - 2018-03-12 22:40:19 --> Total execution time: 0.2206
INFO - 2018-03-12 22:40:19 --> Config Class Initialized
INFO - 2018-03-12 22:40:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:19 --> URI Class Initialized
INFO - 2018-03-12 22:40:19 --> Router Class Initialized
INFO - 2018-03-12 22:40:19 --> Output Class Initialized
INFO - 2018-03-12 22:40:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:19 --> CSRF cookie sent
INFO - 2018-03-12 22:40:19 --> Input Class Initialized
INFO - 2018-03-12 22:40:19 --> Language Class Initialized
ERROR - 2018-03-12 22:40:19 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:40:19 --> Config Class Initialized
INFO - 2018-03-12 22:40:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:19 --> URI Class Initialized
INFO - 2018-03-12 22:40:19 --> Router Class Initialized
INFO - 2018-03-12 22:40:20 --> Output Class Initialized
INFO - 2018-03-12 22:40:20 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:20 --> CSRF cookie sent
INFO - 2018-03-12 22:40:20 --> Input Class Initialized
INFO - 2018-03-12 22:40:20 --> Language Class Initialized
ERROR - 2018-03-12 22:40:20 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:40:53 --> Config Class Initialized
INFO - 2018-03-12 22:40:53 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:53 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:53 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:53 --> URI Class Initialized
INFO - 2018-03-12 22:40:53 --> Router Class Initialized
INFO - 2018-03-12 22:40:53 --> Output Class Initialized
INFO - 2018-03-12 22:40:53 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:53 --> CSRF cookie sent
INFO - 2018-03-12 22:40:53 --> Input Class Initialized
INFO - 2018-03-12 22:40:53 --> Language Class Initialized
INFO - 2018-03-12 22:40:53 --> Loader Class Initialized
INFO - 2018-03-12 22:40:53 --> Helper loaded: url_helper
INFO - 2018-03-12 22:40:53 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:40:53 --> User Agent Class Initialized
INFO - 2018-03-12 22:40:53 --> Controller Class Initialized
INFO - 2018-03-12 22:40:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:40:53 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:40:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:40:53 --> Final output sent to browser
DEBUG - 2018-03-12 22:40:53 --> Total execution time: 0.1978
INFO - 2018-03-12 22:40:53 --> Config Class Initialized
INFO - 2018-03-12 22:40:53 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:53 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:53 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:53 --> URI Class Initialized
INFO - 2018-03-12 22:40:53 --> Router Class Initialized
INFO - 2018-03-12 22:40:53 --> Output Class Initialized
INFO - 2018-03-12 22:40:53 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:53 --> CSRF cookie sent
INFO - 2018-03-12 22:40:53 --> Input Class Initialized
INFO - 2018-03-12 22:40:53 --> Language Class Initialized
ERROR - 2018-03-12 22:40:53 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:40:53 --> Config Class Initialized
INFO - 2018-03-12 22:40:53 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:40:53 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:40:53 --> Utf8 Class Initialized
INFO - 2018-03-12 22:40:53 --> URI Class Initialized
INFO - 2018-03-12 22:40:53 --> Router Class Initialized
INFO - 2018-03-12 22:40:54 --> Output Class Initialized
INFO - 2018-03-12 22:40:54 --> Security Class Initialized
DEBUG - 2018-03-12 22:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:40:54 --> CSRF cookie sent
INFO - 2018-03-12 22:40:54 --> Input Class Initialized
INFO - 2018-03-12 22:40:54 --> Language Class Initialized
ERROR - 2018-03-12 22:40:54 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:41:15 --> Config Class Initialized
INFO - 2018-03-12 22:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:41:15 --> Utf8 Class Initialized
INFO - 2018-03-12 22:41:15 --> URI Class Initialized
INFO - 2018-03-12 22:41:15 --> Router Class Initialized
INFO - 2018-03-12 22:41:15 --> Output Class Initialized
INFO - 2018-03-12 22:41:15 --> Security Class Initialized
DEBUG - 2018-03-12 22:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:41:15 --> CSRF cookie sent
INFO - 2018-03-12 22:41:15 --> Input Class Initialized
INFO - 2018-03-12 22:41:15 --> Language Class Initialized
INFO - 2018-03-12 22:41:15 --> Loader Class Initialized
INFO - 2018-03-12 22:41:15 --> Helper loaded: url_helper
INFO - 2018-03-12 22:41:15 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:41:15 --> User Agent Class Initialized
INFO - 2018-03-12 22:41:15 --> Controller Class Initialized
INFO - 2018-03-12 22:41:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:41:15 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:41:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:41:15 --> Final output sent to browser
DEBUG - 2018-03-12 22:41:15 --> Total execution time: 0.2171
INFO - 2018-03-12 22:41:15 --> Config Class Initialized
INFO - 2018-03-12 22:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:41:15 --> Utf8 Class Initialized
INFO - 2018-03-12 22:41:15 --> URI Class Initialized
INFO - 2018-03-12 22:41:15 --> Router Class Initialized
INFO - 2018-03-12 22:41:15 --> Output Class Initialized
INFO - 2018-03-12 22:41:15 --> Security Class Initialized
DEBUG - 2018-03-12 22:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:41:15 --> CSRF cookie sent
INFO - 2018-03-12 22:41:15 --> Input Class Initialized
INFO - 2018-03-12 22:41:15 --> Language Class Initialized
ERROR - 2018-03-12 22:41:15 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:41:16 --> Config Class Initialized
INFO - 2018-03-12 22:41:16 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:41:16 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:41:16 --> Utf8 Class Initialized
INFO - 2018-03-12 22:41:16 --> URI Class Initialized
INFO - 2018-03-12 22:41:16 --> Router Class Initialized
INFO - 2018-03-12 22:41:16 --> Output Class Initialized
INFO - 2018-03-12 22:41:16 --> Security Class Initialized
DEBUG - 2018-03-12 22:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:41:16 --> CSRF cookie sent
INFO - 2018-03-12 22:41:16 --> Input Class Initialized
INFO - 2018-03-12 22:41:16 --> Language Class Initialized
ERROR - 2018-03-12 22:41:16 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:42:06 --> Config Class Initialized
INFO - 2018-03-12 22:42:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:42:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:42:06 --> Utf8 Class Initialized
INFO - 2018-03-12 22:42:06 --> URI Class Initialized
INFO - 2018-03-12 22:42:06 --> Router Class Initialized
INFO - 2018-03-12 22:42:06 --> Output Class Initialized
INFO - 2018-03-12 22:42:06 --> Security Class Initialized
DEBUG - 2018-03-12 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:42:06 --> CSRF cookie sent
INFO - 2018-03-12 22:42:06 --> Input Class Initialized
INFO - 2018-03-12 22:42:06 --> Language Class Initialized
INFO - 2018-03-12 22:42:06 --> Loader Class Initialized
INFO - 2018-03-12 22:42:06 --> Helper loaded: url_helper
INFO - 2018-03-12 22:42:06 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:42:06 --> User Agent Class Initialized
INFO - 2018-03-12 22:42:06 --> Controller Class Initialized
INFO - 2018-03-12 22:42:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:42:06 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:42:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:42:06 --> Final output sent to browser
DEBUG - 2018-03-12 22:42:06 --> Total execution time: 0.2193
INFO - 2018-03-12 22:42:06 --> Config Class Initialized
INFO - 2018-03-12 22:42:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:42:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:42:06 --> Utf8 Class Initialized
INFO - 2018-03-12 22:42:06 --> URI Class Initialized
INFO - 2018-03-12 22:42:06 --> Router Class Initialized
INFO - 2018-03-12 22:42:06 --> Output Class Initialized
INFO - 2018-03-12 22:42:06 --> Security Class Initialized
DEBUG - 2018-03-12 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:42:06 --> CSRF cookie sent
INFO - 2018-03-12 22:42:06 --> Input Class Initialized
INFO - 2018-03-12 22:42:07 --> Language Class Initialized
ERROR - 2018-03-12 22:42:07 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:42:07 --> Config Class Initialized
INFO - 2018-03-12 22:42:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:42:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:42:07 --> Utf8 Class Initialized
INFO - 2018-03-12 22:42:07 --> URI Class Initialized
INFO - 2018-03-12 22:42:07 --> Router Class Initialized
INFO - 2018-03-12 22:42:07 --> Output Class Initialized
INFO - 2018-03-12 22:42:07 --> Security Class Initialized
DEBUG - 2018-03-12 22:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:42:07 --> CSRF cookie sent
INFO - 2018-03-12 22:42:07 --> Input Class Initialized
INFO - 2018-03-12 22:42:07 --> Language Class Initialized
ERROR - 2018-03-12 22:42:07 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:43:33 --> Config Class Initialized
INFO - 2018-03-12 22:43:33 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:33 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:33 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:33 --> URI Class Initialized
INFO - 2018-03-12 22:43:33 --> Router Class Initialized
INFO - 2018-03-12 22:43:33 --> Output Class Initialized
INFO - 2018-03-12 22:43:33 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:33 --> CSRF cookie sent
INFO - 2018-03-12 22:43:33 --> Input Class Initialized
INFO - 2018-03-12 22:43:33 --> Language Class Initialized
INFO - 2018-03-12 22:43:33 --> Loader Class Initialized
INFO - 2018-03-12 22:43:33 --> Helper loaded: url_helper
INFO - 2018-03-12 22:43:33 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:43:33 --> User Agent Class Initialized
INFO - 2018-03-12 22:43:33 --> Controller Class Initialized
INFO - 2018-03-12 22:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:43:33 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:43:33 --> Final output sent to browser
DEBUG - 2018-03-12 22:43:33 --> Total execution time: 0.2213
INFO - 2018-03-12 22:43:33 --> Config Class Initialized
INFO - 2018-03-12 22:43:33 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:33 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:33 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:33 --> URI Class Initialized
INFO - 2018-03-12 22:43:33 --> Router Class Initialized
INFO - 2018-03-12 22:43:33 --> Output Class Initialized
INFO - 2018-03-12 22:43:33 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:33 --> CSRF cookie sent
INFO - 2018-03-12 22:43:33 --> Input Class Initialized
INFO - 2018-03-12 22:43:33 --> Language Class Initialized
ERROR - 2018-03-12 22:43:33 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:43:33 --> Config Class Initialized
INFO - 2018-03-12 22:43:33 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:33 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:33 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:33 --> URI Class Initialized
INFO - 2018-03-12 22:43:33 --> Router Class Initialized
INFO - 2018-03-12 22:43:33 --> Output Class Initialized
INFO - 2018-03-12 22:43:33 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:33 --> CSRF cookie sent
INFO - 2018-03-12 22:43:34 --> Input Class Initialized
INFO - 2018-03-12 22:43:34 --> Language Class Initialized
ERROR - 2018-03-12 22:43:34 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:43:48 --> Config Class Initialized
INFO - 2018-03-12 22:43:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:48 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:48 --> URI Class Initialized
INFO - 2018-03-12 22:43:48 --> Router Class Initialized
INFO - 2018-03-12 22:43:48 --> Output Class Initialized
INFO - 2018-03-12 22:43:48 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:48 --> CSRF cookie sent
INFO - 2018-03-12 22:43:48 --> Input Class Initialized
INFO - 2018-03-12 22:43:48 --> Language Class Initialized
INFO - 2018-03-12 22:43:48 --> Loader Class Initialized
INFO - 2018-03-12 22:43:48 --> Helper loaded: url_helper
INFO - 2018-03-12 22:43:48 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:43:48 --> User Agent Class Initialized
INFO - 2018-03-12 22:43:48 --> Controller Class Initialized
INFO - 2018-03-12 22:43:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:43:48 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:43:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:43:48 --> Final output sent to browser
DEBUG - 2018-03-12 22:43:48 --> Total execution time: 0.2475
INFO - 2018-03-12 22:43:48 --> Config Class Initialized
INFO - 2018-03-12 22:43:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:48 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:48 --> URI Class Initialized
INFO - 2018-03-12 22:43:48 --> Router Class Initialized
INFO - 2018-03-12 22:43:48 --> Output Class Initialized
INFO - 2018-03-12 22:43:48 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:48 --> CSRF cookie sent
INFO - 2018-03-12 22:43:48 --> Input Class Initialized
INFO - 2018-03-12 22:43:48 --> Language Class Initialized
ERROR - 2018-03-12 22:43:48 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:43:48 --> Config Class Initialized
INFO - 2018-03-12 22:43:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:43:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:43:48 --> Utf8 Class Initialized
INFO - 2018-03-12 22:43:48 --> URI Class Initialized
INFO - 2018-03-12 22:43:48 --> Router Class Initialized
INFO - 2018-03-12 22:43:48 --> Output Class Initialized
INFO - 2018-03-12 22:43:48 --> Security Class Initialized
DEBUG - 2018-03-12 22:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:43:48 --> CSRF cookie sent
INFO - 2018-03-12 22:43:48 --> Input Class Initialized
INFO - 2018-03-12 22:43:48 --> Language Class Initialized
ERROR - 2018-03-12 22:43:48 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:44:26 --> Config Class Initialized
INFO - 2018-03-12 22:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:44:26 --> Utf8 Class Initialized
INFO - 2018-03-12 22:44:26 --> URI Class Initialized
INFO - 2018-03-12 22:44:26 --> Router Class Initialized
INFO - 2018-03-12 22:44:26 --> Output Class Initialized
INFO - 2018-03-12 22:44:26 --> Security Class Initialized
DEBUG - 2018-03-12 22:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:44:26 --> CSRF cookie sent
INFO - 2018-03-12 22:44:26 --> Input Class Initialized
INFO - 2018-03-12 22:44:26 --> Language Class Initialized
INFO - 2018-03-12 22:44:26 --> Loader Class Initialized
INFO - 2018-03-12 22:44:26 --> Helper loaded: url_helper
INFO - 2018-03-12 22:44:26 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:44:26 --> User Agent Class Initialized
INFO - 2018-03-12 22:44:26 --> Controller Class Initialized
INFO - 2018-03-12 22:44:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:44:26 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:44:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:44:26 --> Final output sent to browser
DEBUG - 2018-03-12 22:44:26 --> Total execution time: 0.1994
INFO - 2018-03-12 22:44:26 --> Config Class Initialized
INFO - 2018-03-12 22:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:44:26 --> Utf8 Class Initialized
INFO - 2018-03-12 22:44:26 --> URI Class Initialized
INFO - 2018-03-12 22:44:26 --> Router Class Initialized
INFO - 2018-03-12 22:44:26 --> Output Class Initialized
INFO - 2018-03-12 22:44:26 --> Security Class Initialized
DEBUG - 2018-03-12 22:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:44:26 --> CSRF cookie sent
INFO - 2018-03-12 22:44:26 --> Input Class Initialized
INFO - 2018-03-12 22:44:26 --> Language Class Initialized
ERROR - 2018-03-12 22:44:26 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:44:26 --> Config Class Initialized
INFO - 2018-03-12 22:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:44:26 --> Utf8 Class Initialized
INFO - 2018-03-12 22:44:26 --> URI Class Initialized
INFO - 2018-03-12 22:44:26 --> Router Class Initialized
INFO - 2018-03-12 22:44:26 --> Output Class Initialized
INFO - 2018-03-12 22:44:26 --> Security Class Initialized
DEBUG - 2018-03-12 22:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:44:26 --> CSRF cookie sent
INFO - 2018-03-12 22:44:27 --> Input Class Initialized
INFO - 2018-03-12 22:44:27 --> Language Class Initialized
ERROR - 2018-03-12 22:44:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:45:19 --> Config Class Initialized
INFO - 2018-03-12 22:45:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:45:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:45:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:45:19 --> URI Class Initialized
INFO - 2018-03-12 22:45:19 --> Router Class Initialized
INFO - 2018-03-12 22:45:19 --> Output Class Initialized
INFO - 2018-03-12 22:45:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:45:19 --> CSRF cookie sent
INFO - 2018-03-12 22:45:19 --> Input Class Initialized
INFO - 2018-03-12 22:45:19 --> Language Class Initialized
INFO - 2018-03-12 22:45:19 --> Loader Class Initialized
INFO - 2018-03-12 22:45:19 --> Helper loaded: url_helper
INFO - 2018-03-12 22:45:19 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:45:19 --> User Agent Class Initialized
INFO - 2018-03-12 22:45:19 --> Controller Class Initialized
INFO - 2018-03-12 22:45:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:45:19 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:45:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:45:19 --> Final output sent to browser
DEBUG - 2018-03-12 22:45:19 --> Total execution time: 0.1998
INFO - 2018-03-12 22:45:19 --> Config Class Initialized
INFO - 2018-03-12 22:45:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:45:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:45:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:45:19 --> URI Class Initialized
INFO - 2018-03-12 22:45:19 --> Router Class Initialized
INFO - 2018-03-12 22:45:19 --> Output Class Initialized
INFO - 2018-03-12 22:45:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:45:19 --> CSRF cookie sent
INFO - 2018-03-12 22:45:19 --> Input Class Initialized
INFO - 2018-03-12 22:45:19 --> Language Class Initialized
ERROR - 2018-03-12 22:45:19 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:45:19 --> Config Class Initialized
INFO - 2018-03-12 22:45:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:45:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:45:19 --> Utf8 Class Initialized
INFO - 2018-03-12 22:45:19 --> URI Class Initialized
INFO - 2018-03-12 22:45:19 --> Router Class Initialized
INFO - 2018-03-12 22:45:19 --> Output Class Initialized
INFO - 2018-03-12 22:45:19 --> Security Class Initialized
DEBUG - 2018-03-12 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:45:19 --> CSRF cookie sent
INFO - 2018-03-12 22:45:19 --> Input Class Initialized
INFO - 2018-03-12 22:45:19 --> Language Class Initialized
ERROR - 2018-03-12 22:45:19 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:46:22 --> Config Class Initialized
INFO - 2018-03-12 22:46:22 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:46:22 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:46:22 --> Utf8 Class Initialized
INFO - 2018-03-12 22:46:22 --> URI Class Initialized
INFO - 2018-03-12 22:46:22 --> Router Class Initialized
INFO - 2018-03-12 22:46:22 --> Output Class Initialized
INFO - 2018-03-12 22:46:22 --> Security Class Initialized
DEBUG - 2018-03-12 22:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:46:22 --> CSRF cookie sent
INFO - 2018-03-12 22:46:22 --> Input Class Initialized
INFO - 2018-03-12 22:46:22 --> Language Class Initialized
INFO - 2018-03-12 22:46:22 --> Loader Class Initialized
INFO - 2018-03-12 22:46:22 --> Helper loaded: url_helper
INFO - 2018-03-12 22:46:22 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:46:22 --> User Agent Class Initialized
INFO - 2018-03-12 22:46:22 --> Controller Class Initialized
INFO - 2018-03-12 22:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:46:23 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:46:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:46:23 --> Final output sent to browser
DEBUG - 2018-03-12 22:46:23 --> Total execution time: 0.2395
INFO - 2018-03-12 22:46:23 --> Config Class Initialized
INFO - 2018-03-12 22:46:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:46:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:46:23 --> Utf8 Class Initialized
INFO - 2018-03-12 22:46:23 --> URI Class Initialized
INFO - 2018-03-12 22:46:23 --> Router Class Initialized
INFO - 2018-03-12 22:46:23 --> Output Class Initialized
INFO - 2018-03-12 22:46:23 --> Security Class Initialized
DEBUG - 2018-03-12 22:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:46:23 --> CSRF cookie sent
INFO - 2018-03-12 22:46:23 --> Input Class Initialized
INFO - 2018-03-12 22:46:23 --> Language Class Initialized
ERROR - 2018-03-12 22:46:23 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:46:23 --> Config Class Initialized
INFO - 2018-03-12 22:46:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:46:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:46:23 --> Utf8 Class Initialized
INFO - 2018-03-12 22:46:23 --> URI Class Initialized
INFO - 2018-03-12 22:46:23 --> Router Class Initialized
INFO - 2018-03-12 22:46:23 --> Output Class Initialized
INFO - 2018-03-12 22:46:23 --> Security Class Initialized
DEBUG - 2018-03-12 22:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:46:23 --> CSRF cookie sent
INFO - 2018-03-12 22:46:23 --> Input Class Initialized
INFO - 2018-03-12 22:46:23 --> Language Class Initialized
ERROR - 2018-03-12 22:46:23 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:47:47 --> Config Class Initialized
INFO - 2018-03-12 22:47:47 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:47:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:47:47 --> Utf8 Class Initialized
INFO - 2018-03-12 22:47:47 --> URI Class Initialized
INFO - 2018-03-12 22:47:47 --> Router Class Initialized
INFO - 2018-03-12 22:47:47 --> Output Class Initialized
INFO - 2018-03-12 22:47:47 --> Security Class Initialized
DEBUG - 2018-03-12 22:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:47:47 --> CSRF cookie sent
INFO - 2018-03-12 22:47:47 --> Input Class Initialized
INFO - 2018-03-12 22:47:47 --> Language Class Initialized
INFO - 2018-03-12 22:47:47 --> Loader Class Initialized
INFO - 2018-03-12 22:47:47 --> Helper loaded: url_helper
INFO - 2018-03-12 22:47:47 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:47:47 --> User Agent Class Initialized
INFO - 2018-03-12 22:47:47 --> Controller Class Initialized
INFO - 2018-03-12 22:47:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:47:47 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:47:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:47:47 --> Final output sent to browser
DEBUG - 2018-03-12 22:47:47 --> Total execution time: 0.2354
INFO - 2018-03-12 22:47:47 --> Config Class Initialized
INFO - 2018-03-12 22:47:47 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:47:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:47:47 --> Utf8 Class Initialized
INFO - 2018-03-12 22:47:47 --> URI Class Initialized
INFO - 2018-03-12 22:47:47 --> Router Class Initialized
INFO - 2018-03-12 22:47:47 --> Output Class Initialized
INFO - 2018-03-12 22:47:47 --> Security Class Initialized
DEBUG - 2018-03-12 22:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:47:47 --> CSRF cookie sent
INFO - 2018-03-12 22:47:47 --> Input Class Initialized
INFO - 2018-03-12 22:47:47 --> Language Class Initialized
ERROR - 2018-03-12 22:47:47 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:47:47 --> Config Class Initialized
INFO - 2018-03-12 22:47:47 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:47:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:47:47 --> Utf8 Class Initialized
INFO - 2018-03-12 22:47:47 --> URI Class Initialized
INFO - 2018-03-12 22:47:47 --> Router Class Initialized
INFO - 2018-03-12 22:47:47 --> Output Class Initialized
INFO - 2018-03-12 22:47:47 --> Security Class Initialized
DEBUG - 2018-03-12 22:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:47:47 --> CSRF cookie sent
INFO - 2018-03-12 22:47:47 --> Input Class Initialized
INFO - 2018-03-12 22:47:47 --> Language Class Initialized
ERROR - 2018-03-12 22:47:47 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:48:18 --> Config Class Initialized
INFO - 2018-03-12 22:48:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:18 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:18 --> URI Class Initialized
INFO - 2018-03-12 22:48:18 --> Router Class Initialized
INFO - 2018-03-12 22:48:18 --> Output Class Initialized
INFO - 2018-03-12 22:48:18 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:18 --> CSRF cookie sent
INFO - 2018-03-12 22:48:18 --> Input Class Initialized
INFO - 2018-03-12 22:48:18 --> Language Class Initialized
INFO - 2018-03-12 22:48:18 --> Loader Class Initialized
INFO - 2018-03-12 22:48:18 --> Helper loaded: url_helper
INFO - 2018-03-12 22:48:18 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:48:18 --> User Agent Class Initialized
INFO - 2018-03-12 22:48:18 --> Controller Class Initialized
INFO - 2018-03-12 22:48:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:48:18 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:48:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:48:18 --> Final output sent to browser
DEBUG - 2018-03-12 22:48:18 --> Total execution time: 0.2232
INFO - 2018-03-12 22:48:18 --> Config Class Initialized
INFO - 2018-03-12 22:48:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:18 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:18 --> URI Class Initialized
INFO - 2018-03-12 22:48:18 --> Router Class Initialized
INFO - 2018-03-12 22:48:18 --> Output Class Initialized
INFO - 2018-03-12 22:48:18 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:18 --> CSRF cookie sent
INFO - 2018-03-12 22:48:18 --> Input Class Initialized
INFO - 2018-03-12 22:48:18 --> Language Class Initialized
ERROR - 2018-03-12 22:48:18 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:48:18 --> Config Class Initialized
INFO - 2018-03-12 22:48:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:18 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:18 --> URI Class Initialized
INFO - 2018-03-12 22:48:18 --> Router Class Initialized
INFO - 2018-03-12 22:48:18 --> Output Class Initialized
INFO - 2018-03-12 22:48:18 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:18 --> CSRF cookie sent
INFO - 2018-03-12 22:48:18 --> Input Class Initialized
INFO - 2018-03-12 22:48:18 --> Language Class Initialized
ERROR - 2018-03-12 22:48:18 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:48:58 --> Config Class Initialized
INFO - 2018-03-12 22:48:58 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:58 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:58 --> URI Class Initialized
INFO - 2018-03-12 22:48:58 --> Router Class Initialized
INFO - 2018-03-12 22:48:58 --> Output Class Initialized
INFO - 2018-03-12 22:48:58 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:58 --> CSRF cookie sent
INFO - 2018-03-12 22:48:58 --> Input Class Initialized
INFO - 2018-03-12 22:48:58 --> Language Class Initialized
INFO - 2018-03-12 22:48:58 --> Loader Class Initialized
INFO - 2018-03-12 22:48:58 --> Helper loaded: url_helper
INFO - 2018-03-12 22:48:58 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:48:58 --> User Agent Class Initialized
INFO - 2018-03-12 22:48:58 --> Controller Class Initialized
INFO - 2018-03-12 22:48:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:48:58 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:48:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:48:58 --> Final output sent to browser
DEBUG - 2018-03-12 22:48:58 --> Total execution time: 0.1959
INFO - 2018-03-12 22:48:58 --> Config Class Initialized
INFO - 2018-03-12 22:48:58 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:58 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:58 --> URI Class Initialized
INFO - 2018-03-12 22:48:58 --> Router Class Initialized
INFO - 2018-03-12 22:48:58 --> Output Class Initialized
INFO - 2018-03-12 22:48:58 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:58 --> CSRF cookie sent
INFO - 2018-03-12 22:48:58 --> Input Class Initialized
INFO - 2018-03-12 22:48:58 --> Language Class Initialized
ERROR - 2018-03-12 22:48:58 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:48:58 --> Config Class Initialized
INFO - 2018-03-12 22:48:58 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:48:58 --> Utf8 Class Initialized
INFO - 2018-03-12 22:48:58 --> URI Class Initialized
INFO - 2018-03-12 22:48:58 --> Router Class Initialized
INFO - 2018-03-12 22:48:58 --> Output Class Initialized
INFO - 2018-03-12 22:48:58 --> Security Class Initialized
DEBUG - 2018-03-12 22:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:48:58 --> CSRF cookie sent
INFO - 2018-03-12 22:48:58 --> Input Class Initialized
INFO - 2018-03-12 22:48:58 --> Language Class Initialized
ERROR - 2018-03-12 22:48:58 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:49:02 --> Config Class Initialized
INFO - 2018-03-12 22:49:02 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:02 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:02 --> URI Class Initialized
INFO - 2018-03-12 22:49:02 --> Router Class Initialized
INFO - 2018-03-12 22:49:02 --> Output Class Initialized
INFO - 2018-03-12 22:49:02 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:02 --> CSRF cookie sent
INFO - 2018-03-12 22:49:02 --> Input Class Initialized
INFO - 2018-03-12 22:49:02 --> Language Class Initialized
INFO - 2018-03-12 22:49:02 --> Loader Class Initialized
INFO - 2018-03-12 22:49:02 --> Helper loaded: url_helper
INFO - 2018-03-12 22:49:02 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:49:03 --> User Agent Class Initialized
INFO - 2018-03-12 22:49:03 --> Controller Class Initialized
INFO - 2018-03-12 22:49:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:49:03 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-12 22:49:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:49:03 --> Final output sent to browser
DEBUG - 2018-03-12 22:49:03 --> Total execution time: 0.2067
INFO - 2018-03-12 22:49:03 --> Config Class Initialized
INFO - 2018-03-12 22:49:03 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:03 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:03 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:03 --> URI Class Initialized
INFO - 2018-03-12 22:49:03 --> Router Class Initialized
INFO - 2018-03-12 22:49:03 --> Output Class Initialized
INFO - 2018-03-12 22:49:03 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:03 --> CSRF cookie sent
INFO - 2018-03-12 22:49:03 --> Input Class Initialized
INFO - 2018-03-12 22:49:03 --> Language Class Initialized
ERROR - 2018-03-12 22:49:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:49:03 --> Config Class Initialized
INFO - 2018-03-12 22:49:03 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:03 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:03 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:03 --> URI Class Initialized
INFO - 2018-03-12 22:49:03 --> Router Class Initialized
INFO - 2018-03-12 22:49:03 --> Output Class Initialized
INFO - 2018-03-12 22:49:03 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:03 --> CSRF cookie sent
INFO - 2018-03-12 22:49:03 --> Input Class Initialized
INFO - 2018-03-12 22:49:03 --> Language Class Initialized
ERROR - 2018-03-12 22:49:03 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:49:49 --> Config Class Initialized
INFO - 2018-03-12 22:49:49 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:49 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:49 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:49 --> URI Class Initialized
INFO - 2018-03-12 22:49:49 --> Router Class Initialized
INFO - 2018-03-12 22:49:49 --> Output Class Initialized
INFO - 2018-03-12 22:49:49 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:49 --> CSRF cookie sent
INFO - 2018-03-12 22:49:49 --> Input Class Initialized
INFO - 2018-03-12 22:49:49 --> Language Class Initialized
INFO - 2018-03-12 22:49:49 --> Loader Class Initialized
INFO - 2018-03-12 22:49:49 --> Helper loaded: url_helper
INFO - 2018-03-12 22:49:49 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:49:49 --> User Agent Class Initialized
INFO - 2018-03-12 22:49:49 --> Controller Class Initialized
INFO - 2018-03-12 22:49:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:49:49 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-12 22:49:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:49:49 --> Final output sent to browser
DEBUG - 2018-03-12 22:49:49 --> Total execution time: 0.1991
INFO - 2018-03-12 22:49:49 --> Config Class Initialized
INFO - 2018-03-12 22:49:49 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:49 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:49 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:49 --> URI Class Initialized
INFO - 2018-03-12 22:49:49 --> Router Class Initialized
INFO - 2018-03-12 22:49:49 --> Output Class Initialized
INFO - 2018-03-12 22:49:49 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:49 --> CSRF cookie sent
INFO - 2018-03-12 22:49:49 --> Input Class Initialized
INFO - 2018-03-12 22:49:49 --> Language Class Initialized
ERROR - 2018-03-12 22:49:49 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:49:49 --> Config Class Initialized
INFO - 2018-03-12 22:49:49 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:49:49 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:49:49 --> Utf8 Class Initialized
INFO - 2018-03-12 22:49:49 --> URI Class Initialized
INFO - 2018-03-12 22:49:49 --> Router Class Initialized
INFO - 2018-03-12 22:49:49 --> Output Class Initialized
INFO - 2018-03-12 22:49:49 --> Security Class Initialized
DEBUG - 2018-03-12 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:49:49 --> CSRF cookie sent
INFO - 2018-03-12 22:49:49 --> Input Class Initialized
INFO - 2018-03-12 22:49:49 --> Language Class Initialized
ERROR - 2018-03-12 22:49:49 --> 404 Page Not Found: Assets/css
INFO - 2018-03-12 22:50:46 --> Config Class Initialized
INFO - 2018-03-12 22:50:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:50:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:50:46 --> Utf8 Class Initialized
INFO - 2018-03-12 22:50:46 --> URI Class Initialized
INFO - 2018-03-12 22:50:46 --> Router Class Initialized
INFO - 2018-03-12 22:50:46 --> Output Class Initialized
INFO - 2018-03-12 22:50:46 --> Security Class Initialized
DEBUG - 2018-03-12 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:50:46 --> CSRF cookie sent
INFO - 2018-03-12 22:50:46 --> Input Class Initialized
INFO - 2018-03-12 22:50:46 --> Language Class Initialized
INFO - 2018-03-12 22:50:46 --> Loader Class Initialized
INFO - 2018-03-12 22:50:46 --> Helper loaded: url_helper
INFO - 2018-03-12 22:50:46 --> Helper loaded: form_helper
DEBUG - 2018-03-12 22:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 22:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 22:50:46 --> User Agent Class Initialized
INFO - 2018-03-12 22:50:46 --> Controller Class Initialized
INFO - 2018-03-12 22:50:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-12 22:50:46 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-12 22:50:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-12 22:50:46 --> Final output sent to browser
DEBUG - 2018-03-12 22:50:46 --> Total execution time: 0.2012
INFO - 2018-03-12 22:50:46 --> Config Class Initialized
INFO - 2018-03-12 22:50:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:50:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:50:46 --> Utf8 Class Initialized
INFO - 2018-03-12 22:50:46 --> URI Class Initialized
INFO - 2018-03-12 22:50:46 --> Router Class Initialized
INFO - 2018-03-12 22:50:46 --> Output Class Initialized
INFO - 2018-03-12 22:50:46 --> Security Class Initialized
DEBUG - 2018-03-12 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:50:46 --> CSRF cookie sent
INFO - 2018-03-12 22:50:46 --> Input Class Initialized
INFO - 2018-03-12 22:50:46 --> Language Class Initialized
ERROR - 2018-03-12 22:50:46 --> 404 Page Not Found: Assets/images
INFO - 2018-03-12 22:50:46 --> Config Class Initialized
INFO - 2018-03-12 22:50:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 22:50:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 22:50:46 --> Utf8 Class Initialized
INFO - 2018-03-12 22:50:46 --> URI Class Initialized
INFO - 2018-03-12 22:50:46 --> Router Class Initialized
INFO - 2018-03-12 22:50:46 --> Output Class Initialized
INFO - 2018-03-12 22:50:46 --> Security Class Initialized
DEBUG - 2018-03-12 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 22:50:46 --> CSRF cookie sent
INFO - 2018-03-12 22:50:46 --> Input Class Initialized
INFO - 2018-03-12 22:50:46 --> Language Class Initialized
ERROR - 2018-03-12 22:50:46 --> 404 Page Not Found: Assets/css

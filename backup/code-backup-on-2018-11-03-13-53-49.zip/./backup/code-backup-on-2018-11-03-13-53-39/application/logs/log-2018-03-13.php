<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-13 00:06:13 --> Config Class Initialized
INFO - 2018-03-13 00:06:13 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:06:13 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:06:13 --> Utf8 Class Initialized
INFO - 2018-03-13 00:06:13 --> URI Class Initialized
INFO - 2018-03-13 00:06:13 --> Router Class Initialized
INFO - 2018-03-13 00:06:13 --> Output Class Initialized
INFO - 2018-03-13 00:06:13 --> Security Class Initialized
DEBUG - 2018-03-13 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:06:13 --> CSRF cookie sent
INFO - 2018-03-13 00:06:13 --> Input Class Initialized
INFO - 2018-03-13 00:06:13 --> Language Class Initialized
INFO - 2018-03-13 00:06:13 --> Loader Class Initialized
INFO - 2018-03-13 00:06:13 --> Helper loaded: url_helper
INFO - 2018-03-13 00:06:13 --> Helper loaded: form_helper
DEBUG - 2018-03-13 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 00:06:13 --> User Agent Class Initialized
INFO - 2018-03-13 00:06:13 --> Controller Class Initialized
INFO - 2018-03-13 00:06:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-13 00:06:13 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-13 00:06:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-13 00:06:13 --> Final output sent to browser
DEBUG - 2018-03-13 00:06:13 --> Total execution time: 0.1955
INFO - 2018-03-13 00:06:13 --> Config Class Initialized
INFO - 2018-03-13 00:06:13 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:06:13 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:06:13 --> Utf8 Class Initialized
INFO - 2018-03-13 00:06:13 --> URI Class Initialized
INFO - 2018-03-13 00:06:13 --> Router Class Initialized
INFO - 2018-03-13 00:06:13 --> Output Class Initialized
INFO - 2018-03-13 00:06:13 --> Security Class Initialized
DEBUG - 2018-03-13 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:06:13 --> CSRF cookie sent
INFO - 2018-03-13 00:06:13 --> Input Class Initialized
INFO - 2018-03-13 00:06:13 --> Language Class Initialized
ERROR - 2018-03-13 00:06:13 --> 404 Page Not Found: Assets/images
INFO - 2018-03-13 00:06:38 --> Config Class Initialized
INFO - 2018-03-13 00:06:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:06:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:06:38 --> Utf8 Class Initialized
INFO - 2018-03-13 00:06:38 --> URI Class Initialized
INFO - 2018-03-13 00:06:38 --> Router Class Initialized
INFO - 2018-03-13 00:06:38 --> Output Class Initialized
INFO - 2018-03-13 00:06:38 --> Security Class Initialized
DEBUG - 2018-03-13 00:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:06:38 --> CSRF cookie sent
INFO - 2018-03-13 00:06:38 --> Input Class Initialized
INFO - 2018-03-13 00:06:38 --> Language Class Initialized
ERROR - 2018-03-13 00:06:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-13 00:07:55 --> Config Class Initialized
INFO - 2018-03-13 00:07:55 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:07:55 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:07:55 --> Utf8 Class Initialized
INFO - 2018-03-13 00:07:55 --> URI Class Initialized
INFO - 2018-03-13 00:07:55 --> Router Class Initialized
INFO - 2018-03-13 00:07:55 --> Output Class Initialized
INFO - 2018-03-13 00:07:55 --> Security Class Initialized
DEBUG - 2018-03-13 00:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:07:55 --> CSRF cookie sent
INFO - 2018-03-13 00:07:55 --> Input Class Initialized
INFO - 2018-03-13 00:07:55 --> Language Class Initialized
INFO - 2018-03-13 00:07:55 --> Loader Class Initialized
INFO - 2018-03-13 00:07:55 --> Helper loaded: url_helper
INFO - 2018-03-13 00:07:55 --> Helper loaded: form_helper
DEBUG - 2018-03-13 00:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 00:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 00:07:55 --> User Agent Class Initialized
INFO - 2018-03-13 00:07:55 --> Controller Class Initialized
INFO - 2018-03-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\test1.php
INFO - 2018-03-13 00:07:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-13 00:07:55 --> Final output sent to browser
DEBUG - 2018-03-13 00:07:55 --> Total execution time: 0.1768
INFO - 2018-03-13 00:07:55 --> Config Class Initialized
INFO - 2018-03-13 00:07:55 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:07:55 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:07:55 --> Utf8 Class Initialized
INFO - 2018-03-13 00:07:55 --> URI Class Initialized
INFO - 2018-03-13 00:07:55 --> Router Class Initialized
INFO - 2018-03-13 00:07:55 --> Output Class Initialized
INFO - 2018-03-13 00:07:55 --> Security Class Initialized
DEBUG - 2018-03-13 00:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:07:55 --> CSRF cookie sent
INFO - 2018-03-13 00:07:55 --> Input Class Initialized
INFO - 2018-03-13 00:07:55 --> Language Class Initialized
ERROR - 2018-03-13 00:07:55 --> 404 Page Not Found: Assets/images
INFO - 2018-03-13 00:07:55 --> Config Class Initialized
INFO - 2018-03-13 00:07:55 --> Hooks Class Initialized
DEBUG - 2018-03-13 00:07:55 --> UTF-8 Support Enabled
INFO - 2018-03-13 00:07:55 --> Utf8 Class Initialized
INFO - 2018-03-13 00:07:55 --> URI Class Initialized
INFO - 2018-03-13 00:07:55 --> Router Class Initialized
INFO - 2018-03-13 00:07:56 --> Output Class Initialized
INFO - 2018-03-13 00:07:56 --> Security Class Initialized
DEBUG - 2018-03-13 00:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 00:07:56 --> CSRF cookie sent
INFO - 2018-03-13 00:07:56 --> Input Class Initialized
INFO - 2018-03-13 00:07:56 --> Language Class Initialized
ERROR - 2018-03-13 00:07:56 --> 404 Page Not Found: Assets/css
INFO - 2018-03-13 17:59:15 --> Config Class Initialized
INFO - 2018-03-13 17:59:15 --> Hooks Class Initialized
DEBUG - 2018-03-13 17:59:15 --> UTF-8 Support Enabled
INFO - 2018-03-13 17:59:15 --> Utf8 Class Initialized
INFO - 2018-03-13 17:59:15 --> URI Class Initialized
INFO - 2018-03-13 17:59:15 --> Router Class Initialized
INFO - 2018-03-13 17:59:15 --> Output Class Initialized
INFO - 2018-03-13 17:59:15 --> Security Class Initialized
DEBUG - 2018-03-13 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 17:59:15 --> CSRF cookie sent
INFO - 2018-03-13 17:59:15 --> Input Class Initialized
INFO - 2018-03-13 17:59:15 --> Language Class Initialized
INFO - 2018-03-13 17:59:15 --> Loader Class Initialized
INFO - 2018-03-13 17:59:15 --> Helper loaded: url_helper
INFO - 2018-03-13 17:59:15 --> Helper loaded: form_helper
DEBUG - 2018-03-13 17:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:59:15 --> User Agent Class Initialized
INFO - 2018-03-13 17:59:15 --> Controller Class Initialized
INFO - 2018-03-13 17:59:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-13 17:59:15 --> File loaded: E:\www\yacopoo\application\views\test.php
INFO - 2018-03-13 17:59:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-13 17:59:15 --> Final output sent to browser
DEBUG - 2018-03-13 17:59:15 --> Total execution time: 0.5531
INFO - 2018-03-13 17:59:15 --> Config Class Initialized
INFO - 2018-03-13 17:59:15 --> Hooks Class Initialized
DEBUG - 2018-03-13 17:59:15 --> UTF-8 Support Enabled
INFO - 2018-03-13 17:59:15 --> Utf8 Class Initialized
INFO - 2018-03-13 17:59:15 --> URI Class Initialized
INFO - 2018-03-13 17:59:15 --> Router Class Initialized
INFO - 2018-03-13 17:59:15 --> Output Class Initialized
INFO - 2018-03-13 17:59:15 --> Security Class Initialized
DEBUG - 2018-03-13 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 17:59:15 --> CSRF cookie sent
INFO - 2018-03-13 17:59:15 --> Input Class Initialized
INFO - 2018-03-13 17:59:15 --> Language Class Initialized
ERROR - 2018-03-13 17:59:15 --> 404 Page Not Found: Assets/images
INFO - 2018-03-13 17:59:19 --> Config Class Initialized
INFO - 2018-03-13 17:59:19 --> Hooks Class Initialized
DEBUG - 2018-03-13 17:59:19 --> UTF-8 Support Enabled
INFO - 2018-03-13 17:59:19 --> Utf8 Class Initialized
INFO - 2018-03-13 17:59:19 --> URI Class Initialized
INFO - 2018-03-13 17:59:19 --> Router Class Initialized
INFO - 2018-03-13 17:59:19 --> Output Class Initialized
INFO - 2018-03-13 17:59:19 --> Security Class Initialized
DEBUG - 2018-03-13 17:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 17:59:19 --> CSRF cookie sent
INFO - 2018-03-13 17:59:19 --> Input Class Initialized
INFO - 2018-03-13 17:59:19 --> Language Class Initialized
ERROR - 2018-03-13 17:59:19 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-19 16:00:02 --> Config Class Initialized
INFO - 2018-03-19 16:00:02 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:00:02 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:00:02 --> Utf8 Class Initialized
INFO - 2018-03-19 16:00:02 --> URI Class Initialized
INFO - 2018-03-19 16:00:02 --> Router Class Initialized
INFO - 2018-03-19 16:00:02 --> Output Class Initialized
INFO - 2018-03-19 16:00:02 --> Security Class Initialized
DEBUG - 2018-03-19 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:00:02 --> CSRF cookie sent
INFO - 2018-03-19 16:00:02 --> Input Class Initialized
INFO - 2018-03-19 16:00:02 --> Language Class Initialized
INFO - 2018-03-19 16:00:02 --> Loader Class Initialized
INFO - 2018-03-19 16:00:03 --> Helper loaded: url_helper
INFO - 2018-03-19 16:00:03 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:00:03 --> User Agent Class Initialized
INFO - 2018-03-19 16:00:03 --> Controller Class Initialized
INFO - 2018-03-19 16:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:00:03 --> File loaded: E:\www\yacopoo\application\views\lawyer.php
INFO - 2018-03-19 16:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:00:03 --> Final output sent to browser
DEBUG - 2018-03-19 16:00:03 --> Total execution time: 0.7150
INFO - 2018-03-19 16:00:03 --> Config Class Initialized
INFO - 2018-03-19 16:00:03 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:00:03 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:00:03 --> Utf8 Class Initialized
INFO - 2018-03-19 16:00:03 --> URI Class Initialized
INFO - 2018-03-19 16:00:03 --> Router Class Initialized
INFO - 2018-03-19 16:00:03 --> Output Class Initialized
INFO - 2018-03-19 16:00:03 --> Security Class Initialized
DEBUG - 2018-03-19 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:00:03 --> CSRF cookie sent
INFO - 2018-03-19 16:00:03 --> Input Class Initialized
INFO - 2018-03-19 16:00:03 --> Language Class Initialized
ERROR - 2018-03-19 16:00:03 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:00:20 --> Config Class Initialized
INFO - 2018-03-19 16:00:20 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:00:20 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:00:20 --> Utf8 Class Initialized
INFO - 2018-03-19 16:00:20 --> URI Class Initialized
INFO - 2018-03-19 16:00:20 --> Router Class Initialized
INFO - 2018-03-19 16:00:20 --> Output Class Initialized
INFO - 2018-03-19 16:00:20 --> Security Class Initialized
DEBUG - 2018-03-19 16:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:00:20 --> CSRF cookie sent
INFO - 2018-03-19 16:00:20 --> Input Class Initialized
INFO - 2018-03-19 16:00:20 --> Language Class Initialized
INFO - 2018-03-19 16:00:20 --> Loader Class Initialized
INFO - 2018-03-19 16:00:20 --> Helper loaded: url_helper
INFO - 2018-03-19 16:00:20 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:00:20 --> User Agent Class Initialized
INFO - 2018-03-19 16:00:20 --> Controller Class Initialized
INFO - 2018-03-19 16:00:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:00:20 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:00:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:00:20 --> Final output sent to browser
DEBUG - 2018-03-19 16:00:20 --> Total execution time: 0.2443
INFO - 2018-03-19 16:00:20 --> Config Class Initialized
INFO - 2018-03-19 16:00:20 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:00:20 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:00:20 --> Utf8 Class Initialized
INFO - 2018-03-19 16:00:20 --> URI Class Initialized
INFO - 2018-03-19 16:00:20 --> Router Class Initialized
INFO - 2018-03-19 16:00:20 --> Output Class Initialized
INFO - 2018-03-19 16:00:20 --> Security Class Initialized
DEBUG - 2018-03-19 16:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:00:20 --> CSRF cookie sent
INFO - 2018-03-19 16:00:20 --> Input Class Initialized
INFO - 2018-03-19 16:00:20 --> Language Class Initialized
ERROR - 2018-03-19 16:00:20 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:09:58 --> Config Class Initialized
INFO - 2018-03-19 16:09:58 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:09:58 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:09:58 --> Utf8 Class Initialized
INFO - 2018-03-19 16:09:58 --> URI Class Initialized
INFO - 2018-03-19 16:09:58 --> Router Class Initialized
INFO - 2018-03-19 16:09:58 --> Output Class Initialized
INFO - 2018-03-19 16:09:58 --> Security Class Initialized
DEBUG - 2018-03-19 16:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:09:58 --> CSRF cookie sent
INFO - 2018-03-19 16:09:58 --> Input Class Initialized
INFO - 2018-03-19 16:09:58 --> Language Class Initialized
INFO - 2018-03-19 16:09:58 --> Loader Class Initialized
INFO - 2018-03-19 16:09:58 --> Helper loaded: url_helper
INFO - 2018-03-19 16:09:58 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:09:58 --> User Agent Class Initialized
INFO - 2018-03-19 16:09:58 --> Controller Class Initialized
INFO - 2018-03-19 16:09:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:09:58 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:09:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:09:58 --> Final output sent to browser
DEBUG - 2018-03-19 16:09:58 --> Total execution time: 0.1808
INFO - 2018-03-19 16:09:58 --> Config Class Initialized
INFO - 2018-03-19 16:09:58 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:09:58 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:09:58 --> Utf8 Class Initialized
INFO - 2018-03-19 16:09:58 --> URI Class Initialized
INFO - 2018-03-19 16:09:58 --> Router Class Initialized
INFO - 2018-03-19 16:09:58 --> Output Class Initialized
INFO - 2018-03-19 16:09:58 --> Security Class Initialized
DEBUG - 2018-03-19 16:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:09:58 --> CSRF cookie sent
INFO - 2018-03-19 16:09:58 --> Input Class Initialized
INFO - 2018-03-19 16:09:58 --> Language Class Initialized
ERROR - 2018-03-19 16:09:58 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:12:55 --> Config Class Initialized
INFO - 2018-03-19 16:12:55 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:12:55 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:12:55 --> Utf8 Class Initialized
INFO - 2018-03-19 16:12:55 --> URI Class Initialized
INFO - 2018-03-19 16:12:55 --> Router Class Initialized
INFO - 2018-03-19 16:12:55 --> Output Class Initialized
INFO - 2018-03-19 16:12:55 --> Security Class Initialized
DEBUG - 2018-03-19 16:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:12:55 --> CSRF cookie sent
INFO - 2018-03-19 16:12:55 --> Input Class Initialized
INFO - 2018-03-19 16:12:55 --> Language Class Initialized
ERROR - 2018-03-19 16:12:55 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:13:32 --> Config Class Initialized
INFO - 2018-03-19 16:13:32 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:13:32 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:32 --> Utf8 Class Initialized
INFO - 2018-03-19 16:13:32 --> URI Class Initialized
INFO - 2018-03-19 16:13:32 --> Router Class Initialized
INFO - 2018-03-19 16:13:32 --> Output Class Initialized
INFO - 2018-03-19 16:13:32 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:32 --> CSRF cookie sent
INFO - 2018-03-19 16:13:32 --> Input Class Initialized
INFO - 2018-03-19 16:13:32 --> Language Class Initialized
INFO - 2018-03-19 16:13:32 --> Loader Class Initialized
INFO - 2018-03-19 16:13:32 --> Helper loaded: url_helper
INFO - 2018-03-19 16:13:32 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:13:32 --> User Agent Class Initialized
INFO - 2018-03-19 16:13:32 --> Controller Class Initialized
INFO - 2018-03-19 16:13:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:13:32 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:13:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:13:32 --> Final output sent to browser
DEBUG - 2018-03-19 16:13:33 --> Total execution time: 0.1897
INFO - 2018-03-19 16:13:33 --> Config Class Initialized
INFO - 2018-03-19 16:13:33 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:13:33 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:33 --> Utf8 Class Initialized
INFO - 2018-03-19 16:13:33 --> URI Class Initialized
INFO - 2018-03-19 16:13:33 --> Router Class Initialized
INFO - 2018-03-19 16:13:33 --> Config Class Initialized
INFO - 2018-03-19 16:13:33 --> Hooks Class Initialized
INFO - 2018-03-19 16:13:33 --> Output Class Initialized
INFO - 2018-03-19 16:13:33 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:33 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:33 --> Utf8 Class Initialized
DEBUG - 2018-03-19 16:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:33 --> CSRF cookie sent
INFO - 2018-03-19 16:13:33 --> URI Class Initialized
INFO - 2018-03-19 16:13:33 --> Input Class Initialized
INFO - 2018-03-19 16:13:33 --> Router Class Initialized
INFO - 2018-03-19 16:13:33 --> Language Class Initialized
INFO - 2018-03-19 16:13:33 --> Output Class Initialized
ERROR - 2018-03-19 16:13:33 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:13:33 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:33 --> CSRF cookie sent
INFO - 2018-03-19 16:13:33 --> Input Class Initialized
INFO - 2018-03-19 16:13:33 --> Language Class Initialized
ERROR - 2018-03-19 16:13:33 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:13:49 --> Config Class Initialized
INFO - 2018-03-19 16:13:49 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:13:49 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:49 --> Utf8 Class Initialized
INFO - 2018-03-19 16:13:49 --> URI Class Initialized
INFO - 2018-03-19 16:13:49 --> Router Class Initialized
INFO - 2018-03-19 16:13:49 --> Output Class Initialized
INFO - 2018-03-19 16:13:49 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:49 --> CSRF cookie sent
INFO - 2018-03-19 16:13:49 --> Input Class Initialized
INFO - 2018-03-19 16:13:49 --> Language Class Initialized
INFO - 2018-03-19 16:13:49 --> Loader Class Initialized
INFO - 2018-03-19 16:13:49 --> Helper loaded: url_helper
INFO - 2018-03-19 16:13:49 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:13:49 --> User Agent Class Initialized
INFO - 2018-03-19 16:13:49 --> Controller Class Initialized
INFO - 2018-03-19 16:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:13:49 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:13:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:13:49 --> Final output sent to browser
DEBUG - 2018-03-19 16:13:49 --> Total execution time: 0.1904
INFO - 2018-03-19 16:13:49 --> Config Class Initialized
INFO - 2018-03-19 16:13:49 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:13:49 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:49 --> Utf8 Class Initialized
INFO - 2018-03-19 16:13:49 --> URI Class Initialized
INFO - 2018-03-19 16:13:49 --> Router Class Initialized
INFO - 2018-03-19 16:13:49 --> Output Class Initialized
INFO - 2018-03-19 16:13:49 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:49 --> CSRF cookie sent
INFO - 2018-03-19 16:13:49 --> Input Class Initialized
INFO - 2018-03-19 16:13:49 --> Language Class Initialized
ERROR - 2018-03-19 16:13:49 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:13:49 --> Config Class Initialized
INFO - 2018-03-19 16:13:49 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:13:49 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:13:49 --> Utf8 Class Initialized
INFO - 2018-03-19 16:13:49 --> URI Class Initialized
INFO - 2018-03-19 16:13:49 --> Router Class Initialized
INFO - 2018-03-19 16:13:49 --> Output Class Initialized
INFO - 2018-03-19 16:13:49 --> Security Class Initialized
DEBUG - 2018-03-19 16:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:13:50 --> CSRF cookie sent
INFO - 2018-03-19 16:13:50 --> Input Class Initialized
INFO - 2018-03-19 16:13:50 --> Language Class Initialized
ERROR - 2018-03-19 16:13:50 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:14:19 --> Config Class Initialized
INFO - 2018-03-19 16:14:19 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:19 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:19 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:19 --> URI Class Initialized
INFO - 2018-03-19 16:14:19 --> Router Class Initialized
INFO - 2018-03-19 16:14:19 --> Output Class Initialized
INFO - 2018-03-19 16:14:19 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:19 --> CSRF cookie sent
INFO - 2018-03-19 16:14:19 --> Input Class Initialized
INFO - 2018-03-19 16:14:19 --> Language Class Initialized
INFO - 2018-03-19 16:14:19 --> Loader Class Initialized
INFO - 2018-03-19 16:14:19 --> Helper loaded: url_helper
INFO - 2018-03-19 16:14:19 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:14:19 --> User Agent Class Initialized
INFO - 2018-03-19 16:14:19 --> Controller Class Initialized
INFO - 2018-03-19 16:14:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:14:19 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:14:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:14:19 --> Final output sent to browser
DEBUG - 2018-03-19 16:14:19 --> Total execution time: 0.1934
INFO - 2018-03-19 16:14:19 --> Config Class Initialized
INFO - 2018-03-19 16:14:19 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:19 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:19 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:19 --> URI Class Initialized
INFO - 2018-03-19 16:14:19 --> Router Class Initialized
INFO - 2018-03-19 16:14:19 --> Output Class Initialized
INFO - 2018-03-19 16:14:19 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:19 --> CSRF cookie sent
INFO - 2018-03-19 16:14:19 --> Input Class Initialized
INFO - 2018-03-19 16:14:19 --> Language Class Initialized
ERROR - 2018-03-19 16:14:19 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:14:19 --> Config Class Initialized
INFO - 2018-03-19 16:14:20 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:20 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:20 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:20 --> URI Class Initialized
INFO - 2018-03-19 16:14:20 --> Router Class Initialized
INFO - 2018-03-19 16:14:20 --> Output Class Initialized
INFO - 2018-03-19 16:14:20 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:20 --> CSRF cookie sent
INFO - 2018-03-19 16:14:20 --> Input Class Initialized
INFO - 2018-03-19 16:14:20 --> Language Class Initialized
ERROR - 2018-03-19 16:14:20 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:14:27 --> Config Class Initialized
INFO - 2018-03-19 16:14:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:27 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:27 --> URI Class Initialized
INFO - 2018-03-19 16:14:27 --> Router Class Initialized
INFO - 2018-03-19 16:14:27 --> Output Class Initialized
INFO - 2018-03-19 16:14:27 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:27 --> CSRF cookie sent
INFO - 2018-03-19 16:14:27 --> Input Class Initialized
INFO - 2018-03-19 16:14:27 --> Language Class Initialized
INFO - 2018-03-19 16:14:27 --> Loader Class Initialized
INFO - 2018-03-19 16:14:27 --> Helper loaded: url_helper
INFO - 2018-03-19 16:14:27 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:14:27 --> User Agent Class Initialized
INFO - 2018-03-19 16:14:27 --> Controller Class Initialized
INFO - 2018-03-19 16:14:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:14:27 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:14:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:14:27 --> Final output sent to browser
DEBUG - 2018-03-19 16:14:27 --> Total execution time: 0.1997
INFO - 2018-03-19 16:14:27 --> Config Class Initialized
INFO - 2018-03-19 16:14:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:27 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:27 --> URI Class Initialized
INFO - 2018-03-19 16:14:27 --> Router Class Initialized
INFO - 2018-03-19 16:14:27 --> Output Class Initialized
INFO - 2018-03-19 16:14:27 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:27 --> CSRF cookie sent
INFO - 2018-03-19 16:14:27 --> Input Class Initialized
INFO - 2018-03-19 16:14:27 --> Language Class Initialized
ERROR - 2018-03-19 16:14:27 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:14:27 --> Config Class Initialized
INFO - 2018-03-19 16:14:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:14:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:14:27 --> Utf8 Class Initialized
INFO - 2018-03-19 16:14:27 --> URI Class Initialized
INFO - 2018-03-19 16:14:27 --> Router Class Initialized
INFO - 2018-03-19 16:14:27 --> Output Class Initialized
INFO - 2018-03-19 16:14:27 --> Security Class Initialized
DEBUG - 2018-03-19 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:14:27 --> CSRF cookie sent
INFO - 2018-03-19 16:14:27 --> Input Class Initialized
INFO - 2018-03-19 16:14:27 --> Language Class Initialized
ERROR - 2018-03-19 16:14:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:15:25 --> Config Class Initialized
INFO - 2018-03-19 16:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:15:25 --> Utf8 Class Initialized
INFO - 2018-03-19 16:15:25 --> URI Class Initialized
INFO - 2018-03-19 16:15:25 --> Router Class Initialized
INFO - 2018-03-19 16:15:25 --> Output Class Initialized
INFO - 2018-03-19 16:15:25 --> Security Class Initialized
DEBUG - 2018-03-19 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:15:25 --> CSRF cookie sent
INFO - 2018-03-19 16:15:25 --> Input Class Initialized
INFO - 2018-03-19 16:15:25 --> Language Class Initialized
INFO - 2018-03-19 16:15:25 --> Loader Class Initialized
INFO - 2018-03-19 16:15:25 --> Helper loaded: url_helper
INFO - 2018-03-19 16:15:25 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:15:25 --> User Agent Class Initialized
INFO - 2018-03-19 16:15:25 --> Controller Class Initialized
INFO - 2018-03-19 16:15:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:15:25 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:15:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:15:25 --> Final output sent to browser
DEBUG - 2018-03-19 16:15:25 --> Total execution time: 0.2025
INFO - 2018-03-19 16:15:25 --> Config Class Initialized
INFO - 2018-03-19 16:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:15:25 --> Utf8 Class Initialized
INFO - 2018-03-19 16:15:25 --> URI Class Initialized
INFO - 2018-03-19 16:15:25 --> Router Class Initialized
INFO - 2018-03-19 16:15:25 --> Output Class Initialized
INFO - 2018-03-19 16:15:25 --> Security Class Initialized
DEBUG - 2018-03-19 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:15:25 --> CSRF cookie sent
INFO - 2018-03-19 16:15:25 --> Input Class Initialized
INFO - 2018-03-19 16:15:25 --> Language Class Initialized
ERROR - 2018-03-19 16:15:25 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:15:25 --> Config Class Initialized
INFO - 2018-03-19 16:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:15:26 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:15:26 --> Utf8 Class Initialized
INFO - 2018-03-19 16:15:26 --> URI Class Initialized
INFO - 2018-03-19 16:15:26 --> Router Class Initialized
INFO - 2018-03-19 16:15:26 --> Output Class Initialized
INFO - 2018-03-19 16:15:26 --> Security Class Initialized
DEBUG - 2018-03-19 16:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:15:26 --> CSRF cookie sent
INFO - 2018-03-19 16:15:26 --> Input Class Initialized
INFO - 2018-03-19 16:15:26 --> Language Class Initialized
ERROR - 2018-03-19 16:15:26 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:16:46 --> Config Class Initialized
INFO - 2018-03-19 16:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:16:46 --> Utf8 Class Initialized
INFO - 2018-03-19 16:16:46 --> URI Class Initialized
INFO - 2018-03-19 16:16:46 --> Router Class Initialized
INFO - 2018-03-19 16:16:46 --> Output Class Initialized
INFO - 2018-03-19 16:16:46 --> Security Class Initialized
DEBUG - 2018-03-19 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:16:46 --> CSRF cookie sent
INFO - 2018-03-19 16:16:46 --> Input Class Initialized
INFO - 2018-03-19 16:16:46 --> Language Class Initialized
INFO - 2018-03-19 16:16:46 --> Loader Class Initialized
INFO - 2018-03-19 16:16:46 --> Helper loaded: url_helper
INFO - 2018-03-19 16:16:46 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:16:46 --> User Agent Class Initialized
INFO - 2018-03-19 16:16:46 --> Controller Class Initialized
INFO - 2018-03-19 16:16:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:16:46 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:16:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:16:46 --> Final output sent to browser
DEBUG - 2018-03-19 16:16:46 --> Total execution time: 0.2020
INFO - 2018-03-19 16:16:46 --> Config Class Initialized
INFO - 2018-03-19 16:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:16:46 --> Utf8 Class Initialized
INFO - 2018-03-19 16:16:46 --> URI Class Initialized
INFO - 2018-03-19 16:16:46 --> Router Class Initialized
INFO - 2018-03-19 16:16:46 --> Output Class Initialized
INFO - 2018-03-19 16:16:46 --> Security Class Initialized
DEBUG - 2018-03-19 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:16:46 --> CSRF cookie sent
INFO - 2018-03-19 16:16:46 --> Input Class Initialized
INFO - 2018-03-19 16:16:46 --> Language Class Initialized
ERROR - 2018-03-19 16:16:46 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:16:47 --> Config Class Initialized
INFO - 2018-03-19 16:16:47 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:16:47 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:16:47 --> Utf8 Class Initialized
INFO - 2018-03-19 16:16:47 --> URI Class Initialized
INFO - 2018-03-19 16:16:47 --> Router Class Initialized
INFO - 2018-03-19 16:16:47 --> Output Class Initialized
INFO - 2018-03-19 16:16:47 --> Security Class Initialized
DEBUG - 2018-03-19 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:16:47 --> CSRF cookie sent
INFO - 2018-03-19 16:16:47 --> Input Class Initialized
INFO - 2018-03-19 16:16:47 --> Language Class Initialized
ERROR - 2018-03-19 16:16:47 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:18:25 --> Config Class Initialized
INFO - 2018-03-19 16:18:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:18:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:18:25 --> Utf8 Class Initialized
INFO - 2018-03-19 16:18:25 --> URI Class Initialized
INFO - 2018-03-19 16:18:25 --> Router Class Initialized
INFO - 2018-03-19 16:18:25 --> Output Class Initialized
INFO - 2018-03-19 16:18:25 --> Security Class Initialized
DEBUG - 2018-03-19 16:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:18:25 --> CSRF cookie sent
INFO - 2018-03-19 16:18:25 --> Input Class Initialized
INFO - 2018-03-19 16:18:25 --> Language Class Initialized
INFO - 2018-03-19 16:18:25 --> Loader Class Initialized
INFO - 2018-03-19 16:18:25 --> Helper loaded: url_helper
INFO - 2018-03-19 16:18:25 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:18:25 --> User Agent Class Initialized
INFO - 2018-03-19 16:18:25 --> Controller Class Initialized
INFO - 2018-03-19 16:18:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:18:25 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:18:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:18:25 --> Final output sent to browser
DEBUG - 2018-03-19 16:18:25 --> Total execution time: 0.2118
INFO - 2018-03-19 16:18:25 --> Config Class Initialized
INFO - 2018-03-19 16:18:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:18:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:18:25 --> Utf8 Class Initialized
INFO - 2018-03-19 16:18:25 --> URI Class Initialized
INFO - 2018-03-19 16:18:25 --> Router Class Initialized
INFO - 2018-03-19 16:18:25 --> Output Class Initialized
INFO - 2018-03-19 16:18:25 --> Security Class Initialized
DEBUG - 2018-03-19 16:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:18:25 --> CSRF cookie sent
INFO - 2018-03-19 16:18:25 --> Input Class Initialized
INFO - 2018-03-19 16:18:25 --> Language Class Initialized
ERROR - 2018-03-19 16:18:25 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:18:25 --> Config Class Initialized
INFO - 2018-03-19 16:18:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:18:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:18:25 --> Utf8 Class Initialized
INFO - 2018-03-19 16:18:26 --> URI Class Initialized
INFO - 2018-03-19 16:18:26 --> Router Class Initialized
INFO - 2018-03-19 16:18:26 --> Output Class Initialized
INFO - 2018-03-19 16:18:26 --> Security Class Initialized
DEBUG - 2018-03-19 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:18:26 --> CSRF cookie sent
INFO - 2018-03-19 16:18:26 --> Input Class Initialized
INFO - 2018-03-19 16:18:26 --> Language Class Initialized
ERROR - 2018-03-19 16:18:26 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:20:45 --> Config Class Initialized
INFO - 2018-03-19 16:20:45 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:20:45 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:20:45 --> Utf8 Class Initialized
INFO - 2018-03-19 16:20:45 --> URI Class Initialized
INFO - 2018-03-19 16:20:45 --> Router Class Initialized
INFO - 2018-03-19 16:20:45 --> Output Class Initialized
INFO - 2018-03-19 16:20:45 --> Security Class Initialized
DEBUG - 2018-03-19 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:20:45 --> CSRF cookie sent
INFO - 2018-03-19 16:20:45 --> Input Class Initialized
INFO - 2018-03-19 16:20:45 --> Language Class Initialized
INFO - 2018-03-19 16:20:45 --> Loader Class Initialized
INFO - 2018-03-19 16:20:46 --> Helper loaded: url_helper
INFO - 2018-03-19 16:20:46 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:20:46 --> User Agent Class Initialized
INFO - 2018-03-19 16:20:46 --> Controller Class Initialized
INFO - 2018-03-19 16:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:20:46 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:20:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:20:46 --> Final output sent to browser
DEBUG - 2018-03-19 16:20:46 --> Total execution time: 0.2197
INFO - 2018-03-19 16:20:46 --> Config Class Initialized
INFO - 2018-03-19 16:20:46 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:20:46 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:20:46 --> Utf8 Class Initialized
INFO - 2018-03-19 16:20:46 --> URI Class Initialized
INFO - 2018-03-19 16:20:46 --> Router Class Initialized
INFO - 2018-03-19 16:20:46 --> Output Class Initialized
INFO - 2018-03-19 16:20:46 --> Security Class Initialized
DEBUG - 2018-03-19 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:20:46 --> CSRF cookie sent
INFO - 2018-03-19 16:20:46 --> Input Class Initialized
INFO - 2018-03-19 16:20:46 --> Language Class Initialized
ERROR - 2018-03-19 16:20:46 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:20:46 --> Config Class Initialized
INFO - 2018-03-19 16:20:46 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:20:46 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:20:46 --> Utf8 Class Initialized
INFO - 2018-03-19 16:20:46 --> URI Class Initialized
INFO - 2018-03-19 16:20:46 --> Router Class Initialized
INFO - 2018-03-19 16:20:46 --> Output Class Initialized
INFO - 2018-03-19 16:20:46 --> Security Class Initialized
DEBUG - 2018-03-19 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:20:46 --> CSRF cookie sent
INFO - 2018-03-19 16:20:46 --> Input Class Initialized
INFO - 2018-03-19 16:20:46 --> Language Class Initialized
ERROR - 2018-03-19 16:20:46 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 16:22:04 --> Config Class Initialized
INFO - 2018-03-19 16:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:22:04 --> Utf8 Class Initialized
INFO - 2018-03-19 16:22:04 --> URI Class Initialized
INFO - 2018-03-19 16:22:04 --> Router Class Initialized
INFO - 2018-03-19 16:22:04 --> Output Class Initialized
INFO - 2018-03-19 16:22:04 --> Security Class Initialized
DEBUG - 2018-03-19 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:22:04 --> CSRF cookie sent
INFO - 2018-03-19 16:22:04 --> Input Class Initialized
INFO - 2018-03-19 16:22:04 --> Language Class Initialized
INFO - 2018-03-19 16:22:04 --> Loader Class Initialized
INFO - 2018-03-19 16:22:04 --> Helper loaded: url_helper
INFO - 2018-03-19 16:22:04 --> Helper loaded: form_helper
DEBUG - 2018-03-19 16:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 16:22:04 --> User Agent Class Initialized
INFO - 2018-03-19 16:22:04 --> Controller Class Initialized
INFO - 2018-03-19 16:22:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 16:22:04 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 16:22:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 16:22:04 --> Final output sent to browser
DEBUG - 2018-03-19 16:22:04 --> Total execution time: 0.2316
INFO - 2018-03-19 16:22:04 --> Config Class Initialized
INFO - 2018-03-19 16:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:22:04 --> Utf8 Class Initialized
INFO - 2018-03-19 16:22:04 --> URI Class Initialized
INFO - 2018-03-19 16:22:04 --> Router Class Initialized
INFO - 2018-03-19 16:22:04 --> Output Class Initialized
INFO - 2018-03-19 16:22:04 --> Security Class Initialized
DEBUG - 2018-03-19 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:22:04 --> CSRF cookie sent
INFO - 2018-03-19 16:22:04 --> Input Class Initialized
INFO - 2018-03-19 16:22:04 --> Language Class Initialized
ERROR - 2018-03-19 16:22:04 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 16:22:04 --> Config Class Initialized
INFO - 2018-03-19 16:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-19 16:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-19 16:22:05 --> Utf8 Class Initialized
INFO - 2018-03-19 16:22:05 --> URI Class Initialized
INFO - 2018-03-19 16:22:05 --> Router Class Initialized
INFO - 2018-03-19 16:22:05 --> Output Class Initialized
INFO - 2018-03-19 16:22:05 --> Security Class Initialized
DEBUG - 2018-03-19 16:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 16:22:05 --> CSRF cookie sent
INFO - 2018-03-19 16:22:05 --> Input Class Initialized
INFO - 2018-03-19 16:22:05 --> Language Class Initialized
ERROR - 2018-03-19 16:22:05 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 18:38:33 --> Config Class Initialized
INFO - 2018-03-19 18:38:33 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:38:33 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:38:33 --> Utf8 Class Initialized
INFO - 2018-03-19 18:38:33 --> URI Class Initialized
INFO - 2018-03-19 18:38:33 --> Router Class Initialized
INFO - 2018-03-19 18:38:33 --> Output Class Initialized
INFO - 2018-03-19 18:38:33 --> Security Class Initialized
DEBUG - 2018-03-19 18:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:38:33 --> CSRF cookie sent
INFO - 2018-03-19 18:38:33 --> Input Class Initialized
INFO - 2018-03-19 18:38:33 --> Language Class Initialized
INFO - 2018-03-19 18:38:33 --> Loader Class Initialized
INFO - 2018-03-19 18:38:33 --> Helper loaded: url_helper
INFO - 2018-03-19 18:38:33 --> Helper loaded: form_helper
DEBUG - 2018-03-19 18:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 18:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 18:38:33 --> User Agent Class Initialized
INFO - 2018-03-19 18:38:33 --> Controller Class Initialized
INFO - 2018-03-19 18:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 18:38:33 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-19 18:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 18:38:33 --> Final output sent to browser
DEBUG - 2018-03-19 18:38:33 --> Total execution time: 0.2206
INFO - 2018-03-19 18:38:33 --> Config Class Initialized
INFO - 2018-03-19 18:38:33 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:38:33 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:38:33 --> Utf8 Class Initialized
INFO - 2018-03-19 18:38:33 --> URI Class Initialized
INFO - 2018-03-19 18:38:33 --> Router Class Initialized
INFO - 2018-03-19 18:38:33 --> Output Class Initialized
INFO - 2018-03-19 18:38:33 --> Security Class Initialized
DEBUG - 2018-03-19 18:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:38:33 --> CSRF cookie sent
INFO - 2018-03-19 18:38:33 --> Input Class Initialized
INFO - 2018-03-19 18:38:33 --> Language Class Initialized
ERROR - 2018-03-19 18:38:33 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 18:42:44 --> Config Class Initialized
INFO - 2018-03-19 18:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:42:45 --> Utf8 Class Initialized
INFO - 2018-03-19 18:42:45 --> URI Class Initialized
INFO - 2018-03-19 18:42:45 --> Router Class Initialized
INFO - 2018-03-19 18:42:45 --> Output Class Initialized
INFO - 2018-03-19 18:42:45 --> Security Class Initialized
DEBUG - 2018-03-19 18:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:42:45 --> CSRF cookie sent
INFO - 2018-03-19 18:42:45 --> Input Class Initialized
INFO - 2018-03-19 18:42:45 --> Language Class Initialized
INFO - 2018-03-19 18:42:45 --> Loader Class Initialized
INFO - 2018-03-19 18:42:45 --> Helper loaded: url_helper
INFO - 2018-03-19 18:42:45 --> Helper loaded: form_helper
DEBUG - 2018-03-19 18:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 18:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 18:42:45 --> User Agent Class Initialized
INFO - 2018-03-19 18:42:45 --> Controller Class Initialized
INFO - 2018-03-19 18:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 18:42:45 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-19 18:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 18:42:45 --> Final output sent to browser
DEBUG - 2018-03-19 18:42:45 --> Total execution time: 0.2200
INFO - 2018-03-19 18:42:45 --> Config Class Initialized
INFO - 2018-03-19 18:42:45 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:42:45 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:42:45 --> Utf8 Class Initialized
INFO - 2018-03-19 18:42:45 --> URI Class Initialized
INFO - 2018-03-19 18:42:45 --> Router Class Initialized
INFO - 2018-03-19 18:42:45 --> Output Class Initialized
INFO - 2018-03-19 18:42:45 --> Security Class Initialized
DEBUG - 2018-03-19 18:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:42:45 --> CSRF cookie sent
INFO - 2018-03-19 18:42:45 --> Input Class Initialized
INFO - 2018-03-19 18:42:45 --> Language Class Initialized
ERROR - 2018-03-19 18:42:45 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 18:43:28 --> Config Class Initialized
INFO - 2018-03-19 18:43:28 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:43:28 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:43:28 --> Utf8 Class Initialized
INFO - 2018-03-19 18:43:28 --> URI Class Initialized
INFO - 2018-03-19 18:43:28 --> Router Class Initialized
INFO - 2018-03-19 18:43:28 --> Output Class Initialized
INFO - 2018-03-19 18:43:28 --> Security Class Initialized
DEBUG - 2018-03-19 18:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:43:28 --> CSRF cookie sent
INFO - 2018-03-19 18:43:28 --> Input Class Initialized
INFO - 2018-03-19 18:43:28 --> Language Class Initialized
INFO - 2018-03-19 18:43:28 --> Loader Class Initialized
INFO - 2018-03-19 18:43:28 --> Helper loaded: url_helper
INFO - 2018-03-19 18:43:28 --> Helper loaded: form_helper
DEBUG - 2018-03-19 18:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 18:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 18:43:28 --> User Agent Class Initialized
INFO - 2018-03-19 18:43:28 --> Controller Class Initialized
INFO - 2018-03-19 18:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 18:43:28 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-19 18:43:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 18:43:28 --> Final output sent to browser
DEBUG - 2018-03-19 18:43:28 --> Total execution time: 0.2187
INFO - 2018-03-19 18:43:28 --> Config Class Initialized
INFO - 2018-03-19 18:43:28 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:43:28 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:43:28 --> Utf8 Class Initialized
INFO - 2018-03-19 18:43:28 --> URI Class Initialized
INFO - 2018-03-19 18:43:28 --> Router Class Initialized
INFO - 2018-03-19 18:43:28 --> Output Class Initialized
INFO - 2018-03-19 18:43:28 --> Security Class Initialized
DEBUG - 2018-03-19 18:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:43:28 --> CSRF cookie sent
INFO - 2018-03-19 18:43:28 --> Input Class Initialized
INFO - 2018-03-19 18:43:28 --> Language Class Initialized
ERROR - 2018-03-19 18:43:28 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 18:44:18 --> Config Class Initialized
INFO - 2018-03-19 18:44:18 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:44:18 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:44:18 --> Utf8 Class Initialized
INFO - 2018-03-19 18:44:18 --> URI Class Initialized
INFO - 2018-03-19 18:44:18 --> Router Class Initialized
INFO - 2018-03-19 18:44:18 --> Output Class Initialized
INFO - 2018-03-19 18:44:18 --> Security Class Initialized
DEBUG - 2018-03-19 18:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:44:18 --> CSRF cookie sent
INFO - 2018-03-19 18:44:18 --> Input Class Initialized
INFO - 2018-03-19 18:44:18 --> Language Class Initialized
INFO - 2018-03-19 18:44:18 --> Loader Class Initialized
INFO - 2018-03-19 18:44:18 --> Helper loaded: url_helper
INFO - 2018-03-19 18:44:18 --> Helper loaded: form_helper
DEBUG - 2018-03-19 18:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 18:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 18:44:18 --> User Agent Class Initialized
INFO - 2018-03-19 18:44:18 --> Controller Class Initialized
INFO - 2018-03-19 18:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 18:44:18 --> File loaded: E:\www\yacopoo\application\views\lawyer.php
INFO - 2018-03-19 18:44:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 18:44:18 --> Final output sent to browser
DEBUG - 2018-03-19 18:44:18 --> Total execution time: 0.2162
INFO - 2018-03-19 18:44:18 --> Config Class Initialized
INFO - 2018-03-19 18:44:18 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:44:18 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:44:18 --> Utf8 Class Initialized
INFO - 2018-03-19 18:44:18 --> URI Class Initialized
INFO - 2018-03-19 18:44:18 --> Router Class Initialized
INFO - 2018-03-19 18:44:18 --> Output Class Initialized
INFO - 2018-03-19 18:44:18 --> Security Class Initialized
DEBUG - 2018-03-19 18:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:44:18 --> CSRF cookie sent
INFO - 2018-03-19 18:44:18 --> Input Class Initialized
INFO - 2018-03-19 18:44:18 --> Language Class Initialized
ERROR - 2018-03-19 18:44:18 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 18:46:11 --> Config Class Initialized
INFO - 2018-03-19 18:46:11 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:46:11 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:46:11 --> Utf8 Class Initialized
INFO - 2018-03-19 18:46:11 --> URI Class Initialized
INFO - 2018-03-19 18:46:11 --> Router Class Initialized
INFO - 2018-03-19 18:46:11 --> Output Class Initialized
INFO - 2018-03-19 18:46:11 --> Security Class Initialized
DEBUG - 2018-03-19 18:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:46:11 --> CSRF cookie sent
INFO - 2018-03-19 18:46:11 --> Input Class Initialized
INFO - 2018-03-19 18:46:11 --> Language Class Initialized
INFO - 2018-03-19 18:46:11 --> Loader Class Initialized
INFO - 2018-03-19 18:46:11 --> Helper loaded: url_helper
INFO - 2018-03-19 18:46:11 --> Helper loaded: form_helper
DEBUG - 2018-03-19 18:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 18:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 18:46:11 --> User Agent Class Initialized
INFO - 2018-03-19 18:46:11 --> Controller Class Initialized
INFO - 2018-03-19 18:46:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 18:46:11 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 18:46:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 18:46:11 --> Final output sent to browser
DEBUG - 2018-03-19 18:46:11 --> Total execution time: 0.2154
INFO - 2018-03-19 18:46:11 --> Config Class Initialized
INFO - 2018-03-19 18:46:11 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:46:11 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:46:11 --> Utf8 Class Initialized
INFO - 2018-03-19 18:46:11 --> URI Class Initialized
INFO - 2018-03-19 18:46:11 --> Router Class Initialized
INFO - 2018-03-19 18:46:11 --> Output Class Initialized
INFO - 2018-03-19 18:46:11 --> Security Class Initialized
DEBUG - 2018-03-19 18:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:46:11 --> CSRF cookie sent
INFO - 2018-03-19 18:46:11 --> Input Class Initialized
INFO - 2018-03-19 18:46:11 --> Language Class Initialized
ERROR - 2018-03-19 18:46:11 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 18:46:15 --> Config Class Initialized
INFO - 2018-03-19 18:46:15 --> Hooks Class Initialized
DEBUG - 2018-03-19 18:46:15 --> UTF-8 Support Enabled
INFO - 2018-03-19 18:46:15 --> Utf8 Class Initialized
INFO - 2018-03-19 18:46:15 --> URI Class Initialized
INFO - 2018-03-19 18:46:15 --> Router Class Initialized
INFO - 2018-03-19 18:46:15 --> Output Class Initialized
INFO - 2018-03-19 18:46:15 --> Security Class Initialized
DEBUG - 2018-03-19 18:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 18:46:15 --> CSRF cookie sent
INFO - 2018-03-19 18:46:15 --> Input Class Initialized
INFO - 2018-03-19 18:46:15 --> Language Class Initialized
ERROR - 2018-03-19 18:46:15 --> 404 Page Not Found: Assets/css
INFO - 2018-03-19 20:41:29 --> Config Class Initialized
INFO - 2018-03-19 20:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-19 20:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-19 20:41:29 --> Utf8 Class Initialized
INFO - 2018-03-19 20:41:29 --> URI Class Initialized
INFO - 2018-03-19 20:41:29 --> Router Class Initialized
INFO - 2018-03-19 20:41:29 --> Output Class Initialized
INFO - 2018-03-19 20:41:29 --> Security Class Initialized
DEBUG - 2018-03-19 20:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 20:41:29 --> CSRF cookie sent
INFO - 2018-03-19 20:41:29 --> Input Class Initialized
INFO - 2018-03-19 20:41:29 --> Language Class Initialized
INFO - 2018-03-19 20:41:29 --> Loader Class Initialized
INFO - 2018-03-19 20:41:29 --> Helper loaded: url_helper
INFO - 2018-03-19 20:41:29 --> Helper loaded: form_helper
DEBUG - 2018-03-19 20:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 20:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 20:41:29 --> User Agent Class Initialized
INFO - 2018-03-19 20:41:29 --> Controller Class Initialized
INFO - 2018-03-19 20:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 20:41:29 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 20:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 20:41:29 --> Final output sent to browser
DEBUG - 2018-03-19 20:41:29 --> Total execution time: 0.5636
INFO - 2018-03-19 20:41:30 --> Config Class Initialized
INFO - 2018-03-19 20:41:30 --> Hooks Class Initialized
DEBUG - 2018-03-19 20:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-19 20:41:30 --> Utf8 Class Initialized
INFO - 2018-03-19 20:41:30 --> URI Class Initialized
INFO - 2018-03-19 20:41:30 --> Router Class Initialized
INFO - 2018-03-19 20:41:30 --> Output Class Initialized
INFO - 2018-03-19 20:41:30 --> Security Class Initialized
DEBUG - 2018-03-19 20:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 20:41:30 --> CSRF cookie sent
INFO - 2018-03-19 20:41:30 --> Input Class Initialized
INFO - 2018-03-19 20:41:30 --> Language Class Initialized
ERROR - 2018-03-19 20:41:30 --> 404 Page Not Found: Assets/images
INFO - 2018-03-19 20:41:31 --> Config Class Initialized
INFO - 2018-03-19 20:41:31 --> Hooks Class Initialized
DEBUG - 2018-03-19 20:41:31 --> UTF-8 Support Enabled
INFO - 2018-03-19 20:41:31 --> Utf8 Class Initialized
INFO - 2018-03-19 20:41:31 --> URI Class Initialized
INFO - 2018-03-19 20:41:31 --> Router Class Initialized
INFO - 2018-03-19 20:41:31 --> Output Class Initialized
INFO - 2018-03-19 20:41:31 --> Security Class Initialized
DEBUG - 2018-03-19 20:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 20:41:31 --> CSRF cookie sent
INFO - 2018-03-19 20:41:31 --> Input Class Initialized
INFO - 2018-03-19 20:41:31 --> Language Class Initialized
INFO - 2018-03-19 20:41:31 --> Loader Class Initialized
INFO - 2018-03-19 20:41:31 --> Helper loaded: url_helper
INFO - 2018-03-19 20:41:31 --> Helper loaded: form_helper
DEBUG - 2018-03-19 20:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 20:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 20:41:31 --> User Agent Class Initialized
INFO - 2018-03-19 20:41:31 --> Controller Class Initialized
INFO - 2018-03-19 20:41:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-19 20:41:31 --> File loaded: E:\www\yacopoo\application\views\meeting.php
INFO - 2018-03-19 20:41:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-19 20:41:31 --> Final output sent to browser
DEBUG - 2018-03-19 20:41:31 --> Total execution time: 0.3964
INFO - 2018-03-19 20:41:31 --> Config Class Initialized
INFO - 2018-03-19 20:41:31 --> Hooks Class Initialized
DEBUG - 2018-03-19 20:41:31 --> UTF-8 Support Enabled
INFO - 2018-03-19 20:41:31 --> Utf8 Class Initialized
INFO - 2018-03-19 20:41:31 --> URI Class Initialized
INFO - 2018-03-19 20:41:31 --> Router Class Initialized
INFO - 2018-03-19 20:41:31 --> Output Class Initialized
INFO - 2018-03-19 20:41:31 --> Security Class Initialized
DEBUG - 2018-03-19 20:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 20:41:31 --> CSRF cookie sent
INFO - 2018-03-19 20:41:31 --> Input Class Initialized
INFO - 2018-03-19 20:41:31 --> Language Class Initialized
ERROR - 2018-03-19 20:41:31 --> 404 Page Not Found: Assets/images

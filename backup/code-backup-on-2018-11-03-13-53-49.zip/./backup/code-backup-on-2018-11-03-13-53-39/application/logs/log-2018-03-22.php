<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-22 18:17:55 --> Config Class Initialized
INFO - 2018-03-22 18:17:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:17:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:17:55 --> Utf8 Class Initialized
INFO - 2018-03-22 18:17:55 --> URI Class Initialized
INFO - 2018-03-22 18:17:55 --> Router Class Initialized
INFO - 2018-03-22 18:17:55 --> Output Class Initialized
INFO - 2018-03-22 18:17:55 --> Security Class Initialized
DEBUG - 2018-03-22 18:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:17:55 --> CSRF cookie sent
INFO - 2018-03-22 18:17:55 --> Input Class Initialized
INFO - 2018-03-22 18:17:55 --> Language Class Initialized
INFO - 2018-03-22 18:17:55 --> Loader Class Initialized
INFO - 2018-03-22 18:17:55 --> Helper loaded: url_helper
INFO - 2018-03-22 18:17:55 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:17:55 --> User Agent Class Initialized
INFO - 2018-03-22 18:17:55 --> Controller Class Initialized
INFO - 2018-03-22 18:17:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:17:55 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:17:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:17:55 --> Final output sent to browser
DEBUG - 2018-03-22 18:17:55 --> Total execution time: 0.2088
INFO - 2018-03-22 18:17:55 --> Config Class Initialized
INFO - 2018-03-22 18:17:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:17:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:17:55 --> Utf8 Class Initialized
INFO - 2018-03-22 18:17:55 --> URI Class Initialized
INFO - 2018-03-22 18:17:55 --> Router Class Initialized
INFO - 2018-03-22 18:17:55 --> Output Class Initialized
INFO - 2018-03-22 18:17:55 --> Security Class Initialized
DEBUG - 2018-03-22 18:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:17:55 --> CSRF cookie sent
INFO - 2018-03-22 18:17:55 --> Input Class Initialized
INFO - 2018-03-22 18:17:56 --> Language Class Initialized
ERROR - 2018-03-22 18:17:56 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:18:01 --> Config Class Initialized
INFO - 2018-03-22 18:18:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:01 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:01 --> URI Class Initialized
INFO - 2018-03-22 18:18:01 --> Router Class Initialized
INFO - 2018-03-22 18:18:01 --> Output Class Initialized
INFO - 2018-03-22 18:18:01 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:01 --> CSRF cookie sent
INFO - 2018-03-22 18:18:01 --> Input Class Initialized
INFO - 2018-03-22 18:18:01 --> Language Class Initialized
ERROR - 2018-03-22 18:18:01 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:18:32 --> Config Class Initialized
INFO - 2018-03-22 18:18:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:32 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:32 --> URI Class Initialized
INFO - 2018-03-22 18:18:32 --> Router Class Initialized
INFO - 2018-03-22 18:18:32 --> Output Class Initialized
INFO - 2018-03-22 18:18:32 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:32 --> CSRF cookie sent
INFO - 2018-03-22 18:18:32 --> Input Class Initialized
INFO - 2018-03-22 18:18:32 --> Language Class Initialized
INFO - 2018-03-22 18:18:32 --> Loader Class Initialized
INFO - 2018-03-22 18:18:32 --> Helper loaded: url_helper
INFO - 2018-03-22 18:18:32 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:18:32 --> User Agent Class Initialized
INFO - 2018-03-22 18:18:32 --> Controller Class Initialized
INFO - 2018-03-22 18:18:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:18:32 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:18:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:18:32 --> Final output sent to browser
DEBUG - 2018-03-22 18:18:32 --> Total execution time: 0.2072
INFO - 2018-03-22 18:18:32 --> Config Class Initialized
INFO - 2018-03-22 18:18:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:32 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:32 --> URI Class Initialized
INFO - 2018-03-22 18:18:32 --> Router Class Initialized
INFO - 2018-03-22 18:18:32 --> Output Class Initialized
INFO - 2018-03-22 18:18:32 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:32 --> CSRF cookie sent
INFO - 2018-03-22 18:18:32 --> Input Class Initialized
INFO - 2018-03-22 18:18:32 --> Language Class Initialized
ERROR - 2018-03-22 18:18:32 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:18:33 --> Config Class Initialized
INFO - 2018-03-22 18:18:33 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:33 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:33 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:33 --> URI Class Initialized
INFO - 2018-03-22 18:18:33 --> Router Class Initialized
INFO - 2018-03-22 18:18:33 --> Output Class Initialized
INFO - 2018-03-22 18:18:33 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:33 --> CSRF cookie sent
INFO - 2018-03-22 18:18:33 --> Input Class Initialized
INFO - 2018-03-22 18:18:33 --> Language Class Initialized
ERROR - 2018-03-22 18:18:33 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:18:37 --> Config Class Initialized
INFO - 2018-03-22 18:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:37 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:37 --> URI Class Initialized
INFO - 2018-03-22 18:18:37 --> Router Class Initialized
INFO - 2018-03-22 18:18:37 --> Output Class Initialized
INFO - 2018-03-22 18:18:37 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:37 --> CSRF cookie sent
INFO - 2018-03-22 18:18:37 --> Input Class Initialized
INFO - 2018-03-22 18:18:37 --> Language Class Initialized
INFO - 2018-03-22 18:18:37 --> Loader Class Initialized
INFO - 2018-03-22 18:18:37 --> Helper loaded: url_helper
INFO - 2018-03-22 18:18:37 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:18:38 --> User Agent Class Initialized
INFO - 2018-03-22 18:18:38 --> Controller Class Initialized
INFO - 2018-03-22 18:18:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:18:38 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:18:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:18:38 --> Final output sent to browser
DEBUG - 2018-03-22 18:18:38 --> Total execution time: 0.2096
INFO - 2018-03-22 18:18:38 --> Config Class Initialized
INFO - 2018-03-22 18:18:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:38 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:38 --> URI Class Initialized
INFO - 2018-03-22 18:18:38 --> Router Class Initialized
INFO - 2018-03-22 18:18:38 --> Output Class Initialized
INFO - 2018-03-22 18:18:38 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:38 --> CSRF cookie sent
INFO - 2018-03-22 18:18:38 --> Input Class Initialized
INFO - 2018-03-22 18:18:38 --> Language Class Initialized
ERROR - 2018-03-22 18:18:38 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:18:38 --> Config Class Initialized
INFO - 2018-03-22 18:18:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:18:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:18:38 --> Utf8 Class Initialized
INFO - 2018-03-22 18:18:38 --> URI Class Initialized
INFO - 2018-03-22 18:18:38 --> Router Class Initialized
INFO - 2018-03-22 18:18:38 --> Output Class Initialized
INFO - 2018-03-22 18:18:38 --> Security Class Initialized
DEBUG - 2018-03-22 18:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:18:38 --> CSRF cookie sent
INFO - 2018-03-22 18:18:38 --> Input Class Initialized
INFO - 2018-03-22 18:18:38 --> Language Class Initialized
ERROR - 2018-03-22 18:18:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:19:20 --> Config Class Initialized
INFO - 2018-03-22 18:19:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:20 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:20 --> URI Class Initialized
INFO - 2018-03-22 18:19:20 --> Router Class Initialized
INFO - 2018-03-22 18:19:21 --> Output Class Initialized
INFO - 2018-03-22 18:19:21 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:21 --> CSRF cookie sent
INFO - 2018-03-22 18:19:21 --> Input Class Initialized
INFO - 2018-03-22 18:19:21 --> Language Class Initialized
INFO - 2018-03-22 18:19:21 --> Loader Class Initialized
INFO - 2018-03-22 18:19:21 --> Helper loaded: url_helper
INFO - 2018-03-22 18:19:21 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:19:21 --> User Agent Class Initialized
INFO - 2018-03-22 18:19:21 --> Controller Class Initialized
INFO - 2018-03-22 18:19:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:19:21 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:19:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:19:21 --> Final output sent to browser
DEBUG - 2018-03-22 18:19:21 --> Total execution time: 0.2380
INFO - 2018-03-22 18:19:21 --> Config Class Initialized
INFO - 2018-03-22 18:19:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:21 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:21 --> URI Class Initialized
INFO - 2018-03-22 18:19:21 --> Router Class Initialized
INFO - 2018-03-22 18:19:21 --> Output Class Initialized
INFO - 2018-03-22 18:19:21 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:21 --> CSRF cookie sent
INFO - 2018-03-22 18:19:21 --> Input Class Initialized
INFO - 2018-03-22 18:19:21 --> Language Class Initialized
ERROR - 2018-03-22 18:19:21 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:19:21 --> Config Class Initialized
INFO - 2018-03-22 18:19:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:21 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:21 --> URI Class Initialized
INFO - 2018-03-22 18:19:21 --> Router Class Initialized
INFO - 2018-03-22 18:19:21 --> Output Class Initialized
INFO - 2018-03-22 18:19:21 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:21 --> CSRF cookie sent
INFO - 2018-03-22 18:19:21 --> Input Class Initialized
INFO - 2018-03-22 18:19:21 --> Language Class Initialized
ERROR - 2018-03-22 18:19:21 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:19:37 --> Config Class Initialized
INFO - 2018-03-22 18:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:37 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:37 --> URI Class Initialized
INFO - 2018-03-22 18:19:37 --> Router Class Initialized
INFO - 2018-03-22 18:19:37 --> Output Class Initialized
INFO - 2018-03-22 18:19:37 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:37 --> CSRF cookie sent
INFO - 2018-03-22 18:19:37 --> Input Class Initialized
INFO - 2018-03-22 18:19:37 --> Language Class Initialized
INFO - 2018-03-22 18:19:37 --> Loader Class Initialized
INFO - 2018-03-22 18:19:37 --> Helper loaded: url_helper
INFO - 2018-03-22 18:19:37 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:19:37 --> User Agent Class Initialized
INFO - 2018-03-22 18:19:37 --> Controller Class Initialized
INFO - 2018-03-22 18:19:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:19:37 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:19:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:19:37 --> Final output sent to browser
DEBUG - 2018-03-22 18:19:37 --> Total execution time: 0.2068
INFO - 2018-03-22 18:19:37 --> Config Class Initialized
INFO - 2018-03-22 18:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:37 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:37 --> URI Class Initialized
INFO - 2018-03-22 18:19:37 --> Router Class Initialized
INFO - 2018-03-22 18:19:37 --> Output Class Initialized
INFO - 2018-03-22 18:19:37 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:37 --> CSRF cookie sent
INFO - 2018-03-22 18:19:37 --> Input Class Initialized
INFO - 2018-03-22 18:19:37 --> Language Class Initialized
ERROR - 2018-03-22 18:19:37 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:19:38 --> Config Class Initialized
INFO - 2018-03-22 18:19:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:19:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:19:38 --> Utf8 Class Initialized
INFO - 2018-03-22 18:19:38 --> URI Class Initialized
INFO - 2018-03-22 18:19:38 --> Router Class Initialized
INFO - 2018-03-22 18:19:38 --> Output Class Initialized
INFO - 2018-03-22 18:19:38 --> Security Class Initialized
DEBUG - 2018-03-22 18:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:19:38 --> CSRF cookie sent
INFO - 2018-03-22 18:19:38 --> Input Class Initialized
INFO - 2018-03-22 18:19:38 --> Language Class Initialized
ERROR - 2018-03-22 18:19:38 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:20:26 --> Config Class Initialized
INFO - 2018-03-22 18:20:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:26 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:26 --> URI Class Initialized
INFO - 2018-03-22 18:20:26 --> Router Class Initialized
INFO - 2018-03-22 18:20:26 --> Output Class Initialized
INFO - 2018-03-22 18:20:26 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:26 --> CSRF cookie sent
INFO - 2018-03-22 18:20:26 --> Input Class Initialized
INFO - 2018-03-22 18:20:26 --> Language Class Initialized
INFO - 2018-03-22 18:20:26 --> Loader Class Initialized
INFO - 2018-03-22 18:20:26 --> Helper loaded: url_helper
INFO - 2018-03-22 18:20:26 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:20:26 --> User Agent Class Initialized
INFO - 2018-03-22 18:20:26 --> Controller Class Initialized
INFO - 2018-03-22 18:20:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:20:26 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:20:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:20:26 --> Final output sent to browser
DEBUG - 2018-03-22 18:20:26 --> Total execution time: 0.1930
INFO - 2018-03-22 18:20:27 --> Config Class Initialized
INFO - 2018-03-22 18:20:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:27 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:27 --> URI Class Initialized
INFO - 2018-03-22 18:20:27 --> Router Class Initialized
INFO - 2018-03-22 18:20:27 --> Output Class Initialized
INFO - 2018-03-22 18:20:27 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:27 --> CSRF cookie sent
INFO - 2018-03-22 18:20:27 --> Input Class Initialized
INFO - 2018-03-22 18:20:27 --> Language Class Initialized
ERROR - 2018-03-22 18:20:27 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:20:27 --> Config Class Initialized
INFO - 2018-03-22 18:20:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:27 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:27 --> URI Class Initialized
INFO - 2018-03-22 18:20:27 --> Router Class Initialized
INFO - 2018-03-22 18:20:27 --> Output Class Initialized
INFO - 2018-03-22 18:20:27 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:27 --> CSRF cookie sent
INFO - 2018-03-22 18:20:27 --> Input Class Initialized
INFO - 2018-03-22 18:20:27 --> Language Class Initialized
ERROR - 2018-03-22 18:20:27 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:20:58 --> Config Class Initialized
INFO - 2018-03-22 18:20:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:58 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:58 --> URI Class Initialized
INFO - 2018-03-22 18:20:58 --> Router Class Initialized
INFO - 2018-03-22 18:20:58 --> Output Class Initialized
INFO - 2018-03-22 18:20:58 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:58 --> CSRF cookie sent
INFO - 2018-03-22 18:20:58 --> Input Class Initialized
INFO - 2018-03-22 18:20:58 --> Language Class Initialized
INFO - 2018-03-22 18:20:58 --> Loader Class Initialized
INFO - 2018-03-22 18:20:58 --> Helper loaded: url_helper
INFO - 2018-03-22 18:20:58 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:20:58 --> User Agent Class Initialized
INFO - 2018-03-22 18:20:58 --> Controller Class Initialized
INFO - 2018-03-22 18:20:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:20:58 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:20:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:20:58 --> Final output sent to browser
DEBUG - 2018-03-22 18:20:58 --> Total execution time: 0.2208
INFO - 2018-03-22 18:20:58 --> Config Class Initialized
INFO - 2018-03-22 18:20:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:58 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:58 --> URI Class Initialized
INFO - 2018-03-22 18:20:58 --> Router Class Initialized
INFO - 2018-03-22 18:20:58 --> Output Class Initialized
INFO - 2018-03-22 18:20:58 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:58 --> CSRF cookie sent
INFO - 2018-03-22 18:20:58 --> Input Class Initialized
INFO - 2018-03-22 18:20:58 --> Language Class Initialized
ERROR - 2018-03-22 18:20:58 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:20:58 --> Config Class Initialized
INFO - 2018-03-22 18:20:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:20:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:20:58 --> Utf8 Class Initialized
INFO - 2018-03-22 18:20:58 --> URI Class Initialized
INFO - 2018-03-22 18:20:58 --> Router Class Initialized
INFO - 2018-03-22 18:20:58 --> Output Class Initialized
INFO - 2018-03-22 18:20:58 --> Security Class Initialized
DEBUG - 2018-03-22 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:20:58 --> CSRF cookie sent
INFO - 2018-03-22 18:20:58 --> Input Class Initialized
INFO - 2018-03-22 18:20:58 --> Language Class Initialized
ERROR - 2018-03-22 18:20:58 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:25:12 --> Config Class Initialized
INFO - 2018-03-22 18:25:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:12 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:12 --> URI Class Initialized
INFO - 2018-03-22 18:25:12 --> Router Class Initialized
INFO - 2018-03-22 18:25:12 --> Output Class Initialized
INFO - 2018-03-22 18:25:12 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:12 --> CSRF cookie sent
INFO - 2018-03-22 18:25:12 --> Input Class Initialized
INFO - 2018-03-22 18:25:12 --> Language Class Initialized
INFO - 2018-03-22 18:25:12 --> Loader Class Initialized
INFO - 2018-03-22 18:25:12 --> Helper loaded: url_helper
INFO - 2018-03-22 18:25:12 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:25:12 --> User Agent Class Initialized
INFO - 2018-03-22 18:25:12 --> Controller Class Initialized
INFO - 2018-03-22 18:25:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:25:12 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:25:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:25:12 --> Final output sent to browser
DEBUG - 2018-03-22 18:25:12 --> Total execution time: 0.1862
INFO - 2018-03-22 18:25:12 --> Config Class Initialized
INFO - 2018-03-22 18:25:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:12 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:12 --> URI Class Initialized
INFO - 2018-03-22 18:25:12 --> Router Class Initialized
INFO - 2018-03-22 18:25:12 --> Output Class Initialized
INFO - 2018-03-22 18:25:12 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:13 --> CSRF cookie sent
INFO - 2018-03-22 18:25:13 --> Input Class Initialized
INFO - 2018-03-22 18:25:13 --> Language Class Initialized
ERROR - 2018-03-22 18:25:13 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:25:13 --> Config Class Initialized
INFO - 2018-03-22 18:25:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:13 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:13 --> URI Class Initialized
INFO - 2018-03-22 18:25:13 --> Router Class Initialized
INFO - 2018-03-22 18:25:13 --> Output Class Initialized
INFO - 2018-03-22 18:25:13 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:13 --> CSRF cookie sent
INFO - 2018-03-22 18:25:13 --> Input Class Initialized
INFO - 2018-03-22 18:25:13 --> Language Class Initialized
ERROR - 2018-03-22 18:25:13 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:25:36 --> Config Class Initialized
INFO - 2018-03-22 18:25:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:36 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:36 --> URI Class Initialized
INFO - 2018-03-22 18:25:36 --> Router Class Initialized
INFO - 2018-03-22 18:25:36 --> Output Class Initialized
INFO - 2018-03-22 18:25:36 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:36 --> CSRF cookie sent
INFO - 2018-03-22 18:25:36 --> Input Class Initialized
INFO - 2018-03-22 18:25:36 --> Language Class Initialized
INFO - 2018-03-22 18:25:36 --> Loader Class Initialized
INFO - 2018-03-22 18:25:36 --> Helper loaded: url_helper
INFO - 2018-03-22 18:25:36 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:25:36 --> User Agent Class Initialized
INFO - 2018-03-22 18:25:36 --> Controller Class Initialized
INFO - 2018-03-22 18:25:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:25:36 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:25:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:25:36 --> Final output sent to browser
DEBUG - 2018-03-22 18:25:36 --> Total execution time: 0.2102
INFO - 2018-03-22 18:25:36 --> Config Class Initialized
INFO - 2018-03-22 18:25:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:36 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:36 --> URI Class Initialized
INFO - 2018-03-22 18:25:36 --> Router Class Initialized
INFO - 2018-03-22 18:25:36 --> Output Class Initialized
INFO - 2018-03-22 18:25:36 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:36 --> CSRF cookie sent
INFO - 2018-03-22 18:25:36 --> Input Class Initialized
INFO - 2018-03-22 18:25:36 --> Language Class Initialized
ERROR - 2018-03-22 18:25:36 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:25:37 --> Config Class Initialized
INFO - 2018-03-22 18:25:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:37 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:37 --> URI Class Initialized
INFO - 2018-03-22 18:25:37 --> Router Class Initialized
INFO - 2018-03-22 18:25:37 --> Output Class Initialized
INFO - 2018-03-22 18:25:37 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:37 --> CSRF cookie sent
INFO - 2018-03-22 18:25:37 --> Input Class Initialized
INFO - 2018-03-22 18:25:37 --> Language Class Initialized
ERROR - 2018-03-22 18:25:37 --> 404 Page Not Found: Assets/css
INFO - 2018-03-22 18:25:51 --> Config Class Initialized
INFO - 2018-03-22 18:25:51 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:51 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:51 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:51 --> URI Class Initialized
INFO - 2018-03-22 18:25:51 --> Router Class Initialized
INFO - 2018-03-22 18:25:51 --> Output Class Initialized
INFO - 2018-03-22 18:25:51 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:51 --> CSRF cookie sent
INFO - 2018-03-22 18:25:51 --> Input Class Initialized
INFO - 2018-03-22 18:25:51 --> Language Class Initialized
INFO - 2018-03-22 18:25:51 --> Loader Class Initialized
INFO - 2018-03-22 18:25:51 --> Helper loaded: url_helper
INFO - 2018-03-22 18:25:51 --> Helper loaded: form_helper
DEBUG - 2018-03-22 18:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:25:52 --> User Agent Class Initialized
INFO - 2018-03-22 18:25:52 --> Controller Class Initialized
INFO - 2018-03-22 18:25:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-03-22 18:25:52 --> File loaded: E:\www\yacopoo\application\views\register.php
INFO - 2018-03-22 18:25:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-03-22 18:25:52 --> Final output sent to browser
DEBUG - 2018-03-22 18:25:52 --> Total execution time: 0.2122
INFO - 2018-03-22 18:25:52 --> Config Class Initialized
INFO - 2018-03-22 18:25:52 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:52 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:52 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:52 --> URI Class Initialized
INFO - 2018-03-22 18:25:52 --> Router Class Initialized
INFO - 2018-03-22 18:25:52 --> Output Class Initialized
INFO - 2018-03-22 18:25:52 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:52 --> CSRF cookie sent
INFO - 2018-03-22 18:25:52 --> Input Class Initialized
INFO - 2018-03-22 18:25:52 --> Language Class Initialized
ERROR - 2018-03-22 18:25:52 --> 404 Page Not Found: Assets/images
INFO - 2018-03-22 18:25:52 --> Config Class Initialized
INFO - 2018-03-22 18:25:52 --> Hooks Class Initialized
DEBUG - 2018-03-22 18:25:52 --> UTF-8 Support Enabled
INFO - 2018-03-22 18:25:52 --> Utf8 Class Initialized
INFO - 2018-03-22 18:25:52 --> URI Class Initialized
INFO - 2018-03-22 18:25:52 --> Router Class Initialized
INFO - 2018-03-22 18:25:52 --> Output Class Initialized
INFO - 2018-03-22 18:25:52 --> Security Class Initialized
DEBUG - 2018-03-22 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 18:25:52 --> CSRF cookie sent
INFO - 2018-03-22 18:25:52 --> Input Class Initialized
INFO - 2018-03-22 18:25:52 --> Language Class Initialized
ERROR - 2018-03-22 18:25:52 --> 404 Page Not Found: Assets/css

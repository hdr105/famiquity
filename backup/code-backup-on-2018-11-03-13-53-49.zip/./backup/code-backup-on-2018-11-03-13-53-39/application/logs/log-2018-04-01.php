<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-01 19:04:52 --> Config Class Initialized
INFO - 2018-04-01 19:04:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:04:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:04:52 --> Utf8 Class Initialized
INFO - 2018-04-01 19:04:52 --> URI Class Initialized
INFO - 2018-04-01 19:04:52 --> Router Class Initialized
INFO - 2018-04-01 19:04:52 --> Output Class Initialized
INFO - 2018-04-01 19:04:52 --> Security Class Initialized
DEBUG - 2018-04-01 19:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:04:53 --> CSRF cookie sent
INFO - 2018-04-01 19:04:53 --> Input Class Initialized
INFO - 2018-04-01 19:04:53 --> Language Class Initialized
INFO - 2018-04-01 19:04:53 --> Loader Class Initialized
INFO - 2018-04-01 19:04:53 --> Helper loaded: url_helper
INFO - 2018-04-01 19:04:53 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:04:53 --> User Agent Class Initialized
INFO - 2018-04-01 19:04:53 --> Controller Class Initialized
INFO - 2018-04-01 19:04:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:04:53 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-01 19:04:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:04:53 --> Final output sent to browser
DEBUG - 2018-04-01 19:04:53 --> Total execution time: 1.7553
INFO - 2018-04-01 19:04:54 --> Config Class Initialized
INFO - 2018-04-01 19:04:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:04:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:04:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:04:54 --> URI Class Initialized
INFO - 2018-04-01 19:04:54 --> Router Class Initialized
INFO - 2018-04-01 19:04:54 --> Output Class Initialized
INFO - 2018-04-01 19:04:54 --> Security Class Initialized
DEBUG - 2018-04-01 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:04:54 --> CSRF cookie sent
INFO - 2018-04-01 19:04:54 --> Input Class Initialized
INFO - 2018-04-01 19:04:54 --> Language Class Initialized
ERROR - 2018-04-01 19:04:54 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:06:55 --> Config Class Initialized
INFO - 2018-04-01 19:06:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:06:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
DEBUG - 2018-04-01 19:06:56 --> No URI present. Default controller set.
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Loader Class Initialized
INFO - 2018-04-01 19:06:56 --> Helper loaded: url_helper
INFO - 2018-04-01 19:06:56 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:06:56 --> User Agent Class Initialized
INFO - 2018-04-01 19:06:56 --> Controller Class Initialized
INFO - 2018-04-01 19:06:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:06:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:06:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:06:56 --> Final output sent to browser
DEBUG - 2018-04-01 19:06:56 --> Total execution time: 0.2136
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:06:56 --> Config Class Initialized
INFO - 2018-04-01 19:06:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:06:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:56 --> URI Class Initialized
INFO - 2018-04-01 19:06:56 --> Router Class Initialized
INFO - 2018-04-01 19:06:56 --> Output Class Initialized
INFO - 2018-04-01 19:06:56 --> Security Class Initialized
DEBUG - 2018-04-01 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:56 --> CSRF cookie sent
INFO - 2018-04-01 19:06:56 --> Input Class Initialized
INFO - 2018-04-01 19:06:56 --> Language Class Initialized
ERROR - 2018-04-01 19:06:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:06:57 --> Config Class Initialized
INFO - 2018-04-01 19:06:57 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:06:57 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:06:57 --> Utf8 Class Initialized
INFO - 2018-04-01 19:06:57 --> URI Class Initialized
INFO - 2018-04-01 19:06:57 --> Router Class Initialized
INFO - 2018-04-01 19:06:57 --> Output Class Initialized
INFO - 2018-04-01 19:06:57 --> Security Class Initialized
DEBUG - 2018-04-01 19:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:06:57 --> CSRF cookie sent
INFO - 2018-04-01 19:06:57 --> Input Class Initialized
INFO - 2018-04-01 19:06:58 --> Language Class Initialized
ERROR - 2018-04-01 19:06:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:15:34 --> Config Class Initialized
INFO - 2018-04-01 19:15:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:34 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:34 --> URI Class Initialized
DEBUG - 2018-04-01 19:15:34 --> No URI present. Default controller set.
INFO - 2018-04-01 19:15:34 --> Router Class Initialized
INFO - 2018-04-01 19:15:34 --> Output Class Initialized
INFO - 2018-04-01 19:15:34 --> Security Class Initialized
DEBUG - 2018-04-01 19:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:34 --> CSRF cookie sent
INFO - 2018-04-01 19:15:34 --> Input Class Initialized
INFO - 2018-04-01 19:15:34 --> Language Class Initialized
INFO - 2018-04-01 19:15:34 --> Loader Class Initialized
INFO - 2018-04-01 19:15:34 --> Helper loaded: url_helper
INFO - 2018-04-01 19:15:34 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:15:34 --> User Agent Class Initialized
INFO - 2018-04-01 19:15:34 --> Controller Class Initialized
INFO - 2018-04-01 19:15:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:15:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:15:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:15:34 --> Final output sent to browser
DEBUG - 2018-04-01 19:15:34 --> Total execution time: 0.1986
INFO - 2018-04-01 19:15:34 --> Config Class Initialized
INFO - 2018-04-01 19:15:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:34 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:34 --> URI Class Initialized
INFO - 2018-04-01 19:15:34 --> Router Class Initialized
INFO - 2018-04-01 19:15:34 --> Output Class Initialized
INFO - 2018-04-01 19:15:34 --> Security Class Initialized
INFO - 2018-04-01 19:15:34 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:35 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:15:35 --> Config Class Initialized
INFO - 2018-04-01 19:15:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:35 --> URI Class Initialized
INFO - 2018-04-01 19:15:35 --> Router Class Initialized
INFO - 2018-04-01 19:15:35 --> Output Class Initialized
INFO - 2018-04-01 19:15:35 --> Security Class Initialized
DEBUG - 2018-04-01 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:35 --> CSRF cookie sent
INFO - 2018-04-01 19:15:35 --> Input Class Initialized
INFO - 2018-04-01 19:15:35 --> Language Class Initialized
ERROR - 2018-04-01 19:15:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:15:36 --> Config Class Initialized
INFO - 2018-04-01 19:15:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:15:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:15:36 --> Utf8 Class Initialized
INFO - 2018-04-01 19:15:36 --> URI Class Initialized
INFO - 2018-04-01 19:15:36 --> Router Class Initialized
INFO - 2018-04-01 19:15:36 --> Output Class Initialized
INFO - 2018-04-01 19:15:36 --> Security Class Initialized
DEBUG - 2018-04-01 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:15:36 --> CSRF cookie sent
INFO - 2018-04-01 19:15:36 --> Input Class Initialized
INFO - 2018-04-01 19:15:36 --> Language Class Initialized
ERROR - 2018-04-01 19:15:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:19 --> Config Class Initialized
INFO - 2018-04-01 19:16:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:19 --> URI Class Initialized
DEBUG - 2018-04-01 19:16:19 --> No URI present. Default controller set.
INFO - 2018-04-01 19:16:19 --> Router Class Initialized
INFO - 2018-04-01 19:16:19 --> Output Class Initialized
INFO - 2018-04-01 19:16:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:19 --> CSRF cookie sent
INFO - 2018-04-01 19:16:19 --> Input Class Initialized
INFO - 2018-04-01 19:16:19 --> Language Class Initialized
INFO - 2018-04-01 19:16:19 --> Loader Class Initialized
INFO - 2018-04-01 19:16:19 --> Helper loaded: url_helper
INFO - 2018-04-01 19:16:19 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:16:19 --> User Agent Class Initialized
INFO - 2018-04-01 19:16:19 --> Controller Class Initialized
INFO - 2018-04-01 19:16:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:16:19 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:16:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:16:19 --> Final output sent to browser
DEBUG - 2018-04-01 19:16:19 --> Total execution time: 0.2307
INFO - 2018-04-01 19:16:19 --> Config Class Initialized
INFO - 2018-04-01 19:16:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:16:20 --> Config Class Initialized
INFO - 2018-04-01 19:16:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:20 --> URI Class Initialized
INFO - 2018-04-01 19:16:20 --> Router Class Initialized
INFO - 2018-04-01 19:16:20 --> Output Class Initialized
INFO - 2018-04-01 19:16:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:20 --> CSRF cookie sent
INFO - 2018-04-01 19:16:20 --> Input Class Initialized
INFO - 2018-04-01 19:16:20 --> Language Class Initialized
ERROR - 2018-04-01 19:16:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:21 --> Config Class Initialized
INFO - 2018-04-01 19:16:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:21 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:21 --> URI Class Initialized
INFO - 2018-04-01 19:16:21 --> Router Class Initialized
INFO - 2018-04-01 19:16:21 --> Output Class Initialized
INFO - 2018-04-01 19:16:21 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:21 --> CSRF cookie sent
INFO - 2018-04-01 19:16:21 --> Input Class Initialized
INFO - 2018-04-01 19:16:21 --> Language Class Initialized
ERROR - 2018-04-01 19:16:21 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
DEBUG - 2018-04-01 19:16:32 --> No URI present. Default controller set.
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> Loader Class Initialized
INFO - 2018-04-01 19:16:32 --> Helper loaded: url_helper
INFO - 2018-04-01 19:16:32 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:16:32 --> User Agent Class Initialized
INFO - 2018-04-01 19:16:32 --> Controller Class Initialized
INFO - 2018-04-01 19:16:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:16:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:16:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:16:32 --> Final output sent to browser
DEBUG - 2018-04-01 19:16:32 --> Total execution time: 0.2415
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Config Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:32 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
INFO - 2018-04-01 19:16:32 --> URI Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Router Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Output Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
INFO - 2018-04-01 19:16:32 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> CSRF cookie sent
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Input Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
INFO - 2018-04-01 19:16:32 --> Language Class Initialized
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:16:32 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:16:33 --> Config Class Initialized
INFO - 2018-04-01 19:16:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:33 --> URI Class Initialized
INFO - 2018-04-01 19:16:33 --> Router Class Initialized
INFO - 2018-04-01 19:16:33 --> Output Class Initialized
INFO - 2018-04-01 19:16:33 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:33 --> CSRF cookie sent
INFO - 2018-04-01 19:16:33 --> Input Class Initialized
INFO - 2018-04-01 19:16:33 --> Language Class Initialized
ERROR - 2018-04-01 19:16:33 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:34 --> Config Class Initialized
INFO - 2018-04-01 19:16:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:34 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:34 --> URI Class Initialized
INFO - 2018-04-01 19:16:34 --> Router Class Initialized
INFO - 2018-04-01 19:16:34 --> Output Class Initialized
INFO - 2018-04-01 19:16:34 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:34 --> CSRF cookie sent
INFO - 2018-04-01 19:16:34 --> Input Class Initialized
INFO - 2018-04-01 19:16:34 --> Language Class Initialized
ERROR - 2018-04-01 19:16:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:52 --> Config Class Initialized
INFO - 2018-04-01 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:52 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:52 --> URI Class Initialized
DEBUG - 2018-04-01 19:16:52 --> No URI present. Default controller set.
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> Loader Class Initialized
INFO - 2018-04-01 19:16:53 --> Helper loaded: url_helper
INFO - 2018-04-01 19:16:53 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:16:53 --> User Agent Class Initialized
INFO - 2018-04-01 19:16:53 --> Controller Class Initialized
INFO - 2018-04-01 19:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:16:53 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:16:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:16:53 --> Final output sent to browser
DEBUG - 2018-04-01 19:16:53 --> Total execution time: 0.2402
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:53 --> Config Class Initialized
INFO - 2018-04-01 19:16:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:53 --> URI Class Initialized
INFO - 2018-04-01 19:16:53 --> Router Class Initialized
INFO - 2018-04-01 19:16:53 --> Output Class Initialized
INFO - 2018-04-01 19:16:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:53 --> CSRF cookie sent
INFO - 2018-04-01 19:16:53 --> Input Class Initialized
INFO - 2018-04-01 19:16:53 --> Language Class Initialized
ERROR - 2018-04-01 19:16:53 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:16:54 --> Config Class Initialized
INFO - 2018-04-01 19:16:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:16:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:16:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:16:54 --> URI Class Initialized
INFO - 2018-04-01 19:16:54 --> Router Class Initialized
INFO - 2018-04-01 19:16:54 --> Output Class Initialized
INFO - 2018-04-01 19:16:54 --> Security Class Initialized
DEBUG - 2018-04-01 19:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:16:54 --> CSRF cookie sent
INFO - 2018-04-01 19:16:54 --> Input Class Initialized
INFO - 2018-04-01 19:16:54 --> Language Class Initialized
ERROR - 2018-04-01 19:16:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:17:28 --> Config Class Initialized
INFO - 2018-04-01 19:17:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:17:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:28 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:28 --> URI Class Initialized
DEBUG - 2018-04-01 19:17:28 --> No URI present. Default controller set.
INFO - 2018-04-01 19:17:28 --> Router Class Initialized
INFO - 2018-04-01 19:17:28 --> Output Class Initialized
INFO - 2018-04-01 19:17:28 --> Security Class Initialized
DEBUG - 2018-04-01 19:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:28 --> CSRF cookie sent
INFO - 2018-04-01 19:17:28 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
INFO - 2018-04-01 19:17:29 --> Loader Class Initialized
INFO - 2018-04-01 19:17:29 --> Helper loaded: url_helper
INFO - 2018-04-01 19:17:29 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:17:29 --> User Agent Class Initialized
INFO - 2018-04-01 19:17:29 --> Controller Class Initialized
INFO - 2018-04-01 19:17:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:17:29 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:17:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:17:29 --> Final output sent to browser
DEBUG - 2018-04-01 19:17:29 --> Total execution time: 0.2114
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:17:29 --> Config Class Initialized
INFO - 2018-04-01 19:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:29 --> URI Class Initialized
INFO - 2018-04-01 19:17:29 --> Router Class Initialized
INFO - 2018-04-01 19:17:29 --> Output Class Initialized
INFO - 2018-04-01 19:17:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:29 --> CSRF cookie sent
INFO - 2018-04-01 19:17:29 --> Input Class Initialized
INFO - 2018-04-01 19:17:29 --> Language Class Initialized
ERROR - 2018-04-01 19:17:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:17:30 --> Config Class Initialized
INFO - 2018-04-01 19:17:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:17:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:17:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:17:30 --> URI Class Initialized
INFO - 2018-04-01 19:17:30 --> Router Class Initialized
INFO - 2018-04-01 19:17:30 --> Output Class Initialized
INFO - 2018-04-01 19:17:30 --> Security Class Initialized
DEBUG - 2018-04-01 19:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:17:30 --> CSRF cookie sent
INFO - 2018-04-01 19:17:30 --> Input Class Initialized
INFO - 2018-04-01 19:17:30 --> Language Class Initialized
ERROR - 2018-04-01 19:17:30 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:18:07 --> Config Class Initialized
INFO - 2018-04-01 19:18:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:07 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:07 --> URI Class Initialized
DEBUG - 2018-04-01 19:18:07 --> No URI present. Default controller set.
INFO - 2018-04-01 19:18:07 --> Router Class Initialized
INFO - 2018-04-01 19:18:07 --> Output Class Initialized
INFO - 2018-04-01 19:18:07 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:07 --> CSRF cookie sent
INFO - 2018-04-01 19:18:07 --> Input Class Initialized
INFO - 2018-04-01 19:18:07 --> Language Class Initialized
INFO - 2018-04-01 19:18:07 --> Loader Class Initialized
INFO - 2018-04-01 19:18:07 --> Helper loaded: url_helper
INFO - 2018-04-01 19:18:07 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:18:07 --> User Agent Class Initialized
INFO - 2018-04-01 19:18:07 --> Controller Class Initialized
INFO - 2018-04-01 19:18:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:18:07 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:18:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:18:07 --> Final output sent to browser
DEBUG - 2018-04-01 19:18:07 --> Total execution time: 0.2325
INFO - 2018-04-01 19:18:07 --> Config Class Initialized
INFO - 2018-04-01 19:18:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:07 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:18:08 --> Config Class Initialized
INFO - 2018-04-01 19:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:08 --> URI Class Initialized
INFO - 2018-04-01 19:18:08 --> Router Class Initialized
INFO - 2018-04-01 19:18:08 --> Output Class Initialized
INFO - 2018-04-01 19:18:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:08 --> CSRF cookie sent
INFO - 2018-04-01 19:18:08 --> Input Class Initialized
INFO - 2018-04-01 19:18:08 --> Language Class Initialized
ERROR - 2018-04-01 19:18:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:18:09 --> Config Class Initialized
INFO - 2018-04-01 19:18:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:09 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:09 --> URI Class Initialized
INFO - 2018-04-01 19:18:09 --> Router Class Initialized
INFO - 2018-04-01 19:18:09 --> Output Class Initialized
INFO - 2018-04-01 19:18:09 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:09 --> CSRF cookie sent
INFO - 2018-04-01 19:18:09 --> Input Class Initialized
INFO - 2018-04-01 19:18:09 --> Language Class Initialized
ERROR - 2018-04-01 19:18:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
DEBUG - 2018-04-01 19:18:33 --> No URI present. Default controller set.
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> Loader Class Initialized
INFO - 2018-04-01 19:18:33 --> Helper loaded: url_helper
INFO - 2018-04-01 19:18:33 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:18:33 --> User Agent Class Initialized
INFO - 2018-04-01 19:18:33 --> Controller Class Initialized
INFO - 2018-04-01 19:18:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:18:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:18:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:18:33 --> Final output sent to browser
DEBUG - 2018-04-01 19:18:33 --> Total execution time: 0.2801
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
INFO - 2018-04-01 19:18:33 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> CSRF cookie sent
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Input Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
INFO - 2018-04-01 19:18:33 --> Language Class Initialized
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:18:33 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:18:33 --> Config Class Initialized
INFO - 2018-04-01 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:33 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:33 --> URI Class Initialized
INFO - 2018-04-01 19:18:33 --> Router Class Initialized
INFO - 2018-04-01 19:18:33 --> Output Class Initialized
INFO - 2018-04-01 19:18:34 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:34 --> CSRF cookie sent
INFO - 2018-04-01 19:18:34 --> Input Class Initialized
INFO - 2018-04-01 19:18:34 --> Language Class Initialized
ERROR - 2018-04-01 19:18:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:18:34 --> Config Class Initialized
INFO - 2018-04-01 19:18:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:18:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:18:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:18:35 --> URI Class Initialized
INFO - 2018-04-01 19:18:35 --> Router Class Initialized
INFO - 2018-04-01 19:18:35 --> Output Class Initialized
INFO - 2018-04-01 19:18:35 --> Security Class Initialized
DEBUG - 2018-04-01 19:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:18:35 --> CSRF cookie sent
INFO - 2018-04-01 19:18:35 --> Input Class Initialized
INFO - 2018-04-01 19:18:35 --> Language Class Initialized
ERROR - 2018-04-01 19:18:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
DEBUG - 2018-04-01 19:19:00 --> No URI present. Default controller set.
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Loader Class Initialized
INFO - 2018-04-01 19:19:00 --> Helper loaded: url_helper
INFO - 2018-04-01 19:19:00 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:19:00 --> User Agent Class Initialized
INFO - 2018-04-01 19:19:00 --> Controller Class Initialized
INFO - 2018-04-01 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:19:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:19:00 --> Final output sent to browser
DEBUG - 2018-04-01 19:19:00 --> Total execution time: 0.2254
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Config Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:19:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
INFO - 2018-04-01 19:19:00 --> URI Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
INFO - 2018-04-01 19:19:00 --> Router Class Initialized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> Output Class Initialized
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Security Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> CSRF cookie sent
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
INFO - 2018-04-01 19:19:00 --> Input Class Initialized
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
INFO - 2018-04-01 19:19:00 --> Language Class Initialized
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:19:00 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:19:01 --> Config Class Initialized
INFO - 2018-04-01 19:19:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:19:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:19:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:01 --> URI Class Initialized
INFO - 2018-04-01 19:19:01 --> Router Class Initialized
INFO - 2018-04-01 19:19:01 --> Output Class Initialized
INFO - 2018-04-01 19:19:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:19:01 --> CSRF cookie sent
INFO - 2018-04-01 19:19:01 --> Input Class Initialized
INFO - 2018-04-01 19:19:01 --> Language Class Initialized
ERROR - 2018-04-01 19:19:01 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:19:02 --> Config Class Initialized
INFO - 2018-04-01 19:19:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:19:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:19:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:19:02 --> URI Class Initialized
INFO - 2018-04-01 19:19:02 --> Router Class Initialized
INFO - 2018-04-01 19:19:02 --> Output Class Initialized
INFO - 2018-04-01 19:19:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:19:02 --> CSRF cookie sent
INFO - 2018-04-01 19:19:02 --> Input Class Initialized
INFO - 2018-04-01 19:19:02 --> Language Class Initialized
ERROR - 2018-04-01 19:19:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
DEBUG - 2018-04-01 19:20:01 --> No URI present. Default controller set.
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> Loader Class Initialized
INFO - 2018-04-01 19:20:01 --> Helper loaded: url_helper
INFO - 2018-04-01 19:20:01 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:20:01 --> User Agent Class Initialized
INFO - 2018-04-01 19:20:01 --> Controller Class Initialized
INFO - 2018-04-01 19:20:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:20:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:20:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:20:01 --> Final output sent to browser
DEBUG - 2018-04-01 19:20:01 --> Total execution time: 0.2704
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
INFO - 2018-04-01 19:20:01 --> Config Class Initialized
INFO - 2018-04-01 19:20:01 --> Hooks Class Initialized
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
DEBUG - 2018-04-01 19:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> URI Class Initialized
INFO - 2018-04-01 19:20:01 --> Router Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
INFO - 2018-04-01 19:20:01 --> Output Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
INFO - 2018-04-01 19:20:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
DEBUG - 2018-04-01 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> CSRF cookie sent
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> Input Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
INFO - 2018-04-01 19:20:01 --> Language Class Initialized
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:20:01 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:20:02 --> Config Class Initialized
INFO - 2018-04-01 19:20:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:20:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:02 --> URI Class Initialized
INFO - 2018-04-01 19:20:02 --> Router Class Initialized
INFO - 2018-04-01 19:20:02 --> Output Class Initialized
INFO - 2018-04-01 19:20:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:02 --> CSRF cookie sent
INFO - 2018-04-01 19:20:02 --> Input Class Initialized
INFO - 2018-04-01 19:20:02 --> Language Class Initialized
ERROR - 2018-04-01 19:20:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:20:03 --> Config Class Initialized
INFO - 2018-04-01 19:20:03 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:20:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:20:03 --> Utf8 Class Initialized
INFO - 2018-04-01 19:20:03 --> URI Class Initialized
INFO - 2018-04-01 19:20:03 --> Router Class Initialized
INFO - 2018-04-01 19:20:03 --> Output Class Initialized
INFO - 2018-04-01 19:20:03 --> Security Class Initialized
DEBUG - 2018-04-01 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:20:03 --> CSRF cookie sent
INFO - 2018-04-01 19:20:03 --> Input Class Initialized
INFO - 2018-04-01 19:20:03 --> Language Class Initialized
ERROR - 2018-04-01 19:20:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
DEBUG - 2018-04-01 19:21:55 --> No URI present. Default controller set.
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:55 --> CSRF cookie sent
INFO - 2018-04-01 19:21:55 --> Input Class Initialized
INFO - 2018-04-01 19:21:55 --> Language Class Initialized
INFO - 2018-04-01 19:21:55 --> Loader Class Initialized
INFO - 2018-04-01 19:21:55 --> Helper loaded: url_helper
INFO - 2018-04-01 19:21:55 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:21:55 --> User Agent Class Initialized
INFO - 2018-04-01 19:21:55 --> Controller Class Initialized
INFO - 2018-04-01 19:21:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:21:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:21:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:21:55 --> Final output sent to browser
DEBUG - 2018-04-01 19:21:55 --> Total execution time: 0.2620
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:55 --> CSRF cookie sent
INFO - 2018-04-01 19:21:55 --> Config Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:55 --> Input Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> Language Class Initialized
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:21:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
ERROR - 2018-04-01 19:21:55 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
INFO - 2018-04-01 19:21:55 --> URI Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Router Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Output Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:55 --> Security Class Initialized
INFO - 2018-04-01 19:21:55 --> CSRF cookie sent
INFO - 2018-04-01 19:21:55 --> CSRF cookie sent
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> CSRF cookie sent
INFO - 2018-04-01 19:21:56 --> CSRF cookie sent
INFO - 2018-04-01 19:21:56 --> CSRF cookie sent
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Images/team
INFO - 2018-04-01 19:21:56 --> Config Class Initialized
INFO - 2018-04-01 19:21:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:56 --> URI Class Initialized
INFO - 2018-04-01 19:21:56 --> Router Class Initialized
INFO - 2018-04-01 19:21:56 --> Output Class Initialized
INFO - 2018-04-01 19:21:56 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:56 --> CSRF cookie sent
INFO - 2018-04-01 19:21:56 --> Input Class Initialized
INFO - 2018-04-01 19:21:56 --> Language Class Initialized
ERROR - 2018-04-01 19:21:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:21:57 --> Config Class Initialized
INFO - 2018-04-01 19:21:57 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:57 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:57 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:57 --> URI Class Initialized
INFO - 2018-04-01 19:21:57 --> Router Class Initialized
INFO - 2018-04-01 19:21:57 --> Output Class Initialized
INFO - 2018-04-01 19:21:57 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:57 --> CSRF cookie sent
INFO - 2018-04-01 19:21:57 --> Input Class Initialized
INFO - 2018-04-01 19:21:57 --> Language Class Initialized
ERROR - 2018-04-01 19:21:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:22:02 --> Config Class Initialized
INFO - 2018-04-01 19:22:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:22:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:22:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:22:02 --> URI Class Initialized
INFO - 2018-04-01 19:22:02 --> Router Class Initialized
INFO - 2018-04-01 19:22:02 --> Output Class Initialized
INFO - 2018-04-01 19:22:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:22:02 --> CSRF cookie sent
INFO - 2018-04-01 19:22:02 --> Input Class Initialized
INFO - 2018-04-01 19:22:02 --> Language Class Initialized
ERROR - 2018-04-01 19:22:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:23:19 --> Config Class Initialized
INFO - 2018-04-01 19:23:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:23:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
DEBUG - 2018-04-01 19:23:20 --> No URI present. Default controller set.
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
INFO - 2018-04-01 19:23:20 --> Loader Class Initialized
INFO - 2018-04-01 19:23:20 --> Helper loaded: url_helper
INFO - 2018-04-01 19:23:20 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:23:20 --> User Agent Class Initialized
INFO - 2018-04-01 19:23:20 --> Controller Class Initialized
INFO - 2018-04-01 19:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:23:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:23:20 --> Final output sent to browser
DEBUG - 2018-04-01 19:23:20 --> Total execution time: 0.2317
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:23:20 --> Config Class Initialized
INFO - 2018-04-01 19:23:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Images/team
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Images/team
DEBUG - 2018-04-01 19:23:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:20 --> URI Class Initialized
INFO - 2018-04-01 19:23:20 --> Router Class Initialized
INFO - 2018-04-01 19:23:20 --> Output Class Initialized
INFO - 2018-04-01 19:23:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:20 --> CSRF cookie sent
INFO - 2018-04-01 19:23:20 --> Input Class Initialized
INFO - 2018-04-01 19:23:20 --> Language Class Initialized
ERROR - 2018-04-01 19:23:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:23:21 --> Config Class Initialized
INFO - 2018-04-01 19:23:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:23:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:21 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:21 --> URI Class Initialized
INFO - 2018-04-01 19:23:21 --> Router Class Initialized
INFO - 2018-04-01 19:23:21 --> Output Class Initialized
INFO - 2018-04-01 19:23:21 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:21 --> CSRF cookie sent
INFO - 2018-04-01 19:23:21 --> Input Class Initialized
INFO - 2018-04-01 19:23:21 --> Language Class Initialized
ERROR - 2018-04-01 19:23:21 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:23:22 --> Config Class Initialized
INFO - 2018-04-01 19:23:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:23:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:23:22 --> Utf8 Class Initialized
INFO - 2018-04-01 19:23:22 --> URI Class Initialized
INFO - 2018-04-01 19:23:22 --> Router Class Initialized
INFO - 2018-04-01 19:23:22 --> Output Class Initialized
INFO - 2018-04-01 19:23:22 --> Security Class Initialized
DEBUG - 2018-04-01 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:23:22 --> CSRF cookie sent
INFO - 2018-04-01 19:23:22 --> Input Class Initialized
INFO - 2018-04-01 19:23:22 --> Language Class Initialized
ERROR - 2018-04-01 19:23:22 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:24:14 --> Config Class Initialized
INFO - 2018-04-01 19:24:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:24:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:24:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:14 --> URI Class Initialized
DEBUG - 2018-04-01 19:24:14 --> No URI present. Default controller set.
INFO - 2018-04-01 19:24:14 --> Router Class Initialized
INFO - 2018-04-01 19:24:14 --> Output Class Initialized
INFO - 2018-04-01 19:24:14 --> Security Class Initialized
DEBUG - 2018-04-01 19:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:14 --> CSRF cookie sent
INFO - 2018-04-01 19:24:14 --> Input Class Initialized
INFO - 2018-04-01 19:24:14 --> Language Class Initialized
INFO - 2018-04-01 19:24:14 --> Loader Class Initialized
INFO - 2018-04-01 19:24:14 --> Helper loaded: url_helper
INFO - 2018-04-01 19:24:14 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:24:14 --> User Agent Class Initialized
INFO - 2018-04-01 19:24:14 --> Controller Class Initialized
INFO - 2018-04-01 19:24:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:24:14 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:24:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:24:14 --> Final output sent to browser
DEBUG - 2018-04-01 19:24:14 --> Total execution time: 0.2329
INFO - 2018-04-01 19:24:14 --> Config Class Initialized
INFO - 2018-04-01 19:24:14 --> Config Class Initialized
INFO - 2018-04-01 19:24:14 --> Hooks Class Initialized
INFO - 2018-04-01 19:24:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:24:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:24:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:24:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:14 --> URI Class Initialized
INFO - 2018-04-01 19:24:14 --> URI Class Initialized
INFO - 2018-04-01 19:24:14 --> Router Class Initialized
INFO - 2018-04-01 19:24:14 --> Output Class Initialized
INFO - 2018-04-01 19:24:14 --> Router Class Initialized
INFO - 2018-04-01 19:24:14 --> Security Class Initialized
INFO - 2018-04-01 19:24:14 --> Output Class Initialized
INFO - 2018-04-01 19:24:14 --> Security Class Initialized
DEBUG - 2018-04-01 19:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:14 --> CSRF cookie sent
DEBUG - 2018-04-01 19:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:14 --> Input Class Initialized
INFO - 2018-04-01 19:24:14 --> CSRF cookie sent
INFO - 2018-04-01 19:24:15 --> Input Class Initialized
INFO - 2018-04-01 19:24:15 --> Language Class Initialized
INFO - 2018-04-01 19:24:15 --> Language Class Initialized
ERROR - 2018-04-01 19:24:15 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:24:15 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:24:15 --> Config Class Initialized
INFO - 2018-04-01 19:24:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:24:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:24:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:15 --> URI Class Initialized
INFO - 2018-04-01 19:24:15 --> Router Class Initialized
INFO - 2018-04-01 19:24:15 --> Output Class Initialized
INFO - 2018-04-01 19:24:15 --> Security Class Initialized
DEBUG - 2018-04-01 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:15 --> CSRF cookie sent
INFO - 2018-04-01 19:24:15 --> Input Class Initialized
INFO - 2018-04-01 19:24:15 --> Language Class Initialized
ERROR - 2018-04-01 19:24:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:24:15 --> Config Class Initialized
INFO - 2018-04-01 19:24:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:24:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:24:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:15 --> URI Class Initialized
INFO - 2018-04-01 19:24:15 --> Router Class Initialized
INFO - 2018-04-01 19:24:15 --> Output Class Initialized
INFO - 2018-04-01 19:24:15 --> Security Class Initialized
DEBUG - 2018-04-01 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:15 --> CSRF cookie sent
INFO - 2018-04-01 19:24:15 --> Input Class Initialized
INFO - 2018-04-01 19:24:15 --> Language Class Initialized
ERROR - 2018-04-01 19:24:15 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:24:16 --> Config Class Initialized
INFO - 2018-04-01 19:24:16 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:24:16 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:24:16 --> Utf8 Class Initialized
INFO - 2018-04-01 19:24:16 --> URI Class Initialized
INFO - 2018-04-01 19:24:16 --> Router Class Initialized
INFO - 2018-04-01 19:24:16 --> Output Class Initialized
INFO - 2018-04-01 19:24:16 --> Security Class Initialized
DEBUG - 2018-04-01 19:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:24:16 --> CSRF cookie sent
INFO - 2018-04-01 19:24:16 --> Input Class Initialized
INFO - 2018-04-01 19:24:16 --> Language Class Initialized
ERROR - 2018-04-01 19:24:16 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:26:13 --> Config Class Initialized
INFO - 2018-04-01 19:26:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:13 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:13 --> URI Class Initialized
DEBUG - 2018-04-01 19:26:13 --> No URI present. Default controller set.
INFO - 2018-04-01 19:26:13 --> Router Class Initialized
INFO - 2018-04-01 19:26:13 --> Output Class Initialized
INFO - 2018-04-01 19:26:13 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:13 --> CSRF cookie sent
INFO - 2018-04-01 19:26:13 --> Input Class Initialized
INFO - 2018-04-01 19:26:13 --> Language Class Initialized
INFO - 2018-04-01 19:26:13 --> Loader Class Initialized
INFO - 2018-04-01 19:26:13 --> Helper loaded: url_helper
INFO - 2018-04-01 19:26:13 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:26:13 --> User Agent Class Initialized
INFO - 2018-04-01 19:26:13 --> Controller Class Initialized
INFO - 2018-04-01 19:26:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:26:13 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:26:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:26:13 --> Final output sent to browser
DEBUG - 2018-04-01 19:26:13 --> Total execution time: 0.2465
INFO - 2018-04-01 19:26:13 --> Config Class Initialized
INFO - 2018-04-01 19:26:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:13 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:13 --> URI Class Initialized
INFO - 2018-04-01 19:26:13 --> Router Class Initialized
INFO - 2018-04-01 19:26:13 --> Output Class Initialized
INFO - 2018-04-01 19:26:13 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:13 --> CSRF cookie sent
INFO - 2018-04-01 19:26:13 --> Input Class Initialized
INFO - 2018-04-01 19:26:13 --> Language Class Initialized
ERROR - 2018-04-01 19:26:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:26:13 --> Config Class Initialized
INFO - 2018-04-01 19:26:14 --> Config Class Initialized
INFO - 2018-04-01 19:26:14 --> Hooks Class Initialized
INFO - 2018-04-01 19:26:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:26:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:14 --> URI Class Initialized
INFO - 2018-04-01 19:26:14 --> URI Class Initialized
INFO - 2018-04-01 19:26:14 --> Router Class Initialized
INFO - 2018-04-01 19:26:14 --> Router Class Initialized
INFO - 2018-04-01 19:26:14 --> Output Class Initialized
INFO - 2018-04-01 19:26:14 --> Output Class Initialized
INFO - 2018-04-01 19:26:14 --> Security Class Initialized
INFO - 2018-04-01 19:26:14 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:14 --> CSRF cookie sent
INFO - 2018-04-01 19:26:14 --> CSRF cookie sent
INFO - 2018-04-01 19:26:14 --> Input Class Initialized
INFO - 2018-04-01 19:26:14 --> Input Class Initialized
INFO - 2018-04-01 19:26:14 --> Language Class Initialized
INFO - 2018-04-01 19:26:14 --> Language Class Initialized
ERROR - 2018-04-01 19:26:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-01 19:26:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:26:14 --> Config Class Initialized
INFO - 2018-04-01 19:26:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:14 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:14 --> URI Class Initialized
INFO - 2018-04-01 19:26:14 --> Router Class Initialized
INFO - 2018-04-01 19:26:14 --> Output Class Initialized
INFO - 2018-04-01 19:26:14 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:14 --> CSRF cookie sent
INFO - 2018-04-01 19:26:14 --> Input Class Initialized
INFO - 2018-04-01 19:26:14 --> Language Class Initialized
ERROR - 2018-04-01 19:26:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:26:15 --> Config Class Initialized
INFO - 2018-04-01 19:26:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:15 --> URI Class Initialized
INFO - 2018-04-01 19:26:15 --> Router Class Initialized
INFO - 2018-04-01 19:26:15 --> Output Class Initialized
INFO - 2018-04-01 19:26:15 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:15 --> CSRF cookie sent
INFO - 2018-04-01 19:26:15 --> Input Class Initialized
INFO - 2018-04-01 19:26:15 --> Language Class Initialized
ERROR - 2018-04-01 19:26:15 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:26:53 --> Config Class Initialized
INFO - 2018-04-01 19:26:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:53 --> URI Class Initialized
DEBUG - 2018-04-01 19:26:53 --> No URI present. Default controller set.
INFO - 2018-04-01 19:26:53 --> Router Class Initialized
INFO - 2018-04-01 19:26:53 --> Output Class Initialized
INFO - 2018-04-01 19:26:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:53 --> CSRF cookie sent
INFO - 2018-04-01 19:26:53 --> Input Class Initialized
INFO - 2018-04-01 19:26:53 --> Language Class Initialized
INFO - 2018-04-01 19:26:53 --> Loader Class Initialized
INFO - 2018-04-01 19:26:53 --> Helper loaded: url_helper
INFO - 2018-04-01 19:26:53 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:26:53 --> User Agent Class Initialized
INFO - 2018-04-01 19:26:53 --> Controller Class Initialized
INFO - 2018-04-01 19:26:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:26:53 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:26:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:26:53 --> Final output sent to browser
DEBUG - 2018-04-01 19:26:53 --> Total execution time: 0.2547
INFO - 2018-04-01 19:26:53 --> Config Class Initialized
INFO - 2018-04-01 19:26:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:53 --> URI Class Initialized
INFO - 2018-04-01 19:26:53 --> Router Class Initialized
INFO - 2018-04-01 19:26:53 --> Output Class Initialized
INFO - 2018-04-01 19:26:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:53 --> CSRF cookie sent
INFO - 2018-04-01 19:26:53 --> Input Class Initialized
INFO - 2018-04-01 19:26:53 --> Language Class Initialized
INFO - 2018-04-01 19:26:54 --> Config Class Initialized
INFO - 2018-04-01 19:26:54 --> Config Class Initialized
INFO - 2018-04-01 19:26:54 --> Hooks Class Initialized
INFO - 2018-04-01 19:26:54 --> Hooks Class Initialized
ERROR - 2018-04-01 19:26:54 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-01 19:26:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:26:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:54 --> URI Class Initialized
INFO - 2018-04-01 19:26:54 --> URI Class Initialized
INFO - 2018-04-01 19:26:54 --> Router Class Initialized
INFO - 2018-04-01 19:26:54 --> Router Class Initialized
INFO - 2018-04-01 19:26:54 --> Output Class Initialized
INFO - 2018-04-01 19:26:54 --> Security Class Initialized
INFO - 2018-04-01 19:26:54 --> Output Class Initialized
INFO - 2018-04-01 19:26:54 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:54 --> CSRF cookie sent
DEBUG - 2018-04-01 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:54 --> Input Class Initialized
INFO - 2018-04-01 19:26:54 --> CSRF cookie sent
INFO - 2018-04-01 19:26:54 --> Input Class Initialized
INFO - 2018-04-01 19:26:54 --> Language Class Initialized
INFO - 2018-04-01 19:26:54 --> Language Class Initialized
ERROR - 2018-04-01 19:26:54 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:26:54 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:26:54 --> Config Class Initialized
INFO - 2018-04-01 19:26:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:54 --> URI Class Initialized
INFO - 2018-04-01 19:26:54 --> Router Class Initialized
INFO - 2018-04-01 19:26:54 --> Output Class Initialized
INFO - 2018-04-01 19:26:54 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:54 --> CSRF cookie sent
INFO - 2018-04-01 19:26:54 --> Input Class Initialized
INFO - 2018-04-01 19:26:54 --> Language Class Initialized
ERROR - 2018-04-01 19:26:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:26:55 --> Config Class Initialized
INFO - 2018-04-01 19:26:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:26:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:26:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:26:55 --> URI Class Initialized
INFO - 2018-04-01 19:26:55 --> Router Class Initialized
INFO - 2018-04-01 19:26:55 --> Output Class Initialized
INFO - 2018-04-01 19:26:55 --> Security Class Initialized
DEBUG - 2018-04-01 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:26:55 --> CSRF cookie sent
INFO - 2018-04-01 19:26:55 --> Input Class Initialized
INFO - 2018-04-01 19:26:55 --> Language Class Initialized
ERROR - 2018-04-01 19:26:55 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:27:29 --> Config Class Initialized
INFO - 2018-04-01 19:27:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:29 --> URI Class Initialized
DEBUG - 2018-04-01 19:27:29 --> No URI present. Default controller set.
INFO - 2018-04-01 19:27:29 --> Router Class Initialized
INFO - 2018-04-01 19:27:29 --> Output Class Initialized
INFO - 2018-04-01 19:27:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:29 --> CSRF cookie sent
INFO - 2018-04-01 19:27:29 --> Input Class Initialized
INFO - 2018-04-01 19:27:29 --> Language Class Initialized
INFO - 2018-04-01 19:27:29 --> Loader Class Initialized
INFO - 2018-04-01 19:27:29 --> Helper loaded: url_helper
INFO - 2018-04-01 19:27:29 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:27:29 --> User Agent Class Initialized
INFO - 2018-04-01 19:27:29 --> Controller Class Initialized
INFO - 2018-04-01 19:27:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:27:29 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:27:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:27:30 --> Final output sent to browser
DEBUG - 2018-04-01 19:27:30 --> Total execution time: 0.2482
INFO - 2018-04-01 19:27:30 --> Config Class Initialized
INFO - 2018-04-01 19:27:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:30 --> Config Class Initialized
INFO - 2018-04-01 19:27:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:30 --> Hooks Class Initialized
INFO - 2018-04-01 19:27:30 --> URI Class Initialized
DEBUG - 2018-04-01 19:27:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:30 --> Router Class Initialized
INFO - 2018-04-01 19:27:30 --> URI Class Initialized
INFO - 2018-04-01 19:27:30 --> Output Class Initialized
INFO - 2018-04-01 19:27:30 --> Security Class Initialized
INFO - 2018-04-01 19:27:30 --> Router Class Initialized
DEBUG - 2018-04-01 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:30 --> Output Class Initialized
INFO - 2018-04-01 19:27:30 --> CSRF cookie sent
INFO - 2018-04-01 19:27:30 --> Security Class Initialized
INFO - 2018-04-01 19:27:30 --> Input Class Initialized
DEBUG - 2018-04-01 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:30 --> CSRF cookie sent
INFO - 2018-04-01 19:27:30 --> Language Class Initialized
INFO - 2018-04-01 19:27:30 --> Input Class Initialized
ERROR - 2018-04-01 19:27:30 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:27:30 --> Language Class Initialized
ERROR - 2018-04-01 19:27:30 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:27:30 --> Config Class Initialized
INFO - 2018-04-01 19:27:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:30 --> URI Class Initialized
INFO - 2018-04-01 19:27:30 --> Router Class Initialized
INFO - 2018-04-01 19:27:30 --> Output Class Initialized
INFO - 2018-04-01 19:27:30 --> Security Class Initialized
DEBUG - 2018-04-01 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:30 --> CSRF cookie sent
INFO - 2018-04-01 19:27:30 --> Input Class Initialized
INFO - 2018-04-01 19:27:30 --> Language Class Initialized
ERROR - 2018-04-01 19:27:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:27:30 --> Config Class Initialized
INFO - 2018-04-01 19:27:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:30 --> URI Class Initialized
INFO - 2018-04-01 19:27:30 --> Router Class Initialized
INFO - 2018-04-01 19:27:31 --> Output Class Initialized
INFO - 2018-04-01 19:27:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:31 --> CSRF cookie sent
INFO - 2018-04-01 19:27:31 --> Input Class Initialized
INFO - 2018-04-01 19:27:31 --> Language Class Initialized
ERROR - 2018-04-01 19:27:31 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:27:32 --> Config Class Initialized
INFO - 2018-04-01 19:27:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:32 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:32 --> URI Class Initialized
INFO - 2018-04-01 19:27:32 --> Router Class Initialized
INFO - 2018-04-01 19:27:32 --> Output Class Initialized
INFO - 2018-04-01 19:27:32 --> Security Class Initialized
DEBUG - 2018-04-01 19:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:32 --> CSRF cookie sent
INFO - 2018-04-01 19:27:32 --> Input Class Initialized
INFO - 2018-04-01 19:27:32 --> Language Class Initialized
ERROR - 2018-04-01 19:27:32 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:27:59 --> Config Class Initialized
INFO - 2018-04-01 19:27:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:27:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:27:59 --> Utf8 Class Initialized
INFO - 2018-04-01 19:27:59 --> URI Class Initialized
DEBUG - 2018-04-01 19:27:59 --> No URI present. Default controller set.
INFO - 2018-04-01 19:27:59 --> Router Class Initialized
INFO - 2018-04-01 19:27:59 --> Output Class Initialized
INFO - 2018-04-01 19:27:59 --> Security Class Initialized
DEBUG - 2018-04-01 19:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:27:59 --> CSRF cookie sent
INFO - 2018-04-01 19:27:59 --> Input Class Initialized
INFO - 2018-04-01 19:27:59 --> Language Class Initialized
INFO - 2018-04-01 19:27:59 --> Loader Class Initialized
INFO - 2018-04-01 19:27:59 --> Helper loaded: url_helper
INFO - 2018-04-01 19:27:59 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:27:59 --> User Agent Class Initialized
INFO - 2018-04-01 19:27:59 --> Controller Class Initialized
INFO - 2018-04-01 19:27:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:27:59 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:27:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:27:59 --> Final output sent to browser
DEBUG - 2018-04-01 19:27:59 --> Total execution time: 0.2384
INFO - 2018-04-01 19:28:00 --> Config Class Initialized
INFO - 2018-04-01 19:28:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:28:00 --> Config Class Initialized
INFO - 2018-04-01 19:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:28:00 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:28:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:28:00 --> URI Class Initialized
INFO - 2018-04-01 19:28:00 --> URI Class Initialized
INFO - 2018-04-01 19:28:00 --> Router Class Initialized
INFO - 2018-04-01 19:28:00 --> Output Class Initialized
INFO - 2018-04-01 19:28:00 --> Router Class Initialized
INFO - 2018-04-01 19:28:00 --> Security Class Initialized
INFO - 2018-04-01 19:28:00 --> Output Class Initialized
INFO - 2018-04-01 19:28:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:28:00 --> CSRF cookie sent
DEBUG - 2018-04-01 19:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:28:00 --> Input Class Initialized
INFO - 2018-04-01 19:28:00 --> CSRF cookie sent
INFO - 2018-04-01 19:28:00 --> Input Class Initialized
INFO - 2018-04-01 19:28:00 --> Language Class Initialized
INFO - 2018-04-01 19:28:00 --> Language Class Initialized
ERROR - 2018-04-01 19:28:00 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:28:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:28:00 --> Config Class Initialized
INFO - 2018-04-01 19:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:28:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:28:00 --> URI Class Initialized
INFO - 2018-04-01 19:28:00 --> Router Class Initialized
INFO - 2018-04-01 19:28:00 --> Output Class Initialized
INFO - 2018-04-01 19:28:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:28:00 --> CSRF cookie sent
INFO - 2018-04-01 19:28:00 --> Input Class Initialized
INFO - 2018-04-01 19:28:00 --> Language Class Initialized
ERROR - 2018-04-01 19:28:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:28:00 --> Config Class Initialized
INFO - 2018-04-01 19:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:28:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:28:00 --> URI Class Initialized
INFO - 2018-04-01 19:28:00 --> Router Class Initialized
INFO - 2018-04-01 19:28:00 --> Output Class Initialized
INFO - 2018-04-01 19:28:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:28:00 --> CSRF cookie sent
INFO - 2018-04-01 19:28:00 --> Input Class Initialized
INFO - 2018-04-01 19:28:00 --> Language Class Initialized
ERROR - 2018-04-01 19:28:01 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:28:01 --> Config Class Initialized
INFO - 2018-04-01 19:28:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:28:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:28:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:28:02 --> URI Class Initialized
INFO - 2018-04-01 19:28:02 --> Router Class Initialized
INFO - 2018-04-01 19:28:02 --> Output Class Initialized
INFO - 2018-04-01 19:28:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:28:02 --> CSRF cookie sent
INFO - 2018-04-01 19:28:02 --> Input Class Initialized
INFO - 2018-04-01 19:28:02 --> Language Class Initialized
ERROR - 2018-04-01 19:28:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:29:57 --> Config Class Initialized
INFO - 2018-04-01 19:29:57 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:29:57 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:57 --> Utf8 Class Initialized
INFO - 2018-04-01 19:29:57 --> URI Class Initialized
DEBUG - 2018-04-01 19:29:57 --> No URI present. Default controller set.
INFO - 2018-04-01 19:29:57 --> Router Class Initialized
INFO - 2018-04-01 19:29:57 --> Output Class Initialized
INFO - 2018-04-01 19:29:57 --> Security Class Initialized
DEBUG - 2018-04-01 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:57 --> CSRF cookie sent
INFO - 2018-04-01 19:29:57 --> Input Class Initialized
INFO - 2018-04-01 19:29:57 --> Language Class Initialized
INFO - 2018-04-01 19:29:57 --> Loader Class Initialized
INFO - 2018-04-01 19:29:57 --> Helper loaded: url_helper
INFO - 2018-04-01 19:29:57 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:29:57 --> User Agent Class Initialized
INFO - 2018-04-01 19:29:57 --> Controller Class Initialized
INFO - 2018-04-01 19:29:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:29:57 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:29:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:29:57 --> Final output sent to browser
DEBUG - 2018-04-01 19:29:57 --> Total execution time: 0.2421
INFO - 2018-04-01 19:29:57 --> Config Class Initialized
INFO - 2018-04-01 19:29:57 --> Hooks Class Initialized
INFO - 2018-04-01 19:29:57 --> Config Class Initialized
DEBUG - 2018-04-01 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:58 --> Hooks Class Initialized
INFO - 2018-04-01 19:29:58 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:58 --> Utf8 Class Initialized
INFO - 2018-04-01 19:29:58 --> URI Class Initialized
INFO - 2018-04-01 19:29:58 --> URI Class Initialized
INFO - 2018-04-01 19:29:58 --> Router Class Initialized
INFO - 2018-04-01 19:29:58 --> Router Class Initialized
INFO - 2018-04-01 19:29:58 --> Output Class Initialized
INFO - 2018-04-01 19:29:58 --> Security Class Initialized
INFO - 2018-04-01 19:29:58 --> Output Class Initialized
INFO - 2018-04-01 19:29:58 --> Security Class Initialized
DEBUG - 2018-04-01 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:58 --> CSRF cookie sent
DEBUG - 2018-04-01 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:58 --> Input Class Initialized
INFO - 2018-04-01 19:29:58 --> CSRF cookie sent
INFO - 2018-04-01 19:29:58 --> Input Class Initialized
INFO - 2018-04-01 19:29:58 --> Language Class Initialized
INFO - 2018-04-01 19:29:58 --> Language Class Initialized
ERROR - 2018-04-01 19:29:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-01 19:29:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:29:58 --> Config Class Initialized
INFO - 2018-04-01 19:29:58 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:58 --> Utf8 Class Initialized
INFO - 2018-04-01 19:29:58 --> URI Class Initialized
INFO - 2018-04-01 19:29:58 --> Router Class Initialized
INFO - 2018-04-01 19:29:58 --> Output Class Initialized
INFO - 2018-04-01 19:29:58 --> Security Class Initialized
DEBUG - 2018-04-01 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:58 --> CSRF cookie sent
INFO - 2018-04-01 19:29:58 --> Input Class Initialized
INFO - 2018-04-01 19:29:58 --> Language Class Initialized
ERROR - 2018-04-01 19:29:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:29:58 --> Config Class Initialized
INFO - 2018-04-01 19:29:58 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:58 --> Utf8 Class Initialized
INFO - 2018-04-01 19:29:58 --> URI Class Initialized
INFO - 2018-04-01 19:29:58 --> Router Class Initialized
INFO - 2018-04-01 19:29:58 --> Output Class Initialized
INFO - 2018-04-01 19:29:58 --> Security Class Initialized
DEBUG - 2018-04-01 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:58 --> CSRF cookie sent
INFO - 2018-04-01 19:29:58 --> Input Class Initialized
INFO - 2018-04-01 19:29:58 --> Language Class Initialized
ERROR - 2018-04-01 19:29:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:29:59 --> Config Class Initialized
INFO - 2018-04-01 19:29:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:29:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:29:59 --> Utf8 Class Initialized
INFO - 2018-04-01 19:29:59 --> URI Class Initialized
INFO - 2018-04-01 19:29:59 --> Router Class Initialized
INFO - 2018-04-01 19:29:59 --> Output Class Initialized
INFO - 2018-04-01 19:29:59 --> Security Class Initialized
DEBUG - 2018-04-01 19:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:29:59 --> CSRF cookie sent
INFO - 2018-04-01 19:29:59 --> Input Class Initialized
INFO - 2018-04-01 19:30:00 --> Language Class Initialized
ERROR - 2018-04-01 19:30:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:00 --> Config Class Initialized
INFO - 2018-04-01 19:30:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:00 --> URI Class Initialized
DEBUG - 2018-04-01 19:30:00 --> No URI present. Default controller set.
INFO - 2018-04-01 19:30:00 --> Router Class Initialized
INFO - 2018-04-01 19:30:00 --> Output Class Initialized
INFO - 2018-04-01 19:30:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:00 --> CSRF cookie sent
INFO - 2018-04-01 19:30:00 --> Input Class Initialized
INFO - 2018-04-01 19:30:00 --> Language Class Initialized
INFO - 2018-04-01 19:30:00 --> Loader Class Initialized
INFO - 2018-04-01 19:30:00 --> Helper loaded: url_helper
INFO - 2018-04-01 19:30:00 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:30:01 --> User Agent Class Initialized
INFO - 2018-04-01 19:30:01 --> Controller Class Initialized
INFO - 2018-04-01 19:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:30:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:30:01 --> Final output sent to browser
DEBUG - 2018-04-01 19:30:01 --> Total execution time: 0.2614
INFO - 2018-04-01 19:30:01 --> Config Class Initialized
INFO - 2018-04-01 19:30:01 --> Config Class Initialized
INFO - 2018-04-01 19:30:01 --> Hooks Class Initialized
INFO - 2018-04-01 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:01 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:01 --> URI Class Initialized
INFO - 2018-04-01 19:30:01 --> URI Class Initialized
INFO - 2018-04-01 19:30:01 --> Router Class Initialized
INFO - 2018-04-01 19:30:01 --> Output Class Initialized
INFO - 2018-04-01 19:30:01 --> Router Class Initialized
INFO - 2018-04-01 19:30:01 --> Security Class Initialized
INFO - 2018-04-01 19:30:01 --> Output Class Initialized
INFO - 2018-04-01 19:30:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:01 --> CSRF cookie sent
DEBUG - 2018-04-01 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:01 --> CSRF cookie sent
INFO - 2018-04-01 19:30:01 --> Input Class Initialized
INFO - 2018-04-01 19:30:01 --> Input Class Initialized
INFO - 2018-04-01 19:30:01 --> Language Class Initialized
ERROR - 2018-04-01 19:30:01 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:30:01 --> Language Class Initialized
ERROR - 2018-04-01 19:30:01 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:01 --> Config Class Initialized
INFO - 2018-04-01 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:01 --> URI Class Initialized
INFO - 2018-04-01 19:30:01 --> Router Class Initialized
INFO - 2018-04-01 19:30:01 --> Output Class Initialized
INFO - 2018-04-01 19:30:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:01 --> CSRF cookie sent
INFO - 2018-04-01 19:30:01 --> Input Class Initialized
INFO - 2018-04-01 19:30:01 --> Language Class Initialized
ERROR - 2018-04-01 19:30:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:30:01 --> Config Class Initialized
INFO - 2018-04-01 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:02 --> URI Class Initialized
INFO - 2018-04-01 19:30:02 --> Router Class Initialized
INFO - 2018-04-01 19:30:02 --> Output Class Initialized
INFO - 2018-04-01 19:30:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:02 --> CSRF cookie sent
INFO - 2018-04-01 19:30:02 --> Input Class Initialized
INFO - 2018-04-01 19:30:02 --> Language Class Initialized
ERROR - 2018-04-01 19:30:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:02 --> Config Class Initialized
INFO - 2018-04-01 19:30:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:02 --> URI Class Initialized
DEBUG - 2018-04-01 19:30:02 --> No URI present. Default controller set.
INFO - 2018-04-01 19:30:02 --> Router Class Initialized
INFO - 2018-04-01 19:30:02 --> Output Class Initialized
INFO - 2018-04-01 19:30:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:02 --> CSRF cookie sent
INFO - 2018-04-01 19:30:02 --> Input Class Initialized
INFO - 2018-04-01 19:30:02 --> Language Class Initialized
INFO - 2018-04-01 19:30:03 --> Loader Class Initialized
INFO - 2018-04-01 19:30:03 --> Helper loaded: url_helper
INFO - 2018-04-01 19:30:03 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:30:03 --> User Agent Class Initialized
INFO - 2018-04-01 19:30:03 --> Controller Class Initialized
INFO - 2018-04-01 19:30:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:30:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:30:03 --> Config Class Initialized
INFO - 2018-04-01 19:30:03 --> Hooks Class Initialized
INFO - 2018-04-01 19:30:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:30:03 --> Final output sent to browser
DEBUG - 2018-04-01 19:30:03 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:30:03 --> Total execution time: 0.3403
INFO - 2018-04-01 19:30:03 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:03 --> URI Class Initialized
INFO - 2018-04-01 19:30:03 --> Router Class Initialized
INFO - 2018-04-01 19:30:03 --> Output Class Initialized
INFO - 2018-04-01 19:30:03 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:03 --> Config Class Initialized
INFO - 2018-04-01 19:30:03 --> Hooks Class Initialized
INFO - 2018-04-01 19:30:03 --> CSRF cookie sent
INFO - 2018-04-01 19:30:03 --> Input Class Initialized
DEBUG - 2018-04-01 19:30:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:03 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:03 --> Language Class Initialized
INFO - 2018-04-01 19:30:03 --> Config Class Initialized
INFO - 2018-04-01 19:30:03 --> Hooks Class Initialized
INFO - 2018-04-01 19:30:03 --> URI Class Initialized
ERROR - 2018-04-01 19:30:03 --> 404 Page Not Found: Revolution/assets
DEBUG - 2018-04-01 19:30:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:03 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:03 --> URI Class Initialized
INFO - 2018-04-01 19:30:03 --> Router Class Initialized
INFO - 2018-04-01 19:30:03 --> Router Class Initialized
INFO - 2018-04-01 19:30:03 --> Output Class Initialized
INFO - 2018-04-01 19:30:03 --> Output Class Initialized
INFO - 2018-04-01 19:30:03 --> Security Class Initialized
INFO - 2018-04-01 19:30:03 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:03 --> CSRF cookie sent
INFO - 2018-04-01 19:30:03 --> CSRF cookie sent
INFO - 2018-04-01 19:30:03 --> Input Class Initialized
INFO - 2018-04-01 19:30:03 --> Input Class Initialized
INFO - 2018-04-01 19:30:03 --> Language Class Initialized
INFO - 2018-04-01 19:30:03 --> Language Class Initialized
ERROR - 2018-04-01 19:30:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-01 19:30:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:03 --> Config Class Initialized
INFO - 2018-04-01 19:30:03 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:03 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:03 --> URI Class Initialized
INFO - 2018-04-01 19:30:03 --> Router Class Initialized
INFO - 2018-04-01 19:30:03 --> Output Class Initialized
INFO - 2018-04-01 19:30:03 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:03 --> CSRF cookie sent
INFO - 2018-04-01 19:30:03 --> Input Class Initialized
INFO - 2018-04-01 19:30:03 --> Language Class Initialized
ERROR - 2018-04-01 19:30:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:30:04 --> Config Class Initialized
INFO - 2018-04-01 19:30:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:04 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:04 --> URI Class Initialized
INFO - 2018-04-01 19:30:04 --> Router Class Initialized
INFO - 2018-04-01 19:30:04 --> Output Class Initialized
INFO - 2018-04-01 19:30:04 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:04 --> CSRF cookie sent
INFO - 2018-04-01 19:30:04 --> Input Class Initialized
INFO - 2018-04-01 19:30:04 --> Language Class Initialized
ERROR - 2018-04-01 19:30:04 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:05 --> Config Class Initialized
INFO - 2018-04-01 19:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:05 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:05 --> URI Class Initialized
INFO - 2018-04-01 19:30:05 --> Router Class Initialized
INFO - 2018-04-01 19:30:05 --> Output Class Initialized
INFO - 2018-04-01 19:30:05 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:05 --> CSRF cookie sent
INFO - 2018-04-01 19:30:05 --> Input Class Initialized
INFO - 2018-04-01 19:30:05 --> Language Class Initialized
ERROR - 2018-04-01 19:30:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:20 --> Config Class Initialized
INFO - 2018-04-01 19:30:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:20 --> URI Class Initialized
DEBUG - 2018-04-01 19:30:20 --> No URI present. Default controller set.
INFO - 2018-04-01 19:30:20 --> Router Class Initialized
INFO - 2018-04-01 19:30:20 --> Output Class Initialized
INFO - 2018-04-01 19:30:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:20 --> CSRF cookie sent
INFO - 2018-04-01 19:30:20 --> Input Class Initialized
INFO - 2018-04-01 19:30:20 --> Language Class Initialized
INFO - 2018-04-01 19:30:20 --> Loader Class Initialized
INFO - 2018-04-01 19:30:20 --> Helper loaded: url_helper
INFO - 2018-04-01 19:30:20 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:30:20 --> User Agent Class Initialized
INFO - 2018-04-01 19:30:20 --> Controller Class Initialized
INFO - 2018-04-01 19:30:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:30:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:30:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:30:20 --> Final output sent to browser
DEBUG - 2018-04-01 19:30:20 --> Total execution time: 0.2497
INFO - 2018-04-01 19:30:20 --> Config Class Initialized
INFO - 2018-04-01 19:30:20 --> Hooks Class Initialized
INFO - 2018-04-01 19:30:20 --> Config Class Initialized
INFO - 2018-04-01 19:30:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:20 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:30:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:20 --> URI Class Initialized
INFO - 2018-04-01 19:30:20 --> URI Class Initialized
INFO - 2018-04-01 19:30:20 --> Router Class Initialized
INFO - 2018-04-01 19:30:20 --> Router Class Initialized
INFO - 2018-04-01 19:30:20 --> Output Class Initialized
INFO - 2018-04-01 19:30:20 --> Security Class Initialized
INFO - 2018-04-01 19:30:20 --> Output Class Initialized
INFO - 2018-04-01 19:30:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:20 --> CSRF cookie sent
DEBUG - 2018-04-01 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:20 --> Input Class Initialized
INFO - 2018-04-01 19:30:20 --> CSRF cookie sent
INFO - 2018-04-01 19:30:20 --> Input Class Initialized
INFO - 2018-04-01 19:30:20 --> Language Class Initialized
INFO - 2018-04-01 19:30:20 --> Language Class Initialized
ERROR - 2018-04-01 19:30:20 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:30:20 --> Config Class Initialized
ERROR - 2018-04-01 19:30:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:20 --> URI Class Initialized
INFO - 2018-04-01 19:30:20 --> Router Class Initialized
INFO - 2018-04-01 19:30:21 --> Output Class Initialized
INFO - 2018-04-01 19:30:21 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:21 --> CSRF cookie sent
INFO - 2018-04-01 19:30:21 --> Input Class Initialized
INFO - 2018-04-01 19:30:21 --> Language Class Initialized
ERROR - 2018-04-01 19:30:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:30:21 --> Config Class Initialized
INFO - 2018-04-01 19:30:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:21 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:21 --> URI Class Initialized
INFO - 2018-04-01 19:30:21 --> Router Class Initialized
INFO - 2018-04-01 19:30:21 --> Output Class Initialized
INFO - 2018-04-01 19:30:21 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:21 --> CSRF cookie sent
INFO - 2018-04-01 19:30:21 --> Input Class Initialized
INFO - 2018-04-01 19:30:21 --> Language Class Initialized
ERROR - 2018-04-01 19:30:21 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:30:22 --> Config Class Initialized
INFO - 2018-04-01 19:30:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:30:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:30:22 --> Utf8 Class Initialized
INFO - 2018-04-01 19:30:22 --> URI Class Initialized
INFO - 2018-04-01 19:30:22 --> Router Class Initialized
INFO - 2018-04-01 19:30:22 --> Output Class Initialized
INFO - 2018-04-01 19:30:22 --> Security Class Initialized
DEBUG - 2018-04-01 19:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:30:22 --> CSRF cookie sent
INFO - 2018-04-01 19:30:22 --> Input Class Initialized
INFO - 2018-04-01 19:30:22 --> Language Class Initialized
ERROR - 2018-04-01 19:30:22 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:18 --> Config Class Initialized
INFO - 2018-04-01 19:31:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:18 --> URI Class Initialized
DEBUG - 2018-04-01 19:31:18 --> No URI present. Default controller set.
INFO - 2018-04-01 19:31:18 --> Router Class Initialized
INFO - 2018-04-01 19:31:18 --> Output Class Initialized
INFO - 2018-04-01 19:31:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:18 --> CSRF cookie sent
INFO - 2018-04-01 19:31:18 --> Input Class Initialized
INFO - 2018-04-01 19:31:18 --> Language Class Initialized
INFO - 2018-04-01 19:31:18 --> Loader Class Initialized
INFO - 2018-04-01 19:31:18 --> Helper loaded: url_helper
INFO - 2018-04-01 19:31:18 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:31:18 --> User Agent Class Initialized
INFO - 2018-04-01 19:31:18 --> Controller Class Initialized
INFO - 2018-04-01 19:31:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:31:18 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:31:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:31:18 --> Final output sent to browser
DEBUG - 2018-04-01 19:31:18 --> Total execution time: 0.2496
INFO - 2018-04-01 19:31:18 --> Config Class Initialized
INFO - 2018-04-01 19:31:18 --> Config Class Initialized
INFO - 2018-04-01 19:31:18 --> Hooks Class Initialized
INFO - 2018-04-01 19:31:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:18 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:31:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:18 --> URI Class Initialized
INFO - 2018-04-01 19:31:18 --> URI Class Initialized
INFO - 2018-04-01 19:31:18 --> Router Class Initialized
INFO - 2018-04-01 19:31:18 --> Router Class Initialized
INFO - 2018-04-01 19:31:18 --> Output Class Initialized
INFO - 2018-04-01 19:31:18 --> Output Class Initialized
INFO - 2018-04-01 19:31:18 --> Security Class Initialized
INFO - 2018-04-01 19:31:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:18 --> CSRF cookie sent
INFO - 2018-04-01 19:31:18 --> CSRF cookie sent
INFO - 2018-04-01 19:31:18 --> Input Class Initialized
INFO - 2018-04-01 19:31:18 --> Input Class Initialized
INFO - 2018-04-01 19:31:18 --> Language Class Initialized
INFO - 2018-04-01 19:31:18 --> Language Class Initialized
ERROR - 2018-04-01 19:31:18 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-01 19:31:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:18 --> Config Class Initialized
INFO - 2018-04-01 19:31:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:18 --> URI Class Initialized
INFO - 2018-04-01 19:31:18 --> Router Class Initialized
INFO - 2018-04-01 19:31:18 --> Output Class Initialized
INFO - 2018-04-01 19:31:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:19 --> CSRF cookie sent
INFO - 2018-04-01 19:31:19 --> Input Class Initialized
INFO - 2018-04-01 19:31:19 --> Language Class Initialized
ERROR - 2018-04-01 19:31:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:31:19 --> Config Class Initialized
INFO - 2018-04-01 19:31:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:19 --> URI Class Initialized
INFO - 2018-04-01 19:31:19 --> Router Class Initialized
INFO - 2018-04-01 19:31:19 --> Output Class Initialized
INFO - 2018-04-01 19:31:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:19 --> CSRF cookie sent
INFO - 2018-04-01 19:31:19 --> Input Class Initialized
INFO - 2018-04-01 19:31:19 --> Language Class Initialized
ERROR - 2018-04-01 19:31:19 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:20 --> Config Class Initialized
INFO - 2018-04-01 19:31:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:20 --> URI Class Initialized
INFO - 2018-04-01 19:31:20 --> Router Class Initialized
INFO - 2018-04-01 19:31:20 --> Output Class Initialized
INFO - 2018-04-01 19:31:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:20 --> CSRF cookie sent
INFO - 2018-04-01 19:31:20 --> Input Class Initialized
INFO - 2018-04-01 19:31:20 --> Language Class Initialized
ERROR - 2018-04-01 19:31:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:41 --> Config Class Initialized
INFO - 2018-04-01 19:31:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:41 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:41 --> URI Class Initialized
DEBUG - 2018-04-01 19:31:41 --> No URI present. Default controller set.
INFO - 2018-04-01 19:31:41 --> Router Class Initialized
INFO - 2018-04-01 19:31:41 --> Output Class Initialized
INFO - 2018-04-01 19:31:41 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:41 --> CSRF cookie sent
INFO - 2018-04-01 19:31:41 --> Input Class Initialized
INFO - 2018-04-01 19:31:41 --> Language Class Initialized
INFO - 2018-04-01 19:31:41 --> Loader Class Initialized
INFO - 2018-04-01 19:31:41 --> Helper loaded: url_helper
INFO - 2018-04-01 19:31:41 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:31:41 --> User Agent Class Initialized
INFO - 2018-04-01 19:31:41 --> Controller Class Initialized
INFO - 2018-04-01 19:31:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:31:41 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:31:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:31:41 --> Final output sent to browser
DEBUG - 2018-04-01 19:31:41 --> Total execution time: 0.2588
INFO - 2018-04-01 19:31:41 --> Config Class Initialized
INFO - 2018-04-01 19:31:41 --> Hooks Class Initialized
INFO - 2018-04-01 19:31:41 --> Config Class Initialized
INFO - 2018-04-01 19:31:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:31:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:41 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:41 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:41 --> URI Class Initialized
INFO - 2018-04-01 19:31:41 --> URI Class Initialized
INFO - 2018-04-01 19:31:42 --> Router Class Initialized
INFO - 2018-04-01 19:31:42 --> Router Class Initialized
INFO - 2018-04-01 19:31:42 --> Output Class Initialized
INFO - 2018-04-01 19:31:42 --> Output Class Initialized
INFO - 2018-04-01 19:31:42 --> Security Class Initialized
INFO - 2018-04-01 19:31:42 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:42 --> CSRF cookie sent
INFO - 2018-04-01 19:31:42 --> CSRF cookie sent
INFO - 2018-04-01 19:31:42 --> Input Class Initialized
INFO - 2018-04-01 19:31:42 --> Input Class Initialized
INFO - 2018-04-01 19:31:42 --> Language Class Initialized
INFO - 2018-04-01 19:31:42 --> Language Class Initialized
ERROR - 2018-04-01 19:31:42 --> 404 Page Not Found: Revolution/assets
ERROR - 2018-04-01 19:31:42 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:31:42 --> Config Class Initialized
INFO - 2018-04-01 19:31:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:42 --> URI Class Initialized
INFO - 2018-04-01 19:31:42 --> Router Class Initialized
INFO - 2018-04-01 19:31:42 --> Output Class Initialized
INFO - 2018-04-01 19:31:42 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:42 --> CSRF cookie sent
INFO - 2018-04-01 19:31:42 --> Input Class Initialized
INFO - 2018-04-01 19:31:42 --> Language Class Initialized
ERROR - 2018-04-01 19:31:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:31:42 --> Config Class Initialized
INFO - 2018-04-01 19:31:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:42 --> URI Class Initialized
INFO - 2018-04-01 19:31:42 --> Router Class Initialized
INFO - 2018-04-01 19:31:42 --> Output Class Initialized
INFO - 2018-04-01 19:31:42 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:42 --> CSRF cookie sent
INFO - 2018-04-01 19:31:42 --> Input Class Initialized
INFO - 2018-04-01 19:31:42 --> Language Class Initialized
ERROR - 2018-04-01 19:31:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:44 --> Config Class Initialized
INFO - 2018-04-01 19:31:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:44 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:44 --> URI Class Initialized
INFO - 2018-04-01 19:31:44 --> Router Class Initialized
INFO - 2018-04-01 19:31:44 --> Output Class Initialized
INFO - 2018-04-01 19:31:44 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:44 --> CSRF cookie sent
INFO - 2018-04-01 19:31:44 --> Input Class Initialized
INFO - 2018-04-01 19:31:44 --> Language Class Initialized
ERROR - 2018-04-01 19:31:44 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:54 --> Config Class Initialized
INFO - 2018-04-01 19:31:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:54 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:54 --> URI Class Initialized
DEBUG - 2018-04-01 19:31:54 --> No URI present. Default controller set.
INFO - 2018-04-01 19:31:54 --> Router Class Initialized
INFO - 2018-04-01 19:31:54 --> Output Class Initialized
INFO - 2018-04-01 19:31:54 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:54 --> CSRF cookie sent
INFO - 2018-04-01 19:31:54 --> Input Class Initialized
INFO - 2018-04-01 19:31:54 --> Language Class Initialized
INFO - 2018-04-01 19:31:54 --> Loader Class Initialized
INFO - 2018-04-01 19:31:54 --> Helper loaded: url_helper
INFO - 2018-04-01 19:31:54 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:31:54 --> User Agent Class Initialized
INFO - 2018-04-01 19:31:55 --> Controller Class Initialized
INFO - 2018-04-01 19:31:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:31:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:31:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:31:55 --> Final output sent to browser
DEBUG - 2018-04-01 19:31:55 --> Total execution time: 0.2560
INFO - 2018-04-01 19:31:55 --> Config Class Initialized
INFO - 2018-04-01 19:31:55 --> Config Class Initialized
INFO - 2018-04-01 19:31:55 --> Hooks Class Initialized
INFO - 2018-04-01 19:31:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:31:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:55 --> URI Class Initialized
INFO - 2018-04-01 19:31:55 --> URI Class Initialized
INFO - 2018-04-01 19:31:55 --> Router Class Initialized
INFO - 2018-04-01 19:31:55 --> Router Class Initialized
INFO - 2018-04-01 19:31:55 --> Output Class Initialized
INFO - 2018-04-01 19:31:55 --> Output Class Initialized
INFO - 2018-04-01 19:31:55 --> Security Class Initialized
INFO - 2018-04-01 19:31:55 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:55 --> CSRF cookie sent
INFO - 2018-04-01 19:31:55 --> CSRF cookie sent
INFO - 2018-04-01 19:31:55 --> Input Class Initialized
INFO - 2018-04-01 19:31:55 --> Input Class Initialized
INFO - 2018-04-01 19:31:55 --> Language Class Initialized
INFO - 2018-04-01 19:31:55 --> Language Class Initialized
ERROR - 2018-04-01 19:31:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-01 19:31:55 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:55 --> Config Class Initialized
INFO - 2018-04-01 19:31:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:55 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:55 --> URI Class Initialized
INFO - 2018-04-01 19:31:55 --> Router Class Initialized
INFO - 2018-04-01 19:31:55 --> Output Class Initialized
INFO - 2018-04-01 19:31:55 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:55 --> CSRF cookie sent
INFO - 2018-04-01 19:31:55 --> Input Class Initialized
INFO - 2018-04-01 19:31:55 --> Language Class Initialized
ERROR - 2018-04-01 19:31:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:31:55 --> Config Class Initialized
INFO - 2018-04-01 19:31:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:56 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:56 --> URI Class Initialized
INFO - 2018-04-01 19:31:56 --> Router Class Initialized
INFO - 2018-04-01 19:31:56 --> Output Class Initialized
INFO - 2018-04-01 19:31:56 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:56 --> CSRF cookie sent
INFO - 2018-04-01 19:31:56 --> Input Class Initialized
INFO - 2018-04-01 19:31:56 --> Language Class Initialized
ERROR - 2018-04-01 19:31:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:31:57 --> Config Class Initialized
INFO - 2018-04-01 19:31:57 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:31:57 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:31:57 --> Utf8 Class Initialized
INFO - 2018-04-01 19:31:57 --> URI Class Initialized
INFO - 2018-04-01 19:31:57 --> Router Class Initialized
INFO - 2018-04-01 19:31:57 --> Output Class Initialized
INFO - 2018-04-01 19:31:57 --> Security Class Initialized
DEBUG - 2018-04-01 19:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:31:57 --> CSRF cookie sent
INFO - 2018-04-01 19:31:57 --> Input Class Initialized
INFO - 2018-04-01 19:31:57 --> Language Class Initialized
ERROR - 2018-04-01 19:31:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:35:47 --> Config Class Initialized
INFO - 2018-04-01 19:35:47 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:35:47 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:35:47 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:47 --> URI Class Initialized
DEBUG - 2018-04-01 19:35:47 --> No URI present. Default controller set.
INFO - 2018-04-01 19:35:47 --> Router Class Initialized
INFO - 2018-04-01 19:35:47 --> Output Class Initialized
INFO - 2018-04-01 19:35:47 --> Security Class Initialized
DEBUG - 2018-04-01 19:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:47 --> CSRF cookie sent
INFO - 2018-04-01 19:35:47 --> Input Class Initialized
INFO - 2018-04-01 19:35:47 --> Language Class Initialized
INFO - 2018-04-01 19:35:47 --> Loader Class Initialized
INFO - 2018-04-01 19:35:47 --> Helper loaded: url_helper
INFO - 2018-04-01 19:35:47 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:35:47 --> User Agent Class Initialized
INFO - 2018-04-01 19:35:47 --> Controller Class Initialized
INFO - 2018-04-01 19:35:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:35:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:35:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:35:47 --> Final output sent to browser
DEBUG - 2018-04-01 19:35:47 --> Total execution time: 0.3006
INFO - 2018-04-01 19:35:47 --> Config Class Initialized
INFO - 2018-04-01 19:35:47 --> Hooks Class Initialized
INFO - 2018-04-01 19:35:47 --> Config Class Initialized
INFO - 2018-04-01 19:35:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:35:48 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:35:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:35:48 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:48 --> URI Class Initialized
INFO - 2018-04-01 19:35:48 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:48 --> Router Class Initialized
INFO - 2018-04-01 19:35:48 --> URI Class Initialized
INFO - 2018-04-01 19:35:48 --> Output Class Initialized
INFO - 2018-04-01 19:35:48 --> Security Class Initialized
INFO - 2018-04-01 19:35:48 --> Router Class Initialized
DEBUG - 2018-04-01 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:48 --> Output Class Initialized
INFO - 2018-04-01 19:35:48 --> CSRF cookie sent
INFO - 2018-04-01 19:35:48 --> Security Class Initialized
INFO - 2018-04-01 19:35:48 --> Input Class Initialized
DEBUG - 2018-04-01 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:48 --> CSRF cookie sent
INFO - 2018-04-01 19:35:48 --> Language Class Initialized
INFO - 2018-04-01 19:35:48 --> Input Class Initialized
ERROR - 2018-04-01 19:35:48 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:35:48 --> Language Class Initialized
ERROR - 2018-04-01 19:35:48 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:35:48 --> Config Class Initialized
INFO - 2018-04-01 19:35:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:35:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:35:48 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:48 --> URI Class Initialized
INFO - 2018-04-01 19:35:48 --> Router Class Initialized
INFO - 2018-04-01 19:35:48 --> Output Class Initialized
INFO - 2018-04-01 19:35:48 --> Security Class Initialized
DEBUG - 2018-04-01 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:48 --> CSRF cookie sent
INFO - 2018-04-01 19:35:48 --> Input Class Initialized
INFO - 2018-04-01 19:35:48 --> Language Class Initialized
ERROR - 2018-04-01 19:35:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:35:48 --> Config Class Initialized
INFO - 2018-04-01 19:35:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:35:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:35:48 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:48 --> URI Class Initialized
INFO - 2018-04-01 19:35:48 --> Router Class Initialized
INFO - 2018-04-01 19:35:48 --> Output Class Initialized
INFO - 2018-04-01 19:35:48 --> Security Class Initialized
DEBUG - 2018-04-01 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:48 --> CSRF cookie sent
INFO - 2018-04-01 19:35:48 --> Input Class Initialized
INFO - 2018-04-01 19:35:48 --> Language Class Initialized
ERROR - 2018-04-01 19:35:48 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:35:49 --> Config Class Initialized
INFO - 2018-04-01 19:35:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:35:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:35:49 --> Utf8 Class Initialized
INFO - 2018-04-01 19:35:49 --> URI Class Initialized
INFO - 2018-04-01 19:35:49 --> Router Class Initialized
INFO - 2018-04-01 19:35:49 --> Output Class Initialized
INFO - 2018-04-01 19:35:49 --> Security Class Initialized
DEBUG - 2018-04-01 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:35:49 --> CSRF cookie sent
INFO - 2018-04-01 19:35:49 --> Input Class Initialized
INFO - 2018-04-01 19:35:49 --> Language Class Initialized
ERROR - 2018-04-01 19:35:49 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:39:36 --> Config Class Initialized
INFO - 2018-04-01 19:39:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:39:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:39:36 --> Utf8 Class Initialized
INFO - 2018-04-01 19:39:36 --> URI Class Initialized
DEBUG - 2018-04-01 19:39:36 --> No URI present. Default controller set.
INFO - 2018-04-01 19:39:36 --> Router Class Initialized
INFO - 2018-04-01 19:39:36 --> Output Class Initialized
INFO - 2018-04-01 19:39:36 --> Security Class Initialized
DEBUG - 2018-04-01 19:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:39:36 --> CSRF cookie sent
INFO - 2018-04-01 19:39:36 --> Input Class Initialized
INFO - 2018-04-01 19:39:36 --> Language Class Initialized
INFO - 2018-04-01 19:39:36 --> Loader Class Initialized
INFO - 2018-04-01 19:39:36 --> Helper loaded: url_helper
INFO - 2018-04-01 19:39:36 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:39:36 --> User Agent Class Initialized
INFO - 2018-04-01 19:39:37 --> Controller Class Initialized
INFO - 2018-04-01 19:39:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:39:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:39:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:39:37 --> Final output sent to browser
DEBUG - 2018-04-01 19:39:37 --> Total execution time: 0.2684
INFO - 2018-04-01 19:39:37 --> Config Class Initialized
INFO - 2018-04-01 19:39:37 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:39:37 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:39:37 --> Utf8 Class Initialized
INFO - 2018-04-01 19:39:37 --> URI Class Initialized
INFO - 2018-04-01 19:39:37 --> Router Class Initialized
INFO - 2018-04-01 19:39:37 --> Output Class Initialized
INFO - 2018-04-01 19:39:37 --> Security Class Initialized
DEBUG - 2018-04-01 19:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:39:37 --> CSRF cookie sent
INFO - 2018-04-01 19:39:37 --> Input Class Initialized
INFO - 2018-04-01 19:39:37 --> Language Class Initialized
ERROR - 2018-04-01 19:39:37 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:39:37 --> Config Class Initialized
INFO - 2018-04-01 19:39:37 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:39:37 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:39:37 --> Utf8 Class Initialized
INFO - 2018-04-01 19:39:37 --> URI Class Initialized
INFO - 2018-04-01 19:39:37 --> Router Class Initialized
INFO - 2018-04-01 19:39:37 --> Output Class Initialized
INFO - 2018-04-01 19:39:37 --> Security Class Initialized
DEBUG - 2018-04-01 19:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:39:37 --> CSRF cookie sent
INFO - 2018-04-01 19:39:37 --> Input Class Initialized
INFO - 2018-04-01 19:39:37 --> Language Class Initialized
ERROR - 2018-04-01 19:39:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:39:39 --> Config Class Initialized
INFO - 2018-04-01 19:39:39 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:39:39 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:39:39 --> Utf8 Class Initialized
INFO - 2018-04-01 19:39:39 --> URI Class Initialized
INFO - 2018-04-01 19:39:39 --> Router Class Initialized
INFO - 2018-04-01 19:39:39 --> Output Class Initialized
INFO - 2018-04-01 19:39:39 --> Security Class Initialized
DEBUG - 2018-04-01 19:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:39:39 --> CSRF cookie sent
INFO - 2018-04-01 19:39:39 --> Input Class Initialized
INFO - 2018-04-01 19:39:39 --> Language Class Initialized
ERROR - 2018-04-01 19:39:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:40:09 --> Config Class Initialized
INFO - 2018-04-01 19:40:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:40:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:40:09 --> Utf8 Class Initialized
INFO - 2018-04-01 19:40:09 --> URI Class Initialized
DEBUG - 2018-04-01 19:40:09 --> No URI present. Default controller set.
INFO - 2018-04-01 19:40:09 --> Router Class Initialized
INFO - 2018-04-01 19:40:09 --> Output Class Initialized
INFO - 2018-04-01 19:40:09 --> Security Class Initialized
DEBUG - 2018-04-01 19:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:40:10 --> CSRF cookie sent
INFO - 2018-04-01 19:40:10 --> Input Class Initialized
INFO - 2018-04-01 19:40:10 --> Language Class Initialized
INFO - 2018-04-01 19:40:10 --> Loader Class Initialized
INFO - 2018-04-01 19:40:10 --> Helper loaded: url_helper
INFO - 2018-04-01 19:40:10 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:40:10 --> User Agent Class Initialized
INFO - 2018-04-01 19:40:10 --> Controller Class Initialized
INFO - 2018-04-01 19:40:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:40:10 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:40:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:40:10 --> Final output sent to browser
DEBUG - 2018-04-01 19:40:10 --> Total execution time: 0.2685
INFO - 2018-04-01 19:40:10 --> Config Class Initialized
INFO - 2018-04-01 19:40:10 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:40:10 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:40:10 --> Utf8 Class Initialized
INFO - 2018-04-01 19:40:10 --> URI Class Initialized
INFO - 2018-04-01 19:40:10 --> Router Class Initialized
INFO - 2018-04-01 19:40:10 --> Output Class Initialized
INFO - 2018-04-01 19:40:10 --> Security Class Initialized
DEBUG - 2018-04-01 19:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:40:10 --> CSRF cookie sent
INFO - 2018-04-01 19:40:10 --> Input Class Initialized
INFO - 2018-04-01 19:40:10 --> Language Class Initialized
ERROR - 2018-04-01 19:40:10 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:40:11 --> Config Class Initialized
INFO - 2018-04-01 19:40:11 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:40:11 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:40:11 --> Utf8 Class Initialized
INFO - 2018-04-01 19:40:11 --> URI Class Initialized
INFO - 2018-04-01 19:40:11 --> Router Class Initialized
INFO - 2018-04-01 19:40:11 --> Output Class Initialized
INFO - 2018-04-01 19:40:11 --> Security Class Initialized
DEBUG - 2018-04-01 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:40:11 --> CSRF cookie sent
INFO - 2018-04-01 19:40:11 --> Input Class Initialized
INFO - 2018-04-01 19:40:11 --> Language Class Initialized
ERROR - 2018-04-01 19:40:11 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:40:15 --> Config Class Initialized
INFO - 2018-04-01 19:40:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:40:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:40:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:40:15 --> URI Class Initialized
INFO - 2018-04-01 19:40:15 --> Router Class Initialized
INFO - 2018-04-01 19:40:15 --> Output Class Initialized
INFO - 2018-04-01 19:40:15 --> Security Class Initialized
DEBUG - 2018-04-01 19:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:40:15 --> CSRF cookie sent
INFO - 2018-04-01 19:40:15 --> Input Class Initialized
INFO - 2018-04-01 19:40:15 --> Language Class Initialized
ERROR - 2018-04-01 19:40:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:42:07 --> Config Class Initialized
INFO - 2018-04-01 19:42:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:42:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:42:07 --> Utf8 Class Initialized
INFO - 2018-04-01 19:42:07 --> URI Class Initialized
DEBUG - 2018-04-01 19:42:07 --> No URI present. Default controller set.
INFO - 2018-04-01 19:42:07 --> Router Class Initialized
INFO - 2018-04-01 19:42:07 --> Output Class Initialized
INFO - 2018-04-01 19:42:07 --> Security Class Initialized
DEBUG - 2018-04-01 19:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:42:07 --> CSRF cookie sent
INFO - 2018-04-01 19:42:07 --> Input Class Initialized
INFO - 2018-04-01 19:42:07 --> Language Class Initialized
INFO - 2018-04-01 19:42:07 --> Loader Class Initialized
INFO - 2018-04-01 19:42:07 --> Helper loaded: url_helper
INFO - 2018-04-01 19:42:07 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:42:07 --> User Agent Class Initialized
INFO - 2018-04-01 19:42:08 --> Controller Class Initialized
INFO - 2018-04-01 19:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:42:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:42:08 --> Final output sent to browser
DEBUG - 2018-04-01 19:42:08 --> Total execution time: 0.2782
INFO - 2018-04-01 19:42:08 --> Config Class Initialized
INFO - 2018-04-01 19:42:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:42:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:42:08 --> URI Class Initialized
INFO - 2018-04-01 19:42:08 --> Router Class Initialized
INFO - 2018-04-01 19:42:08 --> Output Class Initialized
INFO - 2018-04-01 19:42:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:42:08 --> CSRF cookie sent
INFO - 2018-04-01 19:42:08 --> Input Class Initialized
INFO - 2018-04-01 19:42:08 --> Language Class Initialized
ERROR - 2018-04-01 19:42:08 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:42:08 --> Config Class Initialized
INFO - 2018-04-01 19:42:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:42:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:42:08 --> URI Class Initialized
INFO - 2018-04-01 19:42:08 --> Router Class Initialized
INFO - 2018-04-01 19:42:08 --> Output Class Initialized
INFO - 2018-04-01 19:42:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:42:08 --> CSRF cookie sent
INFO - 2018-04-01 19:42:08 --> Input Class Initialized
INFO - 2018-04-01 19:42:08 --> Language Class Initialized
ERROR - 2018-04-01 19:42:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:42:09 --> Config Class Initialized
INFO - 2018-04-01 19:42:10 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:42:10 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:42:10 --> Utf8 Class Initialized
INFO - 2018-04-01 19:42:10 --> URI Class Initialized
INFO - 2018-04-01 19:42:10 --> Router Class Initialized
INFO - 2018-04-01 19:42:10 --> Output Class Initialized
INFO - 2018-04-01 19:42:10 --> Security Class Initialized
DEBUG - 2018-04-01 19:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:42:10 --> CSRF cookie sent
INFO - 2018-04-01 19:42:10 --> Input Class Initialized
INFO - 2018-04-01 19:42:10 --> Language Class Initialized
ERROR - 2018-04-01 19:42:10 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:46:00 --> Config Class Initialized
INFO - 2018-04-01 19:46:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:00 --> URI Class Initialized
DEBUG - 2018-04-01 19:46:00 --> No URI present. Default controller set.
INFO - 2018-04-01 19:46:00 --> Router Class Initialized
INFO - 2018-04-01 19:46:00 --> Output Class Initialized
INFO - 2018-04-01 19:46:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:00 --> CSRF cookie sent
INFO - 2018-04-01 19:46:00 --> Input Class Initialized
INFO - 2018-04-01 19:46:00 --> Language Class Initialized
INFO - 2018-04-01 19:46:00 --> Loader Class Initialized
INFO - 2018-04-01 19:46:00 --> Helper loaded: url_helper
INFO - 2018-04-01 19:46:00 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:46:00 --> User Agent Class Initialized
INFO - 2018-04-01 19:46:00 --> Controller Class Initialized
INFO - 2018-04-01 19:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:46:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:46:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:46:00 --> Final output sent to browser
DEBUG - 2018-04-01 19:46:00 --> Total execution time: 0.2838
INFO - 2018-04-01 19:46:00 --> Config Class Initialized
INFO - 2018-04-01 19:46:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:00 --> URI Class Initialized
INFO - 2018-04-01 19:46:00 --> Router Class Initialized
INFO - 2018-04-01 19:46:00 --> Output Class Initialized
INFO - 2018-04-01 19:46:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:00 --> CSRF cookie sent
INFO - 2018-04-01 19:46:00 --> Input Class Initialized
INFO - 2018-04-01 19:46:00 --> Language Class Initialized
ERROR - 2018-04-01 19:46:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:46:00 --> Config Class Initialized
INFO - 2018-04-01 19:46:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:01 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:01 --> URI Class Initialized
INFO - 2018-04-01 19:46:01 --> Router Class Initialized
INFO - 2018-04-01 19:46:01 --> Output Class Initialized
INFO - 2018-04-01 19:46:01 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:01 --> CSRF cookie sent
INFO - 2018-04-01 19:46:01 --> Input Class Initialized
INFO - 2018-04-01 19:46:01 --> Language Class Initialized
ERROR - 2018-04-01 19:46:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:46:02 --> Config Class Initialized
INFO - 2018-04-01 19:46:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:02 --> URI Class Initialized
INFO - 2018-04-01 19:46:02 --> Router Class Initialized
INFO - 2018-04-01 19:46:02 --> Output Class Initialized
INFO - 2018-04-01 19:46:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:02 --> CSRF cookie sent
INFO - 2018-04-01 19:46:02 --> Input Class Initialized
INFO - 2018-04-01 19:46:02 --> Language Class Initialized
ERROR - 2018-04-01 19:46:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:46:51 --> Config Class Initialized
INFO - 2018-04-01 19:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:51 --> URI Class Initialized
DEBUG - 2018-04-01 19:46:51 --> No URI present. Default controller set.
INFO - 2018-04-01 19:46:51 --> Router Class Initialized
INFO - 2018-04-01 19:46:51 --> Output Class Initialized
INFO - 2018-04-01 19:46:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:51 --> CSRF cookie sent
INFO - 2018-04-01 19:46:51 --> Input Class Initialized
INFO - 2018-04-01 19:46:51 --> Language Class Initialized
INFO - 2018-04-01 19:46:51 --> Loader Class Initialized
INFO - 2018-04-01 19:46:51 --> Helper loaded: url_helper
INFO - 2018-04-01 19:46:51 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:46:51 --> User Agent Class Initialized
INFO - 2018-04-01 19:46:51 --> Controller Class Initialized
INFO - 2018-04-01 19:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:46:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:46:51 --> Final output sent to browser
DEBUG - 2018-04-01 19:46:51 --> Total execution time: 0.2955
INFO - 2018-04-01 19:46:51 --> Config Class Initialized
INFO - 2018-04-01 19:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:51 --> URI Class Initialized
INFO - 2018-04-01 19:46:51 --> Router Class Initialized
INFO - 2018-04-01 19:46:51 --> Output Class Initialized
INFO - 2018-04-01 19:46:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:51 --> CSRF cookie sent
INFO - 2018-04-01 19:46:51 --> Input Class Initialized
INFO - 2018-04-01 19:46:51 --> Language Class Initialized
ERROR - 2018-04-01 19:46:51 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:46:52 --> Config Class Initialized
INFO - 2018-04-01 19:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:52 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:52 --> URI Class Initialized
INFO - 2018-04-01 19:46:52 --> Router Class Initialized
INFO - 2018-04-01 19:46:52 --> Output Class Initialized
INFO - 2018-04-01 19:46:52 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:52 --> CSRF cookie sent
INFO - 2018-04-01 19:46:52 --> Input Class Initialized
INFO - 2018-04-01 19:46:52 --> Language Class Initialized
ERROR - 2018-04-01 19:46:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:46:53 --> Config Class Initialized
INFO - 2018-04-01 19:46:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:46:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:46:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:46:53 --> URI Class Initialized
INFO - 2018-04-01 19:46:53 --> Router Class Initialized
INFO - 2018-04-01 19:46:53 --> Output Class Initialized
INFO - 2018-04-01 19:46:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:46:53 --> CSRF cookie sent
INFO - 2018-04-01 19:46:53 --> Input Class Initialized
INFO - 2018-04-01 19:46:53 --> Language Class Initialized
ERROR - 2018-04-01 19:46:53 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:02 --> Config Class Initialized
INFO - 2018-04-01 19:47:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:02 --> URI Class Initialized
INFO - 2018-04-01 19:47:02 --> Router Class Initialized
INFO - 2018-04-01 19:47:02 --> Output Class Initialized
INFO - 2018-04-01 19:47:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:02 --> CSRF cookie sent
INFO - 2018-04-01 19:47:02 --> Input Class Initialized
INFO - 2018-04-01 19:47:02 --> Language Class Initialized
ERROR - 2018-04-01 19:47:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:04 --> Config Class Initialized
INFO - 2018-04-01 19:47:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:04 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:04 --> URI Class Initialized
INFO - 2018-04-01 19:47:04 --> Router Class Initialized
INFO - 2018-04-01 19:47:04 --> Output Class Initialized
INFO - 2018-04-01 19:47:04 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:04 --> CSRF cookie sent
INFO - 2018-04-01 19:47:04 --> Input Class Initialized
INFO - 2018-04-01 19:47:04 --> Language Class Initialized
ERROR - 2018-04-01 19:47:04 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:05 --> Config Class Initialized
INFO - 2018-04-01 19:47:05 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:05 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:05 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:05 --> URI Class Initialized
INFO - 2018-04-01 19:47:06 --> Router Class Initialized
INFO - 2018-04-01 19:47:06 --> Output Class Initialized
INFO - 2018-04-01 19:47:06 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:06 --> CSRF cookie sent
INFO - 2018-04-01 19:47:06 --> Input Class Initialized
INFO - 2018-04-01 19:47:06 --> Language Class Initialized
ERROR - 2018-04-01 19:47:06 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:06 --> Config Class Initialized
INFO - 2018-04-01 19:47:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:06 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:06 --> URI Class Initialized
INFO - 2018-04-01 19:47:06 --> Router Class Initialized
INFO - 2018-04-01 19:47:06 --> Output Class Initialized
INFO - 2018-04-01 19:47:06 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:06 --> CSRF cookie sent
INFO - 2018-04-01 19:47:06 --> Input Class Initialized
INFO - 2018-04-01 19:47:06 --> Language Class Initialized
ERROR - 2018-04-01 19:47:06 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:07 --> Config Class Initialized
INFO - 2018-04-01 19:47:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:07 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:07 --> URI Class Initialized
INFO - 2018-04-01 19:47:07 --> Router Class Initialized
INFO - 2018-04-01 19:47:07 --> Output Class Initialized
INFO - 2018-04-01 19:47:07 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:07 --> CSRF cookie sent
INFO - 2018-04-01 19:47:07 --> Input Class Initialized
INFO - 2018-04-01 19:47:07 --> Language Class Initialized
ERROR - 2018-04-01 19:47:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:08 --> Config Class Initialized
INFO - 2018-04-01 19:47:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:08 --> URI Class Initialized
INFO - 2018-04-01 19:47:08 --> Router Class Initialized
INFO - 2018-04-01 19:47:08 --> Output Class Initialized
INFO - 2018-04-01 19:47:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:08 --> CSRF cookie sent
INFO - 2018-04-01 19:47:08 --> Input Class Initialized
INFO - 2018-04-01 19:47:08 --> Language Class Initialized
ERROR - 2018-04-01 19:47:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:08 --> Config Class Initialized
INFO - 2018-04-01 19:47:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:08 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:08 --> URI Class Initialized
INFO - 2018-04-01 19:47:08 --> Router Class Initialized
INFO - 2018-04-01 19:47:08 --> Output Class Initialized
INFO - 2018-04-01 19:47:08 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:08 --> CSRF cookie sent
INFO - 2018-04-01 19:47:08 --> Input Class Initialized
INFO - 2018-04-01 19:47:08 --> Language Class Initialized
ERROR - 2018-04-01 19:47:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:09 --> Config Class Initialized
INFO - 2018-04-01 19:47:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:09 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:09 --> URI Class Initialized
INFO - 2018-04-01 19:47:09 --> Router Class Initialized
INFO - 2018-04-01 19:47:09 --> Output Class Initialized
INFO - 2018-04-01 19:47:09 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:09 --> CSRF cookie sent
INFO - 2018-04-01 19:47:09 --> Input Class Initialized
INFO - 2018-04-01 19:47:09 --> Language Class Initialized
ERROR - 2018-04-01 19:47:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:47:09 --> Config Class Initialized
INFO - 2018-04-01 19:47:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:47:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:47:09 --> Utf8 Class Initialized
INFO - 2018-04-01 19:47:09 --> URI Class Initialized
INFO - 2018-04-01 19:47:09 --> Router Class Initialized
INFO - 2018-04-01 19:47:09 --> Output Class Initialized
INFO - 2018-04-01 19:47:09 --> Security Class Initialized
DEBUG - 2018-04-01 19:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:47:09 --> CSRF cookie sent
INFO - 2018-04-01 19:47:09 --> Input Class Initialized
INFO - 2018-04-01 19:47:09 --> Language Class Initialized
ERROR - 2018-04-01 19:47:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:48:18 --> Config Class Initialized
INFO - 2018-04-01 19:48:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:18 --> URI Class Initialized
DEBUG - 2018-04-01 19:48:18 --> No URI present. Default controller set.
INFO - 2018-04-01 19:48:18 --> Router Class Initialized
INFO - 2018-04-01 19:48:18 --> Output Class Initialized
INFO - 2018-04-01 19:48:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:18 --> CSRF cookie sent
INFO - 2018-04-01 19:48:18 --> Input Class Initialized
INFO - 2018-04-01 19:48:18 --> Language Class Initialized
INFO - 2018-04-01 19:48:18 --> Loader Class Initialized
INFO - 2018-04-01 19:48:18 --> Helper loaded: url_helper
INFO - 2018-04-01 19:48:18 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:48:18 --> User Agent Class Initialized
INFO - 2018-04-01 19:48:18 --> Controller Class Initialized
INFO - 2018-04-01 19:48:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:48:18 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:48:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:48:18 --> Final output sent to browser
DEBUG - 2018-04-01 19:48:18 --> Total execution time: 0.2798
INFO - 2018-04-01 19:48:18 --> Config Class Initialized
INFO - 2018-04-01 19:48:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:18 --> URI Class Initialized
INFO - 2018-04-01 19:48:18 --> Router Class Initialized
INFO - 2018-04-01 19:48:18 --> Output Class Initialized
INFO - 2018-04-01 19:48:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:18 --> CSRF cookie sent
INFO - 2018-04-01 19:48:18 --> Input Class Initialized
INFO - 2018-04-01 19:48:18 --> Language Class Initialized
ERROR - 2018-04-01 19:48:18 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:48:18 --> Config Class Initialized
INFO - 2018-04-01 19:48:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:18 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:18 --> URI Class Initialized
INFO - 2018-04-01 19:48:18 --> Router Class Initialized
INFO - 2018-04-01 19:48:18 --> Output Class Initialized
INFO - 2018-04-01 19:48:18 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:19 --> CSRF cookie sent
INFO - 2018-04-01 19:48:19 --> Input Class Initialized
INFO - 2018-04-01 19:48:19 --> Language Class Initialized
ERROR - 2018-04-01 19:48:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:48:20 --> Config Class Initialized
INFO - 2018-04-01 19:48:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:20 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:20 --> URI Class Initialized
INFO - 2018-04-01 19:48:20 --> Router Class Initialized
INFO - 2018-04-01 19:48:20 --> Output Class Initialized
INFO - 2018-04-01 19:48:20 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:20 --> CSRF cookie sent
INFO - 2018-04-01 19:48:20 --> Input Class Initialized
INFO - 2018-04-01 19:48:20 --> Language Class Initialized
ERROR - 2018-04-01 19:48:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-01 19:48:51 --> Config Class Initialized
INFO - 2018-04-01 19:48:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:51 --> URI Class Initialized
DEBUG - 2018-04-01 19:48:51 --> No URI present. Default controller set.
INFO - 2018-04-01 19:48:51 --> Router Class Initialized
INFO - 2018-04-01 19:48:51 --> Output Class Initialized
INFO - 2018-04-01 19:48:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:51 --> CSRF cookie sent
INFO - 2018-04-01 19:48:51 --> Input Class Initialized
INFO - 2018-04-01 19:48:51 --> Language Class Initialized
INFO - 2018-04-01 19:48:51 --> Loader Class Initialized
INFO - 2018-04-01 19:48:51 --> Helper loaded: url_helper
INFO - 2018-04-01 19:48:51 --> Helper loaded: form_helper
DEBUG - 2018-04-01 19:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:48:51 --> User Agent Class Initialized
INFO - 2018-04-01 19:48:51 --> Controller Class Initialized
INFO - 2018-04-01 19:48:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-01 19:48:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-01 19:48:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-01 19:48:51 --> Final output sent to browser
DEBUG - 2018-04-01 19:48:51 --> Total execution time: 0.2907
INFO - 2018-04-01 19:48:51 --> Config Class Initialized
INFO - 2018-04-01 19:48:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:51 --> URI Class Initialized
INFO - 2018-04-01 19:48:51 --> Router Class Initialized
INFO - 2018-04-01 19:48:51 --> Output Class Initialized
INFO - 2018-04-01 19:48:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:51 --> CSRF cookie sent
INFO - 2018-04-01 19:48:51 --> Input Class Initialized
INFO - 2018-04-01 19:48:51 --> Language Class Initialized
ERROR - 2018-04-01 19:48:51 --> 404 Page Not Found: Assets/images
INFO - 2018-04-01 19:48:51 --> Config Class Initialized
INFO - 2018-04-01 19:48:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:51 --> URI Class Initialized
INFO - 2018-04-01 19:48:51 --> Router Class Initialized
INFO - 2018-04-01 19:48:51 --> Output Class Initialized
INFO - 2018-04-01 19:48:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:51 --> CSRF cookie sent
INFO - 2018-04-01 19:48:51 --> Input Class Initialized
INFO - 2018-04-01 19:48:51 --> Language Class Initialized
ERROR - 2018-04-01 19:48:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-01 19:48:53 --> Config Class Initialized
INFO - 2018-04-01 19:48:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:48:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:48:53 --> Utf8 Class Initialized
INFO - 2018-04-01 19:48:53 --> URI Class Initialized
INFO - 2018-04-01 19:48:53 --> Router Class Initialized
INFO - 2018-04-01 19:48:53 --> Output Class Initialized
INFO - 2018-04-01 19:48:53 --> Security Class Initialized
DEBUG - 2018-04-01 19:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:48:53 --> CSRF cookie sent
INFO - 2018-04-01 19:48:53 --> Input Class Initialized
INFO - 2018-04-01 19:48:53 --> Language Class Initialized
ERROR - 2018-04-01 19:48:53 --> 404 Page Not Found: Revolution/assets

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-02 16:41:02 --> Config Class Initialized
INFO - 2018-04-02 16:41:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:03 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:03 --> URI Class Initialized
DEBUG - 2018-04-02 16:41:03 --> No URI present. Default controller set.
INFO - 2018-04-02 16:41:03 --> Router Class Initialized
INFO - 2018-04-02 16:41:03 --> Output Class Initialized
INFO - 2018-04-02 16:41:03 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:03 --> CSRF cookie sent
INFO - 2018-04-02 16:41:03 --> Input Class Initialized
INFO - 2018-04-02 16:41:03 --> Language Class Initialized
INFO - 2018-04-02 16:41:03 --> Loader Class Initialized
INFO - 2018-04-02 16:41:03 --> Helper loaded: url_helper
INFO - 2018-04-02 16:41:03 --> Helper loaded: form_helper
DEBUG - 2018-04-02 16:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 16:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 16:41:03 --> User Agent Class Initialized
INFO - 2018-04-02 16:41:03 --> Controller Class Initialized
INFO - 2018-04-02 16:41:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 16:41:04 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 16:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 16:41:04 --> Final output sent to browser
DEBUG - 2018-04-02 16:41:04 --> Total execution time: 1.2109
INFO - 2018-04-02 16:41:04 --> Config Class Initialized
INFO - 2018-04-02 16:41:04 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:04 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:04 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:04 --> URI Class Initialized
INFO - 2018-04-02 16:41:04 --> Router Class Initialized
INFO - 2018-04-02 16:41:04 --> Output Class Initialized
INFO - 2018-04-02 16:41:04 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:04 --> CSRF cookie sent
INFO - 2018-04-02 16:41:04 --> Input Class Initialized
INFO - 2018-04-02 16:41:04 --> Language Class Initialized
ERROR - 2018-04-02 16:41:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 16:41:05 --> Config Class Initialized
INFO - 2018-04-02 16:41:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:05 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:05 --> URI Class Initialized
INFO - 2018-04-02 16:41:05 --> Router Class Initialized
INFO - 2018-04-02 16:41:05 --> Output Class Initialized
INFO - 2018-04-02 16:41:05 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:05 --> CSRF cookie sent
INFO - 2018-04-02 16:41:05 --> Input Class Initialized
INFO - 2018-04-02 16:41:05 --> Language Class Initialized
ERROR - 2018-04-02 16:41:05 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 16:41:06 --> Config Class Initialized
INFO - 2018-04-02 16:41:06 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:06 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:06 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:06 --> URI Class Initialized
INFO - 2018-04-02 16:41:06 --> Router Class Initialized
INFO - 2018-04-02 16:41:06 --> Output Class Initialized
INFO - 2018-04-02 16:41:06 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:06 --> CSRF cookie sent
INFO - 2018-04-02 16:41:06 --> Input Class Initialized
INFO - 2018-04-02 16:41:06 --> Language Class Initialized
ERROR - 2018-04-02 16:41:06 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 16:41:30 --> Config Class Initialized
INFO - 2018-04-02 16:41:30 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:30 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:30 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:30 --> URI Class Initialized
DEBUG - 2018-04-02 16:41:30 --> No URI present. Default controller set.
INFO - 2018-04-02 16:41:30 --> Router Class Initialized
INFO - 2018-04-02 16:41:30 --> Output Class Initialized
INFO - 2018-04-02 16:41:30 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:30 --> CSRF cookie sent
INFO - 2018-04-02 16:41:30 --> Input Class Initialized
INFO - 2018-04-02 16:41:30 --> Language Class Initialized
INFO - 2018-04-02 16:41:30 --> Loader Class Initialized
INFO - 2018-04-02 16:41:30 --> Helper loaded: url_helper
INFO - 2018-04-02 16:41:30 --> Helper loaded: form_helper
DEBUG - 2018-04-02 16:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 16:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 16:41:30 --> User Agent Class Initialized
INFO - 2018-04-02 16:41:30 --> Controller Class Initialized
INFO - 2018-04-02 16:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 16:41:30 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 16:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 16:41:30 --> Final output sent to browser
DEBUG - 2018-04-02 16:41:30 --> Total execution time: 0.2047
INFO - 2018-04-02 16:41:31 --> Config Class Initialized
INFO - 2018-04-02 16:41:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:31 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:31 --> URI Class Initialized
INFO - 2018-04-02 16:41:31 --> Router Class Initialized
INFO - 2018-04-02 16:41:31 --> Output Class Initialized
INFO - 2018-04-02 16:41:31 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:31 --> CSRF cookie sent
INFO - 2018-04-02 16:41:31 --> Input Class Initialized
INFO - 2018-04-02 16:41:31 --> Language Class Initialized
ERROR - 2018-04-02 16:41:31 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 16:41:31 --> Config Class Initialized
INFO - 2018-04-02 16:41:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:31 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:31 --> URI Class Initialized
INFO - 2018-04-02 16:41:31 --> Router Class Initialized
INFO - 2018-04-02 16:41:31 --> Output Class Initialized
INFO - 2018-04-02 16:41:31 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:31 --> CSRF cookie sent
INFO - 2018-04-02 16:41:31 --> Input Class Initialized
INFO - 2018-04-02 16:41:31 --> Language Class Initialized
ERROR - 2018-04-02 16:41:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 16:41:33 --> Config Class Initialized
INFO - 2018-04-02 16:41:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:41:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:41:33 --> Utf8 Class Initialized
INFO - 2018-04-02 16:41:33 --> URI Class Initialized
INFO - 2018-04-02 16:41:33 --> Router Class Initialized
INFO - 2018-04-02 16:41:33 --> Output Class Initialized
INFO - 2018-04-02 16:41:33 --> Security Class Initialized
DEBUG - 2018-04-02 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:41:33 --> CSRF cookie sent
INFO - 2018-04-02 16:41:33 --> Input Class Initialized
INFO - 2018-04-02 16:41:33 --> Language Class Initialized
ERROR - 2018-04-02 16:41:33 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 16:44:50 --> Config Class Initialized
INFO - 2018-04-02 16:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:44:50 --> Utf8 Class Initialized
INFO - 2018-04-02 16:44:50 --> URI Class Initialized
DEBUG - 2018-04-02 16:44:50 --> No URI present. Default controller set.
INFO - 2018-04-02 16:44:50 --> Router Class Initialized
INFO - 2018-04-02 16:44:50 --> Output Class Initialized
INFO - 2018-04-02 16:44:50 --> Security Class Initialized
DEBUG - 2018-04-02 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:44:50 --> CSRF cookie sent
INFO - 2018-04-02 16:44:50 --> Input Class Initialized
INFO - 2018-04-02 16:44:50 --> Language Class Initialized
INFO - 2018-04-02 16:44:50 --> Loader Class Initialized
INFO - 2018-04-02 16:44:50 --> Helper loaded: url_helper
INFO - 2018-04-02 16:44:50 --> Helper loaded: form_helper
DEBUG - 2018-04-02 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 16:44:50 --> User Agent Class Initialized
INFO - 2018-04-02 16:44:50 --> Controller Class Initialized
INFO - 2018-04-02 16:44:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 16:44:50 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 16:44:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 16:44:50 --> Final output sent to browser
DEBUG - 2018-04-02 16:44:50 --> Total execution time: 0.1911
INFO - 2018-04-02 16:44:50 --> Config Class Initialized
INFO - 2018-04-02 16:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:44:50 --> Utf8 Class Initialized
INFO - 2018-04-02 16:44:50 --> URI Class Initialized
INFO - 2018-04-02 16:44:51 --> Router Class Initialized
INFO - 2018-04-02 16:44:51 --> Output Class Initialized
INFO - 2018-04-02 16:44:51 --> Security Class Initialized
DEBUG - 2018-04-02 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:44:51 --> CSRF cookie sent
INFO - 2018-04-02 16:44:51 --> Input Class Initialized
INFO - 2018-04-02 16:44:51 --> Language Class Initialized
ERROR - 2018-04-02 16:44:51 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 16:44:51 --> Config Class Initialized
INFO - 2018-04-02 16:44:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:44:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:44:51 --> Utf8 Class Initialized
INFO - 2018-04-02 16:44:51 --> URI Class Initialized
INFO - 2018-04-02 16:44:51 --> Router Class Initialized
INFO - 2018-04-02 16:44:51 --> Output Class Initialized
INFO - 2018-04-02 16:44:51 --> Security Class Initialized
DEBUG - 2018-04-02 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:44:51 --> CSRF cookie sent
INFO - 2018-04-02 16:44:51 --> Input Class Initialized
INFO - 2018-04-02 16:44:51 --> Language Class Initialized
ERROR - 2018-04-02 16:44:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 16:44:52 --> Config Class Initialized
INFO - 2018-04-02 16:44:52 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:44:52 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:44:52 --> Utf8 Class Initialized
INFO - 2018-04-02 16:44:52 --> URI Class Initialized
INFO - 2018-04-02 16:44:52 --> Router Class Initialized
INFO - 2018-04-02 16:44:52 --> Output Class Initialized
INFO - 2018-04-02 16:44:52 --> Security Class Initialized
DEBUG - 2018-04-02 16:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:44:52 --> CSRF cookie sent
INFO - 2018-04-02 16:44:52 --> Input Class Initialized
INFO - 2018-04-02 16:44:52 --> Language Class Initialized
ERROR - 2018-04-02 16:44:52 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 16:48:33 --> Config Class Initialized
INFO - 2018-04-02 16:48:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:48:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:48:33 --> Utf8 Class Initialized
INFO - 2018-04-02 16:48:33 --> URI Class Initialized
DEBUG - 2018-04-02 16:48:33 --> No URI present. Default controller set.
INFO - 2018-04-02 16:48:33 --> Router Class Initialized
INFO - 2018-04-02 16:48:33 --> Output Class Initialized
INFO - 2018-04-02 16:48:33 --> Security Class Initialized
DEBUG - 2018-04-02 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:48:33 --> CSRF cookie sent
INFO - 2018-04-02 16:48:33 --> Input Class Initialized
INFO - 2018-04-02 16:48:33 --> Language Class Initialized
INFO - 2018-04-02 16:48:33 --> Loader Class Initialized
INFO - 2018-04-02 16:48:33 --> Helper loaded: url_helper
INFO - 2018-04-02 16:48:33 --> Helper loaded: form_helper
DEBUG - 2018-04-02 16:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 16:48:33 --> User Agent Class Initialized
INFO - 2018-04-02 16:48:33 --> Controller Class Initialized
INFO - 2018-04-02 16:48:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 16:48:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 16:48:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 16:48:34 --> Final output sent to browser
DEBUG - 2018-04-02 16:48:34 --> Total execution time: 0.2092
INFO - 2018-04-02 16:48:34 --> Config Class Initialized
INFO - 2018-04-02 16:48:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:48:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:48:34 --> Utf8 Class Initialized
INFO - 2018-04-02 16:48:34 --> URI Class Initialized
INFO - 2018-04-02 16:48:34 --> Router Class Initialized
INFO - 2018-04-02 16:48:34 --> Output Class Initialized
INFO - 2018-04-02 16:48:34 --> Security Class Initialized
DEBUG - 2018-04-02 16:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:48:34 --> CSRF cookie sent
INFO - 2018-04-02 16:48:34 --> Input Class Initialized
INFO - 2018-04-02 16:48:34 --> Language Class Initialized
ERROR - 2018-04-02 16:48:34 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 16:48:34 --> Config Class Initialized
INFO - 2018-04-02 16:48:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:48:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:48:34 --> Utf8 Class Initialized
INFO - 2018-04-02 16:48:34 --> URI Class Initialized
INFO - 2018-04-02 16:48:34 --> Router Class Initialized
INFO - 2018-04-02 16:48:34 --> Output Class Initialized
INFO - 2018-04-02 16:48:34 --> Security Class Initialized
DEBUG - 2018-04-02 16:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:48:34 --> CSRF cookie sent
INFO - 2018-04-02 16:48:34 --> Input Class Initialized
INFO - 2018-04-02 16:48:34 --> Language Class Initialized
ERROR - 2018-04-02 16:48:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 16:48:36 --> Config Class Initialized
INFO - 2018-04-02 16:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:48:36 --> Utf8 Class Initialized
INFO - 2018-04-02 16:48:36 --> URI Class Initialized
INFO - 2018-04-02 16:48:36 --> Router Class Initialized
INFO - 2018-04-02 16:48:36 --> Output Class Initialized
INFO - 2018-04-02 16:48:36 --> Security Class Initialized
DEBUG - 2018-04-02 16:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:48:36 --> CSRF cookie sent
INFO - 2018-04-02 16:48:36 --> Input Class Initialized
INFO - 2018-04-02 16:48:36 --> Language Class Initialized
ERROR - 2018-04-02 16:48:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 16:50:32 --> Config Class Initialized
INFO - 2018-04-02 16:50:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:50:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:50:32 --> Utf8 Class Initialized
INFO - 2018-04-02 16:50:32 --> URI Class Initialized
DEBUG - 2018-04-02 16:50:32 --> No URI present. Default controller set.
INFO - 2018-04-02 16:50:32 --> Router Class Initialized
INFO - 2018-04-02 16:50:32 --> Output Class Initialized
INFO - 2018-04-02 16:50:32 --> Security Class Initialized
DEBUG - 2018-04-02 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:50:32 --> CSRF cookie sent
INFO - 2018-04-02 16:50:32 --> Input Class Initialized
INFO - 2018-04-02 16:50:32 --> Language Class Initialized
INFO - 2018-04-02 16:50:32 --> Loader Class Initialized
INFO - 2018-04-02 16:50:32 --> Helper loaded: url_helper
INFO - 2018-04-02 16:50:32 --> Helper loaded: form_helper
DEBUG - 2018-04-02 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 16:50:32 --> User Agent Class Initialized
INFO - 2018-04-02 16:50:32 --> Controller Class Initialized
INFO - 2018-04-02 16:50:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 16:50:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 16:50:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 16:50:32 --> Final output sent to browser
DEBUG - 2018-04-02 16:50:32 --> Total execution time: 0.2230
INFO - 2018-04-02 16:50:33 --> Config Class Initialized
INFO - 2018-04-02 16:50:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:50:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:50:33 --> Utf8 Class Initialized
INFO - 2018-04-02 16:50:33 --> URI Class Initialized
INFO - 2018-04-02 16:50:33 --> Router Class Initialized
INFO - 2018-04-02 16:50:33 --> Output Class Initialized
INFO - 2018-04-02 16:50:33 --> Security Class Initialized
DEBUG - 2018-04-02 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:50:33 --> CSRF cookie sent
INFO - 2018-04-02 16:50:33 --> Input Class Initialized
INFO - 2018-04-02 16:50:33 --> Language Class Initialized
ERROR - 2018-04-02 16:50:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 16:50:33 --> Config Class Initialized
INFO - 2018-04-02 16:50:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:50:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:50:33 --> Utf8 Class Initialized
INFO - 2018-04-02 16:50:33 --> URI Class Initialized
INFO - 2018-04-02 16:50:33 --> Router Class Initialized
INFO - 2018-04-02 16:50:33 --> Output Class Initialized
INFO - 2018-04-02 16:50:33 --> Security Class Initialized
DEBUG - 2018-04-02 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:50:33 --> CSRF cookie sent
INFO - 2018-04-02 16:50:33 --> Input Class Initialized
INFO - 2018-04-02 16:50:33 --> Language Class Initialized
ERROR - 2018-04-02 16:50:33 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 16:50:34 --> Config Class Initialized
INFO - 2018-04-02 16:50:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 16:50:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 16:50:34 --> Utf8 Class Initialized
INFO - 2018-04-02 16:50:34 --> URI Class Initialized
INFO - 2018-04-02 16:50:35 --> Router Class Initialized
INFO - 2018-04-02 16:50:35 --> Output Class Initialized
INFO - 2018-04-02 16:50:35 --> Security Class Initialized
DEBUG - 2018-04-02 16:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 16:50:35 --> CSRF cookie sent
INFO - 2018-04-02 16:50:35 --> Input Class Initialized
INFO - 2018-04-02 16:50:35 --> Language Class Initialized
ERROR - 2018-04-02 16:50:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 17:07:07 --> Config Class Initialized
INFO - 2018-04-02 17:07:07 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:07:07 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:07:07 --> Utf8 Class Initialized
INFO - 2018-04-02 17:07:07 --> URI Class Initialized
INFO - 2018-04-02 17:07:07 --> Router Class Initialized
INFO - 2018-04-02 17:07:07 --> Output Class Initialized
INFO - 2018-04-02 17:07:07 --> Security Class Initialized
DEBUG - 2018-04-02 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:07:07 --> CSRF cookie sent
INFO - 2018-04-02 17:07:07 --> Input Class Initialized
INFO - 2018-04-02 17:07:07 --> Language Class Initialized
INFO - 2018-04-02 17:07:07 --> Loader Class Initialized
INFO - 2018-04-02 17:07:07 --> Helper loaded: url_helper
INFO - 2018-04-02 17:07:07 --> Helper loaded: form_helper
DEBUG - 2018-04-02 17:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 17:07:07 --> User Agent Class Initialized
INFO - 2018-04-02 17:07:07 --> Controller Class Initialized
INFO - 2018-04-02 17:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 17:07:07 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-02 17:07:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 17:07:07 --> Final output sent to browser
DEBUG - 2018-04-02 17:07:07 --> Total execution time: 0.2135
INFO - 2018-04-02 17:07:08 --> Config Class Initialized
INFO - 2018-04-02 17:07:08 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:07:08 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:07:08 --> Utf8 Class Initialized
INFO - 2018-04-02 17:07:08 --> URI Class Initialized
INFO - 2018-04-02 17:07:08 --> Router Class Initialized
INFO - 2018-04-02 17:07:08 --> Output Class Initialized
INFO - 2018-04-02 17:07:08 --> Security Class Initialized
DEBUG - 2018-04-02 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:07:08 --> CSRF cookie sent
INFO - 2018-04-02 17:07:08 --> Input Class Initialized
INFO - 2018-04-02 17:07:08 --> Language Class Initialized
ERROR - 2018-04-02 17:07:08 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 17:07:08 --> Config Class Initialized
INFO - 2018-04-02 17:07:08 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:07:08 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:07:08 --> Utf8 Class Initialized
INFO - 2018-04-02 17:07:08 --> URI Class Initialized
INFO - 2018-04-02 17:07:08 --> Router Class Initialized
INFO - 2018-04-02 17:07:08 --> Output Class Initialized
INFO - 2018-04-02 17:07:08 --> Security Class Initialized
DEBUG - 2018-04-02 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:07:08 --> CSRF cookie sent
INFO - 2018-04-02 17:07:08 --> Input Class Initialized
INFO - 2018-04-02 17:07:08 --> Language Class Initialized
ERROR - 2018-04-02 17:07:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 17:08:05 --> Config Class Initialized
INFO - 2018-04-02 17:08:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:08:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:08:05 --> Utf8 Class Initialized
INFO - 2018-04-02 17:08:05 --> URI Class Initialized
DEBUG - 2018-04-02 17:08:05 --> No URI present. Default controller set.
INFO - 2018-04-02 17:08:05 --> Router Class Initialized
INFO - 2018-04-02 17:08:05 --> Output Class Initialized
INFO - 2018-04-02 17:08:05 --> Security Class Initialized
DEBUG - 2018-04-02 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:08:05 --> CSRF cookie sent
INFO - 2018-04-02 17:08:05 --> Input Class Initialized
INFO - 2018-04-02 17:08:05 --> Language Class Initialized
INFO - 2018-04-02 17:08:05 --> Loader Class Initialized
INFO - 2018-04-02 17:08:05 --> Helper loaded: url_helper
INFO - 2018-04-02 17:08:05 --> Helper loaded: form_helper
DEBUG - 2018-04-02 17:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 17:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 17:08:05 --> User Agent Class Initialized
INFO - 2018-04-02 17:08:05 --> Controller Class Initialized
INFO - 2018-04-02 17:08:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 17:08:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 17:08:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 17:08:05 --> Final output sent to browser
DEBUG - 2018-04-02 17:08:05 --> Total execution time: 0.2119
INFO - 2018-04-02 17:08:05 --> Config Class Initialized
INFO - 2018-04-02 17:08:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:08:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:08:05 --> Utf8 Class Initialized
INFO - 2018-04-02 17:08:05 --> URI Class Initialized
INFO - 2018-04-02 17:08:05 --> Router Class Initialized
INFO - 2018-04-02 17:08:05 --> Output Class Initialized
INFO - 2018-04-02 17:08:05 --> Security Class Initialized
DEBUG - 2018-04-02 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:08:05 --> CSRF cookie sent
INFO - 2018-04-02 17:08:05 --> Input Class Initialized
INFO - 2018-04-02 17:08:05 --> Language Class Initialized
ERROR - 2018-04-02 17:08:05 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 17:08:05 --> Config Class Initialized
INFO - 2018-04-02 17:08:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:08:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:08:05 --> Utf8 Class Initialized
INFO - 2018-04-02 17:08:05 --> URI Class Initialized
INFO - 2018-04-02 17:08:06 --> Router Class Initialized
INFO - 2018-04-02 17:08:06 --> Output Class Initialized
INFO - 2018-04-02 17:08:06 --> Security Class Initialized
DEBUG - 2018-04-02 17:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:08:06 --> CSRF cookie sent
INFO - 2018-04-02 17:08:06 --> Input Class Initialized
INFO - 2018-04-02 17:08:06 --> Language Class Initialized
ERROR - 2018-04-02 17:08:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 17:08:07 --> Config Class Initialized
INFO - 2018-04-02 17:08:07 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:08:07 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:08:07 --> Utf8 Class Initialized
INFO - 2018-04-02 17:08:07 --> URI Class Initialized
INFO - 2018-04-02 17:08:07 --> Router Class Initialized
INFO - 2018-04-02 17:08:07 --> Output Class Initialized
INFO - 2018-04-02 17:08:07 --> Security Class Initialized
DEBUG - 2018-04-02 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:08:07 --> CSRF cookie sent
INFO - 2018-04-02 17:08:07 --> Input Class Initialized
INFO - 2018-04-02 17:08:07 --> Language Class Initialized
ERROR - 2018-04-02 17:08:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 17:16:58 --> Config Class Initialized
INFO - 2018-04-02 17:16:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:16:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:16:58 --> Utf8 Class Initialized
INFO - 2018-04-02 17:16:58 --> URI Class Initialized
INFO - 2018-04-02 17:16:58 --> Router Class Initialized
INFO - 2018-04-02 17:16:58 --> Output Class Initialized
INFO - 2018-04-02 17:16:58 --> Security Class Initialized
DEBUG - 2018-04-02 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:16:58 --> CSRF cookie sent
INFO - 2018-04-02 17:16:58 --> Input Class Initialized
INFO - 2018-04-02 17:16:58 --> Language Class Initialized
INFO - 2018-04-02 17:16:58 --> Loader Class Initialized
INFO - 2018-04-02 17:16:58 --> Helper loaded: url_helper
INFO - 2018-04-02 17:16:58 --> Helper loaded: form_helper
DEBUG - 2018-04-02 17:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 17:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 17:16:59 --> User Agent Class Initialized
INFO - 2018-04-02 17:16:59 --> Controller Class Initialized
INFO - 2018-04-02 17:16:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 17:16:59 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-02 17:16:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 17:16:59 --> Final output sent to browser
DEBUG - 2018-04-02 17:16:59 --> Total execution time: 0.2171
INFO - 2018-04-02 17:16:59 --> Config Class Initialized
INFO - 2018-04-02 17:16:59 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:16:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:16:59 --> Utf8 Class Initialized
INFO - 2018-04-02 17:16:59 --> URI Class Initialized
INFO - 2018-04-02 17:16:59 --> Router Class Initialized
INFO - 2018-04-02 17:16:59 --> Output Class Initialized
INFO - 2018-04-02 17:16:59 --> Security Class Initialized
DEBUG - 2018-04-02 17:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:16:59 --> CSRF cookie sent
INFO - 2018-04-02 17:16:59 --> Input Class Initialized
INFO - 2018-04-02 17:16:59 --> Language Class Initialized
ERROR - 2018-04-02 17:16:59 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 17:16:59 --> Config Class Initialized
INFO - 2018-04-02 17:16:59 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:16:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:16:59 --> Utf8 Class Initialized
INFO - 2018-04-02 17:16:59 --> URI Class Initialized
INFO - 2018-04-02 17:16:59 --> Router Class Initialized
INFO - 2018-04-02 17:16:59 --> Output Class Initialized
INFO - 2018-04-02 17:16:59 --> Security Class Initialized
DEBUG - 2018-04-02 17:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:16:59 --> CSRF cookie sent
INFO - 2018-04-02 17:16:59 --> Input Class Initialized
INFO - 2018-04-02 17:16:59 --> Language Class Initialized
ERROR - 2018-04-02 17:16:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 17:17:55 --> Config Class Initialized
INFO - 2018-04-02 17:17:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:17:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:17:55 --> Utf8 Class Initialized
INFO - 2018-04-02 17:17:55 --> URI Class Initialized
DEBUG - 2018-04-02 17:17:55 --> No URI present. Default controller set.
INFO - 2018-04-02 17:17:55 --> Router Class Initialized
INFO - 2018-04-02 17:17:55 --> Output Class Initialized
INFO - 2018-04-02 17:17:55 --> Security Class Initialized
DEBUG - 2018-04-02 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:17:55 --> CSRF cookie sent
INFO - 2018-04-02 17:17:55 --> Input Class Initialized
INFO - 2018-04-02 17:17:55 --> Language Class Initialized
INFO - 2018-04-02 17:17:55 --> Loader Class Initialized
INFO - 2018-04-02 17:17:55 --> Helper loaded: url_helper
INFO - 2018-04-02 17:17:55 --> Helper loaded: form_helper
DEBUG - 2018-04-02 17:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 17:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 17:17:55 --> User Agent Class Initialized
INFO - 2018-04-02 17:17:55 --> Controller Class Initialized
INFO - 2018-04-02 17:17:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 17:17:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 17:17:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 17:17:55 --> Final output sent to browser
DEBUG - 2018-04-02 17:17:55 --> Total execution time: 0.2230
INFO - 2018-04-02 17:17:55 --> Config Class Initialized
INFO - 2018-04-02 17:17:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:17:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:17:55 --> Utf8 Class Initialized
INFO - 2018-04-02 17:17:55 --> URI Class Initialized
INFO - 2018-04-02 17:17:55 --> Router Class Initialized
INFO - 2018-04-02 17:17:55 --> Output Class Initialized
INFO - 2018-04-02 17:17:55 --> Security Class Initialized
DEBUG - 2018-04-02 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:17:55 --> CSRF cookie sent
INFO - 2018-04-02 17:17:55 --> Input Class Initialized
INFO - 2018-04-02 17:17:55 --> Language Class Initialized
ERROR - 2018-04-02 17:17:55 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 17:17:55 --> Config Class Initialized
INFO - 2018-04-02 17:17:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:17:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:17:55 --> Utf8 Class Initialized
INFO - 2018-04-02 17:17:55 --> URI Class Initialized
INFO - 2018-04-02 17:17:55 --> Router Class Initialized
INFO - 2018-04-02 17:17:55 --> Output Class Initialized
INFO - 2018-04-02 17:17:55 --> Security Class Initialized
DEBUG - 2018-04-02 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:17:55 --> CSRF cookie sent
INFO - 2018-04-02 17:17:55 --> Input Class Initialized
INFO - 2018-04-02 17:17:55 --> Language Class Initialized
ERROR - 2018-04-02 17:17:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 17:17:57 --> Config Class Initialized
INFO - 2018-04-02 17:17:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 17:17:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 17:17:57 --> Utf8 Class Initialized
INFO - 2018-04-02 17:17:57 --> URI Class Initialized
INFO - 2018-04-02 17:17:57 --> Router Class Initialized
INFO - 2018-04-02 17:17:57 --> Output Class Initialized
INFO - 2018-04-02 17:17:57 --> Security Class Initialized
DEBUG - 2018-04-02 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 17:17:57 --> CSRF cookie sent
INFO - 2018-04-02 17:17:57 --> Input Class Initialized
INFO - 2018-04-02 17:17:57 --> Language Class Initialized
ERROR - 2018-04-02 17:17:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:42:58 --> Config Class Initialized
INFO - 2018-04-02 18:42:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:42:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:42:58 --> Utf8 Class Initialized
INFO - 2018-04-02 18:42:58 --> URI Class Initialized
DEBUG - 2018-04-02 18:42:58 --> No URI present. Default controller set.
INFO - 2018-04-02 18:42:58 --> Router Class Initialized
INFO - 2018-04-02 18:42:58 --> Output Class Initialized
INFO - 2018-04-02 18:42:58 --> Security Class Initialized
DEBUG - 2018-04-02 18:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:42:58 --> CSRF cookie sent
INFO - 2018-04-02 18:42:59 --> Input Class Initialized
INFO - 2018-04-02 18:42:59 --> Language Class Initialized
INFO - 2018-04-02 18:42:59 --> Loader Class Initialized
INFO - 2018-04-02 18:42:59 --> Helper loaded: url_helper
INFO - 2018-04-02 18:42:59 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:42:59 --> User Agent Class Initialized
INFO - 2018-04-02 18:42:59 --> Controller Class Initialized
INFO - 2018-04-02 18:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:42:59 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:42:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:42:59 --> Final output sent to browser
DEBUG - 2018-04-02 18:42:59 --> Total execution time: 1.3508
INFO - 2018-04-02 18:43:00 --> Config Class Initialized
INFO - 2018-04-02 18:43:00 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:00 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:00 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:00 --> URI Class Initialized
INFO - 2018-04-02 18:43:00 --> Router Class Initialized
INFO - 2018-04-02 18:43:00 --> Output Class Initialized
INFO - 2018-04-02 18:43:00 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:00 --> CSRF cookie sent
INFO - 2018-04-02 18:43:00 --> Input Class Initialized
INFO - 2018-04-02 18:43:00 --> Language Class Initialized
ERROR - 2018-04-02 18:43:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:43:01 --> Config Class Initialized
INFO - 2018-04-02 18:43:01 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:01 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:01 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:01 --> URI Class Initialized
INFO - 2018-04-02 18:43:01 --> Router Class Initialized
INFO - 2018-04-02 18:43:01 --> Output Class Initialized
INFO - 2018-04-02 18:43:01 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:01 --> CSRF cookie sent
INFO - 2018-04-02 18:43:01 --> Input Class Initialized
INFO - 2018-04-02 18:43:01 --> Language Class Initialized
ERROR - 2018-04-02 18:43:01 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:43:02 --> Config Class Initialized
INFO - 2018-04-02 18:43:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:02 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:02 --> URI Class Initialized
INFO - 2018-04-02 18:43:02 --> Router Class Initialized
INFO - 2018-04-02 18:43:02 --> Output Class Initialized
INFO - 2018-04-02 18:43:02 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:02 --> CSRF cookie sent
INFO - 2018-04-02 18:43:02 --> Input Class Initialized
INFO - 2018-04-02 18:43:02 --> Language Class Initialized
ERROR - 2018-04-02 18:43:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:43:31 --> Config Class Initialized
INFO - 2018-04-02 18:43:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:31 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:31 --> URI Class Initialized
DEBUG - 2018-04-02 18:43:31 --> No URI present. Default controller set.
INFO - 2018-04-02 18:43:31 --> Router Class Initialized
INFO - 2018-04-02 18:43:31 --> Output Class Initialized
INFO - 2018-04-02 18:43:31 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:31 --> CSRF cookie sent
INFO - 2018-04-02 18:43:31 --> Input Class Initialized
INFO - 2018-04-02 18:43:31 --> Language Class Initialized
INFO - 2018-04-02 18:43:31 --> Loader Class Initialized
INFO - 2018-04-02 18:43:31 --> Helper loaded: url_helper
INFO - 2018-04-02 18:43:31 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:43:31 --> User Agent Class Initialized
INFO - 2018-04-02 18:43:31 --> Controller Class Initialized
INFO - 2018-04-02 18:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:43:31 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:43:31 --> Final output sent to browser
DEBUG - 2018-04-02 18:43:31 --> Total execution time: 0.2290
INFO - 2018-04-02 18:43:32 --> Config Class Initialized
INFO - 2018-04-02 18:43:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:32 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:32 --> URI Class Initialized
INFO - 2018-04-02 18:43:32 --> Router Class Initialized
INFO - 2018-04-02 18:43:32 --> Output Class Initialized
INFO - 2018-04-02 18:43:32 --> Config Class Initialized
INFO - 2018-04-02 18:43:32 --> Hooks Class Initialized
INFO - 2018-04-02 18:43:32 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 18:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:32 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:32 --> CSRF cookie sent
INFO - 2018-04-02 18:43:32 --> Input Class Initialized
INFO - 2018-04-02 18:43:32 --> URI Class Initialized
INFO - 2018-04-02 18:43:32 --> Language Class Initialized
INFO - 2018-04-02 18:43:32 --> Router Class Initialized
ERROR - 2018-04-02 18:43:32 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:43:32 --> Output Class Initialized
INFO - 2018-04-02 18:43:32 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:32 --> CSRF cookie sent
INFO - 2018-04-02 18:43:32 --> Input Class Initialized
INFO - 2018-04-02 18:43:32 --> Language Class Initialized
ERROR - 2018-04-02 18:43:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:43:33 --> Config Class Initialized
INFO - 2018-04-02 18:43:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:33 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:33 --> URI Class Initialized
INFO - 2018-04-02 18:43:33 --> Router Class Initialized
INFO - 2018-04-02 18:43:33 --> Output Class Initialized
INFO - 2018-04-02 18:43:33 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:34 --> CSRF cookie sent
INFO - 2018-04-02 18:43:34 --> Input Class Initialized
INFO - 2018-04-02 18:43:34 --> Language Class Initialized
ERROR - 2018-04-02 18:43:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:43:54 --> Config Class Initialized
INFO - 2018-04-02 18:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:54 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:54 --> URI Class Initialized
DEBUG - 2018-04-02 18:43:55 --> No URI present. Default controller set.
INFO - 2018-04-02 18:43:55 --> Router Class Initialized
INFO - 2018-04-02 18:43:55 --> Output Class Initialized
INFO - 2018-04-02 18:43:55 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:55 --> CSRF cookie sent
INFO - 2018-04-02 18:43:55 --> Input Class Initialized
INFO - 2018-04-02 18:43:55 --> Language Class Initialized
INFO - 2018-04-02 18:43:55 --> Loader Class Initialized
INFO - 2018-04-02 18:43:55 --> Helper loaded: url_helper
INFO - 2018-04-02 18:43:55 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:43:55 --> User Agent Class Initialized
INFO - 2018-04-02 18:43:55 --> Controller Class Initialized
INFO - 2018-04-02 18:43:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:43:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:43:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:43:55 --> Final output sent to browser
DEBUG - 2018-04-02 18:43:55 --> Total execution time: 0.2539
INFO - 2018-04-02 18:43:55 --> Config Class Initialized
INFO - 2018-04-02 18:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:55 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:55 --> URI Class Initialized
INFO - 2018-04-02 18:43:55 --> Router Class Initialized
INFO - 2018-04-02 18:43:55 --> Output Class Initialized
INFO - 2018-04-02 18:43:55 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:55 --> CSRF cookie sent
INFO - 2018-04-02 18:43:55 --> Input Class Initialized
INFO - 2018-04-02 18:43:55 --> Language Class Initialized
ERROR - 2018-04-02 18:43:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:43:55 --> Config Class Initialized
INFO - 2018-04-02 18:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:55 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:55 --> URI Class Initialized
INFO - 2018-04-02 18:43:56 --> Router Class Initialized
INFO - 2018-04-02 18:43:56 --> Output Class Initialized
INFO - 2018-04-02 18:43:56 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:56 --> CSRF cookie sent
INFO - 2018-04-02 18:43:56 --> Input Class Initialized
INFO - 2018-04-02 18:43:56 --> Language Class Initialized
ERROR - 2018-04-02 18:43:56 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:43:57 --> Config Class Initialized
INFO - 2018-04-02 18:43:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:43:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:43:57 --> Utf8 Class Initialized
INFO - 2018-04-02 18:43:57 --> URI Class Initialized
INFO - 2018-04-02 18:43:57 --> Router Class Initialized
INFO - 2018-04-02 18:43:57 --> Output Class Initialized
INFO - 2018-04-02 18:43:57 --> Security Class Initialized
DEBUG - 2018-04-02 18:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:43:57 --> CSRF cookie sent
INFO - 2018-04-02 18:43:57 --> Input Class Initialized
INFO - 2018-04-02 18:43:57 --> Language Class Initialized
ERROR - 2018-04-02 18:43:57 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:44:49 --> Config Class Initialized
INFO - 2018-04-02 18:44:49 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:44:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:44:49 --> Utf8 Class Initialized
INFO - 2018-04-02 18:44:49 --> URI Class Initialized
DEBUG - 2018-04-02 18:44:49 --> No URI present. Default controller set.
INFO - 2018-04-02 18:44:49 --> Router Class Initialized
INFO - 2018-04-02 18:44:49 --> Output Class Initialized
INFO - 2018-04-02 18:44:49 --> Security Class Initialized
DEBUG - 2018-04-02 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:44:49 --> CSRF cookie sent
INFO - 2018-04-02 18:44:49 --> Input Class Initialized
INFO - 2018-04-02 18:44:49 --> Language Class Initialized
INFO - 2018-04-02 18:44:49 --> Loader Class Initialized
INFO - 2018-04-02 18:44:49 --> Helper loaded: url_helper
INFO - 2018-04-02 18:44:49 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:44:49 --> User Agent Class Initialized
INFO - 2018-04-02 18:44:49 --> Controller Class Initialized
INFO - 2018-04-02 18:44:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:44:49 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:44:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:44:49 --> Final output sent to browser
DEBUG - 2018-04-02 18:44:49 --> Total execution time: 0.2222
INFO - 2018-04-02 18:44:49 --> Config Class Initialized
INFO - 2018-04-02 18:44:49 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:44:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:44:49 --> Utf8 Class Initialized
INFO - 2018-04-02 18:44:49 --> URI Class Initialized
INFO - 2018-04-02 18:44:49 --> Router Class Initialized
INFO - 2018-04-02 18:44:49 --> Config Class Initialized
INFO - 2018-04-02 18:44:49 --> Hooks Class Initialized
INFO - 2018-04-02 18:44:49 --> Output Class Initialized
DEBUG - 2018-04-02 18:44:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:44:49 --> Utf8 Class Initialized
INFO - 2018-04-02 18:44:49 --> URI Class Initialized
INFO - 2018-04-02 18:44:49 --> Security Class Initialized
DEBUG - 2018-04-02 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:44:49 --> Router Class Initialized
INFO - 2018-04-02 18:44:49 --> CSRF cookie sent
INFO - 2018-04-02 18:44:49 --> Output Class Initialized
INFO - 2018-04-02 18:44:49 --> Input Class Initialized
INFO - 2018-04-02 18:44:49 --> Security Class Initialized
INFO - 2018-04-02 18:44:49 --> Language Class Initialized
DEBUG - 2018-04-02 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:44:49 --> CSRF cookie sent
ERROR - 2018-04-02 18:44:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:44:50 --> Input Class Initialized
INFO - 2018-04-02 18:44:50 --> Language Class Initialized
ERROR - 2018-04-02 18:44:50 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:44:51 --> Config Class Initialized
INFO - 2018-04-02 18:44:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:44:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:44:51 --> Utf8 Class Initialized
INFO - 2018-04-02 18:44:51 --> URI Class Initialized
INFO - 2018-04-02 18:44:51 --> Router Class Initialized
INFO - 2018-04-02 18:44:51 --> Output Class Initialized
INFO - 2018-04-02 18:44:51 --> Security Class Initialized
DEBUG - 2018-04-02 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:44:51 --> CSRF cookie sent
INFO - 2018-04-02 18:44:51 --> Input Class Initialized
INFO - 2018-04-02 18:44:51 --> Language Class Initialized
ERROR - 2018-04-02 18:44:51 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:45:04 --> Config Class Initialized
INFO - 2018-04-02 18:45:04 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:04 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:04 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:04 --> URI Class Initialized
DEBUG - 2018-04-02 18:45:04 --> No URI present. Default controller set.
INFO - 2018-04-02 18:45:04 --> Router Class Initialized
INFO - 2018-04-02 18:45:04 --> Output Class Initialized
INFO - 2018-04-02 18:45:04 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:04 --> CSRF cookie sent
INFO - 2018-04-02 18:45:04 --> Input Class Initialized
INFO - 2018-04-02 18:45:04 --> Language Class Initialized
INFO - 2018-04-02 18:45:04 --> Loader Class Initialized
INFO - 2018-04-02 18:45:04 --> Helper loaded: url_helper
INFO - 2018-04-02 18:45:04 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:45:04 --> User Agent Class Initialized
INFO - 2018-04-02 18:45:04 --> Controller Class Initialized
INFO - 2018-04-02 18:45:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:45:04 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:45:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:45:04 --> Final output sent to browser
DEBUG - 2018-04-02 18:45:04 --> Total execution time: 0.2547
INFO - 2018-04-02 18:45:05 --> Config Class Initialized
INFO - 2018-04-02 18:45:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:05 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:05 --> URI Class Initialized
INFO - 2018-04-02 18:45:05 --> Router Class Initialized
INFO - 2018-04-02 18:45:05 --> Output Class Initialized
INFO - 2018-04-02 18:45:05 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:05 --> CSRF cookie sent
INFO - 2018-04-02 18:45:05 --> Input Class Initialized
INFO - 2018-04-02 18:45:05 --> Language Class Initialized
ERROR - 2018-04-02 18:45:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:45:05 --> Config Class Initialized
INFO - 2018-04-02 18:45:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:05 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:05 --> URI Class Initialized
INFO - 2018-04-02 18:45:06 --> Router Class Initialized
INFO - 2018-04-02 18:45:06 --> Output Class Initialized
INFO - 2018-04-02 18:45:06 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:06 --> CSRF cookie sent
INFO - 2018-04-02 18:45:06 --> Input Class Initialized
INFO - 2018-04-02 18:45:06 --> Language Class Initialized
ERROR - 2018-04-02 18:45:06 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:45:07 --> Config Class Initialized
INFO - 2018-04-02 18:45:07 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:07 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:07 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:07 --> URI Class Initialized
INFO - 2018-04-02 18:45:07 --> Router Class Initialized
INFO - 2018-04-02 18:45:07 --> Output Class Initialized
INFO - 2018-04-02 18:45:07 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:07 --> CSRF cookie sent
INFO - 2018-04-02 18:45:07 --> Input Class Initialized
INFO - 2018-04-02 18:45:07 --> Language Class Initialized
ERROR - 2018-04-02 18:45:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:45:26 --> Config Class Initialized
INFO - 2018-04-02 18:45:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:26 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:26 --> URI Class Initialized
DEBUG - 2018-04-02 18:45:26 --> No URI present. Default controller set.
INFO - 2018-04-02 18:45:26 --> Router Class Initialized
INFO - 2018-04-02 18:45:26 --> Output Class Initialized
INFO - 2018-04-02 18:45:26 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:26 --> CSRF cookie sent
INFO - 2018-04-02 18:45:26 --> Input Class Initialized
INFO - 2018-04-02 18:45:26 --> Language Class Initialized
INFO - 2018-04-02 18:45:26 --> Loader Class Initialized
INFO - 2018-04-02 18:45:26 --> Helper loaded: url_helper
INFO - 2018-04-02 18:45:26 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:45:26 --> User Agent Class Initialized
INFO - 2018-04-02 18:45:26 --> Controller Class Initialized
INFO - 2018-04-02 18:45:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:45:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:45:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:45:27 --> Final output sent to browser
DEBUG - 2018-04-02 18:45:27 --> Total execution time: 0.2396
INFO - 2018-04-02 18:45:27 --> Config Class Initialized
INFO - 2018-04-02 18:45:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:27 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:27 --> URI Class Initialized
INFO - 2018-04-02 18:45:27 --> Router Class Initialized
INFO - 2018-04-02 18:45:27 --> Output Class Initialized
INFO - 2018-04-02 18:45:27 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:27 --> CSRF cookie sent
INFO - 2018-04-02 18:45:27 --> Input Class Initialized
INFO - 2018-04-02 18:45:27 --> Language Class Initialized
ERROR - 2018-04-02 18:45:27 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:45:27 --> Config Class Initialized
INFO - 2018-04-02 18:45:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:27 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:27 --> URI Class Initialized
INFO - 2018-04-02 18:45:27 --> Router Class Initialized
INFO - 2018-04-02 18:45:27 --> Output Class Initialized
INFO - 2018-04-02 18:45:27 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:27 --> CSRF cookie sent
INFO - 2018-04-02 18:45:27 --> Input Class Initialized
INFO - 2018-04-02 18:45:27 --> Language Class Initialized
ERROR - 2018-04-02 18:45:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:45:29 --> Config Class Initialized
INFO - 2018-04-02 18:45:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:29 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:29 --> URI Class Initialized
INFO - 2018-04-02 18:45:29 --> Router Class Initialized
INFO - 2018-04-02 18:45:29 --> Output Class Initialized
INFO - 2018-04-02 18:45:29 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:29 --> CSRF cookie sent
INFO - 2018-04-02 18:45:29 --> Input Class Initialized
INFO - 2018-04-02 18:45:29 --> Language Class Initialized
ERROR - 2018-04-02 18:45:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:45:38 --> Config Class Initialized
INFO - 2018-04-02 18:45:38 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:38 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:38 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:38 --> URI Class Initialized
DEBUG - 2018-04-02 18:45:38 --> No URI present. Default controller set.
INFO - 2018-04-02 18:45:38 --> Router Class Initialized
INFO - 2018-04-02 18:45:38 --> Output Class Initialized
INFO - 2018-04-02 18:45:38 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:38 --> CSRF cookie sent
INFO - 2018-04-02 18:45:38 --> Input Class Initialized
INFO - 2018-04-02 18:45:38 --> Language Class Initialized
INFO - 2018-04-02 18:45:38 --> Loader Class Initialized
INFO - 2018-04-02 18:45:38 --> Helper loaded: url_helper
INFO - 2018-04-02 18:45:38 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:45:38 --> User Agent Class Initialized
INFO - 2018-04-02 18:45:38 --> Controller Class Initialized
INFO - 2018-04-02 18:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:45:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:45:38 --> Final output sent to browser
DEBUG - 2018-04-02 18:45:38 --> Total execution time: 0.2482
INFO - 2018-04-02 18:45:39 --> Config Class Initialized
INFO - 2018-04-02 18:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:39 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:39 --> URI Class Initialized
INFO - 2018-04-02 18:45:39 --> Router Class Initialized
INFO - 2018-04-02 18:45:39 --> Output Class Initialized
INFO - 2018-04-02 18:45:39 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:39 --> CSRF cookie sent
INFO - 2018-04-02 18:45:39 --> Input Class Initialized
INFO - 2018-04-02 18:45:39 --> Language Class Initialized
ERROR - 2018-04-02 18:45:39 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:45:39 --> Config Class Initialized
INFO - 2018-04-02 18:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:39 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:39 --> URI Class Initialized
INFO - 2018-04-02 18:45:39 --> Router Class Initialized
INFO - 2018-04-02 18:45:39 --> Output Class Initialized
INFO - 2018-04-02 18:45:39 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:39 --> CSRF cookie sent
INFO - 2018-04-02 18:45:39 --> Input Class Initialized
INFO - 2018-04-02 18:45:39 --> Language Class Initialized
ERROR - 2018-04-02 18:45:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:45:40 --> Config Class Initialized
INFO - 2018-04-02 18:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:45:40 --> Utf8 Class Initialized
INFO - 2018-04-02 18:45:41 --> URI Class Initialized
INFO - 2018-04-02 18:45:41 --> Router Class Initialized
INFO - 2018-04-02 18:45:41 --> Output Class Initialized
INFO - 2018-04-02 18:45:41 --> Security Class Initialized
DEBUG - 2018-04-02 18:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:45:41 --> CSRF cookie sent
INFO - 2018-04-02 18:45:41 --> Input Class Initialized
INFO - 2018-04-02 18:45:41 --> Language Class Initialized
ERROR - 2018-04-02 18:45:41 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:48:01 --> Config Class Initialized
INFO - 2018-04-02 18:48:01 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:48:01 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:48:01 --> Utf8 Class Initialized
INFO - 2018-04-02 18:48:01 --> URI Class Initialized
DEBUG - 2018-04-02 18:48:01 --> No URI present. Default controller set.
INFO - 2018-04-02 18:48:01 --> Router Class Initialized
INFO - 2018-04-02 18:48:01 --> Output Class Initialized
INFO - 2018-04-02 18:48:01 --> Security Class Initialized
DEBUG - 2018-04-02 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:48:01 --> CSRF cookie sent
INFO - 2018-04-02 18:48:01 --> Input Class Initialized
INFO - 2018-04-02 18:48:01 --> Language Class Initialized
INFO - 2018-04-02 18:48:01 --> Loader Class Initialized
INFO - 2018-04-02 18:48:01 --> Helper loaded: url_helper
INFO - 2018-04-02 18:48:01 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:48:01 --> User Agent Class Initialized
INFO - 2018-04-02 18:48:01 --> Controller Class Initialized
INFO - 2018-04-02 18:48:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:48:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:48:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:48:01 --> Final output sent to browser
DEBUG - 2018-04-02 18:48:01 --> Total execution time: 0.2279
INFO - 2018-04-02 18:48:02 --> Config Class Initialized
INFO - 2018-04-02 18:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:48:02 --> Utf8 Class Initialized
INFO - 2018-04-02 18:48:02 --> URI Class Initialized
INFO - 2018-04-02 18:48:02 --> Router Class Initialized
INFO - 2018-04-02 18:48:02 --> Output Class Initialized
INFO - 2018-04-02 18:48:02 --> Security Class Initialized
DEBUG - 2018-04-02 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:48:02 --> CSRF cookie sent
INFO - 2018-04-02 18:48:02 --> Input Class Initialized
INFO - 2018-04-02 18:48:02 --> Config Class Initialized
INFO - 2018-04-02 18:48:02 --> Hooks Class Initialized
INFO - 2018-04-02 18:48:02 --> Language Class Initialized
ERROR - 2018-04-02 18:48:02 --> 404 Page Not Found: Assets/images
DEBUG - 2018-04-02 18:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:48:02 --> Utf8 Class Initialized
INFO - 2018-04-02 18:48:02 --> URI Class Initialized
INFO - 2018-04-02 18:48:02 --> Router Class Initialized
INFO - 2018-04-02 18:48:02 --> Output Class Initialized
INFO - 2018-04-02 18:48:02 --> Security Class Initialized
DEBUG - 2018-04-02 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:48:02 --> CSRF cookie sent
INFO - 2018-04-02 18:48:02 --> Input Class Initialized
INFO - 2018-04-02 18:48:02 --> Language Class Initialized
ERROR - 2018-04-02 18:48:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:48:03 --> Config Class Initialized
INFO - 2018-04-02 18:48:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:48:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:48:03 --> Utf8 Class Initialized
INFO - 2018-04-02 18:48:03 --> URI Class Initialized
INFO - 2018-04-02 18:48:03 --> Router Class Initialized
INFO - 2018-04-02 18:48:03 --> Output Class Initialized
INFO - 2018-04-02 18:48:03 --> Security Class Initialized
DEBUG - 2018-04-02 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:48:04 --> CSRF cookie sent
INFO - 2018-04-02 18:48:04 --> Input Class Initialized
INFO - 2018-04-02 18:48:04 --> Language Class Initialized
ERROR - 2018-04-02 18:48:04 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 18:50:33 --> Config Class Initialized
INFO - 2018-04-02 18:50:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:50:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:50:33 --> Utf8 Class Initialized
INFO - 2018-04-02 18:50:33 --> URI Class Initialized
DEBUG - 2018-04-02 18:50:33 --> No URI present. Default controller set.
INFO - 2018-04-02 18:50:33 --> Router Class Initialized
INFO - 2018-04-02 18:50:33 --> Output Class Initialized
INFO - 2018-04-02 18:50:33 --> Security Class Initialized
DEBUG - 2018-04-02 18:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:50:33 --> CSRF cookie sent
INFO - 2018-04-02 18:50:33 --> Input Class Initialized
INFO - 2018-04-02 18:50:33 --> Language Class Initialized
INFO - 2018-04-02 18:50:33 --> Loader Class Initialized
INFO - 2018-04-02 18:50:33 --> Helper loaded: url_helper
INFO - 2018-04-02 18:50:33 --> Helper loaded: form_helper
DEBUG - 2018-04-02 18:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 18:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 18:50:33 --> User Agent Class Initialized
INFO - 2018-04-02 18:50:33 --> Controller Class Initialized
INFO - 2018-04-02 18:50:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 18:50:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-02 18:50:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 18:50:33 --> Final output sent to browser
DEBUG - 2018-04-02 18:50:33 --> Total execution time: 0.2306
INFO - 2018-04-02 18:50:34 --> Config Class Initialized
INFO - 2018-04-02 18:50:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:50:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:50:34 --> Utf8 Class Initialized
INFO - 2018-04-02 18:50:34 --> URI Class Initialized
INFO - 2018-04-02 18:50:34 --> Router Class Initialized
INFO - 2018-04-02 18:50:34 --> Output Class Initialized
INFO - 2018-04-02 18:50:34 --> Security Class Initialized
DEBUG - 2018-04-02 18:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:50:34 --> CSRF cookie sent
INFO - 2018-04-02 18:50:34 --> Input Class Initialized
INFO - 2018-04-02 18:50:34 --> Language Class Initialized
ERROR - 2018-04-02 18:50:34 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 18:50:34 --> Config Class Initialized
INFO - 2018-04-02 18:50:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:50:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:50:34 --> Utf8 Class Initialized
INFO - 2018-04-02 18:50:34 --> URI Class Initialized
INFO - 2018-04-02 18:50:34 --> Router Class Initialized
INFO - 2018-04-02 18:50:34 --> Output Class Initialized
INFO - 2018-04-02 18:50:34 --> Security Class Initialized
DEBUG - 2018-04-02 18:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:50:34 --> CSRF cookie sent
INFO - 2018-04-02 18:50:34 --> Input Class Initialized
INFO - 2018-04-02 18:50:34 --> Language Class Initialized
ERROR - 2018-04-02 18:50:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 18:50:36 --> Config Class Initialized
INFO - 2018-04-02 18:50:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 18:50:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 18:50:36 --> Utf8 Class Initialized
INFO - 2018-04-02 18:50:36 --> URI Class Initialized
INFO - 2018-04-02 18:50:36 --> Router Class Initialized
INFO - 2018-04-02 18:50:36 --> Output Class Initialized
INFO - 2018-04-02 18:50:36 --> Security Class Initialized
DEBUG - 2018-04-02 18:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 18:50:36 --> CSRF cookie sent
INFO - 2018-04-02 18:50:36 --> Input Class Initialized
INFO - 2018-04-02 18:50:36 --> Language Class Initialized
ERROR - 2018-04-02 18:50:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-02 22:54:47 --> Config Class Initialized
INFO - 2018-04-02 22:54:47 --> Hooks Class Initialized
DEBUG - 2018-04-02 22:54:47 --> UTF-8 Support Enabled
INFO - 2018-04-02 22:54:47 --> Utf8 Class Initialized
INFO - 2018-04-02 22:54:47 --> URI Class Initialized
INFO - 2018-04-02 22:54:47 --> Router Class Initialized
INFO - 2018-04-02 22:54:47 --> Output Class Initialized
INFO - 2018-04-02 22:54:47 --> Security Class Initialized
DEBUG - 2018-04-02 22:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 22:54:47 --> CSRF cookie sent
INFO - 2018-04-02 22:54:47 --> Input Class Initialized
INFO - 2018-04-02 22:54:47 --> Language Class Initialized
INFO - 2018-04-02 22:54:47 --> Loader Class Initialized
INFO - 2018-04-02 22:54:47 --> Helper loaded: url_helper
INFO - 2018-04-02 22:54:47 --> Helper loaded: form_helper
DEBUG - 2018-04-02 22:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 22:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 22:54:48 --> User Agent Class Initialized
INFO - 2018-04-02 22:54:48 --> Controller Class Initialized
INFO - 2018-04-02 22:54:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-02 22:54:48 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-02 22:54:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-02 22:54:48 --> Final output sent to browser
DEBUG - 2018-04-02 22:54:48 --> Total execution time: 0.6938
INFO - 2018-04-02 22:54:48 --> Config Class Initialized
INFO - 2018-04-02 22:54:48 --> Hooks Class Initialized
DEBUG - 2018-04-02 22:54:48 --> UTF-8 Support Enabled
INFO - 2018-04-02 22:54:48 --> Utf8 Class Initialized
INFO - 2018-04-02 22:54:48 --> URI Class Initialized
INFO - 2018-04-02 22:54:48 --> Router Class Initialized
INFO - 2018-04-02 22:54:48 --> Output Class Initialized
INFO - 2018-04-02 22:54:48 --> Security Class Initialized
DEBUG - 2018-04-02 22:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 22:54:48 --> CSRF cookie sent
INFO - 2018-04-02 22:54:48 --> Input Class Initialized
INFO - 2018-04-02 22:54:48 --> Language Class Initialized
ERROR - 2018-04-02 22:54:48 --> 404 Page Not Found: Assets/images
INFO - 2018-04-02 22:54:51 --> Config Class Initialized
INFO - 2018-04-02 22:54:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 22:54:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 22:54:51 --> Utf8 Class Initialized
INFO - 2018-04-02 22:54:51 --> URI Class Initialized
INFO - 2018-04-02 22:54:51 --> Router Class Initialized
INFO - 2018-04-02 22:54:51 --> Output Class Initialized
INFO - 2018-04-02 22:54:51 --> Security Class Initialized
DEBUG - 2018-04-02 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 22:54:51 --> CSRF cookie sent
INFO - 2018-04-02 22:54:51 --> Input Class Initialized
INFO - 2018-04-02 22:54:51 --> Language Class Initialized
ERROR - 2018-04-02 22:54:51 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-03 22:03:53 --> Config Class Initialized
INFO - 2018-04-03 22:03:53 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:03:53 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:03:53 --> Utf8 Class Initialized
INFO - 2018-04-03 22:03:53 --> URI Class Initialized
INFO - 2018-04-03 22:03:53 --> Router Class Initialized
INFO - 2018-04-03 22:03:54 --> Output Class Initialized
INFO - 2018-04-03 22:03:54 --> Security Class Initialized
DEBUG - 2018-04-03 22:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:03:54 --> CSRF cookie sent
INFO - 2018-04-03 22:03:54 --> Input Class Initialized
INFO - 2018-04-03 22:03:54 --> Language Class Initialized
INFO - 2018-04-03 22:03:54 --> Loader Class Initialized
INFO - 2018-04-03 22:03:54 --> Helper loaded: url_helper
INFO - 2018-04-03 22:03:54 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:03:54 --> User Agent Class Initialized
INFO - 2018-04-03 22:03:54 --> Controller Class Initialized
INFO - 2018-04-03 22:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:03:54 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:03:54 --> Final output sent to browser
DEBUG - 2018-04-03 22:03:54 --> Total execution time: 0.6122
INFO - 2018-04-03 22:03:54 --> Config Class Initialized
INFO - 2018-04-03 22:03:54 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:03:54 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:03:54 --> Utf8 Class Initialized
INFO - 2018-04-03 22:03:54 --> URI Class Initialized
INFO - 2018-04-03 22:03:54 --> Router Class Initialized
INFO - 2018-04-03 22:03:54 --> Output Class Initialized
INFO - 2018-04-03 22:03:54 --> Security Class Initialized
DEBUG - 2018-04-03 22:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:03:54 --> CSRF cookie sent
INFO - 2018-04-03 22:03:54 --> Input Class Initialized
INFO - 2018-04-03 22:03:54 --> Language Class Initialized
ERROR - 2018-04-03 22:03:54 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:07:23 --> Config Class Initialized
INFO - 2018-04-03 22:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:07:23 --> Utf8 Class Initialized
INFO - 2018-04-03 22:07:23 --> URI Class Initialized
INFO - 2018-04-03 22:07:23 --> Router Class Initialized
INFO - 2018-04-03 22:07:23 --> Output Class Initialized
INFO - 2018-04-03 22:07:23 --> Security Class Initialized
DEBUG - 2018-04-03 22:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:07:23 --> CSRF cookie sent
INFO - 2018-04-03 22:07:23 --> Input Class Initialized
INFO - 2018-04-03 22:07:23 --> Language Class Initialized
INFO - 2018-04-03 22:07:23 --> Loader Class Initialized
INFO - 2018-04-03 22:07:23 --> Helper loaded: url_helper
INFO - 2018-04-03 22:07:23 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:07:23 --> User Agent Class Initialized
INFO - 2018-04-03 22:07:23 --> Controller Class Initialized
INFO - 2018-04-03 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-03 22:07:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string E:\www\yacopoo\application\views\01_register.php 15
INFO - 2018-04-03 22:07:23 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:07:23 --> Final output sent to browser
DEBUG - 2018-04-03 22:07:23 --> Total execution time: 0.2119
INFO - 2018-04-03 22:07:23 --> Config Class Initialized
INFO - 2018-04-03 22:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:07:23 --> Utf8 Class Initialized
INFO - 2018-04-03 22:07:23 --> URI Class Initialized
INFO - 2018-04-03 22:07:23 --> Router Class Initialized
INFO - 2018-04-03 22:07:23 --> Output Class Initialized
INFO - 2018-04-03 22:07:23 --> Security Class Initialized
DEBUG - 2018-04-03 22:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:07:23 --> CSRF cookie sent
INFO - 2018-04-03 22:07:23 --> Input Class Initialized
INFO - 2018-04-03 22:07:23 --> Language Class Initialized
ERROR - 2018-04-03 22:07:23 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:08:03 --> Config Class Initialized
INFO - 2018-04-03 22:08:03 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:08:03 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:08:03 --> Utf8 Class Initialized
INFO - 2018-04-03 22:08:03 --> URI Class Initialized
INFO - 2018-04-03 22:08:03 --> Router Class Initialized
INFO - 2018-04-03 22:08:03 --> Output Class Initialized
INFO - 2018-04-03 22:08:03 --> Security Class Initialized
DEBUG - 2018-04-03 22:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:08:03 --> CSRF cookie sent
INFO - 2018-04-03 22:08:03 --> Input Class Initialized
INFO - 2018-04-03 22:08:03 --> Language Class Initialized
INFO - 2018-04-03 22:08:03 --> Loader Class Initialized
INFO - 2018-04-03 22:08:03 --> Helper loaded: url_helper
INFO - 2018-04-03 22:08:03 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:08:03 --> User Agent Class Initialized
INFO - 2018-04-03 22:08:03 --> Controller Class Initialized
INFO - 2018-04-03 22:08:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:08:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:08:03 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:08:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:08:03 --> Final output sent to browser
DEBUG - 2018-04-03 22:08:03 --> Total execution time: 0.1855
INFO - 2018-04-03 22:08:03 --> Config Class Initialized
INFO - 2018-04-03 22:08:03 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:08:03 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:08:03 --> Utf8 Class Initialized
INFO - 2018-04-03 22:08:03 --> URI Class Initialized
INFO - 2018-04-03 22:08:03 --> Router Class Initialized
INFO - 2018-04-03 22:08:03 --> Output Class Initialized
INFO - 2018-04-03 22:08:03 --> Security Class Initialized
DEBUG - 2018-04-03 22:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:08:03 --> CSRF cookie sent
INFO - 2018-04-03 22:08:03 --> Input Class Initialized
INFO - 2018-04-03 22:08:03 --> Language Class Initialized
ERROR - 2018-04-03 22:08:03 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:08:30 --> Config Class Initialized
INFO - 2018-04-03 22:08:30 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:08:30 --> Utf8 Class Initialized
INFO - 2018-04-03 22:08:30 --> URI Class Initialized
INFO - 2018-04-03 22:08:30 --> Router Class Initialized
INFO - 2018-04-03 22:08:30 --> Output Class Initialized
INFO - 2018-04-03 22:08:30 --> Security Class Initialized
DEBUG - 2018-04-03 22:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:08:30 --> CSRF cookie sent
INFO - 2018-04-03 22:08:30 --> Input Class Initialized
INFO - 2018-04-03 22:08:30 --> Language Class Initialized
ERROR - 2018-04-03 22:08:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:09:49 --> Config Class Initialized
INFO - 2018-04-03 22:09:49 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:09:49 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:09:49 --> Utf8 Class Initialized
INFO - 2018-04-03 22:09:49 --> URI Class Initialized
INFO - 2018-04-03 22:09:49 --> Router Class Initialized
INFO - 2018-04-03 22:09:49 --> Output Class Initialized
INFO - 2018-04-03 22:09:49 --> Security Class Initialized
DEBUG - 2018-04-03 22:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:09:49 --> CSRF cookie sent
INFO - 2018-04-03 22:09:49 --> Input Class Initialized
INFO - 2018-04-03 22:09:49 --> Language Class Initialized
INFO - 2018-04-03 22:09:49 --> Loader Class Initialized
INFO - 2018-04-03 22:09:49 --> Helper loaded: url_helper
INFO - 2018-04-03 22:09:49 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:09:49 --> User Agent Class Initialized
INFO - 2018-04-03 22:09:49 --> Controller Class Initialized
INFO - 2018-04-03 22:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:09:49 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:09:49 --> Final output sent to browser
DEBUG - 2018-04-03 22:09:49 --> Total execution time: 0.2066
INFO - 2018-04-03 22:09:49 --> Config Class Initialized
INFO - 2018-04-03 22:09:49 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:09:49 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:09:49 --> Utf8 Class Initialized
INFO - 2018-04-03 22:09:49 --> URI Class Initialized
INFO - 2018-04-03 22:09:49 --> Router Class Initialized
INFO - 2018-04-03 22:09:49 --> Output Class Initialized
INFO - 2018-04-03 22:09:49 --> Security Class Initialized
DEBUG - 2018-04-03 22:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:09:49 --> CSRF cookie sent
INFO - 2018-04-03 22:09:49 --> Input Class Initialized
INFO - 2018-04-03 22:09:49 --> Language Class Initialized
INFO - 2018-04-03 22:09:49 --> Config Class Initialized
INFO - 2018-04-03 22:09:49 --> Hooks Class Initialized
ERROR - 2018-04-03 22:09:49 --> 404 Page Not Found: Assets/images
DEBUG - 2018-04-03 22:09:49 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:09:49 --> Utf8 Class Initialized
INFO - 2018-04-03 22:09:50 --> URI Class Initialized
INFO - 2018-04-03 22:09:50 --> Router Class Initialized
INFO - 2018-04-03 22:09:50 --> Output Class Initialized
INFO - 2018-04-03 22:09:50 --> Security Class Initialized
DEBUG - 2018-04-03 22:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:09:50 --> CSRF cookie sent
INFO - 2018-04-03 22:09:50 --> Input Class Initialized
INFO - 2018-04-03 22:09:50 --> Language Class Initialized
ERROR - 2018-04-03 22:09:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:11:43 --> Config Class Initialized
INFO - 2018-04-03 22:11:43 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:11:43 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:11:43 --> Utf8 Class Initialized
INFO - 2018-04-03 22:11:43 --> URI Class Initialized
INFO - 2018-04-03 22:11:43 --> Router Class Initialized
INFO - 2018-04-03 22:11:43 --> Output Class Initialized
INFO - 2018-04-03 22:11:43 --> Security Class Initialized
DEBUG - 2018-04-03 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:11:43 --> CSRF cookie sent
INFO - 2018-04-03 22:11:43 --> Input Class Initialized
INFO - 2018-04-03 22:11:43 --> Language Class Initialized
INFO - 2018-04-03 22:11:43 --> Loader Class Initialized
INFO - 2018-04-03 22:11:43 --> Helper loaded: url_helper
INFO - 2018-04-03 22:11:43 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:11:43 --> User Agent Class Initialized
INFO - 2018-04-03 22:11:43 --> Controller Class Initialized
INFO - 2018-04-03 22:11:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:11:43 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:11:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:11:43 --> Final output sent to browser
DEBUG - 2018-04-03 22:11:43 --> Total execution time: 0.2068
INFO - 2018-04-03 22:11:43 --> Config Class Initialized
INFO - 2018-04-03 22:11:43 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:11:43 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:11:43 --> Utf8 Class Initialized
INFO - 2018-04-03 22:11:43 --> URI Class Initialized
INFO - 2018-04-03 22:11:43 --> Router Class Initialized
INFO - 2018-04-03 22:11:43 --> Output Class Initialized
INFO - 2018-04-03 22:11:43 --> Security Class Initialized
DEBUG - 2018-04-03 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:11:43 --> CSRF cookie sent
INFO - 2018-04-03 22:11:43 --> Input Class Initialized
INFO - 2018-04-03 22:11:43 --> Language Class Initialized
ERROR - 2018-04-03 22:11:43 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:11:43 --> Config Class Initialized
INFO - 2018-04-03 22:11:43 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:11:43 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:11:43 --> Utf8 Class Initialized
INFO - 2018-04-03 22:11:43 --> URI Class Initialized
INFO - 2018-04-03 22:11:43 --> Router Class Initialized
INFO - 2018-04-03 22:11:43 --> Output Class Initialized
INFO - 2018-04-03 22:11:43 --> Security Class Initialized
DEBUG - 2018-04-03 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:11:43 --> CSRF cookie sent
INFO - 2018-04-03 22:11:43 --> Input Class Initialized
INFO - 2018-04-03 22:11:43 --> Language Class Initialized
ERROR - 2018-04-03 22:11:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:12:02 --> Config Class Initialized
INFO - 2018-04-03 22:12:02 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:12:02 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:12:02 --> Utf8 Class Initialized
INFO - 2018-04-03 22:12:02 --> URI Class Initialized
INFO - 2018-04-03 22:12:02 --> Router Class Initialized
INFO - 2018-04-03 22:12:02 --> Output Class Initialized
INFO - 2018-04-03 22:12:02 --> Security Class Initialized
DEBUG - 2018-04-03 22:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:12:02 --> CSRF cookie sent
INFO - 2018-04-03 22:12:02 --> Input Class Initialized
INFO - 2018-04-03 22:12:02 --> Language Class Initialized
INFO - 2018-04-03 22:12:02 --> Loader Class Initialized
INFO - 2018-04-03 22:12:02 --> Helper loaded: url_helper
INFO - 2018-04-03 22:12:02 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:12:02 --> User Agent Class Initialized
INFO - 2018-04-03 22:12:02 --> Controller Class Initialized
INFO - 2018-04-03 22:12:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:12:02 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:12:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:12:02 --> Final output sent to browser
DEBUG - 2018-04-03 22:12:02 --> Total execution time: 0.1912
INFO - 2018-04-03 22:12:03 --> Config Class Initialized
INFO - 2018-04-03 22:12:03 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:12:03 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:12:03 --> Utf8 Class Initialized
INFO - 2018-04-03 22:12:03 --> URI Class Initialized
INFO - 2018-04-03 22:12:03 --> Router Class Initialized
INFO - 2018-04-03 22:12:03 --> Output Class Initialized
INFO - 2018-04-03 22:12:03 --> Security Class Initialized
DEBUG - 2018-04-03 22:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:12:03 --> CSRF cookie sent
INFO - 2018-04-03 22:12:03 --> Input Class Initialized
INFO - 2018-04-03 22:12:03 --> Language Class Initialized
ERROR - 2018-04-03 22:12:03 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:12:03 --> Config Class Initialized
INFO - 2018-04-03 22:12:03 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:12:03 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:12:03 --> Utf8 Class Initialized
INFO - 2018-04-03 22:12:03 --> URI Class Initialized
INFO - 2018-04-03 22:12:03 --> Router Class Initialized
INFO - 2018-04-03 22:12:03 --> Output Class Initialized
INFO - 2018-04-03 22:12:03 --> Security Class Initialized
DEBUG - 2018-04-03 22:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:12:03 --> CSRF cookie sent
INFO - 2018-04-03 22:12:03 --> Input Class Initialized
INFO - 2018-04-03 22:12:03 --> Language Class Initialized
ERROR - 2018-04-03 22:12:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:06 --> Config Class Initialized
INFO - 2018-04-03 22:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:06 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:06 --> URI Class Initialized
INFO - 2018-04-03 22:16:06 --> Router Class Initialized
INFO - 2018-04-03 22:16:06 --> Output Class Initialized
INFO - 2018-04-03 22:16:06 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:06 --> CSRF cookie sent
INFO - 2018-04-03 22:16:06 --> Input Class Initialized
INFO - 2018-04-03 22:16:06 --> Language Class Initialized
INFO - 2018-04-03 22:16:06 --> Loader Class Initialized
INFO - 2018-04-03 22:16:06 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:06 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:06 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:06 --> Controller Class Initialized
INFO - 2018-04-03 22:16:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:06 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:16:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:06 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:06 --> Total execution time: 0.1889
INFO - 2018-04-03 22:16:06 --> Config Class Initialized
INFO - 2018-04-03 22:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:06 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:06 --> URI Class Initialized
INFO - 2018-04-03 22:16:06 --> Router Class Initialized
INFO - 2018-04-03 22:16:06 --> Output Class Initialized
INFO - 2018-04-03 22:16:06 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:06 --> CSRF cookie sent
INFO - 2018-04-03 22:16:06 --> Input Class Initialized
INFO - 2018-04-03 22:16:06 --> Language Class Initialized
ERROR - 2018-04-03 22:16:06 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:07 --> Config Class Initialized
INFO - 2018-04-03 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:07 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:07 --> URI Class Initialized
INFO - 2018-04-03 22:16:07 --> Router Class Initialized
INFO - 2018-04-03 22:16:07 --> Output Class Initialized
INFO - 2018-04-03 22:16:07 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:07 --> CSRF cookie sent
INFO - 2018-04-03 22:16:07 --> Input Class Initialized
INFO - 2018-04-03 22:16:07 --> Language Class Initialized
ERROR - 2018-04-03 22:16:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:08 --> Config Class Initialized
INFO - 2018-04-03 22:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:08 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:08 --> URI Class Initialized
INFO - 2018-04-03 22:16:08 --> Router Class Initialized
INFO - 2018-04-03 22:16:08 --> Output Class Initialized
INFO - 2018-04-03 22:16:08 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:08 --> CSRF cookie sent
INFO - 2018-04-03 22:16:08 --> Input Class Initialized
INFO - 2018-04-03 22:16:08 --> Language Class Initialized
INFO - 2018-04-03 22:16:08 --> Loader Class Initialized
INFO - 2018-04-03 22:16:08 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:08 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:08 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:08 --> Controller Class Initialized
INFO - 2018-04-03 22:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:16:08 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:08 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:08 --> Total execution time: 0.2542
INFO - 2018-04-03 22:16:08 --> Config Class Initialized
INFO - 2018-04-03 22:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:08 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:08 --> URI Class Initialized
INFO - 2018-04-03 22:16:08 --> Router Class Initialized
INFO - 2018-04-03 22:16:08 --> Output Class Initialized
INFO - 2018-04-03 22:16:08 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:08 --> CSRF cookie sent
INFO - 2018-04-03 22:16:08 --> Input Class Initialized
INFO - 2018-04-03 22:16:08 --> Language Class Initialized
ERROR - 2018-04-03 22:16:08 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:08 --> Config Class Initialized
INFO - 2018-04-03 22:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:08 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:08 --> URI Class Initialized
INFO - 2018-04-03 22:16:08 --> Router Class Initialized
INFO - 2018-04-03 22:16:08 --> Output Class Initialized
INFO - 2018-04-03 22:16:08 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:08 --> CSRF cookie sent
INFO - 2018-04-03 22:16:08 --> Input Class Initialized
INFO - 2018-04-03 22:16:08 --> Language Class Initialized
ERROR - 2018-04-03 22:16:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:10 --> Config Class Initialized
INFO - 2018-04-03 22:16:10 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:10 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:10 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:10 --> URI Class Initialized
INFO - 2018-04-03 22:16:10 --> Router Class Initialized
INFO - 2018-04-03 22:16:10 --> Output Class Initialized
INFO - 2018-04-03 22:16:10 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:10 --> CSRF cookie sent
INFO - 2018-04-03 22:16:10 --> Input Class Initialized
INFO - 2018-04-03 22:16:10 --> Language Class Initialized
INFO - 2018-04-03 22:16:10 --> Loader Class Initialized
INFO - 2018-04-03 22:16:10 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:10 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:10 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:10 --> Controller Class Initialized
INFO - 2018-04-03 22:16:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:16:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:16:10 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:16:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:10 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:10 --> Total execution time: 0.2256
INFO - 2018-04-03 22:16:10 --> Config Class Initialized
INFO - 2018-04-03 22:16:10 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:10 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:10 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:10 --> URI Class Initialized
INFO - 2018-04-03 22:16:10 --> Router Class Initialized
INFO - 2018-04-03 22:16:10 --> Output Class Initialized
INFO - 2018-04-03 22:16:10 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:10 --> CSRF cookie sent
INFO - 2018-04-03 22:16:10 --> Input Class Initialized
INFO - 2018-04-03 22:16:10 --> Language Class Initialized
ERROR - 2018-04-03 22:16:10 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:10 --> Config Class Initialized
INFO - 2018-04-03 22:16:10 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:10 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:10 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:10 --> URI Class Initialized
INFO - 2018-04-03 22:16:10 --> Router Class Initialized
INFO - 2018-04-03 22:16:10 --> Output Class Initialized
INFO - 2018-04-03 22:16:10 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:10 --> CSRF cookie sent
INFO - 2018-04-03 22:16:10 --> Input Class Initialized
INFO - 2018-04-03 22:16:11 --> Language Class Initialized
ERROR - 2018-04-03 22:16:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:18 --> Config Class Initialized
INFO - 2018-04-03 22:16:18 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:18 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:18 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:18 --> URI Class Initialized
INFO - 2018-04-03 22:16:18 --> Router Class Initialized
INFO - 2018-04-03 22:16:18 --> Output Class Initialized
INFO - 2018-04-03 22:16:18 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:18 --> CSRF cookie sent
INFO - 2018-04-03 22:16:18 --> Input Class Initialized
INFO - 2018-04-03 22:16:18 --> Language Class Initialized
INFO - 2018-04-03 22:16:18 --> Loader Class Initialized
INFO - 2018-04-03 22:16:18 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:18 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:18 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:18 --> Controller Class Initialized
INFO - 2018-04-03 22:16:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:18 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:16:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:18 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:18 --> Total execution time: 0.2070
INFO - 2018-04-03 22:16:19 --> Config Class Initialized
INFO - 2018-04-03 22:16:19 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:19 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:19 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:19 --> URI Class Initialized
INFO - 2018-04-03 22:16:19 --> Router Class Initialized
INFO - 2018-04-03 22:16:19 --> Output Class Initialized
INFO - 2018-04-03 22:16:19 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:19 --> CSRF cookie sent
INFO - 2018-04-03 22:16:19 --> Input Class Initialized
INFO - 2018-04-03 22:16:19 --> Language Class Initialized
ERROR - 2018-04-03 22:16:19 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:19 --> Config Class Initialized
INFO - 2018-04-03 22:16:19 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:19 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:19 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:19 --> URI Class Initialized
INFO - 2018-04-03 22:16:19 --> Router Class Initialized
INFO - 2018-04-03 22:16:19 --> Output Class Initialized
INFO - 2018-04-03 22:16:19 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:19 --> CSRF cookie sent
INFO - 2018-04-03 22:16:19 --> Input Class Initialized
INFO - 2018-04-03 22:16:19 --> Language Class Initialized
ERROR - 2018-04-03 22:16:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:21 --> Config Class Initialized
INFO - 2018-04-03 22:16:21 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:21 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:21 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:21 --> URI Class Initialized
INFO - 2018-04-03 22:16:21 --> Router Class Initialized
INFO - 2018-04-03 22:16:21 --> Output Class Initialized
INFO - 2018-04-03 22:16:21 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:21 --> CSRF cookie sent
INFO - 2018-04-03 22:16:21 --> Input Class Initialized
INFO - 2018-04-03 22:16:21 --> Language Class Initialized
INFO - 2018-04-03 22:16:21 --> Loader Class Initialized
INFO - 2018-04-03 22:16:21 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:21 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:21 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:21 --> Controller Class Initialized
INFO - 2018-04-03 22:16:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:16:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:16:21 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:16:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:21 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:21 --> Total execution time: 0.2146
INFO - 2018-04-03 22:16:21 --> Config Class Initialized
INFO - 2018-04-03 22:16:21 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:21 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:21 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:21 --> URI Class Initialized
INFO - 2018-04-03 22:16:21 --> Router Class Initialized
INFO - 2018-04-03 22:16:21 --> Output Class Initialized
INFO - 2018-04-03 22:16:21 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:21 --> CSRF cookie sent
INFO - 2018-04-03 22:16:21 --> Input Class Initialized
INFO - 2018-04-03 22:16:21 --> Language Class Initialized
ERROR - 2018-04-03 22:16:21 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:21 --> Config Class Initialized
INFO - 2018-04-03 22:16:21 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:21 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:21 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:21 --> URI Class Initialized
INFO - 2018-04-03 22:16:21 --> Router Class Initialized
INFO - 2018-04-03 22:16:21 --> Output Class Initialized
INFO - 2018-04-03 22:16:21 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:21 --> CSRF cookie sent
INFO - 2018-04-03 22:16:21 --> Input Class Initialized
INFO - 2018-04-03 22:16:21 --> Language Class Initialized
ERROR - 2018-04-03 22:16:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:16:56 --> Config Class Initialized
INFO - 2018-04-03 22:16:56 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:56 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:56 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:56 --> URI Class Initialized
INFO - 2018-04-03 22:16:56 --> Router Class Initialized
INFO - 2018-04-03 22:16:56 --> Output Class Initialized
INFO - 2018-04-03 22:16:56 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:57 --> CSRF cookie sent
INFO - 2018-04-03 22:16:57 --> Input Class Initialized
INFO - 2018-04-03 22:16:57 --> Language Class Initialized
INFO - 2018-04-03 22:16:57 --> Loader Class Initialized
INFO - 2018-04-03 22:16:57 --> Helper loaded: url_helper
INFO - 2018-04-03 22:16:57 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:16:57 --> User Agent Class Initialized
INFO - 2018-04-03 22:16:57 --> Controller Class Initialized
INFO - 2018-04-03 22:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:16:57 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:16:57 --> Final output sent to browser
DEBUG - 2018-04-03 22:16:57 --> Total execution time: 0.2270
INFO - 2018-04-03 22:16:57 --> Config Class Initialized
INFO - 2018-04-03 22:16:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:57 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:57 --> URI Class Initialized
INFO - 2018-04-03 22:16:57 --> Router Class Initialized
INFO - 2018-04-03 22:16:57 --> Output Class Initialized
INFO - 2018-04-03 22:16:57 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:57 --> CSRF cookie sent
INFO - 2018-04-03 22:16:57 --> Input Class Initialized
INFO - 2018-04-03 22:16:57 --> Language Class Initialized
ERROR - 2018-04-03 22:16:57 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:16:57 --> Config Class Initialized
INFO - 2018-04-03 22:16:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:16:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:16:57 --> Utf8 Class Initialized
INFO - 2018-04-03 22:16:57 --> URI Class Initialized
INFO - 2018-04-03 22:16:57 --> Router Class Initialized
INFO - 2018-04-03 22:16:57 --> Output Class Initialized
INFO - 2018-04-03 22:16:57 --> Security Class Initialized
DEBUG - 2018-04-03 22:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:16:57 --> CSRF cookie sent
INFO - 2018-04-03 22:16:57 --> Input Class Initialized
INFO - 2018-04-03 22:16:57 --> Language Class Initialized
ERROR - 2018-04-03 22:16:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:17:25 --> Config Class Initialized
INFO - 2018-04-03 22:17:25 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:17:25 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:17:25 --> Utf8 Class Initialized
INFO - 2018-04-03 22:17:25 --> URI Class Initialized
INFO - 2018-04-03 22:17:25 --> Router Class Initialized
INFO - 2018-04-03 22:17:25 --> Output Class Initialized
INFO - 2018-04-03 22:17:25 --> Security Class Initialized
DEBUG - 2018-04-03 22:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:17:25 --> CSRF cookie sent
INFO - 2018-04-03 22:17:25 --> Input Class Initialized
INFO - 2018-04-03 22:17:25 --> Language Class Initialized
INFO - 2018-04-03 22:17:25 --> Loader Class Initialized
INFO - 2018-04-03 22:17:25 --> Helper loaded: url_helper
INFO - 2018-04-03 22:17:25 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:17:25 --> User Agent Class Initialized
INFO - 2018-04-03 22:17:25 --> Controller Class Initialized
INFO - 2018-04-03 22:17:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:17:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:17:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:17:25 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-03 22:17:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:17:25 --> Final output sent to browser
DEBUG - 2018-04-03 22:17:25 --> Total execution time: 0.2302
INFO - 2018-04-03 22:17:26 --> Config Class Initialized
INFO - 2018-04-03 22:17:26 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:17:26 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:17:26 --> Utf8 Class Initialized
INFO - 2018-04-03 22:17:26 --> URI Class Initialized
INFO - 2018-04-03 22:17:26 --> Router Class Initialized
INFO - 2018-04-03 22:17:26 --> Output Class Initialized
INFO - 2018-04-03 22:17:26 --> Security Class Initialized
DEBUG - 2018-04-03 22:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:17:26 --> CSRF cookie sent
INFO - 2018-04-03 22:17:26 --> Input Class Initialized
INFO - 2018-04-03 22:17:26 --> Language Class Initialized
ERROR - 2018-04-03 22:17:26 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:17:26 --> Config Class Initialized
INFO - 2018-04-03 22:17:26 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:17:26 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:17:26 --> Utf8 Class Initialized
INFO - 2018-04-03 22:17:26 --> URI Class Initialized
INFO - 2018-04-03 22:17:26 --> Router Class Initialized
INFO - 2018-04-03 22:17:26 --> Output Class Initialized
INFO - 2018-04-03 22:17:26 --> Security Class Initialized
DEBUG - 2018-04-03 22:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:17:26 --> CSRF cookie sent
INFO - 2018-04-03 22:17:26 --> Input Class Initialized
INFO - 2018-04-03 22:17:26 --> Language Class Initialized
ERROR - 2018-04-03 22:17:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:18:00 --> Config Class Initialized
INFO - 2018-04-03 22:18:00 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:18:00 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:18:00 --> Utf8 Class Initialized
INFO - 2018-04-03 22:18:01 --> URI Class Initialized
INFO - 2018-04-03 22:18:01 --> Router Class Initialized
INFO - 2018-04-03 22:18:01 --> Output Class Initialized
INFO - 2018-04-03 22:18:01 --> Security Class Initialized
DEBUG - 2018-04-03 22:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:18:01 --> CSRF cookie sent
INFO - 2018-04-03 22:18:01 --> Input Class Initialized
INFO - 2018-04-03 22:18:01 --> Language Class Initialized
INFO - 2018-04-03 22:18:01 --> Loader Class Initialized
INFO - 2018-04-03 22:18:01 --> Helper loaded: url_helper
INFO - 2018-04-03 22:18:01 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:18:01 --> User Agent Class Initialized
INFO - 2018-04-03 22:18:01 --> Controller Class Initialized
INFO - 2018-04-03 22:18:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:18:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:18:01 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:18:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:18:01 --> Final output sent to browser
DEBUG - 2018-04-03 22:18:01 --> Total execution time: 0.2103
INFO - 2018-04-03 22:18:01 --> Config Class Initialized
INFO - 2018-04-03 22:18:01 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:18:01 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:18:01 --> Utf8 Class Initialized
INFO - 2018-04-03 22:18:01 --> URI Class Initialized
INFO - 2018-04-03 22:18:01 --> Router Class Initialized
INFO - 2018-04-03 22:18:01 --> Output Class Initialized
INFO - 2018-04-03 22:18:01 --> Security Class Initialized
DEBUG - 2018-04-03 22:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:18:01 --> CSRF cookie sent
INFO - 2018-04-03 22:18:01 --> Input Class Initialized
INFO - 2018-04-03 22:18:01 --> Language Class Initialized
ERROR - 2018-04-03 22:18:01 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:18:01 --> Config Class Initialized
INFO - 2018-04-03 22:18:01 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:18:01 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:18:01 --> Utf8 Class Initialized
INFO - 2018-04-03 22:18:01 --> URI Class Initialized
INFO - 2018-04-03 22:18:01 --> Router Class Initialized
INFO - 2018-04-03 22:18:01 --> Output Class Initialized
INFO - 2018-04-03 22:18:01 --> Security Class Initialized
DEBUG - 2018-04-03 22:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:18:01 --> CSRF cookie sent
INFO - 2018-04-03 22:18:01 --> Input Class Initialized
INFO - 2018-04-03 22:18:01 --> Language Class Initialized
ERROR - 2018-04-03 22:18:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:19:24 --> Config Class Initialized
INFO - 2018-04-03 22:19:24 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:24 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:24 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:24 --> URI Class Initialized
INFO - 2018-04-03 22:19:24 --> Router Class Initialized
INFO - 2018-04-03 22:19:24 --> Output Class Initialized
INFO - 2018-04-03 22:19:24 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:24 --> CSRF cookie sent
INFO - 2018-04-03 22:19:24 --> Input Class Initialized
INFO - 2018-04-03 22:19:24 --> Language Class Initialized
INFO - 2018-04-03 22:19:24 --> Loader Class Initialized
INFO - 2018-04-03 22:19:24 --> Helper loaded: url_helper
INFO - 2018-04-03 22:19:24 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:19:24 --> User Agent Class Initialized
INFO - 2018-04-03 22:19:24 --> Controller Class Initialized
INFO - 2018-04-03 22:19:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:19:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:19:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:19:24 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:19:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:19:24 --> Final output sent to browser
DEBUG - 2018-04-03 22:19:24 --> Total execution time: 0.2327
INFO - 2018-04-03 22:19:24 --> Config Class Initialized
INFO - 2018-04-03 22:19:24 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:24 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:24 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:24 --> URI Class Initialized
INFO - 2018-04-03 22:19:24 --> Router Class Initialized
INFO - 2018-04-03 22:19:24 --> Output Class Initialized
INFO - 2018-04-03 22:19:24 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:24 --> CSRF cookie sent
INFO - 2018-04-03 22:19:24 --> Input Class Initialized
INFO - 2018-04-03 22:19:24 --> Language Class Initialized
ERROR - 2018-04-03 22:19:24 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:19:24 --> Config Class Initialized
INFO - 2018-04-03 22:19:24 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:24 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:24 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:24 --> URI Class Initialized
INFO - 2018-04-03 22:19:24 --> Router Class Initialized
INFO - 2018-04-03 22:19:24 --> Output Class Initialized
INFO - 2018-04-03 22:19:24 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:24 --> CSRF cookie sent
INFO - 2018-04-03 22:19:24 --> Input Class Initialized
INFO - 2018-04-03 22:19:24 --> Language Class Initialized
ERROR - 2018-04-03 22:19:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:19:46 --> Config Class Initialized
INFO - 2018-04-03 22:19:46 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:46 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:46 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:46 --> URI Class Initialized
INFO - 2018-04-03 22:19:46 --> Router Class Initialized
INFO - 2018-04-03 22:19:46 --> Output Class Initialized
INFO - 2018-04-03 22:19:46 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:46 --> CSRF cookie sent
INFO - 2018-04-03 22:19:46 --> Input Class Initialized
INFO - 2018-04-03 22:19:46 --> Language Class Initialized
INFO - 2018-04-03 22:19:46 --> Loader Class Initialized
INFO - 2018-04-03 22:19:46 --> Helper loaded: url_helper
INFO - 2018-04-03 22:19:46 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:19:46 --> User Agent Class Initialized
INFO - 2018-04-03 22:19:46 --> Controller Class Initialized
INFO - 2018-04-03 22:19:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:19:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:19:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:19:46 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-03 22:19:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:19:46 --> Final output sent to browser
DEBUG - 2018-04-03 22:19:46 --> Total execution time: 0.2329
INFO - 2018-04-03 22:19:46 --> Config Class Initialized
INFO - 2018-04-03 22:19:46 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:46 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:46 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:46 --> URI Class Initialized
INFO - 2018-04-03 22:19:46 --> Router Class Initialized
INFO - 2018-04-03 22:19:46 --> Output Class Initialized
INFO - 2018-04-03 22:19:46 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:46 --> CSRF cookie sent
INFO - 2018-04-03 22:19:46 --> Input Class Initialized
INFO - 2018-04-03 22:19:46 --> Language Class Initialized
ERROR - 2018-04-03 22:19:46 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:19:46 --> Config Class Initialized
INFO - 2018-04-03 22:19:46 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:19:46 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:19:46 --> Utf8 Class Initialized
INFO - 2018-04-03 22:19:46 --> URI Class Initialized
INFO - 2018-04-03 22:19:46 --> Router Class Initialized
INFO - 2018-04-03 22:19:46 --> Output Class Initialized
INFO - 2018-04-03 22:19:46 --> Security Class Initialized
DEBUG - 2018-04-03 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:19:46 --> CSRF cookie sent
INFO - 2018-04-03 22:19:46 --> Input Class Initialized
INFO - 2018-04-03 22:19:46 --> Language Class Initialized
ERROR - 2018-04-03 22:19:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:27:26 --> Config Class Initialized
INFO - 2018-04-03 22:27:26 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:27:26 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:27:26 --> Utf8 Class Initialized
INFO - 2018-04-03 22:27:26 --> URI Class Initialized
INFO - 2018-04-03 22:27:26 --> Router Class Initialized
INFO - 2018-04-03 22:27:26 --> Output Class Initialized
INFO - 2018-04-03 22:27:26 --> Security Class Initialized
DEBUG - 2018-04-03 22:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:27:26 --> CSRF cookie sent
INFO - 2018-04-03 22:27:26 --> Input Class Initialized
INFO - 2018-04-03 22:27:26 --> Language Class Initialized
INFO - 2018-04-03 22:27:26 --> Loader Class Initialized
INFO - 2018-04-03 22:27:26 --> Helper loaded: url_helper
INFO - 2018-04-03 22:27:26 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:27:26 --> User Agent Class Initialized
INFO - 2018-04-03 22:27:26 --> Controller Class Initialized
INFO - 2018-04-03 22:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:27:49 --> Config Class Initialized
INFO - 2018-04-03 22:27:49 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:27:49 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:27:50 --> Utf8 Class Initialized
INFO - 2018-04-03 22:27:50 --> URI Class Initialized
INFO - 2018-04-03 22:27:50 --> Router Class Initialized
INFO - 2018-04-03 22:27:50 --> Output Class Initialized
INFO - 2018-04-03 22:27:50 --> Security Class Initialized
DEBUG - 2018-04-03 22:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:27:50 --> CSRF cookie sent
INFO - 2018-04-03 22:27:50 --> Input Class Initialized
INFO - 2018-04-03 22:27:50 --> Language Class Initialized
INFO - 2018-04-03 22:27:50 --> Loader Class Initialized
INFO - 2018-04-03 22:27:50 --> Helper loaded: url_helper
INFO - 2018-04-03 22:27:50 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:27:50 --> User Agent Class Initialized
INFO - 2018-04-03 22:27:50 --> Controller Class Initialized
INFO - 2018-04-03 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:27:50 --> File loaded: E:\www\yacopoo\application\views\legal_questions.php
INFO - 2018-04-03 22:27:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:27:50 --> Final output sent to browser
DEBUG - 2018-04-03 22:27:50 --> Total execution time: 0.2296
INFO - 2018-04-03 22:27:50 --> Config Class Initialized
INFO - 2018-04-03 22:27:50 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:27:50 --> Utf8 Class Initialized
INFO - 2018-04-03 22:27:50 --> URI Class Initialized
INFO - 2018-04-03 22:27:50 --> Router Class Initialized
INFO - 2018-04-03 22:27:50 --> Output Class Initialized
INFO - 2018-04-03 22:27:50 --> Security Class Initialized
DEBUG - 2018-04-03 22:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:27:50 --> CSRF cookie sent
INFO - 2018-04-03 22:27:50 --> Input Class Initialized
INFO - 2018-04-03 22:27:50 --> Language Class Initialized
INFO - 2018-04-03 22:27:50 --> Config Class Initialized
INFO - 2018-04-03 22:27:50 --> Hooks Class Initialized
ERROR - 2018-04-03 22:27:50 --> 404 Page Not Found: Assets/images
DEBUG - 2018-04-03 22:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:27:50 --> Utf8 Class Initialized
INFO - 2018-04-03 22:27:50 --> URI Class Initialized
INFO - 2018-04-03 22:27:50 --> Router Class Initialized
INFO - 2018-04-03 22:27:50 --> Output Class Initialized
INFO - 2018-04-03 22:27:50 --> Security Class Initialized
DEBUG - 2018-04-03 22:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:27:50 --> CSRF cookie sent
INFO - 2018-04-03 22:27:50 --> Input Class Initialized
INFO - 2018-04-03 22:27:50 --> Language Class Initialized
ERROR - 2018-04-03 22:27:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:28:41 --> Config Class Initialized
INFO - 2018-04-03 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:28:41 --> Utf8 Class Initialized
INFO - 2018-04-03 22:28:41 --> URI Class Initialized
INFO - 2018-04-03 22:28:41 --> Router Class Initialized
INFO - 2018-04-03 22:28:41 --> Output Class Initialized
INFO - 2018-04-03 22:28:41 --> Security Class Initialized
DEBUG - 2018-04-03 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:28:41 --> CSRF cookie sent
INFO - 2018-04-03 22:28:41 --> Input Class Initialized
INFO - 2018-04-03 22:28:41 --> Language Class Initialized
INFO - 2018-04-03 22:28:41 --> Loader Class Initialized
INFO - 2018-04-03 22:28:41 --> Helper loaded: url_helper
INFO - 2018-04-03 22:28:41 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:28:41 --> User Agent Class Initialized
INFO - 2018-04-03 22:28:41 --> Controller Class Initialized
INFO - 2018-04-03 22:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:28:41 --> File loaded: E:\www\yacopoo\application\views\legal_questions.php
INFO - 2018-04-03 22:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:28:41 --> Final output sent to browser
DEBUG - 2018-04-03 22:28:41 --> Total execution time: 0.2284
INFO - 2018-04-03 22:28:41 --> Config Class Initialized
INFO - 2018-04-03 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:28:41 --> Utf8 Class Initialized
INFO - 2018-04-03 22:28:41 --> URI Class Initialized
INFO - 2018-04-03 22:28:41 --> Router Class Initialized
INFO - 2018-04-03 22:28:41 --> Output Class Initialized
INFO - 2018-04-03 22:28:41 --> Security Class Initialized
DEBUG - 2018-04-03 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:28:41 --> CSRF cookie sent
INFO - 2018-04-03 22:28:41 --> Input Class Initialized
INFO - 2018-04-03 22:28:41 --> Language Class Initialized
ERROR - 2018-04-03 22:28:41 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:28:41 --> Config Class Initialized
INFO - 2018-04-03 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:28:42 --> Utf8 Class Initialized
INFO - 2018-04-03 22:28:42 --> URI Class Initialized
INFO - 2018-04-03 22:28:42 --> Router Class Initialized
INFO - 2018-04-03 22:28:42 --> Output Class Initialized
INFO - 2018-04-03 22:28:42 --> Security Class Initialized
DEBUG - 2018-04-03 22:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:28:42 --> CSRF cookie sent
INFO - 2018-04-03 22:28:42 --> Input Class Initialized
INFO - 2018-04-03 22:28:42 --> Language Class Initialized
ERROR - 2018-04-03 22:28:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:29:34 --> Config Class Initialized
INFO - 2018-04-03 22:29:34 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:29:34 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:29:34 --> Utf8 Class Initialized
INFO - 2018-04-03 22:29:34 --> URI Class Initialized
INFO - 2018-04-03 22:29:34 --> Router Class Initialized
INFO - 2018-04-03 22:29:34 --> Output Class Initialized
INFO - 2018-04-03 22:29:34 --> Security Class Initialized
DEBUG - 2018-04-03 22:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:29:34 --> CSRF cookie sent
INFO - 2018-04-03 22:29:34 --> Input Class Initialized
INFO - 2018-04-03 22:29:35 --> Language Class Initialized
INFO - 2018-04-03 22:29:35 --> Loader Class Initialized
INFO - 2018-04-03 22:29:35 --> Helper loaded: url_helper
INFO - 2018-04-03 22:29:35 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:29:35 --> User Agent Class Initialized
INFO - 2018-04-03 22:29:35 --> Controller Class Initialized
INFO - 2018-04-03 22:29:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:29:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:29:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:29:35 --> File loaded: E:\www\yacopoo\application\views\legal_questions.php
INFO - 2018-04-03 22:29:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:29:35 --> Final output sent to browser
DEBUG - 2018-04-03 22:29:35 --> Total execution time: 0.2456
INFO - 2018-04-03 22:29:35 --> Config Class Initialized
INFO - 2018-04-03 22:29:35 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:29:35 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:29:35 --> Utf8 Class Initialized
INFO - 2018-04-03 22:29:35 --> URI Class Initialized
INFO - 2018-04-03 22:29:35 --> Router Class Initialized
INFO - 2018-04-03 22:29:35 --> Output Class Initialized
INFO - 2018-04-03 22:29:35 --> Security Class Initialized
DEBUG - 2018-04-03 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:29:35 --> CSRF cookie sent
INFO - 2018-04-03 22:29:35 --> Input Class Initialized
INFO - 2018-04-03 22:29:35 --> Language Class Initialized
ERROR - 2018-04-03 22:29:35 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:29:35 --> Config Class Initialized
INFO - 2018-04-03 22:29:35 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:29:35 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:29:35 --> Utf8 Class Initialized
INFO - 2018-04-03 22:29:35 --> URI Class Initialized
INFO - 2018-04-03 22:29:35 --> Router Class Initialized
INFO - 2018-04-03 22:29:35 --> Output Class Initialized
INFO - 2018-04-03 22:29:35 --> Security Class Initialized
DEBUG - 2018-04-03 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:29:35 --> CSRF cookie sent
INFO - 2018-04-03 22:29:35 --> Input Class Initialized
INFO - 2018-04-03 22:29:35 --> Language Class Initialized
ERROR - 2018-04-03 22:29:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:33:47 --> Config Class Initialized
INFO - 2018-04-03 22:33:47 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:33:47 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:33:47 --> Utf8 Class Initialized
INFO - 2018-04-03 22:33:47 --> URI Class Initialized
INFO - 2018-04-03 22:33:47 --> Router Class Initialized
INFO - 2018-04-03 22:33:47 --> Output Class Initialized
INFO - 2018-04-03 22:33:47 --> Security Class Initialized
DEBUG - 2018-04-03 22:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:33:47 --> CSRF cookie sent
INFO - 2018-04-03 22:33:47 --> Input Class Initialized
INFO - 2018-04-03 22:33:48 --> Language Class Initialized
INFO - 2018-04-03 22:33:48 --> Loader Class Initialized
INFO - 2018-04-03 22:33:48 --> Helper loaded: url_helper
INFO - 2018-04-03 22:33:48 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:33:48 --> User Agent Class Initialized
INFO - 2018-04-03 22:33:48 --> Controller Class Initialized
INFO - 2018-04-03 22:33:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:33:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:33:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:33:48 --> File loaded: E:\www\yacopoo\application\views\legal_questions.php
INFO - 2018-04-03 22:33:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:33:48 --> Final output sent to browser
DEBUG - 2018-04-03 22:33:48 --> Total execution time: 0.2406
INFO - 2018-04-03 22:33:48 --> Config Class Initialized
INFO - 2018-04-03 22:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:33:48 --> Utf8 Class Initialized
INFO - 2018-04-03 22:33:48 --> URI Class Initialized
INFO - 2018-04-03 22:33:48 --> Router Class Initialized
INFO - 2018-04-03 22:33:48 --> Output Class Initialized
INFO - 2018-04-03 22:33:48 --> Security Class Initialized
DEBUG - 2018-04-03 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:33:48 --> CSRF cookie sent
INFO - 2018-04-03 22:33:48 --> Config Class Initialized
INFO - 2018-04-03 22:33:48 --> Input Class Initialized
INFO - 2018-04-03 22:33:48 --> Hooks Class Initialized
INFO - 2018-04-03 22:33:48 --> Language Class Initialized
DEBUG - 2018-04-03 22:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:33:48 --> Utf8 Class Initialized
ERROR - 2018-04-03 22:33:48 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:33:48 --> URI Class Initialized
INFO - 2018-04-03 22:33:48 --> Router Class Initialized
INFO - 2018-04-03 22:33:48 --> Output Class Initialized
INFO - 2018-04-03 22:33:48 --> Security Class Initialized
DEBUG - 2018-04-03 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:33:48 --> CSRF cookie sent
INFO - 2018-04-03 22:33:48 --> Input Class Initialized
INFO - 2018-04-03 22:33:48 --> Language Class Initialized
ERROR - 2018-04-03 22:33:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-03 22:35:06 --> Config Class Initialized
INFO - 2018-04-03 22:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:35:06 --> Utf8 Class Initialized
INFO - 2018-04-03 22:35:06 --> URI Class Initialized
INFO - 2018-04-03 22:35:06 --> Router Class Initialized
INFO - 2018-04-03 22:35:06 --> Output Class Initialized
INFO - 2018-04-03 22:35:06 --> Security Class Initialized
DEBUG - 2018-04-03 22:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:35:06 --> CSRF cookie sent
INFO - 2018-04-03 22:35:06 --> Input Class Initialized
INFO - 2018-04-03 22:35:06 --> Language Class Initialized
INFO - 2018-04-03 22:35:06 --> Loader Class Initialized
INFO - 2018-04-03 22:35:06 --> Helper loaded: url_helper
INFO - 2018-04-03 22:35:06 --> Helper loaded: form_helper
DEBUG - 2018-04-03 22:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:35:06 --> User Agent Class Initialized
INFO - 2018-04-03 22:35:06 --> Controller Class Initialized
INFO - 2018-04-03 22:35:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-03 22:35:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-03 22:35:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-03 22:35:06 --> File loaded: E:\www\yacopoo\application\views\legal_questions.php
INFO - 2018-04-03 22:35:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-03 22:35:06 --> Final output sent to browser
DEBUG - 2018-04-03 22:35:06 --> Total execution time: 0.2387
INFO - 2018-04-03 22:35:06 --> Config Class Initialized
INFO - 2018-04-03 22:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:35:06 --> Utf8 Class Initialized
INFO - 2018-04-03 22:35:06 --> URI Class Initialized
INFO - 2018-04-03 22:35:06 --> Router Class Initialized
INFO - 2018-04-03 22:35:06 --> Output Class Initialized
INFO - 2018-04-03 22:35:06 --> Security Class Initialized
DEBUG - 2018-04-03 22:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:35:06 --> CSRF cookie sent
INFO - 2018-04-03 22:35:06 --> Input Class Initialized
INFO - 2018-04-03 22:35:06 --> Language Class Initialized
ERROR - 2018-04-03 22:35:06 --> 404 Page Not Found: Assets/images
INFO - 2018-04-03 22:35:07 --> Config Class Initialized
INFO - 2018-04-03 22:35:07 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:35:07 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:35:07 --> Utf8 Class Initialized
INFO - 2018-04-03 22:35:07 --> URI Class Initialized
INFO - 2018-04-03 22:35:07 --> Router Class Initialized
INFO - 2018-04-03 22:35:07 --> Output Class Initialized
INFO - 2018-04-03 22:35:07 --> Security Class Initialized
DEBUG - 2018-04-03 22:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:35:07 --> CSRF cookie sent
INFO - 2018-04-03 22:35:07 --> Input Class Initialized
INFO - 2018-04-03 22:35:07 --> Language Class Initialized
ERROR - 2018-04-03 22:35:07 --> 404 Page Not Found: Assets/css

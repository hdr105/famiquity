<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-04 00:59:58 --> Config Class Initialized
INFO - 2018-04-04 00:59:58 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:59:58 --> Utf8 Class Initialized
INFO - 2018-04-04 00:59:58 --> URI Class Initialized
INFO - 2018-04-04 00:59:58 --> Router Class Initialized
INFO - 2018-04-04 00:59:58 --> Output Class Initialized
INFO - 2018-04-04 00:59:58 --> Security Class Initialized
DEBUG - 2018-04-04 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:59:58 --> CSRF cookie sent
INFO - 2018-04-04 00:59:58 --> Input Class Initialized
INFO - 2018-04-04 00:59:58 --> Language Class Initialized
INFO - 2018-04-04 00:59:58 --> Loader Class Initialized
INFO - 2018-04-04 00:59:58 --> Helper loaded: url_helper
INFO - 2018-04-04 00:59:58 --> Helper loaded: form_helper
DEBUG - 2018-04-04 00:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:59:58 --> User Agent Class Initialized
INFO - 2018-04-04 00:59:58 --> Controller Class Initialized
INFO - 2018-04-04 00:59:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 00:59:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 00:59:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 00:59:58 --> File loaded: E:\www\yacopoo\application\views\personal_info.php
INFO - 2018-04-04 00:59:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 00:59:58 --> Final output sent to browser
DEBUG - 2018-04-04 00:59:58 --> Total execution time: 0.3387
INFO - 2018-04-04 00:59:58 --> Config Class Initialized
INFO - 2018-04-04 00:59:58 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:59:58 --> Utf8 Class Initialized
INFO - 2018-04-04 00:59:58 --> URI Class Initialized
INFO - 2018-04-04 00:59:58 --> Router Class Initialized
INFO - 2018-04-04 00:59:58 --> Output Class Initialized
INFO - 2018-04-04 00:59:58 --> Security Class Initialized
DEBUG - 2018-04-04 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:59:58 --> CSRF cookie sent
INFO - 2018-04-04 00:59:58 --> Input Class Initialized
INFO - 2018-04-04 00:59:58 --> Language Class Initialized
ERROR - 2018-04-04 00:59:58 --> 404 Page Not Found: Assets/images
INFO - 2018-04-04 00:59:58 --> Config Class Initialized
INFO - 2018-04-04 00:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:59:59 --> Utf8 Class Initialized
INFO - 2018-04-04 00:59:59 --> URI Class Initialized
INFO - 2018-04-04 00:59:59 --> Router Class Initialized
INFO - 2018-04-04 00:59:59 --> Output Class Initialized
INFO - 2018-04-04 00:59:59 --> Security Class Initialized
DEBUG - 2018-04-04 00:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:59:59 --> CSRF cookie sent
INFO - 2018-04-04 00:59:59 --> Input Class Initialized
INFO - 2018-04-04 00:59:59 --> Language Class Initialized
ERROR - 2018-04-04 00:59:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 01:00:46 --> Config Class Initialized
INFO - 2018-04-04 01:00:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:00:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:00:46 --> Utf8 Class Initialized
INFO - 2018-04-04 01:00:46 --> URI Class Initialized
INFO - 2018-04-04 01:00:46 --> Router Class Initialized
INFO - 2018-04-04 01:00:46 --> Output Class Initialized
INFO - 2018-04-04 01:00:46 --> Security Class Initialized
DEBUG - 2018-04-04 01:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:00:46 --> CSRF cookie sent
INFO - 2018-04-04 01:00:46 --> Input Class Initialized
INFO - 2018-04-04 01:00:46 --> Language Class Initialized
INFO - 2018-04-04 01:00:46 --> Loader Class Initialized
INFO - 2018-04-04 01:00:46 --> Helper loaded: url_helper
INFO - 2018-04-04 01:00:46 --> Helper loaded: form_helper
DEBUG - 2018-04-04 01:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 01:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 01:00:46 --> User Agent Class Initialized
INFO - 2018-04-04 01:00:46 --> Controller Class Initialized
INFO - 2018-04-04 01:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 01:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 01:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 01:00:46 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-04 01:00:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 01:00:46 --> Final output sent to browser
DEBUG - 2018-04-04 01:00:46 --> Total execution time: 0.2014
INFO - 2018-04-04 01:00:47 --> Config Class Initialized
INFO - 2018-04-04 01:00:47 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:00:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:00:47 --> Utf8 Class Initialized
INFO - 2018-04-04 01:00:47 --> URI Class Initialized
INFO - 2018-04-04 01:00:47 --> Router Class Initialized
INFO - 2018-04-04 01:00:47 --> Output Class Initialized
INFO - 2018-04-04 01:00:47 --> Security Class Initialized
DEBUG - 2018-04-04 01:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:00:47 --> CSRF cookie sent
INFO - 2018-04-04 01:00:47 --> Input Class Initialized
INFO - 2018-04-04 01:00:47 --> Language Class Initialized
ERROR - 2018-04-04 01:00:47 --> 404 Page Not Found: Assets/images
INFO - 2018-04-04 01:00:47 --> Config Class Initialized
INFO - 2018-04-04 01:00:47 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:00:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:00:47 --> Utf8 Class Initialized
INFO - 2018-04-04 01:00:47 --> URI Class Initialized
INFO - 2018-04-04 01:00:47 --> Router Class Initialized
INFO - 2018-04-04 01:00:47 --> Output Class Initialized
INFO - 2018-04-04 01:00:47 --> Security Class Initialized
DEBUG - 2018-04-04 01:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:00:47 --> CSRF cookie sent
INFO - 2018-04-04 01:00:47 --> Input Class Initialized
INFO - 2018-04-04 01:00:47 --> Language Class Initialized
ERROR - 2018-04-04 01:00:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 01:01:45 --> Config Class Initialized
INFO - 2018-04-04 01:01:45 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:01:45 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:01:45 --> Utf8 Class Initialized
INFO - 2018-04-04 01:01:45 --> URI Class Initialized
INFO - 2018-04-04 01:01:45 --> Router Class Initialized
INFO - 2018-04-04 01:01:45 --> Output Class Initialized
INFO - 2018-04-04 01:01:45 --> Security Class Initialized
DEBUG - 2018-04-04 01:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:01:45 --> CSRF cookie sent
INFO - 2018-04-04 01:01:45 --> Input Class Initialized
INFO - 2018-04-04 01:01:45 --> Language Class Initialized
INFO - 2018-04-04 01:01:45 --> Loader Class Initialized
INFO - 2018-04-04 01:01:45 --> Helper loaded: url_helper
INFO - 2018-04-04 01:01:45 --> Helper loaded: form_helper
DEBUG - 2018-04-04 01:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 01:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 01:01:45 --> User Agent Class Initialized
INFO - 2018-04-04 01:01:45 --> Controller Class Initialized
INFO - 2018-04-04 01:01:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 01:01:45 --> File loaded: E:\www\yacopoo\application\views\credit.php
INFO - 2018-04-04 01:01:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 01:01:45 --> Final output sent to browser
DEBUG - 2018-04-04 01:01:45 --> Total execution time: 0.1803
INFO - 2018-04-04 01:01:45 --> Config Class Initialized
INFO - 2018-04-04 01:01:45 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:01:45 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:01:45 --> Utf8 Class Initialized
INFO - 2018-04-04 01:01:45 --> URI Class Initialized
INFO - 2018-04-04 01:01:45 --> Router Class Initialized
INFO - 2018-04-04 01:01:45 --> Output Class Initialized
INFO - 2018-04-04 01:01:45 --> Security Class Initialized
DEBUG - 2018-04-04 01:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:01:45 --> CSRF cookie sent
INFO - 2018-04-04 01:01:45 --> Input Class Initialized
INFO - 2018-04-04 01:01:45 --> Language Class Initialized
ERROR - 2018-04-04 01:01:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 01:01:46 --> Config Class Initialized
INFO - 2018-04-04 01:01:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 01:01:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 01:01:46 --> Utf8 Class Initialized
INFO - 2018-04-04 01:01:46 --> URI Class Initialized
INFO - 2018-04-04 01:01:46 --> Router Class Initialized
INFO - 2018-04-04 01:01:46 --> Output Class Initialized
INFO - 2018-04-04 01:01:46 --> Security Class Initialized
DEBUG - 2018-04-04 01:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 01:01:46 --> CSRF cookie sent
INFO - 2018-04-04 01:01:46 --> Input Class Initialized
INFO - 2018-04-04 01:01:46 --> Language Class Initialized
ERROR - 2018-04-04 01:01:46 --> 404 Page Not Found: Assets/images
INFO - 2018-04-04 22:18:56 --> Config Class Initialized
INFO - 2018-04-04 22:18:56 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:18:56 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:18:56 --> Utf8 Class Initialized
INFO - 2018-04-04 22:18:56 --> URI Class Initialized
INFO - 2018-04-04 22:18:56 --> Router Class Initialized
INFO - 2018-04-04 22:18:56 --> Output Class Initialized
INFO - 2018-04-04 22:18:56 --> Security Class Initialized
DEBUG - 2018-04-04 22:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:18:56 --> CSRF cookie sent
INFO - 2018-04-04 22:18:56 --> Input Class Initialized
INFO - 2018-04-04 22:18:56 --> Language Class Initialized
INFO - 2018-04-04 22:18:56 --> Loader Class Initialized
INFO - 2018-04-04 22:18:56 --> Helper loaded: url_helper
INFO - 2018-04-04 22:18:56 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:18:56 --> User Agent Class Initialized
INFO - 2018-04-04 22:18:56 --> Controller Class Initialized
INFO - 2018-04-04 22:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:18:56 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-04 22:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:18:56 --> Final output sent to browser
DEBUG - 2018-04-04 22:18:56 --> Total execution time: 0.8310
INFO - 2018-04-04 22:18:57 --> Config Class Initialized
INFO - 2018-04-04 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:18:58 --> Utf8 Class Initialized
INFO - 2018-04-04 22:18:58 --> Config Class Initialized
INFO - 2018-04-04 22:18:58 --> Hooks Class Initialized
INFO - 2018-04-04 22:18:58 --> URI Class Initialized
INFO - 2018-04-04 22:18:58 --> Router Class Initialized
DEBUG - 2018-04-04 22:18:58 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:18:58 --> Utf8 Class Initialized
INFO - 2018-04-04 22:18:58 --> Output Class Initialized
INFO - 2018-04-04 22:18:58 --> URI Class Initialized
INFO - 2018-04-04 22:18:58 --> Security Class Initialized
DEBUG - 2018-04-04 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:18:58 --> Router Class Initialized
INFO - 2018-04-04 22:18:58 --> CSRF cookie sent
INFO - 2018-04-04 22:18:58 --> Output Class Initialized
INFO - 2018-04-04 22:18:58 --> Input Class Initialized
INFO - 2018-04-04 22:18:58 --> Security Class Initialized
INFO - 2018-04-04 22:18:58 --> Language Class Initialized
DEBUG - 2018-04-04 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:18:58 --> CSRF cookie sent
INFO - 2018-04-04 22:18:58 --> Input Class Initialized
ERROR - 2018-04-04 22:18:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:18:58 --> Language Class Initialized
ERROR - 2018-04-04 22:18:58 --> 404 Page Not Found: Assets/images
INFO - 2018-04-04 22:18:58 --> Config Class Initialized
INFO - 2018-04-04 22:18:58 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:18:58 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:18:58 --> Utf8 Class Initialized
INFO - 2018-04-04 22:18:58 --> URI Class Initialized
INFO - 2018-04-04 22:18:58 --> Router Class Initialized
INFO - 2018-04-04 22:18:58 --> Output Class Initialized
INFO - 2018-04-04 22:18:58 --> Security Class Initialized
DEBUG - 2018-04-04 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:18:58 --> CSRF cookie sent
INFO - 2018-04-04 22:18:58 --> Input Class Initialized
INFO - 2018-04-04 22:18:58 --> Language Class Initialized
ERROR - 2018-04-04 22:18:58 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:21:19 --> Config Class Initialized
INFO - 2018-04-04 22:21:19 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:21:19 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:21:19 --> Utf8 Class Initialized
INFO - 2018-04-04 22:21:19 --> URI Class Initialized
INFO - 2018-04-04 22:21:19 --> Router Class Initialized
INFO - 2018-04-04 22:21:20 --> Output Class Initialized
INFO - 2018-04-04 22:21:20 --> Security Class Initialized
DEBUG - 2018-04-04 22:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:21:20 --> CSRF cookie sent
INFO - 2018-04-04 22:21:20 --> Input Class Initialized
INFO - 2018-04-04 22:21:20 --> Language Class Initialized
INFO - 2018-04-04 22:21:20 --> Loader Class Initialized
INFO - 2018-04-04 22:21:20 --> Helper loaded: url_helper
INFO - 2018-04-04 22:21:20 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:21:20 --> User Agent Class Initialized
INFO - 2018-04-04 22:21:20 --> Controller Class Initialized
INFO - 2018-04-04 22:21:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:21:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:21:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:21:20 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-04 22:21:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:21:20 --> Final output sent to browser
DEBUG - 2018-04-04 22:21:20 --> Total execution time: 0.2638
INFO - 2018-04-04 22:21:20 --> Config Class Initialized
INFO - 2018-04-04 22:21:20 --> Config Class Initialized
INFO - 2018-04-04 22:21:20 --> Hooks Class Initialized
INFO - 2018-04-04 22:21:20 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:21:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 22:21:20 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:21:20 --> Utf8 Class Initialized
INFO - 2018-04-04 22:21:20 --> Utf8 Class Initialized
INFO - 2018-04-04 22:21:20 --> URI Class Initialized
INFO - 2018-04-04 22:21:20 --> URI Class Initialized
INFO - 2018-04-04 22:21:20 --> Router Class Initialized
INFO - 2018-04-04 22:21:20 --> Router Class Initialized
INFO - 2018-04-04 22:21:20 --> Output Class Initialized
INFO - 2018-04-04 22:21:20 --> Output Class Initialized
INFO - 2018-04-04 22:21:20 --> Security Class Initialized
INFO - 2018-04-04 22:21:20 --> Security Class Initialized
DEBUG - 2018-04-04 22:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 22:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:21:20 --> CSRF cookie sent
INFO - 2018-04-04 22:21:20 --> CSRF cookie sent
INFO - 2018-04-04 22:21:20 --> Input Class Initialized
INFO - 2018-04-04 22:21:20 --> Input Class Initialized
INFO - 2018-04-04 22:21:20 --> Language Class Initialized
INFO - 2018-04-04 22:21:21 --> Language Class Initialized
INFO - 2018-04-04 22:21:21 --> Config Class Initialized
INFO - 2018-04-04 22:21:21 --> Hooks Class Initialized
ERROR - 2018-04-04 22:21:21 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-04 22:21:21 --> 404 Page Not Found: Assets/app
DEBUG - 2018-04-04 22:21:21 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:21:21 --> Utf8 Class Initialized
INFO - 2018-04-04 22:21:21 --> URI Class Initialized
INFO - 2018-04-04 22:21:21 --> Router Class Initialized
INFO - 2018-04-04 22:21:21 --> Output Class Initialized
INFO - 2018-04-04 22:21:21 --> Security Class Initialized
DEBUG - 2018-04-04 22:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:21:21 --> CSRF cookie sent
INFO - 2018-04-04 22:21:21 --> Input Class Initialized
INFO - 2018-04-04 22:21:21 --> Language Class Initialized
ERROR - 2018-04-04 22:21:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:21:21 --> Config Class Initialized
INFO - 2018-04-04 22:21:21 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:21:21 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:21:21 --> Utf8 Class Initialized
INFO - 2018-04-04 22:21:21 --> URI Class Initialized
INFO - 2018-04-04 22:21:21 --> Router Class Initialized
INFO - 2018-04-04 22:21:21 --> Output Class Initialized
INFO - 2018-04-04 22:21:21 --> Security Class Initialized
DEBUG - 2018-04-04 22:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:21:21 --> CSRF cookie sent
INFO - 2018-04-04 22:21:21 --> Input Class Initialized
INFO - 2018-04-04 22:21:21 --> Language Class Initialized
ERROR - 2018-04-04 22:21:21 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:22:22 --> Config Class Initialized
INFO - 2018-04-04 22:22:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:22:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:22:22 --> Utf8 Class Initialized
INFO - 2018-04-04 22:22:22 --> URI Class Initialized
INFO - 2018-04-04 22:22:22 --> Router Class Initialized
INFO - 2018-04-04 22:22:22 --> Output Class Initialized
INFO - 2018-04-04 22:22:22 --> Security Class Initialized
DEBUG - 2018-04-04 22:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:22:22 --> CSRF cookie sent
INFO - 2018-04-04 22:22:22 --> Input Class Initialized
INFO - 2018-04-04 22:22:22 --> Language Class Initialized
INFO - 2018-04-04 22:22:22 --> Loader Class Initialized
INFO - 2018-04-04 22:22:22 --> Helper loaded: url_helper
INFO - 2018-04-04 22:22:22 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:22:22 --> User Agent Class Initialized
INFO - 2018-04-04 22:22:22 --> Controller Class Initialized
INFO - 2018-04-04 22:22:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:22:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:22:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:22:22 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-04 22:22:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:22:22 --> Final output sent to browser
DEBUG - 2018-04-04 22:22:22 --> Total execution time: 0.2792
INFO - 2018-04-04 22:22:23 --> Config Class Initialized
INFO - 2018-04-04 22:22:23 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:22:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:22:23 --> Utf8 Class Initialized
INFO - 2018-04-04 22:22:23 --> URI Class Initialized
INFO - 2018-04-04 22:22:23 --> Router Class Initialized
INFO - 2018-04-04 22:22:23 --> Output Class Initialized
INFO - 2018-04-04 22:22:23 --> Security Class Initialized
DEBUG - 2018-04-04 22:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:22:23 --> CSRF cookie sent
INFO - 2018-04-04 22:22:23 --> Input Class Initialized
INFO - 2018-04-04 22:22:23 --> Language Class Initialized
ERROR - 2018-04-04 22:22:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:22:23 --> Config Class Initialized
INFO - 2018-04-04 22:22:23 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:22:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:22:23 --> Utf8 Class Initialized
INFO - 2018-04-04 22:22:23 --> URI Class Initialized
INFO - 2018-04-04 22:22:23 --> Router Class Initialized
INFO - 2018-04-04 22:22:23 --> Output Class Initialized
INFO - 2018-04-04 22:22:23 --> Security Class Initialized
DEBUG - 2018-04-04 22:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:22:23 --> CSRF cookie sent
INFO - 2018-04-04 22:22:23 --> Input Class Initialized
INFO - 2018-04-04 22:22:23 --> Language Class Initialized
ERROR - 2018-04-04 22:22:23 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:26:42 --> Config Class Initialized
INFO - 2018-04-04 22:26:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:26:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:26:43 --> Utf8 Class Initialized
INFO - 2018-04-04 22:26:43 --> URI Class Initialized
INFO - 2018-04-04 22:26:43 --> Router Class Initialized
INFO - 2018-04-04 22:26:43 --> Output Class Initialized
INFO - 2018-04-04 22:26:43 --> Security Class Initialized
DEBUG - 2018-04-04 22:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:26:43 --> CSRF cookie sent
INFO - 2018-04-04 22:26:43 --> Input Class Initialized
INFO - 2018-04-04 22:26:43 --> Language Class Initialized
INFO - 2018-04-04 22:26:43 --> Loader Class Initialized
INFO - 2018-04-04 22:26:43 --> Helper loaded: url_helper
INFO - 2018-04-04 22:26:43 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:26:43 --> User Agent Class Initialized
INFO - 2018-04-04 22:26:43 --> Controller Class Initialized
INFO - 2018-04-04 22:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:26:43 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:26:43 --> Final output sent to browser
DEBUG - 2018-04-04 22:26:43 --> Total execution time: 0.2720
INFO - 2018-04-04 22:26:43 --> Config Class Initialized
INFO - 2018-04-04 22:26:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:26:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:26:43 --> Utf8 Class Initialized
INFO - 2018-04-04 22:26:43 --> URI Class Initialized
INFO - 2018-04-04 22:26:43 --> Router Class Initialized
INFO - 2018-04-04 22:26:43 --> Output Class Initialized
INFO - 2018-04-04 22:26:43 --> Security Class Initialized
DEBUG - 2018-04-04 22:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:26:43 --> CSRF cookie sent
INFO - 2018-04-04 22:26:43 --> Input Class Initialized
INFO - 2018-04-04 22:26:43 --> Language Class Initialized
ERROR - 2018-04-04 22:26:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:26:44 --> Config Class Initialized
INFO - 2018-04-04 22:26:44 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:26:44 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:26:44 --> Utf8 Class Initialized
INFO - 2018-04-04 22:26:44 --> URI Class Initialized
INFO - 2018-04-04 22:26:44 --> Router Class Initialized
INFO - 2018-04-04 22:26:44 --> Output Class Initialized
INFO - 2018-04-04 22:26:44 --> Security Class Initialized
DEBUG - 2018-04-04 22:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:26:44 --> CSRF cookie sent
INFO - 2018-04-04 22:26:44 --> Input Class Initialized
INFO - 2018-04-04 22:26:44 --> Language Class Initialized
ERROR - 2018-04-04 22:26:44 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:27:31 --> Config Class Initialized
INFO - 2018-04-04 22:27:31 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:27:31 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:27:31 --> Utf8 Class Initialized
INFO - 2018-04-04 22:27:31 --> URI Class Initialized
INFO - 2018-04-04 22:27:31 --> Router Class Initialized
INFO - 2018-04-04 22:27:31 --> Output Class Initialized
INFO - 2018-04-04 22:27:31 --> Security Class Initialized
DEBUG - 2018-04-04 22:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:27:31 --> CSRF cookie sent
INFO - 2018-04-04 22:27:31 --> Input Class Initialized
INFO - 2018-04-04 22:27:31 --> Language Class Initialized
INFO - 2018-04-04 22:27:31 --> Loader Class Initialized
INFO - 2018-04-04 22:27:31 --> Helper loaded: url_helper
INFO - 2018-04-04 22:27:31 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:27:31 --> User Agent Class Initialized
INFO - 2018-04-04 22:27:31 --> Controller Class Initialized
INFO - 2018-04-04 22:27:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:27:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:27:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:27:31 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:27:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:27:31 --> Final output sent to browser
DEBUG - 2018-04-04 22:27:31 --> Total execution time: 0.2672
INFO - 2018-04-04 22:27:32 --> Config Class Initialized
INFO - 2018-04-04 22:27:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:27:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:27:32 --> Utf8 Class Initialized
INFO - 2018-04-04 22:27:32 --> URI Class Initialized
INFO - 2018-04-04 22:27:32 --> Router Class Initialized
INFO - 2018-04-04 22:27:32 --> Output Class Initialized
INFO - 2018-04-04 22:27:32 --> Security Class Initialized
DEBUG - 2018-04-04 22:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:27:32 --> CSRF cookie sent
INFO - 2018-04-04 22:27:32 --> Input Class Initialized
INFO - 2018-04-04 22:27:32 --> Language Class Initialized
INFO - 2018-04-04 22:27:32 --> Config Class Initialized
INFO - 2018-04-04 22:27:32 --> Hooks Class Initialized
ERROR - 2018-04-04 22:27:32 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:27:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:27:32 --> Utf8 Class Initialized
INFO - 2018-04-04 22:27:32 --> URI Class Initialized
INFO - 2018-04-04 22:27:32 --> Router Class Initialized
INFO - 2018-04-04 22:27:32 --> Output Class Initialized
INFO - 2018-04-04 22:27:32 --> Security Class Initialized
DEBUG - 2018-04-04 22:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:27:32 --> CSRF cookie sent
INFO - 2018-04-04 22:27:32 --> Input Class Initialized
INFO - 2018-04-04 22:27:32 --> Language Class Initialized
ERROR - 2018-04-04 22:27:32 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:28:19 --> Config Class Initialized
INFO - 2018-04-04 22:28:19 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:28:19 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:28:19 --> Utf8 Class Initialized
INFO - 2018-04-04 22:28:19 --> URI Class Initialized
INFO - 2018-04-04 22:28:19 --> Router Class Initialized
INFO - 2018-04-04 22:28:19 --> Output Class Initialized
INFO - 2018-04-04 22:28:19 --> Security Class Initialized
DEBUG - 2018-04-04 22:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:28:19 --> CSRF cookie sent
INFO - 2018-04-04 22:28:19 --> Input Class Initialized
INFO - 2018-04-04 22:28:19 --> Language Class Initialized
INFO - 2018-04-04 22:28:19 --> Loader Class Initialized
INFO - 2018-04-04 22:28:19 --> Helper loaded: url_helper
INFO - 2018-04-04 22:28:19 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:28:19 --> User Agent Class Initialized
INFO - 2018-04-04 22:28:19 --> Controller Class Initialized
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:28:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:28:19 --> Final output sent to browser
DEBUG - 2018-04-04 22:28:19 --> Total execution time: 0.2708
INFO - 2018-04-04 22:28:19 --> Config Class Initialized
INFO - 2018-04-04 22:28:19 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:28:19 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:28:19 --> Utf8 Class Initialized
INFO - 2018-04-04 22:28:19 --> URI Class Initialized
INFO - 2018-04-04 22:28:20 --> Router Class Initialized
INFO - 2018-04-04 22:28:20 --> Output Class Initialized
INFO - 2018-04-04 22:28:20 --> Security Class Initialized
DEBUG - 2018-04-04 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:28:20 --> CSRF cookie sent
INFO - 2018-04-04 22:28:20 --> Config Class Initialized
INFO - 2018-04-04 22:28:20 --> Hooks Class Initialized
INFO - 2018-04-04 22:28:20 --> Input Class Initialized
INFO - 2018-04-04 22:28:20 --> Language Class Initialized
DEBUG - 2018-04-04 22:28:20 --> UTF-8 Support Enabled
ERROR - 2018-04-04 22:28:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:28:20 --> Utf8 Class Initialized
INFO - 2018-04-04 22:28:20 --> URI Class Initialized
INFO - 2018-04-04 22:28:20 --> Router Class Initialized
INFO - 2018-04-04 22:28:20 --> Output Class Initialized
INFO - 2018-04-04 22:28:20 --> Security Class Initialized
DEBUG - 2018-04-04 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:28:20 --> CSRF cookie sent
INFO - 2018-04-04 22:28:20 --> Input Class Initialized
INFO - 2018-04-04 22:28:20 --> Language Class Initialized
ERROR - 2018-04-04 22:28:20 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:29:21 --> Config Class Initialized
INFO - 2018-04-04 22:29:21 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:29:21 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:29:21 --> Utf8 Class Initialized
INFO - 2018-04-04 22:29:21 --> URI Class Initialized
INFO - 2018-04-04 22:29:21 --> Router Class Initialized
INFO - 2018-04-04 22:29:21 --> Output Class Initialized
INFO - 2018-04-04 22:29:21 --> Security Class Initialized
DEBUG - 2018-04-04 22:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:29:21 --> CSRF cookie sent
INFO - 2018-04-04 22:29:21 --> Input Class Initialized
INFO - 2018-04-04 22:29:21 --> Language Class Initialized
INFO - 2018-04-04 22:29:21 --> Loader Class Initialized
INFO - 2018-04-04 22:29:21 --> Helper loaded: url_helper
INFO - 2018-04-04 22:29:21 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:29:21 --> User Agent Class Initialized
INFO - 2018-04-04 22:29:21 --> Controller Class Initialized
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:29:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:29:21 --> Final output sent to browser
DEBUG - 2018-04-04 22:29:21 --> Total execution time: 0.2746
INFO - 2018-04-04 22:29:22 --> Config Class Initialized
INFO - 2018-04-04 22:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:29:22 --> Utf8 Class Initialized
INFO - 2018-04-04 22:29:22 --> URI Class Initialized
INFO - 2018-04-04 22:29:22 --> Router Class Initialized
INFO - 2018-04-04 22:29:22 --> Output Class Initialized
INFO - 2018-04-04 22:29:22 --> Security Class Initialized
DEBUG - 2018-04-04 22:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:29:22 --> CSRF cookie sent
INFO - 2018-04-04 22:29:22 --> Input Class Initialized
INFO - 2018-04-04 22:29:22 --> Language Class Initialized
ERROR - 2018-04-04 22:29:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:29:22 --> Config Class Initialized
INFO - 2018-04-04 22:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:29:22 --> Utf8 Class Initialized
INFO - 2018-04-04 22:29:22 --> URI Class Initialized
INFO - 2018-04-04 22:29:22 --> Router Class Initialized
INFO - 2018-04-04 22:29:22 --> Output Class Initialized
INFO - 2018-04-04 22:29:22 --> Security Class Initialized
DEBUG - 2018-04-04 22:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:29:22 --> CSRF cookie sent
INFO - 2018-04-04 22:29:22 --> Input Class Initialized
INFO - 2018-04-04 22:29:22 --> Language Class Initialized
ERROR - 2018-04-04 22:29:22 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:33:35 --> Config Class Initialized
INFO - 2018-04-04 22:33:35 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:35 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:35 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:35 --> URI Class Initialized
INFO - 2018-04-04 22:33:35 --> Router Class Initialized
INFO - 2018-04-04 22:33:35 --> Output Class Initialized
INFO - 2018-04-04 22:33:35 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:35 --> CSRF cookie sent
INFO - 2018-04-04 22:33:35 --> Input Class Initialized
INFO - 2018-04-04 22:33:35 --> Language Class Initialized
INFO - 2018-04-04 22:33:35 --> Loader Class Initialized
INFO - 2018-04-04 22:33:35 --> Helper loaded: url_helper
INFO - 2018-04-04 22:33:35 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:33:35 --> User Agent Class Initialized
INFO - 2018-04-04 22:33:35 --> Controller Class Initialized
INFO - 2018-04-04 22:33:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:33:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:33:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:33:36 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:33:36 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:33:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:33:36 --> Final output sent to browser
DEBUG - 2018-04-04 22:33:36 --> Total execution time: 0.2843
INFO - 2018-04-04 22:33:37 --> Config Class Initialized
INFO - 2018-04-04 22:33:37 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:37 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:37 --> URI Class Initialized
INFO - 2018-04-04 22:33:37 --> Router Class Initialized
INFO - 2018-04-04 22:33:37 --> Output Class Initialized
INFO - 2018-04-04 22:33:37 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:37 --> CSRF cookie sent
INFO - 2018-04-04 22:33:37 --> Input Class Initialized
INFO - 2018-04-04 22:33:37 --> Language Class Initialized
ERROR - 2018-04-04 22:33:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:33:37 --> Config Class Initialized
INFO - 2018-04-04 22:33:37 --> Config Class Initialized
INFO - 2018-04-04 22:33:37 --> Hooks Class Initialized
INFO - 2018-04-04 22:33:37 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 22:33:37 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:37 --> URI Class Initialized
INFO - 2018-04-04 22:33:37 --> URI Class Initialized
INFO - 2018-04-04 22:33:37 --> Router Class Initialized
INFO - 2018-04-04 22:33:37 --> Router Class Initialized
INFO - 2018-04-04 22:33:37 --> Output Class Initialized
INFO - 2018-04-04 22:33:37 --> Output Class Initialized
INFO - 2018-04-04 22:33:37 --> Security Class Initialized
INFO - 2018-04-04 22:33:37 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 22:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:37 --> CSRF cookie sent
INFO - 2018-04-04 22:33:37 --> CSRF cookie sent
INFO - 2018-04-04 22:33:37 --> Input Class Initialized
INFO - 2018-04-04 22:33:37 --> Input Class Initialized
INFO - 2018-04-04 22:33:37 --> Language Class Initialized
INFO - 2018-04-04 22:33:37 --> Language Class Initialized
ERROR - 2018-04-04 22:33:37 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:33:37 --> Loader Class Initialized
INFO - 2018-04-04 22:33:37 --> Helper loaded: url_helper
INFO - 2018-04-04 22:33:37 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:33:38 --> User Agent Class Initialized
INFO - 2018-04-04 22:33:38 --> Controller Class Initialized
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:33:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:33:38 --> Final output sent to browser
DEBUG - 2018-04-04 22:33:38 --> Total execution time: 0.4006
INFO - 2018-04-04 22:33:38 --> Config Class Initialized
INFO - 2018-04-04 22:33:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:38 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:38 --> URI Class Initialized
INFO - 2018-04-04 22:33:38 --> Router Class Initialized
INFO - 2018-04-04 22:33:38 --> Output Class Initialized
INFO - 2018-04-04 22:33:38 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:38 --> CSRF cookie sent
INFO - 2018-04-04 22:33:38 --> Input Class Initialized
INFO - 2018-04-04 22:33:38 --> Language Class Initialized
ERROR - 2018-04-04 22:33:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:33:38 --> Config Class Initialized
INFO - 2018-04-04 22:33:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:39 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:39 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:39 --> URI Class Initialized
INFO - 2018-04-04 22:33:39 --> Router Class Initialized
INFO - 2018-04-04 22:33:39 --> Output Class Initialized
INFO - 2018-04-04 22:33:39 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:39 --> CSRF cookie sent
INFO - 2018-04-04 22:33:39 --> Input Class Initialized
INFO - 2018-04-04 22:33:39 --> Language Class Initialized
ERROR - 2018-04-04 22:33:39 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:33:56 --> Config Class Initialized
INFO - 2018-04-04 22:33:56 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:56 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:56 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:56 --> URI Class Initialized
INFO - 2018-04-04 22:33:56 --> Router Class Initialized
INFO - 2018-04-04 22:33:56 --> Output Class Initialized
INFO - 2018-04-04 22:33:56 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:56 --> CSRF cookie sent
INFO - 2018-04-04 22:33:56 --> Input Class Initialized
INFO - 2018-04-04 22:33:56 --> Language Class Initialized
INFO - 2018-04-04 22:33:56 --> Loader Class Initialized
INFO - 2018-04-04 22:33:56 --> Helper loaded: url_helper
INFO - 2018-04-04 22:33:56 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:33:56 --> User Agent Class Initialized
INFO - 2018-04-04 22:33:56 --> Controller Class Initialized
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:33:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:33:56 --> Final output sent to browser
DEBUG - 2018-04-04 22:33:56 --> Total execution time: 0.2893
INFO - 2018-04-04 22:33:57 --> Config Class Initialized
INFO - 2018-04-04 22:33:57 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:57 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:57 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:57 --> URI Class Initialized
INFO - 2018-04-04 22:33:57 --> Router Class Initialized
INFO - 2018-04-04 22:33:57 --> Output Class Initialized
INFO - 2018-04-04 22:33:57 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:57 --> CSRF cookie sent
INFO - 2018-04-04 22:33:57 --> Input Class Initialized
INFO - 2018-04-04 22:33:57 --> Language Class Initialized
ERROR - 2018-04-04 22:33:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:33:57 --> Config Class Initialized
INFO - 2018-04-04 22:33:57 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:33:57 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:33:57 --> Utf8 Class Initialized
INFO - 2018-04-04 22:33:57 --> URI Class Initialized
INFO - 2018-04-04 22:33:57 --> Router Class Initialized
INFO - 2018-04-04 22:33:57 --> Output Class Initialized
INFO - 2018-04-04 22:33:57 --> Security Class Initialized
DEBUG - 2018-04-04 22:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:33:57 --> CSRF cookie sent
INFO - 2018-04-04 22:33:57 --> Input Class Initialized
INFO - 2018-04-04 22:33:57 --> Language Class Initialized
ERROR - 2018-04-04 22:33:57 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:34:28 --> Config Class Initialized
INFO - 2018-04-04 22:34:28 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:29 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:29 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:29 --> URI Class Initialized
INFO - 2018-04-04 22:34:29 --> Router Class Initialized
INFO - 2018-04-04 22:34:29 --> Output Class Initialized
INFO - 2018-04-04 22:34:29 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:29 --> CSRF cookie sent
INFO - 2018-04-04 22:34:29 --> Input Class Initialized
INFO - 2018-04-04 22:34:29 --> Language Class Initialized
INFO - 2018-04-04 22:34:29 --> Loader Class Initialized
INFO - 2018-04-04 22:34:29 --> Helper loaded: url_helper
INFO - 2018-04-04 22:34:29 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:34:29 --> User Agent Class Initialized
INFO - 2018-04-04 22:34:29 --> Controller Class Initialized
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:34:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:34:29 --> Final output sent to browser
DEBUG - 2018-04-04 22:34:29 --> Total execution time: 0.2954
INFO - 2018-04-04 22:34:29 --> Config Class Initialized
INFO - 2018-04-04 22:34:29 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:29 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:29 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:29 --> URI Class Initialized
INFO - 2018-04-04 22:34:29 --> Router Class Initialized
INFO - 2018-04-04 22:34:29 --> Output Class Initialized
INFO - 2018-04-04 22:34:30 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:30 --> CSRF cookie sent
INFO - 2018-04-04 22:34:30 --> Input Class Initialized
INFO - 2018-04-04 22:34:30 --> Language Class Initialized
ERROR - 2018-04-04 22:34:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:34:30 --> Config Class Initialized
INFO - 2018-04-04 22:34:30 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:30 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:30 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:30 --> URI Class Initialized
INFO - 2018-04-04 22:34:30 --> Router Class Initialized
INFO - 2018-04-04 22:34:30 --> Output Class Initialized
INFO - 2018-04-04 22:34:30 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:30 --> CSRF cookie sent
INFO - 2018-04-04 22:34:30 --> Input Class Initialized
INFO - 2018-04-04 22:34:30 --> Language Class Initialized
ERROR - 2018-04-04 22:34:30 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:34:31 --> Config Class Initialized
INFO - 2018-04-04 22:34:31 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:31 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:31 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:31 --> URI Class Initialized
INFO - 2018-04-04 22:34:31 --> Router Class Initialized
INFO - 2018-04-04 22:34:31 --> Output Class Initialized
INFO - 2018-04-04 22:34:31 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:31 --> CSRF cookie sent
INFO - 2018-04-04 22:34:31 --> Input Class Initialized
INFO - 2018-04-04 22:34:32 --> Language Class Initialized
INFO - 2018-04-04 22:34:32 --> Loader Class Initialized
INFO - 2018-04-04 22:34:32 --> Helper loaded: url_helper
INFO - 2018-04-04 22:34:32 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:34:32 --> User Agent Class Initialized
INFO - 2018-04-04 22:34:32 --> Controller Class Initialized
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:34:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:34:32 --> Final output sent to browser
DEBUG - 2018-04-04 22:34:32 --> Total execution time: 0.2766
INFO - 2018-04-04 22:34:32 --> Config Class Initialized
INFO - 2018-04-04 22:34:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:32 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:32 --> URI Class Initialized
INFO - 2018-04-04 22:34:32 --> Router Class Initialized
INFO - 2018-04-04 22:34:32 --> Output Class Initialized
INFO - 2018-04-04 22:34:32 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:32 --> CSRF cookie sent
INFO - 2018-04-04 22:34:32 --> Input Class Initialized
INFO - 2018-04-04 22:34:32 --> Language Class Initialized
ERROR - 2018-04-04 22:34:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:34:32 --> Config Class Initialized
INFO - 2018-04-04 22:34:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:33 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:33 --> URI Class Initialized
INFO - 2018-04-04 22:34:33 --> Router Class Initialized
INFO - 2018-04-04 22:34:33 --> Output Class Initialized
INFO - 2018-04-04 22:34:33 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:33 --> CSRF cookie sent
INFO - 2018-04-04 22:34:33 --> Input Class Initialized
INFO - 2018-04-04 22:34:33 --> Language Class Initialized
ERROR - 2018-04-04 22:34:33 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:34:33 --> Config Class Initialized
INFO - 2018-04-04 22:34:33 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:33 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:33 --> URI Class Initialized
INFO - 2018-04-04 22:34:33 --> Router Class Initialized
INFO - 2018-04-04 22:34:33 --> Output Class Initialized
INFO - 2018-04-04 22:34:33 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:33 --> CSRF cookie sent
INFO - 2018-04-04 22:34:33 --> Input Class Initialized
INFO - 2018-04-04 22:34:33 --> Language Class Initialized
INFO - 2018-04-04 22:34:33 --> Loader Class Initialized
INFO - 2018-04-04 22:34:33 --> Helper loaded: url_helper
INFO - 2018-04-04 22:34:33 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:34:33 --> User Agent Class Initialized
INFO - 2018-04-04 22:34:33 --> Controller Class Initialized
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:34:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:34:33 --> Final output sent to browser
DEBUG - 2018-04-04 22:34:33 --> Total execution time: 0.3646
INFO - 2018-04-04 22:34:34 --> Config Class Initialized
INFO - 2018-04-04 22:34:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:34 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:34 --> URI Class Initialized
INFO - 2018-04-04 22:34:34 --> Router Class Initialized
INFO - 2018-04-04 22:34:34 --> Output Class Initialized
INFO - 2018-04-04 22:34:34 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:34 --> CSRF cookie sent
INFO - 2018-04-04 22:34:34 --> Input Class Initialized
INFO - 2018-04-04 22:34:34 --> Language Class Initialized
ERROR - 2018-04-04 22:34:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:34:34 --> Config Class Initialized
INFO - 2018-04-04 22:34:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:34 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:35 --> URI Class Initialized
INFO - 2018-04-04 22:34:35 --> Router Class Initialized
INFO - 2018-04-04 22:34:35 --> Output Class Initialized
INFO - 2018-04-04 22:34:35 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:35 --> CSRF cookie sent
INFO - 2018-04-04 22:34:35 --> Input Class Initialized
INFO - 2018-04-04 22:34:35 --> Language Class Initialized
ERROR - 2018-04-04 22:34:35 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:34:35 --> Config Class Initialized
INFO - 2018-04-04 22:34:35 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:35 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:35 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:35 --> URI Class Initialized
INFO - 2018-04-04 22:34:35 --> Router Class Initialized
INFO - 2018-04-04 22:34:35 --> Output Class Initialized
INFO - 2018-04-04 22:34:35 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:35 --> CSRF cookie sent
INFO - 2018-04-04 22:34:35 --> Input Class Initialized
INFO - 2018-04-04 22:34:35 --> Language Class Initialized
INFO - 2018-04-04 22:34:35 --> Loader Class Initialized
INFO - 2018-04-04 22:34:35 --> Helper loaded: url_helper
INFO - 2018-04-04 22:34:35 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:34:35 --> User Agent Class Initialized
INFO - 2018-04-04 22:34:35 --> Controller Class Initialized
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:34:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:34:35 --> Final output sent to browser
DEBUG - 2018-04-04 22:34:35 --> Total execution time: 0.2912
INFO - 2018-04-04 22:34:37 --> Config Class Initialized
INFO - 2018-04-04 22:34:37 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:37 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:37 --> URI Class Initialized
INFO - 2018-04-04 22:34:37 --> Router Class Initialized
INFO - 2018-04-04 22:34:37 --> Output Class Initialized
INFO - 2018-04-04 22:34:37 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:37 --> CSRF cookie sent
INFO - 2018-04-04 22:34:37 --> Input Class Initialized
INFO - 2018-04-04 22:34:37 --> Language Class Initialized
ERROR - 2018-04-04 22:34:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:34:37 --> Config Class Initialized
INFO - 2018-04-04 22:34:37 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:34:37 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:34:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:34:37 --> URI Class Initialized
INFO - 2018-04-04 22:34:37 --> Router Class Initialized
INFO - 2018-04-04 22:34:37 --> Output Class Initialized
INFO - 2018-04-04 22:34:37 --> Security Class Initialized
DEBUG - 2018-04-04 22:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:34:37 --> CSRF cookie sent
INFO - 2018-04-04 22:34:37 --> Input Class Initialized
INFO - 2018-04-04 22:34:37 --> Language Class Initialized
ERROR - 2018-04-04 22:34:37 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:41:42 --> Config Class Initialized
INFO - 2018-04-04 22:41:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:41:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:41:42 --> Utf8 Class Initialized
INFO - 2018-04-04 22:41:42 --> URI Class Initialized
INFO - 2018-04-04 22:41:42 --> Router Class Initialized
INFO - 2018-04-04 22:41:42 --> Output Class Initialized
INFO - 2018-04-04 22:41:42 --> Security Class Initialized
DEBUG - 2018-04-04 22:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:41:42 --> CSRF cookie sent
INFO - 2018-04-04 22:41:42 --> Input Class Initialized
INFO - 2018-04-04 22:41:42 --> Language Class Initialized
INFO - 2018-04-04 22:41:42 --> Loader Class Initialized
INFO - 2018-04-04 22:41:42 --> Helper loaded: url_helper
INFO - 2018-04-04 22:41:42 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:41:42 --> User Agent Class Initialized
INFO - 2018-04-04 22:41:42 --> Controller Class Initialized
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:41:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:41:42 --> Final output sent to browser
DEBUG - 2018-04-04 22:41:42 --> Total execution time: 0.2724
INFO - 2018-04-04 22:41:43 --> Config Class Initialized
INFO - 2018-04-04 22:41:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:41:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:41:43 --> Utf8 Class Initialized
INFO - 2018-04-04 22:41:43 --> URI Class Initialized
INFO - 2018-04-04 22:41:43 --> Router Class Initialized
INFO - 2018-04-04 22:41:43 --> Output Class Initialized
INFO - 2018-04-04 22:41:43 --> Security Class Initialized
DEBUG - 2018-04-04 22:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:41:43 --> CSRF cookie sent
INFO - 2018-04-04 22:41:43 --> Input Class Initialized
INFO - 2018-04-04 22:41:43 --> Config Class Initialized
INFO - 2018-04-04 22:41:43 --> Language Class Initialized
INFO - 2018-04-04 22:41:43 --> Hooks Class Initialized
ERROR - 2018-04-04 22:41:43 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:41:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:41:43 --> Utf8 Class Initialized
INFO - 2018-04-04 22:41:43 --> URI Class Initialized
INFO - 2018-04-04 22:41:43 --> Router Class Initialized
INFO - 2018-04-04 22:41:43 --> Output Class Initialized
INFO - 2018-04-04 22:41:43 --> Security Class Initialized
DEBUG - 2018-04-04 22:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:41:43 --> CSRF cookie sent
INFO - 2018-04-04 22:41:43 --> Input Class Initialized
INFO - 2018-04-04 22:41:43 --> Language Class Initialized
ERROR - 2018-04-04 22:41:43 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:42:07 --> Config Class Initialized
INFO - 2018-04-04 22:42:07 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:07 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:07 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:07 --> URI Class Initialized
INFO - 2018-04-04 22:42:07 --> Router Class Initialized
INFO - 2018-04-04 22:42:07 --> Output Class Initialized
INFO - 2018-04-04 22:42:07 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:07 --> CSRF cookie sent
INFO - 2018-04-04 22:42:07 --> Input Class Initialized
INFO - 2018-04-04 22:42:07 --> Language Class Initialized
INFO - 2018-04-04 22:42:07 --> Loader Class Initialized
INFO - 2018-04-04 22:42:07 --> Helper loaded: url_helper
INFO - 2018-04-04 22:42:07 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:42:07 --> User Agent Class Initialized
INFO - 2018-04-04 22:42:07 --> Controller Class Initialized
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:42:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:42:07 --> Final output sent to browser
DEBUG - 2018-04-04 22:42:07 --> Total execution time: 0.2824
INFO - 2018-04-04 22:42:08 --> Config Class Initialized
INFO - 2018-04-04 22:42:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:08 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:08 --> URI Class Initialized
INFO - 2018-04-04 22:42:08 --> Router Class Initialized
INFO - 2018-04-04 22:42:08 --> Output Class Initialized
INFO - 2018-04-04 22:42:08 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:08 --> CSRF cookie sent
INFO - 2018-04-04 22:42:08 --> Input Class Initialized
INFO - 2018-04-04 22:42:08 --> Config Class Initialized
INFO - 2018-04-04 22:42:08 --> Language Class Initialized
INFO - 2018-04-04 22:42:08 --> Hooks Class Initialized
ERROR - 2018-04-04 22:42:08 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:42:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:08 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:09 --> URI Class Initialized
INFO - 2018-04-04 22:42:09 --> Router Class Initialized
INFO - 2018-04-04 22:42:09 --> Output Class Initialized
INFO - 2018-04-04 22:42:09 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:09 --> CSRF cookie sent
INFO - 2018-04-04 22:42:09 --> Input Class Initialized
INFO - 2018-04-04 22:42:09 --> Language Class Initialized
ERROR - 2018-04-04 22:42:09 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:42:38 --> Config Class Initialized
INFO - 2018-04-04 22:42:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:38 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:38 --> URI Class Initialized
INFO - 2018-04-04 22:42:38 --> Router Class Initialized
INFO - 2018-04-04 22:42:38 --> Output Class Initialized
INFO - 2018-04-04 22:42:38 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:38 --> CSRF cookie sent
INFO - 2018-04-04 22:42:38 --> Input Class Initialized
INFO - 2018-04-04 22:42:38 --> Language Class Initialized
INFO - 2018-04-04 22:42:38 --> Loader Class Initialized
INFO - 2018-04-04 22:42:38 --> Helper loaded: url_helper
INFO - 2018-04-04 22:42:38 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:42:38 --> User Agent Class Initialized
INFO - 2018-04-04 22:42:38 --> Controller Class Initialized
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:42:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:42:38 --> Final output sent to browser
DEBUG - 2018-04-04 22:42:38 --> Total execution time: 0.3087
INFO - 2018-04-04 22:42:38 --> Config Class Initialized
INFO - 2018-04-04 22:42:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:39 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:39 --> URI Class Initialized
INFO - 2018-04-04 22:42:39 --> Router Class Initialized
INFO - 2018-04-04 22:42:39 --> Output Class Initialized
INFO - 2018-04-04 22:42:39 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:39 --> CSRF cookie sent
INFO - 2018-04-04 22:42:39 --> Input Class Initialized
INFO - 2018-04-04 22:42:39 --> Config Class Initialized
INFO - 2018-04-04 22:42:39 --> Hooks Class Initialized
INFO - 2018-04-04 22:42:39 --> Language Class Initialized
ERROR - 2018-04-04 22:42:39 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:42:39 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:39 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:39 --> URI Class Initialized
INFO - 2018-04-04 22:42:39 --> Router Class Initialized
INFO - 2018-04-04 22:42:39 --> Output Class Initialized
INFO - 2018-04-04 22:42:39 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:39 --> CSRF cookie sent
INFO - 2018-04-04 22:42:39 --> Input Class Initialized
INFO - 2018-04-04 22:42:39 --> Language Class Initialized
ERROR - 2018-04-04 22:42:39 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:42:41 --> Config Class Initialized
INFO - 2018-04-04 22:42:41 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:41 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:41 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:41 --> URI Class Initialized
INFO - 2018-04-04 22:42:41 --> Router Class Initialized
INFO - 2018-04-04 22:42:41 --> Output Class Initialized
INFO - 2018-04-04 22:42:42 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:42 --> CSRF cookie sent
INFO - 2018-04-04 22:42:42 --> Input Class Initialized
INFO - 2018-04-04 22:42:42 --> Language Class Initialized
INFO - 2018-04-04 22:42:42 --> Loader Class Initialized
INFO - 2018-04-04 22:42:42 --> Helper loaded: url_helper
INFO - 2018-04-04 22:42:42 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:42:42 --> User Agent Class Initialized
INFO - 2018-04-04 22:42:42 --> Controller Class Initialized
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:42:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:42:42 --> Final output sent to browser
DEBUG - 2018-04-04 22:42:42 --> Total execution time: 0.2818
INFO - 2018-04-04 22:42:42 --> Config Class Initialized
INFO - 2018-04-04 22:42:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:42 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:42 --> URI Class Initialized
INFO - 2018-04-04 22:42:42 --> Router Class Initialized
INFO - 2018-04-04 22:42:42 --> Output Class Initialized
INFO - 2018-04-04 22:42:42 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:42 --> CSRF cookie sent
INFO - 2018-04-04 22:42:42 --> Input Class Initialized
INFO - 2018-04-04 22:42:42 --> Language Class Initialized
INFO - 2018-04-04 22:42:42 --> Config Class Initialized
ERROR - 2018-04-04 22:42:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:42:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:42:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:42:42 --> Utf8 Class Initialized
INFO - 2018-04-04 22:42:43 --> URI Class Initialized
INFO - 2018-04-04 22:42:43 --> Router Class Initialized
INFO - 2018-04-04 22:42:43 --> Output Class Initialized
INFO - 2018-04-04 22:42:43 --> Security Class Initialized
DEBUG - 2018-04-04 22:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:42:43 --> CSRF cookie sent
INFO - 2018-04-04 22:42:43 --> Input Class Initialized
INFO - 2018-04-04 22:42:43 --> Language Class Initialized
ERROR - 2018-04-04 22:42:43 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:43:08 --> Config Class Initialized
INFO - 2018-04-04 22:43:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:43:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:08 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:08 --> URI Class Initialized
INFO - 2018-04-04 22:43:08 --> Router Class Initialized
INFO - 2018-04-04 22:43:08 --> Output Class Initialized
INFO - 2018-04-04 22:43:08 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:08 --> CSRF cookie sent
INFO - 2018-04-04 22:43:08 --> Input Class Initialized
INFO - 2018-04-04 22:43:08 --> Language Class Initialized
INFO - 2018-04-04 22:43:08 --> Loader Class Initialized
INFO - 2018-04-04 22:43:08 --> Helper loaded: url_helper
INFO - 2018-04-04 22:43:08 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:43:08 --> User Agent Class Initialized
INFO - 2018-04-04 22:43:08 --> Controller Class Initialized
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:43:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:43:08 --> Final output sent to browser
DEBUG - 2018-04-04 22:43:08 --> Total execution time: 0.3538
INFO - 2018-04-04 22:43:09 --> Config Class Initialized
INFO - 2018-04-04 22:43:09 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:43:09 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:09 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:09 --> URI Class Initialized
INFO - 2018-04-04 22:43:09 --> Router Class Initialized
INFO - 2018-04-04 22:43:09 --> Output Class Initialized
INFO - 2018-04-04 22:43:09 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:09 --> CSRF cookie sent
INFO - 2018-04-04 22:43:09 --> Input Class Initialized
INFO - 2018-04-04 22:43:09 --> Language Class Initialized
ERROR - 2018-04-04 22:43:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:43:09 --> Config Class Initialized
INFO - 2018-04-04 22:43:09 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:43:09 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:09 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:09 --> URI Class Initialized
INFO - 2018-04-04 22:43:09 --> Router Class Initialized
INFO - 2018-04-04 22:43:09 --> Output Class Initialized
INFO - 2018-04-04 22:43:09 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:09 --> CSRF cookie sent
INFO - 2018-04-04 22:43:09 --> Input Class Initialized
INFO - 2018-04-04 22:43:09 --> Language Class Initialized
ERROR - 2018-04-04 22:43:09 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:43:54 --> Config Class Initialized
INFO - 2018-04-04 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:54 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:54 --> URI Class Initialized
INFO - 2018-04-04 22:43:54 --> Router Class Initialized
INFO - 2018-04-04 22:43:54 --> Output Class Initialized
INFO - 2018-04-04 22:43:54 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:54 --> CSRF cookie sent
INFO - 2018-04-04 22:43:54 --> Input Class Initialized
INFO - 2018-04-04 22:43:54 --> Language Class Initialized
INFO - 2018-04-04 22:43:54 --> Loader Class Initialized
INFO - 2018-04-04 22:43:54 --> Helper loaded: url_helper
INFO - 2018-04-04 22:43:54 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:43:54 --> User Agent Class Initialized
INFO - 2018-04-04 22:43:54 --> Controller Class Initialized
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:43:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:43:54 --> Final output sent to browser
DEBUG - 2018-04-04 22:43:54 --> Total execution time: 0.2915
INFO - 2018-04-04 22:43:54 --> Config Class Initialized
INFO - 2018-04-04 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:55 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:55 --> URI Class Initialized
INFO - 2018-04-04 22:43:55 --> Router Class Initialized
INFO - 2018-04-04 22:43:55 --> Output Class Initialized
INFO - 2018-04-04 22:43:55 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:55 --> CSRF cookie sent
INFO - 2018-04-04 22:43:55 --> Input Class Initialized
INFO - 2018-04-04 22:43:55 --> Language Class Initialized
INFO - 2018-04-04 22:43:55 --> Config Class Initialized
INFO - 2018-04-04 22:43:55 --> Hooks Class Initialized
ERROR - 2018-04-04 22:43:55 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:43:55 --> Utf8 Class Initialized
INFO - 2018-04-04 22:43:55 --> URI Class Initialized
INFO - 2018-04-04 22:43:55 --> Router Class Initialized
INFO - 2018-04-04 22:43:55 --> Output Class Initialized
INFO - 2018-04-04 22:43:55 --> Security Class Initialized
DEBUG - 2018-04-04 22:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:43:55 --> CSRF cookie sent
INFO - 2018-04-04 22:43:55 --> Input Class Initialized
INFO - 2018-04-04 22:43:55 --> Language Class Initialized
ERROR - 2018-04-04 22:43:55 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:44:37 --> Config Class Initialized
INFO - 2018-04-04 22:44:37 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:44:37 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:44:37 --> Utf8 Class Initialized
INFO - 2018-04-04 22:44:37 --> URI Class Initialized
INFO - 2018-04-04 22:44:37 --> Router Class Initialized
INFO - 2018-04-04 22:44:37 --> Output Class Initialized
INFO - 2018-04-04 22:44:37 --> Security Class Initialized
DEBUG - 2018-04-04 22:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:44:37 --> CSRF cookie sent
INFO - 2018-04-04 22:44:37 --> Input Class Initialized
INFO - 2018-04-04 22:44:37 --> Language Class Initialized
INFO - 2018-04-04 22:44:37 --> Loader Class Initialized
INFO - 2018-04-04 22:44:37 --> Helper loaded: url_helper
INFO - 2018-04-04 22:44:37 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:44:37 --> User Agent Class Initialized
INFO - 2018-04-04 22:44:37 --> Controller Class Initialized
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:44:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:44:37 --> Final output sent to browser
DEBUG - 2018-04-04 22:44:37 --> Total execution time: 0.3060
INFO - 2018-04-04 22:44:38 --> Config Class Initialized
INFO - 2018-04-04 22:44:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:44:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:44:38 --> Utf8 Class Initialized
INFO - 2018-04-04 22:44:38 --> URI Class Initialized
INFO - 2018-04-04 22:44:38 --> Router Class Initialized
INFO - 2018-04-04 22:44:38 --> Output Class Initialized
INFO - 2018-04-04 22:44:38 --> Security Class Initialized
DEBUG - 2018-04-04 22:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:44:38 --> CSRF cookie sent
INFO - 2018-04-04 22:44:38 --> Input Class Initialized
INFO - 2018-04-04 22:44:38 --> Language Class Initialized
ERROR - 2018-04-04 22:44:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 22:44:38 --> Config Class Initialized
INFO - 2018-04-04 22:44:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:44:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:44:38 --> Utf8 Class Initialized
INFO - 2018-04-04 22:44:38 --> URI Class Initialized
INFO - 2018-04-04 22:44:38 --> Router Class Initialized
INFO - 2018-04-04 22:44:38 --> Output Class Initialized
INFO - 2018-04-04 22:44:38 --> Security Class Initialized
DEBUG - 2018-04-04 22:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:44:38 --> CSRF cookie sent
INFO - 2018-04-04 22:44:38 --> Input Class Initialized
INFO - 2018-04-04 22:44:38 --> Language Class Initialized
ERROR - 2018-04-04 22:44:38 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 22:45:38 --> Config Class Initialized
INFO - 2018-04-04 22:45:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:45:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:45:38 --> Utf8 Class Initialized
INFO - 2018-04-04 22:45:38 --> URI Class Initialized
INFO - 2018-04-04 22:45:38 --> Router Class Initialized
INFO - 2018-04-04 22:45:38 --> Output Class Initialized
INFO - 2018-04-04 22:45:38 --> Security Class Initialized
DEBUG - 2018-04-04 22:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:45:38 --> CSRF cookie sent
INFO - 2018-04-04 22:45:38 --> Input Class Initialized
INFO - 2018-04-04 22:45:38 --> Language Class Initialized
INFO - 2018-04-04 22:45:38 --> Loader Class Initialized
INFO - 2018-04-04 22:45:38 --> Helper loaded: url_helper
INFO - 2018-04-04 22:45:38 --> Helper loaded: form_helper
DEBUG - 2018-04-04 22:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:45:38 --> User Agent Class Initialized
INFO - 2018-04-04 22:45:38 --> Controller Class Initialized
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 22:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 22:45:38 --> Final output sent to browser
DEBUG - 2018-04-04 22:45:38 --> Total execution time: 0.6000
INFO - 2018-04-04 22:45:39 --> Config Class Initialized
INFO - 2018-04-04 22:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:45:39 --> Utf8 Class Initialized
INFO - 2018-04-04 22:45:39 --> URI Class Initialized
INFO - 2018-04-04 22:45:39 --> Router Class Initialized
INFO - 2018-04-04 22:45:39 --> Output Class Initialized
INFO - 2018-04-04 22:45:39 --> Security Class Initialized
DEBUG - 2018-04-04 22:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:45:39 --> CSRF cookie sent
INFO - 2018-04-04 22:45:39 --> Input Class Initialized
INFO - 2018-04-04 22:45:39 --> Config Class Initialized
INFO - 2018-04-04 22:45:39 --> Language Class Initialized
INFO - 2018-04-04 22:45:39 --> Hooks Class Initialized
ERROR - 2018-04-04 22:45:39 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-04 22:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:45:40 --> Utf8 Class Initialized
INFO - 2018-04-04 22:45:40 --> URI Class Initialized
INFO - 2018-04-04 22:45:40 --> Router Class Initialized
INFO - 2018-04-04 22:45:40 --> Output Class Initialized
INFO - 2018-04-04 22:45:40 --> Security Class Initialized
DEBUG - 2018-04-04 22:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:45:40 --> CSRF cookie sent
INFO - 2018-04-04 22:45:40 --> Input Class Initialized
INFO - 2018-04-04 22:45:40 --> Language Class Initialized
ERROR - 2018-04-04 22:45:40 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:11:53 --> Config Class Initialized
INFO - 2018-04-04 23:11:53 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:11:53 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:11:53 --> Utf8 Class Initialized
INFO - 2018-04-04 23:11:53 --> URI Class Initialized
INFO - 2018-04-04 23:11:53 --> Router Class Initialized
INFO - 2018-04-04 23:11:53 --> Output Class Initialized
INFO - 2018-04-04 23:11:53 --> Security Class Initialized
DEBUG - 2018-04-04 23:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:11:53 --> CSRF cookie sent
INFO - 2018-04-04 23:11:53 --> Input Class Initialized
INFO - 2018-04-04 23:11:53 --> Language Class Initialized
INFO - 2018-04-04 23:11:53 --> Loader Class Initialized
INFO - 2018-04-04 23:11:53 --> Helper loaded: url_helper
INFO - 2018-04-04 23:11:53 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:11:53 --> User Agent Class Initialized
INFO - 2018-04-04 23:11:53 --> Controller Class Initialized
INFO - 2018-04-04 23:11:53 --> Pixel_Model class loaded
INFO - 2018-04-04 23:11:53 --> Database Driver Class Initialized
INFO - 2018-04-04 23:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:12:38 --> Config Class Initialized
INFO - 2018-04-04 23:12:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:12:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:12:38 --> Utf8 Class Initialized
INFO - 2018-04-04 23:12:38 --> URI Class Initialized
INFO - 2018-04-04 23:12:38 --> Router Class Initialized
INFO - 2018-04-04 23:12:38 --> Output Class Initialized
INFO - 2018-04-04 23:12:38 --> Security Class Initialized
DEBUG - 2018-04-04 23:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:12:38 --> CSRF cookie sent
INFO - 2018-04-04 23:12:38 --> Input Class Initialized
INFO - 2018-04-04 23:12:38 --> Language Class Initialized
INFO - 2018-04-04 23:12:38 --> Loader Class Initialized
INFO - 2018-04-04 23:12:38 --> Helper loaded: url_helper
INFO - 2018-04-04 23:12:38 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:12:38 --> User Agent Class Initialized
INFO - 2018-04-04 23:12:38 --> Controller Class Initialized
INFO - 2018-04-04 23:12:38 --> Pixel_Model class loaded
INFO - 2018-04-04 23:12:38 --> Database Driver Class Initialized
INFO - 2018-04-04 23:12:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:12:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:12:38 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:12:38 --> Final output sent to browser
DEBUG - 2018-04-04 23:12:38 --> Total execution time: 0.3164
INFO - 2018-04-04 23:14:44 --> Config Class Initialized
INFO - 2018-04-04 23:14:44 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:14:44 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:14:44 --> Utf8 Class Initialized
INFO - 2018-04-04 23:14:44 --> URI Class Initialized
INFO - 2018-04-04 23:14:44 --> Router Class Initialized
INFO - 2018-04-04 23:14:44 --> Output Class Initialized
INFO - 2018-04-04 23:14:44 --> Security Class Initialized
DEBUG - 2018-04-04 23:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:14:44 --> CSRF cookie sent
INFO - 2018-04-04 23:14:44 --> Input Class Initialized
INFO - 2018-04-04 23:14:44 --> Language Class Initialized
INFO - 2018-04-04 23:14:44 --> Loader Class Initialized
INFO - 2018-04-04 23:14:44 --> Helper loaded: url_helper
INFO - 2018-04-04 23:14:44 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:14:44 --> User Agent Class Initialized
INFO - 2018-04-04 23:14:44 --> Controller Class Initialized
INFO - 2018-04-04 23:14:44 --> Pixel_Model class loaded
INFO - 2018-04-04 23:14:44 --> Database Driver Class Initialized
INFO - 2018-04-04 23:14:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:14:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:14:47 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:14:47 --> Final output sent to browser
DEBUG - 2018-04-04 23:14:47 --> Total execution time: 3.3272
INFO - 2018-04-04 23:15:21 --> Config Class Initialized
INFO - 2018-04-04 23:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:21 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:21 --> URI Class Initialized
INFO - 2018-04-04 23:15:21 --> Router Class Initialized
INFO - 2018-04-04 23:15:21 --> Output Class Initialized
INFO - 2018-04-04 23:15:21 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:21 --> CSRF cookie sent
INFO - 2018-04-04 23:15:21 --> Input Class Initialized
INFO - 2018-04-04 23:15:21 --> Language Class Initialized
INFO - 2018-04-04 23:15:21 --> Loader Class Initialized
INFO - 2018-04-04 23:15:21 --> Helper loaded: url_helper
INFO - 2018-04-04 23:15:21 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:15:21 --> User Agent Class Initialized
INFO - 2018-04-04 23:15:21 --> Controller Class Initialized
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:15:21 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:15:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:15:21 --> Final output sent to browser
DEBUG - 2018-04-04 23:15:21 --> Total execution time: 0.3724
INFO - 2018-04-04 23:15:22 --> Config Class Initialized
INFO - 2018-04-04 23:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:22 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:22 --> URI Class Initialized
INFO - 2018-04-04 23:15:22 --> Router Class Initialized
INFO - 2018-04-04 23:15:22 --> Output Class Initialized
INFO - 2018-04-04 23:15:22 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:22 --> CSRF cookie sent
INFO - 2018-04-04 23:15:22 --> Input Class Initialized
INFO - 2018-04-04 23:15:22 --> Language Class Initialized
ERROR - 2018-04-04 23:15:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:15:22 --> Config Class Initialized
INFO - 2018-04-04 23:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:22 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:22 --> URI Class Initialized
INFO - 2018-04-04 23:15:22 --> Router Class Initialized
INFO - 2018-04-04 23:15:22 --> Output Class Initialized
INFO - 2018-04-04 23:15:22 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:22 --> CSRF cookie sent
INFO - 2018-04-04 23:15:23 --> Input Class Initialized
INFO - 2018-04-04 23:15:23 --> Language Class Initialized
ERROR - 2018-04-04 23:15:23 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:15:23 --> Config Class Initialized
INFO - 2018-04-04 23:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:23 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:23 --> URI Class Initialized
INFO - 2018-04-04 23:15:23 --> Router Class Initialized
INFO - 2018-04-04 23:15:23 --> Output Class Initialized
INFO - 2018-04-04 23:15:23 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:23 --> CSRF cookie sent
INFO - 2018-04-04 23:15:23 --> Input Class Initialized
INFO - 2018-04-04 23:15:23 --> Language Class Initialized
INFO - 2018-04-04 23:15:23 --> Loader Class Initialized
INFO - 2018-04-04 23:15:24 --> Helper loaded: url_helper
INFO - 2018-04-04 23:15:24 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:15:24 --> User Agent Class Initialized
INFO - 2018-04-04 23:15:24 --> Controller Class Initialized
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:15:24 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:15:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:15:24 --> Final output sent to browser
DEBUG - 2018-04-04 23:15:24 --> Total execution time: 0.3507
INFO - 2018-04-04 23:15:24 --> Config Class Initialized
INFO - 2018-04-04 23:15:24 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:24 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:24 --> URI Class Initialized
INFO - 2018-04-04 23:15:24 --> Router Class Initialized
INFO - 2018-04-04 23:15:24 --> Output Class Initialized
INFO - 2018-04-04 23:15:24 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:24 --> CSRF cookie sent
INFO - 2018-04-04 23:15:24 --> Input Class Initialized
INFO - 2018-04-04 23:15:24 --> Language Class Initialized
ERROR - 2018-04-04 23:15:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:15:25 --> Config Class Initialized
INFO - 2018-04-04 23:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:25 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:25 --> URI Class Initialized
INFO - 2018-04-04 23:15:25 --> Router Class Initialized
INFO - 2018-04-04 23:15:25 --> Output Class Initialized
INFO - 2018-04-04 23:15:25 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:25 --> CSRF cookie sent
INFO - 2018-04-04 23:15:25 --> Input Class Initialized
INFO - 2018-04-04 23:15:25 --> Language Class Initialized
ERROR - 2018-04-04 23:15:25 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:15:26 --> Config Class Initialized
INFO - 2018-04-04 23:15:26 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:26 --> URI Class Initialized
INFO - 2018-04-04 23:15:26 --> Router Class Initialized
INFO - 2018-04-04 23:15:26 --> Output Class Initialized
INFO - 2018-04-04 23:15:26 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:26 --> CSRF cookie sent
INFO - 2018-04-04 23:15:26 --> Input Class Initialized
INFO - 2018-04-04 23:15:26 --> Language Class Initialized
INFO - 2018-04-04 23:15:26 --> Loader Class Initialized
INFO - 2018-04-04 23:15:26 --> Helper loaded: url_helper
INFO - 2018-04-04 23:15:26 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:15:26 --> User Agent Class Initialized
INFO - 2018-04-04 23:15:26 --> Controller Class Initialized
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:15:26 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:15:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:15:26 --> Final output sent to browser
DEBUG - 2018-04-04 23:15:26 --> Total execution time: 0.3205
INFO - 2018-04-04 23:15:27 --> Config Class Initialized
INFO - 2018-04-04 23:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:27 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:27 --> URI Class Initialized
INFO - 2018-04-04 23:15:27 --> Router Class Initialized
INFO - 2018-04-04 23:15:27 --> Output Class Initialized
INFO - 2018-04-04 23:15:27 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:27 --> CSRF cookie sent
INFO - 2018-04-04 23:15:27 --> Input Class Initialized
INFO - 2018-04-04 23:15:27 --> Language Class Initialized
ERROR - 2018-04-04 23:15:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:15:27 --> Config Class Initialized
INFO - 2018-04-04 23:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:15:27 --> Utf8 Class Initialized
INFO - 2018-04-04 23:15:27 --> URI Class Initialized
INFO - 2018-04-04 23:15:27 --> Router Class Initialized
INFO - 2018-04-04 23:15:28 --> Output Class Initialized
INFO - 2018-04-04 23:15:28 --> Security Class Initialized
DEBUG - 2018-04-04 23:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:15:28 --> CSRF cookie sent
INFO - 2018-04-04 23:15:28 --> Input Class Initialized
INFO - 2018-04-04 23:15:28 --> Language Class Initialized
ERROR - 2018-04-04 23:15:28 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:17:02 --> Config Class Initialized
INFO - 2018-04-04 23:17:02 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:17:02 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:17:02 --> Utf8 Class Initialized
INFO - 2018-04-04 23:17:02 --> URI Class Initialized
INFO - 2018-04-04 23:17:02 --> Router Class Initialized
INFO - 2018-04-04 23:17:02 --> Output Class Initialized
INFO - 2018-04-04 23:17:02 --> Security Class Initialized
DEBUG - 2018-04-04 23:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:17:02 --> CSRF cookie sent
INFO - 2018-04-04 23:17:02 --> Input Class Initialized
INFO - 2018-04-04 23:17:02 --> Language Class Initialized
INFO - 2018-04-04 23:17:02 --> Loader Class Initialized
INFO - 2018-04-04 23:17:02 --> Helper loaded: url_helper
INFO - 2018-04-04 23:17:03 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:17:03 --> User Agent Class Initialized
INFO - 2018-04-04 23:17:03 --> Controller Class Initialized
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:17:03 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:17:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:17:03 --> Final output sent to browser
DEBUG - 2018-04-04 23:17:03 --> Total execution time: 0.3204
INFO - 2018-04-04 23:17:03 --> Config Class Initialized
INFO - 2018-04-04 23:17:03 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:17:03 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:17:03 --> Utf8 Class Initialized
INFO - 2018-04-04 23:17:03 --> URI Class Initialized
INFO - 2018-04-04 23:17:03 --> Router Class Initialized
INFO - 2018-04-04 23:17:03 --> Output Class Initialized
INFO - 2018-04-04 23:17:03 --> Security Class Initialized
DEBUG - 2018-04-04 23:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:17:03 --> CSRF cookie sent
INFO - 2018-04-04 23:17:03 --> Input Class Initialized
INFO - 2018-04-04 23:17:03 --> Language Class Initialized
ERROR - 2018-04-04 23:17:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:17:04 --> Config Class Initialized
INFO - 2018-04-04 23:17:04 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:17:04 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:17:04 --> Utf8 Class Initialized
INFO - 2018-04-04 23:17:04 --> URI Class Initialized
INFO - 2018-04-04 23:17:04 --> Router Class Initialized
INFO - 2018-04-04 23:17:04 --> Output Class Initialized
INFO - 2018-04-04 23:17:04 --> Security Class Initialized
DEBUG - 2018-04-04 23:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:17:04 --> CSRF cookie sent
INFO - 2018-04-04 23:17:04 --> Input Class Initialized
INFO - 2018-04-04 23:17:04 --> Language Class Initialized
ERROR - 2018-04-04 23:17:04 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:18:11 --> Config Class Initialized
INFO - 2018-04-04 23:18:11 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:18:11 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:18:11 --> Utf8 Class Initialized
INFO - 2018-04-04 23:18:11 --> URI Class Initialized
INFO - 2018-04-04 23:18:11 --> Router Class Initialized
INFO - 2018-04-04 23:18:11 --> Output Class Initialized
INFO - 2018-04-04 23:18:11 --> Security Class Initialized
DEBUG - 2018-04-04 23:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:18:11 --> CSRF cookie sent
INFO - 2018-04-04 23:18:11 --> Input Class Initialized
INFO - 2018-04-04 23:18:11 --> Language Class Initialized
INFO - 2018-04-04 23:18:11 --> Loader Class Initialized
INFO - 2018-04-04 23:18:11 --> Helper loaded: url_helper
INFO - 2018-04-04 23:18:11 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:18:11 --> User Agent Class Initialized
INFO - 2018-04-04 23:18:11 --> Controller Class Initialized
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:18:11 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:18:11 --> Final output sent to browser
DEBUG - 2018-04-04 23:18:11 --> Total execution time: 0.3540
INFO - 2018-04-04 23:18:12 --> Config Class Initialized
INFO - 2018-04-04 23:18:12 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:18:12 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:18:12 --> Utf8 Class Initialized
INFO - 2018-04-04 23:18:12 --> URI Class Initialized
INFO - 2018-04-04 23:18:12 --> Router Class Initialized
INFO - 2018-04-04 23:18:12 --> Output Class Initialized
INFO - 2018-04-04 23:18:12 --> Security Class Initialized
DEBUG - 2018-04-04 23:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:18:12 --> CSRF cookie sent
INFO - 2018-04-04 23:18:12 --> Input Class Initialized
INFO - 2018-04-04 23:18:12 --> Language Class Initialized
ERROR - 2018-04-04 23:18:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:18:12 --> Config Class Initialized
INFO - 2018-04-04 23:18:12 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:18:12 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:18:12 --> Utf8 Class Initialized
INFO - 2018-04-04 23:18:12 --> URI Class Initialized
INFO - 2018-04-04 23:18:12 --> Router Class Initialized
INFO - 2018-04-04 23:18:12 --> Output Class Initialized
INFO - 2018-04-04 23:18:12 --> Security Class Initialized
DEBUG - 2018-04-04 23:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:18:12 --> CSRF cookie sent
INFO - 2018-04-04 23:18:12 --> Input Class Initialized
INFO - 2018-04-04 23:18:12 --> Language Class Initialized
ERROR - 2018-04-04 23:18:12 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:23:06 --> Config Class Initialized
INFO - 2018-04-04 23:23:06 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:06 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:06 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:06 --> URI Class Initialized
INFO - 2018-04-04 23:23:06 --> Router Class Initialized
INFO - 2018-04-04 23:23:06 --> Output Class Initialized
INFO - 2018-04-04 23:23:06 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:06 --> CSRF cookie sent
INFO - 2018-04-04 23:23:06 --> Input Class Initialized
INFO - 2018-04-04 23:23:06 --> Language Class Initialized
INFO - 2018-04-04 23:23:07 --> Loader Class Initialized
INFO - 2018-04-04 23:23:07 --> Helper loaded: url_helper
INFO - 2018-04-04 23:23:07 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:23:07 --> User Agent Class Initialized
INFO - 2018-04-04 23:23:07 --> Controller Class Initialized
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:23:07 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:23:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:23:07 --> Final output sent to browser
DEBUG - 2018-04-04 23:23:07 --> Total execution time: 0.3333
INFO - 2018-04-04 23:23:07 --> Config Class Initialized
INFO - 2018-04-04 23:23:07 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:07 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:07 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:07 --> URI Class Initialized
INFO - 2018-04-04 23:23:07 --> Router Class Initialized
INFO - 2018-04-04 23:23:07 --> Output Class Initialized
INFO - 2018-04-04 23:23:07 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:07 --> CSRF cookie sent
INFO - 2018-04-04 23:23:07 --> Input Class Initialized
INFO - 2018-04-04 23:23:07 --> Language Class Initialized
ERROR - 2018-04-04 23:23:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:23:08 --> Config Class Initialized
INFO - 2018-04-04 23:23:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:08 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:08 --> URI Class Initialized
INFO - 2018-04-04 23:23:08 --> Router Class Initialized
INFO - 2018-04-04 23:23:08 --> Output Class Initialized
INFO - 2018-04-04 23:23:08 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:08 --> CSRF cookie sent
INFO - 2018-04-04 23:23:08 --> Input Class Initialized
INFO - 2018-04-04 23:23:08 --> Language Class Initialized
ERROR - 2018-04-04 23:23:08 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:23:33 --> Config Class Initialized
INFO - 2018-04-04 23:23:33 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:33 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:33 --> URI Class Initialized
INFO - 2018-04-04 23:23:33 --> Router Class Initialized
INFO - 2018-04-04 23:23:33 --> Output Class Initialized
INFO - 2018-04-04 23:23:33 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:33 --> CSRF cookie sent
INFO - 2018-04-04 23:23:33 --> Input Class Initialized
INFO - 2018-04-04 23:23:33 --> Language Class Initialized
INFO - 2018-04-04 23:23:33 --> Loader Class Initialized
INFO - 2018-04-04 23:23:33 --> Helper loaded: url_helper
INFO - 2018-04-04 23:23:33 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:23:33 --> User Agent Class Initialized
INFO - 2018-04-04 23:23:33 --> Controller Class Initialized
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:23:33 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:23:33 --> Final output sent to browser
DEBUG - 2018-04-04 23:23:33 --> Total execution time: 0.3192
INFO - 2018-04-04 23:23:34 --> Config Class Initialized
INFO - 2018-04-04 23:23:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:34 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:34 --> URI Class Initialized
INFO - 2018-04-04 23:23:34 --> Router Class Initialized
INFO - 2018-04-04 23:23:34 --> Output Class Initialized
INFO - 2018-04-04 23:23:34 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:34 --> CSRF cookie sent
INFO - 2018-04-04 23:23:34 --> Input Class Initialized
INFO - 2018-04-04 23:23:34 --> Language Class Initialized
ERROR - 2018-04-04 23:23:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:23:34 --> Config Class Initialized
INFO - 2018-04-04 23:23:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:23:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:23:34 --> Utf8 Class Initialized
INFO - 2018-04-04 23:23:34 --> URI Class Initialized
INFO - 2018-04-04 23:23:34 --> Router Class Initialized
INFO - 2018-04-04 23:23:34 --> Output Class Initialized
INFO - 2018-04-04 23:23:34 --> Security Class Initialized
DEBUG - 2018-04-04 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:23:34 --> CSRF cookie sent
INFO - 2018-04-04 23:23:34 --> Input Class Initialized
INFO - 2018-04-04 23:23:34 --> Language Class Initialized
ERROR - 2018-04-04 23:23:34 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:24:32 --> Config Class Initialized
INFO - 2018-04-04 23:24:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:32 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:32 --> URI Class Initialized
INFO - 2018-04-04 23:24:32 --> Router Class Initialized
INFO - 2018-04-04 23:24:32 --> Output Class Initialized
INFO - 2018-04-04 23:24:32 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:32 --> CSRF cookie sent
INFO - 2018-04-04 23:24:32 --> Input Class Initialized
INFO - 2018-04-04 23:24:32 --> Language Class Initialized
INFO - 2018-04-04 23:24:32 --> Loader Class Initialized
INFO - 2018-04-04 23:24:32 --> Helper loaded: url_helper
INFO - 2018-04-04 23:24:32 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:24:32 --> User Agent Class Initialized
INFO - 2018-04-04 23:24:32 --> Controller Class Initialized
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:24:32 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:24:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:24:32 --> Final output sent to browser
DEBUG - 2018-04-04 23:24:32 --> Total execution time: 0.3638
INFO - 2018-04-04 23:24:33 --> Config Class Initialized
INFO - 2018-04-04 23:24:33 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:33 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:33 --> URI Class Initialized
INFO - 2018-04-04 23:24:33 --> Router Class Initialized
INFO - 2018-04-04 23:24:33 --> Output Class Initialized
INFO - 2018-04-04 23:24:33 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:33 --> CSRF cookie sent
INFO - 2018-04-04 23:24:33 --> Input Class Initialized
INFO - 2018-04-04 23:24:33 --> Language Class Initialized
ERROR - 2018-04-04 23:24:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:24:33 --> Config Class Initialized
INFO - 2018-04-04 23:24:33 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:33 --> Config Class Initialized
INFO - 2018-04-04 23:24:33 --> Hooks Class Initialized
INFO - 2018-04-04 23:24:33 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:33 --> URI Class Initialized
DEBUG - 2018-04-04 23:24:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:33 --> Router Class Initialized
INFO - 2018-04-04 23:24:33 --> Output Class Initialized
INFO - 2018-04-04 23:24:33 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:33 --> URI Class Initialized
INFO - 2018-04-04 23:24:33 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:33 --> Router Class Initialized
INFO - 2018-04-04 23:24:34 --> CSRF cookie sent
INFO - 2018-04-04 23:24:34 --> Output Class Initialized
INFO - 2018-04-04 23:24:34 --> Input Class Initialized
INFO - 2018-04-04 23:24:34 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:34 --> Language Class Initialized
INFO - 2018-04-04 23:24:34 --> CSRF cookie sent
INFO - 2018-04-04 23:24:34 --> Loader Class Initialized
INFO - 2018-04-04 23:24:34 --> Input Class Initialized
INFO - 2018-04-04 23:24:34 --> Helper loaded: url_helper
INFO - 2018-04-04 23:24:34 --> Language Class Initialized
INFO - 2018-04-04 23:24:34 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:24:34 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:24:34 --> User Agent Class Initialized
INFO - 2018-04-04 23:24:34 --> Controller Class Initialized
INFO - 2018-04-04 23:24:34 --> Pixel_Model class loaded
INFO - 2018-04-04 23:24:34 --> Database Driver Class Initialized
INFO - 2018-04-04 23:24:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:24:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:24:37 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:24:37 --> Final output sent to browser
DEBUG - 2018-04-04 23:24:37 --> Total execution time: 3.5252
INFO - 2018-04-04 23:24:46 --> Config Class Initialized
INFO - 2018-04-04 23:24:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:46 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:46 --> URI Class Initialized
INFO - 2018-04-04 23:24:46 --> Router Class Initialized
INFO - 2018-04-04 23:24:46 --> Output Class Initialized
INFO - 2018-04-04 23:24:46 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:46 --> CSRF cookie sent
INFO - 2018-04-04 23:24:46 --> Input Class Initialized
INFO - 2018-04-04 23:24:46 --> Language Class Initialized
INFO - 2018-04-04 23:24:46 --> Loader Class Initialized
INFO - 2018-04-04 23:24:46 --> Helper loaded: url_helper
INFO - 2018-04-04 23:24:46 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:24:46 --> User Agent Class Initialized
INFO - 2018-04-04 23:24:46 --> Controller Class Initialized
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:24:46 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:24:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:24:46 --> Final output sent to browser
DEBUG - 2018-04-04 23:24:46 --> Total execution time: 0.3294
INFO - 2018-04-04 23:24:46 --> Config Class Initialized
INFO - 2018-04-04 23:24:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:47 --> URI Class Initialized
INFO - 2018-04-04 23:24:47 --> Router Class Initialized
INFO - 2018-04-04 23:24:47 --> Output Class Initialized
INFO - 2018-04-04 23:24:47 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:47 --> CSRF cookie sent
INFO - 2018-04-04 23:24:47 --> Input Class Initialized
INFO - 2018-04-04 23:24:47 --> Language Class Initialized
ERROR - 2018-04-04 23:24:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:24:47 --> Config Class Initialized
INFO - 2018-04-04 23:24:47 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:24:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:47 --> Config Class Initialized
INFO - 2018-04-04 23:24:47 --> Hooks Class Initialized
INFO - 2018-04-04 23:24:47 --> URI Class Initialized
INFO - 2018-04-04 23:24:47 --> Router Class Initialized
DEBUG - 2018-04-04 23:24:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:24:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:24:47 --> Output Class Initialized
INFO - 2018-04-04 23:24:47 --> URI Class Initialized
INFO - 2018-04-04 23:24:47 --> Security Class Initialized
DEBUG - 2018-04-04 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:47 --> Router Class Initialized
INFO - 2018-04-04 23:24:47 --> CSRF cookie sent
INFO - 2018-04-04 23:24:47 --> Output Class Initialized
INFO - 2018-04-04 23:24:47 --> Input Class Initialized
INFO - 2018-04-04 23:24:47 --> Security Class Initialized
INFO - 2018-04-04 23:24:47 --> Language Class Initialized
DEBUG - 2018-04-04 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:24:47 --> CSRF cookie sent
INFO - 2018-04-04 23:24:47 --> Loader Class Initialized
INFO - 2018-04-04 23:24:47 --> Input Class Initialized
INFO - 2018-04-04 23:24:47 --> Helper loaded: url_helper
INFO - 2018-04-04 23:24:47 --> Language Class Initialized
INFO - 2018-04-04 23:24:47 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:24:47 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:24:47 --> User Agent Class Initialized
INFO - 2018-04-04 23:24:47 --> Controller Class Initialized
INFO - 2018-04-04 23:24:47 --> Pixel_Model class loaded
INFO - 2018-04-04 23:24:47 --> Database Driver Class Initialized
INFO - 2018-04-04 23:24:47 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:24:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:24:47 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:24:47 --> Final output sent to browser
DEBUG - 2018-04-04 23:24:47 --> Total execution time: 0.4913
INFO - 2018-04-04 23:25:49 --> Config Class Initialized
INFO - 2018-04-04 23:25:49 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:25:49 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:25:49 --> Utf8 Class Initialized
INFO - 2018-04-04 23:25:49 --> URI Class Initialized
INFO - 2018-04-04 23:25:50 --> Router Class Initialized
INFO - 2018-04-04 23:25:50 --> Output Class Initialized
INFO - 2018-04-04 23:25:50 --> Security Class Initialized
DEBUG - 2018-04-04 23:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:25:50 --> CSRF cookie sent
INFO - 2018-04-04 23:25:50 --> Input Class Initialized
INFO - 2018-04-04 23:25:50 --> Language Class Initialized
INFO - 2018-04-04 23:25:50 --> Loader Class Initialized
INFO - 2018-04-04 23:25:50 --> Helper loaded: url_helper
INFO - 2018-04-04 23:25:50 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:25:50 --> User Agent Class Initialized
INFO - 2018-04-04 23:25:50 --> Controller Class Initialized
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:25:50 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:25:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:25:50 --> Final output sent to browser
DEBUG - 2018-04-04 23:25:50 --> Total execution time: 0.3741
INFO - 2018-04-04 23:25:50 --> Config Class Initialized
INFO - 2018-04-04 23:25:50 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:25:50 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:25:50 --> Utf8 Class Initialized
INFO - 2018-04-04 23:25:50 --> URI Class Initialized
INFO - 2018-04-04 23:25:50 --> Router Class Initialized
INFO - 2018-04-04 23:25:50 --> Output Class Initialized
INFO - 2018-04-04 23:25:50 --> Security Class Initialized
DEBUG - 2018-04-04 23:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:25:50 --> CSRF cookie sent
INFO - 2018-04-04 23:25:50 --> Input Class Initialized
INFO - 2018-04-04 23:25:50 --> Language Class Initialized
ERROR - 2018-04-04 23:25:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:25:51 --> Config Class Initialized
INFO - 2018-04-04 23:25:51 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:25:51 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:25:51 --> Config Class Initialized
INFO - 2018-04-04 23:25:51 --> Hooks Class Initialized
INFO - 2018-04-04 23:25:51 --> Utf8 Class Initialized
INFO - 2018-04-04 23:25:51 --> URI Class Initialized
DEBUG - 2018-04-04 23:25:51 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:25:51 --> Utf8 Class Initialized
INFO - 2018-04-04 23:25:51 --> Router Class Initialized
INFO - 2018-04-04 23:25:51 --> URI Class Initialized
INFO - 2018-04-04 23:25:51 --> Output Class Initialized
INFO - 2018-04-04 23:25:51 --> Security Class Initialized
INFO - 2018-04-04 23:25:51 --> Router Class Initialized
DEBUG - 2018-04-04 23:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:25:51 --> Output Class Initialized
INFO - 2018-04-04 23:25:51 --> CSRF cookie sent
INFO - 2018-04-04 23:25:51 --> Security Class Initialized
INFO - 2018-04-04 23:25:51 --> Input Class Initialized
DEBUG - 2018-04-04 23:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:25:51 --> CSRF cookie sent
INFO - 2018-04-04 23:25:51 --> Language Class Initialized
INFO - 2018-04-04 23:25:51 --> Input Class Initialized
INFO - 2018-04-04 23:25:51 --> Loader Class Initialized
INFO - 2018-04-04 23:25:51 --> Language Class Initialized
INFO - 2018-04-04 23:25:51 --> Helper loaded: url_helper
INFO - 2018-04-04 23:25:51 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:25:51 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:25:51 --> User Agent Class Initialized
INFO - 2018-04-04 23:25:51 --> Controller Class Initialized
INFO - 2018-04-04 23:25:51 --> Pixel_Model class loaded
INFO - 2018-04-04 23:25:51 --> Database Driver Class Initialized
INFO - 2018-04-04 23:25:54 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:25:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:25:54 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:25:54 --> Final output sent to browser
DEBUG - 2018-04-04 23:25:54 --> Total execution time: 3.5649
INFO - 2018-04-04 23:26:22 --> Config Class Initialized
INFO - 2018-04-04 23:26:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:26:22 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:26:22 --> Utf8 Class Initialized
INFO - 2018-04-04 23:26:22 --> URI Class Initialized
INFO - 2018-04-04 23:26:22 --> Router Class Initialized
INFO - 2018-04-04 23:26:22 --> Output Class Initialized
INFO - 2018-04-04 23:26:22 --> Security Class Initialized
DEBUG - 2018-04-04 23:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:26:22 --> CSRF cookie sent
INFO - 2018-04-04 23:26:22 --> Input Class Initialized
INFO - 2018-04-04 23:26:22 --> Language Class Initialized
INFO - 2018-04-04 23:26:22 --> Loader Class Initialized
INFO - 2018-04-04 23:26:22 --> Helper loaded: url_helper
INFO - 2018-04-04 23:26:22 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:26:22 --> User Agent Class Initialized
INFO - 2018-04-04 23:26:22 --> Controller Class Initialized
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:26:22 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:26:22 --> Final output sent to browser
DEBUG - 2018-04-04 23:26:22 --> Total execution time: 0.3733
INFO - 2018-04-04 23:26:22 --> Config Class Initialized
INFO - 2018-04-04 23:26:22 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:26:23 --> Utf8 Class Initialized
INFO - 2018-04-04 23:26:23 --> URI Class Initialized
INFO - 2018-04-04 23:26:23 --> Router Class Initialized
INFO - 2018-04-04 23:26:23 --> Output Class Initialized
INFO - 2018-04-04 23:26:23 --> Security Class Initialized
DEBUG - 2018-04-04 23:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:26:23 --> CSRF cookie sent
INFO - 2018-04-04 23:26:23 --> Input Class Initialized
INFO - 2018-04-04 23:26:23 --> Language Class Initialized
ERROR - 2018-04-04 23:26:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:26:23 --> Config Class Initialized
INFO - 2018-04-04 23:26:23 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:26:23 --> Utf8 Class Initialized
INFO - 2018-04-04 23:26:23 --> Config Class Initialized
INFO - 2018-04-04 23:26:23 --> Hooks Class Initialized
INFO - 2018-04-04 23:26:23 --> URI Class Initialized
INFO - 2018-04-04 23:26:23 --> Router Class Initialized
DEBUG - 2018-04-04 23:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:26:23 --> Utf8 Class Initialized
INFO - 2018-04-04 23:26:23 --> Output Class Initialized
INFO - 2018-04-04 23:26:23 --> URI Class Initialized
INFO - 2018-04-04 23:26:23 --> Security Class Initialized
DEBUG - 2018-04-04 23:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:26:23 --> Router Class Initialized
INFO - 2018-04-04 23:26:23 --> CSRF cookie sent
INFO - 2018-04-04 23:26:23 --> Output Class Initialized
INFO - 2018-04-04 23:26:23 --> Input Class Initialized
INFO - 2018-04-04 23:26:23 --> Security Class Initialized
INFO - 2018-04-04 23:26:23 --> Language Class Initialized
DEBUG - 2018-04-04 23:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:26:23 --> CSRF cookie sent
INFO - 2018-04-04 23:26:23 --> Loader Class Initialized
INFO - 2018-04-04 23:26:23 --> Input Class Initialized
INFO - 2018-04-04 23:26:23 --> Helper loaded: url_helper
INFO - 2018-04-04 23:26:23 --> Language Class Initialized
INFO - 2018-04-04 23:26:23 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:26:23 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:26:23 --> User Agent Class Initialized
INFO - 2018-04-04 23:26:23 --> Controller Class Initialized
INFO - 2018-04-04 23:26:23 --> Pixel_Model class loaded
INFO - 2018-04-04 23:26:23 --> Database Driver Class Initialized
INFO - 2018-04-04 23:26:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:26:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:26:23 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:26:23 --> Final output sent to browser
DEBUG - 2018-04-04 23:26:23 --> Total execution time: 0.5255
INFO - 2018-04-04 23:28:48 --> Config Class Initialized
INFO - 2018-04-04 23:28:48 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:28:48 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:28:48 --> Utf8 Class Initialized
INFO - 2018-04-04 23:28:48 --> URI Class Initialized
INFO - 2018-04-04 23:28:48 --> Router Class Initialized
INFO - 2018-04-04 23:28:48 --> Output Class Initialized
INFO - 2018-04-04 23:28:48 --> Security Class Initialized
DEBUG - 2018-04-04 23:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:28:48 --> CSRF cookie sent
INFO - 2018-04-04 23:28:48 --> Input Class Initialized
INFO - 2018-04-04 23:28:48 --> Language Class Initialized
INFO - 2018-04-04 23:28:48 --> Loader Class Initialized
INFO - 2018-04-04 23:28:48 --> Helper loaded: url_helper
INFO - 2018-04-04 23:28:48 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:28:48 --> User Agent Class Initialized
INFO - 2018-04-04 23:28:48 --> Controller Class Initialized
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:28:48 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:28:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:28:48 --> Final output sent to browser
DEBUG - 2018-04-04 23:28:48 --> Total execution time: 0.3410
INFO - 2018-04-04 23:28:48 --> Config Class Initialized
INFO - 2018-04-04 23:28:48 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:28:49 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:28:49 --> Utf8 Class Initialized
INFO - 2018-04-04 23:28:49 --> URI Class Initialized
INFO - 2018-04-04 23:28:49 --> Router Class Initialized
INFO - 2018-04-04 23:28:49 --> Output Class Initialized
INFO - 2018-04-04 23:28:49 --> Security Class Initialized
DEBUG - 2018-04-04 23:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:28:49 --> CSRF cookie sent
INFO - 2018-04-04 23:28:49 --> Input Class Initialized
INFO - 2018-04-04 23:28:49 --> Language Class Initialized
ERROR - 2018-04-04 23:28:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:28:49 --> Config Class Initialized
INFO - 2018-04-04 23:28:49 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:28:49 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:28:49 --> Config Class Initialized
INFO - 2018-04-04 23:28:49 --> Hooks Class Initialized
INFO - 2018-04-04 23:28:49 --> Utf8 Class Initialized
INFO - 2018-04-04 23:28:49 --> URI Class Initialized
DEBUG - 2018-04-04 23:28:49 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:28:49 --> Router Class Initialized
INFO - 2018-04-04 23:28:49 --> Utf8 Class Initialized
INFO - 2018-04-04 23:28:49 --> Output Class Initialized
INFO - 2018-04-04 23:28:49 --> Security Class Initialized
INFO - 2018-04-04 23:28:49 --> URI Class Initialized
DEBUG - 2018-04-04 23:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:28:49 --> Router Class Initialized
INFO - 2018-04-04 23:28:49 --> CSRF cookie sent
INFO - 2018-04-04 23:28:49 --> Output Class Initialized
INFO - 2018-04-04 23:28:49 --> Input Class Initialized
INFO - 2018-04-04 23:28:49 --> Security Class Initialized
INFO - 2018-04-04 23:28:49 --> Language Class Initialized
DEBUG - 2018-04-04 23:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:28:49 --> CSRF cookie sent
INFO - 2018-04-04 23:28:49 --> Loader Class Initialized
INFO - 2018-04-04 23:28:49 --> Input Class Initialized
INFO - 2018-04-04 23:28:49 --> Helper loaded: url_helper
INFO - 2018-04-04 23:28:49 --> Language Class Initialized
INFO - 2018-04-04 23:28:49 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:28:49 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:28:49 --> User Agent Class Initialized
INFO - 2018-04-04 23:28:49 --> Controller Class Initialized
INFO - 2018-04-04 23:28:49 --> Pixel_Model class loaded
INFO - 2018-04-04 23:28:49 --> Database Driver Class Initialized
INFO - 2018-04-04 23:28:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:28:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:28:52 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:28:52 --> Final output sent to browser
DEBUG - 2018-04-04 23:28:52 --> Total execution time: 3.4828
INFO - 2018-04-04 23:30:41 --> Config Class Initialized
INFO - 2018-04-04 23:30:41 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:30:41 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:30:41 --> Utf8 Class Initialized
INFO - 2018-04-04 23:30:41 --> URI Class Initialized
INFO - 2018-04-04 23:30:41 --> Router Class Initialized
INFO - 2018-04-04 23:30:41 --> Output Class Initialized
INFO - 2018-04-04 23:30:41 --> Security Class Initialized
DEBUG - 2018-04-04 23:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:30:41 --> CSRF cookie sent
INFO - 2018-04-04 23:30:41 --> Input Class Initialized
INFO - 2018-04-04 23:30:41 --> Language Class Initialized
INFO - 2018-04-04 23:30:41 --> Loader Class Initialized
INFO - 2018-04-04 23:30:41 --> Helper loaded: url_helper
INFO - 2018-04-04 23:30:41 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:30:41 --> User Agent Class Initialized
INFO - 2018-04-04 23:30:41 --> Controller Class Initialized
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:30:41 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:30:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:30:41 --> Final output sent to browser
DEBUG - 2018-04-04 23:30:41 --> Total execution time: 0.4122
INFO - 2018-04-04 23:30:42 --> Config Class Initialized
INFO - 2018-04-04 23:30:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:30:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:30:42 --> Utf8 Class Initialized
INFO - 2018-04-04 23:30:42 --> URI Class Initialized
INFO - 2018-04-04 23:30:42 --> Router Class Initialized
INFO - 2018-04-04 23:30:42 --> Output Class Initialized
INFO - 2018-04-04 23:30:42 --> Security Class Initialized
DEBUG - 2018-04-04 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:30:42 --> CSRF cookie sent
INFO - 2018-04-04 23:30:42 --> Input Class Initialized
INFO - 2018-04-04 23:30:42 --> Language Class Initialized
ERROR - 2018-04-04 23:30:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:30:42 --> Config Class Initialized
INFO - 2018-04-04 23:30:42 --> Hooks Class Initialized
INFO - 2018-04-04 23:30:42 --> Config Class Initialized
INFO - 2018-04-04 23:30:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:30:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:30:42 --> Utf8 Class Initialized
DEBUG - 2018-04-04 23:30:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:30:42 --> Utf8 Class Initialized
INFO - 2018-04-04 23:30:42 --> URI Class Initialized
INFO - 2018-04-04 23:30:42 --> URI Class Initialized
INFO - 2018-04-04 23:30:42 --> Router Class Initialized
INFO - 2018-04-04 23:30:42 --> Output Class Initialized
INFO - 2018-04-04 23:30:42 --> Router Class Initialized
INFO - 2018-04-04 23:30:42 --> Security Class Initialized
INFO - 2018-04-04 23:30:42 --> Output Class Initialized
INFO - 2018-04-04 23:30:42 --> Security Class Initialized
DEBUG - 2018-04-04 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:30:42 --> CSRF cookie sent
DEBUG - 2018-04-04 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:30:42 --> CSRF cookie sent
INFO - 2018-04-04 23:30:42 --> Input Class Initialized
INFO - 2018-04-04 23:30:42 --> Input Class Initialized
INFO - 2018-04-04 23:30:42 --> Language Class Initialized
INFO - 2018-04-04 23:30:42 --> Language Class Initialized
INFO - 2018-04-04 23:30:42 --> Loader Class Initialized
INFO - 2018-04-04 23:30:42 --> Helper loaded: url_helper
ERROR - 2018-04-04 23:30:42 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:30:42 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:30:42 --> User Agent Class Initialized
INFO - 2018-04-04 23:30:42 --> Controller Class Initialized
INFO - 2018-04-04 23:30:43 --> Pixel_Model class loaded
INFO - 2018-04-04 23:30:43 --> Database Driver Class Initialized
INFO - 2018-04-04 23:30:46 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:30:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:30:46 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:30:46 --> Final output sent to browser
DEBUG - 2018-04-04 23:30:46 --> Total execution time: 3.5227
INFO - 2018-04-04 23:32:07 --> Config Class Initialized
INFO - 2018-04-04 23:32:07 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:32:07 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:32:07 --> Utf8 Class Initialized
INFO - 2018-04-04 23:32:07 --> URI Class Initialized
INFO - 2018-04-04 23:32:07 --> Router Class Initialized
INFO - 2018-04-04 23:32:07 --> Output Class Initialized
INFO - 2018-04-04 23:32:07 --> Security Class Initialized
DEBUG - 2018-04-04 23:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:32:07 --> CSRF cookie sent
INFO - 2018-04-04 23:32:07 --> Input Class Initialized
INFO - 2018-04-04 23:32:07 --> Language Class Initialized
INFO - 2018-04-04 23:32:07 --> Loader Class Initialized
INFO - 2018-04-04 23:32:07 --> Helper loaded: url_helper
INFO - 2018-04-04 23:32:07 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:32:07 --> User Agent Class Initialized
INFO - 2018-04-04 23:32:07 --> Controller Class Initialized
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:32:07 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:32:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:32:07 --> Final output sent to browser
DEBUG - 2018-04-04 23:32:07 --> Total execution time: 0.3930
INFO - 2018-04-04 23:32:08 --> Config Class Initialized
INFO - 2018-04-04 23:32:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:32:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:32:08 --> Utf8 Class Initialized
INFO - 2018-04-04 23:32:08 --> URI Class Initialized
INFO - 2018-04-04 23:32:08 --> Router Class Initialized
INFO - 2018-04-04 23:32:08 --> Output Class Initialized
INFO - 2018-04-04 23:32:08 --> Security Class Initialized
DEBUG - 2018-04-04 23:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:32:08 --> CSRF cookie sent
INFO - 2018-04-04 23:32:08 --> Input Class Initialized
INFO - 2018-04-04 23:32:08 --> Language Class Initialized
ERROR - 2018-04-04 23:32:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:32:08 --> Config Class Initialized
INFO - 2018-04-04 23:32:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:32:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:32:08 --> Utf8 Class Initialized
INFO - 2018-04-04 23:32:08 --> URI Class Initialized
INFO - 2018-04-04 23:32:08 --> Router Class Initialized
INFO - 2018-04-04 23:32:08 --> Output Class Initialized
INFO - 2018-04-04 23:32:08 --> Security Class Initialized
DEBUG - 2018-04-04 23:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:32:08 --> CSRF cookie sent
INFO - 2018-04-04 23:32:08 --> Input Class Initialized
INFO - 2018-04-04 23:32:08 --> Language Class Initialized
ERROR - 2018-04-04 23:32:08 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:35:26 --> Config Class Initialized
INFO - 2018-04-04 23:35:26 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:35:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:35:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:35:26 --> URI Class Initialized
INFO - 2018-04-04 23:35:26 --> Router Class Initialized
INFO - 2018-04-04 23:35:26 --> Output Class Initialized
INFO - 2018-04-04 23:35:26 --> Security Class Initialized
DEBUG - 2018-04-04 23:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:35:26 --> CSRF cookie sent
INFO - 2018-04-04 23:35:26 --> Input Class Initialized
INFO - 2018-04-04 23:35:26 --> Language Class Initialized
INFO - 2018-04-04 23:35:26 --> Loader Class Initialized
INFO - 2018-04-04 23:35:26 --> Helper loaded: url_helper
INFO - 2018-04-04 23:35:26 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:35:26 --> User Agent Class Initialized
INFO - 2018-04-04 23:35:26 --> Controller Class Initialized
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:35:26 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:35:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:35:26 --> Final output sent to browser
DEBUG - 2018-04-04 23:35:26 --> Total execution time: 0.3517
INFO - 2018-04-04 23:35:27 --> Config Class Initialized
INFO - 2018-04-04 23:35:27 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:35:27 --> Utf8 Class Initialized
INFO - 2018-04-04 23:35:27 --> URI Class Initialized
INFO - 2018-04-04 23:35:27 --> Router Class Initialized
INFO - 2018-04-04 23:35:27 --> Output Class Initialized
INFO - 2018-04-04 23:35:27 --> Security Class Initialized
DEBUG - 2018-04-04 23:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:35:27 --> CSRF cookie sent
INFO - 2018-04-04 23:35:27 --> Input Class Initialized
INFO - 2018-04-04 23:35:27 --> Language Class Initialized
ERROR - 2018-04-04 23:35:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:35:31 --> Config Class Initialized
INFO - 2018-04-04 23:35:31 --> Config Class Initialized
INFO - 2018-04-04 23:35:31 --> Hooks Class Initialized
INFO - 2018-04-04 23:35:31 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:35:31 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:35:31 --> Utf8 Class Initialized
INFO - 2018-04-04 23:35:31 --> Utf8 Class Initialized
INFO - 2018-04-04 23:35:31 --> URI Class Initialized
INFO - 2018-04-04 23:35:31 --> URI Class Initialized
INFO - 2018-04-04 23:35:31 --> Router Class Initialized
INFO - 2018-04-04 23:35:31 --> Router Class Initialized
INFO - 2018-04-04 23:35:31 --> Output Class Initialized
INFO - 2018-04-04 23:35:31 --> Security Class Initialized
INFO - 2018-04-04 23:35:31 --> Output Class Initialized
DEBUG - 2018-04-04 23:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:35:31 --> Security Class Initialized
INFO - 2018-04-04 23:35:31 --> CSRF cookie sent
DEBUG - 2018-04-04 23:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:35:31 --> CSRF cookie sent
INFO - 2018-04-04 23:35:31 --> Input Class Initialized
INFO - 2018-04-04 23:35:31 --> Input Class Initialized
INFO - 2018-04-04 23:35:31 --> Language Class Initialized
INFO - 2018-04-04 23:35:31 --> Language Class Initialized
ERROR - 2018-04-04 23:35:31 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:35:31 --> Loader Class Initialized
INFO - 2018-04-04 23:35:31 --> Helper loaded: url_helper
INFO - 2018-04-04 23:35:31 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:35:31 --> User Agent Class Initialized
INFO - 2018-04-04 23:35:31 --> Controller Class Initialized
INFO - 2018-04-04 23:35:31 --> Pixel_Model class loaded
INFO - 2018-04-04 23:35:31 --> Database Driver Class Initialized
INFO - 2018-04-04 23:35:34 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:35:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:35:34 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:35:34 --> Final output sent to browser
DEBUG - 2018-04-04 23:35:34 --> Total execution time: 3.5814
INFO - 2018-04-04 23:36:25 --> Config Class Initialized
INFO - 2018-04-04 23:36:25 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:25 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:25 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:25 --> URI Class Initialized
INFO - 2018-04-04 23:36:25 --> Router Class Initialized
INFO - 2018-04-04 23:36:25 --> Output Class Initialized
INFO - 2018-04-04 23:36:25 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:25 --> CSRF cookie sent
INFO - 2018-04-04 23:36:25 --> Input Class Initialized
INFO - 2018-04-04 23:36:25 --> Language Class Initialized
INFO - 2018-04-04 23:36:25 --> Loader Class Initialized
INFO - 2018-04-04 23:36:25 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:25 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:25 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:25 --> Controller Class Initialized
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:36:25 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:36:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:36:25 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:25 --> Total execution time: 0.3922
INFO - 2018-04-04 23:36:26 --> Config Class Initialized
INFO - 2018-04-04 23:36:26 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:26 --> URI Class Initialized
INFO - 2018-04-04 23:36:26 --> Router Class Initialized
INFO - 2018-04-04 23:36:26 --> Output Class Initialized
INFO - 2018-04-04 23:36:26 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:26 --> CSRF cookie sent
INFO - 2018-04-04 23:36:26 --> Input Class Initialized
INFO - 2018-04-04 23:36:26 --> Language Class Initialized
ERROR - 2018-04-04 23:36:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:36:26 --> Config Class Initialized
INFO - 2018-04-04 23:36:26 --> Config Class Initialized
INFO - 2018-04-04 23:36:26 --> Hooks Class Initialized
INFO - 2018-04-04 23:36:26 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:26 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:36:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:26 --> URI Class Initialized
INFO - 2018-04-04 23:36:26 --> URI Class Initialized
INFO - 2018-04-04 23:36:26 --> Router Class Initialized
INFO - 2018-04-04 23:36:26 --> Router Class Initialized
INFO - 2018-04-04 23:36:26 --> Output Class Initialized
INFO - 2018-04-04 23:36:26 --> Output Class Initialized
INFO - 2018-04-04 23:36:26 --> Security Class Initialized
INFO - 2018-04-04 23:36:26 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 23:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:26 --> CSRF cookie sent
INFO - 2018-04-04 23:36:26 --> CSRF cookie sent
INFO - 2018-04-04 23:36:26 --> Input Class Initialized
INFO - 2018-04-04 23:36:26 --> Input Class Initialized
INFO - 2018-04-04 23:36:26 --> Language Class Initialized
INFO - 2018-04-04 23:36:26 --> Language Class Initialized
ERROR - 2018-04-04 23:36:26 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:36:26 --> Loader Class Initialized
INFO - 2018-04-04 23:36:26 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:26 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:26 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:26 --> Controller Class Initialized
INFO - 2018-04-04 23:36:27 --> Pixel_Model class loaded
INFO - 2018-04-04 23:36:27 --> Database Driver Class Initialized
INFO - 2018-04-04 23:36:30 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:36:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:36:30 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:30 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:30 --> Total execution time: 3.5291
INFO - 2018-04-04 23:36:38 --> Config Class Initialized
INFO - 2018-04-04 23:36:38 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:38 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:38 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:39 --> URI Class Initialized
INFO - 2018-04-04 23:36:39 --> Router Class Initialized
INFO - 2018-04-04 23:36:39 --> Output Class Initialized
INFO - 2018-04-04 23:36:39 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:39 --> CSRF cookie sent
INFO - 2018-04-04 23:36:39 --> Input Class Initialized
INFO - 2018-04-04 23:36:39 --> Language Class Initialized
INFO - 2018-04-04 23:36:39 --> Loader Class Initialized
INFO - 2018-04-04 23:36:39 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:39 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:39 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:39 --> Controller Class Initialized
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:36:39 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:36:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:36:39 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:39 --> Total execution time: 0.3750
INFO - 2018-04-04 23:36:39 --> Config Class Initialized
INFO - 2018-04-04 23:36:39 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:39 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:39 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:39 --> URI Class Initialized
INFO - 2018-04-04 23:36:39 --> Router Class Initialized
INFO - 2018-04-04 23:36:39 --> Output Class Initialized
INFO - 2018-04-04 23:36:39 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:40 --> CSRF cookie sent
INFO - 2018-04-04 23:36:40 --> Input Class Initialized
INFO - 2018-04-04 23:36:40 --> Language Class Initialized
ERROR - 2018-04-04 23:36:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:36:40 --> Config Class Initialized
INFO - 2018-04-04 23:36:40 --> Config Class Initialized
INFO - 2018-04-04 23:36:40 --> Hooks Class Initialized
INFO - 2018-04-04 23:36:40 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:36:40 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:40 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:40 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:40 --> URI Class Initialized
INFO - 2018-04-04 23:36:40 --> URI Class Initialized
INFO - 2018-04-04 23:36:40 --> Router Class Initialized
INFO - 2018-04-04 23:36:40 --> Router Class Initialized
INFO - 2018-04-04 23:36:40 --> Output Class Initialized
INFO - 2018-04-04 23:36:40 --> Output Class Initialized
INFO - 2018-04-04 23:36:40 --> Security Class Initialized
INFO - 2018-04-04 23:36:40 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 23:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:40 --> CSRF cookie sent
INFO - 2018-04-04 23:36:40 --> CSRF cookie sent
INFO - 2018-04-04 23:36:40 --> Input Class Initialized
INFO - 2018-04-04 23:36:40 --> Input Class Initialized
INFO - 2018-04-04 23:36:40 --> Language Class Initialized
INFO - 2018-04-04 23:36:40 --> Language Class Initialized
ERROR - 2018-04-04 23:36:40 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:36:40 --> Loader Class Initialized
INFO - 2018-04-04 23:36:40 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:40 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:40 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:40 --> Controller Class Initialized
INFO - 2018-04-04 23:36:40 --> Pixel_Model class loaded
INFO - 2018-04-04 23:36:40 --> Database Driver Class Initialized
INFO - 2018-04-04 23:36:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:36:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:36:40 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:40 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:40 --> Total execution time: 0.5554
INFO - 2018-04-04 23:36:42 --> Config Class Initialized
INFO - 2018-04-04 23:36:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:42 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:42 --> URI Class Initialized
INFO - 2018-04-04 23:36:42 --> Router Class Initialized
INFO - 2018-04-04 23:36:42 --> Output Class Initialized
INFO - 2018-04-04 23:36:42 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:42 --> CSRF cookie sent
INFO - 2018-04-04 23:36:42 --> Input Class Initialized
INFO - 2018-04-04 23:36:42 --> Language Class Initialized
INFO - 2018-04-04 23:36:42 --> Loader Class Initialized
INFO - 2018-04-04 23:36:42 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:42 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:42 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:42 --> Controller Class Initialized
INFO - 2018-04-04 23:36:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:36:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:36:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:36:42 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:36:43 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:43 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:36:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:36:43 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:43 --> Total execution time: 0.3704
INFO - 2018-04-04 23:36:43 --> Config Class Initialized
INFO - 2018-04-04 23:36:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:43 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:43 --> URI Class Initialized
INFO - 2018-04-04 23:36:43 --> Router Class Initialized
INFO - 2018-04-04 23:36:43 --> Output Class Initialized
INFO - 2018-04-04 23:36:43 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:43 --> CSRF cookie sent
INFO - 2018-04-04 23:36:43 --> Input Class Initialized
INFO - 2018-04-04 23:36:43 --> Language Class Initialized
ERROR - 2018-04-04 23:36:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:36:43 --> Config Class Initialized
INFO - 2018-04-04 23:36:43 --> Hooks Class Initialized
INFO - 2018-04-04 23:36:43 --> Config Class Initialized
INFO - 2018-04-04 23:36:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:36:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:36:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:36:43 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:43 --> Utf8 Class Initialized
INFO - 2018-04-04 23:36:43 --> URI Class Initialized
INFO - 2018-04-04 23:36:43 --> URI Class Initialized
INFO - 2018-04-04 23:36:44 --> Router Class Initialized
INFO - 2018-04-04 23:36:44 --> Router Class Initialized
INFO - 2018-04-04 23:36:44 --> Output Class Initialized
INFO - 2018-04-04 23:36:44 --> Output Class Initialized
INFO - 2018-04-04 23:36:44 --> Security Class Initialized
INFO - 2018-04-04 23:36:44 --> Security Class Initialized
DEBUG - 2018-04-04 23:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 23:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:36:44 --> CSRF cookie sent
INFO - 2018-04-04 23:36:44 --> CSRF cookie sent
INFO - 2018-04-04 23:36:44 --> Input Class Initialized
INFO - 2018-04-04 23:36:44 --> Input Class Initialized
INFO - 2018-04-04 23:36:44 --> Language Class Initialized
INFO - 2018-04-04 23:36:44 --> Language Class Initialized
ERROR - 2018-04-04 23:36:44 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:36:44 --> Loader Class Initialized
INFO - 2018-04-04 23:36:44 --> Helper loaded: url_helper
INFO - 2018-04-04 23:36:44 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:36:44 --> User Agent Class Initialized
INFO - 2018-04-04 23:36:44 --> Controller Class Initialized
INFO - 2018-04-04 23:36:44 --> Pixel_Model class loaded
INFO - 2018-04-04 23:36:44 --> Database Driver Class Initialized
INFO - 2018-04-04 23:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:36:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:36:44 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:36:44 --> Final output sent to browser
DEBUG - 2018-04-04 23:36:44 --> Total execution time: 0.5523
INFO - 2018-04-04 23:37:41 --> Config Class Initialized
INFO - 2018-04-04 23:37:41 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:37:41 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:37:41 --> Utf8 Class Initialized
INFO - 2018-04-04 23:37:41 --> URI Class Initialized
INFO - 2018-04-04 23:37:42 --> Router Class Initialized
INFO - 2018-04-04 23:37:42 --> Output Class Initialized
INFO - 2018-04-04 23:37:42 --> Security Class Initialized
DEBUG - 2018-04-04 23:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:37:42 --> CSRF cookie sent
INFO - 2018-04-04 23:37:42 --> Input Class Initialized
INFO - 2018-04-04 23:37:42 --> Language Class Initialized
INFO - 2018-04-04 23:37:42 --> Loader Class Initialized
INFO - 2018-04-04 23:37:42 --> Helper loaded: url_helper
INFO - 2018-04-04 23:37:42 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:37:42 --> User Agent Class Initialized
INFO - 2018-04-04 23:37:42 --> Controller Class Initialized
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:37:42 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:37:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:37:42 --> Final output sent to browser
DEBUG - 2018-04-04 23:37:42 --> Total execution time: 0.3520
INFO - 2018-04-04 23:37:42 --> Config Class Initialized
INFO - 2018-04-04 23:37:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:37:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:37:42 --> Utf8 Class Initialized
INFO - 2018-04-04 23:37:42 --> URI Class Initialized
INFO - 2018-04-04 23:37:42 --> Router Class Initialized
INFO - 2018-04-04 23:37:42 --> Output Class Initialized
INFO - 2018-04-04 23:37:42 --> Security Class Initialized
DEBUG - 2018-04-04 23:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:37:42 --> CSRF cookie sent
INFO - 2018-04-04 23:37:42 --> Input Class Initialized
INFO - 2018-04-04 23:37:42 --> Language Class Initialized
ERROR - 2018-04-04 23:37:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:37:43 --> Config Class Initialized
INFO - 2018-04-04 23:37:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:37:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:37:43 --> Utf8 Class Initialized
INFO - 2018-04-04 23:37:43 --> URI Class Initialized
INFO - 2018-04-04 23:37:43 --> Router Class Initialized
INFO - 2018-04-04 23:37:43 --> Output Class Initialized
INFO - 2018-04-04 23:37:43 --> Security Class Initialized
DEBUG - 2018-04-04 23:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:37:43 --> CSRF cookie sent
INFO - 2018-04-04 23:37:43 --> Input Class Initialized
INFO - 2018-04-04 23:37:43 --> Language Class Initialized
ERROR - 2018-04-04 23:37:43 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:38:32 --> Config Class Initialized
INFO - 2018-04-04 23:38:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:38:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:38:32 --> Utf8 Class Initialized
INFO - 2018-04-04 23:38:32 --> URI Class Initialized
INFO - 2018-04-04 23:38:32 --> Router Class Initialized
INFO - 2018-04-04 23:38:32 --> Output Class Initialized
INFO - 2018-04-04 23:38:32 --> Security Class Initialized
DEBUG - 2018-04-04 23:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:38:33 --> CSRF cookie sent
INFO - 2018-04-04 23:38:33 --> Input Class Initialized
INFO - 2018-04-04 23:38:33 --> Language Class Initialized
INFO - 2018-04-04 23:38:33 --> Loader Class Initialized
INFO - 2018-04-04 23:38:33 --> Helper loaded: url_helper
INFO - 2018-04-04 23:38:33 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:38:33 --> User Agent Class Initialized
INFO - 2018-04-04 23:38:33 --> Controller Class Initialized
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:38:33 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:38:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:38:33 --> Final output sent to browser
DEBUG - 2018-04-04 23:38:33 --> Total execution time: 0.3441
INFO - 2018-04-04 23:38:33 --> Config Class Initialized
INFO - 2018-04-04 23:38:33 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:38:33 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:38:33 --> Utf8 Class Initialized
INFO - 2018-04-04 23:38:33 --> URI Class Initialized
INFO - 2018-04-04 23:38:33 --> Router Class Initialized
INFO - 2018-04-04 23:38:33 --> Output Class Initialized
INFO - 2018-04-04 23:38:33 --> Security Class Initialized
DEBUG - 2018-04-04 23:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:38:33 --> CSRF cookie sent
INFO - 2018-04-04 23:38:33 --> Input Class Initialized
INFO - 2018-04-04 23:38:33 --> Language Class Initialized
ERROR - 2018-04-04 23:38:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:38:34 --> Config Class Initialized
INFO - 2018-04-04 23:38:34 --> Hooks Class Initialized
INFO - 2018-04-04 23:38:34 --> Config Class Initialized
INFO - 2018-04-04 23:38:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:38:34 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:38:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:38:34 --> Utf8 Class Initialized
INFO - 2018-04-04 23:38:34 --> Utf8 Class Initialized
INFO - 2018-04-04 23:38:34 --> URI Class Initialized
INFO - 2018-04-04 23:38:34 --> URI Class Initialized
INFO - 2018-04-04 23:38:34 --> Router Class Initialized
INFO - 2018-04-04 23:38:34 --> Router Class Initialized
INFO - 2018-04-04 23:38:34 --> Output Class Initialized
INFO - 2018-04-04 23:38:34 --> Security Class Initialized
INFO - 2018-04-04 23:38:34 --> Output Class Initialized
INFO - 2018-04-04 23:38:34 --> Security Class Initialized
DEBUG - 2018-04-04 23:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:38:34 --> CSRF cookie sent
DEBUG - 2018-04-04 23:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:38:34 --> CSRF cookie sent
INFO - 2018-04-04 23:38:34 --> Input Class Initialized
INFO - 2018-04-04 23:38:34 --> Input Class Initialized
INFO - 2018-04-04 23:38:34 --> Language Class Initialized
INFO - 2018-04-04 23:38:34 --> Language Class Initialized
INFO - 2018-04-04 23:38:34 --> Loader Class Initialized
ERROR - 2018-04-04 23:38:34 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:38:34 --> Helper loaded: url_helper
INFO - 2018-04-04 23:38:34 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:38:34 --> User Agent Class Initialized
INFO - 2018-04-04 23:38:34 --> Controller Class Initialized
INFO - 2018-04-04 23:38:34 --> Pixel_Model class loaded
INFO - 2018-04-04 23:38:34 --> Database Driver Class Initialized
INFO - 2018-04-04 23:38:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:38:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:38:37 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:38:37 --> Final output sent to browser
DEBUG - 2018-04-04 23:38:37 --> Total execution time: 3.5536
INFO - 2018-04-04 23:41:03 --> Config Class Initialized
INFO - 2018-04-04 23:41:03 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:41:03 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:41:03 --> Utf8 Class Initialized
INFO - 2018-04-04 23:41:03 --> URI Class Initialized
INFO - 2018-04-04 23:41:03 --> Router Class Initialized
INFO - 2018-04-04 23:41:03 --> Output Class Initialized
INFO - 2018-04-04 23:41:03 --> Security Class Initialized
DEBUG - 2018-04-04 23:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:41:03 --> CSRF cookie sent
INFO - 2018-04-04 23:41:03 --> Input Class Initialized
INFO - 2018-04-04 23:41:03 --> Language Class Initialized
INFO - 2018-04-04 23:41:03 --> Loader Class Initialized
INFO - 2018-04-04 23:41:03 --> Helper loaded: url_helper
INFO - 2018-04-04 23:41:03 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:41:03 --> User Agent Class Initialized
INFO - 2018-04-04 23:41:03 --> Controller Class Initialized
INFO - 2018-04-04 23:41:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:41:04 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:41:04 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:41:04 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:41:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:41:04 --> Final output sent to browser
DEBUG - 2018-04-04 23:41:04 --> Total execution time: 0.3539
INFO - 2018-04-04 23:41:04 --> Config Class Initialized
INFO - 2018-04-04 23:41:04 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:41:04 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:41:04 --> Utf8 Class Initialized
INFO - 2018-04-04 23:41:04 --> URI Class Initialized
INFO - 2018-04-04 23:41:04 --> Config Class Initialized
INFO - 2018-04-04 23:41:04 --> Router Class Initialized
INFO - 2018-04-04 23:41:04 --> Hooks Class Initialized
INFO - 2018-04-04 23:41:04 --> Output Class Initialized
INFO - 2018-04-04 23:41:04 --> Security Class Initialized
DEBUG - 2018-04-04 23:41:04 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:41:04 --> Utf8 Class Initialized
DEBUG - 2018-04-04 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:41:04 --> CSRF cookie sent
INFO - 2018-04-04 23:41:04 --> URI Class Initialized
INFO - 2018-04-04 23:41:04 --> Input Class Initialized
INFO - 2018-04-04 23:41:04 --> Router Class Initialized
INFO - 2018-04-04 23:41:04 --> Language Class Initialized
INFO - 2018-04-04 23:41:04 --> Output Class Initialized
INFO - 2018-04-04 23:41:04 --> Security Class Initialized
ERROR - 2018-04-04 23:41:04 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:41:04 --> CSRF cookie sent
INFO - 2018-04-04 23:41:04 --> Input Class Initialized
INFO - 2018-04-04 23:41:04 --> Language Class Initialized
ERROR - 2018-04-04 23:41:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:41:04 --> Config Class Initialized
INFO - 2018-04-04 23:41:04 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:41:04 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:41:04 --> Config Class Initialized
INFO - 2018-04-04 23:41:04 --> Hooks Class Initialized
INFO - 2018-04-04 23:41:04 --> Utf8 Class Initialized
INFO - 2018-04-04 23:41:05 --> URI Class Initialized
DEBUG - 2018-04-04 23:41:05 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:41:05 --> Utf8 Class Initialized
INFO - 2018-04-04 23:41:05 --> Router Class Initialized
INFO - 2018-04-04 23:41:05 --> URI Class Initialized
INFO - 2018-04-04 23:41:05 --> Output Class Initialized
INFO - 2018-04-04 23:41:05 --> Security Class Initialized
INFO - 2018-04-04 23:41:05 --> Router Class Initialized
DEBUG - 2018-04-04 23:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:41:05 --> Output Class Initialized
INFO - 2018-04-04 23:41:05 --> CSRF cookie sent
INFO - 2018-04-04 23:41:05 --> Security Class Initialized
INFO - 2018-04-04 23:41:05 --> Input Class Initialized
DEBUG - 2018-04-04 23:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:41:05 --> CSRF cookie sent
INFO - 2018-04-04 23:41:05 --> Language Class Initialized
INFO - 2018-04-04 23:41:05 --> Input Class Initialized
ERROR - 2018-04-04 23:41:05 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:41:05 --> Language Class Initialized
ERROR - 2018-04-04 23:41:05 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:43:04 --> Config Class Initialized
INFO - 2018-04-04 23:43:04 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:43:04 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:04 --> URI Class Initialized
INFO - 2018-04-04 23:43:04 --> Router Class Initialized
INFO - 2018-04-04 23:43:04 --> Output Class Initialized
INFO - 2018-04-04 23:43:04 --> Security Class Initialized
DEBUG - 2018-04-04 23:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:43:04 --> CSRF cookie sent
INFO - 2018-04-04 23:43:05 --> Input Class Initialized
INFO - 2018-04-04 23:43:05 --> Language Class Initialized
INFO - 2018-04-04 23:43:05 --> Loader Class Initialized
INFO - 2018-04-04 23:43:05 --> Helper loaded: url_helper
INFO - 2018-04-04 23:43:05 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:43:05 --> User Agent Class Initialized
INFO - 2018-04-04 23:43:05 --> Controller Class Initialized
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:43:05 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:43:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:43:05 --> Final output sent to browser
DEBUG - 2018-04-04 23:43:05 --> Total execution time: 0.3588
INFO - 2018-04-04 23:43:05 --> Config Class Initialized
INFO - 2018-04-04 23:43:05 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:43:05 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:43:05 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:05 --> URI Class Initialized
INFO - 2018-04-04 23:43:05 --> Router Class Initialized
INFO - 2018-04-04 23:43:05 --> Output Class Initialized
INFO - 2018-04-04 23:43:05 --> Security Class Initialized
DEBUG - 2018-04-04 23:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:43:05 --> CSRF cookie sent
INFO - 2018-04-04 23:43:05 --> Input Class Initialized
INFO - 2018-04-04 23:43:06 --> Language Class Initialized
ERROR - 2018-04-04 23:43:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:43:06 --> Config Class Initialized
INFO - 2018-04-04 23:43:06 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:43:06 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:43:06 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:06 --> URI Class Initialized
INFO - 2018-04-04 23:43:06 --> Config Class Initialized
INFO - 2018-04-04 23:43:06 --> Config Class Initialized
INFO - 2018-04-04 23:43:06 --> Hooks Class Initialized
INFO - 2018-04-04 23:43:06 --> Hooks Class Initialized
INFO - 2018-04-04 23:43:06 --> Router Class Initialized
INFO - 2018-04-04 23:43:06 --> Output Class Initialized
DEBUG - 2018-04-04 23:43:06 --> UTF-8 Support Enabled
DEBUG - 2018-04-04 23:43:06 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:43:06 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:06 --> Security Class Initialized
INFO - 2018-04-04 23:43:06 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:06 --> URI Class Initialized
INFO - 2018-04-04 23:43:06 --> URI Class Initialized
DEBUG - 2018-04-04 23:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:43:06 --> CSRF cookie sent
INFO - 2018-04-04 23:43:06 --> Router Class Initialized
INFO - 2018-04-04 23:43:06 --> Router Class Initialized
INFO - 2018-04-04 23:43:06 --> Input Class Initialized
INFO - 2018-04-04 23:43:06 --> Output Class Initialized
INFO - 2018-04-04 23:43:06 --> Output Class Initialized
INFO - 2018-04-04 23:43:06 --> Language Class Initialized
INFO - 2018-04-04 23:43:06 --> Security Class Initialized
INFO - 2018-04-04 23:43:06 --> Security Class Initialized
DEBUG - 2018-04-04 23:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-04 23:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:43:06 --> Loader Class Initialized
INFO - 2018-04-04 23:43:06 --> CSRF cookie sent
INFO - 2018-04-04 23:43:06 --> CSRF cookie sent
INFO - 2018-04-04 23:43:06 --> Helper loaded: url_helper
INFO - 2018-04-04 23:43:06 --> Input Class Initialized
INFO - 2018-04-04 23:43:06 --> Input Class Initialized
INFO - 2018-04-04 23:43:06 --> Helper loaded: form_helper
INFO - 2018-04-04 23:43:06 --> Language Class Initialized
INFO - 2018-04-04 23:43:06 --> Language Class Initialized
DEBUG - 2018-04-04 23:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:43:06 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-04 23:43:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-04 23:43:06 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:43:06 --> User Agent Class Initialized
INFO - 2018-04-04 23:43:06 --> Controller Class Initialized
INFO - 2018-04-04 23:43:06 --> Pixel_Model class loaded
INFO - 2018-04-04 23:43:06 --> Database Driver Class Initialized
INFO - 2018-04-04 23:43:09 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:43:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:43:09 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:43:09 --> Final output sent to browser
DEBUG - 2018-04-04 23:43:09 --> Total execution time: 3.5207
INFO - 2018-04-04 23:43:32 --> Config Class Initialized
INFO - 2018-04-04 23:43:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:43:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:43:32 --> Utf8 Class Initialized
INFO - 2018-04-04 23:43:32 --> URI Class Initialized
INFO - 2018-04-04 23:43:32 --> Router Class Initialized
INFO - 2018-04-04 23:43:32 --> Output Class Initialized
INFO - 2018-04-04 23:43:32 --> Security Class Initialized
DEBUG - 2018-04-04 23:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:43:32 --> CSRF cookie sent
INFO - 2018-04-04 23:43:32 --> Input Class Initialized
INFO - 2018-04-04 23:43:32 --> Language Class Initialized
INFO - 2018-04-04 23:43:32 --> Loader Class Initialized
INFO - 2018-04-04 23:43:32 --> Helper loaded: url_helper
INFO - 2018-04-04 23:43:33 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:43:33 --> User Agent Class Initialized
INFO - 2018-04-04 23:43:33 --> Controller Class Initialized
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:43:33 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:43:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:43:33 --> Final output sent to browser
DEBUG - 2018-04-04 23:43:33 --> Total execution time: 0.9747
INFO - 2018-04-04 23:44:59 --> Config Class Initialized
INFO - 2018-04-04 23:44:59 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:44:59 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:44:59 --> Utf8 Class Initialized
INFO - 2018-04-04 23:44:59 --> URI Class Initialized
INFO - 2018-04-04 23:44:59 --> Router Class Initialized
INFO - 2018-04-04 23:44:59 --> Output Class Initialized
INFO - 2018-04-04 23:44:59 --> Security Class Initialized
DEBUG - 2018-04-04 23:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:44:59 --> CSRF cookie sent
INFO - 2018-04-04 23:44:59 --> Input Class Initialized
INFO - 2018-04-04 23:44:59 --> Language Class Initialized
INFO - 2018-04-04 23:44:59 --> Loader Class Initialized
INFO - 2018-04-04 23:44:59 --> Helper loaded: url_helper
INFO - 2018-04-04 23:44:59 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:44:59 --> User Agent Class Initialized
INFO - 2018-04-04 23:44:59 --> Controller Class Initialized
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:44:59 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:44:59 --> Final output sent to browser
DEBUG - 2018-04-04 23:44:59 --> Total execution time: 0.3941
INFO - 2018-04-04 23:45:00 --> Config Class Initialized
INFO - 2018-04-04 23:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:00 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:00 --> URI Class Initialized
INFO - 2018-04-04 23:45:00 --> Router Class Initialized
INFO - 2018-04-04 23:45:00 --> Output Class Initialized
INFO - 2018-04-04 23:45:00 --> Security Class Initialized
DEBUG - 2018-04-04 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:00 --> CSRF cookie sent
INFO - 2018-04-04 23:45:00 --> Input Class Initialized
INFO - 2018-04-04 23:45:00 --> Language Class Initialized
ERROR - 2018-04-04 23:45:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:45:00 --> Config Class Initialized
INFO - 2018-04-04 23:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:00 --> Config Class Initialized
INFO - 2018-04-04 23:45:00 --> Config Class Initialized
INFO - 2018-04-04 23:45:00 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:00 --> Hooks Class Initialized
INFO - 2018-04-04 23:45:00 --> URI Class Initialized
INFO - 2018-04-04 23:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:00 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:00 --> Router Class Initialized
DEBUG - 2018-04-04 23:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:00 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:00 --> URI Class Initialized
INFO - 2018-04-04 23:45:00 --> Output Class Initialized
INFO - 2018-04-04 23:45:00 --> URI Class Initialized
INFO - 2018-04-04 23:45:00 --> Router Class Initialized
INFO - 2018-04-04 23:45:00 --> Security Class Initialized
INFO - 2018-04-04 23:45:00 --> Output Class Initialized
INFO - 2018-04-04 23:45:00 --> Router Class Initialized
DEBUG - 2018-04-04 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:00 --> Security Class Initialized
INFO - 2018-04-04 23:45:00 --> Output Class Initialized
INFO - 2018-04-04 23:45:00 --> CSRF cookie sent
DEBUG - 2018-04-04 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:00 --> Security Class Initialized
INFO - 2018-04-04 23:45:00 --> Input Class Initialized
INFO - 2018-04-04 23:45:00 --> CSRF cookie sent
DEBUG - 2018-04-04 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:00 --> Input Class Initialized
INFO - 2018-04-04 23:45:00 --> CSRF cookie sent
INFO - 2018-04-04 23:45:00 --> Language Class Initialized
INFO - 2018-04-04 23:45:00 --> Input Class Initialized
INFO - 2018-04-04 23:45:00 --> Language Class Initialized
INFO - 2018-04-04 23:45:00 --> Loader Class Initialized
INFO - 2018-04-04 23:45:00 --> Language Class Initialized
ERROR - 2018-04-04 23:45:00 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:45:00 --> Helper loaded: url_helper
INFO - 2018-04-04 23:45:00 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:45:00 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:45:00 --> User Agent Class Initialized
INFO - 2018-04-04 23:45:00 --> Controller Class Initialized
INFO - 2018-04-04 23:45:00 --> Pixel_Model class loaded
INFO - 2018-04-04 23:45:00 --> Database Driver Class Initialized
INFO - 2018-04-04 23:45:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:45:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:45:04 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:45:04 --> Final output sent to browser
DEBUG - 2018-04-04 23:45:04 --> Total execution time: 3.5475
INFO - 2018-04-04 23:45:46 --> Config Class Initialized
INFO - 2018-04-04 23:45:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:45:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:46 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:46 --> URI Class Initialized
INFO - 2018-04-04 23:45:46 --> Router Class Initialized
INFO - 2018-04-04 23:45:46 --> Output Class Initialized
INFO - 2018-04-04 23:45:46 --> Security Class Initialized
DEBUG - 2018-04-04 23:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:46 --> CSRF cookie sent
INFO - 2018-04-04 23:45:46 --> Input Class Initialized
INFO - 2018-04-04 23:45:46 --> Language Class Initialized
INFO - 2018-04-04 23:45:46 --> Loader Class Initialized
INFO - 2018-04-04 23:45:46 --> Helper loaded: url_helper
INFO - 2018-04-04 23:45:46 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:45:46 --> User Agent Class Initialized
INFO - 2018-04-04 23:45:46 --> Controller Class Initialized
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:45:46 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:45:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:45:46 --> Final output sent to browser
DEBUG - 2018-04-04 23:45:46 --> Total execution time: 0.3723
INFO - 2018-04-04 23:45:47 --> Config Class Initialized
INFO - 2018-04-04 23:45:47 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:47 --> URI Class Initialized
INFO - 2018-04-04 23:45:47 --> Router Class Initialized
INFO - 2018-04-04 23:45:47 --> Output Class Initialized
INFO - 2018-04-04 23:45:47 --> Security Class Initialized
DEBUG - 2018-04-04 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:47 --> CSRF cookie sent
INFO - 2018-04-04 23:45:47 --> Input Class Initialized
INFO - 2018-04-04 23:45:47 --> Language Class Initialized
ERROR - 2018-04-04 23:45:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:45:47 --> Config Class Initialized
INFO - 2018-04-04 23:45:47 --> Hooks Class Initialized
INFO - 2018-04-04 23:45:47 --> Config Class Initialized
DEBUG - 2018-04-04 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:47 --> Config Class Initialized
INFO - 2018-04-04 23:45:47 --> Hooks Class Initialized
INFO - 2018-04-04 23:45:47 --> Hooks Class Initialized
INFO - 2018-04-04 23:45:47 --> Utf8 Class Initialized
DEBUG - 2018-04-04 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:47 --> URI Class Initialized
DEBUG - 2018-04-04 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:45:47 --> Utf8 Class Initialized
INFO - 2018-04-04 23:45:47 --> URI Class Initialized
INFO - 2018-04-04 23:45:47 --> Router Class Initialized
INFO - 2018-04-04 23:45:47 --> Router Class Initialized
INFO - 2018-04-04 23:45:47 --> URI Class Initialized
INFO - 2018-04-04 23:45:47 --> Output Class Initialized
INFO - 2018-04-04 23:45:47 --> Security Class Initialized
INFO - 2018-04-04 23:45:47 --> Output Class Initialized
INFO - 2018-04-04 23:45:47 --> Router Class Initialized
INFO - 2018-04-04 23:45:47 --> Security Class Initialized
DEBUG - 2018-04-04 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:47 --> Output Class Initialized
INFO - 2018-04-04 23:45:47 --> CSRF cookie sent
DEBUG - 2018-04-04 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:47 --> Security Class Initialized
INFO - 2018-04-04 23:45:47 --> Input Class Initialized
INFO - 2018-04-04 23:45:47 --> CSRF cookie sent
DEBUG - 2018-04-04 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:45:47 --> Input Class Initialized
INFO - 2018-04-04 23:45:47 --> CSRF cookie sent
INFO - 2018-04-04 23:45:47 --> Language Class Initialized
INFO - 2018-04-04 23:45:47 --> Input Class Initialized
INFO - 2018-04-04 23:45:47 --> Language Class Initialized
INFO - 2018-04-04 23:45:47 --> Loader Class Initialized
INFO - 2018-04-04 23:45:47 --> Language Class Initialized
INFO - 2018-04-04 23:45:47 --> Helper loaded: url_helper
ERROR - 2018-04-04 23:45:47 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:45:47 --> Helper loaded: form_helper
ERROR - 2018-04-04 23:45:47 --> 404 Page Not Found: Assets/js
DEBUG - 2018-04-04 23:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:45:47 --> User Agent Class Initialized
INFO - 2018-04-04 23:45:47 --> Controller Class Initialized
INFO - 2018-04-04 23:45:47 --> Pixel_Model class loaded
INFO - 2018-04-04 23:45:47 --> Database Driver Class Initialized
INFO - 2018-04-04 23:45:50 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:45:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:45:51 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:45:51 --> Final output sent to browser
DEBUG - 2018-04-04 23:45:51 --> Total execution time: 3.6827
INFO - 2018-04-04 23:55:24 --> Config Class Initialized
INFO - 2018-04-04 23:55:24 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:55:24 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:55:24 --> Utf8 Class Initialized
INFO - 2018-04-04 23:55:24 --> URI Class Initialized
INFO - 2018-04-04 23:55:24 --> Router Class Initialized
INFO - 2018-04-04 23:55:24 --> Output Class Initialized
INFO - 2018-04-04 23:55:24 --> Security Class Initialized
DEBUG - 2018-04-04 23:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:55:24 --> CSRF cookie sent
INFO - 2018-04-04 23:55:24 --> Input Class Initialized
INFO - 2018-04-04 23:55:24 --> Language Class Initialized
INFO - 2018-04-04 23:55:24 --> Loader Class Initialized
INFO - 2018-04-04 23:55:24 --> Helper loaded: url_helper
INFO - 2018-04-04 23:55:24 --> Helper loaded: form_helper
DEBUG - 2018-04-04 23:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 23:55:24 --> User Agent Class Initialized
INFO - 2018-04-04 23:55:24 --> Controller Class Initialized
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-04 23:55:25 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\questions\life_decision.php 10
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\start_questions.php
INFO - 2018-04-04 23:55:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-04 23:55:25 --> Final output sent to browser
DEBUG - 2018-04-04 23:55:25 --> Total execution time: 0.3644
INFO - 2018-04-04 23:55:25 --> Config Class Initialized
INFO - 2018-04-04 23:55:25 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:55:25 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:55:25 --> Utf8 Class Initialized
INFO - 2018-04-04 23:55:25 --> URI Class Initialized
INFO - 2018-04-04 23:55:25 --> Router Class Initialized
INFO - 2018-04-04 23:55:25 --> Output Class Initialized
INFO - 2018-04-04 23:55:25 --> Security Class Initialized
DEBUG - 2018-04-04 23:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:55:25 --> CSRF cookie sent
INFO - 2018-04-04 23:55:25 --> Input Class Initialized
INFO - 2018-04-04 23:55:25 --> Language Class Initialized
ERROR - 2018-04-04 23:55:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-04 23:55:26 --> Config Class Initialized
INFO - 2018-04-04 23:55:26 --> Hooks Class Initialized
DEBUG - 2018-04-04 23:55:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:55:26 --> Config Class Initialized
INFO - 2018-04-04 23:55:26 --> Hooks Class Initialized
INFO - 2018-04-04 23:55:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:55:26 --> URI Class Initialized
DEBUG - 2018-04-04 23:55:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:55:26 --> Router Class Initialized
INFO - 2018-04-04 23:55:26 --> Config Class Initialized
INFO - 2018-04-04 23:55:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:55:26 --> Hooks Class Initialized
INFO - 2018-04-04 23:55:26 --> URI Class Initialized
INFO - 2018-04-04 23:55:26 --> Output Class Initialized
DEBUG - 2018-04-04 23:55:26 --> UTF-8 Support Enabled
INFO - 2018-04-04 23:55:26 --> Router Class Initialized
INFO - 2018-04-04 23:55:26 --> Utf8 Class Initialized
INFO - 2018-04-04 23:55:26 --> Security Class Initialized
INFO - 2018-04-04 23:55:26 --> Output Class Initialized
DEBUG - 2018-04-04 23:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:55:26 --> Security Class Initialized
INFO - 2018-04-04 23:55:26 --> URI Class Initialized
INFO - 2018-04-04 23:55:26 --> CSRF cookie sent
INFO - 2018-04-04 23:55:26 --> Router Class Initialized
DEBUG - 2018-04-04 23:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:55:26 --> CSRF cookie sent
INFO - 2018-04-04 23:55:26 --> Input Class Initialized
INFO - 2018-04-04 23:55:26 --> Output Class Initialized
INFO - 2018-04-04 23:55:26 --> Input Class Initialized
INFO - 2018-04-04 23:55:26 --> Language Class Initialized
INFO - 2018-04-04 23:55:26 --> Security Class Initialized
INFO - 2018-04-04 23:55:26 --> Language Class Initialized
DEBUG - 2018-04-04 23:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 23:55:26 --> Loader Class Initialized
INFO - 2018-04-04 23:55:26 --> CSRF cookie sent
INFO - 2018-04-04 23:55:26 --> Helper loaded: url_helper
ERROR - 2018-04-04 23:55:26 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:55:26 --> Helper loaded: form_helper
INFO - 2018-04-04 23:55:26 --> Input Class Initialized
INFO - 2018-04-04 23:55:26 --> Language Class Initialized
DEBUG - 2018-04-04 23:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 23:55:26 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-04 23:55:26 --> 404 Page Not Found: Assets/js
INFO - 2018-04-04 23:55:26 --> User Agent Class Initialized
INFO - 2018-04-04 23:55:26 --> Controller Class Initialized
INFO - 2018-04-04 23:55:26 --> Pixel_Model class loaded
INFO - 2018-04-04 23:55:26 --> Database Driver Class Initialized
INFO - 2018-04-04 23:55:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-04 23:55:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-04 23:55:29 --> File loaded: E:\www\yacopoo\application\views\questions/life_decision.php
INFO - 2018-04-04 23:55:29 --> Final output sent to browser
DEBUG - 2018-04-04 23:55:29 --> Total execution time: 3.6019
